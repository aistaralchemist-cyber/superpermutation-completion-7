# Lean replay for the price-137 reduction

Jaehun Jung, 25 November 2026. The three endpoint modules concern partial words and price-137 covers of the 720 rotation classes of permutations on seven symbols. Lean checks each statement with its displayed hypotheses.

| Theorem in `ExactWordFlow.HistoricalTransfer` | Conclusion |
| --- | --- |
| `word_to_exact_price` | A word of length 1,196 that visits all 720 classes and completes exactly 48 yields a covering board of price 137 with 1–11 trails. |
| `word_to_eight_at_137` | Given the three caps `TrailCap 1 96 40`, `TrailCap 10 42 85`, and `TrailCap 11 36 90`, the trail count can be restricted to 2–9. |
| `exact_price_without_width_five` | Such a board can be replaced by one at the same price and trail count whose trails contain no width-five row. The replacement may change the number of holes and packets. |
| `full_runs_without_fives` | On a width-five-free board of exact price 137, a trail contains two consecutive full rows. Three are forced with at least three trails, and four with at least nine. |
| `lower_of_eight_at_137` | The three caps together with an exclusion of every remaining board would give a lower bound of 5,901. |

The geometric search described in the parent directory is open. Its numerical filters, timeouts, and restricted searches supply no proof of the last theorem’s uniform exclusion hypothesis.

## Stage and check the inputs

The staging step uses Python 3 and Git. Start in the extracted `price137/lean` directory. When working outside a clone of the paper repository, first download its pinned base archive with the command below. The staging script checks its SHA-256.

```sh
curl -fL https://raw.githubusercontent.com/aistaralchemist-cyber/superpermutation-completion-7/4a98a9ae38cd6ec82c0ee0622a49419c3d98d453/seven-symbol-verification.zip -o ../../seven-symbol-verification.zip
```
 These commands create two external source checkouts and a new Lake project under a fresh temporary directory.

```sh
work=$(mktemp -d)
git clone https://github.com/jhalfar/superpermutation-almanac-lean.git "$work/site"
git clone --filter=blob:none https://github.com/jhalfar/superpermutations.git "$work/research"
python3 prepare.py \
  --archive ../../seven-symbol-verification.zip \
  --site "$work/site" --research "$work/research" --output "$work/replay"
```

The program reads the Halfar files from Git at commit `8e3c02b5234b49a1422751f86f9e472706082374`. It checks out the Almanac library at `a09f9ef4ebb74ae1297f17c5fad38296695f2959`. The public seven-symbol archive is identified by SHA-256 `0f58e7441ccd42c12119ebb988d9874f30822863b93d31e5463b0e03c90c41fd`. Its 214 selected modules are joined by one module restored from a template and the pinned catalogue word 7-5905-071, 31 Halfar research modules, and 47 local sources. The 293 modules and 10 included data files are listed with their origins and final SHA-256 hashes. A one-line proof-port change to Halfar’s `LowerBounds.J16Rules` is recorded explicitly in the staging script. [Source manifest](sources.tsv) · [Staging script](prepare.py)

## Choose a replay

With Lean 4.35.0 and Lake installed, a researcher who wants to rebuild the dependency tree can run the following in the prepared checkout. The full build includes earlier combinatorial searches and certificate checks. Elapsed time and peak memory for a clean full build have not been measured.

```sh
(cd "$work/replay" && lake exe cache get && lake build +Price137FullRuns)
```

Where the dependency objects have already been built, the following shorter check freshly elaborates the three endpoint files, printing their axiom inventories. `LEAN_PATH` must point to trustworthy objects compiled from the matching sources. For the clean project above, it can be obtained from its Lake environment.

```sh
export LEAN_PATH="$(cd "$work/replay" && lake env printenv LEAN_PATH)"
export LEAN="$(cd "$work/replay" && lake env lean --print-prefix)/bin/lean"
sh check-endpoints.sh
```

For this release the full source tree was staged and hash-checked. The three endpoint files were separately recompiled with Lean 4.35.0 using an existing local dependency build. The fresh full dependency rebuild is left for independent replay. The word-to-board reduction trusts Lean’s native evaluator for finite computations. [Endpoint check log](checked-endpoints.log)

## Source credits

The pinned Almanac project carries its original `NOTICE`, `SOURCES.tsv`, and licenses for its bundled libraries, including the work of Jakub Halfar, Jay Pantone, urdvr, and Xiaolong Liu. The preparation script preserves these and installs the additional Halfar research checkout’s `LICENSE` and `NOTICE` in the staging directory. Record 7-5905-071 is obtained from Halfar’s catalogue via the pinned Git object. Jaehun Jung directed this study with assistance from OpenAI Codex. [Almanac formal library](https://github.com/jhalfar/superpermutation-almanac-lean/tree/a09f9ef4ebb74ae1297f17c5fad38296695f2959) · [Halfar research sources](https://github.com/jhalfar/superpermutations/tree/8e3c02b5234b49a1422751f86f9e472706082374) · [Seven-symbol base supplement](https://github.com/aistaralchemist-cyber/superpermutation-completion-7/tree/4a98a9ae38cd6ec82c0ee0622a49419c3d98d453)

import RingSeedResult
import LowerBounds.PFinalK16
import LowerBounds.PK16F0Native
import HalfarRing5901

/-! The earlier chain bound plus a fresh ring evaluation imply the geometric
RX statement without any 5,900 or defect-sixteen hypothesis. -/
namespace ExactWordFlow.Core1224
open SuperpermLowerBounds T5899

theorem rx_unconditional : J16.RX := by
  have chain0 : PS.SeqCapLt 7 0 (PS.capF Ptabs 0) 85 :=
    K16.seqCap_of_k16search (by decide) (by decide) (by decide)
      (fun j hj => absurd hj (Nat.not_lt_zero j)) (PS.seqCapLt_zero _ _ _) (PS.covered_one K16.f0k)
  have chain : PS.SeqCapLt 7 0 (fun x => Mtab.getD x 0) (63 + 1) := by
    rw [← capF_zero]
    exact chain0.mono (by decide)
  apply PS.ringCapT_of_search (by decide) (by decide) (by decide : 0 < 16) chain
  exact PS.covered_one (ring_rows_exact ▸ rx63_seed)

#print axioms rx_unconditional
end ExactWordFlow.Core1224

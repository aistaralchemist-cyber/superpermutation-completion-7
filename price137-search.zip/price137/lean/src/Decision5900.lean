import GlobalClosedPrice
import BudgetCoreCurve

/-! Consequences of the component price for seven symbols at length 5,900. -/
namespace ExactWordFlow.Audit5900
open SevenWordWindows SuperpermutationBounds ResidualDensity ResidualRoutes RotationComponentCount

theorem lower5896 (w : Block) (hw : Covers w) : 5896 ≤ w.length := by
  obtain ⟨a,b,word⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
  obtain ⟨X,size,h⟩ := extract_at_ends w hw (by simp [word]; omega)
  have bound := GlobalClosedPrice.budget h
  omega

theorem outside52 {X : Multiset Block} {s t : Block} (h : Feasible X s t) (sz : X.card≤854) :
    (occupied X s).card ≤ 52 := by
  classical
  have b := GlobalClosedPrice.budget h
  have pay (q) (_ : q ∈ occupied X s) : 3 ≤ GlobalClosedPrice.fee ((part X q).card) := by
    unfold GlobalClosedPrice.fee
    omega
  have cheap := Finset.sum_le_sum pay
  simp only [Finset.sum_const, smul_eq_mul] at cheap
  omega

theorem decision5900 :
    (∃w : Block, Covers w ∧ w.length≤5900) ↔ BudgetCoreCurve.atLength 1224 52 :=
  BudgetCoreCurve.threshold 854 52 (by decide) (fun h cap => outside52 h cap)

#print axioms lower5896
#print axioms outside52
#print axioms decision5900
end ExactWordFlow.Audit5900

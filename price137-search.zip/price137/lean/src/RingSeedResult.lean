import RingSearchResult
import LowerBounds.PTables

/-! Independently check the ring row against the older chain upper bounds
already certified in the 5,899 submission. -/
namespace ExactWordFlow.Core1224
open SuperpermLowerBounds SuperpermLowerBounds.T5899

theorem rx63_seed :
    PS.ringSearch 7 Mtab ringRows 63 400 13 16 0 16 = false := by
  native_decide

#print axioms rx63_seed
end ExactWordFlow.Core1224

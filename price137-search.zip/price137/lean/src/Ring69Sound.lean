import Defect16Obstruction
import Ring69Seed
import LowerBounds.KFinal

namespace ExactWordFlow.Defect16Obstruction
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.T5900

/-- The inherited seed table reconstructed from the accepted 5,899 submission. -/
theorem seed_checked : KS.SetB := by
  obtain ⟨c0, c1, c2, c3, c4, c5⟩ := seqCaps_of_k16 (by decide) (by decide)
    (by decide) (by decide) (by decide) (by decide)
    (PS.covered_one K16.f0k) (PS.covered_one K16.f1k) (PS.covered_one K16.f2k)
    (PS.covered_one K16.f3k) (PS.covered_one K16.f4k) (PS.covered_one K16.f5k)
  refine ⟨c0, c1, c2, c3, c4, c5, ?_⟩
  have chain : PS.SeqCapLt 7 0 (fun x => Mtab.getD x 0) (77+1) := by
    rw [← capF_zero]
    exact c0.mono (by decide)
  exact PS.ringCapT_of_search (by decide) (by decide) (by decide) chain
    (PS.covered_one PS.ring)

theorem middle_checked : middleRing := by
  have chain : PS.SeqCapLt 7 0 (fun x => Mtab.getD x 0) (69+1) := by
    rw [← capF_zero]
    exact seed_checked.1.mono (by decide)
  have rings : PS.RingCapT 7 (fun x => TRtab.getD x 0) 69 :=
    PS.ringCapT_of_search (by decide) (by decide) (by decide) chain (PS.covered_one ring69_seed)
  intro L hp h64 h69
  have bound := rings L hp.1 hp.2.1 hp.2.2.1 hp.2.2.2 h69
  have numeric : ∀ i : Fin 70, 64 ≤ i.val → TRtab.getD i.val 0 = i.val+31 := by native_decide
  exact bound.trans_eq (numeric ⟨PS.holesT 7 L,by omega⟩ h64)

theorem table_of_kernel (hK : K16.TheoremK16) : KS.TableT :=
  table_from_six hK middle_checked

#print axioms middle_checked
#print axioms table_of_kernel
end ExactWordFlow.Defect16Obstruction

import Core1224
import FortyEight854

namespace ExactWordFlow.Core1224
open SevenWordWindows SuperpermutationBounds RotationCore

/-- These quantify over words of the indicated exact length; the inequalities count
completed rotation classes of a word that visits all 720. -/
def completionAtMost (length bound : Nat) : Prop :=
  ∀ v : Block, v.length = length → (visited v).card = 720 → (complete v).card ≤ bound

private theorem atMost_iff (l k : Nat) :
    completionAtMost l k ↔ ¬ BudgetCoreCurve.atLength l (k+1) := by
  constructor
  · rintro h ⟨v, length, visited, many⟩
    have := h v length visited
    omega
  · intro no v length visited
    by_contra! many
    exact no ⟨v, length, visited, by omega⟩

theorem almanac_iff_atMost51 :
    Almanac.LowerBoundAt 7 5901 ↔ completionAtMost 1224 51 :=
  almanac_iff_core.trans (atMost_iff 1224 51).symm

theorem atMost51_iff_atMost47 : completionAtMost 1224 51 ↔ completionAtMost 1196 47 := by
  rw [atMost_iff, atMost_iff]
  exact not_congr (Audit5900.decision5900.symm.trans FortyEight854.decision1196)

theorem atMost52 : completionAtMost 1224 52 := by
  intro v len vis
  have floor := expansion_floor v (by omega) vis
  omega

theorem atMost48 : completionAtMost 1196 48 := by
  intro v len vis
  have floor := expansion_floor v (by omega) vis
  omega

#print axioms almanac_iff_atMost51
#print axioms atMost51_iff_atMost47
#print axioms atMost52
#print axioms atMost48
end ExactWordFlow.Core1224

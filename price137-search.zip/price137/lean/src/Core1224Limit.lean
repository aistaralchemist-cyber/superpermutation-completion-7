import Core1224

namespace ExactWordFlow.Core1224
open SevenWordWindows RotationCore RotationReinsert

theorem length_of_visits (v : Block) (vis : (visited v).card = 720) : 725 ≤ v.length := by
  let good := (anchors v).filter (fun u => decide (ResidualDensity.full u))
  have distinct := List.toFinset_card_le (good.map ResidualDensity.tag)
  have keep := List.length_filter_le (fun u => decide (ResidualDensity.full u)) (anchors v)
  change (good.map ResidualDensity.tag).toFinset.card = 720 at vis
  change good.length ≤ (anchors v).length at keep
  rw [List.length_map] at distinct
  simp only [anchors, List.length_cons, List.length_map, windows_length] at keep
  omega

/-- The official bound is equivalent to the all-words, at-most formulation. -/
theorem almanac_iff_uniform_limit :
    Almanac.LowerBoundAt 7 5901 ↔
      ∀ v : Block, v.length ≤ 1224 → (visited v).card = 720 → (complete v).card ≤ 51 := by
  rw [almanac_iff_core]
  constructor
  · intro exclude v small vis
    by_contra! enough
    obtain ⟨z, sz, sameVis, sameCom⟩ := ExactBoundary.pad (v := v) (by
      have := length_of_visits v vis
      omega) small
    exact exclude ⟨z, sz, sameVis ▸ vis, sameCom ▸ (by omega)⟩
  · rintro limit ⟨v, length, vis, completed⟩
    have maxDone := limit v (by omega) vis
    omega

#print axioms length_of_visits
#print axioms almanac_iff_uniform_limit
end ExactWordFlow.Core1224

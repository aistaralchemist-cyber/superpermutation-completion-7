import Window573
import FiveLong854

namespace ExactWordFlow.Window597
open SevenWordWindows ResidualDensity DirectedEuler WeightedMarks MarkedGeometry MarkEnvelope854
open private initial start accepted move memoryWord prefixes from MarkedDensity
open private upper_read upper_step from MarkEnvelope854
open private unmask mask_cons from StrongerDensity
open private canonical normalize from Interval66
open private search_complete from Geometry40
open private runs from MarkedExtrema

open private optimal maximizer obstructions no_profile from Window561
open private submask from MarkedGeometry
open private count_add from DensityBudget

open private extra no_extra from Window567

/-- Untrusted one-gap obstruction certificate. Every decoded row is checked
against all canonical starting states by the theorem below. -/
private def further : List (List Nat) :=
  ((include_str "root597-rows.txt").splitOn "\n").filterMap fun row =>
    if row.isEmpty then none else some ((row.splitOn "0").map String.length)

private theorem rejected : further.all (fun ns =>
    !ns.isEmpty && ns.all (fun n=>decide (0<n)) &&
    canonical.all (fun s => !rowSearch ns s []))=true := by native_decide

private theorem no_further {u : ℕ→Six} {p : ℕ→Prop} (w : Walk u) (h : Marked u p)
    (ns : List Nat) (hn : ns∈further) (i : ℕ) (marks : rowsMarked p i ns) : False := by
  have ⟨⟨nonempty,positive⟩,bad⟩ := Bool.and_eq_true_iff.mp (List.all_eq_true.mp rejected ns hn)
    |>.imp_left Bool.and_eq_true_iff.mp
  have pos (n) (hm : n∈ns) := of_decide_eq_true (List.all_eq_true.mp positive n hm)
  have first : p i := by
    cases ns with
    | nil => simp at nonempty
    | cons n rest => simpa using marks.1 0 (pos n List.mem_cons_self)
  obtain ⟨v,vw,vm,initial⟩:=normalize w h i first
  have yes:=search_complete vw vm ns pos i marks [] (by simp)
  have no:=List.all_eq_true.mp bad _ initial
  simp [yes] at no



private def more := obstructions ++ extra ++ further
private def excluded := forbidden ++ more.map rowsMask

private theorem avoids {u : Nat → Six} {p : Nat → Prop} [DecidablePred p] (w : Walk u)
    (m : Marked u p) (i n : Nat) : ∀ x ∈ excluded, ¬ x <:+: mask p i n := by
  intro x mem
  rcases List.mem_append.mp mem with base | extraMem
  · exact safe w m i n x base
  · obtain ⟨ns,hn,rfl⟩ := List.mem_map.mp extraMem
    intro ⟨l,r,hx⟩
    have sub:=submask i n l (rowsMask ns) r hx
    have marks:=unmask _ _ ns sub
    rcases List.mem_append.mp hn with old | fresh
    · rcases List.mem_append.mp old with prior | next
      · exact no_profile w m ns prior _ marks
      · exact no_extra w m ns next _ marks
    · exact no_further w m ns fresh _ marks

/-- Retain a suffix which is a prefix of an excluded mask. The soundness check
below validates the suffix remembered on each accepted transition, as well as
the obstructing suffix on each rejected transition. -/
private structure Node where
  parent : Nat
  bit : Bool
  left : Nat
  right : Nat
  deriving Inhabited

private def nodes : Array Node :=
  (((include_str "root597-transitions.txt").splitOn "\n").filterMap fun line =>
    match (line.splitOn " ").mapM String.toNat? with
    | some [p,b,l,r] => some (⟨p,b==1,l,r⟩ : Node)
    | _ => none).toArray

private def revWords : Array (List Bool) :=
  nodes.foldl (fun a node=>a.push (if a.isEmpty then [] else
    node.bit::a[node.parent]?.getD [])) #[]

private def memory (s : Nat) := (revWords[s]?.getD []).reverse

private def links := nodes.map fun r=>(r.left,r.right)
private def advance (s : Nat) (b : Bool) : Nat :=
  let edge := links[s]?.getD (nodes.size,nodes.size)
  if b then edge.2 else edge.1

private def validMove (s : Nat) (b : Bool) :=
  let j := advance s b
  let ext := memory s++[b]
  if j<nodes.size then (memory j).isSuffixOf ext
  else match excluded[j-nodes.size]? with
       | some q=>q.isSuffixOf ext
       | none=>false

set_option maxRecDepth 16384 in
private theorem sound : (0 < nodes.size ∧ memory 0=[]) ∧
    ∀s : Fin nodes.size, validMove s.val false=true ∧ validMove s.val true=true := by native_decide

private theorem accepts (s : Nat) (b : Bool) (pre bs : List Bool) (ok : s<nodes.size)
    (suffix : memory s <:+ pre) (keep : ∀x∈excluded, ¬x <:+: pre++b::bs) :
    advance s b<nodes.size ∧ memory (advance s b) <:+ pre++[b] := by
  have checked : validMove s b=true := by
    cases b
    · exact (sound.2 ⟨s,ok⟩).1
    · exact (sound.2 ⟨s,ok⟩).2
  have longer : memory s++[b] <:+ pre++[b] := by
    obtain ⟨left,eq⟩:=suffix
    exact ⟨left,by simp [←List.append_assoc,eq]⟩
  unfold validMove at checked
  by_cases inside : advance s b<nodes.size
  · rw [ite_eq_left inside] at checked
    exact ⟨inside,(List.isSuffixOf_iff_suffix.mp checked).trans longer⟩
  · rw [ite_eq_right inside] at checked
    generalize hq : excluded[advance s b-nodes.size]? = opt at checked
    cases opt with
    | none => simp at checked
    | some x =>
      have hx : x∈excluded := List.mem_of_getElem? hq
      have bad := checked
      have bad' := ((List.isSuffixOf_iff_suffix.mp bad).trans longer).isInfix
      exact False.elim (keep _ hx (by simpa using bad'.trans (List.prefix_append (pre++[b]) bs).isInfix))

private def scores : Nat → Array Nat
  | 0 => #[]
  | n+1 =>
    let v:=scores n
    links.map fun (l,r)=>max (v[l]?.getD 0) (if r<nodes.size then 1+v[r]?.getD 0 else 0)

private def score (n s : Nat) := (scores n)[s]?.getD 0

private theorem pay {s : Nat} (n : Nat) (b : Bool) (ok : s<nodes.size)
    (next : advance s b<nodes.size) :
    b.toNat + score n (advance s b) ≤ score (n+1) s := by
  have sz : s<links.size := by simpa [links] using ok
  generalize eq : links[s] = link
  obtain ⟨l,r⟩ := link
  have someLink : links[s]? = some (l,r) := by rw [getElem?_pos links s sz,eq]
  have bound : score (n+1) s =
      max (score n l) (if r<nodes.size then 1+score n r else 0) := by
    simp [score,scores,Array.getElem?_map,someLink]
  rw [bound]
  cases b <;> simp_all [advance,score]

private theorem read_score (pre rest : List Bool) (s : Nat) (ok : s<nodes.size)
    (suffix : memory s <:+ pre) (keep : ∀x∈excluded, ¬x <:+: pre++rest) :
    rest.count true ≤ score rest.length s := by
  induction rest generalizing s pre with
  | nil => simp
  | cons b bs ih =>
    obtain ⟨next,suff⟩:=accepts s b pre bs ok suffix keep
    have tail:=ih (pre++[b]) _ next suff (by simpa using keep)
    have cost:=pay bs.length b ok next
    cases b <;> simp only [List.count_cons_self,List.count_cons_of_ne (by decide : false≠true),
      List.length_cons,Bool.toNat_false,Bool.toNat_true] at * <;> omega

theorem interval {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i n : Nat) :
    count p i n ≤ score n 0 := by
  have h:=read_score [] (mask p i n) 0 sound.1.1 (by simp [sound.1.2])
    (by simpa using avoids w m i n)
  rw [mark_count] at h
  simpa [mask] using h

private def table : List (Nat × Nat) :=
  [(578,489),(584,494),(590,499),(596,504),(561,475),(567,480)]

private theorem limits : table.all (fun q=>decide (score (q.1+1) 0 ≤ q.2))=true := by
  native_decide

theorem route {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀e∈es,e.length=7) {k c : Nat} (member : (k,c)∈table) (len : es.length≤k) :
    classCount s es≤c := by
  obtain ⟨u,I,w,m,h⟩:=open_observations r wd
  have cap:=interval w m 0 (k+1)
  have lim:=of_decide_eq_true (List.all_eq_true.mp limits _ member)
  change score (k+1) 0≤c at lim
  have add:=count_add (·∈I) 0 (es.length+1) (k-es.length)
  rw [show es.length+1+(k-es.length)=k+1 by omega] at add
  omega

open SevenWordWindows DirectedEuler ResidualDensity ResidualRoutes RotationComponentCount
open ResidualIncidence SuperpermutationBounds
open private hits Cost totals rank_partition from NearHundredShape
open private lump from GlobalClosedPrice
open private initial from MarkedDensity

/-- High component counts allow at most one long component, which then
has 35 edges. The open window contradicts the required incidence rank in
both shapes, including a 35-edge component. -/
theorem outside42 {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤854) :
    (occupied X s).card≤42 := by
  classical
  by_contra! hn
  let Q:=occupied X s
  let home:=label X s
  let L:=Q.filter (fun q=>6<Cost X q)
  have high : 43≤Q.card := hn
  have low : Q.card≤46 := Window573.outside46 h bd
  have budget:=FiveLong854.budget h bd
  change 3*Q.card+22*L.card+12*(Q.filter (fun q=>6<Cost X q ∧ ¬(Cost X q=35 ∧ hits X s q=30))).card≤156 at budget
  have small : L.card≤1 := by omega
  have all35 (q) (hq:q∈L) : Cost X q=35 := by
    obtain ⟨mem,large⟩:=Finset.mem_filter.mp hq
    by_contra diff
    have pos:=Finset.card_pos.mpr (show (Q.filter (fun q=>6<Cost X q ∧ ¬(Cost X q=35 ∧ hits X s q=30))).Nonempty from
      ⟨q,Finset.mem_filter.mpr ⟨mem,large,fun hh=>diff hh.1⟩⟩)
    have : 0<L.card:=Finset.card_pos.mpr ⟨q,hq⟩
    omega
  have per (q) (hq:q∈Q) : Cost X q-6 = if 6<Cost X q then 29 else 0 := by
    split
    next isLong => have := all35 q (Finset.mem_filter.mpr ⟨hq,isLong⟩); omega
    next isShort => omega
  have excess : ∑q∈Q,(Cost X q-6)=29*L.card := by
    rw [Finset.sum_congr rfl per,lump]
  obtain ⟨mass,pay⟩:=totals h
  change Cost X home+6*Q.card+(∑q∈Q,(Cost X q-6))=X.card at mass
  change 7*(∑q∈Q,(hits X s q-1))+(if 0<(∑q∈Q,(Cost X q-6)) then 6 else 0)≤
    35*Q.card+6*(∑q∈Q,(Cost X q-6)) at pay
  rw [excess] at mass pay
  have rank:=rank_partition h
  change separateRank X s=hits X s home-1+∑q∈Q,(hits X s q-1) at rank
  have connected : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have visit:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  by_cases no : L.card=0
  · rw [no] at mass pay
    rcases (show Q.card=43 ∨ Q.card=44 ∨ Q.card=45 ∨ Q.card=46 by omega) with v|v|v|v
    · have cap:=route r wd (k:=596) (c:=504) (by decide) (by omega); omega
    · have cap:=route r wd (k:=590) (c:=499) (by decide) (by omega); omega
    · have cap:=route r wd (k:=584) (c:=494) (by decide) (by omega); omega
    · have cap:=route r wd (k:=578) (c:=489) (by decide) (by omega); omega
  · have one : L.card=1 := by omega
    rw [one] at mass pay budget
    rcases (show Q.card=43 ∨ Q.card=44 by omega) with v|v
    · have cap:=route r wd (k:=567) (c:=480) (by decide) (by omega); omega
    · have cap:=route r wd (k:=561) (c:=475) (by decide) (by omega); omega

theorem decision1154 :
    (∃w : Block, Covers w ∧ w.length≤5900) ↔ BudgetCoreCurve.atLength 1154 42 :=
  BudgetCoreCurve.threshold 854 42 (by decide) (fun h bd => outside42 h bd)

#print axioms outside42
#print axioms decision1154
end ExactWordFlow.Window597

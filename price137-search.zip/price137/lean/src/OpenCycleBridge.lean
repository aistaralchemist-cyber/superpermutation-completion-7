import OpenCycle

namespace ExactWordFlow.OpenCycleBridge
open SevenWordWindows SuperpermutationBounds ResidualDensity DirectedEuler ResidualRoutes

/-- Every residual edge out of the source in a shortest spelling is a bridge
after the mandatory permutation cycles have also been included. -/
theorem source_bridge {X : Multiset Block} {s t e : Block} (h : Feasible X s t)
    (minimal : ∀v : Block, Covers v → 5046+X.card≤v.length)
    (present : e∈X) (atS : src e=s) :
    label (required+X.erase e) (src e) ≠ label (required+X.erase e) (dst e) := by
  classical
  intro detour
  let A := X.erase e
  have split : X=e ::ₘ A := (Multiset.cons_erase present).symm
  have width (g) (hg:g∈A) := h.edges_seven g (Multiset.mem_of_le (Multiset.erase_le _ _) hg)
  have bal : A.map src+{t}=A.map dst+{dst e} := by
    have orig := h.balance
    rw [split] at orig
    ext g
    have atg := congrArg (Multiset.count g) orig
    simp only [Multiset.map_cons,Multiset.count_add,Multiset.count_cons,Multiset.count_singleton,atS] at atg ⊢
    omega
  let G:=required+A
  have all (g) (hg:g∈required+X) : label G (src g)=label G (dst g) := by
    rcases Multiset.mem_add.mp hg with must|extra
    · exact on_edge (Multiset.mem_add.mpr (Or.inl must))
    · rw [split] at extra
      rcases Multiset.mem_cons.mp extra with rfl|keep
      · exact detour
      · exact on_edge (Multiset.mem_add.mpr (Or.inr keep))
  let S : Set Block := {p | label G p=label G s}
  have rooted := h.reachable S rfl (fun g hg hv=>(all g hg).symm.trans hv)
  have together : RequiredComponent.RequiredTogether A := fun p hp q hq =>
    (rooted p (Multiset.mem_add.mpr (Or.inl hp))).trans
      (rooted q (Multiset.mem_add.mpr (Or.inl hq))).symm
  obtain ⟨Y,sub,a,b,flow⟩ := RequiredComponent.feasible_submultiset width bal together
  obtain ⟨w,cover,len⟩ := (word_iff_flow (Y.card+5046) (by omega)).mpr ⟨Y,a,b,by omega,flow⟩
  have low := minimal w cover
  have upper := Multiset.card_le_card sub
  rw [split,Multiset.card_cons] at low
  omega

/-- A visit back to s on a residual Euler trail would give a second path
between the endpoints of its first edge. -/
theorem source_degrees {X : Multiset Block} {s t : Block} (h : Feasible X s t) (openEnds:s≠t)
    (minimal : ∀v : Block, Covers v → 5046+X.card≤v.length) :
    (X.map dst).count s=0 ∧ (X.map src).count s=1 := by
  classical
  have absent : s ∉ X.map dst := by
    intro hit
    obtain ⟨f,hf,dest⟩ := Multiset.mem_map.mp hit
    obtain ⟨a,b,es,eb,r,_,ends⟩ := component_route h.balance s
    obtain ⟨a0,b0⟩ := ends.1 rfl
    subst a; subst b
    cases r with
    | nil => exact openEnds rfl
    | @cons s t es e atS tail =>
      have inPart : f∈part X (label X s) := in_part.mpr ⟨hf, (on_edge hf).trans (congrArg (label X) dest)⟩
      have inTrail : f∈e::es := by change f∈(↑(e::es) : Multiset Block); rw [eb]; exact inPart
      have firstPart : e∈part X (label X s) := eb ▸ (show e∈(↑(e::es) : Multiset Block) by simp)
      have firstX := (in_part.mp firstPart).1
      have bridge := source_bridge h minimal firstX atS
      rcases List.mem_cons.mp inTrail with rfl|inRest
      · exact bridge (congrArg _ (atS.trans dest.symm))
      have tailSub : (↑es : Multiset Block)≤X.erase e := by
        have sub : part X (label X s) ≤ X := Multiset.filter_le ..
        rw [←eb] at sub
        change e ::ₘ (↑es : Multiset Block) ≤ X at sub
        simpa only [Multiset.erase_cons_head] using Multiset.erase_le_erase e sub
      let G:=required+X.erase e
      have live (g) (hg:g∈es) : g∈G := Multiset.mem_add.mpr (Or.inr (Multiset.mem_of_le tailSub hg))
      have detour := Essential.walk_label tail live
        (v:=dst f) (List.mem_cons_of_mem _ (List.mem_map_of_mem inRest))
      exact bridge (by simpa only [G,dest,atS] using detour)
  have zero := Multiset.count_eq_zero.mpr absent
  have mass := congrArg (Multiset.count s) h.balance
  refine ⟨zero,?_⟩
  simpa [Multiset.count_add,Multiset.count_singleton,openEnds,Ne.symm openEnds,zero] using mass

#print axioms source_bridge
#print axioms source_degrees
end ExactWordFlow.OpenCycleBridge

import Mathlib.Data.List.Chain
import Mathlib.Tactic

namespace Seventeen

/-- Every trail has at least one row and joins consecutive rows at matching ports. -/
def Good (link : α → α → Prop) (F : List (List α)) : Prop :=
  ∀ T ∈ F, T ≠ [] ∧ T.IsChain link

private theorem cut_one {link : α → α → Prop} {F : List (List α)} (ok : Good link F)
    (room : F.length < F.flatten.length) :
    ∃ G, Good link G ∧ G.flatten = F.flatten ∧ G.length = F.length + 1 := by
  induction F with
  | nil => simp at room
  | cons t rest ih =>
    have head := ok t (by simp)
    have tail : Good link rest := fun u hu => ok u (by simp [hu])
    cases t with
    | nil => exact (head.1 rfl).elim
    | cons x xs =>
      cases xs with
      | nil =>
        have room' : rest.length < rest.flatten.length := by simpa using room
        obtain ⟨G,hG,flat,size⟩ := ih tail room'
        refine ⟨[x] :: G, ?_, by simp [flat], by simp [size]⟩
        intro T h
        rcases List.mem_cons.mp h with rfl | h
        · exact head
        · exact hG _ h
      | cons y ys =>
        refine ⟨[x] :: (y :: ys) :: rest, ?_, by simp, by simp⟩
        intro T h
        rcases List.mem_cons.mp h with rfl | h
        · exact ⟨by simp, List.isChain_singleton _⟩
        rcases List.mem_cons.mp h with rfl | h
        · exact ⟨by simp, (List.isChain_cons_cons.mp head.2).2⟩
        · exact tail _ h

/-- Cut e interior row joins. The ordered flattened row list, hence every row entry,
its multiplicity, holes and the entire complement, stays identical. -/
theorem cuts {link : α → α → Prop} {F : List (List α)} (ok : Good link F)
    (e : Nat) (room : F.length + e ≤ F.flatten.length) :
    ∃ G, Good link G ∧ G.flatten = F.flatten ∧ G.length = F.length + e := by
  induction e generalizing F with
  | zero => exact ⟨F, ok, rfl, by simp⟩
  | succ e ih =>
    obtain ⟨one,valid,flat,size⟩ := cut_one ok (by omega)
    have room' : one.length + e ≤ one.flatten.length := by rw [size,flat]; omega
    obtain ⟨G,hG,hflat,hsize⟩ := ih valid room'
    exact ⟨G,hG,hflat.trans flat,by omega⟩

theorem room_of_budget (r h m e : Nat) (value : 15+5*(m+e)+h≤r) : m+e≤r := by omega

theorem seventeen (e m : Nat) (positive : 1≤m) (ceiling : m+2*e≤17) :
    1≤m+e ∧ m+e≤17 := by omega

end Seventeen

#print axioms Seventeen.cuts

import KernelFromRows
import Ring69Sound
import FiveChainSearches
import LowerBounds.J16Final

namespace ExactWordFlow.Defect16Obstruction
open SevenWordWindows RotationCore SuperpermLowerBounds T5900

theorem chain_checked : PS.SeqCapLt 7 0 (PS.capF Ttab 0) 66 :=
  chain_prefix seed_checked ⟨400, 10, 8, by decide, PS.covered_one chain59⟩
    ⟨400, 12, 8, by decide, PS.covered_one chain62to65⟩

theorem checked_kernel_of_runs (kernels : K16.Evals) : K16.TheoremK16 :=
  kernel_from_rows seed_checked chain_checked (K16.kernel_of_search kernels)

/-- The input propositions concern individual sequences or tuples of pieces. -/
theorem exclude_from_kernel_and_joint (kernel : K16.Kernel16) (joint : K16.Joint16) :
    ¬ ∃ v : Block, v.length = 1196 ∧ (visited v).card = 720 ∧ (complete v).card = 48 :=
  exclude_from_parts (kernel_from_rows seed_checked chain_checked kernel) middle_checked joint

/-- Source-level evaluation alternative. The caller fills the joint record using
the verified RX equation and the eighteen kernel-independent joint-search fields. -/
theorem exclude_from_defect16_runs (kernels : K16.Evals) (joints : J16.EvRX → J16.Evals) :
    ¬ ∃ v : Block, v.length = 1196 ∧ (visited v).card = 720 ∧ (complete v).card = 48 := by
  have hK := checked_kernel_of_runs kernels
  have joint := J16.joint_of_search_rx (table_of_kernel hK) hK Core1224.rx_unconditional
    (joints Core1224.rx_field)
  exact exclude_from_parts hK middle_checked joint

#print axioms chain_checked
#print axioms exclude_from_kernel_and_joint
#print axioms exclude_from_defect16_runs
end ExactWordFlow.Defect16Obstruction

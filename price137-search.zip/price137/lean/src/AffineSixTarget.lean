import CompletionExchange
import SixFlow
import SixFrequency
import SixGeometry
import DirectFrontier
import Exact48Target

namespace ExactWordFlow.AffineSixTarget
open SevenWordWindows RotationCore SuperpermutationBounds

/-- A candidate for the specified six arithmetic-progression cycles on Fin 7. -/
def Candidate (w : Block) : Prop :=
  w.length = 1196 ∧ (visited w).card = 720 ∧ (complete w).card = 48 ∧ SixGeometry.six ⊆ complete w

theorem exists_iff :
    (∃ w, Candidate w) ↔
    ∃ w : Block, w.length = 1196 ∧ (visited w).card = 720 ∧ (complete w).card = 48 := by
  constructor
  · rintro ⟨w, size, visits, done, _⟩
    exact ⟨w, size, visits, done⟩
  · rintro ⟨w, size, visits, done⟩
    obtain ⟨z, _, sz, vz, cz, six, _⟩ :=
      CompletionExchange.prescribe_six w size visits done SixGeometry.six
        SixGeometry.legal SixGeometry.six_card.le
    exact ⟨z, sz, vz, cz, six⟩

theorem lower_iff_excluded : Almanac.LowerBoundAt 7 5901 ↔ ¬ ∃ w, Candidate w :=
  Exact48Target.exclusion_iff_lower.symm.trans exists_iff.not.symm

def OpenCandidate (w : Block) : Prop :=
  Candidate w ∧ w.take 6 ≠ w.drop (w.length-6) ∧ ∀ a : Fin 7, 49 ≤ w.count a

theorem lower_iff_open_excluded : Almanac.LowerBoundAt 7 5901 ↔ ¬ ∃ w, OpenCandidate w := by
  rw [lower_iff_excluded]
  constructor
  · rintro h ⟨w, candidate, _⟩
    exact h ⟨w, candidate⟩
  · rintro h ⟨w, size, visits, done, six⟩
    exact h ⟨w, ⟨size, visits, done, six⟩, SixFlow.candidate_distinct_ends size visits done,
      fun a => SixFrequency.every_letter size visits done a⟩

/-- The two inputs are independent geometric assertions from Halfar's case proof. -/
theorem excluded_of_local_searches
    (kernel : SuperpermLowerBounds.K16.Kernel16)
    (joint : SuperpermLowerBounds.K16.Joint16) : ¬ ∃ w, Candidate w :=
  by
    rintro ⟨w, size, visits, done, _⟩
    exact Defect16Obstruction.exclude_from_kernel_and_joint kernel joint ⟨w, size, visits, done⟩

theorem lower_from_local_searches
    (kernel : SuperpermLowerBounds.K16.Kernel16)
    (joint : SuperpermLowerBounds.K16.Joint16) : Almanac.LowerBoundAt 7 5901 :=
  lower_iff_excluded.mpr (excluded_of_local_searches kernel joint)

#print axioms exists_iff
#print axioms excluded_of_local_searches
end ExactWordFlow.AffineSixTarget

import GlobalClosedPrice
import BudgetCoreCurve
import ShortMarked

namespace ResidualDensity.MarkEnvelope854
open MarkedGeometry WeightedMarks DirectedEuler ExactWordFlow
open private prefixes initial start move memoryWord accepted steps from MarkedDensity

/-- Extend the exact forbidden-mask recurrence to every possible open route at budget 854. -/
private def levels : Array (Array Nat) :=
  (List.range 855).foldl (fun a _ =>
    let prev := a.back!
    a.push (steps.map fun (l,r) =>
      max (prev[l]?.getD 0) (if r<prefixes.size then 1+prev[r]?.getD 0 else 0)))
    #[Array.replicate prefixes.size 0]

def upper (n s : Nat) := ((levels[n]?.getD #[])[s]?).getD 0

private theorem upper_step :
    ∀n : Fin 855, ∀s : Fin prefixes.size, ∀b : Bool,
      move s.val b<prefixes.size →
        b.toNat+upper n.val (move s.val b)≤upper (n.val+1) s.val := by native_decide

private theorem upper_read (pre rest : List Bool) (s : Nat) (ok : s<prefixes.size)
    (small : rest.length≤855) (suffix : memoryWord s <:+ pre)
    (safeWord : ∀x∈forbidden, ¬x <:+: pre++rest) :
    rest.count true ≤ upper rest.length s := by
  induction rest generalizing s pre with
  | nil => simp
  | cons b bs ih =>
    have sz : bs.length<855 := by simpa using small
    obtain ⟨inside,suff,_⟩:=accepted s b pre bs ok suffix safeWord
    have child:=ih (pre++[b]) _ inside (by omega) suff (by simpa using safeWord)
    have cost:=upper_step ⟨bs.length,sz⟩ ⟨s,ok⟩ b inside
    change b.toNat + upper bs.length (move s b)≤ upper (bs.length+1) s at cost
    cases b <;> simp only [List.count_cons_self,List.count_cons_of_ne (by decide : false≠true),
      List.length_cons,Bool.toNat_false,Bool.toNat_true] at * <;> omega

theorem interval_upper {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i n : ℕ) (sm : n≤855) : count p i n≤upper n initial := by
  have b:=upper_read [] (mask p i n) initial start.1 (by simpa [mask] using sm)
    (by simp [start.2.1]) (by simpa using safe w m i n)
  rw [mark_count] at b
  simpa [mask] using b

theorem route_upper {s t : Six} {es : List Six} (r : Route src dst s es t)
    (width : ∀e∈es,e.length=7) (small : es.length+1≤855) :
    classCount s es≤upper (es.length+1) initial := by
  obtain ⟨u,I,w,m,h⟩:=open_observations r width
  rw [←h]
  exact interval_upper w m 0 (es.length+1) small

end ResidualDensity.MarkEnvelope854

import FortyEight854

namespace ExactWordFlow.Window567
open SevenWordWindows ResidualDensity DirectedEuler WeightedMarks MarkedGeometry MarkEnvelope854
open private initial start accepted move memoryWord prefixes from MarkedDensity
open private upper_read upper_step from MarkEnvelope854
open private unmask mask_cons from StrongerDensity
open private canonical normalize from Interval66
open private search_complete from Geometry40
open private runs from MarkedExtrema

open private optimal maximizer obstructions no_profile from Window561
open private submask from MarkedGeometry
open private count_add from DensityBudget

/-- Additional forbidden one-gap profiles needed at 566 edges. -/
private def extra : List (List Nat) := [
  [4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 5, 3],
  [3, 5, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4],
  [2, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 2, 6, 6, 5],
  [5, 6, 6, 2, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 2],
  [3, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 2, 6, 6, 4],
  [4, 6, 6, 2, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 3],
  [4, 6, 4, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6],
  [6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 4, 6, 4],
  [6, 6, 4, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 2],
  [2, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 4, 6, 6],
  [3, 6, 6, 4, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 3],
  [3, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 4, 6, 6, 3],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 1],
  [1, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 5],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 4, 6, 6, 4, 4],
  [4, 4, 6, 6, 4, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 5],
  [2, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 5],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 2]
]

private theorem rejected : extra.all (fun ns =>
    !ns.isEmpty && ns.all (fun n=>decide (0<n)) &&
    canonical.all (fun s => !rowSearch ns s []))=true := by native_decide

private theorem no_extra {u : ℕ→Six} {p : ℕ→Prop} (w : Walk u) (h : Marked u p)
    (ns : List Nat) (hn : ns∈extra) (i : ℕ) (marks : rowsMarked p i ns) : False := by
  have ⟨⟨nonempty,positive⟩,bad⟩ := Bool.and_eq_true_iff.mp (List.all_eq_true.mp rejected ns hn)
    |>.imp_left Bool.and_eq_true_iff.mp
  have pos (n) (hm : n∈ns) := of_decide_eq_true (List.all_eq_true.mp positive n hm)
  have first : p i := by
    cases ns with
    | nil => simp at nonempty
    | cons n rest => simpa using marks.1 0 (pos n List.mem_cons_self)
  obtain ⟨v,vw,vm,initial⟩:=normalize w h i first
  have yes:=search_complete vw vm ns pos i marks [] (by simp)
  have no:=List.all_eq_true.mp bad _ initial
  simp [yes] at no


private def table : List (Nat × Nat) := [(566,479)]

private def checked (x : Nat × Nat) : Bool :=
  x.1+1≤855 && upper (x.1+1) initial==x.2+1 && (optimal (x.1+1) initial).all
    (fun bs => (obstructions ++ extra).any (fun ns => decide (rowsMask ns <:+: bs)))

set_option maxHeartbeats 0 in
set_option maxRecDepth 8192 in
private theorem data : table.all checked=true := by native_decide

theorem marks (u : Nat→Six) (p : Nat→Prop) [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i : Nat) {k c : Nat} (mem : (k,c)∈table) :
    count p i (k+1)≤c := by
  by_contra! many
  have checkedRow:=List.all_eq_true.mp data _ mem
  unfold checked at checkedRow
  simp only [Bool.and_eq_true,beq_iff_eq,decide_eq_true_eq] at checkedRow
  obtain ⟨⟨size,cap⟩,rest⟩:=checkedRow
  let bs:=mask p i (k+1)
  have len : bs.length=k+1:=by simp [bs,mask]
  have hi : upper bs.length initial≤bs.count true := by rw [len,cap,mark_count]; omega
  have hit:=maximizer [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i (k+1)) hi
  rw [len] at hit
  have test:=List.all_eq_true.mp rest _ hit
  obtain ⟨ns,hn,found⟩:=List.any_eq_true.mp test
  obtain ⟨l,r,hpat⟩ := of_decide_eq_true found
  have sub:=submask i (k+1) l (rowsMask ns) r hpat
  rcases List.mem_append.mp hn with h | h
  · exact no_profile w m ns h _ (unmask _ _ ns sub)
  · exact no_extra w m ns h _ (unmask _ _ ns sub)

theorem route {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀e∈es,e.length=7) {k c : Nat} (bounds : (k,c)∈table) (len : es.length≤k) :
    classCount s es≤c := by
  obtain ⟨u,I,walk,mark,eq⟩:=open_observations r wd
  have h:=marks u (·∈I) walk mark 0 bounds
  have add:=count_add (·∈I) 0 (es.length+1) (k-es.length)
  rw [show es.length+1+(k-es.length)=k+1 by omega] at add
  omega

theorem root566 {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀ e∈es,e.length=7) (len : es.length≤566) : classCount s es≤479 :=
  route r wd (k:=566) (by decide) len

open SevenWordWindows DirectedEuler ResidualDensity ResidualRoutes RotationComponentCount
open ResidualIncidence SuperpermutationBounds
open private hits Cost totals rank_partition from NearHundredShape
open private lump from GlobalClosedPrice
open private initial from MarkedDensity

/-- At most forty-seven components away from the start can occur with 854 residual edges. -/
theorem outside47 {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤854) :
    (occupied X s).card≤47 := by
  classical
  by_contra! hn
  let Q:=occupied X s
  let home:=label X s
  have budget:=GlobalClosedPrice.budget h
  simp only [GlobalClosedPrice.fee,Finset.sum_add_distrib,lump,Finset.sum_const,smul_eq_mul] at budget
  have high : 48≤Q.card := hn
  have low : Q.card≤48 := FortyEight854.outside48 h bd
  have noLong : (Q.filter (fun q=>6<(part X q).card)).card=0 := by dsimp [Q]; omega
  have each (q) (hq:q∈Q) : Cost X q≤6 := by
    by_contra! big
    have pos:=Finset.card_pos.mpr (show (Q.filter (fun q=>6<(part X q).card)).Nonempty from
      ⟨q,Finset.mem_filter.mpr ⟨hq,big⟩⟩)
    omega
  have zero : (∑q∈Q,(Cost X q-6))=0 := Finset.sum_eq_zero (fun q hq=>Nat.sub_eq_zero_of_le (each q hq))
  obtain ⟨mass,pay⟩:=totals h
  change Cost X home+6*Q.card+(∑q∈Q,(Cost X q-6))=X.card at mass
  change 7*(∑q∈Q,(hits X s q-1))+(if 0<(∑q∈Q,(Cost X q-6)) then 6 else 0)≤
    35*Q.card+6*(∑q∈Q,(Cost X q-6)) at pay
  rw [zero] at mass pay
  have rank:=rank_partition h
  change separateRank X s=hits X s home-1+∑q∈Q,(hits X s q-1) at rank
  have connected : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have visit:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  have cap:=root566 r wd (by omega)
  omega

/-- The 854-edge budget has a smaller exact partial-word decision problem. -/
theorem decision1189 :
    (∃w : Block, Covers w ∧ w.length≤5900) ↔ BudgetCoreCurve.atLength 1189 47 :=
  BudgetCoreCurve.threshold 854 47 (by decide) (fun h bd => outside47 h bd)

#print axioms outside47
#print axioms decision1189
end ExactWordFlow.Window567

import MarkEnvelope854

namespace ExactWordFlow.Ring854
open ResidualDensity MarkedGeometry MarkEnvelope854 DirectedEuler
open private initial start accepted move memoryWord prefixes from MarkedDensity
open private upper_read from MarkEnvelope854
open private mask_cons from StrongerDensity

private def high : Nat → Nat → Nat → List (List Bool)
  | 0,_,k => if k=0 then [[]] else []
  | n+1,s,k =>
    [false,true].flatMap fun b =>
      let j:=move s b
      if j<prefixes.size ∧ k≤b.toNat+upper n j then
        (high n j (k-b.toNat)).map (b::·)
      else []

private theorem recognizes (pre bs : List Bool) (s k : Nat) (valid : s<prefixes.size)
    (small : bs.length≤855) (suff : memoryWord s <:+ pre)
    (safeWord : ∀x∈forbidden, ¬x <:+: pre++bs) (many : k≤bs.count true) :
    bs∈high bs.length s k := by
  induction bs generalizing s pre k with
  | nil => simp at many; simp [high,many]
  | cons b bs ih =>
    obtain ⟨next,suffix,_⟩:=accepted s b pre bs valid suff safeWord
    have sm : bs.length≤855:=by simpa using Nat.le_of_succ_le small
    have good : ∀x∈forbidden, ¬x <:+: (pre++[b])++bs := by simpa using safeWord
    have tail := upper_read _ _ _ next sm suffix good
    have cnt : (b::bs).count true=b.toNat+bs.count true := by cases b <;> simp [Nat.add_comm]
    rw [cnt] at many
    have child:=ih _ _ (k-b.toNat) next sm suffix good (by omega)
    apply List.mem_flatMap.mpr
    refine ⟨b,by cases b <;> simp,?_⟩
    dsimp only
    rw [ite_eq_left ⟨next,by omega⟩]
    exact List.mem_map.mpr ⟨bs,child,rfl⟩

def sizes : List (Nat × Nat) := [(27,23),(34,29),(40,34),(53,45),(60,51)]
private def blocks (k : Nat) (v : List Bool) : Bool :=
  forbidden.any (fun f=> decide (f.length≤k ∧ f <:+: v++v))
private def checked (q : Nat × Nat) :=
  decide (q.1≤855) && (high q.1 initial q.2).all (blocks q.1)

set_option maxHeartbeats 0 in
set_option maxRecDepth 4096 in
private theorem table : sizes.all checked=true := by native_decide

private theorem double {p : ℕ→Prop} [DecidablePred p] {k : Nat} (per : ∀i,p (i+k) ↔ p i) :
    mask p 0 k ++ mask p 0 k=mask p 0 (k+k) := by
  simp only [mask,List.range_add,List.map_append,List.map_map,Nat.zero_add]
  congr 1
  apply List.map_congr_left
  intro i _
  simp [Function.comp_apply,Nat.add_comm k i,per]

theorem cyclic {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] {k c : Nat} (w : Walk u)
    (cy : CyclicMarked u p k) (key : (k,c)∈sizes) : count p 0 k<c := by
  by_contra! many
  let bs:=mask p 0 k
  have len : bs.length=k:=by simp [bs,mask]
  have tab:=List.all_eq_true.mp table _ key
  change decide (k≤855) && (high k initial c).all (blocks k)=true at tab
  obtain ⟨small,block⟩:=Bool.and_eq_true_iff.mp tab
  have safeWord (v) (hv:v∈forbidden) : ¬v <:+: []++bs := by
    intro infx
    have le:v.length≤k := by obtain ⟨a,b,eq⟩:=infx; have h:=congrArg List.length eq; simp at h; omega
    exact (SynchronizedCycles.safe_all_laps w cy 0 k v hv le) (by simpa [bs] using infx)
  have sat : c≤bs.count true := by change c≤(mask p 0 k).count true; rw [mark_count]; omega
  have yes:=recognizes [] bs initial c start.1 (len ▸ of_decide_eq_true small)
    (by simp [start.2.1]) safeWord sat
  rw [len] at yes
  obtain ⟨v,hv,prohibited⟩:=List.any_eq_true.mp (List.all_eq_true.mp block _ yes)
  obtain ⟨fit,inside⟩:=of_decide_eq_true prohibited
  have infx:v <:+: mask p 0 (k+k):=by simpa [bs,double cy.periodic] using inside
  exact SynchronizedCycles.safe_all_laps w cy 0 _ v hv fit infx

theorem route {s : Block} {es : List Block} (r : Route src dst s es s)
    (wd : ∀e∈es,e.length=7) {k c : Nat} (size:es.length=k) (hm : (k,c)∈sizes) :
    classCount s es<c := by
  subst k
  have lo : 0<es.length:=by simp [sizes] at hm; rcases hm with h|h|h|h|h <;> rcases h with ⟨h,_⟩ <;> omega
  obtain ⟨u,I,w,cy,m⟩:=closed_observations r wd lo
  rw [←m]
  exact cyclic w cy hm

#print axioms route
end ExactWordFlow.Ring854

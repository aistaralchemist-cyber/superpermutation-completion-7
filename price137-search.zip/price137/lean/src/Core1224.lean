import Decision5900
import AlmanacDefs
import LowerBounds.PFinalK16Native

/-!
# The 1,224-letter decision and the Almanac template

The equivalence and the necessary conditions below use the same seven-letter
words and completed rotation classes as the original reduction. The accepted
5,899 lower bound is used only in the quantitative necessary conditions.
-/

namespace ExactWordFlow.Core1224

open SevenWordWindows SuperpermutationBounds RotationCore

/-- The two definitions list the same permutation factors. -/
theorem covers_iff_almanac (w : Block) :
    Covers w ↔ Almanac.IsSuperpermutation 7 w := by
  constructor
  · intro hw p nd len
    obtain ⟨s, t, eq⟩ := hw p len nd
    exact ⟨s, t, eq.symm⟩
  · intro hw p len nd
    obtain ⟨s, t, eq⟩ : ∃ s t, s ++ p ++ t = w := hw p nd len
    exact ⟨s, t, eq.symm⟩

theorem almanac_iff_core :
    Almanac.LowerBoundAt 7 5901 ↔ ¬ BudgetCoreCurve.atLength 1224 52 := by
  constructor
  · intro bound core
    obtain ⟨w, hw, cap⟩ := Audit5900.decision5900.mpr core
    have floor := bound w ((covers_iff_almanac w).mp hw)
    omega
  · intro exclude w cover
    by_contra! short
    exact exclude (Audit5900.decision5900.mp ⟨w, (covers_iff_almanac w).mpr cover, by omega⟩)

/-- Interface to Halfar's word-length conclusion. Instantiating this with
his conditional theorem retains the hypotheses of that theorem. -/
theorem core_excluded_of_word_bound
    (bound : ∀ w : Block, Covers w → 5901 ≤ w.length) :
    ¬ BudgetCoreCurve.atLength 1224 52 :=
  almanac_iff_core.mp (fun w h => bound w ((covers_iff_almanac w).mpr h))

/-- Adding seven letters per unfinished class gives a necessary inequality even
for a core that did not come from the spanning construction. -/
theorem expansion_floor (v : Block) (long : 6 ≤ v.length)
    (vis : (visited v).card = 720) :
    5899 ≤ v.length + 7 * (720 - (complete v).card) := by
  obtain ⟨w, hw, len⟩ := expand_remaining long vis
  rw [←len]
  exact SuperpermLowerBounds.covers_lower_bound_7_k16_native w hw

theorem exact_candidate (v : Block) (len : v.length = 1224)
    (vis : (visited v).card = 720) (enough : 52 ≤ (complete v).card) :
    (complete v).card = 52 ∧ ∃ w : Block, Covers w ∧ w.length = 5900 := by
  have long : 6 ≤ v.length := by omega
  have floor := expansion_floor v long vis
  have eq : (complete v).card = 52 := by omega
  obtain ⟨w, hw, sz⟩ := expand_remaining long vis
  exact ⟨eq, w, hw, by omega⟩

/-- The three lengths closest to the threshold. Length 1,223 would expand
to a word of length exactly 5,899 if it attained 52 completions. -/
theorem minimum_length_for_52 (v : Block) (long : 6 ≤ v.length)
    (vis : (visited v).card = 720) (enough : 52 ≤ (complete v).card) :
    1223 ≤ v.length := by
  have floor := expansion_floor v long vis
  omega

/-- Every deletion of two symbols from a putative candidate must destroy
at least one visit or leave at most 51 completed classes. The proof works for
every word of the resulting length, regardless of how the symbols were deleted. -/
theorem two_letter_loss (v : Block) (len : v.length = 1222) :
    (visited v).card ≠ 720 ∨ (complete v).card ≤ 51 := by
  by_cases visit : (visited v).card = 720
  · right
    have floor := expansion_floor v (by omega) visit
    omega
  · exact Or.inl visit

#print axioms almanac_iff_core
#print axioms core_excluded_of_word_bound
#print axioms expansion_floor
#print axioms exact_candidate
#print axioms minimum_length_for_52
#print axioms two_letter_loss

end ExactWordFlow.Core1224

import MarkEnvelope854

namespace ExactWordFlow.ComponentCap854
open SevenWordWindows DirectedEuler ResidualDensity ResidualRoutes RotationComponentCount
open ResidualIncidence SuperpermutationBounds
open private hits Cost totals rank_partition from NearHundredShape
open private lump from GlobalClosedPrice
open private initial from MarkedDensity

private theorem numeric : ∀ j : Fin 550, ∀ n : Fin 53, 51≤n.val →
    j.val+6*n.val≤854 → MarkEnvelope854.upper (j.val+1) initial+5*n.val<720 := by
  native_decide

/-- At most fifty components away from the start can occur with 854 residual edges. -/
theorem outside50 {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤854) :
    (occupied X s).card≤50 := by
  classical
  by_contra! hn
  let Q:=occupied X s
  let home:=label X s
  have budget:=GlobalClosedPrice.budget h
  simp only [GlobalClosedPrice.fee,Finset.sum_add_distrib,lump,Finset.sum_const,smul_eq_mul] at budget
  have high : 51≤Q.card := hn
  have low : Q.card≤52 := by dsimp [Q]; omega
  have noLong : (Q.filter (fun q=>6<(part X q).card)).card=0 := by dsimp [Q]; omega
  have each (q) (hq:q∈Q) : Cost X q≤6 := by
    by_contra! big
    have pos:=Finset.card_pos.mpr (show (Q.filter (fun q=>6<(part X q).card)).Nonempty from
      ⟨q,Finset.mem_filter.mpr ⟨hq,big⟩⟩)
    omega
  have zero : (∑q∈Q,(Cost X q-6))=0 := Finset.sum_eq_zero (fun q hq=>Nat.sub_eq_zero_of_le (each q hq))
  obtain ⟨mass,pay⟩:=totals h
  change Cost X home+6*Q.card+(∑q∈Q,(Cost X q-6))=X.card at mass
  change 7*(∑q∈Q,(hits X s q-1))+(if 0<(∑q∈Q,(Cost X q-6)) then 6 else 0)≤
    35*Q.card+6*(∑q∈Q,(Cost X q-6)) at pay
  rw [zero] at mass pay
  have rank:=rank_partition h
  change separateRank X s=hits X s home-1+∑q∈Q,(hits X s q-1) at rank
  have connected : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have visit:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  have route:=MarkEnvelope854.route_upper r wd (by omega)
  have table:=numeric ⟨es.length,by omega⟩ ⟨Q.card,by omega⟩ high (by change es.length+6*Q.card≤854; omega)
  change MarkEnvelope854.upper (es.length+1) initial+5*Q.card<720 at table
  omega

/-- The 854-edge budget has a smaller exact partial-word decision problem. -/
theorem decision1210 :
    (∃w : Block, Covers w ∧ w.length≤5900) ↔ BudgetCoreCurve.atLength 1210 50 :=
  BudgetCoreCurve.threshold 854 50 (by decide) (fun h bd => outside50 h bd)

#print axioms outside50
#print axioms decision1210
end ExactWordFlow.ComponentCap854

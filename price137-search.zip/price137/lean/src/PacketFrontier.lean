import Std

namespace SevenOmission

/-- Sum the deficits of nonempty wheel packets of widths at most five. -/
def deficit (xs : List Nat) := (xs.map (5-·)).sum

theorem identity (xs : List Nat) (ok : ∀ t ∈ xs, t ≤ 5) :
    xs.sum + deficit xs = 5*xs.length := by
  induction xs with
  | nil => rfl
  | cons t xs ih =>
    have lim := ok t List.mem_cons_self
    have tail := ih (fun v h => ok v (List.mem_cons_of_mem t h))
    simp [deficit] at tail ⊢
    omega

theorem zero_iff (xs : List Nat) (ok : ∀ t ∈ xs, t ≤ 5) :
    deficit xs=0 ↔ ∀ t ∈ xs, t=5 := by
  induction xs with
  | nil => simp [deficit]
  | cons t xs ih =>
    have lim := ok t List.mem_cons_self
    have tail := ih (fun v h => ok v (List.mem_cons_of_mem t h))
    constructor
    · intro h a ha
      change 5-t+deficit xs=0 at h
      rcases List.mem_cons.mp ha with rfl|ha
      · omega
      · exact tail.mp (by omega) a ha
    · intro h
      change 5-t+deficit xs=0
      have ht := h t List.mem_cons_self
      have hz := tail.mpr (fun a ha => h a (List.mem_cons_of_mem t ha))
      omega

/-- At effective excess three and four trails the finite trail estimates
force 65 or 66 holes. The basic class count then forces exactly 65 value,
zero packet deficit, and zero or one five-cell packet in the complement. -/
theorem last_effective_excess (H V : Nat) (packets : List Nat)
    (low : 65 ≤ H) (high : H ≤ 66) (value : 65 ≤ V)
    (cover : 6*V+5*H+packets.sum=720)
    (widths : ∀ t ∈ packets, t≤5) (loss : deficit packets + 65 ≤ V) :
    V=65 ∧ (∀ t ∈ packets, t=5) ∧
      ((H=65 ∧ packets.length=1) ∨ (H=66 ∧ packets.length=0)) := by
  have eq := identity packets widths
  have hV : V=65 := by omega
  have sat := (zero_iff packets widths).mp (by omega)
  exact ⟨hV,sat,by omega⟩

/-- At effective excess zero and twelve trails these are precisely the
complement types accepted by the existing twelve-trail replay. -/
theorem twelve_boundary (H V : Nat) (packets : List Nat)
    (low : 34 ≤ H) (high : H ≤ 36) (value : 90 ≤ V)
    (cover : 6*V+5*H+packets.sum=720)
    (widths : ∀ t ∈ packets, t≤5) (loss : deficit packets + 90 ≤ V) :
    (H=34 ∧ ((V=90 ∧ packets.length=2 ∧ ∀ t ∈ packets, t=5) ∨
             (V=91 ∧ packets=[4]))) ∨
    (H=35 ∧ V=90 ∧ packets.length=1 ∧ ∀ t ∈ packets, t=5) ∨
    (H=36 ∧ V=90 ∧ packets=[]) := by
  have eq := identity packets widths
  by_cases better : 90 < V
  · have hH : H=34 := by omega
    have hV : V=91 := by omega
    have hsum : packets.sum=4 := by omega
    have nonzero : packets.length≠0 := by intro bad; have := List.eq_nil_of_length_eq_zero bad; simp_all
    have eqs : H=34 ∧ V=91 ∧ packets.length=1 ∧ packets.sum=4 := ⟨hH,hV,by omega,hsum⟩
    have only : packets=[4] := by
      cases packets with
      | nil => simp at eqs
      | cons x xs =>
        have len : (x::xs).length=1 := eqs.2.2.1
        have noMore : xs=[] := List.eq_nil_of_length_eq_zero (by simpa using len)
        subst xs
        simp_all
    exact Or.inl ⟨eqs.1,Or.inr ⟨eqs.2.1,only⟩⟩
  · have sat := (zero_iff packets widths).mp (by omega)
    by_cases h : H=34
    · exact Or.inl ⟨h,Or.inl ⟨by omega,by omega,sat⟩⟩
    by_cases h2 : H=35
    · exact Or.inr (Or.inl ⟨h2,by omega,by omega,sat⟩)
    exact Or.inr (Or.inr ⟨by omega,by omega,List.eq_nil_of_length_eq_zero (by omega)⟩)

end SevenOmission
#print axioms SevenOmission.last_effective_excess
#print axioms SevenOmission.twelve_boundary

import ExactPrice137
import FiveRowDeletion

namespace ExactWordFlow.HistoricalTransfer
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain FiveRowDeletion

private noncomputable def pack (r : NRow 7) (h : r.len=5) : WheelPacket :=
  ⟨r.entries, by simp [NRow.entries_length,h], by simp [NRow.entries_length,h],
   ⟨r,by omega,fun _ h => h⟩⟩

private noncomputable def packets : List (NRow 7) → List WheelPacket
  | [] => []
  | r::rs => if h : r.len=5 then pack r h :: packets rs else packets rs

private theorem packets_data (rs : List (NRow 7)) :
    (packets rs).length=fives rs ∧
    (packets rs).flatMap WheelPacket.cells=rowsEntries (rs.filter (fun r => r.len==5)) := by
  induction rs with
  | nil => constructor <;> rfl
  | cons r rs ih =>
    rcases ih with ⟨n,c⟩
    by_cases h : r.len=5
    all_goals simp_all [packets,pack,fives,rowsEntries]

private def stripped (G : List (List (NRow 7))) :=
  (G.map trim).filter (fun t => !t.isEmpty)

private theorem strip_flat (G : List (List (NRow 7))) :
    (stripped G).flatten=trim G.flatten := by
  induction G with
  | nil => rfl
  | cons t rest ih =>
    have step : trim (t++rest.flatten)=trim t++trim rest.flatten := by simp [trim]
    change (List.filter _ (trim t::rest.map trim)).flatten=trim (t++rest.flatten)
    rw [step,←ih]
    by_cases h : trim t=[]
    · simp [h,stripped]
    · simp [h,stripped]

/-- Preserve exact price and the prescribed trail count when transferring every
five-cell row (a loop on its four-letter port) to its own wheel packet. -/
theorem exact_price_without_width_five {M : Nat} {G : List (List (NRow 7))} {p : List WheelPacket}
    (board : PriceRangeBoard M G p) (pos : 1≤M) (lim : M≤11)
    (price : G.flatten.length+M+p.length=137) :
    ∃ (F : List (List (NRow 7))) (ps : List WheelPacket),
      PriceRangeBoard M F ps ∧ F.flatten.length+M+ps.length=137 ∧
      ∀ r∈F.flatten, r.len≠5 := by
  let S := stripped G
  let link := fun a b : NRow 7 => SLink 7 3 a.lastEntry b.entry
  have flat : S.flatten=trim G.flatten := strip_flat G
  have good : Seventeen.Good link S := by
    intro t ht
    obtain ⟨mapped,nonempty⟩ := List.mem_filter.mp ht
    obtain ⟨u,hu,rfl⟩ := List.mem_map.mp mapped
    refine ⟨by simpa using nonempty, trim_chain (board.family.trails u hu).seams⟩
  have short : S.length≤M := by
    have f := List.length_filter_le (fun t : List (NRow 7) => !t.isEmpty) (G.map trim)
    simpa [S,stripped,board.trails] using f
  have ⟨n,h⟩ := trim_counts G.flatten
  have raw := board.row_count
  rw [price] at raw
  have room : M≤S.flatten.length := by rw [flat]; omega
  obtain ⟨F,whole,unchanged,len⟩ := Seventeen.cuts good (M-S.length) (by omega)
  have same : F.flatten=trim G.flatten := unchanged.trans flat
  have size : F.length=M := by omega
  have fam : TrailFam 7 F := by
    constructor
    · intro t ht
      obtain ⟨ne,seams⟩ := whole t ht
      refine ⟨ne,?_,seams⟩
      intro r hr
      have mem : r ∈ F.flatten := List.mem_flatten.mpr ⟨t,ht,hr⟩
      rw [same] at mem
      obtain ⟨u,hu,hu'⟩ := List.mem_flatten.mp (List.mem_filter.mp mem).1
      exact (board.family.trails u hu).len r hu'
    · rw [same]
      exact board.family.classes.sublist (rowsEntries_sublist List.filter_sublist)
  let ps := packets G.flatten++p
  have ⟨number,cells⟩ := packets_data G.flatten
  have newPrice : F.flatten.length+M+ps.length=137 := by
    rw [same]
    dsimp only [ps]
    rw [List.length_append,number]
    omega
  have perm : (rowsEntries F.flatten ++ ps.flatMap WheelPacket.cells).Perm
      (rowsEntries G.flatten ++ p.flatMap WheelPacket.cells) := by
    dsimp only [ps]
    rw [same,List.flatMap_append,cells,←List.append_assoc]
    exact (trim_class_partition G.flatten).append_right _
  have old := board.coverage
  refine ⟨F,ps,price_ranges_of_cover pos lim fam size ?_ (by omega) (by omega),newPrice,?_⟩
  · exact ⟨perm.length_eq.trans old.1, pairwise_of_perm old.2.1 perm,fun v => by
      obtain ⟨x,hx,hv⟩ := old.2.2 v
      exact ⟨x,perm.mem_iff.mpr hx,hv⟩⟩
  · intro r hr
    rw [same] at hr
    simpa using (List.mem_filter.mp hr).2

#print axioms exact_price_without_width_five
end ExactWordFlow.HistoricalTransfer

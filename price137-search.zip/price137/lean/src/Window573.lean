import Window567

namespace ExactWordFlow.Window573
open SevenWordWindows ResidualDensity DirectedEuler WeightedMarks MarkedGeometry MarkEnvelope854
open private initial start accepted move memoryWord prefixes from MarkedDensity
open private upper_read upper_step from MarkEnvelope854
open private unmask mask_cons from StrongerDensity
open private canonical normalize from Interval66
open private search_complete from Geometry40
open private runs from MarkedExtrema

open private optimal maximizer obstructions no_profile from Window561
open private submask from MarkedGeometry
open private count_add from DensityBudget

open private extra no_extra from Window567

/-- The other one-gap shapes needed at 572 edges. -/
private def further : List (List Nat) := [
  [4, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 4, 6],
  [6, 4, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 4],
  [1, 6, 6, 6, 1, 6, 6, 6, 6, 2],
  [2, 6, 6, 6, 6, 1, 6, 6, 6, 1],
  [3, 6, 4, 6, 6, 6, 6, 2, 5, 3],
  [3, 5, 2, 6, 6, 6, 6, 4, 6, 3],
  [3, 6, 6, 3, 6, 6, 6, 6, 3, 6, 4],
  [4, 6, 3, 6, 6, 6, 6, 3, 6, 6, 3],
  [6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 3, 6, 6, 6, 3, 6, 6, 6, 4],
  [4, 6, 6, 6, 3, 6, 6, 6, 3, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6],
  [2, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 2, 6, 6, 6, 4],
  [4, 6, 6, 6, 2, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 2],
  [3, 6, 6, 6, 4, 6, 6, 3, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 2],
  [2, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 3, 6, 6, 4, 6, 6, 6, 3],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 2, 6, 6, 6, 4, 6, 1],
  [1, 6, 4, 6, 6, 6, 2, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 5],
  [6, 6, 4, 6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 2],
  [2, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6, 4, 6, 6],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 3, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 1],
  [1, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 3, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 5],
  [6, 6, 4, 5, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 2],
  [2, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 5, 4, 6, 6],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 5, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 1],
  [1, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 5, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 5],
  [4, 6, 6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 2],
  [2, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6, 6, 4],
  [3, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 4, 6],
  [6, 4, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 3],
  [3, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 3, 5],
  [5, 3, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 3],
  [1, 6, 6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6],
  [6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6, 6, 1],
  [2, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 3, 6, 6, 6, 4, 6, 6, 4, 2],
  [2, 4, 6, 6, 4, 6, 6, 6, 3, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 2],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 3, 6, 6, 4, 6, 1],
  [1, 6, 4, 6, 6, 3, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 5],
  [2, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 5],
  [5, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 2]
]

private theorem rejected : further.all (fun ns =>
    !ns.isEmpty && ns.all (fun n=>decide (0<n)) &&
    canonical.all (fun s => !rowSearch ns s []))=true := by native_decide

private theorem no_further {u : ℕ→Six} {p : ℕ→Prop} (w : Walk u) (h : Marked u p)
    (ns : List Nat) (hn : ns∈further) (i : ℕ) (marks : rowsMarked p i ns) : False := by
  have ⟨⟨nonempty,positive⟩,bad⟩ := Bool.and_eq_true_iff.mp (List.all_eq_true.mp rejected ns hn)
    |>.imp_left Bool.and_eq_true_iff.mp
  have pos (n) (hm : n∈ns) := of_decide_eq_true (List.all_eq_true.mp positive n hm)
  have first : p i := by
    cases ns with
    | nil => simp at nonempty
    | cons n rest => simpa using marks.1 0 (pos n List.mem_cons_self)
  obtain ⟨v,vw,vm,initial⟩:=normalize w h i first
  have yes:=search_complete vw vm ns pos i marks [] (by simp)
  have no:=List.all_eq_true.mp bad _ initial
  simp [yes] at no



private def more := obstructions ++ extra ++ further
private def excluded := forbidden ++ more.map rowsMask

private theorem avoids {u : Nat → Six} {p : Nat → Prop} [DecidablePred p] (w : Walk u)
    (m : Marked u p) (i n : Nat) : ∀ x ∈ excluded, ¬ x <:+: mask p i n := by
  intro x mem
  rcases List.mem_append.mp mem with base | extraMem
  · exact safe w m i n x base
  · obtain ⟨ns,hn,rfl⟩ := List.mem_map.mp extraMem
    intro ⟨l,r,hx⟩
    have sub:=submask i n l (rowsMask ns) r hx
    have marks:=unmask _ _ ns sub
    rcases List.mem_append.mp hn with old | fresh
    · rcases List.mem_append.mp old with prior | next
      · exact no_profile w m ns prior _ marks
      · exact no_extra w m ns next _ marks
    · exact no_further w m ns fresh _ marks

/-- Retain a suffix which is a prefix of an excluded mask. The soundness check
below validates the suffix remembered on each accepted transition, as well as
the obstructing suffix on each rejected transition. -/
private def words : Array (List Bool) := Id.run do
  let mut seen : Std.HashSet (List Bool) := ∅
  let mut result : Array (List Bool) := #[]
  for w in excluded do
    for pre in w.inits do
      if !seen.contains pre then
        result := result.push pre
        seen := seen.insert pre
  return result

private def indices : Std.HashMap (List Bool) Nat :=
  ((List.range words.size).foldl (fun t i => t.insert (words[i]?.getD []) i) ∅ :
     Std.HashMap (List Bool) Nat)

private def badSet := Std.HashSet.ofList excluded

private def hasBadSuffix : List Bool → Bool
  | [] => false
  | b::bs => badSet.contains (b::bs) || hasBadSuffix bs

private def suffixState : List Bool → Nat
  | [] => indices.getD [] 0
  | b::bs => (indices[b::bs]?).getD (suffixState bs)

private def extend (s : List Bool) (b : Bool) : Nat :=
  let e := s++[b]
  if hasBadSuffix e then words.size else suffixState e

private def links := words.map fun s => (extend s false,extend s true)
private def advance (s : Nat) (b : Bool) : Nat :=
  let edge := links[s]?.getD (words.size,words.size)
  if b then edge.2 else edge.1

private def memory (s : Nat) := words[s]?.getD []

private def validMove (s : Nat) (b : Bool) :=
  let j := advance s b
  let ext := memory s++[b]
  if j<words.size then (memory j).isSuffixOf ext else excluded.any fun x=>x.isSuffixOf ext

set_option maxRecDepth 16384 in
private theorem sound : (0 < words.size ∧ memory 0=[]) ∧
    ∀s : Fin words.size, validMove s.val false=true ∧ validMove s.val true=true := by native_decide

private theorem accepts (s : Nat) (b : Bool) (pre bs : List Bool) (ok : s<words.size)
    (suffix : memory s <:+ pre) (keep : ∀x∈excluded, ¬x <:+: pre++b::bs) :
    advance s b<words.size ∧ memory (advance s b) <:+ pre++[b] := by
  have checked : validMove s b=true := by
    cases b
    · exact (sound.2 ⟨s,ok⟩).1
    · exact (sound.2 ⟨s,ok⟩).2
  have longer : memory s++[b] <:+ pre++[b] := by
    obtain ⟨left,eq⟩:=suffix
    exact ⟨left,by simp [←List.append_assoc,eq]⟩
  unfold validMove at checked
  by_cases inside : advance s b<words.size
  · rw [ite_eq_left inside] at checked
    exact ⟨inside,(List.isSuffixOf_iff_suffix.mp checked).trans longer⟩
  · rw [ite_eq_right inside] at checked
    obtain ⟨x,hx,bad⟩:=List.any_eq_true.mp checked
    have bad' := ((List.isSuffixOf_iff_suffix.mp bad).trans longer).isInfix
    exact False.elim (keep _ hx (by simpa using bad'.trans (List.prefix_append (pre++[b]) bs).isInfix))

private def scores : Nat → Array Nat
  | 0 => #[]
  | n+1 =>
    let v:=scores n
    links.map fun (l,r)=>max (v[l]?.getD 0) (if r<words.size then 1+v[r]?.getD 0 else 0)

private def score (n s : Nat) := (scores n)[s]?.getD 0

private theorem pay {s : Nat} (n : Nat) (b : Bool) (ok : s<words.size)
    (next : advance s b<words.size) :
    b.toNat + score n (advance s b) ≤ score (n+1) s := by
  have sz : s<links.size := by simpa [links] using ok
  generalize eq : links[s] = link
  obtain ⟨l,r⟩ := link
  have someLink : links[s]? = some (l,r) := by rw [getElem?_pos links s sz,eq]
  have bound : score (n+1) s =
      max (score n l) (if r<words.size then 1+score n r else 0) := by
    simp [score,scores,Array.getElem?_map,someLink]
  rw [bound]
  cases b <;> simp_all [advance,score]

private theorem read_score (pre rest : List Bool) (s : Nat) (ok : s<words.size)
    (suffix : memory s <:+ pre) (keep : ∀x∈excluded, ¬x <:+: pre++rest) :
    rest.count true ≤ score rest.length s := by
  induction rest generalizing s pre with
  | nil => simp
  | cons b bs ih =>
    obtain ⟨next,suff⟩:=accepts s b pre bs ok suffix keep
    have tail:=ih (pre++[b]) _ next suff (by simpa using keep)
    have cost:=pay bs.length b ok next
    cases b <;> simp only [List.count_cons_self,List.count_cons_of_ne (by decide : false≠true),
      List.length_cons,Bool.toNat_false,Bool.toNat_true] at * <;> omega

theorem interval {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i n : Nat) :
    count p i n ≤ score n 0 := by
  have h:=read_score [] (mask p i n) 0 sound.1.1 (by simp [sound.1.2])
    (by simpa using avoids w m i n)
  rw [mark_count] at h
  simpa [mask] using h

private theorem limit : score 573 0 = 484 := by native_decide

theorem root572 {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀e∈es,e.length=7) (len : es.length≤572) : classCount s es≤484 := by
  obtain ⟨u,I,w,m,h⟩:=open_observations r wd
  have cap:=interval w m 0 573
  rw [limit] at cap
  have add:=count_add (·∈I) 0 (es.length+1) (572-es.length)
  rw [show es.length+1+(572-es.length)=573 by omega] at add
  omega

open SevenWordWindows DirectedEuler ResidualDensity ResidualRoutes RotationComponentCount
open ResidualIncidence SuperpermutationBounds
open private hits Cost totals rank_partition from NearHundredShape
open private lump from GlobalClosedPrice
open private initial from MarkedDensity

/-- At most forty-six components away from the start can occur with 854 residual edges. -/
theorem outside46 {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤854) :
    (occupied X s).card≤46 := by
  classical
  by_contra! hn
  let Q:=occupied X s
  let home:=label X s
  have budget:=GlobalClosedPrice.budget h
  simp only [GlobalClosedPrice.fee,Finset.sum_add_distrib,lump,Finset.sum_const,smul_eq_mul] at budget
  have high : 47≤Q.card := hn
  have low : Q.card≤47 := Window567.outside47 h bd
  have noLong : (Q.filter (fun q=>6<(part X q).card)).card=0 := by dsimp [Q]; omega
  have each (q) (hq:q∈Q) : Cost X q≤6 := by
    by_contra! big
    have pos:=Finset.card_pos.mpr (show (Q.filter (fun q=>6<(part X q).card)).Nonempty from
      ⟨q,Finset.mem_filter.mpr ⟨hq,big⟩⟩)
    omega
  have zero : (∑q∈Q,(Cost X q-6))=0 := Finset.sum_eq_zero (fun q hq=>Nat.sub_eq_zero_of_le (each q hq))
  obtain ⟨mass,pay⟩:=totals h
  change Cost X home+6*Q.card+(∑q∈Q,(Cost X q-6))=X.card at mass
  change 7*(∑q∈Q,(hits X s q-1))+(if 0<(∑q∈Q,(Cost X q-6)) then 6 else 0)≤
    35*Q.card+6*(∑q∈Q,(Cost X q-6)) at pay
  rw [zero] at mass pay
  have rank:=rank_partition h
  change separateRank X s=hits X s home-1+∑q∈Q,(hits X s q-1) at rank
  have connected : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have visit:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  have cap:=root572 r wd (by omega)
  omega

/-- The 854-edge budget has a smaller exact partial-word decision problem. -/
theorem decision1182 :
    (∃w : Block, Covers w ∧ w.length≤5900) ↔ BudgetCoreCurve.atLength 1182 46 :=
  BudgetCoreCurve.threshold 854 46 (by decide) (fun h bd => outside46 h bd)

#print axioms outside46
#print axioms decision1182
end ExactWordFlow.Window573

import CompletionExchange
import SixProjection

namespace ExactWordFlow.SixFrequency
open SevenWordWindows RotationCore RotationReinsert CoreAssembly WheelBaseResidual
open private actual from CompletionExchange

def hits (g : Fin 7) (w : Block) := ((bag w).filter (fun e=>g∈e)).card

private theorem all_letters : ∀e∈representatives,∀g : Fin 7,g∈e := by native_decide

/-- The 336 mandatory windows and at least two supplementary windows all carry g. -/
theorem hit_floor {w : Block} (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) (g : Fin 7) : 338≤hits g w := by
  classical
  let M := mandatory (complete w)
  let X := bag w-M
  obtain ⟨flow,cost⟩:=actual size vis done
  have two:=SixProjection.twice_for_every_symbol flow (by omega) g
  change 2 ≤ (SixProjection.carrying X g).card at two
  have extra := Multiset.card_le_card (Multiset.filter_le_filter (fun e : Block=>g∈e)
    (Multiset.filter_le (fun e : Block=>¬e.Nodup) X))
  have two' : 2 ≤ (X.filter (fun e=>g∈e)).card := two.trans extra
  have split : X+M=bag w:=tsub_add_cancel_of_le (mandatory_in_bag w)
  have m : M.filter (fun e=>g∈e)=M := Multiset.filter_eq_self.mpr (fun e he =>
    all_letters e (Multiset.mem_filter.mp he).1 g)
  have n := (mandatory_data (complete w) ((complete_subset w).trans (visited_subset w))).1
  change M.card = 7*(complete w).card at n
  rw [done] at n
  unfold hits
  rw [←split,Multiset.filter_add,Multiset.card_add,m,n]
  omega

/-- Incidences missing at the left edge for the first six positions. -/
private def startLoss (g : Fin 7) (w : Block) :=
  (w.take 1).count g + (w.take 2).count g + (w.take 3).count g +
  (w.take 4).count g + (w.take 5).count g + (w.take 6).count g

private theorem at_cons (g a : Fin 7) (xs : Block) :
    hits g (a::xs) ≤ hits g xs + (if g∈a::xs.take 6 then 1 else 0) := by
  by_cases long : 6≤xs.length
  · by_cases h : g∈a::xs.take 6 <;> simp [hits,bag,windows,long,h]
  · simp [hits,bag,windows,long]

theorem incidence_cap (g : Fin 7) (w : Block) :
    hits g w + startLoss g w ≤ 7*w.count g := by
  induction w with
  | nil => simp [hits,bag,windows,startLoss]
  | cons a xs ih =>
    have bound:=at_cons g a xs
    have missing : (if g∈a::xs.take 6 then 1 else 0) ≤ (a::xs.take 6).count g := by
      by_cases present : g∈a::xs.take 6
      · simp [present]
      · simp [present]
    by_cases eq : a=g
    · subst a
      simp [startLoss,List.take] at ih missing bound ⊢
      omega
    · simp [startLoss,List.take,eq,Ne.symm eq] at ih missing bound ⊢
      omega

private theorem end_step (g a : Fin 7) (w : Block) : hits g (w++[a]) ≤ hits g w+1 := by
  induction w with
  | nil => simp [hits,bag,windows]
  | cons b xs ih =>
    by_cases long : 6≤xs.length
    · have five : 5≤xs.length := by omega
      have keep := List.take_append_of_le_length (l₂:=[a]) long
      by_cases mem : g∈b::xs.take 6 <;>
        simpa [hits,bag,windows,long,five,keep,mem] using ih
    · have cap:=Multiset.card_le_card (Multiset.filter_le (fun e : Block=>g∈e) (bag ((b::xs)++[a])))
      change hits g ((b::xs)++[a]) ≤ (windows ((b::xs)++[a])).length at cap
      simp only [windows_length,List.length_append,List.length_cons,List.length_nil] at cap
      omega

theorem every_letter {w : Block} (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) (g : Fin 7) : 49≤w.count g := by
  have floor:=hit_floor size vis done g
  have cap:=incidence_cap g w
  omega

theorem boundary_letter {w : Block} (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) {g : Fin 7} {v : Block}
    (endpt : w=g::v ∨ w=v++[g]) : 50≤w.count g := by
  have floor:=hit_floor size vis done g
  have cap:=incidence_cap g v
  rcases endpt with rfl|rfl
  · have inc:=at_cons g g v
    simp at inc
    simp
    omega
  · have inc:=end_step g g v
    simp [List.count_append]
    omega

#print axioms every_letter
#print axioms boundary_letter
end ExactWordFlow.SixFrequency

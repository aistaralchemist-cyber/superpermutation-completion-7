import HistoricHoleTable

namespace ExactWordFlow.HistoricalTransfer
open SevenWordWindows RotationCore
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain
open private packet_price from WheelPartition
open private width_deficit from PacketTransfer

/-- Consequences on a single board, keeping the actual trails and the actual wheel packets. -/
structure PriceRangeBoard (M : Nat) (G : List (List (NRow 7))) (p : List WheelPacket) : Prop where
  family : TrailFam 7 G
  trails : G.length = M
  coverage :
    let entries := rowsEntries G.flatten ++ p.flatMap WheelPacket.cells
    entries.length=720 ∧ entries.Pairwise (NotRot (k:=7)) ∧
      ∀ v : Vtx 7, ∃ x∈entries, (v : List ℕ) ~r (x : List ℕ)
  accounts :
    let z := G.flatten.length + M + p.length
    let H := rowsHoles 7 G.flatten
    let δ := SevenOmission.deficit (widths p)
    135≤z ∧ z≤137 ∧
      H + 6*M + p.length + δ + 6*(137-z)=102 ∧
      (holeFloor[137-z]!)[M]! ≤ H
  row_count :
    let z := G.flatten.length + M + p.length
    G.flatten.length = rowsHoles 7 G.flatten + 5*M + 35 + 5*(137-z) + SevenOmission.deficit (widths p)
  low : G.flatten.length+M+p.length=135 → 2≤M ∧ M≤6
  mid : G.flatten.length+M+p.length=136 → M≤9
  nine : G.flatten.length+M+p.length=136 → M=9 →
    rowsHoles 7 G.flatten=42 ∧ p=[] ∧ SevenOmission.deficit (widths p)=0 ∧
    G.flatten.length=127

private theorem low_range : ∀ m : Fin 12, 0 < m.val →
    (holeFloor[2]!)[m.val]!+6*m.val+12≤102 → 2 ≤ m.val ∧ m.val≤6 := by decide +kernel

private theorem mid_range : ∀ m : Fin 12,
    (holeFloor[1]!)[m.val]!+6*m.val+6≤102 → m.val≤9 := by decide +kernel

/-- The 720-class mass calculation applies to every witness of the geometric
cut. Substituting its own price and its own row-cap account gives the bounds. -/
theorem price_ranges_of_cover {M : Nat} {G : List (List (NRow 7))} {p : List WheelPacket}
    (lo : 1≤M) (hi : M≤11) (fam : TrailFam 7 G) (sz : G.length=M)
    (cov : let entries := rowsEntries G.flatten ++ p.flatMap WheelPacket.cells
           entries.length=720 ∧ entries.Pairwise (NotRot (k:=7)) ∧
             ∀ v : Vtx 7, ∃ x∈entries, (v : List ℕ) ~r (x : List ℕ))
    (minPrice : 135≤G.flatten.length+M+p.length)
    (maxPrice : G.flatten.length+M+p.length≤137) : PriceRangeBoard M G p := by
  have count := cov.1
  rw [List.length_append] at count
  have area := rowsEntries_length_add_holes (k:=7)
    (fun r hr => len_le_of_rowsEntries_pairwise (by decide : 2≤7) fam.classes hr)
  change (rowsEntries G.flatten).length+rowsHoles 7 G.flatten=6*G.flatten.length at area
  have de := width_deficit p
  have mass := packet_price p
  let z := G.flatten.length+M+p.length
  let H := rowsHoles 7 G.flatten
  let δ := SevenOmission.deficit (widths p)
  have identity : H+6*M+p.length+δ+6*(137-z)=102 := by dsimp [H,z,δ]; omega
  have floor := hole_floor_of_value fam (by omega) (i:=137-z) (by dsimp [z]; omega)
    (by dsimp [z]; omega)
  rw [sz] at floor
  change (holeFloor[137-z]!)[M]!≤H at floor
  refine ⟨fam,sz,cov,⟨minPrice,maxPrice,identity,floor⟩,(by dsimp only; omega),?_,?_,?_⟩
  · intro pr
    change z=135 at pr
    rw [pr] at identity floor
    change (holeFloor[2]!)[M]! ≤ H at floor
    exact low_range ⟨M,by omega⟩ lo (by change (holeFloor[2]!)[M]!+6*M+12≤102; omega)
  · intro pr
    change z=136 at pr
    rw [pr] at identity floor
    change (holeFloor[1]!)[M]! ≤ H at floor
    exact mid_range ⟨M,by omega⟩ (by change (holeFloor[1]!)[M]!+6*M+6≤102; omega)
  · intro pr m
    change z=136 at pr
    rw [pr,m] at identity floor
    change 42≤H at floor
    have empty : p=[] := List.eq_nil_of_length_eq_zero (by omega)
    refine ⟨by change H=42; omega,empty,by change δ=0; omega,?_⟩
    dsimp [z] at pr
    rw [empty] at pr
    simp only [List.length_nil] at pr
    omega

/-- A genuine 1196-letter witness gives one family and packet list satisfying
all three price exclusions, the class coverage and the exact identity together. -/
theorem word_price_ranges {w : Block} (len : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) :
    ∃ (M : Nat) (G : List (List (NRow 7))) (p : List WheelPacket),
      1≤M ∧ M≤11 ∧ PriceRangeBoard M G p := by
  obtain ⟨M,lo,hi,G,p,fam,sz,cov,_,_,pmin,pmax⟩ := word_to_common len vis done
  exact ⟨M,G,p,lo,hi,price_ranges_of_cover lo hi fam sz cov pmin pmax⟩


/-- The four cap hypotheses are isolated geometric trail exclusions. The
bounds above, the coverage and the price identity do not assume any of them. -/
theorem mid_of_trail_caps {M : Nat} {G : List (List (NRow 7))} {p : List WheelPacket}
    (board : PriceRangeBoard M G p) (pos : 1≤M) (pr : G.flatten.length+M+p.length=136)
    (one : TrailCap 1 96 40) (two : TrailCap 2 84 50)
    (eight : TrailCap 8 48 80) (nine : TrailCap 9 42 85) : 3≤M ∧ M≤7 := by
  have maxM := board.mid pr
  obtain ⟨_,_,identity,_⟩ := board.accounts
  have rows := board.row_count
  rw [pr] at identity rows
  have exclude (j b v : Nat) (cap : TrailCap j b v) (eq : M=j)
      (h : rowsHoles 7 G.flatten≤b)
      (value : (v:ℤ)≤(G.flatten.length:ℤ)-(rowsHoles 7 G.flatten:ℤ)) : False :=
    (not_lt_of_ge value) (cap G board.family (board.trails.trans eq) h)
  have a : M≠1 := fun h => exclude 1 96 40 one h (by omega) (by omega)
  have b : M≠2 := fun h => exclude 2 84 50 two h (by omega) (by omega)
  have c : M≠8 := fun h => exclude 8 48 80 eight h (by omega) (by omega)
  have d : M≠9 := fun h => exclude 9 42 85 nine h (by omega) (by omega)
  omega

#print axioms word_price_ranges
end ExactWordFlow.HistoricalTransfer

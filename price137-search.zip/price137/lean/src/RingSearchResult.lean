import LowerBounds.PSearch
import LowerBounds.KTables

/-! Evaluate all residues of the original ring program. The adapter checks
the literal row against Halfar's `J16.RXtab` by definitional equality. -/
namespace ExactWordFlow.Core1224
open SuperpermLowerBounds SuperpermLowerBounds.T5900

def ringRows : List Nat :=
  [5, 1, 2, 1, 1, 1, 10, 6, 16, 3, 13, 14, 15, 16, 21, 22,
   27, 25, 33, 28, 35, 31, 37, 33, 38, 36, 40, 41, 46, 43, 48, 49,
   50, 50, 56, 53, 58, 58, 59, 60, 65, 62, 67, 67, 69, 69, 71, 71,
   76, 77, 78, 78, 84, 81, 82, 83, 86, 87, 89, 89, 91, 90, 93, 92]

theorem rx63_all :
    PS.ringSearch 7 (Ttab.getD 0 []) ringRows 63 400 13 16 0 16 = false := by
  native_decide

#print axioms rx63_all
end ExactWordFlow.Core1224

import LowerBounds.PSearch
import LowerBounds.PTables
import LowerBounds.KTables

/-! Replay the previous ring bound through 69 holes using the accepted seed matrix.
The numeric search uses no improved chain row as an assumption. -/
namespace ExactWordFlow.Defect16Obstruction
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.T5900

theorem ring69_seed : PS.ringSearch 7 Mtab TRtab 69 400 13 16 0 16 = false := by
  native_decide

#print axioms ring69_seed
end ExactWordFlow.Defect16Obstruction

import OpenCycleBridge
import WindowAlphabet

namespace ExactWordFlow.OpenCycleAnchor
open SevenWordWindows SuperpermutationBounds DirectedEuler ResidualDensity OpenCycleBridge
open RotationReinsert RotationCore ResidualRoutes RotationSpan RotationComponentCount CoreAssembly
open private windows_step from WindowAlphabet
open private turn_end last_six from OpenCycle
open private sink from SixCanonical
open private prescribe from CompletionExchange
open private sel_mono from RotationSpan

private theorem required_start : (required.map dst).count SixCanonical.start=1 := by native_decide

theorem normalize_source_once {w : Block} (cover : Covers w) (short : w.length≤5900) :
    ∃v : Block, v.length=5900 ∧ Covers v ∧ v.take 6=SixCanonical.start ∧
      full (v.drop (v.length-6)) ∧ tag (v.take 6)≠tag (v.drop (v.length-6)) ∧ ((bag v).map dst).count SixCanonical.start=1 := by
  obtain ⟨m,hm,sz⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
  have minimal (v : Block) (hv : Covers v) : m.length≤v.length :=
    sz.trans_le (SuperpermBridge.ssuper_le_length hv)
  obtain ⟨v,vm,yes,first,p,pl,pn,suf⟩ := SixCanonical.normalize_to hm (le_refl _)
  have head : v.take 6=SixCanonical.start := by
    obtain ⟨r,rfl⟩ := first
    rw [List.take_append_of_le_length (by simp : 6≤(List.finRange 7).length)]
    decide
  have init : full (v.take 6) := head ▸ (by decide : full SixCanonical.start)
  have hp := (mem_reps p).mpr ⟨pl,pn⟩
  have geo := turn_end p hp
  have terminal := last_six pl suf
  have clean : full (v.drop (v.length-6)) := terminal ▸ geo.1
  have ceil := (minimal w cover).trans short
  have lb := SuperpermLowerBounds.covers_lower_bound_7_k16_native v yes
  have diff := OpenCycle.shortest_tags yes (by omega) (vm ▸ minimal) init clean
  obtain ⟨X,eb,cost,flow⟩ := extract_windows_at_ends v yes (by omega)
  have degrees := source_degrees flow (fun eq => diff (congrArg tag eq)) (by
    intro u hu; have := minimal u hu; omega)
  rw [head] at degrees
  have before : ((bag v).map dst).count SixCanonical.start=1 := by
    rw [←eb,Multiset.map_add,Multiset.count_add,required_start,degrees.1]
  by_cases already : v.length=5900
  · exact ⟨v,already,yes,head,clean,diff,before⟩
  have n : v.length=5899 := by omega
  let y := v++[p.headD 0]
  have yy : Covers y := by
    intro q lq nq
    obtain ⟨l,r,eq⟩ := yes q lq nq
    exact ⟨l,r++[p.headD 0],by simp [y,eq,List.append_assoc]⟩
  have yhead : y.take 6=v.take 6 := List.take_append_of_le_length (by omega)
  have suf' : p.tail++[p.headD 0] <:+ y := by
    obtain ⟨l,eq⟩ := suf
    cases p with
    | nil => simp at pl
    | cons a as =>
      exact ⟨l++[a],by simp [y,←eq,List.append_assoc]⟩
  have turnlen : (p.tail++[p.headD 0]).length=7 := by simp [pl]
  have last := last_six turnlen suf'
  have newDiff : tag (y.take 6)≠tag (y.drop (y.length-6)) := by
    rwa [yhead,last,geo.2.2,←terminal]
  let xs:=v.drop (v.length-6)
  have six : xs.length=6 := by simp [xs,n]
  have add := windows_step (v.take (v.length-6)) xs (p.headD 0) six
  change windows ((v.take (v.length-6) ++ v.drop (v.length-6))++_)=
      windows (v.take (v.length-6)++v.drop (v.length-6))++_ at add
  rw [List.take_append_drop] at add
  have ybag : bag y=bag v+{xs++[p.headD 0]} := by
    change (↑(windows (v++[p.headD 0])) : Multiset Block)=_
    rw [add]
    rfl
  have atTail : dst (xs++[p.headD 0]) = y.drop (y.length-6) := by
    change dst (v.drop _++_)=_
    rw [terminal,last]
    simp only [dst,List.drop_one]
  have off : dst (xs++[p.headD 0]) ≠ SixCanonical.start := by
    intro bad
    apply newDiff
    rw [yhead,head,←atTail,bad]
  refine ⟨y,by simp [y,n],yy,yhead.trans head,last ▸ geo.2.1,newDiff,?_⟩
  rw [ybag,Multiset.map_add,Multiset.count_add,before,Multiset.map_singleton,Multiset.count_singleton]
  simp only [ite_eq_right_iff, Nat.add_eq_left]
  exact fun eq => (off eq.symm).elim

theorem canonical_twice
    {w : Block} (cover : Covers w) (short : w.length≤5900) :
    ∃z : Block, z.length=1196 ∧ (visited z).card=720 ∧ (complete z).card=48 ∧ SixGeometry.six⊆complete z ∧
      z.take 6=SixCanonical.start ∧ full (z.drop (z.length-6)) ∧
      tag (z.take 6)≠tag (z.drop (z.length-6)) ∧ (↑(anchors z) : Multiset Block).count SixCanonical.start=2 := by
  classical
  obtain ⟨v,size,yes,first,last,diff,once⟩ := normalize_source_once cover short
  obtain ⟨X,eb,cost,flow⟩ := extract_windows_at_ends v yes (by omega)
  have budget : X.card=854 := by omega
  obtain ⟨S,legal,bound,spans⟩ := spanning flow
  have few := Window597.outside42 flow budget.le
  have unionLegal := Finset.union_subset legal SixGeometry.legal
  have small : (S∪SixGeometry.six).card≤48 := by have := Finset.card_union_le S SixGeometry.six; have := SixGeometry.six_card; omega
  obtain ⟨D,includes,dLegal,dSize⟩ := Finset.exists_subsuperset_card_eq unionLegal small (by rw [board]; decide)
  have kept : S⊆D := Finset.subset_union_left.trans includes
  obtain ⟨z,head,split,len,all,done⟩ := prescribe flow budget dLegal
    (fun u hu => label_lift (sel_mono X kept) (spans u hu))
  have newEnd := sink flow dLegal (by omega) head split
  have includeSix : SixGeometry.six⊆D := Finset.subset_union_right.trans includes
  have must : (mandatory D).map dst ≤ required.map dst := Multiset.map_le_map (Multiset.filter_le ..)
  let edge : Block := [6,0,1,2,3,4,5]
  have concrete : edge∈required ∧ dst edge=SixCanonical.start ∧ classKey edge∈SixGeometry.six := by native_decide
  have incoming : SixCanonical.start∈(mandatory D).map dst :=
    Multiset.mem_map.mpr ⟨edge,Multiset.mem_filter.mpr ⟨concrete.1,includeSix concrete.2.2⟩,concrete.2.1⟩
  have one := Multiset.count_le_of_le SixCanonical.start must
  have pos := Multiset.count_pos.mpr incoming
  rw [required_start] at one
  rw [←eb,Multiset.map_add,Multiset.count_add,required_start] at once
  have empty : (X.map dst).count SixCanonical.start=0 := by omega
  have single : ((mandatory D).map dst).count SixCanonical.start=1 := by omega
  have zbag : ((bag z).map dst).count SixCanonical.start=1 := by
    rw [split,Multiset.map_add,Multiset.count_add,empty,single]
  have twice : (↑(anchors z) : Multiset Block).count SixCanonical.start=2 := by
    unfold anchors
    rw [head,first]
    change (SixCanonical.start ::ₘ (bag z).map dst).count SixCanonical.start=2
    simp only [Multiset.count_cons_self,zbag]
  exact ⟨z,by omega,all,done ▸ dSize,done ▸ includeSix,head.trans first,newEnd ▸ last,
    by rwa [head,newEnd],twice⟩

#print axioms canonical_twice
end ExactWordFlow.OpenCycleAnchor

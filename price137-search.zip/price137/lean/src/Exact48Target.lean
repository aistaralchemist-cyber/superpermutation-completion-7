import ReducedTarget5901
import Core1224Limit

namespace ExactWordFlow.Exact48Target
open SevenWordWindows SuperpermutationBounds RotationCore

/-- Completing the other 672 classes adds exactly 4,704 letters to this word. -/
theorem extend_exact48 (v : Block) (vis : (visited v).card = 720)
    (done : (complete v).card = 48) :
    ∃ w : Block, Covers w ∧ w.length = v.length + 4704 := by
  have len := Core1224.length_of_visits v vis
  obtain ⟨w, hw, size⟩ := expand_remaining (v := v) (by omega) vis
  exact ⟨w, hw, by simpa [done] using size⟩

/-- Any lower bound on complete seven-symbol words gives a lower bound here. -/
theorem transfer_lower {b : Nat} (floor : Almanac.LowerBoundAt 7 b)
    (v : Block) (vis : (visited v).card = 720) (done : (complete v).card = 48) :
    b ≤ v.length + 4704 := by
  obtain ⟨w, hw, size⟩ := extend_exact48 v vis done
  exact size ▸ floor w ((Core1224.covers_iff_almanac w).mp hw)

/-- Applying Halfar's computer-assisted lower bound rules out lengths up to 1196. -/
theorem minimum_of_5901 (floor : Almanac.LowerBoundAt 7 5901)
    (v : Block) (vis : (visited v).card = 720) (done : (complete v).card = 48) :
    1197 ≤ v.length := by
  have bound := transfer_lower floor v vis done
  omega

/-- The accepted Lean lower bound of 5899 alone gives this unconditional floor. -/
theorem minimum_from_accepted (v : Block) (vis : (visited v).card = 720)
    (done : (complete v).card = 48) : 1195 ≤ v.length := by
  have len := Core1224.length_of_visits v vis
  have bound := Core1224.expansion_floor v (by omega) vis
  rw [done] at bound
  omega

/-- This equivalence uses the established 854-edge component cutoff in the reverse direction. -/
theorem exclusion_iff_lower :
    (¬ ∃ v : Block, v.length = 1196 ∧ (visited v).card = 720 ∧ (complete v).card = 48)
      ↔ Almanac.LowerBoundAt 7 5901 := by
  constructor
  · intro excluded
    apply (Core1224.almanac_iff_atMost51.trans Core1224.atMost51_iff_atMost47).mpr
    intro v size vis
    have cap := Core1224.atMost48 v size vis
    by_contra! enough
    exact excluded ⟨v, size, vis, by omega⟩
  · rintro floor ⟨v, size, vis, done⟩
    have bound := minimum_of_5901 floor v vis done
    omega

#print axioms minimum_of_5901
#print axioms minimum_from_accepted
#print axioms exclusion_iff_lower
end ExactWordFlow.Exact48Target

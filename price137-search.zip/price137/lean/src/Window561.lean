import MarkEnvelope854
import NoRoot271

namespace ExactWordFlow.Window561
open SevenWordWindows ResidualDensity DirectedEuler WeightedMarks MarkedGeometry MarkEnvelope854
open private initial start accepted move memoryWord prefixes from MarkedDensity
open private upper_read upper_step from MarkEnvelope854
open private unmask mask_cons from StrongerDensity
open private canonical normalize from Interval66
open private search_complete from Geometry40
open private runs from MarkedExtrema

private def optimal : Nat → Nat → List (List Bool)
  | 0,_ => [[]]
  | n+1,s =>
    [false,true].flatMap fun b =>
      let j:=move s b
      if j<prefixes.size ∧ b.toNat+upper n j=upper (n+1) s then
        (optimal n j).map (b::·)
      else []

private theorem maximizer (pre bs : List Bool) (s : Nat) (valid : s<prefixes.size)
    (small : bs.length≤855) (suff : memoryWord s <:+ pre)
    (safeWord : ∀x∈forbidden, ¬x <:+: pre++bs) (maximal : upper bs.length s≤bs.count true) :
    bs∈optimal bs.length s := by
  induction bs generalizing s pre with
  | nil => simp [optimal]
  | cons b bs ih =>
    obtain ⟨next,suffix,_⟩:=accepted s b pre bs valid suff safeWord
    have hsz : bs.length<855 := by simpa using small
    have sm : bs.length≤855 := by omega
    have good : ∀x∈forbidden, ¬x <:+: (pre++[b])++bs := by simpa using safeWord
    have tail := upper_read _ _ _ next sm suffix good
    have pay:=upper_step ⟨bs.length,hsz⟩ ⟨s,valid⟩ b next
    change b.toNat+upper bs.length (move s b)≤upper (bs.length+1) s at pay
    have cnt : (b::bs).count true=b.toNat+bs.count true := by cases b <;> simp [Nat.add_comm]
    simp only [List.length_cons,cnt] at maximal
    have win : b.toNat+upper bs.length (move s b)=upper (bs.length+1) s := by omega
    have child:=ih _ _ next sm suffix good (by omega)
    apply List.mem_flatMap.mpr
    refine ⟨b,by cases b <;> simp,?_⟩
    dsimp only
    rw [ite_eq_left ⟨next,win⟩]
    exact List.mem_map.mpr ⟨bs,child,rfl⟩

open private submask from MarkedGeometry
open private count_add from DensityBudget

/-- Each row describes lengths of marked runs separated by a single unmarked position. -/
private def obstructions : List (List Nat) := [
  [5, 6, 3, 6, 6, 6, 6, 3, 6, 6, 2],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 1],
  [4, 6, 6, 3, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 1],
  [1, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 3, 6, 6, 4],
  [5, 4, 6, 6, 6, 6, 1, 5],
  [5, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 3, 6, 6, 6, 4, 2],
  [2, 4, 6, 6, 6, 3, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 5],
  [4, 6, 6, 3, 6, 6, 6, 4, 6, 6, 4, 2],
  [2, 4, 6, 6, 4, 6, 6, 6, 3, 6, 6, 4],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 5, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 1],
  [5, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 1],
  [1, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 5],
  [5, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 1],
  [1, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 5],
  [5, 6, 4, 6, 6, 3, 6, 6, 4, 6, 1],
  [4, 6, 3, 6, 6, 6, 6, 2, 4],
  [4, 2, 6, 6, 6, 6, 3, 6, 4],
  [4, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 3],
  [3, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 4],
  [5, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 5, 3],
  [3, 5, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 5],
  [4, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6, 4, 6, 6, 6, 2],
  [2, 6, 6, 6, 4, 6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 4],
  [5, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 3, 6, 6, 6, 4, 2],
  [2, 4, 6, 6, 6, 3, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 5],
  [1, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6],
  [6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 1]
]

private theorem rejected : obstructions.all (fun ns =>
    !ns.isEmpty && ns.all (fun n=>decide (0<n)) &&
    canonical.all (fun s => !rowSearch ns s []))=true := by native_decide

private theorem no_profile {u : ℕ→Six} {p : ℕ→Prop} (w : Walk u) (h : Marked u p)
    (ns : List Nat) (hn : ns∈obstructions) (i : ℕ) (marks : rowsMarked p i ns) : False := by
  have ⟨⟨nonempty,positive⟩,bad⟩ := Bool.and_eq_true_iff.mp (List.all_eq_true.mp rejected ns hn)
    |>.imp_left Bool.and_eq_true_iff.mp
  have pos (n) (hm : n∈ns) := of_decide_eq_true (List.all_eq_true.mp positive n hm)
  have first : p i := by
    cases ns with
    | nil => simp at nonempty
    | cons n rest => simpa using marks.1 0 (pos n List.mem_cons_self)
  obtain ⟨v,vw,vm,initial⟩:=normalize w h i first
  have yes:=search_complete vw vm ns pos i marks [] (by simp)
  have no:=List.all_eq_true.mp bad _ initial
  simp [yes] at no


private def table : List (Nat × Nat) := [(554,469),(560,474),(644,545)]

private def checked (x : Nat × Nat) : Bool :=
  x.1+1≤855 && upper (x.1+1) initial==x.2+1 && (optimal (x.1+1) initial).all
    (fun bs => obstructions.any (fun ns => decide (rowsMask ns <:+: bs)))

set_option maxHeartbeats 0 in
set_option maxRecDepth 8192 in
private theorem data : table.all checked=true := by native_decide

theorem marks (u : Nat→Six) (p : Nat→Prop) [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i : Nat) {k c : Nat} (mem : (k,c)∈table) :
    count p i (k+1)≤c := by
  by_contra! many
  have checkedRow:=List.all_eq_true.mp data _ mem
  unfold checked at checkedRow
  simp only [Bool.and_eq_true,beq_iff_eq,decide_eq_true_eq] at checkedRow
  obtain ⟨⟨size,cap⟩,rest⟩:=checkedRow
  let bs:=mask p i (k+1)
  have len : bs.length=k+1:=by simp [bs,mask]
  have hi : upper bs.length initial≤bs.count true := by rw [len,cap,mark_count]; omega
  have hit:=maximizer [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i (k+1)) hi
  rw [len] at hit
  have test:=List.all_eq_true.mp rest _ hit
  obtain ⟨ns,hn,found⟩:=List.any_eq_true.mp test
  obtain ⟨l,r,hpat⟩ := of_decide_eq_true found
  have sub:=submask i (k+1) l (rowsMask ns) r hpat
  exact no_profile w m ns hn _ (unmask _ _ ns sub)

theorem route {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀e∈es,e.length=7) {k c : Nat} (bounds : (k,c)∈table) (len : es.length≤k) :
    classCount s es≤c := by
  obtain ⟨u,I,walk,mark,eq⟩:=open_observations r wd
  have h:=marks u (·∈I) walk mark 0 bounds
  have add:=count_add (·∈I) 0 (es.length+1) (k-es.length)
  rw [show es.length+1+(k-es.length)=k+1 by omega] at add
  omega

theorem root554 {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀ e∈es,e.length=7) (len : es.length≤554) : classCount s es≤469 :=
  route r wd (k:=554) (by decide) len

theorem root560 {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀ e∈es,e.length=7) (len : es.length≤560) : classCount s es≤474 :=
  route r wd (k:=560) (by decide) len

theorem root644 {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀ e∈es,e.length=7) (len : es.length≤644) : classCount s es≤545 :=
  route r wd (k:=644) (by decide) len

#print axioms root644
#print axioms root554
#print axioms root560
end ExactWordFlow.Window561

import AllWordPrice

namespace SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain T5899

private theorem packet_room (p : List WheelPacket) :
    (p.flatMap WheelPacket.cells).length ≤ 5*p.length := by
  induction p with
  | nil => exact Nat.le_refl 0
  | cons t rest ih =>
    simp only [List.flatMap_cons,List.length_append,List.length_cons]
    have h := t.small
    omega

/-- Price 134 would give an impossible family of weight at most 84 and
net value at least 50 in Halfar's original trail-cap theorem. -/
theorem partition_price_135 (cap : ChainCap Mf 84) (profiles : Profiles)
    {F : List (List (NRow 7))} (f : TrailFam 7 F) (p : List WheelPacket)
    (length : (rowsEntries F.flatten ++ p.flatMap WheelPacket.cells).length=720) :
    135 ≤ F.flatten.length+F.length+p.length := by
  by_contra! low
  rw [List.length_append] at length
  have area := rowsEntries_length_add_holes (k:=7)
    (fun r hr => len_le_of_rowsEntries_pairwise (by decide : 2 ≤ 7) f.classes hr)
  change (rowsEntries F.flatten).length + rowsHoles 7 F.flatten = 6*F.flatten.length at area
  have space := packet_room p
  have bound := family_le_49 cap profiles f (by rw [lW_prs]; omega)
  rw [lE_prs] at bound
  omega

/-- The minimum in the definition is attained since a covering word exists. -/
theorem geometric_price_135 (cap : ChainCap Mf 84) (profiles : Profiles) : 135 ≤ geometricPrice := by
  obtain ⟨w,hw,_⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0 < 7)
  obtain ⟨F,p,f,cover,_⟩ := all_word_price w hw
  unfold geometricPrice
  apply le_csInf (by exact ⟨_,F,p,f,cover,rfl⟩)
  rintro n ⟨F',p',ff,cover',rfl⟩
  exact partition_price_135 cap profiles ff p' cover'.1

end SuperpermLowerBounds.LengthBudget
#print axioms SuperpermLowerBounds.LengthBudget.geometric_price_135

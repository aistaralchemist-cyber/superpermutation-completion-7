import Core1224
import WheelAccess

/-! A completion bound also for words missing some of the 720 rotation classes. -/
namespace ExactWordFlow.RepairFrom5899
open SevenWordWindows ResidualDensity RotationReinsert RotationCore SuperpermutationBounds

private def anchorStarting (c : Block) (a : Fin 7) := (c.rotate (c.idxOf a)).take 6

private theorem starting_state : ∀ c∈allClasses, ∀ a : Fin 7,
    let u := anchorStarting c a
    u = a :: u.tail ∧ u.tail.length = 5 ∧ full u ∧ tag u = c := by
  native_decide

private theorem visited_append (w t : Block) : visited w ⊆ visited (w++t) := by
  intro c hc
  obtain ⟨u, here, clean, key⟩ := (mem_visited w c).mp hc
  obtain ⟨l,r,loc⟩ := (WheelAccess.anchor_iff _ u clean).mp here
  apply (mem_visited _ _).mpr
  exact ⟨u, (WheelAccess.anchor_iff _ u clean).mpr ⟨l,r++t,by simp [loc,List.append_assoc]⟩, clean, key⟩

private theorem complete_append (w t : Block) : complete w ⊆ complete (w++t) := by
  intro c hc
  obtain ⟨onBoard,all⟩ := (mem_complete w c).mp hc
  apply (mem_complete _ _).mpr
  refine ⟨onBoard, ?_⟩
  intro p hp key
  obtain ⟨l,r,loc⟩ := window_occurs w (all p hp key)
  rw [loc]
  simpa [List.append_assoc] using window_mem l p (r++t) ((mem_reps p).mp hp).1

private theorem add_visit {w c : Block} (nonempty : w ≠ []) (hc : c∈allClasses) :
    ∃ t : Block, t.length=5 ∧ c∈visited (w++t) := by
  let a := w.getLast nonempty
  let u := anchorStarting c a
  obtain ⟨first,len,clean,key⟩ := starting_state c hc a
  refine ⟨u.tail,len,(mem_visited _ _).mpr ⟨u,?_,clean,key⟩⟩
  apply (WheelAccess.anchor_iff _ u clean).mpr
  refine ⟨w.dropLast,[],?_⟩
  have endw : w.dropLast++[a]=w := List.dropLast_append_getLast nonempty
  calc
    w++u.tail = (w.dropLast++[a])++u.tail := by rw [endw]
    _ = w.dropLast++u++[] := by simpa only [List.append_assoc,List.singleton_append,List.append_nil] using congrArg (w.dropLast ++ ·) first.symm

private theorem add_visits (w : Block) (nonempty : w ≠ []) (S : Finset Block) (onBoard : S⊆allClasses) :
    ∃ t : Block, t.length=5*S.card ∧ S⊆visited (w++t) := by
  classical
  induction S using Finset.induction_on with
  | empty => exact ⟨[],by simp,by simp⟩
  | @insert c S fresh ih =>
    obtain ⟨p,sz,cover⟩ := ih (by intro a ha; exact onBoard (Finset.mem_insert_of_mem ha))
    obtain ⟨q,sq,hit⟩ := add_visit (w:=w++p) (by simp [nonempty]) (onBoard (Finset.mem_insert_self ..))
    refine ⟨p++q,by simp [sz,sq,Finset.card_insert_of_notMem fresh,Nat.mul_add],?_⟩
    rw [←List.append_assoc]
    exact Finset.insert_subset hit (cover.trans (visited_append _ _))

/-- Spending at most five letters per missing visit is enough: the last letter of the
current word can start a six-letter representative of any requested rotation class. -/
theorem complete_with_repairs (z : Block) (long : 6≤z.length) :
    ∃ w : Block, Covers w ∧ w.length ≤ z.length + 5*(720-(visited z).card) + 7*(720-(complete z).card) := by
  classical
  let S := allClasses \ visited z
  obtain ⟨t,length,more⟩ := add_visits z (by intro eq; simp [eq] at long) S Finset.sdiff_subset
  have incl : allClasses⊆visited (z++t) := by
    intro c hc
    by_cases seen : c∈visited z
    · exact visited_append z t seen
    · exact more (Finset.mem_sdiff.mpr ⟨hc,seen⟩)
  have all : (visited (z++t)).card=720 := by
    rw [Finset.Subset.antisymm (visited_subset _) incl,board]
  obtain ⟨w,cover,pay⟩ := expand_remaining (v:=z++t) (by simp; omega) all
  have saved := Finset.card_le_card (complete_append z t)
  have paid : S.card=720-(visited z).card := by
    simpa only [S,board] using Finset.card_sdiff_of_subset (visited_subset z)
  rw [List.length_append,length,paid] at pay
  exact ⟨w,cover,by omega⟩

theorem repair_floor (z : Block) (long : 6≤z.length) :
    5899 ≤ z.length + 5*(720-(visited z).card) + 7*(720-(complete z).card) := by
  obtain ⟨w,cover,cap⟩ := complete_with_repairs z long
  exact (SuperpermLowerBounds.covers_lower_bound_7_k16_native w cover).trans cap

/-- For the length in question, the two numerical floors give different completion caps. -/
theorem caps_at_1196 (z : Block) (size : z.length=1196) (vis : (visited z).card=720) :
    ((∀ w : Block, Covers w → 5809≤w.length) → (complete z).card≤61) ∧
    (complete z).card≤48 := by
  obtain ⟨w,cover,pay⟩ := complete_with_repairs z (by omega)
  simp only [size,vis,Nat.sub_self,Nat.mul_zero,Nat.add_zero] at pay
  constructor
  · intro lower
    have h := lower w cover
    omega
  · have h := SuperpermLowerBounds.covers_lower_bound_7_k16_native w cover
    omega

theorem edit_budget_from_lower {B : Nat} (lower : ∀w : Block, Covers w → B≤w.length)
    {z : Block} (long : 6≤z.length) {a b d : Nat}
    (size : z.length + d = 1196) (keep : 48 ≤ (complete z).card+a) (vis : 720 ≤ (visited z).card+b) :
    B+d ≤ 5900+7*a+5*b := by
  obtain ⟨w,covers,cap⟩ := complete_with_repairs z long
  have bound := lower w covers
  have covered := (Finset.card_le_card ((complete_subset z).trans (visited_subset z))).trans_eq board
  omega

/-- Test any shortening that destroys at most a completions and b visits. -/
theorem edit_budget {z : Block} (long : 6≤z.length) {a b d : Nat}
    (size : z.length + d = 1196) (keep : 48 ≤ (complete z).card+a) (vis : 720 ≤ (visited z).card+b) :
    d ≤ 1 + 7*a + 5*b := by
  have limit := edit_budget_from_lower SuperpermLowerBounds.covers_lower_bound_7_k16_native long size keep vis
  omega

#print axioms complete_with_repairs
#print axioms caps_at_1196
#print axioms repair_floor
#print axioms edit_budget
end ExactWordFlow.RepairFrom5899

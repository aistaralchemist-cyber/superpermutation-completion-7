import RepairFrom5899

namespace ExactWordFlow.SixGeometry
open SevenWordWindows RotationCore RotationReinsert

/-- Directed cycles on the seven symbols obtained by adding one fixed nonzero residue. -/
def steps : Finset (Fin 7) := Finset.univ.erase 0
def row (d a : Fin 7) : Block := (List.finRange 7).map (fun i => a+i*d)
def six : Finset Block := steps.image (fun d => row d 0)

theorem legal : six⊆allClasses := by native_decide

theorem six_card : six.card = 6 := by native_decide

private theorem rows : ∀d∈steps,∀a : Fin 7,
    row d a ∈ representatives ∧ classKey (row d a) = row d 0 ∧
    (row d a)[0]? = some a ∧
    ∀ j : Fin 6, ((row d a)[j.val+1]?.getD 0)-((row d a)[j.val]?.getD 0)=d := by
  native_decide

private def diff (w : Block) (i : Nat) : Fin 7 := w[i+1]?.getD 0 - w[i]?.getD 0

private theorem lookup {w p l r : Block} (atP : w=l++p++r) {i : Nat} (hi : i<p.length) :
    w[l.length+i]?=p[i]? := by
  rw [atP, List.getElem?_append_left (by simp; omega), List.getElem?_append_right (by omega)]
  simp

private theorem starts {w : Block} {d : Fin 7} (hd : d∈steps) (sub : six⊆complete w)
    (a : Fin 7) : ∃i : Nat, w[i]?=some a ∧
        ∀ j : Fin 6, i+j.val<w.length-1 ∧ diff w (i+j.val)=d := by
  obtain ⟨inBoard,rot,one,delta⟩ := rows d hd a
  have done := (mem_complete _ _).mp (sub (Finset.mem_image.mpr ⟨d,hd,rfl⟩))
  obtain ⟨l,r,atP⟩ := window_occurs w (done.2 (row d a) inBoard rot)
  have len : (row d a).length=7 := ((mem_reps _).mp inBoard).1
  refine ⟨l.length,?_,?_⟩
  · simpa using (lookup atP (i:=0) (by omega)).trans one
  · intro j
    have le := j.isLt
    refine ⟨by simp [atP,len]; omega,?_⟩
    unfold diff
    rw [Nat.add_assoc,lookup atP (by omega),lookup atP (by omega)]
    exact delta j

/-- A completed progression class requires twelve distinct occurrences of its step. -/
theorem twelve {w : Block} (sub : six⊆complete w) {d : Fin 7} (hd : d∈steps) :
    12 ≤ ((Finset.range (w.length-1)).filter (fun i=>diff w i=d)).card := by
  classical
  choose pos letter span using starts hd sub
  have inj : Function.Injective pos := by
    intro a b same
    have eq := (letter a).symm.trans ((congrArg (fun i=>w[i]?) same).trans (letter b))
    exact Option.some.inj eq
  let S := Finset.univ.image pos
  have n : S.card=7 := by simp [S,Finset.card_image_of_injective _ inj]
  have ne : S.Nonempty := Finset.card_pos.mp (by omega)
  let m := S.max' ne
  let tail := (Finset.range 5).image (fun h=>m+(h+1))
  have nt : tail.card=5 := by
    simp [tail,Finset.card_image_of_injective _ (show Function.Injective (fun h:Nat=>m+(h+1)) by
      intro a b eq; change m+(a+1)=m+(b+1) at eq; omega)]
  have apart : Disjoint S tail := by
    refine Finset.disjoint_left.mpr ?_
    intro i hi hj
    obtain ⟨k,_,rfl⟩:=Finset.mem_image.mp hj
    have le:=Finset.le_max' S _ hi
    change m+(k+1) ≤ m at le
    omega
  have cover : S∪tail ⊆ (Finset.range (w.length-1)).filter (fun i=>diff w i=d) := by
    intro i hi
    obtain old|new := Finset.mem_union.mp hi
    · obtain ⟨a,_,rfl⟩:=Finset.mem_image.mp old
      simpa using (show pos a+0∈(Finset.range (w.length-1)).filter (fun i=>diff w i=d) from
        Finset.mem_filter.mpr ⟨Finset.mem_range.mpr (span a 0).1,(span a 0).2⟩)
    · obtain ⟨k,hk,rfl⟩:=Finset.mem_image.mp new
      have top : m∈S := Finset.max'_mem _ _
      obtain ⟨a,_,eq⟩:=Finset.mem_image.mp top
      let j : Fin 6 := ⟨k+1,by have := Finset.mem_range.mp hk; omega⟩
      have b:=span a j
      rw [eq] at b
      exact Finset.mem_filter.mpr ⟨Finset.mem_range.mpr b.1,b.2⟩
  have bound:=Finset.card_le_card cover
  rw [Finset.card_union_of_disjoint apart,n,nt] at bound
  exact bound

theorem minimum {w : Block} (sub : six⊆complete w) : 73≤w.length := by
  classical
  have charge:=Finset.sum_le_sum (fun (d : Fin 7) (hd : d∈steps)=>twelve sub hd)
  have count : steps.card=6 := by decide
  rw [Finset.sum_const, count, Finset.sum_card_fiberwise_eq_card_filter] at charge
  have cap:=Finset.card_filter_le (Finset.range (w.length-1)) (fun i=>diff w i∈steps)
  simp only [Finset.card_range] at cap
  change 72 ≤ _ at charge
  omega

def witness : Block :=
  "0123456012345024613502461403625140362630415263041642053164205432106543210".toList.map
    (fun c => Fin.ofNat 7 (c.toNat-'0'.toNat))

theorem attained : witness.length=73 ∧ six⊆complete witness := by native_decide

open private add_visit complete_append from RepairFrom5899

/-- The same length suffices for any six classes. Each new class costs twelve letters. -/
theorem pack (S : Finset Block) (onBoard : S⊆allClasses) :
    ∃ w : Block, w.length=1+12*S.card ∧ S⊆complete w := by
  classical
  induction S using Finset.induction_on with
  | empty => exact ⟨[0],by simp,by simp⟩
  | @insert c S fresh ih =>
    obtain ⟨w,len,old⟩:=ih (fun x hx=>onBoard (Finset.mem_insert_of_mem hx))
    have cn:=onBoard (Finset.mem_insert_self ..)
    obtain ⟨t,cost,hit⟩:=add_visit (w:=w) (by intro eq; simp [eq] at len; omega) cn
    obtain ⟨z,sz,_,preserve,completeC⟩:=insert_class (w:=w++t) (c:=c)
      (by simp only [List.length_append]; omega) ((mem_visited _ _).mp hit)
    refine ⟨z,?_,Finset.insert_subset ((mem_complete _ _).mpr ⟨cn,completeC⟩) ?_⟩
    · rw [sz,List.length_append,len,cost,Finset.card_insert_of_notMem fresh]
      omega
    · intro x hx
      obtain ⟨board,seen⟩ := (mem_complete _ _).mp (complete_append w t (old hx))
      exact (mem_complete _ _).mpr ⟨board,fun p hp eq=>preserve p (seen p hp eq)⟩

theorem pack_six {S : Finset Block} (onBoard : S⊆allClasses) (card : S.card=6) :
    ∃w : Block,w.length=73 ∧ S⊆complete w := by
  obtain ⟨w,size,complete⟩:=pack S onBoard
  exact ⟨w,by omega,complete⟩

/-- The powers of the cycle acting in the cyclic order specified by c. -/
def powers (c : Block) : Finset Block :=
  steps.image (fun d => (List.finRange 7).map (fun i => c.getD (i*d).val 0))

def packs : Finset (Finset Block) := allClasses.image powers

theorem partition : packs.card=120 ∧ packs.biUnion id=allClasses ∧
    (∀ P∈packs,P.card=6) ∧
    (∀ P∈packs,∀ Q∈packs,P=Q ∨ Disjoint P Q) ∧ six∈packs := by native_decide

/-- A core with 42 completed classes misses at least 78 entire conjugate six-packs. -/
theorem avoided (S : Finset Block) (small : S.card≤42) :
    78 ≤ (packs.filter (fun P=>Disjoint P S)).card := by
  classical
  let H := packs.filter (fun P=>¬Disjoint P S)
  let pick (P : Finset Block) : Block := if h : (P∩S).Nonempty then h.choose else []
  have mem (P) (h : P∈H) : pick P∈P ∩ S := by
    have n := (Finset.mem_filter.mp h).2
    have e : (P∩S).Nonempty := Finset.not_disjoint_iff_nonempty_inter.mp n
    simpa [pick,e] using e.choose_spec
  have inject : H.card ≤ S.card := Finset.card_le_card_of_injOn pick
    (fun P h => (Finset.mem_inter.mp (mem P h)).2) (by
      intro P hP Q hQ coincide
      have a := (Finset.mem_inter.mp (mem P hP)).1
      have b := (Finset.mem_inter.mp (mem Q hQ)).1
      obtain eq|apart := partition.2.2.2.1 P (Finset.mem_filter.mp hP).1 Q (Finset.mem_filter.mp hQ).1
      · exact eq
      · exact False.elim (Finset.disjoint_left.mp apart a (coincide ▸ b)))
  have diff : packs \ H = packs.filter (fun P => Disjoint P S) := by
    ext P
    simp [H]
    tauto
  have n := Finset.card_sdiff_of_subset (Finset.filter_subset (fun P=>¬Disjoint P S) packs)
  change (packs \ H).card=packs.card-H.card at n
  rw [diff,partition.1] at n
  omega

#print axioms partition
#print axioms avoided
#print axioms pack_six
#print axioms minimum
#print axioms attained

end ExactWordFlow.SixGeometry

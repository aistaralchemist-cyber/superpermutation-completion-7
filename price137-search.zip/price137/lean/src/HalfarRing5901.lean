import LowerBounds.J16RX
import RingSearchResult

/-!
# The exact ring search for defect sixteen

This runs Halfar's original predicate on all sixteen residue classes. No
precomputed Boolean or prefix count is used in the proof.
-/

namespace ExactWordFlow.Core1224
open SuperpermLowerBounds SuperpermLowerBounds.T5900

theorem ring_rows_exact : ringRows = J16.RXtab := rfl

theorem rx_field : J16.EvRX := by
  refine ⟨400, 13, 16, by decide, ?_⟩
  intro tp ht
  exact ⟨0, 16, Nat.zero_le _, ht, ring_rows_exact ▸ rx63_all⟩

theorem rx_of_table (table : KS.TableT) : J16.RX :=
  J16.rx_of_search table rx_field

#print axioms rx63_all
#print axioms rx_field
#print axioms rx_of_table
end ExactWordFlow.Core1224

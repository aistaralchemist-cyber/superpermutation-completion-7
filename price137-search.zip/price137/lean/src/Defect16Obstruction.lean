import RotationCore
import LowerBounds.A16Final
import LowerBounds.PFinalK16Native
import RingSeedBound

/-! Extract a standard configuration directly from a hypothetical short partial word.
The configuration exclusion below uses only statements about sequences and rings. -/
namespace ExactWordFlow.Defect16Obstruction
open SevenWordWindows RotationCore SuperpermutationBounds
open SuperpermLowerBounds SuperpermLowerBounds.T5899 Hunter PreimageChain

private theorem caps : Caps :=
  caps_of_k16 (by decide) (by decide) (by decide) (by decide) (by decide)
    (by decide) (by decide)
    (PS.covered_one K16.f0k) (PS.covered_one K16.f1k) (PS.covered_one K16.f2k)
    (PS.covered_one K16.f3k) (PS.covered_one K16.f4k) (PS.covered_one K16.f5k)
    (PS.covered_one PS.ring)

private theorem profiles : Profiles :=
  profiles_of_k16 (by decide) (by decide) (by decide) (by decide) (by decide)
    (by decide) (PS.covered_one K16.f0k)
    (PS.covered_one PS.prof36) (PS.covered_one PS.prof26) (PS.covered_one PS.prof34)
    (PS.covered_one PS.prof14) (PS.covered_one PS.prof4)

theorem configuration (v : Block) (n : v.length = 1196)
    (vis : (visited v).card = 720) (done : (complete v).card = 48) :
    ∃ c : NConfig 7, c.Valid ∧ 135 ≤ c.cost ∧ c.cost ≤ 136 ∧
      40 ≤ valR c.kernel (rX c.kernel) + (c.hanging.map vH).sum ∧
      wtR c.kernel (rX c.kernel) + (c.hanging.map wH).sum ≤ 96 ∧
      epsC c ≤ 2 ∧ (famC c).length ≤ 11 := by
  obtain ⟨w, hw, size⟩ := expand_remaining (v := v) (by omega) vis
  obtain ⟨c, hv, hc⟩ := exists_stdConfig_of_covers (by decide : 5 ≤ 7) hw
  have cost : c.cost ≤ 136 := by
    rw [n, done] at size
    change 5884 + c.cost ≤ 120 + w.length at hc
    omega
  have lower := no_config_134 caps profiles c hv
  exact ⟨c, hv, by omega, cost, A16.acc_value hv cost, A16.acc_weight hv cost,
    A16.eps_le_two caps profiles hv cost, A16.famC_length_le caps hv cost⟩

open T5900 T5901

/-- Exactly the middle six entries of the previous ring row, in the form x+31. -/
def middleRing : Prop := ∀ L : List PS.TRow, KS.IsPiece .ring L →
  64 ≤ PS.holesT 7 L → PS.holesT 7 L ≤ 69 → L.length ≤ PS.holesT 7 L + 31

private theorem rows : ∀ s : Fin 9, ∀ x : Fin 97, x.val < KS.Tlen.getD s.val 0 →
    x.val < 97-6*s.val ∧ PS.capF D16tab s.val x.val ≤ PS.capF Ttab s.val x.val := by
  native_decide

private theorem lengths : ∀ s : Fin 9, KS.Tlen.getD s.val 0 ≤ 97 := by native_decide

private theorem lowRing : ∀ x : Fin 64, J16.RXtab.getD x.val 0 ≤ TRtab.getD x.val 0 := by
  native_decide

private theorem midRing : ∀ x : Fin 70, 64 ≤ x.val → x.val+31 ≤ TRtab.getD x.val 0 := by
  native_decide

private theorem highRing : ∀ x : Fin 85, 70 ≤ x.val → PS.capF D16tab 0 x.val ≤ TRtab.getD x.val 0 := by
  native_decide

/-- K16 and the already checked RX row cover every entry of the inherited Table T
except six consecutive ring entries. -/
theorem table_from_six (hK : K16.TheoremK16) (middle : middleRing) : KS.TableT := by
  constructor
  · intro s hs L hL clean links small
    let j : Fin 9 := ⟨s, by omega⟩
    have bound := lengths j
    change KS.Tlen.getD s 0 ≤ 97 at bound
    let x : Fin 97 := ⟨PS.holesT 7 L, by omega⟩
    have ⟨safe,cmp⟩ := rows j x small
    exact (hK s (by omega) L hL clean links safe).trans cmp
  · intro L hL clean size closes h84
    let x := PS.holesT 7 L
    by_cases small : x < 64
    · exact (Core1224.rx_unconditional L hL clean size closes (by omega)).trans
        (lowRing ⟨x, small⟩)
    by_cases mid : x < 70
    · exact (middle L ⟨hL, clean, size, closes⟩ (by omega) (by omega)).trans
        (midRing ⟨x, mid⟩ (by change 64 ≤ x; omega))
    have bound := hK 0 (by decide) L hL (fun p hp => by rw [clean p hp]; decide)
      (PS.linksT_zero clean) (by omega)
    exact bound.trans (highRing ⟨x, by omega⟩ (by change 70 ≤ x; omega))

/-- Halfar's component assertions enter here as geometric propositions. -/
theorem exclude_from_parts (hK : K16.TheoremK16) (middle : middleRing) (joint : K16.Joint16) :
    ¬ ∃ v : Block, v.length = 1196 ∧ (visited v).card = 720 ∧ (complete v).card = 48 := by
  rintro ⟨v, n, vis, done⟩
  obtain ⟨c, hv, _, hc, _⟩ := configuration v n vis done
  exact A16.no_config_136 caps profiles (table_from_six hK middle) hK joint c hv hc

#print axioms configuration
#print axioms table_from_six
#print axioms exclude_from_parts
end ExactWordFlow.Defect16Obstruction

import Ring854
import LongCyclePrice105
import ShortWheelPeriod

namespace ExactWordFlow.FiveLong854
open SevenWordWindows DirectedEuler ResidualDensity ResidualRoutes RotationComponentCount ResidualIncidence
open scoped Classical
open private hits Cost totals rank_partition from NearHundredShape
open private closeCap cyclic_price from Cap93Mass
open private lump from GlobalClosedPrice

def fee (e c : Nat) : Nat := 3+(if 6<e then 22 else 0)+
  (if 6<e ∧ ¬(e=35 ∧ c=30) then 12 else 0)

private def cuts (e c : Nat) : Prop :=
  (105≤e → 71*c≤60*e) ∧ (e=14 → c<12) ∧ (e=21 → c<18) ∧ (e=28 → c<24) ∧
  (e=27 → c<23) ∧ (e=34 → c<29) ∧ (e=40 → c<34) ∧ (e=53 → c<45) ∧ (e=60 → c<51)
instance (e c : Nat) : Decidable (cuts e c) := by unfold cuts; infer_instance

private theorem prices : ∀e c : Fin 214, 6≤e.val → c.val≤closeCap e.val → cuts e.val c.val →
    45*(c.val-1)+fee e.val c.val≤38*e.val := by native_decide

private theorem route {s : Block} {es : List Block} (r : Route src dst s es s)
    (wd : ∀e∈es,e.length=7) (lo:6≤es.length) (c : Nat) (hc:c≤classCount s es) :
    45*(c-1)+fee es.length c ≤ 38*es.length := by
  have coarse:=hc.trans (cyclic_price r wd lo)
  by_cases big:214≤es.length
  · have a : ¬es.length≤6:=by omega
    have b : ¬es.length<40:=by omega
    have d : ¬es.length<65:=by omega
    have z : ¬es.length<214:=by omega
    simp [closeCap,a,b,d,z] at coarse
    have f : fee es.length c=37:=by simp [fee,show 6<es.length by omega,show es.length≠35 by omega]
    rw [f]; omega
  have tab : ∀e : Fin 214, closeCap e.val<214 := by native_decide
  have tiny : c<214 := lt_of_le_of_lt coarse (tab ⟨es.length,by omega⟩)
  have far (hh:105≤es.length):71*c≤60*es.length:=by
    have h:=LongCyclePrice105.closed_route r wd hh
    omega
  have high (d : Nat) (he:es.length=7*(d+1)) (hm:13≤es.length) (bound:6*(d+1)<30)
       (upper:classCount s es≤6*(d+1)) : c<6*(d+1) := by
    by_contra! fail
    have same:classCount s es=6*(d+1):=by omega
    have contra:=ShortWheelPeriod.lower r wd he hm same
    omega
  have special (a b : Nat) (hm:(a,b)∈Ring854.sizes) (eq:es.length=a) : c<b :=
    lt_of_le_of_lt hc (Ring854.route r wd eq hm)
  have cert : cuts es.length c := by
    refine ⟨far,?_,?_,?_,special 27 23 (by decide),special 34 29 (by decide),
      special 40 34 (by decide),special 53 45 (by decide),special 60 51 (by decide)⟩
    · intro eq
      have z:=cyclic_price r wd lo
      rw [eq,show closeCap 14=12 by decide] at z
      exact high 1 (by omega) (by omega) (by decide) z
    · intro eq
      have z:=cyclic_price r wd lo
      rw [eq,show closeCap 21=18 by decide] at z
      exact high 2 (by omega) (by omega) (by decide) z
    · intro eq
      have z:=cyclic_price r wd lo
      rw [eq,show closeCap 28=24 by decide] at z
      exact high 3 (by omega) (by omega) (by decide) z
  exact prices ⟨es.length,by omega⟩ ⟨c,tiny⟩ lo coarse cert

theorem budget {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤854) :
    let Q:=occupied X s
    3*Q.card+22*(Q.filter (fun q=>6<Cost X q)).card+
      12*(Q.filter (fun q=>6<Cost X q ∧ ¬(Cost X q=35 ∧ hits X s q=30))).card≤156 := by
  classical
  let Q:=occupied X s
  let home:=label X s
  have pay (q) (hq:q∈Q) : 45*(hits X s q-1)+fee (Cost X q) (hits X s q)≤38*Cost X q := by
    have active:q∈active X s:=occupied_active h ▸ hq
    have size:6≤Cost X q:=(Finset.mem_filter.mp active).2.2
    have away:q≠home:=(Finset.mem_erase.mp hq).1
    obtain ⟨v,_,eq⟩:=residual_clean h away (show 0<Cost X q by omega)
    obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance v
    rw [eq] at bag lv ends
    obtain ⟨aa,bb⟩:=ends.2 away
    subst a; subst b
    have len:es.length=Cost X q:=congrArg Multiset.card bag
    have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
    have bound:=route r wd (by omega) (hits X s q) (contacts_bound (support X s) lv r bag)
    rwa [len] at bound
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have op:=WeightedMarks.path_cap r wd
  have hit:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  have root : 45*(hits X s home-1)≤38*Cost X home+59:=by omega
  have rank:=rank_partition h
  change separateRank X s=hits X s home-1 + ∑q∈Q,(hits X s q-1) at rank
  have sum:=Finset.sum_le_sum pay
  simp only [Finset.sum_add_distrib,←Finset.mul_sum] at sum
  have total:=(totals h).1
  change Cost X home+6*Q.card+(∑q∈Q,(Cost X q-6))=X.card at total
  have split:(∑q∈Q,Cost X q)= 6*Q.card+∑q∈Q,(Cost X q-6) := by
    calc
      _ = ∑q∈Q,(6+(Cost X q-6)) := by
        apply Finset.sum_congr rfl
        intro q hq
        have active:q∈active X s:=occupied_active h ▸ hq
        have size:6≤Cost X q:=(Finset.mem_filter.mp active).2.2
        omega
      _ = _ :=by simp [Finset.sum_add_distrib,Nat.mul_comm]
  have connected : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  have f : (∑q∈Q,fee (Cost X q) (hits X s q))≤156:=by omega
  simp only [fee,Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,lump] at f
  simpa only [Nat.mul_comm 3] using f

theorem five_force_three {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤854)
    (five : ((occupied X s).filter (fun q=>6<Cost X q)).card=5) :
    3≤((occupied X s).filter (fun q=>Cost X q=35 ∧ hits X s q=30)).card := by
  classical
  let Q:=occupied X s
  let sharp:Component X→Prop:=fun q=>Cost X q=35 ∧ hits X s q=30
  let long:Component X→Prop:=fun q=>6<Cost X q
  have count : (Q.filter long).card=5:=five
  have sub:=Finset.card_filter_le (s:=Q) (p:=long)
  have b:=budget h bd
  change 3*Q.card+22*(Q.filter long).card+12*(Q.filter (fun q=>long q ∧ ¬sharp q)).card≤156 at b
  have s1:(Q.filter long).filter sharp=Q.filter sharp:=by
    ext i
    simp only [Finset.mem_filter]
    constructor
    · rintro ⟨⟨hi,_⟩,hs⟩; exact ⟨hi,hs⟩
    · rintro ⟨hi,hs⟩
      have eq:Cost X i=35:=hs.1
      exact ⟨⟨hi,by change 6<Cost X i; omega⟩,hs⟩
  have s2:(Q.filter long).filter (fun q=>¬sharp q)=Q.filter (fun q=>long q ∧ ¬sharp q):=by ext; simp [and_assoc]
  have eq:=Finset.card_filter_add_card_filter_not (s:=Q.filter long) sharp
  rw [s1,s2] at eq
  change 3≤(Q.filter sharp).card
  omega

#print axioms five_force_three
end ExactWordFlow.FiveLong854

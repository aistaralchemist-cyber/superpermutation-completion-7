import Core1224
import CanonicalBaseSpare
import SixPhase
import RequiredComponent
import LapSkeleton

namespace ExactWordFlow.SixFlow
open SevenWordWindows SuperpermutationBounds DirectedEuler ResidualDensity ResidualRoutes RotationReinsert
open private join split_at from LapSkeleton
private theorem required_size : required.card=5040 := by
  simp [required,representatives,List.length_permutations]
  decide

private theorem nil_ends {u v : Block} (r : Route src dst u [] v) : u=v := by cases r; rfl

private theorem perm_info : ∀e∈representatives, full (src e) ∧ full (dst e) ∧ src e≠dst e := by
  native_decide

private theorem rotate_edge {s e : Block} {es : List Block} (r : Route src dst s es s) (he : e∈es) :
    ∃rest : List Block, (↑es : Multiset Block)=e ::ₘ ↑rest ∧ Route src dst (dst e) rest (src e) := by
  obtain ⟨l,t,rfl⟩ := List.append_of_mem he
  obtain ⟨v,left,right⟩ := split_at l (e::t) r
  cases right with
  | cons e eq suffix =>
    exact ⟨t++l,Multiset.coe_eq_coe.mpr (List.perm_append_comm (l₁:=l) (l₂:=e::t)),eq ▸ join suffix left⟩

private theorem whole_width {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (e : Block) (he : e∈required+X) : e.length=7 := by
  rcases Multiset.mem_add.mp he with req|ex
  · exact ((mem_reps _).mp req).1
  · exact h.edges_seven _ ex

/-- Deleting the two windows incident to a dirty six-state of a closed covering
walk leaves a word of length 5,898 with every required seven-symbol factor. -/
theorem closed_clean {X : Multiset Block} {s : Block} (h : Feasible X s s) (size : X.card=854) :
    ∀e∈X, full (src e) ∧ full (dst e) := by
  classical
  have xbal : X.map src=X.map dst := add_right_cancel h.balance
  have bal : (required+X).map src+{s}=(required+X).map dst+{s} := by
    simp only [Multiset.map_add,show required.map src=required.map dst from balanced_representatives,xbal]
  obtain ⟨es,byBag,tour⟩ := exists_route src dst (required+X) s s bal h.reachable
  have allDest (e : Block) (he : e∈required+X) : full (dst e) := by
    by_contra dirty
    obtain ⟨rest,cycle,route⟩ := rotate_edge tour (show e∈es from (show e∈(↑es : Multiset Block) by rw [byBag]; exact he))
    have eq := byBag.symm.trans cycle
    cases rest with
    | nil =>
      have count := congrArg Multiset.card eq
      simp [required_size,size] at count
    | cons f tail =>
      cases route with
      | cons f meet back =>
        have ef : e∉required := fun hp => dirty (perm_info _ hp).2.1
        have ff : f∉required := fun hp => dirty (meet ▸ (perm_info _ hp).1)
        have occurs (g : Block) (hg : g∈tail) : g∈required+X := by
          rw [eq]; simp [hg]
        have fw : f.length=7 := whole_width h _ (by rw [eq]; simp)
        obtain ⟨w,len,_,wins⟩ := spell_route back (by simp [dst,fw]) (fun g hg=>whole_width h _ (occurs g hg))
        have cover : Covers w := by
          intro p lp nd
          have req : p∈required := (mem_reps p).mpr ⟨lp,nd⟩
          have live : p∈required+X := Multiset.mem_add.mpr (Or.inl req)
          rw [eq] at live
          have pt : p∈tail := by
            simp only [Multiset.mem_cons,Multiset.mem_coe,List.mem_cons] at live
            exact (live.resolve_left (by rintro rfl; exact ef req)).resolve_left (by rintro rfl; exact ff req)
          exact window_occurs _ (wins ▸ pt)
        have count := congrArg Multiset.card eq
        simp [required_size,size] at count
        have floor := SuperpermLowerBounds.covers_lower_bound_7_k16_native w cover
        omega
  intro e he
  have dstclean := allDest e (Multiset.mem_add.mpr (Or.inr he))
  have live : src e ∈ X.map dst := xbal ▸ Multiset.mem_map_of_mem src he
  obtain ⟨f,hf,eq⟩ := Multiset.mem_map.mp live
  exact ⟨eq ▸ allDest f (Multiset.mem_add.mpr (Or.inr hf)),dstclean⟩

private theorem size_floor {A : Multiset Block} {a b : Block}
    (width : ∀g∈A,g.length=7) (bal : A.map src+{b}=A.map dst+{a})
    (together : RequiredComponent.RequiredTogether A) : 853 ≤ A.card := by
  obtain ⟨Y,sub,s,t,good⟩ := RequiredComponent.feasible_submultiset width bal together
  obtain ⟨w,cover,len⟩ := (word_iff_flow (Y.card+5046) (by omega)).mpr ⟨Y,s,t,by omega,good⟩
  have floor := SuperpermLowerBounds.covers_lower_bound_7_k16_native w cover
  have lim := Multiset.card_le_card sub
  omega

private theorem labels_on_route {Y : Multiset Block} {u v : Block} {es : List Block}
    (r : Route src dst u es v) (mem : ∀ g∈es,g∈Y) : label Y u=label Y v := by
  induction r with
  | nil => rfl
  | cons e call _ ih =>
    rw [←call]
    exact (on_edge (mem _ (List.mem_cons_self ..))).trans (ih (fun g hg=>mem _ (List.mem_cons_of_mem _ hg)))

/-- If a surplus edge is itself mandatory, its closed residual circuit supplies
a second edge that can be removed. The first edge is still represented, and the
rest of that circuit keeps the far endpoint in the same component. -/
theorem closed_no_extra_permutation {X : Multiset Block} {s : Block}
    (h : Feasible X s s) (size : X.card=854) : ∀e∈X,e∉representatives := by
  classical
  intro e he req
  have xbal : X.map src=X.map dst := add_right_cancel h.balance
  have relaxed := congrArg (fun Y : Multiset Block=>Y+{src e}) xbal
  obtain ⟨a,b,es,bagEq,walk,_,ends⟩ := component_route relaxed (src e)
  obtain ⟨aa,bb⟩ := ends.1 rfl
  subst a; subst b
  have localEdge := in_part.mpr (And.intro he (Eq.refl (label X (src e))))
  obtain ⟨rest,turn,route⟩ := rotate_edge walk (show e∈es from (show e∈(↑es : Multiset Block) by rw [bagEq]; exact localEdge))
  have decomp := bagEq.symm.trans turn
  cases rest with
  | nil =>
    exact (perm_info _ req).2.2 (nil_ends route).symm
  | cons f tail =>
    cases route with
    | cons f meet back =>
      obtain ⟨Z,zEq⟩ := exists_add_of_le (Multiset.filter_le (fun g=>label X (src g)=label X (src e)) X)
      change X=part X (label X (src e))+Z at zEq
      let A : Multiset Block := ↑tail+Z
      have split : X=e ::ₘ f ::ₘ A := by
        rw [zEq,decomp]; change (e ::ₘ f ::ₘ ↑tail)+Z=e ::ₘ f ::ₘ (↑tail+Z); rw [Multiset.cons_add,Multiset.cons_add]
      have aw (g : Block) (hg:g∈A) : g.length=7 := h.edges_seven _ (by rw [split]; simp [hg])
      have bal : A.map src + {src e}=A.map dst + {dst f} := by
        rw [split] at xbal
        ext v
        have atv := congrArg (Multiset.count v) xbal
        simp only [Multiset.map_cons,Multiset.count_cons,Multiset.count_add,Multiset.count_singleton,meet] at *
        omega
      let G := required+A
      have edgeIn : e∈G := Multiset.mem_add.mpr (Or.inl req)
      have home := on_edge edgeIn
      have across : label G (dst f) = label G (src e) := labels_on_route back (fun g hg=>
        Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inl hg))))
      have next : label G (src f)=label G (dst f) := meet ▸ home.symm.trans across.symm
      have all (g) (hg : g∈required+X) : label G (src g)=label G (dst g) := by
        rcases Multiset.mem_add.mp hg with needed|extra
        · exact on_edge (Multiset.mem_add.mpr (Or.inl needed))
        · rw [split] at extra
          rcases Multiset.mem_cons.mp extra with rfl|extra
          · exact home
          rcases Multiset.mem_cons.mp extra with rfl|kept
          · exact next
          · exact on_edge (Multiset.mem_add.mpr (Or.inr kept))
      let S : Set Block := {v | label G v=label G s}
      have rooted := h.reachable S (by rfl) (fun g hg (hs : label G (src g)=_) => (all g hg).symm.trans hs)
      have together : RequiredComponent.RequiredTogether A := fun p hp q hq =>
        (rooted p (Multiset.mem_add.mpr (Or.inl hp))).trans (rooted q (Multiset.mem_add.mpr (Or.inl hq))).symm
      have lim := size_floor aw bal together
      rw [split] at size
      simp at size
      omega

/-- A balanced surplus of 854 cannot realize a seven-symbol covering word. -/
theorem no_balanced_854 {X : Multiset Block} {s : Block} (size : X.card=854) :
    ¬ Feasible X s s := by
  intro h
  have clean := closed_clean h size
  have exclusions := closed_no_extra_permutation h size
  have div := SixPhase.six_dvd_of_nonperm_clean_balanced (add_right_cancel h.balance)
    (fun e he => ⟨h.edges_seven e he,(clean e he).1,(clean e he).2,exclusions e he⟩)
  rw [size] at div
  omega

theorem candidate_distinct_ends {w : Block} (size : w.length=1196)
    (vis : (RotationCore.visited w).card=720) (done : (RotationCore.complete w).card=48) :
    w.take 6 ≠ w.drop (w.length-6) := by
  intro same
  obtain ⟨ws,_,num,_,flow,mass⟩ := WheelBaseResidual.actual_spare (LiteralWheelCover.Inserts.stop w) vis (by omega)
  have noWheels : ws=[] := List.length_eq_zero_iff.mp (by simpa using num)
  simp only [noWheels,EmbeddedWheels.turns,List.flatMap_nil,Multiset.coe_nil,add_zero] at flow mass
  rw [←same] at flow
  exact no_balanced_854 (by omega) flow

/-- At length 5,899 a single excised copy from the surplus would already cross the floor. -/
private theorem no_balanced_853 {X : Multiset Block} {s : Block} (size : X.card=853) :
    ¬ Feasible X s s := by
  classical
  intro h
  have xbal : X.map src=X.map dst := add_right_cancel h.balance
  have bal : (required+X).map src+{s}=(required+X).map dst+{s} := by
    simp only [Multiset.map_add,show required.map src=required.map dst from balanced_representatives,xbal]
  obtain ⟨es,byBag,tour⟩ := exists_route src dst (required+X) s s bal h.reachable
  obtain ⟨e,he⟩ := Multiset.card_pos_iff_exists_mem.mp (show 0<X.card by omega)
  have inList : e∈es := (show e∈(↑es : Multiset Block) by rw [byBag]; exact Multiset.mem_add.mpr (Or.inr he))
  obtain ⟨tail,cycle,route⟩ := rotate_edge tour inList
  have eq := byBag.symm.trans cycle
  have drop : required+X.erase e = ↑tail := by
    have cut := congrArg (fun M : Multiset Block=>M.erase e) eq
    have split : required+X=e ::ₘ (required+X.erase e) := by rw [←Multiset.add_cons,Multiset.cons_erase he]
    rw [split] at cut
    simpa using cut
  obtain ⟨w,len,_,wins⟩ := spell_route route (by simp [dst,h.edges_seven _ he]) (by
    intro g hg
    apply whole_width h
    rw [eq]; exact Multiset.mem_cons_of_mem (show g∈(↑tail : Multiset Block) from hg))
  have cover : Covers w := by
    intro p lp nd
    have original : p∈required := (mem_reps p).mpr ⟨lp,nd⟩
    have live : p∈(↑tail : Multiset Block) := drop ▸ Multiset.mem_add.mpr (Or.inl original)
    exact window_occurs _ (wins ▸ (show p∈tail from live))
  have count := congrArg Multiset.card eq
  simp [required_size,size] at count
  have floor := SuperpermLowerBounds.covers_lower_bound_7_k16_native w cover
  omega

/-- Equal initial and final six-letter states force length at least 5,901. -/
theorem closed_covering_floor {w : Block} (cover : Covers w)
    (same : w.take 6=w.drop (w.length-6)) : 5901≤w.length := by
  have floor := SuperpermLowerBounds.covers_lower_bound_7_k16_native w cover
  obtain ⟨X,size,h⟩ := extract_at_ends w cover (by omega)
  rw [←same] at h
  by_contra! short
  rcases (show X.card=853 ∨ X.card=854 by omega) with a|b
  · exact no_balanced_853 a h
  · exact no_balanced_854 b h

#print axioms closed_covering_floor
#print axioms candidate_distinct_ends
#print axioms no_balanced_854
#print axioms closed_clean
#print axioms closed_no_extra_permutation
end ExactWordFlow.SixFlow

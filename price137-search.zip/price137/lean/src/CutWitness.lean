import WheelPartition
import SplitFrontier

namespace SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain T5899

/-- A purely geometric necessary condition at a specified number of trails.
It mentions no word, cost, original number of trails or attachment forest. -/
def CutCase (M : Nat) : Prop :=
  ∃ (G : List (List (NRow 7))) (ps : List WheelPacket),
    TrailFam 7 G ∧ G.length = M ∧
    (let U := rowsEntries G.flatten ++ ps.flatMap WheelPacket.cells
     U.length = 720 ∧ U.Pairwise (NotRot (k:=7)) ∧
       ∀ v : Vtx 7, ∃ x ∈ U, (v : List ℕ) ~r (x : List ℕ)) ∧
    rowsHoles 7 G.flatten + 6*M ≤ 126 ∧
    (ps.map packetDef).sum + 15 + 5*M ≤
      (G.flatten.length : ℤ) - (rowsHoles 7 G.flatten : ℤ)

theorem cut_case_of_config (c : NConfig 7) (hv : c.Valid) (hc : c.cost ≤ 140) :
    CutCase ((famC c).length + epsC c) := by
  have valid := famC_trailFam hv
  obtain ⟨lo,hi⟩ := costs c hv (j:=3) hc
  rw [lE_prs] at lo
  rw [lW_prs] at hi
  let link := fun a b : NRow 7 => SLink 7 3 a.lastEntry b.entry
  have good : Seventeen.Good link (famC c) := fun T hT =>
    ⟨(valid.trails T hT).ne, (valid.trails T hT).seams⟩
  obtain ⟨G,whole,same,size⟩ := Seventeen.cuts good (epsC c) (by omega)
  have family : TrailFam 7 G := by
    constructor
    · intro T hT
      obtain ⟨ne,links⟩ := whole T hT
      refine ⟨ne,?_,links⟩
      intro row mem
      have member : row ∈ G.flatten := List.mem_flatten.mpr ⟨T,hT,mem⟩
      rw [same] at member
      obtain ⟨old,inF,inOld⟩ := List.mem_flatten.mp member
      exact (valid.trails old inF).len row inOld
    · rw [same]
      exact valid.classes
  obtain ⟨p,part,slack⟩ := omitted_partition c hv (j:=3) hc
  rw [lE_prs] at slack
  refine ⟨G,p,family,size,?_,?_,?_⟩
  · dsimp only
    rw [same]
    constructor
    · exact part.length_eq.trans (exact_entries c hv)
    constructor
    · exact pairwise_of_perm hv.distinct part
    · intro v
      obtain ⟨x,mem,rot⟩ := hv.cover v
      exact ⟨x,part.mem_iff.mpr mem,rot⟩
  · rw [same]
    omega
  · rw [same]
    push_cast
    omega

private theorem source_for_cuts (cap : ChainCap Mf 84) (profiles : Profiles)
    (w : List (Fin 7)) (hw : SuperpermutationBounds.Covers w) (len : w.length ≤ 5904) :
    ∃ c : NConfig 7, c.Valid ∧ c.cost ≤ 140 ∧ 1 ≤ (famC c).length ∧
      6*(famC c).length + 11*epsC c ≤ 111 ∧ CutCase ((famC c).length + epsC c) := by
  obtain ⟨c,hv,hc,_,_,_,ineq⟩ := word_5904 cap profiles w hw len
  refine ⟨c,hv,hc,?_,ineq,cut_case_of_config c hv hc⟩
  have nonempty := (kernel_ok hv).pos
  unfold famC
  rw [List.length_append]
  omega

/-- Without a new finite endpoint computation, 18 geometric tests suffice. -/
theorem word_to_eighteen (cap : ChainCap Mf 84) (profiles : Profiles)
    (w : List (Fin 7)) (hw : SuperpermutationBounds.Covers w) (len : w.length ≤ 5904) :
    ∃ M : Nat, 1 ≤ M ∧ M ≤ 18 ∧ CutCase M := by
  obtain ⟨c,_,_,pos,m,geom⟩ := source_for_cuts cap profiles w hw len
  exact ⟨_,by omega,by omega,geom⟩

/-- A single exclusion at e=0,m=18 suffices to lower 18 tests to 17. -/
theorem word_to_seventeen (cap : ChainCap Mf 84) (profiles : Profiles)
    (end18 : ∀ c : NConfig 7, c.Valid → c.cost ≤ 140 → epsC c = 0 → (famC c).length ≠ 18)
    (w : List (Fin 7)) (hw : SuperpermutationBounds.Covers w) (len : w.length ≤ 5904) :
    ∃ M : Nat, 1 ≤ M ∧ M ≤ 17 ∧ CutCase M := by
  obtain ⟨c,hv,hc,pos,m,geom⟩ := source_for_cuts cap profiles w hw len
  have last := end18 c hv hc
  exact ⟨_,by omega,by omega,geom⟩

/-- Discharging each geometric case would yield the genuine length bound. -/
theorem lower_of_seventeen (cap : ChainCap Mf 84) (profiles : Profiles)
    (end18 : ∀ c : NConfig 7, c.Valid → c.cost ≤ 140 → epsC c = 0 → (famC c).length ≠ 18)
    (cases : ∀ M : Nat, 1 ≤ M → M ≤ 17 → ¬ CutCase M)
    (w : List (Fin 7)) (hw : SuperpermutationBounds.Covers w) : 5905 ≤ w.length := by
  by_contra! short
  obtain ⟨M,lo,hi,test⟩ := word_to_seventeen cap profiles end18 w hw (by omega)
  exact cases M lo hi test

end SuperpermLowerBounds.LengthBudget
#print axioms SuperpermLowerBounds.LengthBudget.word_to_eighteen
#print axioms SuperpermLowerBounds.LengthBudget.word_to_seventeen
#print axioms SuperpermLowerBounds.LengthBudget.lower_of_seventeen

import WordFlow
import ResidualDensity

namespace ExactWordFlow.SixPhase
open SevenWordWindows ResidualDensity

/-- Position of the least letter, read backwards around a six-letter state. -/
private def phase (s : Block) : ZMod 6 := -(s.idxOf (s.min?.getD 0) : ZMod 6)

private theorem phase_table : ∀ s∈states, ∀ a : Fin 7, full (dst (s++[a])) →
    ¬(s++[a]).Nodup → phase (dst (s++[a])) = phase s + 1 := by
  native_decide

private theorem phase_step {e : Block} (wide : e.length=7) (fs : full (src e))
    (fd : full (dst e)) (bad : e∉representatives) : phase (dst e)=phase (src e)+1 := by
  have nn : e ≠ [] := by intro h; simp [h] at wide
  have form : src e++[e.getLast nn]=e := by
    simpa [src,List.dropLast_eq_take,wide] using List.dropLast_append_getLast nn
  have h := phase_table (src e) (mem_states fs) (e.getLast nn)
  rw [form] at h
  exact h fd (fun nd => bad ((mem_reps _).mpr ⟨wide,nd⟩))

private theorem sum_steps (Y : Multiset Block)
    (inc : ∀e∈Y, phase (dst e)=phase (src e)+1) :
    (Y.map (phase ∘ dst)).sum = (Y.map (phase ∘ src)).sum + (Y.card : ZMod 6) := by
  induction Y using Multiset.induction_on with
  | empty => simp
  | cons e Y ih =>
    have arc := inc e (Multiset.mem_cons_self e Y)
    have rest := ih (fun t h => inc t (Multiset.mem_cons_of_mem h))
    simp only [Multiset.map_cons,Multiset.sum_cons,Multiset.card_cons,Nat.cast_add,Nat.cast_one,
      Function.comp_apply]
    simp only [Function.comp_def] at rest
    rw [arc,rest]
    ring

/-- Every balanced multiset of clean, nonpermutation edges contains a multiple of six edges. -/
theorem six_dvd_of_nonperm_clean_balanced {X : Multiset Block} (bal : X.map src = X.map dst)
    (step : ∀e∈X, e.length=7 ∧ full (src e) ∧ full (dst e) ∧ e∉representatives) : 6 ∣ X.card := by
  have inc (e) (he : e∈X) := phase_step (step e he).1 (step e he).2.1
    (step e he).2.2.1 (step e he).2.2.2
  have totals := sum_steps X inc
  have same := congrArg (fun a : Multiset Block => (a.map phase).sum) bal
  simp only [Multiset.map_map] at same
  rw [←same] at totals
  have z : (X.card : ZMod 6)=0 := by
    simpa only [add_eq_left] using totals.symm
  exact (ZMod.natCast_eq_zero_iff _ _).mp z

#print axioms six_dvd_of_nonperm_clean_balanced
end ExactWordFlow.SixPhase

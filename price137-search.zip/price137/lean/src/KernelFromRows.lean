import Defect16Obstruction
import LowerBounds.K16Final
import LowerBounds.KFinal

/-! Reassemble the kernel table in increasing link count. The only changes to
the accepted five-link seed needed from earlier searches are five chain entries. -/
namespace ExactWordFlow.Defect16Obstruction
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.T5900
open SuperpermLowerBounds.T5901 PS

private def limit (s : Nat) := [65,55,51,48,41,37,37,35,35,35,35].getD s 0

private def dataRow : Nat → List (List Nat)
  | 5 => Utab5 | 6 => Utab6 | 7 => Utab7 | 8 => Utab8 | 9 => Utab9 | 10 => Utab10
  | _ => D16tab

private theorem row_rule (kernel : K16.Kernel16) (s : Nat) (hs : s ≤ 10) :
    K16.FRow (dataRow s) s (limit s) (96-6*s) := by
  obtain ⟨k0,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10⟩ := kernel
  interval_cases s
  · exact k0
  · exact k1
  · exact k2
  · exact k3
  · exact k4
  · exact k5
  · exact k6
  · exact k7
  · exact k8
  · exact k9
  · exact k10

private theorem numeric : ∀ s : Fin 11, limit s.val ≤ 96-6*s.val ∧
    ∀ j : Fin 11, ∀ x : Fin 97, j.val ≤ s.val → x.val ≤ 96-6*s.val →
    capF D16tab j.val x.val ≤ capF (dataRow s.val) j.val x.val ∧
      (j=s → capF (dataRow s.val) j.val x.val ≤ capF D16tab j.val x.val) := by native_decide

private theorem convolution : ∀ t : Fin 10, 5 ≤ t.val → ∀ x : Fin 97, x.val ≤ limit (t.val+1) →
    ∀ d : Fin 97, d.val ≤ x.val →
      capF D16tab 0 d.val + capF D16tab t.val (x.val-d.val) ≤ capF D16tab (t.val+1) x.val := by
  native_decide

private theorem seed_start {s : Nat} (hs : s ≤ 5) (hp : 1 ≤ s) (seed : KS.SetB) :
    SeqCapLt 7 s (capF D16tab s) (limit s+1) := by
  obtain ⟨_,b1,b2,b3,b4,b5,_⟩ := seed
  interval_cases s
  · exact K16.capWeaken b1 (by decide) (by decide +kernel)
  · exact K16.capWeaken b2 (by decide) (by decide +kernel)
  · exact K16.capWeaken b3 (by decide) (by decide +kernel)
  · exact K16.capWeaken b4 (by decide) (by decide +kernel)
  · exact K16.capWeaken b5 (by decide) (by decide +kernel)

/-- Build the eleven rows without using the preceding kernel table or joint proof. -/
theorem kernel_from_rows (seed : KS.SetB) (chain : SeqCapLt 7 0 (capF Ttab 0) 66)
    (kernel : K16.Kernel16) : K16.TheoremK16 := by
  intro s
  induction s using Nat.strong_induction_on with
  | h s ih =>
    intro hs
    let i : Fin 11 := ⟨s,by omega⟩
    have lim : limit s ≤ 96-6*s := (numeric i).1
    have left (j x : Nat) (hj : j ≤ s) (hx : x ≤ 96-6*s) :
        capF D16tab j x ≤ capF (dataRow s) j x :=
      ((numeric i).2 ⟨j,by omega⟩ ⟨x,by omega⟩ hj hx).1
    have right (x : Nat) (hx : x ≤ 96-6*s) : capF (dataRow s) s x ≤ capF D16tab s x :=
      ((numeric i).2 i ⟨x,by omega⟩ (le_refl _) hx).2 rfl
    have start : SeqCapLt 7 s (capF D16tab s) (limit s+1) := by
      by_cases z : s=0
      · subst s
        exact K16.capWeaken chain (by decide) (by decide +kernel)
      by_cases few : s≤5
      · exact seed_start few (by omega) seed
      obtain ⟨t, rfl⟩ := Nat.exists_eq_succ_of_ne_zero z
      change limit (t+1) ≤ 96-6*(t+1) at lim
      have h0 := ih 0 (by omega) (by omega)
      have ht := ih t (by omega) (by omega)
      have r0 : limit (t+1)+1 ≤ 97-6*0 := by omega
      have rt : limit (t+1)+1 ≤ 97-6*t := by omega
      apply K16.cl2_first (h0.mono r0) (ht.mono rt)
      intro x hx d hd
      change x < limit (t+1)+1 at hx
      exact convolution ⟨t, by omega⟩ (by change 5 ≤ t; omega) ⟨x,by omega⟩
        (by change x ≤ limit (t+1); omega) ⟨d,by omega⟩ hd
    have cap := row_rule kernel s hs
      (fun j hj => K16.capWeaken (ih j hj (by omega)) (by omega)
        (fun x hx => left j x (by omega) (by omega)))
      (K16.capWeaken start (by omega) (fun x hx => left s x (le_refl _) (by omega)))
    exact K16.capWeaken cap (by omega) (fun x hx => right x (by omega))

/-- The two short evaluations fill the five exceptional baseline entries. -/
theorem chain_prefix (seed : KS.SetB) (c59 : KS.Ev Ttab 0 59 59 2 3 5)
    (c62 : KS.Ev Ttab 0 62 65 2 3 5) : SeqCapLt 7 0 (capF Ttab 0) 66 := by
  have b0 := seed.1
  have t59 : SeqCapLt 7 0 (capF Ttab 0) (59+1) := KS.seqCap_of_ev
    (fun j hj => absurd hj (Nat.not_lt_zero j))
    ((b0.mono (b:=59) (by decide)).congr (by decide +kernel)) c59
  have t61 : SeqCapLt 7 0 (capF Ttab 0) 62 :=
    t59.glue (b0.mono (b:=62) (by decide)) (by decide +kernel)
  exact KS.seqCap_of_ev (fun j hj => absurd hj (Nat.not_lt_zero j)) t61 c62

#print axioms kernel_from_rows
#print axioms chain_prefix
end ExactWordFlow.Defect16Obstruction

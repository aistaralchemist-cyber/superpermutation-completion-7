import Defect16Obstruction
import SixCanonical
import PriceFloor
import PacketTransfer

namespace ExactWordFlow.HistoricalTransfer
open SevenWordWindows RotationCore
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain
open private caps profiles from Defect16Obstruction
open private short_price from LengthBudget
open private packets_of_list packet_price from WheelPartition
open private widths_le flat_cells_length width_deficit from PacketTransfer

noncomputable abbrev trails (c : NConfig 7) := (famC c).length
noncomputable abbrev holes (c : NConfig 7) := rowsHoles 7 (famC c).flatten
noncomputable abbrev rows (c : NConfig 7) := (famC c).flatten.length

/-- Signed-length shift, written without truncated subtraction.
At cost 136 the old effective index is e+1; at cost 135 it is e+2. -/
theorem shifted_accounts (c : NConfig 7) (hv : c.Valid) {q : Nat}
    (index : q+c.cost=epsC c+137) :
    30+5*(q:ℤ) ≤ lE (prs (famC c)) ∧ lW (prs (famC c))+6*(q:ℤ) ≤ 108 := by
  obtain ⟨_,v,w⟩ := accounts hv
  have exactN := exact_entries c hv
  have ⟨val,wt⟩ := famC_num hv
  omega

/-- The chain caps and profiles here are from the checked 5,899 calculation. -/
theorem shifted_limits (c : NConfig 7) (hv : c.Valid) {q : Nat}
    (index : q+c.cost=epsC c+137) :
    q≤3 ∧ 6*trails c+11*q≤78 ∧ (q=3 → trails c≤6) := by
  have F := famC_trailFam hv
  obtain ⟨low,high⟩ := shifted_accounts c hv index
  have capQ : q≤3 := by
    by_contra! many
    have old := family_le_49 caps.chain profiles F (by omega)
    omega
  have weight := lW_prs (famC c)
  refine ⟨capQ,?_,?_⟩
  · change 6*(famC c).length+11*q≤78
    by_contra! big
    have cheap : rowsHoles 7 (famC c).flatten≤45 := by omega
    have bound := short_price caps.chain F cheap
    omega
  · intro top
    change (famC c).length≤6
    by_contra! many
    have bound := family_le_44 caps.chain F (by omega) (by omega)
    omega

/-- Extract a single genuine partition with both the row price and the omitted
packet deficits, retaining the extra unit of room saved at cost 136. -/
theorem packet_accounts (c : NConfig 7) (hv : c.Valid) {q : Nat}
    (index : q+c.cost=epsC c+137) :
    ∃ p : List WheelPacket,
      (rowsEntries (famC c).flatten ++ p.flatMap WheelPacket.cells).Perm c.entries ∧
      135 ≤ rows c + trails c + p.length ∧
      rows c + trails c + p.length + epsC c ≤ c.cost+1 ∧
      (SevenOmission.deficit (widths p):ℤ)+30+5*(q:ℤ)+5*(trails c:ℤ)
        ≤ (rows c:ℤ)-(holes c:ℤ) := by
  obtain ⟨p,hp,sp⟩ := packets_of_list hv c.hanging (fun _ h => h)
  have part : (rowsEntries (famC c).flatten ++ p.flatMap WheelPacket.cells).Perm c.entries := by
    have ker := (kernel_ok hv).inv.flat
    unfold famC NConfig.entries
    rw [List.flatten_append,rowsEntries_append,ker,List.append_assoc]
    exact hp.append_left _
  have len := part.length_eq.trans (exact_entries c hv)
  have lower := partition_price_135 caps.chain profiles (famC_trailFam hv) p len
  rw [List.length_append] at len
  have area := rowsEntries_length_add_holes (k:=7)
    (fun r hr => len_le_of_rowsEntries_pairwise (by decide : 2 ≤ 7) (famC_trailFam hv).classes hr)
  change (rowsEntries (famC c).flatten).length + rowsHoles 7 (famC c).flatten =
      6*(famC c).flatten.length at area
  have exactSlack := exact_slack c hv
  rw [exact_entries c hv,lE_prs] at exactSlack
  have mass := packet_price p
  have defEq := width_deficit p
  have idx : (q:ℤ)+(c.cost:ℤ)=(epsC c:ℤ)+137 := by exact_mod_cast index
  refine ⟨p,part,lower,?_,?_⟩
  · simp only [rows,trails]
    omega
  · simp only [rows,trails,holes]
    omega

/-- The very same 715/720 four-trail boards isolated in the earlier work
occur at (cost,actual excess)=(136,2) or (135,1). No conditional D16 searches
are needed to transfer the geometry. Excluding these boards is separate. -/
theorem four_trail_transfer (c : NConfig 7) (hv : c.Valid)
    (top : 3+c.cost=epsC c+137) (four : trails c=4) (oldRange : 65≤holes c) :
    ∃ p : List WheelPacket,
      (rowsEntries (famC c).flatten ++ p.flatMap WheelPacket.cells).Perm c.entries ∧
      rows c = 65+holes c ∧
      ((holes c=65 ∧ (rowsEntries (famC c).flatten).length=715 ∧ widths p=[5]) ∨
       (holes c=66 ∧ (rowsEntries (famC c).flatten).length=720 ∧ p=[])) := by
  obtain ⟨p,part,_,_,deficit⟩ := packet_accounts c hv top
  have len := part.length_eq.trans (exact_entries c hv)
  rw [List.length_append,flat_cells_length] at len
  have area := rowsEntries_length_add_holes (k:=7)
    (fun r hr => len_le_of_rowsEntries_pairwise (by decide : 2 ≤ 7) (famC_trailFam hv).classes hr)
  change (rowsEntries (famC c).flatten).length + holes c = 6*rows c at area
  have high := (shifted_accounts c hv top).2
  rw [lW_prs] at high
  change (holes c:ℤ)+6*(trails c:ℤ)+6*(3:ℤ)≤108 at high
  let V := rows c-holes c
  have eq : rows c=V+holes c := by dsimp [V]; omega
  obtain ⟨v,fives,shape⟩ := SevenOmission.last_effective_excess (holes c) V (widths p)
    oldRange (by omega) (by omega) (by omega) (widths_le p) (by omega)
  refine ⟨p,part,by omega,?_⟩
  rcases shape with ⟨h,n⟩|⟨h,n⟩
  · obtain ⟨a,ha⟩ := List.length_eq_one_iff.mp n
    have all5 := fives a (by simp [ha])
    exact .inl ⟨h,by omega,by simp [ha,all5]⟩
  · have np : p=[] := List.length_eq_zero_iff.mp (by simpa [widths] using n)
    exact .inr ⟨h,by omega,np⟩

/-- The same six local small-hole exclusions used in the older work suffice to
restrict the highest effective index to its two archived boards. These local
geometric hypotheses are explicit and no global 5,901 bound is assumed. -/
theorem highest_to_archived_boards
    (one : TrailCap 1 96 40) (two : TrailCap 2 84 50)
    (three : TrailCap 3 72 60) (four : TrailCap 4 64 65)
    (five : TrailCap 5 60 70) (six : TrailCap 6 54 75)
    (c : NConfig 7) (hv : c.Valid) (top : 3+c.cost=epsC c+137) :
    trails c=4 ∧ ∃ p : List WheelPacket,
      (rowsEntries (famC c).flatten ++ p.flatMap WheelPacket.cells).Perm c.entries ∧
      rows c=65+holes c ∧
      ((holes c=65 ∧ (rowsEntries (famC c).flatten).length=715 ∧ widths p=[5]) ∨
       (holes c=66 ∧ (rowsEntries (famC c).flatten).length=720 ∧ p=[])) := by
  have F := famC_trailFam hv
  obtain ⟨lo,hi⟩ := shifted_accounts c hv top
  rw [lE_prs] at lo
  rw [lW_prs] at hi
  have maxCount := (shifted_limits c hv top).2.2 rfl
  change (famC c).length≤6 at maxCount
  have pos : 1≤(famC c).length := by
    by_contra! neg
    have nil : famC c=[] := List.eq_nil_of_length_eq_zero (by omega)
    rw [nil] at lo
    simp [rowsHoles] at lo
  have exactly : (famC c).length=4 := by
    by_contra bad
    have cases : (famC c).length=1 ∨ (famC c).length=2 ∨ (famC c).length=3 ∨
      (famC c).length=5 ∨ (famC c).length=6 := by omega
    rcases cases with h|h|h|h|h
    · have := one _ F h (by omega)
      omega
    · have := two _ F h (by omega)
      omega
    · have := three _ F h (by omega)
      omega
    · have := five _ F h (by omega)
      omega
    · have := six _ F h (by omega)
      omega
  refine ⟨exactly,four_trail_transfer c hv top exactly ?_⟩
  change 65≤rowsHoles 7 (famC c).flatten
  by_contra! small
  have := four _ F exactly (by omega)
  omega

/-- Existence statement for an actual 1,196-letter, 720-visit, 48-completion word. -/
theorem actual_transfer {w : Block} (len : w.length=1196) (all : (visited w).card=720)
    (done : (complete w).card=48) :
    ∃ (c : NConfig 7) (q : Nat) (p : List WheelPacket), c.Valid ∧
      135≤c.cost ∧ c.cost≤136 ∧ q+c.cost=epsC c+137 ∧
      q≤3 ∧ 6*trails c+11*q≤78 ∧ (q=3 → trails c≤6) ∧
      (rowsEntries (famC c).flatten ++ p.flatMap WheelPacket.cells).Perm c.entries ∧
      135≤rows c+trails c+p.length ∧ rows c+trails c+p.length+epsC c≤c.cost+1 := by
  obtain ⟨c,hv,lo,hi,_⟩ := Defect16Obstruction.configuration w len all done
  let q := epsC c+137-c.cost
  have idx : q+c.cost=epsC c+137 := by dsimp [q]; omega
  obtain ⟨cap,count,atTop⟩ := shifted_limits c hv idx
  obtain ⟨p,part,lower,upper,_⟩ := packet_accounts c hv idx
  exact ⟨c,q,p,hv,lo,hi,idx,cap,count,atTop,part,lower,upper⟩

#print axioms actual_transfer
#print axioms highest_to_archived_boards
#print axioms four_trail_transfer
end ExactWordFlow.HistoricalTransfer

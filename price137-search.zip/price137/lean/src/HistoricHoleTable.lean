import HistoricalCommonCut

namespace ExactWordFlow.HistoricalTransfer
open SevenWordWindows RotationCore
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain
open private caps from Defect16Obstruction
open private packet_price from WheelPartition
open private width_deficit from PacketTransfer

private def best (xs : List Nat) := xs.foldr max 0

private theorem below_best {a : Nat} {xs : List Nat} (ha : a ∈ xs) : a ≤ best xs := by
  induction xs with
  | nil => simp at ha
  | cons x xs ih =>
    rcases List.mem_cons.mp ha with eq|mem
    · subst x; exact Nat.le_max_left _ _
    · exact Nat.le_trans (ih mem) (Nat.le_max_right _ _)

/-- Row bound for a specified number of trails sharing a budget of up to 84 holes.
Each term uses Halfar's already certified single-trail table. -/
private def rowCaps : Nat → Vector Nat 85
  | 0 => Vector.replicate 85 0
  | m+1 =>
    let old := rowCaps m
    Vector.ofFn fun b => best ((List.range (b.val+1)).map
      (fun h => Mf h + old[b.val-h]!))

private theorem rows_le (F : List (List (NRow 7))) {b : Nat} (small : b<85)
    (budget : rowsHoles 7 F.flatten ≤ b)
    (h : TrailFam 7 F) : F.flatten.length ≤ (rowCaps F.length)[b] := by
  induction F generalizing b with
  | nil => simp
  | cons A S ih =>
    rw [List.flatten_cons,rowsHoles_append] at budget
    rw [List.flatten_cons,List.length_append]
    let a := rowsHoles 7 A
    have allowed := chain_cap_rows caps.chain (h.trails A List.mem_cons_self)
      (h.classes.sublist (rowsEntries_sublist_flatten List.mem_cons_self))
      (by omega)
    have tail : TrailFam 7 S := ⟨fun T ht => h.trails T (List.mem_cons_of_mem _ ht),by
      have hc := h.classes
      rw [List.flatten_cons,rowsEntries_append,List.pairwise_append] at hc
      exact hc.2.1⟩
    have rest := ih (b:=b-a) (by omega) (by dsimp [a]; omega) tail
    have member : Mf a + (rowCaps S.length)[b-a]! ∈ (List.range (b+1)).map
        (fun j => Mf j + (rowCaps S.length)[b-j]!) :=
      List.mem_map.mpr ⟨a,List.mem_range.mpr (by dsimp [a]; omega),rfl⟩
    have largest := below_best member
    simp only [getElem!_pos (rowCaps S.length) (b-a) (by omega : b-a<85)] at largest
    simp only [List.length_cons,rowCaps,Vector.getElem_ofFn]
    exact (Nat.add_le_add allowed rest).trans largest

/-- Rows are indexed by the saving 137 minus geometric price (0, 1 or 2);
columns by the number of trails (1 through 11, with column 0 unused). -/
def holeFloor : Array (Array Nat) := #[
  #[0,62,48,42,40,38,38,38,36,36,36,36],
  #[0,62,56,50,46,44,44,44,42,42,40,40],
  #[0,85,64,58,52,50,50,50,48,48,46,46]]

private def allCaps := Vector.ofFn (fun m : Fin 12 => rowCaps m.val)
private theorem certificate : ∀ i : Fin 3, ∀ m : Fin 12,
    (holeFloor[i.val]!)[m.val]!≤85 ∧ ∀ h : Fin 85,
      h.val < (holeFloor[i.val]!)[m.val]! →
      (allCaps[m.val])[h.val] < h.val+5*m.val+35+5*i.val := by native_decide

/-- Sound for arbitrary pairwise rotation-disjoint trails; no assumed family cap. -/
theorem hole_floor_of_value {G : List (List (NRow 7))} (fam : TrailFam 7 G)
    (m : G.length≤11) {i : Nat} (lev : i≤2)
    (value : rowsHoles 7 G.flatten + 5*G.length+35+5*i ≤ G.flatten.length) :
    (holeFloor[i]!)[G.length]! ≤ rowsHoles 7 G.flatten := by
  have cert := certificate ⟨i,by omega⟩ ⟨G.length,by omega⟩
  apply Nat.le_of_not_gt
  intro short
  have within : rowsHoles 7 G.flatten < 85 := lt_of_lt_of_le short cert.1
  have lower := cert.2 ⟨_,within⟩ short
  simp only [allCaps, Vector.getElem_ofFn] at lower
  have upper := rows_le G within (Nat.le_refl _) fam
  omega

/-- For the actual common geometric test, the same selected trail family obeys
its row of the table at its own price, including any surplus packet deficit. -/
theorem common_hole_floor {M : Nat} (test : CommonCut M) (small : M≤11) :
    ∃ (G : List (List (NRow 7))) (p : List WheelPacket), TrailFam 7 G ∧ G.length=M ∧
      (let z := G.flatten.length+M+p.length
       135≤z ∧ z≤137 ∧ (holeFloor[137-z]!)[M]! ≤ rowsHoles 7 G.flatten ∧
         rowsHoles 7 G.flatten+6*M≤102) := by
  obtain ⟨G,p,fam,sz,⟨count,_,_⟩,budget,_,zlo,zhi⟩ := test
  rw [List.length_append] at count
  have area := rowsEntries_length_add_holes (k:=7)
    (fun r hr => len_le_of_rowsEntries_pairwise (by decide : 2≤7) fam.classes hr)
  change (rowsEntries G.flatten).length+rowsHoles 7 G.flatten=6*G.flatten.length at area
  let z := G.flatten.length+M+p.length
  have defeq := width_deficit p
  have mass := packet_price p
  have ok := hole_floor_of_value (G:=G) fam (by omega) (i:=137-z)
    (by dsimp [z]; omega) (by dsimp [z]; omega)
  exact ⟨G,p,fam,sz,zlo,zhi,by simpa [sz,z] using ok,budget⟩

#print axioms common_hole_floor
end ExactWordFlow.HistoricalTransfer

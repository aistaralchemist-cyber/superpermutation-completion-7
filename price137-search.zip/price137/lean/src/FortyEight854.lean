import ComponentCap854
import Window561

namespace ExactWordFlow.FortyEight854
open SevenWordWindows DirectedEuler ResidualDensity ResidualRoutes RotationComponentCount
open ResidualIncidence SuperpermutationBounds
open private hits Cost totals rank_partition from NearHundredShape
open private lump from GlobalClosedPrice
open private initial from MarkedDensity

/-- At most forty-eight components away from the start can occur with 854 residual edges. -/
theorem outside48 {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤854) :
    (occupied X s).card≤48 := by
  classical
  by_contra! hn
  let Q:=occupied X s
  let home:=label X s
  have budget:=GlobalClosedPrice.budget h
  simp only [GlobalClosedPrice.fee,Finset.sum_add_distrib,lump,Finset.sum_const,smul_eq_mul] at budget
  have high : 49≤Q.card := hn
  have low : Q.card≤50 := ComponentCap854.outside50 h bd
  have noLong : (Q.filter (fun q=>6<(part X q).card)).card=0 := by dsimp [Q]; omega
  have each (q) (hq:q∈Q) : Cost X q≤6 := by
    by_contra! big
    have pos:=Finset.card_pos.mpr (show (Q.filter (fun q=>6<(part X q).card)).Nonempty from
      ⟨q,Finset.mem_filter.mpr ⟨hq,big⟩⟩)
    omega
  have zero : (∑q∈Q,(Cost X q-6))=0 := Finset.sum_eq_zero (fun q hq=>Nat.sub_eq_zero_of_le (each q hq))
  obtain ⟨mass,pay⟩:=totals h
  change Cost X home+6*Q.card+(∑q∈Q,(Cost X q-6))=X.card at mass
  change 7*(∑q∈Q,(hits X s q-1))+(if 0<(∑q∈Q,(Cost X q-6)) then 6 else 0)≤
    35*Q.card+6*(∑q∈Q,(Cost X q-6)) at pay
  rw [zero] at mass pay
  have rank:=rank_partition h
  change separateRank X s=hits X s home-1+∑q∈Q,(hits X s q-1) at rank
  have connected : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have visit:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  by_cases top : Q.card=50
  · have cap:=Window561.root554 r wd (by omega)
    omega
  · have cap:=Window561.root560 r wd (by omega)
    omega

/-- The 854-edge budget has a smaller exact partial-word decision problem. -/
theorem decision1196 :
    (∃w : Block, Covers w ∧ w.length≤5900) ↔ BudgetCoreCurve.atLength 1196 48 :=
  BudgetCoreCurve.threshold 854 48 (by decide) (fun h bd => outside48 h bd)

#print axioms outside48
#print axioms decision1196
end ExactWordFlow.FortyEight854

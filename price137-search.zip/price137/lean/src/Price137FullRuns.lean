import Price137NoFives
namespace ExactWordFlow.HistoricalTransfer
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain

private def partials : List (NRow 7) → Nat
  | [] => 0
  | r::t => if r.len=6 then partials t else partials t+1

/-- Every block of consecutive full rows has length at most d, with n
positions still available before the first partial row. -/
def boundedRuns (d : Nat) : Nat → List (NRow 7) → Prop
  | _, [] => True
  | n, r::t => if r.len=6 then 0<n ∧ boundedRuns d (n-1) t else boundedRuns d d t

private theorem trail_bound {d n : Nat} {t : List (NRow 7)} (ok : boundedRuns d n t) :
    t.length≤(d+1)*partials t+n := by
  induction t generalizing n with
  | nil => simp [partials]
  | cons r t ih =>
    by_cases yes : r.len=6
    · simp [boundedRuns,yes] at ok
      have bound := ih ok.2
      simp [partials,yes]
      omega
    · simp [boundedRuns,yes] at ok
      have bound := ih ok
      simp [partials,yes,Nat.mul_add]
      omega

private theorem partials_add (a b : List (NRow 7)) : partials (a++b)=partials a+partials b := by
  induction a with
  | nil => simp [partials]
  | cons r t ih =>
    by_cases yes:r.len=6
    · simp [partials,yes,ih]
    · simp [partials,yes,ih]
      omega

private theorem family_bound {d : Nat} {G : List (List (NRow 7))}
    (ok : ∀t∈G, boundedRuns d d t) :
    G.flatten.length ≤ (d+1)*partials G.flatten + d*G.length := by
  induction G with
  | nil => simp [partials]
  | cons t rest ih =>
    have first := trail_bound (ok t (by simp))
    have other := ih (fun t ht => ok t (by simp [ht]))
    simp only [List.flatten_cons,List.length_append,partials_add,List.length_cons,Nat.mul_add,Nat.mul_one]
    omega

private theorem partials_holes {a : List (NRow 7)}
    (ok : ∀r∈a,r.len≤6) (no5 : ∀r∈a,r.len≠5) : 2*partials a≤rowsHoles 7 a := by
  induction a with
  | nil => rfl
  | cons r a ih =>
    have cap := ok r (by simp)
    have skip := no5 r (by simp)
    have tail := ih (fun t ht=>ok t (by simp [ht])) (fun t ht=>no5 t (by simp [ht]))
    by_cases yes:r.len=6 <;> simp only [partials,yes,ite_true,ite_false]
    all_goals change _ ≤ 6-r.len+rowsHoles 7 a
    all_goals omega

/-- At exact price 137 an all-width-five-free family contains two consecutive
full rows, three if M≥3, and four if M≥9. The bounds concern consecutive
rows within one and the same trail. -/
theorem full_runs_without_fives {M : Nat} {G : List (List (NRow 7))} {p : List WheelPacket}
    (board : PriceRangeBoard M G p) (price : G.flatten.length+M+p.length=137)
    (no5 : ∀r∈G.flatten,r.len≠5) :
    (¬∀t∈G,boundedRuns 1 1 t) ∧
    (3≤M → ¬∀t∈G,boundedRuns 2 2 t) ∧
    (9≤M → ¬∀t∈G,boundedRuns 3 3 t) := by
  have holes := partials_holes
    (fun r hr => len_le_of_rowsEntries_pairwise (by decide : 2≤7) board.family.classes hr) no5
  obtain ⟨_,_,budget,_⟩ := board.accounts
  have rows := board.row_count
  rw [price] at budget rows
  have count := board.trails
  constructor
  · intro h
    have := family_bound h
    omega
  constructor
  · intro m h
    have := family_bound h
    omega
  · intro m h
    have := family_bound h
    omega

#print axioms full_runs_without_fives
end ExactWordFlow.HistoricalTransfer

import SixCanonical
import ContactBypass

namespace ExactWordFlow.OpenCycle
open SevenWordWindows SuperpermutationBounds ResidualDensity DirectedEuler ResidualRoutes
open private labels_on_route from SixFlow

/-- If two distinct endpoints have the same compulsory rotation class, the first
edge of their residual trail can be dropped. The mandatory class still connects
the old start to the old end; the residual suffix connects the new start to that end. -/
theorem shave {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (fs : full s) (ft : full t) (same : tag s=tag t) (different : s ≠ t) :
    ∃ w : Block, Covers w ∧ w.length < 5046+X.card := by
  classical
  obtain ⟨a,b,es,eb,r,_,ends⟩ := component_route h.balance s
  obtain ⟨a0,b0⟩ := ends.1 rfl
  subst a; subst b
  cases r with
  | nil => exact (different rfl).elim
  | @cons s t es e hs tail =>
    obtain ⟨Z,rest⟩ := exists_add_of_le (Multiset.filter_le (fun g=>label X (src g)=label X s) X)
    change X=part X (label X s)+Z at rest
    let A : Multiset Block := ↑es+Z
    have decomp : X=e ::ₘ A := by
      rw [rest,←eb]
      change (e ::ₘ (↑es : Multiset Block)) + Z=e ::ₘ ((↑es : Multiset Block)+Z)
      rw [Multiset.cons_add]
    have width (g) (hg:g∈A) := h.edges_seven g (decomp ▸ Multiset.mem_cons_of_mem hg)
    have bal : A.map src+{t}=A.map dst+{dst e} := by
      have orig := h.balance
      rw [decomp] at orig
      ext g
      have atg := congrArg (Multiset.count g) orig
      simp only [Multiset.map_cons,Multiset.count_add,Multiset.count_cons,Multiset.count_singleton,hs] at atg ⊢
      omega
    let G:=required+A
    have keep (g) (hg:g∈es) : g∈G :=
      Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inl hg)))
    have endsG := Essential.same_tag (A:=A) fs ft same
    have back := labels_on_route tail keep
    have bridge : label G s=label G (dst e) := endsG.trans back.symm
    have all (g) (hg:g∈required+X) : label G (src g)=label G (dst g) := by
      rcases Multiset.mem_add.mp hg with must|extra
      · exact on_edge (Multiset.mem_add.mpr (Or.inl must))
      · rw [decomp] at extra
        rcases Multiset.mem_cons.mp extra with rfl|present
        · exact (congrArg (label G) hs).trans bridge
        · exact on_edge (Multiset.mem_add.mpr (Or.inr present))
    let S : Set Block := {p | label G p=label G s}
    have rooted := h.reachable S rfl (fun g hg hv=>(all g hg).symm.trans hv)
    have together : RequiredComponent.RequiredTogether A := fun p hp q hq =>
      (rooted p (Multiset.mem_add.mpr (Or.inl hp))).trans
        (rooted q (Multiset.mem_add.mpr (Or.inl hq))).symm
    obtain ⟨Y,sub,a,b,flow⟩ := RequiredComponent.feasible_submultiset width bal together
    obtain ⟨w,cover,len⟩ := (word_iff_flow (Y.card+5046) (by omega)).mpr ⟨Y,a,b,by omega,flow⟩
    have bound:=Multiset.card_le_card sub
    rw [decomp,Multiset.card_cons]
    exact ⟨w,cover,by omega⟩


/-- In a shortest covering word at the budget in question, the two clean
boundaries necessarily belong to different mandatory rotation classes. -/
theorem shortest_tags {w : Block} (cover : Covers w) (short : w.length≤5900)
    (optimal : ∀ v : Block, Covers v → w.length≤v.length)
    (fs : full (w.take 6)) (ft : full (w.drop (w.length-6))) :
    tag (w.take 6) ≠ tag (w.drop (w.length-6)) := by
  intro same
  have floor := SuperpermLowerBounds.covers_lower_bound_7_k16_native w cover
  have different : w.take 6≠w.drop (w.length-6) := by
    intro eq
    have := SixFlow.closed_covering_floor cover eq
    omega
  obtain ⟨X,cost,flow⟩ := extract_at_ends w cover (by omega)
  obtain ⟨v,yes,smaller⟩ := shave flow fs ft same different
  have := optimal v yes
  omega

private theorem turn_end : ∀p∈representatives,
    let q := p.tail++[p.headD 0]
    full (p.drop 1) ∧ full (q.drop 1) ∧ tag (q.drop 1)=tag (p.drop 1) := by native_decide

private theorem last_six {p w : Block} (size : p.length=7) (suf : p <:+ w) :
    w.drop (w.length-6)=p.drop 1 := by
  obtain ⟨l,rfl⟩ := suf
  rw [List.length_append,size, show l.length+7-6=l.length+1 by omega,
    List.drop_length_add_append]

/-- The one possible padding letter rotates the final permutation, so the
normalization to 5900 preserves the separation of the two endpoint classes. -/
theorem normalize_distinct {w : Block} (cover : Covers w) (short : w.length≤5900) :
    ∃v : Block, v.length=5900 ∧ Covers v ∧ v.take 6=SixCanonical.start ∧
      full (v.drop (v.length-6)) ∧ tag (v.take 6)≠tag (v.drop (v.length-6)) := by
  obtain ⟨m,hm,sz⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
  have minimal (v : Block) (hv : Covers v) : m.length≤v.length :=
    sz.trans_le (SuperpermBridge.ssuper_le_length hv)
  obtain ⟨v,vm,yes,first,p,pl,pn,suf⟩ := SixCanonical.normalize_to hm (le_refl _)
  have head : v.take 6=SixCanonical.start := by
    obtain ⟨r,rfl⟩ := first
    rw [List.take_append_of_le_length (by simp : 6≤(List.finRange 7).length)]
    decide
  have init : full (v.take 6) := head ▸ (by decide : full SixCanonical.start)
  have hp := (mem_reps p).mpr ⟨pl,pn⟩
  have geo := turn_end p hp
  have terminal := last_six pl suf
  have clean : full (v.drop (v.length-6)) := terminal ▸ geo.1
  have ceil := (minimal w cover).trans short
  have lb := SuperpermLowerBounds.covers_lower_bound_7_k16_native v yes
  have diff := shortest_tags yes (by omega) (vm ▸ minimal) init clean
  by_cases already : v.length=5900
  · exact ⟨v,already,yes,head,clean,diff⟩
  have n : v.length=5899 := by omega
  let y := v++[p.headD 0]
  have yy : Covers y := by
    intro q lq nq
    obtain ⟨l,r,eq⟩ := yes q lq nq
    exact ⟨l,r++[p.headD 0],by simp [y,eq,List.append_assoc]⟩
  have yhead : y.take 6=v.take 6 := List.take_append_of_le_length (by omega)
  have suf' : p.tail++[p.headD 0] <:+ y := by
    obtain ⟨l,eq⟩ := suf
    cases p with
    | nil => simp at pl
    | cons a as =>
      exact ⟨l++[a],by simp [y,←eq,List.append_assoc]⟩
  have turnlen : (p.tail++[p.headD 0]).length=7 := by simp [pl]
  have last := last_six turnlen suf'
  exact ⟨y,by simp [y,n],yy,yhead.trans head,last ▸ geo.2.1,
    by rw [yhead,last,geo.2.2,←terminal]; exact diff⟩

open RotationSpan RotationCore CoreAssembly RotationComponentCount
open private sink from SixCanonical
open private prescribe from CompletionExchange
open private sel_mono from RotationSpan

theorem canonical_distinct_for {T : Finset Block} (legalT : T⊆allClasses) (quota : T.card≤6)
    {w : Block} (cover : Covers w) (short : w.length≤5900) :
    ∃z : Block, z.length=1196 ∧ (visited z).card=720 ∧ (complete z).card=48 ∧ T⊆complete z ∧
      z.take 6=SixCanonical.start ∧ full (z.drop (z.length-6)) ∧
      tag (z.take 6)≠tag (z.drop (z.length-6)) := by
  classical
  obtain ⟨v,size,yes,first,last,diff⟩ := normalize_distinct cover short
  obtain ⟨X,cost,flow⟩ := extract_at_ends v yes (by omega)
  have budget : X.card=854 := by omega
  obtain ⟨S,legal,bound,spans⟩ := spanning flow
  have few := Window597.outside42 flow budget.le
  have unionLegal := Finset.union_subset legal legalT
  have small : (S∪T).card≤48 := by have := Finset.card_union_le S T; omega
  obtain ⟨D,includes,dLegal,dSize⟩ := Finset.exists_subsuperset_card_eq unionLegal small (by rw [board]; decide)
  have kept : S⊆D := Finset.subset_union_left.trans includes
  obtain ⟨z,head,split,len,all,done⟩ := prescribe flow budget dLegal
    (fun u hu => label_lift (sel_mono X kept) (spans u hu))
  have newEnd := sink flow dLegal (by omega) head split
  exact ⟨z,by omega,all,done ▸ dSize,done ▸ Finset.subset_union_right.trans includes,head.trans first,
    newEnd ▸ last,by rwa [head,newEnd]⟩

theorem affine_iff_separate_classes : (∃w, AffineSixTarget.Candidate w) ↔
    ∃z, AffineSixTarget.Candidate z ∧ z.take 6=SixCanonical.start ∧
      full (z.drop (z.length-6)) ∧ tag (z.take 6)≠tag (z.drop (z.length-6)) := by
  constructor
  · rintro ⟨w,n,v,k,_⟩
    obtain ⟨u,h,c⟩ := Exact48Target.extend_exact48 w v k
    obtain ⟨z,n',v',k',six,first,last,sep⟩ :=
      canonical_distinct_for SixGeometry.legal SixGeometry.six_card.le h (by omega)
    exact ⟨z,⟨n',v',k',six⟩,first,last,sep⟩
  · rintro ⟨w,hw,_⟩
    exact ⟨w,hw⟩

#print axioms affine_iff_separate_classes
#print axioms shave
#print axioms normalize_distinct
end ExactWordFlow.OpenCycle

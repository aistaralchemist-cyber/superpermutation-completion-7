import AffineSixTarget
import NormalizedWord

namespace ExactWordFlow.SixCanonical
open SevenWordWindows SuperpermutationBounds ResidualDensity RotationReinsert RotationCore
open RotationSpan ResidualRoutes ResidualIncidence CoreAssembly RotationComponentCount
open private pad_tail relabel_covers from NormalizedWord
open private prescribe from CompletionExchange
open private sel_mono from RotationSpan
open private perm_info from SixFlow

/-- The shortest-word normalization, with its target length left as a parameter. -/
theorem normalize_to {N : Nat} {w : Word} (cover : Covers w) (le : w.length ≤ N) :
    ∃ s : Word, s.length=N ∧ Covers s ∧
      (List.finRange 7 <+: s) ∧ ∃ p : Word, p.length=7 ∧ p.Nodup ∧ p <:+ s := by
  obtain ⟨z,hz,lz⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
  have zmin (v : Word) (c : Covers v) : z.length≤v.length :=
    lz.trans_le (SuperpermBridge.ssuper_le_length c)
  have ceiling := (zmin w cover).trans le
  obtain ⟨u,v,hfront⟩ := hz (List.finRange 7) List.length_finRange (List.nodup_finRange 7)
  have l0 := congrArg List.length hfront
  simp only [List.length_append,List.length_finRange] at l0
  have positive : 0 < z.length := by omega
  obtain ⟨first,a,b,lf,nf,atFirst,la,_,_⟩ :=
    SevenCriticalLetters.shortest_unique hz zmin 0 positive
  have nilA : a=[] := List.length_eq_zero_iff.mp (by omega)
  subst a
  simp only [List.nil_append] at atFirst
  obtain ⟨last,c,d,ll,nl,atLast,_,bound,_⟩ :=
    SevenCriticalLetters.shortest_unique hz zmin (z.length-1) (by omega)
  have pos := congrArg List.length atLast
  simp only [List.length_append] at pos
  have nilD : d=[] := List.length_eq_zero_iff.mp (by omega)
  subst d
  simp only [List.append_nil] at atLast
  obtain ⟨t,e,p,lt,ending,lp,np⟩ := pad_tail z ⟨c,last,atLast,ll,nl⟩ (N-z.length)
  let f := (SevenAlmostCover.relabel first lf nf).symm
  have start : first.map f=List.finRange 7 := by
    have fwd := SevenAlmostCover.relabel_map first lf nf
    simpa [f] using congrArg (List.map f) fwd.symm
  refine ⟨(z++t).map f,by simp; omega,?_,?_,?_⟩
  · apply relabel_covers
    intro q lq nq
    obtain ⟨l,r,eq⟩ := hz q lq nq
    exact ⟨l,r++t,by simp [eq]⟩
  · refine ⟨(b++t).map f,?_⟩
    simp [atFirst,start]
  · exact ⟨p.map f,by simp [lp],np.map f.injective,⟨e.map f,by simp [ending]⟩⟩


/-- The sink is determined by the source and the window multiset. -/
private theorem sink {X : Multiset Block} {s t z : Block} {D : Finset Block}
    (h : Feasible X s t) (legal : D⊆allClasses) (long : 6≤z.length)
    (head : z.take 6=s) (split : bag z=X+mandatory D) : z.drop (z.length-6)=t := by
  have whole := (read_route z long).balance
  change (bag z).map src + {z.drop (z.length-6)} = (bag z).map dst + {z.take 6} at whole
  rw [split,head,Multiset.map_add,Multiset.map_add,(mandatory_data D legal).2] at whole
  have bal : X.map src+{z.drop (z.length-6)}=X.map dst+{s} := add_left_cancel (a:=(mandatory D).map dst)
    (by simpa only [add_comm,add_left_comm,add_assoc] using whole)
  exact Multiset.singleton_inj.mp (add_left_cancel (bal.trans h.balance.symm))

def start : Block := [0,1,2,3,4,5]

/-- The six prescribed completions may be imposed after fixing a clean start
and a clean end. The spelling keeps both endpoints of the normalized surplus. -/
theorem canonical_for {T : Finset Block} (allowed : T⊆allClasses) (quota : T.card≤6)
    {w : Block} (cover : Covers w) (short : w.length≤5900) :
    ∃z : Block, z.length=1196 ∧ (visited z).card=720 ∧ (complete z).card=48 ∧ T⊆complete z ∧
      z.take 6=start ∧ full (z.drop (z.length-6)) ∧ z.drop (z.length-6)≠start := by
  classical
  obtain ⟨v,size,yes,first,p,plen,pdup,last⟩ := normalize_to cover short
  have vstart : v.take 6=start := by
    obtain ⟨a,rfl⟩ := first
    rw [List.take_append_of_le_length (by simp : 6≤(List.finRange 7).length)]
    decide
  have vend : full (v.drop (v.length-6)) := by
    obtain ⟨b,rfl⟩ := last
    rw [List.length_append,plen,show b.length+7-6=b.length+1 by omega,List.drop_length_add_append]
    exact (perm_info p ((mem_reps p).mpr ⟨plen,pdup⟩)).2.1
  obtain ⟨X,cost,flow⟩ := extract_at_ends v yes (by omega)
  have budget : X.card=854 := by omega
  obtain ⟨S,legal,bound,spans⟩ := spanning flow
  have few := Window597.outside42 flow budget.le
  have unionLegal := Finset.union_subset legal allowed
  have small : (S∪T).card≤48 := by have := Finset.card_union_le S T; omega
  obtain ⟨D,includes,dLegal,dSize⟩ := Finset.exists_subsuperset_card_eq unionLegal small (by rw [board]; decide)
  have kept : S⊆D := Finset.subset_union_left.trans includes
  obtain ⟨z,head,split,len,all,done⟩ := prescribe flow budget dLegal
    (fun u hu => label_lift (sel_mono X kept) (spans u hu))
  have newEnd := sink flow dLegal (by omega) head split
  have zstart := head.trans vstart
  have zSize : z.length=1196 := by omega
  have cz : (complete z).card=48 := done ▸ dSize
  refine ⟨z,zSize,all,cz,done ▸ Finset.subset_union_right.trans includes,zstart,newEnd ▸ vend,?_⟩
  exact fun equal => SixFlow.candidate_distinct_ends zSize all cz (zstart.trans equal.symm)

/-- The exact candidate decision with the six arithmetic cycles, canonical clean
start, and a distinct clean end. -/
theorem affine_iff_canonical :
    (∃ w, AffineSixTarget.Candidate w) ↔
    ∃ z, AffineSixTarget.Candidate z ∧ z.take 6=start ∧
      full (z.drop (z.length-6)) ∧ z.drop (z.length-6)≠start := by
  constructor
  · rintro ⟨w,size,vis,done,_⟩
    obtain ⟨u,y,sz⟩ := Exact48Target.extend_exact48 w vis done
    obtain ⟨z,n,v,k,six,head,tail,diff⟩ := canonical_for SixGeometry.legal SixGeometry.six_card.le y (by omega)
    exact ⟨z,⟨n,v,k,six⟩,head,tail,diff⟩
  · rintro ⟨z,yes,_⟩
    exact ⟨z,yes⟩

/-- One open-endpoint proposition whose negation would complete an independent proof. -/
def Remaining : Prop :=
  ∃ z, AffineSixTarget.Candidate z ∧ z.take 6=start ∧
    full (z.drop (z.length-6)) ∧ z.drop (z.length-6)≠start ∧
    ∀a : Fin 7, 49≤z.count a

theorem remaining_iff_lower : (¬ Remaining) ↔ Almanac.LowerBoundAt 7 5901 := by
  rw [AffineSixTarget.lower_iff_excluded]
  constructor
  · intro impossible h
    obtain ⟨z, hz, head, tail, openEnd⟩ := affine_iff_canonical.mp h
    exact impossible ⟨z, hz, head, tail, openEnd, SixFrequency.every_letter hz.1 hz.2.1 hz.2.2.1⟩
  · rintro impossible ⟨z, hz, _⟩
    exact impossible ⟨z, hz⟩

#print axioms canonical_for
#print axioms affine_iff_canonical
end ExactWordFlow.SixCanonical

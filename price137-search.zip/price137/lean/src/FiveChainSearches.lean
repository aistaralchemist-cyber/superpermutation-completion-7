import LowerBounds.KSearch
import LowerBounds.KTables

/-! The only five improvements over the accepted chain seed required below. -/
namespace ExactWordFlow.Defect16Obstruction
open SuperpermLowerBounds SuperpermLowerBounds.T5900

theorem chain59 : KS.seqSearch 7 Ttab 0 59 59 2 3 5 400 10 8 0 8 = false := by
  native_decide

theorem chain62to65 : KS.seqSearch 7 Ttab 0 62 65 2 3 5 400 12 8 0 8 = false := by
  native_decide

#print axioms chain59
#print axioms chain62to65
end ExactWordFlow.Defect16Obstruction

import WheelPartition
import PacketFrontier
namespace SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain T5899

def widths (ps : List WheelPacket) := ps.map (fun p => p.cells.length)

private theorem widths_le (ps : List WheelPacket) : ∀ t ∈ widths ps, t≤5 := by
  intro t ht
  obtain ⟨p,_,rfl⟩ := List.mem_map.mp ht
  exact p.small

private theorem flat_cells_length (ps : List WheelPacket) :
    (ps.flatMap WheelPacket.cells).length=(widths ps).sum := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    change (p.cells ++ ps.flatMap WheelPacket.cells).length = p.cells.length + (widths ps).sum
    rw [List.length_append,ih]

private theorem width_deficit (ps : List WheelPacket) :
    (SevenOmission.deficit (widths ps) : ℤ)=(ps.map packetDef).sum := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    change (((5-p.cells.length) + SevenOmission.deficit (widths ps) : Nat) : ℤ) =
      packetDef p + (ps.map packetDef).sum
    rw [Nat.cast_add,ih]
    unfold packetDef
    have h := p.small
    omega

/-- Quantities used by the finite geometry are linked to packets extracted
from the actual row configuration. Here raw value is rows minus holes. -/
theorem numeric_packets (c : NConfig 7) (hv : c.Valid) {j : Nat} (hc : c.cost≤137+j)
    {v : Nat} (vraw : (famC c).flatten.length = v + rowsHoles 7 (famC c).flatten) :
    ∃ ps : List WheelPacket,
      (rowsEntries (famC c).flatten ++ ps.flatMap WheelPacket.cells).Perm c.entries ∧
      6*v+5*rowsHoles 7 (famC c).flatten+(widths ps).sum=720 ∧
      SevenOmission.deficit (widths ps) + 30+5*epsC c+5*(famC c).length ≤ v+5*j := by
  obtain ⟨ps,part,budget⟩ := omitted_partition c hv hc
  have sum := part.length_eq
  rw [List.length_append,flat_cells_length,exact_entries c hv] at sum
  have geom := rowsEntries_length_add_holes (k:=7)
    (fun r hr => len_le_of_rowsEntries_pairwise (by decide : 2 ≤ 7) (famC_trailFam hv).classes hr)
  change (rowsEntries (famC c).flatten).length + rowsHoles 7 (famC c).flatten =
      6 * (famC c).flatten.length at geom
  rw [lE_prs,←width_deficit] at budget
  exact ⟨ps,part,by omega,by omega⟩

/-- For all increases j, the two effective-excess-three boundary shapes
carry exactly zero or one omitted packet, and the latter has width five. -/
theorem transfer_four (c : NConfig 7) (hv : c.Valid) {j : Nat} (hc : c.cost≤137+j)
    (e : epsC c=j+3) (m : (famC c).length=4)
    (low : 65 ≤ rowsHoles 7 (famC c).flatten) :
    ∃ ps : List WheelPacket,
      (rowsEntries (famC c).flatten ++ ps.flatMap WheelPacket.cells).Perm c.entries ∧
      (famC c).flatten.length = 65+rowsHoles 7 (famC c).flatten ∧
      (∀ t ∈ widths ps, t=5) ∧
      ((rowsHoles 7 (famC c).flatten=65 ∧ ps.length=1) ∨
       (rowsHoles 7 (famC c).flatten=66 ∧ ps.length=0)) := by
  let H := rowsHoles 7 (famC c).flatten
  let v := (famC c).flatten.length - H
  obtain ⟨lo,hi⟩ := costs c hv hc
  rw [lE_prs,m] at lo
  rw [lW_prs,m] at hi
  have raw : (famC c).flatten.length=v+rowsHoles 7 (famC c).flatten := by dsimp [v,H]; omega
  obtain ⟨p,part,count,loss⟩ := numeric_packets c hv hc raw
  have classif := SevenOmission.last_effective_excess H v (widths p) low
    (by dsimp [H]; omega) (by omega) count (widths_le p) (by omega)
  obtain ⟨vv,pp,rr⟩ := classif
  exact ⟨p,part,by omega,pp,by simpa [widths,H] using rr⟩

/-- The same actual-word transfer for the effective-excess-zero, twelve-trail
frontier. The lower hole threshold is the input from finite trail geometry. -/
theorem transfer_twelve (c : NConfig 7) (hv : c.Valid) {j : Nat} (hc : c.cost ≤ 137+j)
    (e : epsC c=j) (m : (famC c).length=12)
    (low : 34 ≤ rowsHoles 7 (famC c).flatten) :
    ∃ (ps : List WheelPacket) (v : Nat),
      (rowsEntries (famC c).flatten ++ ps.flatMap WheelPacket.cells).Perm c.entries ∧
      (famC c).flatten.length = v+rowsHoles 7 (famC c).flatten ∧
      let H := rowsHoles 7 (famC c).flatten
      let t := widths ps
      (H=34 ∧ ((v=90 ∧ t.length=2 ∧ ∀ n ∈ t, n=5) ∨ (v=91 ∧ t=[4]))) ∨
      (H=35 ∧ v=90 ∧ t.length=1 ∧ ∀ n ∈ t, n=5) ∨ (H=36 ∧ v=90 ∧ t=[]) := by
  let H := rowsHoles 7 (famC c).flatten
  let v := (famC c).flatten.length-H
  obtain ⟨lo,hi⟩ := costs c hv hc
  rw [lE_prs,m] at lo
  rw [lW_prs,m] at hi
  have raw : (famC c).flatten.length=v+rowsHoles 7 (famC c).flatten := by dsimp [v,H]; omega
  obtain ⟨p,part,count,loss⟩ := numeric_packets c hv hc raw
  have classif := SevenOmission.twelve_boundary H v (widths p) low
    (by dsimp [H]; omega) (by omega) count (widths_le p) (by omega)
  exact ⟨p,v,part,raw,classif⟩

end SuperpermLowerBounds.LengthBudget
#print axioms SuperpermLowerBounds.LengthBudget.transfer_four
#print axioms SuperpermLowerBounds.LengthBudget.transfer_twelve

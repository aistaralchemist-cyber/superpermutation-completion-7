import HistoricalPriceRange
import OpenCycleAnchor

namespace ExactWordFlow.HistoricalTransfer
open SevenWordWindows RotationCore SuperpermutationBounds
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain

/-- Splitting interior seams raises the geometric price to 137, preserving the
entire flattened row list and the same wheel packets. No local geometric
exclusion is needed to attain price 137 in this relaxed representation. -/
theorem raise_price {M : Nat} {G : List (List (NRow 7))} {p : List WheelPacket}
    (board : PriceRangeBoard M G p) (lo : 1≤M) (hi : M≤11) :
    ∃ (F : List (List (NRow 7))) (n : Nat), F.flatten=G.flatten ∧
      n=M+(137-(G.flatten.length+M+p.length)) ∧ 1≤n ∧ n≤11 ∧
      PriceRangeBoard n F p ∧ F.flatten.length+n+p.length=137 := by
  let z := G.flatten.length+M+p.length
  let n := M+(137-z)
  have ⟨pmin,pmax,_,_⟩ := board.accounts
  change 135≤z at pmin
  change z≤137 at pmax
  have lim : n≤11 := by
    rcases (show z=135 ∨ z=136 ∨ z=137 by omega) with h|h|h
    · have top := (board.low h).2
      dsimp [n]; omega
    · have top := board.mid h
      dsimp [n]; omega
    · dsimp [n]; omega
  let link := fun a b : NRow 7 => SLink 7 3 a.lastEntry b.entry
  have valid := board.family
  have good : Seventeen.Good link G := fun T hT =>
    ⟨(valid.trails T hT).ne,(valid.trails T hT).seams⟩
  have raw := board.row_count
  have size := board.trails
  obtain ⟨F,ok,flat,num⟩ := Seventeen.cuts good (137-z) (by dsimp only at raw; omega)
  have family : TrailFam 7 F := by
    constructor
    · intro T ht
      obtain ⟨ne,links⟩ := ok T ht
      refine ⟨ne,?_,links⟩
      intro row mem
      have inside : row∈G.flatten := flat ▸ List.mem_flatten.mpr ⟨T,ht,mem⟩
      obtain ⟨old,inG,inOld⟩ := List.mem_flatten.mp inside
      exact (valid.trails old inG).len row inOld
    · rw [flat]
      exact valid.classes
  have total : F.flatten.length+n+p.length=137 := by rw [flat]; dsimp [n,z] at *; omega
  have pos : 1≤n := by dsimp [n]; omega
  have num' : F.length=n := by dsimp [n]; omega
  refine ⟨F,n,flat,rfl,pos,lim,price_ranges_of_cover pos lim family num' ?_ (by omega) (by omega),total⟩
  rw [flat]
  exact board.coverage

theorem word_to_exact_price {w : Block} (len : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) :
    ∃ (M : Nat) (G : List (List (NRow 7))) (p : List WheelPacket),
      1≤M ∧ M≤11 ∧ PriceRangeBoard M G p ∧ G.flatten.length+M+p.length=137 := by
  obtain ⟨m,F,p,lo,hi,board⟩ := word_price_ranges len vis done
  obtain ⟨G,M,_,_,a,b,h,price⟩ := raise_price board lo hi
  exact ⟨M,G,p,a,b,h,price⟩

/-- The three endpoint exclusions reduce the single-price proof target to eight
trail counts. Neither four-trail cover search is a hypothesis of this theorem. -/
theorem word_to_eight_at_137 (one : TrailCap 1 96 40) (ten : TrailCap 10 42 85)
    (eleven : TrailCap 11 36 90) {w : Block} (len : w.length=1196)
    (vis : (visited w).card=720) (done : (complete w).card=48) :
    ∃ (M : Nat) (G : List (List (NRow 7))) (p : List WheelPacket),
      2≤M ∧ M≤9 ∧ PriceRangeBoard M G p ∧ G.flatten.length+M+p.length=137 := by
  obtain ⟨M,G,p,lo,hi,board,price⟩ := word_to_exact_price len vis done
  obtain ⟨_,_,weight,_⟩ := board.accounts
  have value := board.row_count
  rw [price] at weight value
  have rejectSize (j b v : Nat) (cap : TrailCap j b v) (eq : M=j)
      (w : rowsHoles 7 G.flatten≤b) (val : (v:ℤ)≤(G.flatten.length:ℤ)-(rowsHoles 7 G.flatten:ℤ)) :
      False := (not_lt_of_ge val) (cap G board.family (board.trails.trans eq) w)
  have a : M≠1 := fun h => rejectSize 1 96 40 one h (by omega) (by omega)
  have b : M≠10 := fun h => rejectSize 10 42 85 ten h (by omega) (by omega)
  have c : M≠11 := fun h => rejectSize 11 36 90 eleven h (by omega) (by omega)
  exact ⟨M,G,p,by omega,by omega,board,price⟩

/-- The local archives and a uniform exclusion of the remaining exact-price
boards would prove the desired lower bound for every seven-symbol word. -/
theorem lower_of_eight_at_137 (one : TrailCap 1 96 40) (ten : TrailCap 10 42 85)
    (eleven : TrailCap 11 36 90)
    (reject : ∀ (M : Nat) (G : List (List (NRow 7))) (p : List WheelPacket),
      2≤M → M≤9 → PriceRangeBoard M G p → G.flatten.length+M+p.length=137 → False)
    (w : Block) (cover : Covers w) : 5901≤w.length := by
  by_contra! short
  obtain ⟨v,len,vis,done,_⟩ := OpenCycleAnchor.canonical_twice cover (by omega)
  obtain ⟨M,G,p,a,b,board,price⟩ := word_to_eight_at_137 one ten eleven len vis done
  exact reject M G p a b board price

#print axioms word_to_exact_price
#print axioms word_to_eight_at_137
#print axioms lower_of_eight_at_137
end ExactWordFlow.HistoricalTransfer

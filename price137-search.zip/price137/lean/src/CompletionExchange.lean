import Window597
import Mathlib.Data.Nat.Choose.Basic
import Core1224
import CompletedSpareRanks

namespace ExactWordFlow.CompletionExchange
open SevenWordWindows SuperpermutationBounds ResidualDensity ResidualRoutes ResidualIncidence
open RotationCore RotationReinsert RotationSpan RotationComponentCount ConnectorSavings CoreAssembly
open WheelBaseResidual LiteralWheelCover EmbeddedWheels
open private both sel_mono from RotationSpan
open private required_data from ResidualIncidence
private theorem req_tags : ∀p∈representatives,full (src p) ∧ tag (src p)=classKey p := by
  native_decide

private theorem actual {w : Block} (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) :
    let X:=bag w-mandatory (complete w)
    Feasible X (w.take 6) (w.drop (w.length-6)) ∧ X.card=854 := by
  obtain ⟨ws,_,num,_,flow,mass⟩:=actual_spare (Inserts.stop w) vis (by omega)
  have nil:ws=[]:=List.length_eq_zero_iff.mp (by simpa using num)
  simp only [nil,turns,List.flatMap_nil,Multiset.coe_nil,add_zero] at flow mass
  exact ⟨flow,by omega⟩

/-- Globally, at most 42 classes touch more than one component of a feasible residual. -/
theorem shared_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤854) :
    (allClasses.filter (fun c=>2≤(attachments X s c).card)).card≤42 := by
  classical
  have dual := dual_rank h
  have price := GlobalClosedPrice.rank_price h
  have fee (q) (_:q∈occupied X s) : 3 ≤ GlobalClosedPrice.fee ((part X q).card) := by
    unfold GlobalClosedPrice.fee; omega
  have spent:=Finset.sum_le_sum fee
  simp only [Finset.sum_const,smul_eq_mul] at spent
  let shared:=allClasses.filter (fun c=>2≤(attachments X s c).card)
  have each (c) (hc:c∈shared) : 1≤(attachments X s c).card-1 :=
    by have := (Finset.mem_filter.mp hc).2; omega
  have z := Finset.sum_le_sum each
  simp only [Finset.sum_const,smul_eq_mul,mul_one] at z
  have upper:=Finset.sum_le_sum_of_subset (f:=fun c=>(attachments X s c).card-1)
    (Finset.filter_subset (fun c=>2≤(attachments X s c).card) allClasses)
  have n:=Window597.outside42 h bd
  change shared.card≤42
  change (∑c∈shared,((attachments X s c).card-1))≤_ at upper
  have tally : shared.card+719≤(occupied X s).card+separateRank X s :=
    (Nat.add_le_add_right (z.trans upper) 719).trans dual
  by_cases tight : separateRank X s≤719 <;> omega

/-- Keep just the original completed classes touching at least two residual components. -/
private theorem keep_shared {w : Block} {X : Multiset Block} (long : 6≤w.length)
    (split : X+mandatory (complete w)=bag w) :
    let s:=w.take 6
    let A:=(complete w).filter (fun c=>2≤(attachments X s c).card)
    ∀v∈terminals X s,label (selected X A) v=label (selected X A) s := by
  classical
  let s:=w.take 6
  let A:=(complete w).filter (fun c=>2≤(attachments X s c).card)
  let Z:=selected X A
  let home (v : Block) := label Z v=label Z s
  let small (v : Block) := full v ∧ tag v∈complete w ∧ (attachments X s (tag v)).card≤1
  let P (v : Block) := if small v then
    ∀u∈terminals X s,full u → tag u=tag v → home u else home v
  have agree (v) (hv:v∈terminals X s) : P v ↔ home v := by
    by_cases test:small v
    · rw [show P v = _ from ite_eq_left test]
      refine ⟨fun all=>all v hv test.1 rfl,?_⟩
      intro hh u hu fu eq
      have atU : label X u∈attachments X s (tag v) :=
        Finset.mem_image.mpr ⟨u,Finset.mem_filter.mpr ⟨hu,fu,eq⟩,rfl⟩
      have atV : label X v∈attachments X s (tag v) :=
        Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨hv,test.1,rfl⟩,rfl⟩
      exact (label_lift (Multiset.le_add_right X (mandatory A))
        (Finset.card_le_one.mp test.2.2 _ atU _ atV)).trans hh
    · change (if small v then _ else _) ↔ _
      simp [test]
  have step (e) (he:e∈windows w) (start:P (src e)) : P (dst e) := by
    have all:e∈X+mandatory (complete w):=split ▸ (show e∈bag w from he)
    rcases Multiset.mem_add.mp all with inX|mand
    · obtain ⟨l,r⟩:=both s inX
      apply (agree _ r).mpr
      exact (on_edge (Multiset.mem_add.mpr (Or.inl inX) : e∈Z)).symm.trans ((agree _ l).mp start)
    · obtain ⟨rep,sel⟩:=Multiset.mem_filter.mp mand
      obtain ⟨fs,fd,same⟩:=required_data e rep
      have key:= (req_tags e rep).2
      by_cases many:2≤(attachments X s (classKey e)).card
      · have keep:e∈Z:=Multiset.mem_add.mpr (Or.inr (Multiset.mem_filter.mpr
          ⟨rep,Finset.mem_filter.mpr ⟨sel,many⟩⟩))
        have left:¬small (src e):=by intro m; have := m.2.2; rw [key] at this; omega
        have right:¬small (dst e):=by intro m; have := m.2.2; rw [←same,key] at this; omega
        simpa only [P,ite_eq_right right,home] using (on_edge keep).symm.trans
          (show home (src e) by simpa only [P,ite_eq_right left] using start)
      · have l:small (src e):=⟨fs,key ▸ sel,by rw [key]; omega⟩
        have r:small (dst e):=⟨fd,same ▸ l.2.1,same ▸ l.2.2⟩
        simpa only [P,ite_eq_left l,ite_eq_left r,same] using start
  have init:P s:=(agree s (Finset.mem_insert_self ..)).mpr rfl
  have reach:=(read_route w long).closed {v|P v} init step
  change ∀v∈terminals X s,home v
  intro v hv
  apply (agree v hv).mp
  rcases Finset.mem_insert.mp hv with rfl|rest
  · exact init
  rcases Finset.mem_union.mp rest with beg|fin
  · obtain ⟨e,he,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp beg)
    exact reach.2 _ (show e∈bag w from split ▸ Multiset.mem_add.mpr (Or.inl he))
  · obtain ⟨e,he,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp fin)
    have old:e∈bag w:=split ▸ Multiset.mem_add.mpr (Or.inl he)
    exact step e old (reach.2 e old)

/-- Spelling with a prescribed completion set keeps every residual edge, with multiplicity. -/
private theorem prescribe {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (cost : X.card=854) {D : Finset Block} (legal : D⊆allClasses)
    (connect : ∀v∈terminals X s,label (selected X D) v=label (selected X D) s) :
    ∃z : Block,z.take 6=s ∧ bag z=X+mandatory D ∧ z.length=860+7*D.card ∧
      (visited z).card=720 ∧ complete z=D := by
  classical
  let Z:=selected X D
  obtain ⟨num,cycle⟩:=mandatory_data D legal
  have bal : Z.map src+{t}=Z.map dst+{s} := by
    change (X+mandatory D).map src+{t}=(X+mandatory D).map dst+{s}
    simp only [Multiset.map_add,cycle]
    simpa only [add_right_comm] using congrArg (·+(mandatory D).map dst) h.balance
  obtain ⟨a,b,es,bagEq,trail,_,endInfo⟩:=component_route bal s
  obtain ⟨ha,hb⟩:=endInfo.1 rfl
  subst a; subst b
  have access (e) (he:e∈Z) : label Z (src e)=label Z s := by
    rcases Multiset.mem_add.mp he with residual|cycleEdge
    · exact connect _ (both s residual).1
    · obtain ⟨perm,inD⟩:=Multiset.mem_filter.mp cycleEdge
      obtain ⟨v,hv,fv,key⟩:=every_tag h (legal inD)
      obtain ⟨fs,se⟩:=req_tags e perm
      exact (join_same (X:=X) fs fv (se.trans key.symm) (se ▸ inD)).trans (connect v hv)
  have whole : part Z (label Z s)=Z := Multiset.filter_eq_self.mpr access
  have wb : (↑es : Multiset Block)=Z := bagEq.trans whole
  have width (e) (he:e∈es) : e.length=7 := by
    rcases Multiset.mem_add.mp (wb ▸ (show e∈(↑es : Multiset Block) from he)) with residual|cycleEdge
    · exact h.edges_seven e residual
    · exact ((mem_reps _).mp (Multiset.mem_filter.mp cycleEdge).1).1
  obtain ⟨z,len,head,win⟩:=spell_route trail h.start_six width
  have exactBag : bag z=X+mandatory D := by change (↑(windows z) : Multiset Block)=_; rw [win]; exact wb
  have edgeNum:=congrArg Multiset.card wb
  change es.length=(X+mandatory D).card at edgeNum
  rw [Multiset.card_add,cost,num] at edgeNum
  have zlen : z.length=860+7*D.card := by omega
  have seen : allClasses⊆visited z := by
    intro c hc
    obtain ⟨v,hv,fv,key⟩:=every_tag h hc
    have hit:=ResidualRoutes.visits rfl trail bagEq (connect v hv)
    exact (mem_visited _ _).mpr ⟨v,by simpa [anchors,head,win] using hit,fv,key⟩
  have vis : (visited z).card=720 := by rw [Finset.Subset.antisymm (visited_subset z) seen,board]
  have incl : D⊆complete z := by
    intro c hc
    apply (mem_complete z c).mpr
    refine ⟨legal hc,?_⟩
    intro p hp key
    change p∈bag z
    rw [exactBag]
    exact Multiset.mem_add.mpr (Or.inr (Multiset.mem_filter.mpr ⟨hp,key ▸ hc⟩))
  have floor:=Core1224.expansion_floor z (by omega) vis
  have ceiling:=Finset.card_le_card (complete_subset z)
  refine ⟨z,head,exactBag,zlen,vis,(Finset.eq_of_subset_of_card_le incl ?_).symm⟩
  omega

/-- Every candidate has a set of at most 42 sufficient choices. Every completion
set containing that set can be realized with its original residual edge multiset. -/
theorem exact_family (w : Block) (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) :
    ∃ A⊆complete w,A.card≤42 ∧ ∀D : Finset Block,A⊆D → D⊆allClasses →
      ∃z : Block,z.take 6=w.take 6 ∧ bag z=(bag w-mandatory (complete w))+mandatory D ∧
        z.length=860+7*D.card ∧ (visited z).card=720 ∧ complete z=D := by
  classical
  let X:=bag w-mandatory (complete w)
  let s:=w.take 6
  let A:=(complete w).filter (fun c=>2≤(attachments X s c).card)
  have split : X+mandatory (complete w)=bag w := tsub_add_cancel_of_le (mandatory_in_bag w)
  have ⟨flow,cost⟩:=actual size vis done
  have ca:complete w⊆allClasses := (complete_subset w).trans (visited_subset w)
  have bound:=shared_limit flow cost.le
  have sub:A⊆allClasses.filter (fun c=>2≤(attachments X s c).card) := Finset.filter_subset_filter _ ca
  refine ⟨A,Finset.filter_subset ..,(Finset.card_le_card sub).trans bound,?_⟩
  intro D keep legal
  apply prescribe flow cost legal
  intro v hv
  exact label_lift (sel_mono X keep) (keep_shared (by omega : 6≤w.length) split v hv)

/-- One original completion can always be removed without losing any other.
The same choice can be exchanged for any of the 672 unfinished classes. -/
theorem one_exchange (w : Block) (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) :
    ∃c∈complete w,
      (∃ z : Block,z.take 6=w.take 6 ∧ z.length=1189 ∧ (visited z).card=720 ∧
        complete z=(complete w).erase c ∧
        bag z=(bag w-mandatory (complete w))+mandatory ((complete w).erase c)) ∧
      ∀ d∈allClasses,d∉complete w →
        ∃ y : Block,y.take 6=w.take 6 ∧ y.length=1196 ∧ (visited y).card=720 ∧
          complete y=insert d ((complete w).erase c) ∧
          bag y=(bag w-mandatory (complete w))+mandatory (insert d ((complete w).erase c)) := by
  classical
  obtain ⟨A,sub,cap,prescribe⟩:=exact_family w size vis done
  obtain ⟨c,hc,out⟩:=Finset.exists_mem_notMem_of_card_lt_card (show A.card<(complete w).card by omega)
  let S:=(complete w).erase c
  have stay:A⊆S:=by
    intro a ha
    exact Finset.mem_erase.mpr ⟨fun eq=>out (eq ▸ ha),sub ha⟩
  have smaller:S.card=47:=by rw [Finset.card_erase_of_mem hc,done]
  have legal:S⊆allClasses:=(Finset.erase_subset ..).trans ((complete_subset w).trans (visited_subset w))
  obtain ⟨z,head,bg,sz,vz,cz⟩:=prescribe S stay legal
  refine ⟨c,hc,⟨z,head,by omega,vz,cz,bg⟩,?_⟩
  intro d hd missing
  obtain ⟨y,home,bagY,len,seen,completeY⟩:=prescribe (insert d S) (stay.trans (Finset.subset_insert ..)) (Finset.insert_subset hd legal)
  have fresh:d∉S:=fun yes=>missing (Finset.erase_subset _ _ yes)
  rw [Finset.card_insert_of_notMem fresh,smaller] at len
  exact ⟨y,home,by omega,seen,completeY,bagY⟩

/-- Fill any allowed number of the 48 completion positions with a fixed subset of
the original choices, then freely fill the remaining positions from the board. -/
private theorem counted_sets (k : Nat) (enough : 42≤k) (fits : k≤48)
    (w : Block) (size : w.length=1196) (vis : (visited w).card=720) (done : (complete w).card=48) :
    ∃ F : Finset (Finset Block), F.card=Nat.choose (720-k) (48-k) ∧ ∀D∈F,
      ∃z : Block,z.take 6=w.take 6 ∧ z.length=1196 ∧ (visited z).card=720 ∧ complete z=D ∧
        bag z=(bag w-mandatory (complete w))+mandatory D := by
  classical
  obtain ⟨A,sub,cap,family⟩:=exact_family w size vis done
  obtain ⟨K,fixed,old,kcard⟩:=Finset.exists_subsuperset_card_eq sub (cap.trans enough) (show k≤(complete w).card by omega)
  have legal:=old.trans ((complete_subset w).trans (visited_subset w))
  let choices:=(allClasses \ K).powersetCard (48-k)
  let form (u : Finset Block) := K∪u
  have apart {u : Finset Block} (hu:u∈choices) (x) (hx:x∈u) : x∉K :=
    (Finset.mem_sdiff.mp ((Finset.mem_powersetCard.mp hu).1 hx)).2
  have unique : Set.InjOn form (↑choices : Set (Finset Block)) := by
    intro a ha b hb eq
    ext x
    have transfer:=congrArg (fun U : Finset Block=>x∈U) eq
    change (x∈K∪a)=(x∈K∪b) at transfer
    rw [Finset.mem_union,Finset.mem_union] at transfer
    constructor
    · intro hx
      exact (transfer ▸ (show x∈K ∨ x∈a from Or.inr hx)).resolve_left (apart ha _ hx)
    · intro hx
      exact (transfer.symm ▸ (show x∈K ∨ x∈b from Or.inr hx)).resolve_left (apart hb _ hx)
  refine ⟨choices.image form,?_,?_⟩
  · rw [Finset.card_image_of_injOn unique]
    change ((allClasses \ K).powersetCard (48-k)).card=Nat.choose (720-k) (48-k)
    rw [Finset.card_powersetCard,Finset.card_sdiff_of_subset legal,board,kcard]
  · intro D hd
    obtain ⟨u,hu,rfl⟩:=Finset.mem_image.mp hd
    obtain ⟨inside,picked⟩:=Finset.mem_powersetCard.mp hu
    have keep:A⊆form u:=fixed.trans Finset.subset_union_left
    have permitted:form u⊆allClasses:=Finset.union_subset legal (inside.trans Finset.sdiff_subset)
    have dis:Disjoint K u:=by
      apply Finset.disjoint_left.mpr
      intro x hK hu'
      exact apart hu x hu' hK
    have total:(form u).card=48:=by
      change (K∪u).card=48
      rw [Finset.card_union_of_disjoint dis,kcard,picked]
      omega
    obtain ⟨z,head,bg,len,view,hits⟩:=family (form u) keep permitted
    exact ⟨z,head,by omega,view,hits,bg⟩

theorem many_sets (w : Block) (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) :
    ∃ F : Finset (Finset Block), F.card=226801 ∧ ∀D∈F,
      ∃z : Block,z.take 6=w.take 6 ∧ z.length=1196 ∧ (visited z).card=720 ∧ complete z=D ∧
        bag z=(bag w-mandatory (complete w))+mandatory D := by
  obtain ⟨F,count,make⟩ := counted_sets 46 (by decide) (by decide) w size vis done
  refine ⟨F, count.trans ?_, make⟩
  rw [Nat.choose_eq_descFactorial_div_factorial]
  decide

/-- Preserve 42 original classes and choose any six of the remaining 678. -/
theorem many_sets_six (w : Block) (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) :
    ∃ F : Finset (Finset Block), F.card=131950577604105 ∧ ∀D∈F,
      ∃z : Block,z.take 6=w.take 6 ∧ z.length=1196 ∧ (visited z).card=720 ∧ complete z=D ∧
        bag z=(bag w-mandatory (complete w))+mandatory D := by
  obtain ⟨F,count,make⟩ := counted_sets 42 (by decide) (by decide) w size vis done
  refine ⟨F, count.trans ?_, make⟩
  rw [Nat.choose_eq_descFactorial_div_factorial]
  decide

/-- Up to six rotation classes may be prescribed in advance, independently of w. -/
theorem prescribe_six (w : Block) (size : w.length=1196) (vis : (visited w).card=720)
    (done : (complete w).card=48) (T : Finset Block) (boardT : T⊆allClasses) (quota : T.card≤6) :
    ∃z : Block,z.take 6=w.take 6 ∧ z.length=1196 ∧ (visited z).card=720 ∧
      (complete z).card=48 ∧ T⊆complete z ∧
      bag z=(bag w-mandatory (complete w))+mandatory (complete z) := by
  classical
  obtain ⟨A,sub,cap,family⟩:=exact_family w size vis done
  have allowed:=Finset.union_subset (sub.trans ((complete_subset w).trans (visited_subset w))) boardT
  have small: (A∪T).card≤48:=by have := Finset.card_union_le A T; omega
  obtain ⟨D,retain,legal,n⟩:=Finset.exists_subsuperset_card_eq allowed small (by rw [board]; decide)
  obtain ⟨z,head,wins,sz,all,hits⟩:=family D (Finset.subset_union_left.trans retain) legal
  refine ⟨z,head,by omega,all,by rw [hits,n],?_,?_⟩
  · rw [hits]; exact Finset.subset_union_right.trans retain
  · simpa only [hits] using wins

#print axioms many_sets_six
#print axioms prescribe_six
#print axioms many_sets
#print axioms one_exchange
#print axioms shared_limit
#print axioms exact_family
end ExactWordFlow.CompletionExchange

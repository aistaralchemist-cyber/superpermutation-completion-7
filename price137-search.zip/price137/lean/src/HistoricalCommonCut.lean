import HistoricalTransfer
import CutWitness

namespace ExactWordFlow.HistoricalTransfer
open SevenWordWindows RotationCore
open SuperpermLowerBounds SuperpermLowerBounds.T5899 SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain

/-- The common geometric test is precisely the old effective-index-one weight and
price budget, together with coverage and a strengthened geometric price interval. -/
def CommonCut (M : Nat) : Prop :=
  ∃ (G : List (List (NRow 7))) (p : List WheelPacket),
    TrailFam 7 G ∧ G.length=M ∧
    (let entries := rowsEntries G.flatten ++ p.flatMap WheelPacket.cells
     entries.length=720 ∧ entries.Pairwise (NotRot (k:=7)) ∧
       ∀ v : Vtx 7, ∃ x∈entries, (v : List ℕ) ~r (x : List ℕ)) ∧
    rowsHoles 7 G.flatten+6*M≤102 ∧
    (SevenOmission.deficit (widths p):ℤ)+35+5*(M:ℤ)≤
      (G.flatten.length:ℤ)-(rowsHoles 7 G.flatten:ℤ) ∧
    135≤G.flatten.length+M+p.length ∧ G.flatten.length+M+p.length≤137

/-- Cut q-1 old seams, retaining every ordered row and every omitted wheel
packet. Both cost-135 and cost-136 configurations yield this same test. -/
theorem common_of_configuration (c : NConfig 7) (hv : c.Valid)
    {q : Nat} (idx : q+c.cost=epsC c+137) (pos : 1≤q) :
    CommonCut (trails c+(q-1)) := by
  have valid := famC_trailFam hv
  obtain ⟨lo,hi⟩ := shifted_accounts c hv idx
  rw [lE_prs] at lo
  rw [lW_prs] at hi
  let link := fun a b : NRow 7 => SLink 7 3 a.lastEntry b.entry
  have good : Seventeen.Good link (famC c) := fun T hT =>
    ⟨(valid.trails T hT).ne,(valid.trails T hT).seams⟩
  obtain ⟨G,whole,same,size⟩ := Seventeen.cuts good (q-1) (by omega)
  have family : TrailFam 7 G := by
    constructor
    · intro T ht
      obtain ⟨ne,links⟩ := whole T ht
      refine ⟨ne,?_,links⟩
      intro row mem
      have member : row∈G.flatten := List.mem_flatten.mpr ⟨T,ht,mem⟩
      rw [same] at member
      obtain ⟨old,inF,inOld⟩ := List.mem_flatten.mp member
      exact (valid.trails old inF).len row inOld
    · rw [same]
      exact valid.classes
  obtain ⟨p,part,lower,upper,de⟩ := packet_accounts c hv idx
  refine ⟨G,p,family,size,?_,?_,?_,?_,?_⟩
  · dsimp only
    rw [same]
    refine ⟨part.length_eq.trans (exact_entries c hv),pairwise_of_perm hv.distinct part,?_⟩
    intro v
    obtain ⟨x,mem,rot⟩ := hv.cover v
    exact ⟨x,part.mem_iff.mpr mem,rot⟩
  all_goals rw [same]
  all_goals simp only [trails,holes,rows] at *
  all_goals omega

/-- No earlier exclusions from length 5,901 or 5,904 and no new geometric cap
assumptions are needed for this implication from the original partial word. -/
theorem word_to_common {w : Block} (len : w.length=1196) (all : (visited w).card=720)
    (done : (complete w).card=48) : ∃ M : Nat, 1≤M ∧ M≤11 ∧ CommonCut M := by
  obtain ⟨c,q,_,hv,_,hi,idx,_,count,_⟩ := actual_transfer len all done
  have pos : 1≤q := by omega
  have nonempty := (kernel_ok hv).pos
  have minCount : 1≤trails c := by
    unfold trails famC
    rw [List.length_append]
    omega
  exact ⟨_,by omega,by omega,common_of_configuration c hv idx pos⟩

/-- The endpoints are *geometric* exclusions of disjoint trails: no reference
to actual excess, dropped attachments, the starting kernel or word length. -/
theorem word_to_eight_of_caps
    (one : TrailCap 1 96 40) (ten : TrailCap 10 42 85) (eleven : TrailCap 11 36 90)
    {w : Block} (len : w.length=1196) (all : (visited w).card=720)
    (done : (complete w).card=48) : ∃ M : Nat, 2≤M ∧ M≤9 ∧ CommonCut M := by
  obtain ⟨M,lo,hi,test⟩ := word_to_common len all done
  have saved := test
  obtain ⟨G,p,hg,sz,_,weight,value,_⟩ := test
  have d : 0≤(SevenOmission.deficit (widths p):ℤ) := by exact_mod_cast Nat.zero_le _
  have no (i b v : Nat) (cap : TrailCap i b v) (eq : M=i)
      (h : rowsHoles 7 G.flatten≤b) (val : (v:ℤ)≤(G.flatten.length:ℤ)-(rowsHoles 7 G.flatten:ℤ)) :
      False := (not_lt_of_ge val) (cap G hg (sz.trans eq) h)
  have a : M≠1 := fun h => no 1 96 40 one h (by omega) (by omega)
  have b : M≠10 := fun h => no 10 42 85 ten h (by omega) (by omega)
  have c : M≠11 := fun h => no 11 36 90 eleven h (by omega) (by omega)
  exact ⟨M,by omega,by omega,saved⟩

#print axioms word_to_common
#print axioms word_to_eight_of_caps
end ExactWordFlow.HistoricalTransfer

#!/bin/sh
# Re-elaborate the three endpoints against a previously built dependency closure.
set -eu
: "${LEAN_PATH:?Set LEAN_PATH to the dependencies built with Lean 4.35.0}"
bin=${LEAN:-lean}
case "$("$bin" --version)" in
  *"version 4.35.0,"*) ;;
  *) echo "Lean 4.35.0 is required" >&2; exit 1 ;;
esac
src=$(CDPATH='' cd -- "$(dirname -- "$0")/src" && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/price137-endpoints.XXXXXXXX")
trap 'rm -rf "$tmp"' EXIT
export LEAN_PATH="$tmp:$LEAN_PATH"
for name in ExactPrice137 Price137NoFives Price137FullRuns; do
  echo "Checking $name"
  "$bin" --root="$src" -o "$tmp/$name.olean" "$src/$name.lean"
done

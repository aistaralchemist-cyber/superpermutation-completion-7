"""Stage the exact-price reduction as a clean Lean 4.35.0 Lake project."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
SITE = "a09f9ef4ebb74ae1297f17c5fad38296695f2959"
RESEARCH = "8e3c02b5234b49a1422751f86f9e472706082374"
ARCHIVE = "0f58e7441ccd42c12119ebb988d9874f30822863b93d31e5463b0e03c90c41fd"
MARKER = b"  ring_nf\n  exact le_refl _\n\n/-! ### Rule PREV"
PORT = b"  ring_nf\n  all_goals by_cases hy : y.1 = 0 <;> simp [hy] <;> nlinarith\n\n/-! ### Rule PREV"


def git_file(checkout, revision, path):
    return subprocess.check_output(["git", "-C", str(checkout), "show", f"{revision}:{path}"])


def verify(content, expected, name):
    if hashlib.sha256(content).hexdigest() != expected:
        raise ValueError(f"unexpected digest for {name}")


def prepare(args):
    with (HERE / "sources.tsv").open(encoding="utf-8") as manifest:
        rows = list(csv.DictReader(manifest, delimiter="\t"))
    verify(args.archive.read_bytes(), ARCHIVE, args.archive)
    research = args.research.resolve()
    record = git_file(research, RESEARCH, "ties/7/7-5905-071.txt").strip()
    verify(record, "2ddccaaf6223493639fdbcc0c8c89cde9bf73410037a96d07830fbd62ab2302c",
           "7-5905-071")
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError("select an empty or new output directory")
    # The base stays separate from the working checkouts. Git restores its notices and licenses.
    subprocess.run(["git", "clone", "--quiet", "--no-checkout", "--no-hardlinks", "--",
                    str(args.site.resolve()), str(output)], check=True)
    subprocess.run(["git", "-C", str(output), "checkout", "--quiet", "--detach", SITE], check=True)
    roots = []
    with ZipFile(args.archive) as archive:
        for row in rows:
            dest = output / row["target"]
            if dest.exists():
                raise ValueError(f"refusing to overwrite existing source {row['target']}")
            name, provider = row["source"], row["provider"]
            if provider == "overlay":
                data = (HERE / "src" / dest.name).read_bytes()
            elif provider == "archive":
                data = archive.read(name)
            elif provider == "record":
                template = archive.read(name)
                marker = b"__FETCH_EXTERNAL_RECORD_071__"
                if template.count(marker) != 1:
                    raise ValueError("comparison-word template changed")
                data = template.replace(marker, record)
            elif provider == "halfar":
                data = git_file(research, RESEARCH, name)
                if row["target"] == "LowerBounds/J16Rules.lean":
                    if data.count(MARKER) != 1:
                        raise ValueError("Lean 4.35 compatibility patch did not match")
                    data = data.replace(MARKER, PORT)
            else:
                raise ValueError(f"unknown source provider {provider}")
            verify(data, row["sha256"], name)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            if dest.suffix == ".lean" and dest.parent == output:
                roots.append(dest.stem)
    with (output / "lakefile.toml").open("a", encoding="utf-8") as config:
        config.write('\n[[lean_lib]]\nname = "Price137Study"\nroots = ' +
                     json.dumps(roots) + '\n')
    for filename in ("NOTICE", "LICENSE"):
        (output / f"HALFAR-RESEARCH-{filename}").write_bytes(git_file(research, RESEARCH, filename))
    modules = sum(row["target"].endswith(".lean") for row in rows)
    print(f"Staged and checked {modules} Lean modules and {len(rows)-modules} data files in {output}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True, help="seven-symbol-verification.zip")
    parser.add_argument("--site", type=Path, required=True, help="clone of superpermutation-almanac-lean")
    parser.add_argument("--research", type=Path, required=True, help="clone of Halfar's superpermutations")
    parser.add_argument("--output", type=Path, required=True, help="empty or new staging directory")
    prepare(parser.parse_args())

#define DENSE_GEOMETRY_ONLY
#include "check_dense_holes.cpp"
#include <fstream>

int main() {
    Geometry geometry;
    AnchorReach reach(geometry);
    std::map<Profile,bool> records;
    std::string line;
    int total=0, feasible=0, direct=0, coreReject=0;
    while (std::getline(std::cin,line)) {
        std::istringstream in(line);
        Profile family;
        Kind k;
        while (in >> k.first >> k.second) {
            if(k.first<0 || k.first>maxHoles || k.second<1 || k.second>cap[k.first])
                throw std::runtime_error("invalid trail");
            family.push_back(k);
        }
        if(family.empty() || !in.eof()) throw std::runtime_error("invalid family");
        std::sort(family.begin(),family.end(),[](Kind a,Kind b){
            return 6*a.second-a.first>6*b.second-b.first;
        });
        bool reject=false;
        for(size_t n=2;n<=family.size();n++) {
            Profile sub(family.begin(),family.begin()+n);
            std::sort(sub.begin(),sub.end());
            auto found=records.find(sub);
            if(found!=records.end()){
                if(!found->second){reject=true;break;}
                continue;
            }
            for(Kind a:sub) geometry.prepare(a);
            bool maybe=reach.possible(sub);
            if(maybe) {++direct;maybe=canPlace(geometry,sub);}
            records.emplace(sub,maybe);
            if(!maybe){reject=true;if(n<family.size())++coreReject;break;}
        }
        if(!reject) {++feasible;std::cout<<"feasible "<<line<<std::endl;}
        ++total;
        if(total%100==0) std::cerr<<total<<" checked, "<<direct<<" packing calls, "<<coreReject<<" new strict cores"<<std::endl;
    }
    std::cout<<"profiles="<<total<<" feasible="<<feasible<<std::endl;
    return feasible?1:0;
}

"""Enumerate one complete deficit layer and replay the disjoint-trail checker."""
import argparse
import hashlib
import sys
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lower', type=Path, help='Haruhi7/lower in the proof project')
    parser.add_argument('checker', type=Path)
    parser.add_argument('epsilon', type=int, choices=[0, 1, 2])
    parser.add_argument('holes', type=int)
    args = parser.parse_args()
    sys.path.insert(0, str(args.lower.resolve()))
    from check_next_counts import profiles, TABLE_HASH

    e = args.epsilon
    h = args.holes
    if not 30+5*e <= h <= 42+6*e:
        parser.error('hole count outside the boundary family')
    data = (args.lower/'capD16_k.txt').read_bytes()
    if hashlib.sha256(data).hexdigest() != TABLE_HASH:
        raise ValueError('unexpected single-trail upper bounds')
    cap = list(map(int, data.splitlines()[0].split(b':')[1].split()))
    entries = [' '.join(f'{k} {r}' for k, r in p) for p in profiles(cap, e, h)]
    feed = ('\n'.join(entries)+'\n').encode() if entries else b''
    print(f'e={e} m={11-2*e} H={h} profiles={len(entries)} '
          f'input_sha256={hashlib.sha256(feed).hexdigest()}', flush=True)
    result = subprocess.run([str(args.checker.resolve())], input=feed,
                            stdout=subprocess.PIPE, check=False)
    output = result.stdout.decode()
    print(output, end='')
    if result.returncode != 0 or output.strip() != f'profiles={len(entries)} feasible=0':
        raise SystemExit('the supplied checker did not certify exclusion')


if __name__ == '__main__':
    main()

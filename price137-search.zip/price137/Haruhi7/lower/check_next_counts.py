"""Check the low-hole portion at 11, 9 or 7 trails."""
import argparse
from collections import Counter
from pathlib import Path
import hashlib
import subprocess
from check_dense_holes import TABLE_HASH

HERE = Path(__file__).resolve().parent


def profiles(cap, epsilon, holes):
    count = 11 - 2 * epsilon
    missing = holes - 30 - 5*epsilon
    kinds = [(h, r, 2*h+5-r)
             for h in range(holes+1)
             for r in range(max(1, 2*h+5-missing), min(2*h+5, cap[h])+1)]
    def visit(remaining, hleft, dleft, start, chosen):
        if remaining == 0:
            if hleft == dleft == 0:
                yield tuple(chosen)
            return
        for i in range(start, len(kinds)):
            h, r, d = kinds[i]
            if h*remaining > hleft:
                break
            if d <= dleft:
                yield from visit(remaining-1, hleft-h, dleft-d, i, chosen+[(h,r)])
    yield from visit(count, holes, missing, 0, [])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('epsilon', type=int, choices=[0,1,2])
    parser.add_argument('--table', type=Path, default=HERE/'capD16_k.txt')
    parser.add_argument('--checker', type=Path)
    parser.add_argument('--through', type=int)
    args = parser.parse_args()
    raw = args.table.read_bytes()
    if hashlib.sha256(raw).hexdigest() != TABLE_HASH:
        raise ValueError('unexpected single-trail bounds')
    cap = list(map(int, raw.splitlines()[0].split(b':')[1].split()))
    e = args.epsilon
    stop = args.through if args.through is not None else [33,40,47][e]
    if not 30+5*e <= stop <= 42+6*e:
        raise ValueError('outside this family')
    cases = [p for h in range(30+5*e,stop+1) for p in profiles(cap,e,h)]
    print('candidate counts', sorted(Counter(sum(h for h,_ in p) for p in cases).items()))
    if args.checker and cases:
        entries = ''.join(' '.join(f'{h} {r}' for h,r in p)+'\n' for p in cases)
        out = subprocess.run([str(args.checker.resolve())], input=entries, capture_output=True,
                             text=True, check=True)
        if out.stdout.strip() != f'profiles={len(cases)} feasible=0':
            raise ValueError(out.stdout[-700:])
        print(out.stdout.strip())

if __name__ == '__main__':
    main()

"""Extract the directed row and packet seeds for the archived seven-letter record."""
import argparse
from itertools import groupby
from pathlib import Path


def rotate(word):
    return word[1:] + word[:1]


def cycle_id(word):
    position = word.index('0')
    return word[position:] + word[:position]


def tau(word):
    return word[1:6] + word[0] + word[6]


def extract(word):
    alphabet = set('0123456')
    assert len(word) == 5905 and set(word) == alphabet
    windows = [i for i in range(len(word) - 6) if set(word[i:i+7]) == alphabet]
    assert windows[0] == 0 and windows[-1] + 7 == len(word)
    assert len(windows) == len({word[i:i+7] for i in windows}) == 5040
    runs = []
    occurrences = {}
    for _, group in groupby(enumerate(windows), key=lambda item: item[1] - item[0]):
        offsets = [i for _, i in group]
        first, last = offsets[0], offsets[-1]
        occurrences.setdefault(cycle_id(word[first:first+7]), []).append(len(runs))
        runs.append((first, last))
    assert len(occurrences) == 720
    assert all(len(visits) in (1, 2) for visits in occurrences.values())
    paired = {v[0]: v[1] for v in occurrences.values() if len(v) == 2}
    packets = []

    def peel(i, stop):
        cells, joins = [], []
        while i < stop:
            j = paired.get(i, i)
            assert i <= j < stop
            if j != i:
                inner, gaps = peel(i + 1, j)
                assert len(inner) == 5 and gaps == [2] * 4
                assert inner[1:] == [tau(x) for x in inner[:-1]]
                before, after = runs[i][1], runs[j][0]
                assert runs[i+1][0] - before == after - runs[j-1][1] == 2
                assert rotate(word[before:before+7]) == word[after:after+7]
                packets.append(inner)
            first, last = runs[i][0], runs[j][1]
            cell = word[first:first+7]
            assert rotate(word[last:last+7]) == cell
            cells.append(cell)
            if j + 1 < stop:
                joins.append(runs[j+1][0] - last)
            i = j + 1
        return cells, joins

    cells, joins = peel(0, len(runs))
    trails = [[[cells[0]]]]
    for previous, cell, gap in zip(cells, cells[1:], joins):
        if gap == 2:
            assert tau(previous) == cell
            trails[-1][-1].append(cell)
        elif gap == 3:
            trails[-1].append([cell])
        else:
            assert gap >= 4
            trails.append([[cell]])
    assert len(trails) == 6 and sum(map(len, trails)) == 70
    assert len(cells) == 390 and len(packets) == 66
    assert 7 + 6 * len(cells) + sum(joins) + 41 * len(packets) == len(word)
    return trails, packets


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('word', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    trails, packets = extract(args.word.read_text().strip())
    rows = [row for trail in trails for row in trail]
    cells = [word for row in rows + packets for word in row]
    assert len(set(map(cycle_id, cells))) == len(cells) == 720
    text = ['import Std', '', 'namespace ScoreWitnessData', '',
            '-- Each row is encoded as (radix-eight entry permutation, width).',
            'def trails : List (List (Nat × Nat)) := [']
    for i, trail in enumerate(trails):
        entries = [f'({int(row[0], 8)}, {len(row)})' for row in trail]
        text.append('  [' + ', '.join(entries) + ('],' if i + 1 < len(trails) else ']]'))
    text.extend(['', '-- Each packet has five consecutive entries under tau.',
                 'def packets : List Nat := ['])
    for i in range(0, len(packets), 10):
        entries = [str(int(row[0], 8)) for row in packets[i:i+10]]
        text.append('  ' + ', '.join(entries) + (',' if i + 10 < len(packets) else ']'))
    args.output.write_text('\n'.join(text + ['', 'end ScoreWitnessData', '']))
    print('Trail row counts:', [len(trail) for trail in trails])
    print('Row classes:', sum(map(len, rows)), 'packet classes:', sum(map(len, packets)))
    print('Distinct cyclic classes:', len(cells))
    print('Cover score:', len(rows) + len(trails) + len(packets))


if __name__ == '__main__':
    main()

"""Enumerate and, optionally, check the least-row profile constraints at m=12−2ε."""
import argparse
import hashlib
from pathlib import Path
import subprocess

TABLE_HASH = 'f508e1e7b0c0147d6c0a22c76748fb63fe31741aee5df6634d9036ad70bf4982'


def profiles(cap, epsilon, total_holes, extra_value=0):
    chains = 12 - 2 * epsilon
    minimum = 30 + 5 * epsilon
    shortage = total_holes - minimum - extra_value
    if shortage < 0:
        return
    types = sorted((h, 2*h + 5 - d, d)
                   for h in range(total_holes + 1) for d in range(shortage + 1)
                   if 1 <= 2*h + 5 - d <= cap[h])

    def append(left, holes, missing, first, partial):
        if left == 0:
            if holes == missing == 0:
                yield tuple(partial)
            return
        for idx in range(first, len(types)):
            h, rows, d = types[idx]
            if h*left > holes:
                break
            if d <= missing:
                partial.append((h, rows))
                yield from append(left - 1, holes - h, missing - d, idx, partial)
                partial.pop()

    yield from append(chains, total_holes, shortage, 0, [])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('epsilon', type=int, choices=range(3))
    parser.add_argument('--holes', type=int, help='one hole level; defaults to all verified levels')
    parser.add_argument('--table', type=Path, default=Path(__file__).with_name('capD16_k.txt'))
    parser.add_argument('--checker', type=Path, help='compiled check_dense_holes.cpp executable')
    parser.add_argument('--raw-exact-cover', action='store_true', help='check full basic trails before minimum-size pruning')
    parser.add_argument('--exact-cover', action='store_true', help='screen and exhaust every full-cover profile')
    parser.add_argument('--parity', action='store_true', help='test occupancy and kind parity at all anchors, for full covers')
    parser.add_argument('--union', action='store_true', help='use the necessary anchor-union filter')
    parser.add_argument('--extra-value', type=int, default=0, choices=[0,1], help='excess above minimum; for actual complement branches')
    parser.add_argument('--emit', action='store_true', help='write profiles only, for a custom checker')
    args = parser.parse_args()
    table = args.table.read_bytes()
    if hashlib.sha256(table).hexdigest() != TABLE_HASH:
        raise ValueError('unexpected Halfar row table')
    cap = list(map(int, table.splitlines()[0].split(b':')[1].split()))
    eps = args.epsilon
    verified = [33, 42, 48]
    levels = [args.holes] if args.holes is not None else range(30 + 5*eps, verified[eps] + 1)
    for holes in levels:
        if not (30 + 5*eps <= holes <= 36 + 6*eps):
            raise ValueError('outside the dense-family arithmetic interval')
        data = [' '.join(f'{h} {r}' for h, r in profile) for profile in profiles(cap, eps, holes, args.extra_value)]
        if args.emit:
            if data:
                print('\n'.join(data))
            continue
        print(f'epsilon={eps} holes={holes} profiles={len(data)}', flush=True)
        if args.checker is not None and data:
            subprocess.run([str(args.checker.resolve())] + (['--raw-exact-cover'] if args.raw_exact_cover else (['--parity'] if args.parity else (['--union'] if args.union else (['--exact-cover'] if args.exact_cover or holes == 36 + 6*eps else [])))), input='\n'.join(data) + '\n', text=True, check=True)


if __name__ == '__main__':
    main()

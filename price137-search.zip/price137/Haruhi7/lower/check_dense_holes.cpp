// Exhaustively pack least-row seven-symbol trails for a supplied sequence of profiles.
// Generate all input profiles using check_dense_holes.py and Halfar’s published row cap.
// The permutation/row generation follows the local check_six_trails.cpp implementation.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <map>
#include <set>
#include <utility>
#include <tuple>
#include <vector>

using Word = std::array<int, 7>;
using Mask = std::array<std::uint64_t, 12>;
using Kind = std::pair<int, int>; // holes, rows
using Profile = std::vector<Kind>;

static constexpr int maxHoles = 54;
// Halfar's Mtab, LowerBounds/PTables.lean, truncated to the budget of 54.
static constexpr int cap[] = {
    5,5,9,9,13,13,16,16,20,20,24,24,27,27,31,31,34,34,36,38,40,41,
    43,44,46,47,50,51,52,54,56,57,59,60,63,64,66,66,68,69,71,72,
    74,75,77,79,80,82,83,85,85,86,88,89,91};
static_assert(sizeof(cap)/sizeof(*cap) == maxHoles+1);

class Geometry {
public:
    struct Type {
        std::vector<Mask> normalized, placements;
    };
    std::map<Kind, Type> types;

    explicit Geometry(bool least=true) : leastRows(least) {
        Word p{0,1,2,3,4,5,6};
        std::map<Word, int> wordId, circleId;
        std::vector<Word> words;
        do {
            wordId.emplace(p, words.size());
            words.push_back(p);
            if (p[0] == 0) circleId.emplace(p, circleId.size());
        } while (std::next_permutation(p.begin(), p.end()));
        for (int i = 0; i < 5040; ++i) {
            p = words[i];
            classes[i] = circleId.at(canonical(p));
            for (int j = 0; j < 6; ++j) {
                rows[i][j] = wordId.at(p);
                std::rotate(p.begin(), p.begin()+1, p.begin()+6);
            }
            std::rotate(p.begin(), p.end()-1, p.end());
            Word t{p[3],p[4],p[5],p[6],p[0],p[1],p[2]};
            std::sort(t.begin()+4, t.end());
            int j = 0;
            do {
                joins[i][j++] = wordId.at(t);
            } while (std::next_permutation(t.begin()+4, t.end()));
        }
        for (const auto &g : words) {
            std::array<int,720> action{};
            for (const auto &[circle,id] : circleId) {
                Word t = circle;
                for (int &letter : t) letter = g[letter];
                action[id] = circleId.at(canonical(t));
            }
            actions.push_back(action);
        }
    }

    void prepare(Kind kind) {
        if (types.count(kind)) return;
        auto &type = types[kind];
        const int holes=kind.first, target=kind.second;
        std::set<Mask> templates;
        auto extend = [&](auto self, int start, int remaining, int left, Mask used) -> void {
            if (remaining > cap[left] || target-remaining > cap[holes-left]) return;
            // A least-row family cannot have a removable nonpositive proper prefix or suffix.
            if (leastRows && remaining < target && (target-remaining <= holes-left || remaining <= left)) return;
            for (int length = 1; length <= 6; ++length) {
                int entry = rows[start][length-1], c = classes[entry];
                std::uint64_t b = std::uint64_t{1} << (c%64);
                if (used[c/64] & b) break;
                used[c/64] |= b;
                if (leastRows && length == 5 && target >= 2) continue; // its two four-symbol boundary words coincide
                int after = left-(6-length);
                if (after < 0 || after > 5*(remaining-1)) continue;
                if (remaining == 1) templates.insert(used);
                else if (remaining-1 <= cap[after])
                    for (int next : joins[entry]) self(self,next,remaining-1,after,used);
            }
        };
        extend(extend,0,target,holes,{});
        type.normalized.assign(templates.begin(),templates.end());
        std::set<Mask> placements;
        for (const Mask &m : templates) {
            std::vector<int> occupied;
            for (int i=0;i<720;++i) if ((m[i/64]>>(i%64))&1) occupied.push_back(i);
            for (const auto &action : actions) {
                Mask n{};
                for (int i : occupied) {
                    int j = action[i];
                    n[j/64] |= std::uint64_t{1} << (j%64);
                }
                placements.insert(n);
            }
        }
        type.placements.assign(placements.begin(),placements.end());
    }

private:
    bool leastRows;
    std::array<std::array<int,6>,5040> rows{}, joins{};
    std::array<int,5040> classes{};
    std::vector<std::array<int,720>> actions;
    static Word canonical(Word p) {
        std::rotate(p.begin(),std::find(p.begin(),p.end(),0),p.end());
        return p;
    }
    static bool disjoint(const Mask &a,const Mask &b) {
        for (size_t i=0;i<a.size();++i) if (a[i]&b[i]) return false;
        return true;
    }
};

using Bits = std::vector<std::uint64_t>;

bool disjointMasks(const Mask &a, const Mask &b) {
    for (size_t i=0; i<a.size(); ++i) if (a[i] & b[i]) return false;
    return true;
}

int cardinality(const Mask &mask) {
    int total=0;
    for (auto word : mask) total += __builtin_popcountll(word);
    return total;
}

// Keep only positions from [lo,hi) in block number word.
std::uint64_t restrictBlock(std::uint64_t value, int word, int lo, int hi) {
    if (64*word < lo) value &= ~std::uint64_t(0) << (lo%64);
    if (64*word+63 >= hi && hi%64) value &= (std::uint64_t(1) << (hi%64))-1;
    return value;
}

class Packing {
    using Candidates = std::vector<std::vector<const Mask*>>;
    std::vector<const Mask*> shape;
    std::vector<std::pair<int,int>> span;
    std::vector<int> mass;
    std::vector<Bits> compatible;

    int count(int kind, const Bits &available) const {
        auto [lo,hi]=span[kind];
        int result=0;
        for (int w=lo/64; w<(hi+63)/64; ++w)
            result += __builtin_popcountll(restrictBlock(available[w],w,lo,hi));
        return result;
    }

    bool enoughUnion(const std::vector<int> &needed, const Bits &available, int required) const {
        Mask united{};
        for (size_t i=0; i<needed.size(); ++i) if (needed[i]) {
            auto [lo,hi]=span[i];
            for (int w=lo/64; w<(hi+63)/64; ++w) {
                auto bits=restrictBlock(available[w],w,lo,hi);
                while (bits) {
                    const auto &candidate=*shape[64*w+__builtin_ctzll(bits)];
                    bits &= bits-1;
                    for (size_t j=0; j<united.size(); ++j) united[j] |= candidate[j];
                }
            }
            if (cardinality(united)>=required) return true;
        }
        return false;
    }

    bool extend(std::vector<int> &needed, const Bits &available) {
        int next=-1, nextCount=0, required=0, options=0;
        for (int i=0; i<int(needed.size()); ++i) if (needed[i]) {
            int remaining=count(i,available);
            if (remaining<needed[i]) return false;
            required += needed[i]*mass[i];
            options += remaining;
            if (next<0 || remaining*needed[next]<nextCount*needed[i]) {
                next=i;
                nextCount=remaining;
            }
        }
        if (next<0) return true;
        // Disjoint remaining shapes need required distinct classes in their union.
        // The threshold affects speed. Above it this optional rejection is skipped.
        if (options<=540 && !enoughUnion(needed,available,required)) return false;

        auto [lo,hi]=span[next];
        --needed[next];
        Bits child(available.size());
        for (int w=lo/64; w<(hi+63)/64; ++w) {
            auto alternatives=restrictBlock(available[w],w,lo,hi);
            while (alternatives) {
                int j=64*w+__builtin_ctzll(alternatives);
                alternatives &= alternatives-1;
                for (size_t k=0; k<child.size(); ++k) child[k]=available[k]&compatible[j][k];
                // Equal types may be placed in increasing order of rank.
                if (needed[next]) for (int k=lo/64; k<=j/64; ++k)
                    child[k] &= ~restrictBlock(~std::uint64_t(0),k,lo,j+1);
                if (extend(needed,child)) { ++needed[next]; return true; }
            }
        }
        ++needed[next];
        return false;
    }

public:
    explicit Packing(const Candidates &groups) {
        for (const auto &group : groups) {
            int lo=int(shape.size());
            shape.insert(shape.end(),group.begin(),group.end());
            span.emplace_back(lo,int(shape.size()));
            mass.push_back(cardinality(*group.front()));
        }
        compatible.assign(shape.size(),Bits((shape.size()+63)/64));
        for (size_t i=0; i<shape.size(); ++i) for (size_t j=0; j<i; ++j)
            if (disjointMasks(*shape[i],*shape[j])) {
                compatible[i][j/64] |= std::uint64_t(1)<<(j%64);
                compatible[j][i/64] |= std::uint64_t(1)<<(i%64);
            }
    }
    bool solve(std::vector<int> needed) {
        return extend(needed,Bits((shape.size()+63)/64,~std::uint64_t(0)));
    }
};

// Exact coverage fixes a next position that contains an uncovered class.
// Track up to four occurrences to choose a class with few alternatives.
class FullCover {
    using Groups=std::vector<std::vector<const Mask*>>;
public:
    static bool possible(const Groups &groups, const std::vector<int> &need, const Mask &used) {
        Mask once{}, twice{}, three{}, four{};
        int total=0;
        for (size_t i=0; i<need.size(); ++i) if (need[i]) {
            if (int(groups[i].size())<need[i]) return false;
            total+=need[i];
            for (const Mask *p : groups[i]) for (size_t w=0; w<p->size(); ++w) {
                auto cells=(*p)[w];
                four[w] |= three[w]&cells;
                three[w] |= twice[w]&cells;
                twice[w] |= once[w]&cells;
                once[w] |= cells;
            }
        }
        if (!total) return cardinality(used)==720;
        int cell=-1, level=4;
        for (int w=0; w<12; ++w) {
            auto open=(w==11 ? std::uint64_t(65535) : ~std::uint64_t(0)) & ~used[w];
            if (open & ~once[w]) return false;
            if (!open) continue;
            std::uint64_t rare=open & ~twice[w];
            int multiplicity=0;
            if (!rare) { rare=open & ~three[w]; multiplicity=1; }
            if (!rare) { rare=open & ~four[w]; multiplicity=2; }
            if (!rare) { rare=open; multiplicity=3; }
            if (multiplicity<level) { level=multiplicity; cell=64*w+__builtin_ctzll(rare); }
        }
        if (cell<0) return false;
        for (size_t i=0; i<need.size(); ++i) if (need[i]) {
            for (const Mask *candidate : groups[i]) {
                if (!(((*candidate)[cell/64]>>(cell%64))&1)) continue;
                auto nextNeed=need;
                --nextNeed[i];
                Groups next(groups.size());
                for (size_t j=0; j<groups.size(); ++j) if (nextNeed[j]) {
                    next[j].reserve(groups[j].size());
                    for (const Mask *q : groups[j])
                        if (disjointMasks(*candidate,*q)) next[j].push_back(q);
                }
                Mask nextUsed=used;
                for (size_t w=0; w<used.size(); ++w) nextUsed[w] |= (*candidate)[w];
                if (possible(next,nextNeed,nextUsed)) return true;
            }
        }
        return false;
    }
};

bool canPlace(const Geometry &geometry, const Profile &profile, bool full=false) {
    auto blocks=[](Kind k){return 6*k.second-k.first;};
    Kind anchorType=*std::max_element(profile.begin(),profile.end(),[&](Kind a,Kind b){return blocks(a)<blocks(b);});
    std::map<Kind,int> counts;
    for (Kind k : profile) ++counts[k];
    if (--counts[anchorType]==0) counts.erase(anchorType);
    std::vector<int> needed;
    for (const auto &item : counts) needed.push_back(item.second);
    for (const auto &anchor : geometry.types.at(anchorType).normalized) {
        std::vector<std::vector<const Mask*>> groups;
        bool enough=true;
        for (const auto &[kind,num] : counts) {
            groups.emplace_back();
            for (const Mask &candidate : geometry.types.at(kind).placements)
                if (disjointMasks(anchor,candidate)) groups.back().push_back(&candidate);
            if (int(groups.back().size())<num) {enough=false;break;}
        }
        if (enough && (full ? FullCover::possible(groups,needed,anchor) : Packing(groups).solve(needed))) return true;
    }
    return false;
}

// A class can be occupied elsewhere only if at least one compatible placement reaches it.
// The same necessary test can use each different kind in the profile as anchor.
class AnchorReach {
    struct Reach {
        Mask cells{};
        int choices = 0;
    };
    const Geometry &geometry;
    std::map<std::tuple<Kind,int,Kind>,Reach> cache;

    const Reach &from(Kind a, int index, Kind b) {
        auto key = std::make_tuple(a,index,b);
        auto stored = cache.find(key);
        if (stored != cache.end()) return stored->second;
        Reach &r = cache[key];
        const auto &anchor = geometry.types.at(a).normalized[index];
        for (const auto &candidate : geometry.types.at(b).placements) {
            if (!disjointMasks(anchor,candidate)) continue;
            ++r.choices;
            for (size_t w=0; w<candidate.size(); ++w) r.cells[w] |= candidate[w];
        }
        return r;
    }
    static int mass(Kind k) { return 6*k.second-k.first; }

public:
    explicit AnchorReach(const Geometry &geometry) : geometry(geometry) {}

    bool possible(const Profile &p) {
        int total=0;
        std::map<Kind,int> counts;
        for (Kind k : p) { total+=mass(k); ++counts[k]; }
        std::vector<Kind> anchors;
        for (const auto &[k,count] : counts) anchors.push_back(k);
        std::sort(anchors.begin(),anchors.end(),[&](Kind a,Kind b) {
            auto left=geometry.types.at(a).normalized.size();
            auto right=geometry.types.at(b).normalized.size();
            return left==right ? mass(a)>mass(b) : left<right;
        });
        for (Kind a : anchors) {
            bool found=false;
            --counts[a];
            const auto &normalized=geometry.types.at(a).normalized;
            for (int i=0; i<int(normalized.size()); ++i) {
                Mask united=normalized[i];
                bool enough=true;
                for (const auto &[k,n] : counts) if (n) {
                    const auto &r=from(a,i,k);
                    if (r.choices<n) { enough=false; break; }
                    for (size_t w=0; w<united.size(); ++w) united[w] |= r.cells[w];
                }
                if (enough && cardinality(united)>=total) { found=true; break; }
            }
            ++counts[a];
            if (!found) return false;
        }
        return true;
    }
};

// Each compatible occurrence contributes its class mask and a parity bit for its
// kind. The XOR of a disjoint exact cover must occupy every unanchored class.
class ParityBasis {
    std::array<Mask, 738> rows{};
public:
    bool reduce(Mask row, bool insert) {
        for (int block=11; block>=0; --block) while (row[block]) {
            int bit=64*block+63-__builtin_clzll(row[block]);
            if (!rows[bit][block]) {
                if (insert) rows[bit]=row;
                return false;
            }
            for (int i=0; i<=block; ++i) row[i]^=rows[bit][i];
        }
        return true;
    }
};

bool spansAt(const Geometry &geometry, const std::map<Kind,int> &need, const Mask &anchor) {
    if (need.size()>18) throw std::runtime_error("too many trail kinds");
    ParityBasis basis;
    Mask target=anchor;
    for (int i=0; i<720; ++i) target[i/64]^=std::uint64_t(1)<<(i%64);
    int coordinate=720;
    for (const auto &[k,n] : need) if (n) {
        std::uint64_t flag=std::uint64_t(1)<<(coordinate%64);
        int choices=0;
        for (auto mask : geometry.types.at(k).placements) if (disjointMasks(mask,anchor)) {
            ++choices;
            mask[coordinate/64] |= flag;
            basis.reduce(mask,true);
        }
        if (choices<n) return false;
        if (n%2) target[coordinate/64] |= flag;
        ++coordinate;
    }
    return basis.reduce(target,false);
}

bool allAnchorSpans(const Geometry &geometry, const Profile &profile) {
    std::map<Kind,int> need;
    int mass=0;
    for (Kind k : profile) { ++need[k]; mass+=6*k.second-k.first; }
    if (mass!=720) throw std::runtime_error("parity filter needs exactly 720 classes");
    for (const auto &[k,n] : need) {
        --need[k];
        bool possible=false;
        for (const auto &anchor : geometry.types.at(k).normalized) {
            if (spansAt(geometry,need,anchor)) { possible=true; break; }
        }
        ++need[k];
        if (!possible) return false;
    }
    return true;
}

#ifndef DENSE_GEOMETRY_ONLY
int main(int argc, char **argv) {
    bool raw = argc == 2 && std::string(argv[1]) == "--raw-exact-cover";
    bool full = raw || (argc == 2 && std::string(argv[1]) == "--exact-cover");
    bool parity = argc == 2 && std::string(argv[1]) == "--parity";
    bool quick = parity || (argc == 2 && std::string(argv[1]) == "--union");
    if (argc > 1 && !quick && !full) return 2;
    Geometry geometry(!raw);
    AnchorReach reach(geometry);
    std::string line;
    int tested=0, feasible=0;
    while (std::getline(std::cin,line)) {
        if (line.empty()) continue;
        std::istringstream in(line);
        Profile profile;
        int h,r;
        while (in>>h) {
            if (!(in>>r) || h<0 || h>maxHoles || r<1 || r>cap[h]) throw std::runtime_error("invalid trail");
            profile.emplace_back(h,r);
            geometry.prepare({h,r});
        }
        if (profile.empty() || !in.eof()) throw std::runtime_error("invalid profile");
        ++tested;
        bool possible;
        if (full) {
            int mass=0;
            for (Kind k : profile) mass+=6*k.second-k.first;
            if (mass!=720) throw std::runtime_error("incomplete class total for --exact-cover");
            possible=reach.possible(profile) && canPlace(geometry,profile,true);
        } else possible = quick ? reach.possible(profile) : canPlace(geometry,profile);
        if (possible && (!parity || allAnchorSpans(geometry,profile))) {++feasible;std::cout<<"feasible "<<line<<'\n';}
    }
    std::cout<<"profiles="<<tested<<" feasible="<<feasible<<std::endl;
    return feasible && !quick ? 1 : 0;
}

#endif

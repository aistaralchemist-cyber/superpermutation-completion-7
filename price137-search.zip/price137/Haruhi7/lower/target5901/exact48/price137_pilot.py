"""Bounded timing pilot on nine-trail rows at geometric price 137 (macOS/Linux).

Run with python3 price137_pilot.py. Temporary inputs and compiled checkers disappear
on exit. The last layer uses the raw exact-cover checker on independent profiles.
Layers 42 and 43 exercise the historical least-row relaxation, not raw placements.
JSON output includes sampled profile ranks in the check_next_counts.py ordering.
"""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import platform
import random
import subprocess
import tempfile
import time


LOWER = Path(__file__).resolve().parents[2]
TABLE_HASH = "f508e1e7b0c0147d6c0a22c76748fb63fe31741aee5df6634d9036ad70bf4982"


def profile_index(caps, holes):
    """Count the delta-zero profiles and recover any selected rank without listing all."""
    deficit = holes - 35
    kinds = [(h, r, 2*h + 5 - r)
             for h in range(holes + 1)
             for r in range(max(1, 2*h + 5 - deficit), min(caps[h], 2*h + 5) + 1)]

    @lru_cache(maxsize=None)
    def count(i, slots, remaining_holes, remaining_deficit):
        if slots == 0:
            return int(remaining_holes == remaining_deficit == 0)
        if i == len(kinds) or remaining_holes < slots*kinds[i][0]:
            return 0
        h, _, d = kinds[i]
        without = count(i + 1, slots, remaining_holes, remaining_deficit)
        if d > remaining_deficit:
            return without
        return without + count(i, slots - 1, remaining_holes - h, remaining_deficit - d)

    total = count(0, 9, holes, deficit)

    def at(rank):
        if not 0 <= rank < total:
            raise ValueError("profile rank is outside this layer")
        out = []
        i, slots, remaining_holes, remaining_deficit = 0, 9, holes, deficit
        while slots:
            h, r, d = kinds[i]
            pieces = (count(i, slots - 1, remaining_holes - h, remaining_deficit - d)
                      if d <= remaining_deficit and h*slots <= remaining_holes else 0)
            if rank >= pieces:
                rank -= pieces
                i += 1
            else:
                out.append((h, r))
                remaining_holes -= h
                remaining_deficit -= d
                slots -= 1
        return out
    return total, at


def timed_run(argv, profiles, seconds, mib, screen=False):
    payload = ''.join(' '.join(f'{h} {r}' for h, r in profile) + '\n' for profile in profiles)
    with tempfile.TemporaryFile(mode='w+') as src, tempfile.TemporaryFile(mode='w+') as out, tempfile.TemporaryFile(mode='w+') as err:
        src.write(payload)
        src.seek(0)
        start = time.monotonic()
        child = subprocess.Popen(argv, stdin=src, stdout=out, stderr=err)
        peak = 0
        cause = None
        try:
            while child.poll() is None:
                reading = subprocess.run(['ps', '-o', 'rss=', '-p', str(child.pid)],
                                         capture_output=True, text=True).stdout.strip()
                peak = max(peak, int(reading) if reading else 0)
                if peak > mib*1024 or time.monotonic() - start >= seconds:
                    cause = "rss" if peak > mib*1024 else "time"
                    child.kill()
                    break
                time.sleep(.05)
        finally:
            if child.poll() is None:
                child.kill()
            child.wait()
        elapsed = time.monotonic() - start
        out.seek(0)
        err.seek(0)
        output = out.read().strip().splitlines()
        if cause is None and child.returncode not in (0, 1):
            raise RuntimeError((child.returncode, output, err.read()))
        if cause is None:
            label = "surviving" if screen else "feasible"
            expected = f"profiles={len(profiles)} {label}="
            if not output or not output[-1].startswith(expected):
                raise RuntimeError(f"checker did not report all profiles: {output}")
        lines = err.read().strip().splitlines()
        return dict(wall_s=round(elapsed, 3), sampled_peak_mib=round(peak/1024, 1),
                    stopped_by=cause, summary=output[-1] if output else None,
                    progress=lines if screen else lines[-1:])


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--samples', type=int, default=32)
    cli.add_argument('--seconds', type=float, default=3)
    cli.add_argument('--mib', type=int, default=512)
    cli.add_argument('--seed', type=int, default=137)
    args = cli.parse_args()
    if not (1 <= args.samples <= 512 and 0 < args.seconds <= 60 and 1 <= args.mib <= 2048):
        cli.error('expected 1–512 samples, a time limit of at most 60s, and 1–2048 MiB')
    blob = (LOWER/'capD16_k.txt').read_bytes()
    assert hashlib.sha256(blob).hexdigest() == TABLE_HASH
    caps = list(map(int, blob.splitlines()[0].split(b':')[1].split()))
    meta = {'arm': platform.machine(), 'os': platform.platform(), 'seed': args.seed,
            'n': args.samples, 'time_limit_s': args.seconds, 'memory_limit_mib': args.mib,
            'compiler': subprocess.check_output(['c++','--version'],text=True).splitlines()[0],
            'counts': {h: profile_index(caps, h)[0] for h in range(42,49)}}
    print(json.dumps({'setup': meta}), flush=True)
    with tempfile.TemporaryDirectory(prefix='price137-pilot-') as tmp:
        for binary, source in [('core', LOWER/'hole_frontier/corecheck.cpp'),
                               ('raw', LOWER/'check_dense_holes.cpp')]:
            subprocess.run(['c++','-O3','-std=c++17','-I'+str(LOWER),str(source),
                            '-o',str(Path(tmp)/binary)], check=True)
        for h in (42, 43):
            total, at = profile_index(caps, h)
            ranks = sorted(random.Random(args.seed).sample(range(total), 100))
            run = timed_run([str(Path(tmp)/'core')], [at(r) for r in ranks], 22, 768)
            print(json.dumps({'h':h,'mode':'least-row batch','samples':100,**run}),flush=True)
        total, at = profile_index(caps, 48)
        ranks = random.Random(args.seed).sample(range(total), args.samples)
        command = [str(Path(tmp)/'raw'), '--raw-exact-cover']
        deferred = []
        for rank in ranks:
            run = timed_run(command, [at(rank)], args.seconds, args.mib)
            if run['stopped_by']:
                deferred.append(rank)
            print(json.dumps({'h':48,'mode':'raw individual','rank':rank,**run}),flush=True)
        run = timed_run(command, [at(r) for r in ranks], 22, 768)
        print(json.dumps({'h':48,'mode':'raw batch','samples':len(ranks),**run}),flush=True)
        for rank in deferred:
            run = timed_run(command, [at(rank)], 15, 1536)
            print(json.dumps({'h':48,'mode':'raw retry','rank':rank,'limit_s':15,'limit_mib':1536,**run}),flush=True)


if __name__ == '__main__':
    main()

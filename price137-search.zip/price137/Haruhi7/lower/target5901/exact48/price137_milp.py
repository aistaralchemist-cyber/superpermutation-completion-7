"""Bounded geometric feasibility pilot (SciPy/HiGHS). No formal UNSAT certificate.

Examples: python price137_milp.py --control
          python price137_milp.py --trails 9 --seconds 30
          python price137_milp.py --trails 9 --holes 48 --seconds 30

Whole-branch searches normalize away width-five rows. Fixing H disables that
normalization, since moving such rows into packets changes H and k.
"""
import argparse
import json
from math import inf
from time import monotonic
import warnings

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix

from price137_catalog import catalog, full_run_anchor, port_minimum, record_assignment, validate


def missing_roots(cat, chosen, starts):
    """Edge-containing weak components without a start token."""
    neighbors = {}
    for idx in chosen:
        row = cat.rows[idx]
        neighbors.setdefault(row.port_in, set()).add(row.port_out)
        neighbors.setdefault(row.port_out, set()).add(row.port_in)
    pending = set(neighbors)
    while pending:
        comp = {pending.pop()}
        stack = list(comp)
        while stack:
            new = neighbors[stack.pop()] & pending
            pending.difference_update(new)
            comp.update(new)
            stack.extend(new)
        if not any(starts[v] for v in comp):
            yield comp


class Constraints:
    def __init__(self):
        self.row, self.col, self.values = [], [], []
        self.low, self.high = [], []

    def add(self, terms, low=-inf, high=inf):
        index = len(self.low)
        for col, coefficient in terms:
            if coefficient:
                self.row.append(index)
                self.col.append(col)
                self.values.append(coefficient)
        self.low.append(low)
        self.high.append(high)

    def matrix(self, n):
        matrix = coo_matrix((self.values, (self.row, self.col)),
                            shape=(len(self.low), n)).tocsc()
        return LinearConstraint(matrix, self.low, self.high)


def solve(args):
    cat = catalog()
    record = record_assignment(cat) if args.control else None
    m, price = record[-2:] if record else (args.trails, 137)
    nr, nw, nv = len(cat.rows), len(cat.wheels), len(cat.ports)
    cell0, k0, start0 = nr, nr+6*nw, nr+7*nw
    n = start0+nv
    lows, highs = np.zeros(n), np.ones(n)
    highs[k0:start0] = 6
    highs[start0:] = m
    cons = Constraints()
    covers = [[] for _ in cat.classes]
    ports = [[] for _ in cat.ports]
    for i, row in enumerate(cat.rows):
        for cell in row.cells:
            covers[cell].append((i, 1))
        if row.port_in != row.port_out:
            ports[row.port_in].append((i, 1))
            ports[row.port_out].append((i, -1))
    for w, wheel in enumerate(cat.wheels):
        cells = []
        for j, cell in enumerate(wheel):
            y = cell0+6*w+j
            covers[cell].append((y, 1))
            cells.append((y, 1))
        cons.add(cells+[(k0+w, -1)], low=0)
        cons.add(cells+[(k0+w, -5)], high=0)
    for terms in covers:
        cons.add(terms, 1, 1)
    for v, terms in enumerate(ports):
        cons.add(terms+[(start0+v, -1)], high=0)
    cons.add(((start0+v, 1) for v in range(nv)), high=m)
    cons.add([(i, 1) for i in range(nr)]+[(k0+w, 1) for w in range(nw)],
             price-m, price-m)
    cons.add(((i, 1) for i in range(nr)), low=m)
    if record:
        rows, assignments, counts, _, _ = record
        highs[:start0] = 0
        highs[rows] = lows[rows] = 1
        for w, wheel in enumerate(cat.wheels):
            for j, cell in enumerate(wheel):
                if cell in assignments[w]:
                    highs[cell0+6*w+j] = lows[cell0+6*w+j] = 1
        highs[k0:start0] = lows[k0:start0] = counts
    else:
        # At least 720 - 5*(137-m) rows have width six. Relabel one seed.
        whole_branch = args.holes is None and not args.raw
        if whole_branch:
            for i,row in enumerate(cat.rows):
                if row.width == 5:
                    highs[i] = 0
            # With no width-five rows T (nonfull rows) <= H/2. If each
            # run had length < g, F <= (g-1)*(T+m). The exact price
            # identities force the following g, independent of H and k.
            run = 4 if m == 9 else (3 if m >= 3 else 2)
        else:
            run = 2 if m >= 7 else 1
        lows[list(full_run_anchor(cat, run))] = 1
        floor = {2:48, 3:42, 4:40, 5:38, 6:38, 7:38, 8:36, 9:36}[m]
        if args.holes is not None and not floor <= args.holes <= 102-6*m:
            raise ValueError(f"holes must be in [{floor}, {102-6*m}] for this branch")
        hole_min = floor if args.holes is None else args.holes
        hole_max = 102-6*m if args.holes is None else args.holes
        cons.add(((i, 6-row.width) for i,row in enumerate(cat.rows)), hole_min, hole_max)
    integrality = np.ones(n, dtype=np.uint8)
    objective = np.zeros(n)
    deadline = monotonic()+args.seconds
    print(json.dumps(dict(trails=m, price=price, holes=args.holes, control=bool(record),
                          variables=n, constraints=len(cons.low), budget_seconds=args.seconds,
                          no_fives=False if record else whole_branch,
                          anchored_full_rows=0 if record else run)),
          flush=True)
    num_cuts = 0
    began = monotonic()
    def finish(status, **details):
        print(json.dumps(dict(status=status, seconds=round(monotonic()-began, 3),
                              connectivity_cuts=num_cuts, **details)), flush=True)
    while monotonic() < deadline:
        matrix = cons.matrix(n)
        remaining = deadline-monotonic()
        if remaining <= 0:
            break
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='Unrecognized options detected.*threads.*',
                                    category=RuntimeWarning)
            sol = milp(objective, integrality=integrality, bounds=Bounds(lows, highs),
                       constraints=matrix, options=dict(time_limit=remaining, threads=1))
        if sol.x is None:
            return finish("solver_infeasible_unverified" if sol.status == 2 else "unknown",
                          solver_status=int(sol.status), message=sol.message)
        rounded = np.rint(sol.x).astype(int)
        if np.max(np.abs(sol.x-rounded)) > 1e-5:
            return finish("unknown", reason="nonintegral incumbent")
        rows = np.flatnonzero(rounded[:nr]).tolist()
        assignments = [[cell for j, cell in enumerate(wheel) if rounded[cell0+6*w+j]]
                       for w, wheel in enumerate(cat.wheels)]
        counts = rounded[k0:start0].tolist()
        if port_minimum(cat, rows) <= m:
            stats = validate(cat, rows, assignments, counts, m, price)
            if args.holes is not None and sum(6-cat.rows[i].width for i in rows) != args.holes:
                raise ValueError("solver witness has a different hole count")
            if not record and whole_branch and any(cat.rows[i].width == 5 for i in rows):
                raise ValueError("width-five row in a normalized search")
            return finish("checked_board", board=stats, row_ids=rows,
                          packets=[(w, cells, counts[w]) for w,cells in enumerate(assignments) if cells])
        disconnected = list(missing_roots(cat, rows, rounded[start0:]))
        if not disconnected:
            return finish("unknown", reason="inconsistent solver degree or start assignment")
        # Each occupied component needs a start. If these vertices belong to a
        # larger component in a later solution, a crossing selected row justifies it.
        for comp in disconnected:
            big = price-m
            terms = [(start0+v, big) for v in comp]
            for i,row in enumerate(cat.rows):
                a, b = row.port_in in comp, row.port_out in comp
                if a != b:
                    terms.append((i, big))
                elif a:
                    terms.append((i, -1))
            cons.add(terms, low=0)
            num_cuts += 1
    finish("unknown", reason="time budget")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trails', type=int, choices=range(2, 10), default=9)
    parser.add_argument('--holes', type=int)
    parser.add_argument('--seconds', type=float, default=30)
    parser.add_argument('--control', action='store_true')
    parser.add_argument('--raw', action='store_true', help='leave width-five rows available')
    args = parser.parse_args()
    if args.seconds <= 0 or not np.isfinite(args.seconds):
        parser.error('seconds must be finite and positive')
    if args.control and args.holes is not None:
        parser.error('--control and --holes cannot be combined')
    solve(args)

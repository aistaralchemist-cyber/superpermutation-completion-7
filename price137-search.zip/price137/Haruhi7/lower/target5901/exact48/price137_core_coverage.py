"""Measure the nine-trail raw filter, and count full profiles containing a rejected core."""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import random
import subprocess
import tempfile
import time
from price137_pilot import LOWER, TABLE_HASH, profile_index, timed_run


SHORTENED_CORES = (
    ((4,13),(8,20),(8,20),(10,23),(12,27)),
    ((2,7),(2,9),(4,13),(5,13),(6,16),(10,24),(10,24)),
)


def covered_profiles(cores, caps):
    """Enumerate extensions of the recorded cores. In a full profile H=48, R=128."""
    kinds = [(h,r,2*h+5-r) for h in range(49)
             for r in range(max(1,2*h+5-13),min(2*h+5,caps[h])+1)]
    @lru_cache(maxsize=None)
    def possible(i, slots, holes, deficit):
        if slots == 0:
            return holes == deficit == 0
        if i == len(kinds) or holes < slots*kinds[i][0] or deficit < 0:
            return False
        h, _, d = kinds[i]
        return possible(i+1,slots,holes,deficit) or possible(i,slots-1,holes-h,deficit-d)

    def extend(i, slots, holes, deficit, chosen):
        if not possible(i, slots, holes, deficit):
            return
        if slots==0:
            yield tuple(chosen)
            return
        for j in range(i,len(kinds)):
            h, r, d = kinds[j]
            if h*slots>holes:
                break
            if d<=deficit:
                yield from extend(j,slots-1,holes-h,deficit-d,chosen+[(h,r)])

    result = set()
    for core in cores:
        holes=48-sum(h for h,_ in core)
        deficit=13-sum(2*h+5-r for h,r in core)
        for extra in extend(0,9-len(core),holes,deficit,[]):
            result.add(tuple(sorted(core+extra)))
    return len(result)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path)
    args=parser.parse_args()
    raw=(LOWER/'capD16_k.txt').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=TABLE_HASH:
        raise ValueError('unexpected row bounds')
    caps=list(map(int,raw.splitlines()[0].split(b':')[1].split()))
    n,at=profile_index(caps,48)
    cores=set()
    with tempfile.TemporaryDirectory(prefix='raw-cores-') as tmp:
        binary=args.binary
        if binary is None:
            binary=Path(tmp)/'screen'
            subprocess.run(['c++','-std=c++17','-O3',str(Path(__file__).with_name('price137_raw_core.cpp')),
                            '-o',str(binary)],check=True)
        for seed,size in [(137,32),(20261125,128)]:
            ranks=random.Random(seed).sample(range(n),size)
            run=timed_run([str(binary)],[at(r) for r in ranks],25,990,screen=True)
            if run['stopped_by']:
                raise RuntimeError('incomplete sample: '+str(run))
            for line in run['progress']:
                tag, *fields=line.split()
                if tag!='core' or len(fields)%2:
                    raise ValueError(line)
                core=tuple(zip(map(int,fields[::2]),map(int,fields[1::2])))
                cores.add(core)
            print(json.dumps(dict(mode='partial raw screen',seed=seed,size=size,**run)),flush=True)
        # Previously unresolved raw profile from the bounded independent sample.
        rank=849100
        run=timed_run([str(binary),'--finish'],[at(rank)],8,768,screen=True)
        print(json.dumps(dict(mode='incremental raw full',rank=rank,**run)),flush=True)
        for line in run['progress']:
            if line.startswith('core '):
                fields=line.split()[1:]
                core=tuple(zip(map(int,fields[::2]),map(int,fields[1::2])))
                cores.add(core)

        start=time.monotonic()
        rejected=covered_profiles(cores,caps)
        print(json.dumps(dict(mode='population',population=n,distinct_cores=len(cores),
                              covered=rejected,remaining=n-rejected,wall_s=round(time.monotonic()-start,3))),
              flush=True)

        # These two deletion-minimized cores came from the first and second
        # lexicographically listed eight-trail seed profiles. Recheck each directly.
        shortened=SHORTENED_CORES
        verified=timed_run([str(binary),'--verify-cores'],shortened,12,768,screen=True)
        if verified['stopped_by'] or verified['summary']!='profiles=2 surviving=0':
            raise RuntimeError('shortened cores were not verified: '+str(verified))
        improved=covered_profiles(cores.union(shortened),caps)
        print(json.dumps(dict(mode='population after two verified shortenings',
                              population=n,covered=improved,remaining=n-improved,
                              check=verified)),flush=True)

if __name__=='__main__':
    main()

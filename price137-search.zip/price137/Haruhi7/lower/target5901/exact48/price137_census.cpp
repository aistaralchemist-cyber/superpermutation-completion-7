// Arithmetic profile census for exact geometric price 137.
// Build: c++ -O2 -std=c++17 price137_census.cpp -o /tmp/price137_census
// Use --no-width-five for its arithmetic consequence h_i != 1. The stronger
// --full-ends-interior option is a separate sieve. No placements are enumerated.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>

namespace {
enum class Sieve { unrestricted, noWidthFive, fullEndsInterior };
using Count = std::uint64_t;
constexpr int maxH = 90, maxR = 137, maxM = 11;
using Grid = std::array<std::array<Count, maxR + 1>, maxH + 1>;
std::array<Grid, maxM + 1> profiles{};

// T5899.Mtab in jhalfar/superpermutation-almanac-lean, revision
// a09f9ef4ebb74ae1297f17c5fad38296695f2959, LowerBounds/PTables.lean.
// SHA256 of the space-separated decimal entries with a trailing newline:
// 97a25e8d6d693a3d76a329aa7e57010f7ad966503d7e740de367408cb3c4201c
constexpr std::array<int, 85> singleCap = {
    5,5,9,9,13,13,16,16,20,20,24,24,27,27,31,31,34,34,36,38,40,41,
    43,44,46,47,50,51,52,54,56,57,59,60,63,64,66,66,68,69,71,72,
    74,75,77,79,80,82,83,85,85,86,88,89,91,92,93,94,96,98,99,100,
    107,110,111,112,113,114,115,116,119,120,121,122,123,124,125,126,
    127,128,129,130,131,132,133
};

// The first row of holeFloor in HistoricHoleTable.lean (M=0..11).
constexpr int holeFloor[] = {0,62,48,42,40,38,38,38,36,36,36,36};

Count add(Count a, Count b) {
    if (b > std::numeric_limits<Count>::max() - a)
        throw std::overflow_error("profile counter overflow");
    return a + b;
}

std::pair<int, int> rowRange(int holes, Sieve sieve) {
    const int areaCap = (720 + holes) / 6;  // The trail visits 6r-h distinct classes.
    const int upper = holes < static_cast<int>(singleCap.size())
        ? std::min(singleCap[holes], areaCap) : areaCap;
    const int lower = sieve == Sieve::fullEndsInterior
        ? 2 + (holes + 4) / 5 : std::max(1, (holes + 4) / 5);
    // Each row without width five contributes 0, 2, 3, 4 or 5 holes.
    if (sieve == Sieve::noWidthFive && holes == 1) return {1, 0};
    if (sieve == Sieve::fullEndsInterior && holes < 2) return {1, 0};
    return {lower, upper};
}

// Let P(x,y) list allowed single types x^h y^r and let F_m count unordered
// multisets of m types. Logarithmic differentiation of
// product_(h,r) (1 - t*x^h*y^r)^(-1) gives
// m F_m = sum_(j=1..m) P(x^j,y^j) F_(m-j).
// The prefix sums below add each interval of possible r in constant time.
void build(Sieve sieve) {
    profiles[0][0][0] = 1;
    Grid prefix{};
    for (int m = 1; m <= maxM; ++m) {
        auto& target = profiles[m];
        for (int j = 1; j <= m; ++j) {
            for (int h = 0; h <= maxH; ++h)
                for (int r = 0; r <= maxR; ++r)
                    prefix[h][r] = add(profiles[m-j][h][r], r >= j ? prefix[h][r-j] : 0);
            for (int a = 0; a*j <= maxH; ++a) {
                auto [low, high] = rowRange(a, sieve);
                if (high < low) continue;
                for (int h = a*j; h <= maxH; ++h) {
                    const auto& prev = prefix[h-a*j];
                    for (int r = low*j; r <= maxR; ++r) {
                        const Count before = r >= (high+1)*j ? prev[r-(high+1)*j] : 0;
                        target[h][r] = add(target[h][r], prev[r-low*j] - before);
                    }
                }
            }
        }
        for (auto& row : target) for (auto& n : row) {
            if (n % m) throw std::logic_error("nonintegral coefficient");
            n /= m;
        }
    }
}

// Direct two-trail count, independent of the generating-function recurrence.
Count countPairs(int H, int R, Sieve sieve) {
    Count count = 0;
    for (int h = 0; 2*h <= H; ++h) {
        auto [lo, hi] = rowRange(h, sieve);
        auto [otherLo, otherHi] = rowRange(H-h, sieve);
        for (int r = lo; r <= hi; ++r) {
            int s = R-r;
            if (otherLo <= s && s <= otherHi && (h != H-h || r <= s)) ++count;
        }
    }
    return count;
}

struct Counts { int scalar = 0, occupied = 0; Count shapes = 0; };
void print(const Counts& c) {
    std::cout << ' ' << c.scalar << ' ' << c.occupied << ' ' << c.shapes;
}

void census(Sieve sieve) {
    build(sieve);
    if (sieve != Sieve::fullEndsInterior && profiles[11][36][126] != 18)
        throw std::logic_error("eleven-trail control failed");
    if (sieve == Sieve::fullEndsInterior) std::cout << "Conditional full ends and interior width <=4";
    else if (sieve == Sieve::noWidthFive) std::cout << "No width-five rows: arithmetic filter h_i != 1";
    else std::cout << "Unrestricted row widths";
    std::cout << "\nM  scalar nonempty unordered_profiles  after_archived_M9_cut: scalar nonempty unordered_profiles\n";
    Counts total[2];
    for (int m = 2; m <= 9; ++m) {
        Counts byM[2];
        const int budget = 102-6*m;
        for (int h = holeFloor[m]; h <= budget; ++h) {
            int left = budget-h; // k+delta, with 0<=delta<=4k.
            for (int k = (left+4)/5; k <= left; ++k) {
                int r = 137-m-k;
                Count n = profiles[m][h][r];
                if (m == 2 && n != countPairs(h, r, sieve))
                    throw std::logic_error("two-trail direct enumeration mismatch");
                for (int archived = 0; archived < 2; ++archived) {
                    if (archived && m == 9 && h <= 42) continue;
                    ++byM[archived].scalar;
                    byM[archived].occupied += n > 0;
                    byM[archived].shapes = add(byM[archived].shapes, n);
                }
            }
        }
        std::cout << m;
        for (int a = 0; a < 2; ++a) {
            print(byM[a]);
            total[a].scalar += byM[a].scalar;
            total[a].occupied += byM[a].occupied;
            total[a].shapes = add(total[a].shapes, byM[a].shapes);
        }
        std::cout << '\n';
    }
    std::cout << "sum"; print(total[0]); print(total[1]); std::cout << '\n';
    std::cout << "M=9 H=48 k=0: " << profiles[9][48][128] << '\n';
}

} // namespace

int main(int argc, char** argv) {
    const bool query = argc >= 2 && std::string(argv[1]) == "--coefficients";
    if (query) { --argc; ++argv; }
    Sieve sieve = Sieve::unrestricted;
    if (argc == 2 && std::string(argv[1]) == "--no-width-five") sieve = Sieve::noWidthFive;
    else if (argc == 2 && std::string(argv[1]) == "--full-ends-interior") sieve = Sieve::fullEndsInterior;
    else if (argc != 1) {
        std::cerr << "usage: price137_census [--coefficients] [--no-width-five|--full-ends-interior]\n";
        return 2;
    }
    if (query) {
        build(sieve);
        int m, h, r;
        while (std::cin >> m >> h >> r) {
            if (m < 0 || m > maxM || h < 0 || h > maxH || r < 0 || r > maxR)
                throw std::out_of_range("coefficient query outside the computed grid");
            std::cout << profiles[m][h][r] << '\n';
        }
        if (!std::cin.eof()) throw std::runtime_error("invalid coefficient query");
    } else census(sieve);
}

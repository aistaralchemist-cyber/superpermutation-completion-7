"""Count budget-compatible extensions of the rejected cores in price137_core_coverage.jsonl.

The raw placement computations are performed by price137_core_coverage.py. This
script reruns only arithmetic, using the unordered coefficients of price137_census.cpp.
"""
import json
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

from price137_core_coverage import SHORTENED_CORES

DIR = Path(__file__).resolve().parent
FLOORS = (0, 0, 48, 42, 40, 38, 38, 38, 36, 36)


def read_cores():
    records = [json.loads(line) for line in (DIR / 'price137_core_coverage.jsonl').read_text().splitlines()]
    initial = set()
    for rec in records:
        for line in rec.get('progress', []):
            head, *parts = line.split()
            if head == 'core':
                values = list(map(int, parts))
                if len(values) % 2:
                    raise ValueError(line)
                initial.add(tuple(sorted(zip(values[::2], values[1::2]))))
    pop = next(r for r in records if r['mode'] == 'population')
    updated = next(r for r in records if r['mode'] == 'population after two verified shortenings')
    if (len(initial) != pop['distinct_cores'] or updated['check']['stopped_by']
            or updated['check']['summary'] != 'profiles=2 surviving=0'):
        raise ValueError('unverified core census')
    return initial, pop['covered'], updated['covered']


def signature(core):
    return len(core), sum(h for h, _ in core), sum(r for _, r in core)


def intersection_terms(cores, no_fives):
    # A shape containing U and V must contain the multiset maximum U ∨ V.
    # An intersection that already exceeds even the coarse budget cannot extend.
    terms = Counter()
    for c in sorted(cores):
        if no_fives and any(h == 1 for h, _ in c):
            continue
        updates = Counter({c: 1})
        for old, coefficient in terms.items():
            join = tuple(sorted((Counter(old) | Counter(c)).elements()))
            m, h, r = signature(join)
            if m <= 9 and h <= 102-6*m and r <= 137-m:
                updates[join] -= coefficient
        terms.update(updates)
        terms = Counter({k: v for k, v in terms.items() if v})
    sig = Counter()
    for core, coefficient in terms.items():
        sig[signature(core)] += coefficient
    return sig


def tally(cores, no_fives, binary):
    sig = intersection_terms(cores, no_fives)
    bins = {}
    queries = set()
    for m in range(2, 10):
        budget = 102-6*m
        for h in range(FLOORS[m], budget+1):
            rem = budget-h
            for k in range((rem+4)//5, rem+1):
                r = 137-m-k
                extensions = {}
                for (i, a, b), coefficient in sig.items():
                    q = (m-i, h-a, r-b)
                    if min(q) >= 0:
                        extensions[q] = coefficient
                        queries.add(q)
                bins[m,h,k] = extensions
    keys = sorted(queries)
    payload = ''.join(f'{m} {h} {r}\n' for m,h,r in keys)
    args = [str(binary), '--coefficients'] + (['--no-width-five'] if no_fives else [])
    run = subprocess.run(args, input=payload, text=True, capture_output=True, check=True)
    counts = list(map(int, run.stdout.splitlines()))
    if len(counts) != len(keys):
        raise ValueError('coefficient count mismatch')
    coeff = dict(zip(keys, counts))
    return {cell: sum(inc * coeff[q] for q, inc in extensions.items())
            for cell, extensions in bins.items()}


def main():
    initial, old_h48, new_h48 = read_cores()
    with tempfile.TemporaryDirectory() as tmp:
        binary = Path(tmp) / 'price137_census'
        subprocess.run(['c++', '-std=c++17', '-O2', str(DIR/'price137_census.cpp'), '-o', str(binary)], check=True)
        for label, cores, h48_control in [('initial', initial, old_h48),
                                          ('with_shortenings', initial.union(SHORTENED_CORES), new_h48)]:
            for no_fives in (False, True):
                counts = tally(cores, no_fives, binary)
                if min(counts.values()) < 0 or (not no_fives and counts[9,48,0] != h48_control):
                    raise ValueError('union count disagrees with the direct H=48 enumeration')
                after = [sum(n for (i,h,k), n in counts.items() if i == m and (m != 9 or h >= 43))
                         for m in range(2,10)]
                print(json.dumps({'cores': label, 'number': len(cores), 'no_width_five': no_fives,
                                  'removed': sum(counts.values()), 'also_using_M9_H_ge_43': sum(after),
                                  'by_M_after_archive': after, 'M9_H48': counts[9,48,0]}))


if __name__ == '__main__':
    main()

// Raw disjoint-trail screen for nine trails, 48 holes, 128 rows.
// Each reported core is impossible with all row widths and all endpoints allowed.
#define DENSE_GEOMETRY_ONLY
#include "../../check_dense_holes.cpp"

int main(int argc, char **argv) {
    const bool finish = argc == 2 && std::string(argv[1]) == "--finish";
    const bool verify = argc == 2 && std::string(argv[1]) == "--verify-cores";
    if (argc > 1 && !finish && !verify) return 2;
    Geometry geometry(false);
    AnchorReach reach(geometry);
    std::map<Profile,bool> cache;
    std::vector<Profile> cores;
    std::string line;
    int count = 0, rejects = 0;
    while (std::getline(std::cin, line)) {
        std::istringstream input(line);
        Profile family;
        int h, r, totalH = 0, totalR = 0;
        while (input >> h) {
            if (!(input >> r) || h < 0 || h > maxHoles || r < 1 || r > cap[h]) return 2;
            totalH += h; totalR += r;
            family.emplace_back(h, r);
        }
        if (!input.eof() || family.empty()) return 2;
        if (verify) {
            for (Kind k:family) geometry.prepare(k);
            if (reach.possible(family) && canPlace(geometry,family)) return 2;
            ++count;
            ++rejects;
            continue;
        }
        if (family.size()!=9 || totalH!=48 || totalR!=128) return 2;
        std::sort(family.begin(), family.end());
        bool rejected=false;
        for (const Profile &core : cores) {
            if (std::includes(family.begin(),family.end(),core.begin(),core.end())) {
                rejected=true;
                break;
            }
        }
        if (!rejected) {
            // Small-deficit kinds have relatively few template orbits.
            // Skipping all other kinds makes this a one-sided filter.
            auto key=[](Kind k) { return std::make_tuple(2*k.first+5-k.second, -(6*k.second-k.first)); };
            std::sort(family.begin(), family.end(), [&](Kind a,Kind b) { return key(a)<key(b); });
            Profile sub;
            for (Kind k:family) {
                if (!finish && (2*k.first+5-k.second>2 || k.first>12)) continue;
                geometry.prepare(k);
                sub.push_back(k);
                if (sub.size()<3 || (!finish && sub.size()==family.size())) continue;
                Profile sorted=sub;
                std::sort(sorted.begin(),sorted.end());
                auto hit=cache.find(sorted);
                bool possible;
                if (hit!=cache.end()) {
                    possible=hit->second;
                } else {
                    possible=reach.possible(sorted) && canPlace(geometry,sorted,sub.size()==family.size());
                    cache.emplace(sorted,possible);
                }
                if (!possible) {
                    cores.push_back(sorted);
                    std::cerr<<"core";
                    for (Kind x:sorted) std::cerr<<" "<<x.first<<" "<<x.second;
                    std::cerr<<std::endl;
                    rejected=true;
                    break;
                }
            }
        }
        ++count;
        rejects += rejected;
    }
    std::cout<<"profiles="<<count<<" surviving="<<count-rejects<<std::endl;
    // In screen mode every untested extension is retained.
    return count==rejects ? 0 : 1;
}

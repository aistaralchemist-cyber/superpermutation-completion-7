"""Oriented row catalog and candidate checks for the seven-symbol geometric problem.

Row IDs index permutations in lexicographic order, then widths 1 through 6.
Wheel cells are global rotation-class IDs. A wheel may support several packets.
Run this file directly to check the archived W-0021 positive control.
"""

from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import lru_cache
from itertools import permutations
import json
from pathlib import Path
import runpy


@dataclass(frozen=True)
class Row:
    seed: tuple
    width: int
    port_in: int
    port_out: int
    cells: tuple


@dataclass(frozen=True)
class Catalog:
    rows: tuple
    wheels: tuple
    ports: tuple
    classes: tuple


def _tag(seed):
    pivot = seed.index(0)
    return seed[pivot:] + seed[:pivot]


def _advance(seed):
    return seed[1:6] + seed[:1] + seed[6:]


@lru_cache(maxsize=1)
def catalog():
    """Generate all rows and wheels in fixed order independently of a solver."""
    symbols = tuple(range(7))
    ports = tuple(permutations(symbols, 4))
    classes = tuple((0,) + tail for tail in permutations(symbols[1:]))
    port_ids = {port: i for i, port in enumerate(ports)}
    class_ids = {tag: i for i, tag in enumerate(classes)}
    rows = []
    wheels = []
    seen_wheels = set()
    for seed in permutations(symbols):
        start = port_ids[seed[:4]]
        entry = seed
        cells = []
        for width in range(1, 7):
            cells.append(class_ids[_tag(entry)])
            # The exit word of the last block is its last symbol followed by its
            # first six symbols. Its final four symbols are entry[2:6].
            rows.append(Row(seed, width, start, port_ids[entry[2:6]], tuple(cells)))
            entry = _advance(entry)
        assert entry == seed and len(set(cells)) == 6
        key = tuple(sorted(cells))
        if key not in seen_wheels:
            seen_wheels.add(key)
            wheels.append(tuple(cells))
    assert (len(rows), len(wheels), len(ports), len(classes)) == (30240, 840, 840, 720)
    incidence = Counter(cell for wheel in wheels for cell in wheel)
    assert len(incidence) == 720 and set(incidence.values()) == {7}
    return Catalog(tuple(rows), tuple(wheels), ports, classes)


def full_run_anchor(cat, length):
    """Canonical IDs of a disjoint full-row run after relabeling its first seed."""
    if not 1 <= length <= 5:
        raise ValueError("a full-row run has between one and five rows")
    first, = (i for i, r in enumerate(cat.rows) if r.width == 6 and r.seed == tuple(range(7)))
    result = [first]
    occupied = set(cat.rows[first].cells)
    for _ in range(1, length):
        port = cat.rows[result[-1]].port_out
        next_id, = (i for i, r in enumerate(cat.rows)
                    if r.width == 6 and r.port_in == port and occupied.isdisjoint(r.cells))
        result.append(next_id)
        occupied.update(cat.rows[next_id].cells)
    return tuple(result)


def port_minimum(cat, row_ids):
    """Minimum nonempty directed trails partitioning the selected oriented rows."""
    balance = Counter()
    adjacent = defaultdict(set)
    for row_id in row_ids:
        row = cat.rows[row_id]
        start, end = row.port_in, row.port_out
        balance[start] += 1
        balance[end] -= 1
        adjacent[start].add(end)
        adjacent[end].add(start)
    remaining = set(adjacent)
    total = 0
    while remaining:
        stack = [remaining.pop()]
        excess = 0
        while stack:
            port = stack.pop()
            excess += max(0, balance[port])
            for other in adjacent[port]:
                if other in remaining:
                    remaining.remove(other)
                    stack.append(other)
        total += max(1, excess)
    return total


def validate(cat, row_ids, wheel_cells, wheel_counts, m, price):
    """Check one geometric candidate against coverage, packet, trail and price rules.

    Supply two wheel-indexed sequences: the selected global class IDs per wheel
    and its packet count. Raises ValueError on invalid candidates.
    """
    rows = list(row_ids)
    if any(type(i) is not int or not 0 <= i < len(cat.rows) for i in rows):
        raise ValueError("invalid row ID")
    if len(wheel_cells) != len(cat.wheels) or len(wheel_counts) != len(cat.wheels):
        raise ValueError("one assignment and one count per wheel are required")
    if type(m) is not int or type(price) is not int:
        raise ValueError("trail count and price must be integers")
    coverage = Counter(c for i in rows for c in cat.rows[i].cells)
    k = 0
    packet_cells = 0
    for w, (cells, packets) in enumerate(zip(wheel_cells, wheel_counts)):
        chosen = tuple(cells)
        if any(type(c) is not int or c not in cat.wheels[w] for c in chosen):
            raise ValueError(f"foreign cell assigned to wheel {w}")
        if type(packets) is not int or not packets <= len(chosen) <= 5 * packets:
            raise ValueError(f"wheel {w} cannot split these cells into {packets} packets")
        coverage.update(chosen)
        k += packets
        packet_cells += len(chosen)
    if len(coverage) != len(cat.classes) or any(times != 1 for times in coverage.values()):
        raise ValueError("the selected rows and packets must cover each rotation class exactly once")
    mu = port_minimum(cat, rows)
    if not mu <= m <= len(rows):
        raise ValueError(f"unattainable trail count {m} for these rows (minimum {mu})")
    if len(rows) + m + k != price:
        raise ValueError("row, trail, and packet counts do not sum to the requested price")
    holes = sum(6 - cat.rows[i].width for i in rows)
    return dict(price=price, M=m, R=len(rows), k=k, mu=mu, H=holes,
                delta=5 * k - packet_cells, covered=len(coverage))


def record_assignment(cat):
    """Read W-0021 and map its archived six trails and 66 packets to this catalog."""
    haruhi = Path(__file__).resolve().parents[3]
    archived = runpy.run_path(str(haruhi / "lower/length5904/score_witness/extract_score.py"))
    trails, packets = archived["extract"]((haruhi / "records/W-0021.txt").read_text().strip())
    row_ids = {(row.seed, row.width): i for i, row in enumerate(cat.rows)}
    wheel_ids = {tuple(sorted(w)): i for i, w in enumerate(cat.wheels)}
    class_ids = {tag: i for i, tag in enumerate(cat.classes)}
    sequence = []
    for trail in trails:
        indices = [row_ids[tuple(map(int, cells[0])), len(cells)] for cells in trail]
        assert all(cat.rows[i].port_out == cat.rows[j].port_in for i, j in zip(indices, indices[1:]))
        sequence.extend(indices)
    assigned = [[] for _ in cat.wheels]
    counts = [0] * len(cat.wheels)
    for packet in packets:
        seed = tuple(map(int, packet[0]))
        full = cat.rows[row_ids[seed, 6]].cells
        w = wheel_ids[tuple(sorted(full))]
        assigned[w].extend(class_ids[_tag(tuple(map(int, e)))] for e in packet)
        counts[w] += 1
    return sequence, assigned, counts, len(trails), len(sequence) + len(trails) + len(packets)


if __name__ == "__main__":
    board = catalog()
    print(json.dumps(validate(board, *record_assignment(board)), sort_keys=True))

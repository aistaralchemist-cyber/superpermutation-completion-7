# Third-party material

## Single-trail row bounds

Jakub Halfar supplied two inputs to the arithmetic and geometric checks.

- The file `capD16_k.txt` reproduces his kernel table byte for byte. Its SHA-256 is `f508e1e7b0c0147d6c0a22c76748fb63fe31741aee5df6634d9036ad70bf4982`. [Original table](https://github.com/jhalfar/superpermutations/blob/8e3c02b5234b49a1422751f86f9e472706082374/proofs/n7_5901/table/capD16_k.txt)
- The array `singleCap` in `price137_census.cpp` reproduces the 85 entries of Halfar’s `T5899.Mtab` in C++ array syntax. The geometric checker `check_dense_holes.cpp` uses the first 55 entries. [Source declaration](https://github.com/jhalfar/superpermutation-almanac-lean/blob/a09f9ef4ebb74ae1297f17c5fad38296695f2959/LowerBounds/PTables.lean)

Halfar distributed both sources under the Apache License 2.0. The accompanying notices describe his upstream projects and identify their contributors. [License](Halfar-LICENSE.txt) · [Table repository notice](Halfar-NOTICE.txt) · [Lean repository notice](Halfar-Almanac-Lean-NOTICE.txt)

## Seven-symbol control word

Andrei Teodorescu constructed W-0021. The Superpermutation Almanac distributes it under the Creative Commons Attribution 4.0 International license. The positive control uses the Almanac’s text file unchanged, with 5,905 digits on the alphabet 0–6. Its SHA-256 is `ad3203800b59628a7e8c00cb19f21a9a35c4a208689bb1ca4d55e18a742c48e5`. The checker extracts row and wheel data from that word. [Almanac record](https://superpermutations.com/w/W-0021) · [Original text](https://superpermutations.com/w/W-0021/download/text) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)

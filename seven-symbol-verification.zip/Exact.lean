import Inclusion
import Permutations

/-! Exact counts and optimal lengths of superpermutations over a finite alphabet.
The proof uses words as a specification. The counting formula itself only
needs a bounded context and inclusion–exclusion over the target permutations. -/
namespace Superpermutation
abbrev Word (n : Nat) := List (Fin n)

def words (n : Nat) : Nat → List (Word n)
  | 0 => [[]]
  | k+1 => (List.finRange n).flatMap fun a => (words n k).map (a :: ·)

theorem mem_words (w : Word n) (k : Nat) : w ∈ words n k ↔ w.length = k := by
  induction k generalizing w with
  | zero => simp [words]
  | succ k ih =>
    cases w with
    | nil => simp [words]
    | cons a w =>
      simp [words, List.mem_flatMap, List.mem_map, ih, List.finRange]

theorem alphabet_nodup (n : Nat) : (List.finRange n).Nodup := by
  induction n with
  | zero => decide
  | succ n ih =>
    rw [List.finRange_succ, List.nodup_cons]
    constructor
    · simp [Fin.succ_ne_zero]
    · exact List.pairwise_map.mpr (ih.imp (by intro a b h e; exact h (Fin.succ_inj.mp e)))

theorem words_nodup (n k : Nat) : (words n k).Nodup := by
  induction k with
  | zero => simp [words]
  | succ k ih =>
    apply List.pairwise_flatMap.mpr
    constructor
    · intro a _
      exact List.pairwise_map.mpr (ih.imp (by simp))
    · apply (alphabet_nodup n).imp
      intro a b hab x hx y hy e
      obtain ⟨u, _, rfl⟩ := List.mem_map.mp hx
      obtain ⟨v, _, rfl⟩ := List.mem_map.mp hy
      exact hab (List.cons.inj e).1

def occurs {α : Type} [DecidableEq α] (p : List α) : List α → Bool
  | [] => p.isEmpty
  | a :: s => p.isPrefixOf (a :: s) || occurs p s

theorem occurs_iff {α : Type} [DecidableEq α] (p w : List α) :
    occurs p w ↔ p <:+: w := by
  induction w with
  | nil => cases p <;> simp [occurs]
  | cons a s ih => simp [occurs, List.infix_cons_iff, ih]

variable {n : Nat}
def width : List (Word n) → Nat
  | [] => 0
  | p :: t => max p.length (width t)

private theorem length_le_width {p : Word n} {t : List (Word n)} (h : p ∈ t) :
    p.length ≤ width t := by
  induction t with
  | nil => simp at h
  | cons q t ih =>
    rcases List.mem_cons.mp h with rfl | h
    · exact Nat.le_max_left .. 
    · exact Nat.le_trans (ih h) (Nat.le_max_right ..)

private def clean (t : List (Word n)) (s : Word n) := t.all fun p => !(occurs p s)
private def allowedStart (t : List (Word n)) (s : Word n) := t.all fun p => !(p.isPrefixOf s)

private theorem clean_iff (t : List (Word n)) (s : Word n) :
    clean t s ↔ ∀ p ∈ t, ¬ p <:+: s := by simp [clean, ← occurs_iff]
private theorem allowed_iff (t : List (Word n)) (s : Word n) :
    allowedStart t s ↔ ∀ p ∈ t, ¬ p <+: s := by
  simp [allowedStart, ← List.isPrefixOf_iff_prefix]

private theorem clean_cons {t : List (Word n)} {s : Word n} (a : Fin n) (hs : clean t s) :
    clean t (a :: s) ↔ allowedStart t (a :: s) := by
  simp only [clean_iff, allowed_iff, List.infix_cons_iff] at *
  exact ⟨fun h p hp hpre => h p hp (.inl hpre),
    fun h p hp hor => hor.elim (h p hp) (hs p hp)⟩

private theorem start_truncated (t : List (Word n)) (s : Word n) (a : Fin n) :
    allowedStart t (a :: s.take (width t - 1)) = allowedStart t (a :: s) := by
  apply Bool.eq_iff_iff.mpr
  rw [allowed_iff, allowed_iff]
  have equiv (p : Word n) (hp : p ∈ t) :
      p <+: a :: s.take (width t - 1) ↔ p <+: a :: s := by
    cases p with
    | nil => simp
    | cons b p =>
      have bound := length_le_width hp
      simp only [List.length_cons] at bound
      by_cases e : b = a
      · subst b
        simp [List.prefix_cons_inj, List.prefix_take_iff, show p.length ≤ width t - 1 by omega]
      · constructor <;> intro h <;> obtain ⟨l, he⟩ := h <;> exact (e (List.cons.inj he).1).elim
  exact ⟨fun h p hp hpre => h p hp ((equiv p hp).mpr hpre),
    fun h p hp hpre => h p hp ((equiv p hp).mp hpre)⟩

private theorem shift_take (a : Fin n) (s : Word n) (b : Nat) :
    (a :: s.take b).take b = (a :: s).take b := by
  cases b with
  | zero => rfl
  | succ b => simp [List.take_take, Nat.min_eq_left]

/-- With a clean suffix already built, prepend k more symbols. The context
is the first width(t)−1 symbols of that suffix. -/
def avoidStep (t : List (Word n)) : Nat → Word n → Nat
  | 0, _ => 1
  | k+1, ctx => ((List.finRange n).map fun a =>
      if allowedStart t (a :: ctx) then
        avoidStep t k ((a :: ctx).take (width t - 1)) else 0).sum

/-- Tabulating the transition operator retains a single count for each
context of length at most b, independent of the full word length. -/
def contexts (n b : Nat) := (List.range (b+1)).flatMap (words n)

private theorem mem_contexts (s : Word n) (h : s.length ≤ b) : s ∈ contexts n b :=
  List.mem_flatMap.mpr ⟨s.length, List.mem_range.mpr (by omega), (mem_words ..).mpr rfl⟩

private def table (states : List (Word n)) (f : Word n → Nat) :=
  states.map fun ctx => (ctx, f ctx)

private theorem lookup_table (states : List (Word n)) (f : Word n → Nat)
    (c : Word n) (hc : c ∈ states) : (table states f).lookup c = some (f c) := by
  induction states with
  | nil => simp at hc
  | cons a ss ih =>
    by_cases e : c = a
    · subst c; simp [table]
    · simp only [table, List.map_cons, List.lookup_cons]
      have he : (c == a) = false := beq_eq_false_iff_ne.mpr e
      simp only [he]
      exact ih ((List.mem_cons.mp hc).resolve_left e)

private def countTable (t : List (Word n)) : Nat → List (Word n × Nat)
  | 0 => table (contexts n (width t - 1)) (fun _ => 1)
  | k+1 =>
    let b := width t - 1
    let prev := countTable t k
    table (contexts n b) fun ctx => ((List.finRange n).map fun a =>
      if allowedStart t (a :: ctx) then
        (prev.lookup ((a :: ctx).take b)).getD 0 else 0).sum

private theorem table_correct (t : List (Word n)) (k : Nat) (ctx : Word n)
    (h : ctx.length ≤ width t - 1) :
    (countTable t k).lookup ctx = some (avoidStep t k ctx) := by
  induction k generalizing ctx with
  | zero => exact lookup_table _ _ _ (mem_contexts ctx h)
  | succ k ih =>
    rw [countTable, lookup_table _ _ _ (mem_contexts ctx h), avoidStep]
    congr 2
    apply List.map_congr_left
    intro a _
    simp [ih _ (List.length_take_le ..)]

/-- The executable version uses two consecutive rows of the table. -/
private def tabulated (t : List (Word n)) (k : Nat) (s : Word n) : Nat :=
  ((countTable t k).lookup (s.take (width t - 1))).getD 0

private theorem tabulated_eq (t : List (Word n)) (k : Nat) (s : Word n) :
    tabulated t k s = avoidStep t k (s.take (width t - 1)) := by
  simp [tabulated, table_correct _ _ _ (List.length_take_le ..)]

private def semantic (t : List (Word n)) (k : Nat) (s : Word n) :=
  ((words n k).filter fun w => clean t (w.reverse ++ s)).length

private theorem semantic_succ (t : List (Word n)) (k : Nat) (s : Word n) :
    semantic t (k+1) s = ((List.finRange n).map fun a => semantic t k (a :: s)).sum := by
  simp [semantic, words, List.filter_flatMap, List.length_flatMap, List.filter_map,
    Function.comp_def, List.reverse_cons, List.append_assoc]

private theorem semantic_dirty (t : List (Word n)) (k : Nat) (s : Word n) (h : ¬ clean t s) :
    semantic t k s = 0 := by
  apply List.length_eq_zero_iff.mpr
  apply List.filter_eq_nil_iff.mpr
  intro w _ hc
  apply h
  apply (clean_iff ..).mpr
  intro p hp hps
  exact (clean_iff ..).mp hc p hp (hps.trans (List.suffix_append _ _).isInfix)

private theorem step_correct (t : List (Word n)) (k : Nat) (s : Word n) (hs : clean t s) :
    avoidStep t k (s.take (width t - 1)) = semantic t k s := by
  induction k generalizing s with
  | zero => simp [avoidStep, semantic, words, hs]
  | succ k ih =>
    rw [semantic_succ, avoidStep]
    congr 1
    apply List.map_congr_left
    intro a _
    rw [start_truncated, shift_take]
    split
    next ha => exact ih _ ((clean_cons a hs).mpr ha)
    next ha => exact (semantic_dirty _ _ _ fun h => ha ((clean_cons a hs).mp h)).symm

/-- Count completions when adding k symbols to a prescribed suffix. -/
def avoidFrom (t : List (Word n)) (k : Nat) (s : Word n) : Nat :=
  if clean t s then tabulated t k s else 0

theorem avoidFrom_correct (t : List (Word n)) (k : Nat) (s : Word n) :
    (avoidFrom t k s : Int) =
      SuperpermIE.avoidCount (words n k) (fun w p => occurs p (w.reverse ++ s)) t := by
  change _ = (semantic t k s : Int)
  unfold avoidFrom
  split
  next hs => simpa [tabulated_eq] using congrArg Int.ofNat (step_correct t k s hs)
  next hs => simp [semantic_dirty _ _ _ hs]

/-- Count words of length k containing none of the forbidden factors. -/
def avoidance (t : List (Word n)) (k : Nat) := avoidFrom t k []

open SuperpermEnum SuperpermIE

def patterns (n : Nat) := perms (List.finRange n)

/-- The specification uses actual permutations and contiguous sublists. -/
def IsSuper (w : Word n) : Prop := ∀ p : Word n, p.Perm (List.finRange n) → p <:+: w

private theorem all_patterns (w : Word n) :
    ((patterns n).all fun p => occurs p w) ↔ IsSuper w := by
  simp only [List.all_eq_true, patterns, mem_perms, occurs_iff, IsSuper]

/-- Inclusion–exclusion with a prescribed suffix. Every term in this
formula is a bounded-context avoidance recurrence, possibly zero because
the prescribed suffix already contains a forbidden pattern. -/
def countFrom (n k : Nat) (s : Word n) : Int :=
  inclusion (patterns n) (fun t => (avoidFrom t k s : Int))

theorem countFrom_correct (n k : Nat) (s : Word n) :
    countFrom n k s = coverCount (words n k)
      (fun w p => occurs p (w.reverse ++ s)) (patterns n) := by
  apply oracle_count
  exact fun t => avoidFrom_correct t k s

/-- The explicit signed-subset formula at an empty suffix. -/
theorem subset_formula (n k : Nat) :
    countFrom n k [] = total (subsets (patterns n))
      (fun t => (-1 : Int) ^ t.length * (avoidance t k : Int)) := by
  exact inclusion_eq_sum _ _

/-- The matrix entry counts letters which take state u to state v without
introducing a forbidden factor. Parallel transitions are counted separately. -/
def entry (t : List (Word n)) (u v : Word n) : Nat :=
  ((List.finRange n).map fun a =>
    if allowedStart t (a :: u) && ((a :: u).take (width t - 1) == v) then 1 else 0).sum

/-- The u component of the finite matrix times a column vector f. -/
def matrixTimes (t : List (Word n)) (f : Word n → Nat) (u : Word n) : Nat :=
  ((contexts n (width t - 1)).map fun v => entry t u v * f v).sum

/-- Action of M^k on the all-ones vector. -/
def matrixPowerOnes (t : List (Word n)) : Nat → Word n → Nat
  | 0 => fun _ => 1
  | k+1 => matrixTimes t (matrixPowerOnes t k)

private theorem contexts_nodup (n b : Nat) : (contexts n b).Nodup := by
  apply List.pairwise_flatMap.mpr
  constructor
  · intro j _; exact words_nodup n j
  · apply List.nodup_range.imp
    intro i j hij x hx y hy e
    subst y
    exact hij (((mem_words x i).mp hx).symm.trans ((mem_words x j).mp hy))

private theorem sum_add (l : List α) (f g : α → Nat) :
    (l.map (fun x => f x + g x)).sum = (l.map f).sum + (l.map g).sum := by
  induction l with
  | nil => rfl
  | cons a l ih => simp only [List.map_cons, List.sum_cons, ih]; omega

private theorem sum_mul (l : List α) (f : α → Nat) (z : Nat) :
    (l.map f).sum * z = (l.map (fun x => f x * z)).sum := by
  induction l with
  | nil => simp
  | cons a l ih => simp [Nat.add_mul, ih]

private theorem sum_swap (l : List α) (m : List β) (f : α → β → Nat) :
    (l.map (fun a => (m.map (f a)).sum)).sum =
      (m.map fun b => (l.map fun a => f a b).sum).sum := by
  induction l with
  | nil =>
    induction m with
    | nil => rfl
    | cons b m ih => simpa using ih
  | cons a l ih => simp [sum_add, ih]

private theorem select_one (l : List (Word n)) (hd : l.Nodup) (w : Word n) (f : Word n → Nat) :
    (l.map (fun v => if w = v then f v else 0)).sum = if w ∈ l then f w else 0 := by
  induction l with
  | nil => simp
  | cons a l ih =>
    obtain ⟨ha, hl⟩ := List.nodup_cons.mp hd
    by_cases e : w = a
    · subst a; simp [ih hl, ha]
    · simp [e, ih hl]

theorem matrixTimes_eq (t : List (Word n)) (f : Word n → Nat) (u : Word n) :
    matrixTimes t f u = ((List.finRange n).map fun a =>
      if allowedStart t (a :: u) then f ((a :: u).take (width t - 1)) else 0).sum := by
  simp only [matrixTimes, entry, sum_mul, sum_swap (contexts n (width t - 1)) (List.finRange n)]
  congr 1
  apply List.map_congr_left
  intro a _
  cases ha : allowedStart t (a :: u) with
  | true =>
    have eq (v : Word n) : (if ((a :: u).take (width t - 1) == v) = true then 1 else 0) * f v =
        if (a :: u).take (width t - 1) = v then f v else 0 := by
      by_cases h : (a :: u).take (width t - 1) = v <;> simp [h]
    simp only [Bool.true_and, eq, if_true]
    rw [select_one _ (contexts_nodup ..), if_pos (mem_contexts _ (List.length_take_le ..))]
  | false =>
    simp
    rw [show (fun _ : Word n => 0) = Function.const _ (0 : Nat) from rfl,
      List.map_const, List.sum_replicate_nat, Nat.mul_zero]

theorem matrixPower_eq (t : List (Word n)) (k : Nat) (u : Word n) :
    matrixPowerOnes t k u = avoidStep t k u := by
  induction k generalizing u with
  | zero => rfl
  | succ k ih => simp only [matrixPowerOnes, matrixTimes_eq, avoidStep, ih]

theorem avoidFrom_matrix_clean (t : List (Word n)) (k : Nat) (s : Word n)
    (hs : ∀ p ∈ t, ¬ p <:+: s) :
    avoidFrom t k s = matrixPowerOnes t k (s.take (width t - 1)) := by
  simp [avoidFrom, (clean_iff ..).mpr hs, tabulated_eq, matrixPower_eq]

theorem avoidance_matrix (t : List (Word n)) (k : Nat) :
    avoidance t k = if clean t [] then matrixPowerOnes t k [] else 0 := by
  simp [avoidance, avoidFrom, tabulated_eq, matrixPower_eq]

/-- Exact finite matrix formula, including the empty-alphabet convention. -/
theorem count_matrix (n k : Nat) :
    countFrom n k [] = total (subsets (patterns n)) (fun t =>
      (-1 : Int) ^ t.length * (if clean t [] then (matrixPowerOnes t k [] : Int) else 0)) := by
  rw [subset_formula]
  congr 1
  funext t
  rw [avoidance_matrix]
  split <;> rfl

theorem countFrom_pos (n k : Nat) (s : Word n) :
    0 < countFrom n k s ↔ ∃ v : Word n, v.length = k ∧ IsSuper (v.reverse ++ s) := by
  rw [countFrom_correct]
  unfold coverCount
  rw [Int.ofNat_pos, List.length_pos_iff]
  constructor
  · intro h
    obtain ⟨v, hv⟩ := List.exists_mem_of_ne_nil _ h
    obtain ⟨hm, hc⟩ := List.mem_filter.mp hv
    exact ⟨v, (mem_words ..).mp hm, (all_patterns _).mp hc⟩
  · rintro ⟨v, hl, hv⟩ he
    have hm := (List.mem_filter (p := fun w : Word n => (patterns n).all (fun p => occurs p (w.reverse ++ s)))).mpr
      ⟨(mem_words v k).mpr hl, (all_patterns _).mpr hv⟩
    rw [he] at hm
    exact List.not_mem_nil hm

def feasible (n k : Nat) : Prop := ∃ w : Word n, w.length = k ∧ IsSuper w

theorem feasible_iff (n k : Nat) : 0 < countFrom n k [] ↔ feasible n k := by
  rw [countFrom_pos]
  constructor
  · rintro ⟨v, hl, hv⟩
    exact ⟨v.reverse, by simpa using hl, by simpa using hv⟩
  · rintro ⟨w, hl, hw⟩
    exact ⟨w.reverse, by simpa using hl, by simpa using hw⟩

def bound (n : Nat) := n * fact n

theorem bound_feasible (n : Nat) : feasible n (bound n) := by
  refine ⟨(patterns n).flatten, ?_, ?_⟩
  · rw [List.length_flatten]
    have eq : (patterns n).map List.length = (patterns n).map (Function.const _ n) := by
      apply List.map_congr_left
      intro p hp
      simpa using ((mem_perms _ _).mp hp).length_eq
    rw [eq, List.map_const, List.sum_replicate_nat]
    simp [patterns, length_perms, bound, Nat.mul_comm]
  · intro p hp
    exact List.infix_of_mem_flatten ((mem_perms _ _).mpr hp)

private theorem least_of_example (P : Nat → Prop) (m : Nat) (hm : P m) :
    ∃ l, P l ∧ ∀ j, P j → l ≤ j := by
  induction m using Nat.strongRecOn with
  | ind m ih =>
    by_cases h : ∃ j, j < m ∧ P j
    · obtain ⟨j, hj, hp⟩ := h
      exact ih j hj hp
    · refine ⟨m, hm, fun j hp => ?_⟩
      exact Nat.le_of_not_gt (fun hj => h ⟨j, hj, hp⟩)

private theorem extend_feasible (hn : 0 < n) {k j : Nat} (hk : feasible n k) (hj : k ≤ j) :
    feasible n j := by
  obtain ⟨w, hl, hw⟩ := hk
  let tail := List.replicate (j-k) (⟨0, hn⟩ : Fin n)
  refine ⟨w ++ tail, ?_, fun p hp => (hw p hp).trans (List.prefix_append _ _).isInfix⟩
  simp [tail, hl, Nat.add_sub_of_le hj]

/-- Sum of the zero-count indicators at lengths 0,...,m−1. -/
def emptyLengths (n : Nat) : Nat → Nat
  | 0 => 0
  | k+1 => emptyLengths n k + (if 0 < countFrom n k [] then 0 else 1)

def shortestLength (n : Nat) := emptyLengths n (bound n)

private theorem emptyLengths_eq (n l : Nat) (ht : ∀ k, 0 < countFrom n k [] ↔ l ≤ k)
    (m : Nat) : emptyLengths n m = min m l := by
  induction m with
  | zero => simp [emptyLengths]
  | succ m ih =>
    simp only [emptyLengths, ih, ht]
    split <;> omega

/-- The explicit finite sum is attained, and bounds from below the length
of every competing superpermutation. The empty alphabet is included. -/
theorem length_formula (n : Nat) :
    feasible n (shortestLength n) ∧ ∀ j, feasible n j → shortestLength n ≤ j := by
  cases n with
  | zero =>
    have hz : shortestLength 0 = 0 := rfl
    rw [hz]
    exact ⟨bound_feasible 0, fun _ _ => Nat.zero_le _⟩
  | succ n =>
    obtain ⟨l, hl, hmin⟩ := least_of_example _ _ (bound_feasible (n+1))
    have ht (k : Nat) : 0 < countFrom (n+1) k [] ↔ l ≤ k :=
      (feasible_iff ..).trans ⟨hmin k, extend_feasible (Nat.zero_lt_succ _) hl⟩
    have eq : shortestLength (n+1) = l :=
      (emptyLengths_eq _ _ ht _).trans (Nat.min_eq_right (hmin _ (bound_feasible _)))
    rw [eq]
    exact ⟨hl, hmin⟩

/-- Recover a witness by fixing the next symbol that leaves a positive
completion count. Starting from the right, k is the remaining length. -/
def recover (n : Nat) : Nat → Word n → Word n
  | 0, s => s
  | k+1, s =>
    match (List.finRange n).find? (fun a => decide (0 < countFrom n k (a :: s))) with
    | some a => recover n k (a :: s)
    | none => s

theorem recover_correct (n k : Nat) (s : Word n) (h : 0 < countFrom n k s) :
    IsSuper (recover n k s) ∧ (recover n k s).length = k + s.length := by
  induction k generalizing s with
  | zero =>
    obtain ⟨v, hl, hs⟩ := (countFrom_pos ..).mp h
    have he := List.eq_nil_of_length_eq_zero hl
    subst v
    exact ⟨by simpa [recover] using hs, by simp [recover]⟩
  | succ k ih =>
    obtain ⟨v, hl, hs⟩ := (countFrom_pos ..).mp h
    cases v with
    | nil => simp at hl
    | cons a v =>
      have ha : 0 < countFrom n k (a :: s) := (countFrom_pos ..).mpr
        ⟨v, by simpa using hl, by simpa [List.reverse_cons, List.append_assoc] using hs⟩
      rw [recover]
      split
      next x hx =>
        have hpos := List.find?_some (p := fun a => decide (0 < countFrom n k (a :: s))) hx
        have ⟨hc, hl⟩ := ih (x :: s) (of_decide_eq_true hpos)
        exact ⟨hc, by simp only [List.length_cons] at hl; omega⟩
      next hx =>
        exact False.elim ((List.find?_eq_none.mp hx a (by simp [List.finRange])) (by simpa using ha))

def shortestWord (n : Nat) : Word n := recover n (shortestLength n) []

theorem shortestWord_spec (n : Nat) :
    IsSuper (shortestWord n) ∧ (shortestWord n).length = shortestLength n ∧
    ∀ w : Word n, IsSuper w → (shortestWord n).length ≤ w.length := by
  obtain ⟨hf, hm⟩ := length_formula n
  have ⟨hc, hl⟩ := recover_correct n _ [] ((feasible_iff ..).mpr hf)
  have he : (shortestWord n).length = shortestLength n := by simpa [shortestWord] using hl
  exact ⟨hc, he, fun w hw => he ▸ hm _ ⟨w, rfl, hw⟩⟩

#print axioms countFrom_correct
#print axioms length_formula
#print axioms shortestWord_spec
end Superpermutation

import LengthBudget

/-! Use the exact numerical D16 table only in its published domain h+6s≤96.
Each external geometric premise is explicit. The 720-class model supplies
genuine disjoint successive 3-trails, their four-letter shifts, and budgets. -/
namespace SuperpermLowerBounds.LengthBudget.LinkedTransfer
open Hunter PreimageChain T5899

-- Generated from Haruhi7/lower/capD16_k.txt (SHA-256 f508e1e7b0c0147d6c0a22c76748fb63fe31741aee5df6634d9036ad70bf4982).
private def table : List (List Nat) := [
  [5, 5, 9, 9, 13, 13, 16, 16, 20, 20, 24, 24, 27, 27, 31, 31, 34, 34, 36, 38, 40, 41, 43, 44, 46, 47, 50, 51, 52, 54, 56, 57, 59, 60, 63, 64, 66, 66, 68, 69, 71, 72, 74, 75, 77, 79, 80, 82, 83, 85, 85, 86, 88, 89, 91, 92, 93, 94, 96, 97, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135],
  [10, 10, 14, 14, 18, 18, 22, 22, 26, 26, 29, 29, 33, 33, 36, 36, 40, 40, 44, 44, 46, 47, 49, 50, 53, 54, 56, 57, 60, 61, 62, 64, 66, 67, 69, 70, 70, 73, 74, 76, 77, 79, 80, 81, 82, 84, 85, 88, 89, 91, 92, 92, 94, 95, 97, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134],
  [15, 15, 19, 19, 23, 23, 27, 27, 31, 31, 35, 35, 39, 39, 42, 42, 45, 46, 49, 49, 52, 53, 56, 56, 59, 60, 63, 63, 66, 67, 69, 70, 71, 72, 74, 75, 76, 78, 79, 81, 82, 83, 85, 87, 88, 89, 92, 92, 94, 95, 96, 98, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133],
  [20, 20, 24, 24, 28, 28, 32, 32, 36, 36, 40, 40, 44, 44, 47, 48, 51, 51, 54, 55, 58, 58, 61, 62, 64, 65, 68, 69, 71, 72, 74, 75, 78, 79, 80, 81, 82, 83, 85, 87, 87, 89, 90, 92, 93, 97, 98, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132],
  [25, 25, 29, 29, 33, 33, 37, 37, 41, 41, 45, 45, 49, 49, 53, 53, 57, 57, 61, 61, 65, 65, 68, 68, 72, 72, 75, 75, 79, 79, 83, 83, 86, 86, 89, 90, 93, 93, 96, 97, 97, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131],
  [30, 30, 34, 34, 38, 38, 42, 42, 46, 46, 50, 50, 54, 54, 58, 58, 62, 62, 66, 66, 70, 70, 74, 74, 78, 78, 81, 81, 85, 85, 89, 89, 92, 92, 96, 96, 99, 99, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130],
  [35, 35, 39, 39, 43, 43, 47, 47, 51, 51, 55, 55, 59, 59, 63, 63, 67, 67, 71, 71, 75, 75, 79, 79, 83, 83, 87, 87, 91, 91, 94, 94, 98, 98, 102, 102, 105, 105, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129],
  [40, 40, 44, 44, 48, 48, 52, 52, 56, 56, 60, 60, 64, 64, 68, 68, 72, 72, 76, 76, 80, 80, 84, 84, 88, 88, 92, 92, 96, 96, 100, 100, 104, 104, 107, 107, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128],
  [45, 45, 49, 49, 53, 53, 57, 57, 61, 61, 65, 65, 69, 69, 73, 73, 77, 77, 81, 81, 85, 85, 89, 89, 93, 93, 97, 97, 101, 101, 105, 105, 109, 109, 113, 113, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127]]
def cap (s h : Nat) := (table.getD s []).getD h 0

/-- Geometric input from Halfar's D16. Only positive link counts through
eight and the indicated actual hole bounds occur in the thirteen branches. -/
def D16 := ∀s, 1 ≤ s → s ≤ 8 → PathCap s (cap s) (96-6*s)

private theorem cell (s h : Nat) (links : s ≤ 8) (small : h+6*s≤96) :
    cap s h ≤ h+39+5*s := by
  have cert : ∀a : Fin 9, ∀b : Fin 97, b.val+6*a.val≤96 → cap a.val b.val≤b.val+39+5*a.val := by native_decide
  exact cert ⟨s,by omega⟩ ⟨h,by omega⟩ small

/-- Costs transport unchanged under an arbitrary reordering of the real retained trails. -/
private theorem reordered {c : NConfig 7} (hv : c.Valid) (hc : c.cost≤140)
    {F : List (List (NRow 7))} (perm : F.Perm (famC c)) :
    TrailFam 7 F ∧ rowsHoles 7 F.flatten+6*(epsC c+F.length)≤126 ∧
    15+5*((epsC c : Int)+F.length) ≤ (F.flatten.length : Int)-rowsHoles 7 F.flatten := by
  have ⟨v,w⟩ := costs c hv (j:=3) hc
  have pp : (prs F).Perm (prs (famC c)) := perm.map _
  have eqV : lE (prs F)=lE (prs (famC c)) := (pp.map _).sum_eq
  have eqW : lW (prs F)=lW (prs (famC c)) := (pp.map _).sum_eq
  rw [←eqV,lE_prs] at v
  rw [←eqW,lW_prs] at w
  exact ⟨(famC_trailFam hv).of_subperm perm.subperm,by omega,by omega⟩

/-- Every ordering of the retained trails has at least one failed four-shift
join in all higher-excess 5904 branches. It need not be their original order. -/
theorem no_single_sequence (geom : D16) {c : NConfig 7} (hv : c.Valid)
    (hc : c.cost≤140) (e : 4≤epsC c) {F : List (List (NRow 7))}
    (perm : F.Perm (famC c)) (low : 2≤F.length) (up : F.length≤9) :
    ¬F.IsChain (RowLink 7 4) := by
  intro link
  obtain ⟨valid,weight,value⟩ := reordered hv hc perm
  let s := F.length-1
  let h := rowsHoles 7 F.flatten
  have size : F.length=s+1 := by dsimp [s]; omega
  have wb : h+6*s≤96 := by dsimp [h]; omega
  have upper := path_cap_rows (geom s (show 1 ≤ s by omega) (show s≤8 by omega)) valid link size (by change h≤_; omega)
  change F.flatten.length≤cap s h at upper
  have ck := cell s h (by omega) wb
  change 15+5*((epsC c : Int)+F.length) ≤ (F.flatten.length : Int)-h at value
  omega

/-- Published T1 restricted to *zero* shared classes. TrailFam ensures
global class disjointness of the two sequences and all constituent trails.
The symmetric link bounds are equivalent to putting the shorter piece last.
W counts holes plus six per four-shift and V counts rows minus holes minus
five per four-shift. This is a geometric hypothesis, not a finite table lemma. -/
def T1 := ∀ (A B : List (List (NRow 7))), TrailFam 7 (A++B) →
  A≠[] → B≠[] → A.IsChain (RowLink 7 4) → B.IsChain (RowLink 7 4) →
  let s := A.length-1
  let t := B.length-1
  max s t≤7 → min s t≤3 →
  let H := rowsHoles 7 (A++B).flatten
  H+6*(s+t)≤84 → (↑(A++B).flatten.length : Int)-H-5*((s : Int)+t)<50

/-- On each of the five e=5 viable counts (3 through 7), two nonempty
weight-four sequences do not suffice, even after arbitrary reordering. -/
theorem no_two_sequences (geom : T1) {c : NConfig 7} (hv : c.Valid) (hc : c.cost≤140)
    (e : 5≤epsC c) (A B : List (List (NRow 7))) (perm : (A++B).Perm (famC c))
    (bound : (A++B).length≤7) (a : A≠[]) (b : B≠[]) :
    ¬(A.IsChain (RowLink 7 4) ∧ B.IsChain (RowLink 7 4)) := by
  rintro ⟨la,lb⟩
  obtain ⟨valid,weight,value⟩ := reordered hv hc perm
  simp only [List.length_append] at bound weight value
  have pa := List.length_pos_iff.mpr a
  have pb := List.length_pos_iff.mpr b
  have z:=geom A B valid a b la lb (by omega) (by omega) (by omega)
  omega

section Failures
variable {α : Type*} (rel : α → α → Prop) [DecidableRel rel]

/-- One unit for each neighboring pair failing the prescribed shift. -/
def failures : List α → Nat
  | [] | [_] => 0
  | x::y::xs => (if rel x y then 0 else 1)+failures (y::xs)

private theorem chain_zero : ∀ (xs : List α), failures rel xs=0 → xs.IsChain rel
  | [], _ => List.isChain_nil
  | [x], _ => List.isChain_singleton _
  | x::y::xs, h => by
    rw [failures] at h
    have hh : rel x y := by by_contra no; simp [no] at h
    exact List.isChain_cons_cons.mpr ⟨hh,chain_zero (y::xs) (by simpa [hh] using h)⟩

private theorem split_one : ∀ (xs : List α), 2≤xs.length → failures rel xs≤1 →
    ∃ A B, xs=A++B ∧ A≠[] ∧ B≠[] ∧ A.IsChain rel ∧ B.IsChain rel
  | [], len, _ => by simp at len
  | [x], len, _ => by simp at len
  | [x,y], _, _ => ⟨[x],[y],rfl,by simp,by simp,List.isChain_singleton _,List.isChain_singleton _⟩
  | x::y::z::xs, _, small => by
    rw [failures] at small
    by_cases xy : rel x y
    · obtain ⟨A,B,join,na,nb,ra,rb⟩ := split_one (y::z::xs) (by simp)
        (by simpa [xy] using small)
      cases A with
      | nil => exact (na rfl).elim
      | cons a tail =>
        have hfirst : y=a := (List.cons.inj join).1
        subst a
        exact ⟨x::y::tail,B,congrArg (x::·) join,by simp,nb,List.isChain_cons_cons.mpr ⟨xy,ra⟩,rb⟩
    · have clean : failures rel (y::z::xs)=0 := by simp [xy] at small; omega
      exact ⟨[x],y::z::xs,rfl,by simp,by simp,List.isChain_singleton _,chain_zero rel _ clean⟩
end Failures

theorem two_failed_joins (geom : T1) {c : NConfig 7} (hv : c.Valid) (hc : c.cost≤140)
    (e : 5≤epsC c) {F : List (List (NRow 7))} (perm : F.Perm (famC c))
    (size : 2≤F.length) (up : F.length≤7) [DecidableRel (RowLink 7 4)] :
    2≤failures (RowLink 7 4) F := by
  by_contra! no
  obtain ⟨A,B,rfl,a,b,l,r⟩ := split_one (RowLink 7 4) F size (by omega)
  exact no_two_sequences geom hv hc e A B perm up a b ⟨l,r⟩

#print axioms two_failed_joins

/-- An independent one-frontier control showing the joint condition rejects
arithmetic profiles passing the separate D16 bounds and pair value ceiling.
It does not assert the existence of literal disjoint trails of these sizes. -/
theorem pair_control :
    let h₁:=12; let h₂:=36; let r₁:=27; let r₂:=66
    r₁≤cap 0 h₁ ∧ r₂≤cap 0 h₂ ∧ h₁+h₂≤90 ∧
    (r₁+r₂)-(h₁+h₂)=45 ∧ 6*(r₁+r₂)-(h₁+h₂)≤720 ∧
    cap 1 (h₁+h₂)<r₁+r₂ := by decide +kernel

/-- Three separate D16 cells and the linked D16 cell on the first two
pieces all allow the 5904 data. The T1 bound rejects these two grouped
sequences (effective value 50, weight 58). -/
theorem triple_control :
    13≤cap 0 4 ∧ 31≤cap 0 14 ∧ 63≤cap 0 34 ∧
    13+31≤cap 1 (4+14) ∧ 13+31+63-(4+14+34)=55 ∧
    6*(13+31+63)-(4+14+34)≤720 ∧ 4+14+34+6=58 ∧
    13+31+63-(4+14+34)-5=50 := by decide +kernel

/-- Number of unordered size pairs with specified raw value; each trail
obeys its single-chain D16 cell. The available area, 90-hole ceiling and
positive row sizes are enforced, and equal hole counts are ordered by rows. -/
private def pairCount (v : Nat) := ((List.range 91).map fun h =>
    if 720 < 5*h+6*v then 0 else ((List.range (h/2+1)).map fun h₁ =>
      let h₂ := h-h₁
      let total := h+v
      let lo := max 1 (total-cap 0 h₂)
      let hi := min (cap 0 h₁) (if h₁=h₂ then total/2 else total-1)
      hi+1-lo).sum).sum

theorem pair_census :
    ([45,46,47,48,49].map pairCount)=[13113,10593,8881,7360,5982] ∧
    ([45,46,47,48,49].map pairCount).sum=45929 := by native_decide

#print axioms triple_control
#print axioms pair_census
#print axioms no_single_sequence
#print axioms no_two_sequences
#print axioms pair_control
end SuperpermLowerBounds.LengthBudget.LinkedTransfer

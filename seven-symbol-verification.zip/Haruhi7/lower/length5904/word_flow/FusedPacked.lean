import FusedAny
import Cap94Encoding

namespace ExactWordFlow.FusedPacked
open SevenWordWindows ResidualDensity ResidualIncidence RotationComponentCount DirectedEuler
open WeightedMarks MarkedGeometry RotationCore ShortMarked
open private initial move from MarkedDensity
open private win dfs footprint mem_foot add_foot nextContexts usable add from FusedRoots294
open Cap94Lookup (bits bit code known)
open private entries code_inj bit_spec from Cap94Encoding

/-- A six-letter context fits in 18 bits using three bits per letter. -/
def addr : Six → Nat
  | [a,b,c,d,e,f] => a.val*32768+b.val*4096+c.val*512+d.val*64+e.val*8+f.val
  | _ => 0

private def push (x : Nat) (a : Fin 7) : Nat := (x%32768)*8+a.val
private theorem push_spec (x : Six) (hx : x.length=6) (a : Fin 7) :
    addr (step x a)=push (addr x) a := by
  obtain ⟨b,x,rfl,h5⟩:=List.length_eq_succ_iff.mp hx
  obtain ⟨c,x,rfl,h4⟩:=List.length_eq_succ_iff.mp h5
  obtain ⟨d,x,rfl,h3⟩:=List.length_eq_succ_iff.mp h4
  obtain ⟨e,x,rfl,h2⟩:=List.length_eq_succ_iff.mp h3
  obtain ⟨f,x,rfl,h1⟩:=List.length_eq_succ_iff.mp h2
  obtain ⟨g,x,rfl,h0⟩:=List.length_eq_succ_iff.mp h1
  have xe : x=[] := List.length_eq_zero_iff.mp h0
  subst x
  simp only [step,List.tail_cons,List.cons_append,List.nil_append,addr,push]
  have hb:=b.isLt; have hc:=c.isLt; have hd:=d.isLt; have he:=e.isLt; have hf:=f.isLt; have hg:=g.isLt
  omega

private structure Cell where
  valid : Bool := false
  ix : Nat := 0
  ink : Nat := 0
  rotor : Nat := 0
deriving Inhabited
private def cells : Array Cell :=
  states.foldl (fun table x=>table.set! (addr x)
    ⟨true,code (tag x),bit 0 (tag x),addr (x.rotate 1)⟩)
    (Array.replicate 262144 default)
private def atAddr (x : Nat) : Cell := cells[x]?.getD default
private def tableOK : Bool := states.all fun x=>
  let c:=atAddr (addr x)
  c.valid && c.ix==code (tag x) && c.ink==bit 0 (tag x) &&
    c.rotor==addr (x.rotate 1) && known (tag x)
private theorem tableData : tableOK=true := by native_decide
private theorem cellOf (x : Six) (hx : full x) :
    (atAddr (addr x)).valid=true ∧ (atAddr (addr x)).ix=code (tag x) ∧
    (atAddr (addr x)).ink=bit 0 (tag x) ∧ (atAddr (addr x)).rotor=addr (x.rotate 1) ∧
    tag x∈allClasses := by
  have h:=List.all_eq_true.mp tableData _ (mem_states hx)
  simp only [Bool.and_eq_true,beq_iff_eq] at h
  exact ⟨h.1.1.1.1,h.1.1.1.2,h.1.1.2,h.1.2,Cap94Lookup.board_of_known h.2⟩

private def next (b c : Bool) (x : Nat) : List Nat :=
  if b && c then [(atAddr x).rotor] else (List.finRange 7).map (push x)
private def advance (b : Bool) (x seen : Nat) : Option Nat :=
  if b then
    let d:=atAddr x
    if d.valid && !seen.testBit d.ix then some (d.ink ||| seen) else none
  else some seen

private def search (accept : Nat→Bool) : Nat → Nat → Bool → Nat → Nat → Bool
  | 0,st,b,x,seen => if win 0 st b then
      match advance b x seen with
      | none => true
      | some z => accept z
    else true
  | n+1,st,b,x,seen => if win (n+1) st b then
      match advance b x seen with
      | none => true
      | some z =>
        let st' := move st b
        [false,true].all (fun c=> !(win n st' c) ||
          (next b c x).all (fun y=>search accept n st' c y z))
    else true

def check (n : Nat) (accept : Nat→Bool) := search accept n initial true (addr FusedOne294.base) 0

private theorem next_spec {x : Six} {b c : Bool} (len : x.length=6) (valid : b=true → full x) :
    (nextContexts b c x).map addr=next b c (addr x) := by
  cases b <;> cases c <;> simp only [nextContexts,next,Bool.false_and,Bool.true_and,
    Bool.false_eq_true,↓reduceIte,List.map_map,List.map_cons,List.map_nil]
  all_goals first | exact congrArg (fun y=>[y]) (cellOf x (valid rfl)).2.2.2.1.symm
                  | exact List.map_congr_left (fun a _=>push_spec x len a)

private theorem advance_spec {b : Bool} {x : Six} {v : Std.HashSet Six}
    (usableHere : usable b x v=true) (board : footprint v⊆allClasses) :
    advance b (addr x) (bits 0 (footprint v)) = some (bits 0 (footprint (add b x v))) ∧
      footprint (add b x v)⊆allClasses ∧ (b=true → full x) := by
  cases b with
  | false => exact ⟨rfl,board,by simp⟩
  | true =>
    simp only [usable,Bool.not_true,Bool.false_or,Bool.and_eq_true,
      decide_eq_true_eq,Bool.not_eq_true'] at usableHere
    obtain ⟨hx,notin⟩:=usableHere
    have ax:=cellOf x hx
    have absent : (tag x)∉footprint v:=fun old=>by
      have :=Std.HashSet.contains_iff_mem.mpr (mem_foot.mp old)
      simp_all
    have nocc : (bits 0 (footprint v)).testBit (code (tag x))=false := by
      apply Bool.eq_false_iff.mpr
      intro yes
      obtain ⟨y,hy,eq⟩:=(bit_spec _ 0 board _).1 yes
      exact absent ((code_inj (board hy) ax.2.2.2.2 eq) ▸ hy)
    simp only [advance,ite_true,ax.1,ax.2.1,ax.2.2.1,nocc,Bool.not_false,Bool.and_self,
      add,add_foot]
    refine ⟨?_,Finset.insert_subset ax.2.2.2.2 board,fun _=>hx⟩
    simp [bits,Finset.fold_insert absent]

private theorem refines (acc : Nat→Bool) (cert : Finset Six→Bool)
    (leaf : ∀R⊆allClasses,acc (bits 0 R)=true → cert R=true)
    (n st : Nat) (b : Bool) (x : Six) (v : Std.HashSet Six) (len : x.length=6)
    (board : footprint v⊆allClasses)
    (passed : search acc n st b (addr x) (bits 0 (footprint v))=true) :
    dfs cert n st b x v=true := by
  induction n generalizing st b x v with
  | zero =>
    rw [dfs]
    split
    next h =>
      obtain ⟨edge,use⟩:=Bool.and_eq_true_iff.mp h
      obtain ⟨advance,ok,_⟩:=advance_spec use board
      simp only [search,edge,ite_true,advance] at passed
      exact leaf _ ok passed
    next => rfl
  | succ n ih =>
    rw [dfs]
    split
    next h =>
      obtain ⟨edge,use⟩:=Bool.and_eq_true_iff.mp h
      obtain ⟨advance,ok,valid⟩:=advance_spec use board
      simp only [search,edge,ite_true,advance] at passed
      apply List.all_eq_true.mpr
      intro c hc
      have kids:=List.all_eq_true.mp passed c hc
      by_cases yes : win n (move st b) c=true
      · simp only [yes,Bool.not_true,Bool.false_or] at kids ⊢
        apply List.all_eq_true.mpr
        intro y hy
        have member : addr y∈next b c (addr x) := by
          rw [←next_spec len valid]
          exact List.mem_map_of_mem hy
        have length : y.length=6 := by
          unfold nextContexts at hy
          split at hy
          next => simp_all
          next =>
            obtain ⟨a,_,rfl⟩:=List.mem_map.mp hy
            simp [step,List.length_tail,len]
        exact ih _ _ _ _ length ok (List.all_eq_true.mp kids _ member)
      · simp [yes]
    next => rfl

theorem certified (n : Nat) (acc : Nat→Bool) (cert : Finset Six→Bool)
    (leaf : ∀R⊆allClasses,acc (bits 0 R)=true → cert R=true)
    (passed : check n acc=true) : FusedAny.check n cert=true := by
  have e : footprint ({} : Std.HashSet Six)=∅ := by ext x; simp [mem_foot]
  apply refines acc cert leaf n initial true FusedOne294.base {} (by decide)
  · simp [e]
  · simpa only [check,e,bits,Finset.fold_empty] using passed

#print axioms certified
end ExactWordFlow.FusedPacked

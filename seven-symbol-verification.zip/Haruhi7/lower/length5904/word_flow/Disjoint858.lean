import TightIncidence
import WheelContacts

/-! The same actual 462-edge open route still covers all 720 classes with
66 wheels even when all chosen wheel class sets are disjoint. -/
namespace Dense462.DisjointWheels
open ExactWordFlow SevenWordWindows ResidualDensity WheelContacts
open Dense462.RankTight.IncidenceMap (contexts classList)

private def block (s : String) : Block := s.toList.map fun c => Fin.ofNat 7 (c.toNat-48)
def ids : List String := [
  "012345","012354","012435","012453","012534","013245","013254","013425",
  "013452","013524","013542","015234","015324","015342","021346","021364",
  "021634","023461","023641","024315","026134","031245","031425","031452",
  "032416","032461","032641","034125","034152","034216","034261","034621",
  "035124","035142","035412","036241","036421","042365","043125","043152",
  "043251","043521","045136","045163","045321","045613","046513","051234",
  "051243","051324","051342","053124","053142","053412","054213","062134",
  "063241","063421","064513","154326","154362","154623","154632","156423",
  "156432","165432"]
def wheels := ids.map block
def routes := Dense462.word :: wheels.map (fun s => s++s)
def families := routes.map RankTight.IncidenceMap.labels
def X : Multiset Block := ↑(routes.flatMap windows)
private def oneColor (v : Block) := decide (full v ∧ tag v∈wheel (block "012345"))

/-- Complete coverage, geometry, balance, and rank on an actual 858-edge
placement, whose 66 physical wheels have pairwise disjoint rotation-class sets. -/
theorem counterprofile : wheels.length=66 ∧ wheels.Nodup ∧
    (∀s∈wheels, s∈bases) ∧
    (wheels.map wheel).Pairwise Disjoint ∧
    X.card=858 ∧ X.map src + {Dense462.last}=X.map dst+{Dense462.first} ∧
    (routes.map fun w => (contexts w).toFinset).Pairwise Disjoint ∧
    (RankTight.IncidenceMap.labels Dense462.word).card=390 ∧
    families.toFinset.biUnion id = classList.toFinset ∧
    (families.map fun C => C.card-1).sum=719 := by native_decide

def pathContacts := wheels.map (fun w => (wheel w ∩ RankTight.IncidenceMap.labels Dense462.word).card)

/-- No two wheels meet, so the only component with more than one route
is the path and the wheels with a nonempty path contact. -/
theorem star_profile : (List.range 7).map pathContacts.count=[46,3,3,3,7,4,0] ∧
    ((wheels.map wheel).toFinset.biUnion id).card = 396 := by native_decide

private theorem split_check :
    (∀e∈required+X, oneColor (src e)=oneColor (dst e)) ∧
    block "0123456"∈required ∧ block "0123546"∈required ∧
    oneColor (src (block "0123456"))≠oneColor (src (block "0123546")) := by native_decide

theorem disconnected (s t : Block) : ¬ Feasible X s t := by
  intro h
  let S : Set Block := {v | oneColor v = oneColor s}
  have step (e : Block) (he : e∈required+X) (mem : src e∈S) : dst e∈S :=
    (split_check.1 e he).symm.trans mem
  have every := h.reachable S rfl step
  obtain ⟨hu,hv,different⟩ := split_check.2
  exact different ((every _ (Multiset.mem_add.mpr (Or.inl hu))).trans
    (every _ (Multiset.mem_add.mpr (Or.inl hv))).symm)

#print axioms counterprofile
#print axioms star_profile
#print axioms disconnected
end Dense462.DisjointWheels

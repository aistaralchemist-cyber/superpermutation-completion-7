import PermutationGenus

namespace ExactWordFlow.CycleCutDual
open Equiv
variable {X : Type*} [Fintype X] [DecidableEq X]

/-- In a cycle cover of a finite board, each nonempty cut label without
an outgoing edge traps a whole permutation cycle. Different labels trap
different cycles. One further cycle contains the distinguished outside
point. The labels consist of the naturals below b. -/
theorem exits_and_cycles (f : Perm X) (loopless : ∀x,f x≠x)
    (label : X→Nat) (b : Nat) (dummy : X) (outside : b≤label dummy)
    (occupied : ∀j<b, ∃x,label x=j) :
    b+1 ≤ (Finset.univ.filter (fun x=>label x<b ∧ label (f x)≠label x)).card +
      f.cycleFactorsFinset.card := by
  classical
  let D := Finset.univ.filter fun x=>label x<b ∧ label (f x)≠label x
  let lost := Finset.range b \ D.image label
  let pick (j : Nat) : X := if h : ∃x,label x=j then h.choose else dummy
  have bound (j) (hj : j∈lost) : j<b :=
    Finset.mem_range.mp (Finset.mem_sdiff.mp hj).1
  have point (j) (hj : j∈lost) : label (pick j)=j := by
    have yes:=occupied j (bound j hj)
    simp only [pick,dite_eq_left yes,Classical.choose_spec yes]
  have step (j) (hj : j∈lost) (x : X) (hx : label x=j) : label (f x)=j := by
    by_contra diff
    have hxD : x∈D := Finset.mem_filter.mpr ⟨Finset.mem_univ _,by
      exact ⟨hx ▸ (bound j hj),by simpa only [hx] using diff⟩⟩
    exact (Finset.mem_sdiff.mp hj).2 (Finset.mem_image.mpr ⟨x,hxD,hx⟩)
  have loops (x : X) : x∈(f.cycleOf x).support :=
    Perm.mem_support_cycleOf_iff.mpr ⟨Perm.SameCycle.refl _ _,Perm.mem_support.mpr (loopless x)⟩
  have factor (x : X) : f.cycleOf x∈f.cycleFactorsFinset :=
    Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr (Perm.mem_support.mpr (loopless x))
  have trapped (j) (hj : j∈lost) {y : X} (hy : y∈(f.cycleOf (pick j)).support) : label y=j := by
    have walk (n : Nat) : label ((f^n) (pick j))=j := by
      induction n with
      | zero => simpa using point j hj
      | succ n ih => simpa [pow_succ',Perm.mul_apply] using step j hj _ ih
    obtain ⟨n,_,_,eq⟩:=(Perm.mem_support_cycleOf_iff.mp hy).1.exists_pow_eq _
    exact eq ▸ walk n
  let image := lost.image fun j => f.cycleOf (pick j)
  have number : image.card=lost.card := by
    refine Finset.card_image_of_injOn ?_
    intro j hj k hk same
    have mm := loops (pick k)
    change f.cycleOf (pick j)=f.cycleOf (pick k) at same
    rw [←same] at mm
    exact (trapped j hj mm).symm.trans (point k hk)
  have fresh : f.cycleOf dummy∉image := by
    intro h
    obtain ⟨j,hj,eq⟩:=Finset.mem_image.mp h
    have mm:=loops dummy
    rw [←eq] at mm
    have tag:=trapped j hj mm
    have small:=bound j hj
    omega
  have fit : insert (f.cycleOf dummy) image⊆f.cycleFactorsFinset := by
    intro c hc
    rcases Finset.mem_insert.mp hc with rfl|inImage
    · exact factor _
    · obtain ⟨j,_,rfl⟩:=Finset.mem_image.mp inImage
      exact factor _
  have cap:=Finset.card_le_card fit
  rw [Finset.card_insert_of_notMem fresh,number] at cap
  have whole : Finset.range b ⊆ lost ∪ D.image label := by
    intro j hj
    by_cases seen : j∈D.image label
    · exact Finset.mem_union_right _ seen
    · exact Finset.mem_union_left _ (Finset.mem_sdiff.mpr ⟨hj,seen⟩)
  have bc:=(Finset.card_le_card whole).trans (Finset.card_union_le ..)
  have dc : (D.image label).card≤D.card := Finset.card_image_le
  rw [Finset.card_range] at bc
  change b+1 ≤ D.card+f.cycleFactorsFinset.card
  omega

/-- A checkable assignment dual with cut charges remains a lower bound for
arbitrary numbers of correction cycles if one adds one cost per cycle. -/
theorem cost_and_cycles (f : Perm X) (loopless : ∀x,f x≠x)
    (label : X→Nat) (b : Nat) (dummy : X) (outside : b≤label dummy)
    (occupied : ∀j<b, ∃x,label x=j) (row col : X→Int) (cost : X→X→Nat)
    (dual : ∀x y,x≠y → row x+col y+(if label x<b ∧ label y≠label x then (1:Int) else 0)≤cost x y) :
    (∑x,row x)+(∑x,col x)+(b:Int)+1 ≤
      (∑x,(cost x (f x):Int))+(f.cycleFactorsFinset.card:Int) := by
  have sum:=Finset.sum_le_sum (s:=Finset.univ) (fun x _=>dual x (f x) (loopless x).symm)
  rw [Finset.sum_add_distrib,Finset.sum_add_distrib,Equiv.sum_comp f col] at sum
  have exits:=exits_and_cycles f loopless label b dummy outside occupied
  have count : (∑x,if label x<b ∧ label (f x)≠label x then (1:Int) else 0)=
      ((Finset.univ.filter fun x=>label x<b ∧ label (f x)≠label x).card : Int) := by
    rw [←Finset.sum_filter]
    simp only [Finset.sum_const,nsmul_eq_mul,mul_one]
  rw [count] at sum
  omega

#print axioms exits_and_cycles
#print axioms cost_and_cycles
end ExactWordFlow.CycleCutDual

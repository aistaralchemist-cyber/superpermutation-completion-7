import PartitionLoss
import GlobalWheelRank

namespace ExactWordFlow.ResidualIncidence

/-- Every class can be reached by passing between intersecting contact sets.
Empty contact sets are ignored, and every class under discussion belongs
to the union of the listed contact sets. -/
def ContactConnected {ι α : Type*} [DecidableEq α] (Q : Finset ι) (C : ι → Finset α) : Prop :=
  ∀ S : Finset α, (S ∩ Q.biUnion C).Nonempty →
    (∀ i∈Q, (S ∩ C i).Nonempty → C i ⊆ S) → Q.biUnion C ⊆ S

private theorem inside_total {ι α : Type*} [DecidableEq ι] [DecidableEq α]
    {T Q : Finset ι} {C : ι → Finset α} (sub : T ⊆ Q) :
    T.biUnion C ⊆ Q.biUnion C := by
  intro x hx
  obtain ⟨i,hi,mem⟩ := Finset.mem_biUnion.mp hx
  exact Finset.mem_biUnion.mpr ⟨i,sub hi,mem⟩

/-- With exactly |V|-1 nominal connections, contact connectivity is
equivalent to the absence of a rank excess in *every* subfamily.  Hence
any incidence cycle certified by a subfamily excludes a saturated cover.
Conversely the test detects every disconnection at saturation. -/
theorem saturated_contact_iff {ι α : Type*} [DecidableEq ι] [DecidableEq α]
    (Q : Finset ι) (C : ι → Finset α)
    (saturated : ∑ i∈Q, ((C i).card-1) = (Q.biUnion C).card - 1) :
    ContactConnected Q C ↔
      ∀ T ⊆ Q, ∑ i∈T, ((C i).card-1) ≤ (T.biUnion C).card - 1 := by
  classical
  let w (i : ι) := (C i).card - 1
  let V := Q.biUnion C
  change ∑ i∈Q, w i = V.card-1 at saturated
  constructor
  · intro con T sub
    let U := T.biUnion C
    by_cases live : U.Nonempty
    · obtain ⟨H,inc,cost,done⟩ := GlobalWheelRank.grow U ((Q \ T).image C)
      have all : V ⊆ H := by
        apply con
        · obtain ⟨x,hx⟩ := live
          exact ⟨x,Finset.mem_inter.mpr ⟨inc hx,inside_total sub hx⟩⟩
        · intro i hi meet
          by_cases mem : i∈T
          · exact fun x hx => inc (Finset.mem_biUnion.mpr ⟨i,mem,hx⟩)
          · exact done (C i) (Finset.mem_image_of_mem _ (Finset.mem_sdiff.mpr ⟨hi,mem⟩)) meet
      have lower := Finset.card_le_card all
      have pay : ∑ b∈(Q \ T).image C, (b.card-1) ≤ ∑ i∈Q \ T, w i :=
        Finset.sum_image_le_of_nonneg (fun _ _ => Nat.zero_le _)
      have decomp := Finset.sum_sdiff (f:=w) sub
      have positive := Finset.card_pos.mpr live
      change ∑ i∈T, w i ≤ U.card - 1
      omega
    · have summ : ∑ i∈T, w i = 0 := by
        apply Finset.sum_eq_zero
        intro i hi
        have empty : C i=∅ := Finset.not_nonempty_iff_eq_empty.mp
          (fun ⟨x,hx⟩ => live ⟨x,Finset.mem_biUnion.mpr ⟨i,hi,hx⟩⟩)
        simp [w,empty]
      exact (show ∑ i∈T, w i = 0 from summ) ▸ Nat.zero_le _
  · intro forest S has closed
    let T := Q.filter (fun i => C i ⊆ S)
    let R := Q \ T
    let L := T.biUnion C
    let B := R.biUnion C
    have tq : T⊆Q := Finset.filter_subset ..
    have rq : R⊆Q := Finset.sdiff_subset
    have subset : L⊆S := by
      intro x hx
      obtain ⟨i,hi,hx⟩ := Finset.mem_biUnion.mp hx
      exact (Finset.mem_filter.mp hi).2 hx
    have avoid (x) (hx : x∈B) : x∉S := by
      obtain ⟨i,ir,hx⟩ := Finset.mem_biUnion.mp hx
      have ⟨iq,it⟩ := Finset.mem_sdiff.mp ir
      exact fun inside => it (Finset.mem_filter.mpr ⟨iq,closed i iq ⟨x,Finset.mem_inter.mpr ⟨inside,hx⟩⟩⟩)
    have partition : V=L∪B := by
      ext x
      constructor
      · intro hx
        obtain ⟨i,hi,hx⟩ := Finset.mem_biUnion.mp hx
        by_cases inT : i∈T
        · exact Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨i,inT,hx⟩)
        · exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨i,Finset.mem_sdiff.mpr ⟨hi,inT⟩,hx⟩)
      · intro hx
        exact (Finset.mem_union.mp hx).elim (fun mem => inside_total (C:=C) tq mem) (fun mem => inside_total (C:=C) rq mem)
    have dj : Disjoint L B := Finset.disjoint_left.mpr (fun x hl hb => avoid x hb (subset hl))
    have cards := Finset.card_union_of_disjoint dj
    rw [←partition] at cards
    have left := forest T tq
    have right := forest R rq
    change ∑ i∈T, w i ≤ L.card-1 at left
    change ∑ i∈R, w i ≤ B.card-1 at right
    have sumEq : (∑ i∈R, w i) + (∑ i∈T, w i) = ∑ i∈Q, w i :=
      Finset.sum_sdiff tq
    obtain ⟨inside,hs⟩ := has
    obtain ⟨ins,inv⟩ := Finset.mem_inter.mp hs
    have inL : inside∈L := ((Finset.mem_union.mp (partition ▸ (show inside∈V from inv))).resolve_right
      (fun hb => avoid _ hb ins))
    have pos := Finset.card_pos.mpr (show L.Nonempty from ⟨inside,inL⟩)
    intro x hx
    rcases Finset.mem_union.mp (partition ▸ (show x∈V from hx)) with l|r
    · exact subset l
    · have pos' := Finset.card_pos.mpr (show B.Nonempty from ⟨x,r⟩)
      omega

/-- Applied to arbitrary actual window multisets, a saturated simple rank
total forces the hyperforest inequality on every subfamily. -/
theorem feasible_saturated_subfamilies {ι : Type*} [DecidableEq ι] {X : Multiset Block} {s t : Block}
    (g : Block → ι) (h : Feasible X s t)
    (constant : ∀ e∈X, g (src e)=g (dst e))
    (saturated : let D := support X s; ∑ i∈D.image g, ((contacts D g i).card-1)=719) :
    let D := support X s
    ∀ T ⊆ D.image g, ∑ i∈T, ((contacts D g i).card-1) ≤ (T.biUnion (contacts D g)).card-1 := by
  classical
  dsimp only
  intro T ht
  by_contra! bad
  have ne : T.Nonempty := by
    by_contra no
    simp [Finset.not_nonempty_iff_eq_empty.mp no] at bad
  have pay := subfamily_loss g h constant T 1 ht ne (by dsimp only; omega)
  dsimp only at saturated
  omega

#print axioms saturated_contact_iff
#print axioms feasible_saturated_subfamilies
end ExactWordFlow.ResidualIncidence

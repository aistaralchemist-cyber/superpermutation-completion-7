import ExcursionForest
import WheelRepair

namespace ExactWordFlow.ExcursionCore
open SevenWordWindows RotationCore RotationReinsert LapSkeleton DirectedEuler ResidualDensity SuperpermutationBounds

/-- The shortest score representative with all 720 classes visited can be chosen
within 1508 letters whenever a 5904-letter superpermutation exists. The
universal routed-excision and wheel-repair inequalities apply to this same word. -/
theorem decision :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔ ∃v : Block, Minimal 5904 v ∧ v.length≤1508 := by
  constructor
  · intro yes
    obtain ⟨v,len,all,done⟩:=NinetyTwo.exact_length.mp yes
    exact necessity (by omega) all (by omega) done
  · rintro ⟨v,⟨long,all,cost,_⟩,_⟩
    obtain ⟨w,hw,sz⟩:=expand_remaining long all
    exact ⟨w,hw,sz.trans_le cost⟩

#print axioms decision
end ExactWordFlow.ExcursionCore

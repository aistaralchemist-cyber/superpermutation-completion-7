import EqualityComponent91

namespace ExactWordFlow.CoreDecision1501
open SevenWordWindows SuperpermutationBounds RotationCore ResidualDensity RotationReinsert

/-- A common word supplies the anchors of unselected classes and all seven-letter
windows of selected classes. An anchor of a selected class follows from completion. -/
def occurrenceCover (w : Block) (k : Nat) : Prop :=
  ∃ S : Finset Block, S ⊆ allClasses ∧ S.card = k ∧
    (∀ c ∈ allClasses \ S, ∃ i : Fin (anchors w).length,
      full ((anchors w).get i) ∧ tag ((anchors w).get i) = c) ∧
    (∀ p ∈ representatives, classKey p ∈ S →
      ∃ j : Fin (windows w).length, (windows w).get j = p)

theorem occurrenceCover_iff (w : Block) (k : Nat) :
    occurrenceCover w k ↔ (visited w).card = 720 ∧ k ≤ (complete w).card := by
  constructor
  · rintro ⟨S, legal, size, unselected, selected⟩
    have sub : S ⊆ complete w := by
      intro c hc
      apply (mem_complete w c).mpr
      refine ⟨legal hc, ?_⟩
      intro p hp hpc
      obtain ⟨i,eq⟩ := selected p hp (hpc ▸ hc)
      exact eq ▸ List.get_mem _ _
    have every : allClasses ⊆ visited w := by
      intro c hc
      by_cases hs : c ∈ S
      · exact complete_subset w (sub hs)
      · obtain ⟨i,clean,tagged⟩ := unselected c (Finset.mem_sdiff.mpr ⟨hc,hs⟩)
        exact (mem_visited w c).mpr ⟨_,List.get_mem _ _,clean,tagged⟩
    exact ⟨by rw [Finset.Subset.antisymm (visited_subset w) every,board],
      size ▸ Finset.card_le_card sub⟩
  · rintro ⟨all, count⟩
    obtain ⟨S,sub,size⟩ := Finset.exists_subset_card_eq count
    have same : visited w = allClasses := Finset.eq_of_subset_of_card_le (visited_subset w) (by rw [board,all])
    refine ⟨S,fun _ hc => visited_subset w (complete_subset w (sub hc)),size,?_,?_⟩
    · intro c hc
      have hit : c ∈ visited w := same ▸ (Finset.mem_sdiff.mp hc).1
      obtain ⟨u,hu,clean,key⟩ := (mem_visited w c).mp hit
      obtain ⟨i,eq⟩ := List.mem_iff_get.mp hu
      exact ⟨i,eq ▸ clean,eq ▸ key⟩
    · intro p hp hs
      exact List.mem_iff_get.mp (((mem_complete _ _).mp (sub hs)).2 p hp rfl)

/-- Reference decision procedure. One may split at any suffix and replace a
subtree by a separate proof that every extension of that suffix fails. -/
def search (accept : Block → Bool) : Nat → Block → Bool
  | 0, suffix => accept suffix
  | n+1, suffix => (List.finRange 7).any fun a => search accept n (a :: suffix)

theorem search_iff (accept : Block → Bool) (n : Nat) (suffix : Block) :
    search accept n suffix = true ↔
      ∃ pre : Block, pre.length = n ∧ accept (pre ++ suffix) = true := by
  induction n generalizing suffix with
  | zero => simp [search]
  | succ n ih =>
    rw [search,List.any_eq_true]
    constructor
    · rintro ⟨a,_,ok⟩
      obtain ⟨pre,len,hit⟩ := (ih (a::suffix)).mp ok
      exact ⟨pre++[a],by simp [len],by simpa using hit⟩
    · rintro ⟨pre,len,hit⟩
      induction pre using List.reverseRecOn with
      | nil => simp at len
      | append_singleton pre a _ =>
        refine ⟨a,by simp,(ih (a::suffix)).mpr ⟨pre,?_,?_⟩⟩
        · simpa using len
        · simpa using hit

def accept (w : Block) := decide ((visited w).card = 720 ∧ 91 ≤ (complete w).card)

def answer := search accept 1501 []

theorem answer_iff_short : answer = true ↔ ∃ w : Block, Covers w ∧ w.length ≤ 5904 := by
  rw [answer,search_iff,EqualityComponent91.short_word]
  simp only [List.append_nil,accept,decide_eq_true_eq]
  constructor
  · rintro ⟨w,len,hit,done⟩
    exact ⟨w,len,hit,le_antisymm (Core1501.ceiling w len.le hit) done⟩
  · rintro ⟨w,len,hit,done⟩
    exact ⟨w,len,hit,done.ge⟩

theorem false_iff_optimum : answer = false ↔ SuperpermBridge.HR.Ssuper 7 = 5905 := by
  rw [←Target107.goal_iff_minimum,EqualityComponent91.ceiling_equivalence,
    ←Core1501.completion_goal (@EqualityComponent91.component_limit),←answer_iff_short]
  exact Bool.eq_false_iff

/-- A proof-producing refutation may use any relaxation that is implied by
every genuine mixed occurrence witness. This direction alone suffices for UNSAT. -/
theorem optimum_of_refutation {model : Prop}
    (encode : ∀ w : Block, w.length = 1501 → occurrenceCover w 91 → model)
    (refute : ¬model) : SuperpermBridge.HR.Ssuper 7 = 5905 := by
  apply false_iff_optimum.mp
  rw [Bool.eq_false_iff,answer]
  intro ok
  obtain ⟨w,len,good⟩ := (search_iff accept 1501 []).mp ok
  exact refute (encode w len ((occurrenceCover_iff w 91).mpr (by simpa [accept] using good)))

/-- One concrete word directly settles the existence direction. -/
theorem short_of_witness {w : Block} (len : w.length = 1501)
    (good : occurrenceCover w 91) : ∃ z : Block, Covers z ∧ z.length ≤ 5904 := by
  apply answer_iff_short.mp
  rw [answer,search_iff]
  exact ⟨w,len,by simpa [accept] using (occurrenceCover_iff w 91).mp good⟩

/-- The same executable terminal predicate distinguishes the two boundary controls. -/
theorem controls :
    accept (RotationCoreControls.coreTruncated 629) = false ∧
    accept (RotationCoreControls.coreWord 629) = true := by
  obtain ⟨short,long⟩ := Core1501.controls
  change (_,_,_) = (1501,720,90) at short
  change (_,_,_) = (1502,720,91) at long
  have s := congrArg (fun t : Nat × Nat × Nat => t.2) short
  have l := congrArg (fun t : Nat × Nat × Nat => t.2) long
  have s1 := congrArg Prod.fst s
  have s2 := congrArg Prod.snd s
  have l1 := congrArg Prod.fst l
  have l2 := congrArg Prod.snd l
  simp only [accept]
  constructor <;> simp_all

#print axioms occurrenceCover_iff
#print axioms false_iff_optimum
end ExactWordFlow.CoreDecision1501

import ForcedRootClosure
namespace ExactWordFlow.FixedSeed235Exact
open SevenWordWindows SeedWheelCut ExtremeWheelCut ForcedRootClosure
open private digits from ExtremeWheelCut
open private cost from PlanarScoreExample

private def rows : List (Nat × String) := [
  (5, "0123456"),
  (5, "0234516"),
  (5, "0345126"),
  (5, "0451236"),
  (3, "0512346"),
  (5, "0651243"),
  (5, "0512463"),
  (5, "0124653"),
  (3, "0246513"),
  (5, "0324615"),
  (5, "0246135"),
  (3, "0461325"),
  (5, "0546123"),
  (5, "0461253"),
  (5, "0612543"),
  (3, "0125463"),
  (5, "0312564"),
  (5, "0125634"),
  (5, "0256314"),
  (3, "0563124"),
  (3, "0456321"),
  (5, "0145623"),
  (5, "0456213"),
  (5, "0562143"),
  (3, "0621453"),
  (5, "0362154"),
  (5, "0621534"),
  (3, "0215364"),
  (5, "0421563"),
  (5, "0215643"),
  (5, "0156423"),
  (3, "0564213"),
  (5, "0356412"),
  (5, "0564132"),
  (3, "0641352"),
  (5, "0264153"),
  (5, "0641523"),
  (5, "0415263"),
  (3, "0152643"),
  (5, "0315246"),
  (5, "0152436"),
  (5, "0524316"),
  (4, "0243156")]
def walk : List Block := rows.flatMap fun (r,s) =>
  (List.range (r+1)).map fun j => (digits s).take 1 ++ (digits s).tail.rotate j
def rootClasses := (walk.map classKey).toFinset
private def paid := (walk.zip walk.tail).map fun (x,y) => cost x y

theorem profile : (∀ p∈walk,p.length=7 ∧ p.Nodup) ∧ walk.length=235 ∧
    rootClasses.card=235 ∧ paid.length=234 ∧ paid.count 2=192 ∧ paid.count 3=42 ∧
    cost (walk.getLastD []) (walk.headD [])=6 ∧
    (paid.map fun d=>d-2).sum=42 ∧
    walk.length-6-5*(paid.map fun d=>d-2).sum=19 := by native_decide

theorem fixed : force rootClasses=rootClasses := by native_decide

#print axioms profile
#print axioms fixed
end ExactWordFlow.FixedSeed235Exact

import PermutationGenus
import Mathlib.Tactic

namespace ExactWordFlow.PermutationGenus
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [DecidableEq Y]

/-- A neutral fibre consists of the six possible tail rotation phases.
Marks include the closing transition and all paid nonneutral breaks.
An unmarked correction cycle requires one additional fibre representative;
every other fibre used by moved states must already contain a mark. -/
theorem neutral_fibre_capacity (h : Perm X) (key : X → Y) (B : Finset X)
    (seed : X) (marked : seed∈B) (moved : seed∈h.support)
    (cap : ∀y,(Finset.univ.filter (fun x=>key x=y)).card≤6)
    (step : ∀x,x∉B → key (h x)=key x) :
    h.support.card ≤ 6*(B.card+(h.cycleFactorsFinset.filter
      (fun c=>Disjoint c.support B)).card) ∧
    (h.cycleFactorsFinset.filter (fun c=>Disjoint c.support B)).card<h.cycleType.card := by
  classical
  let H := h.cycleFactorsFinset
  let E := H.filter (fun c=>Disjoint c.support B)
  let rep (c : Perm X) : X := if ne : c.support.Nonempty then ne.choose else seed
  let marks := B ∪ E.image rep
  have repMem (c : Perm X) (hc : c∈H) : rep c∈c.support := by
    obtain ⟨a,ha,_⟩:=(Perm.mem_cycleFactorsFinset_iff.mp hc).1
    have ne : c.support.Nonempty := ⟨a,Perm.mem_support.mpr ha⟩
    simpa only [rep,dite_eq_left ne] using ne.choose_spec
  have covers : h.support.image key⊆marks.image key := by
    intro y hy
    obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hy
    let c:=h.cycleOf x
    have hc : c∈H := Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr hx
    have witness : ∃z,z∈c.support ∧ z∈marks := by
      by_cases clean : Disjoint c.support B
      · exact ⟨rep c,repMem c hc,Finset.mem_union_right _ (Finset.mem_image_of_mem _
          (Finset.mem_filter.mpr ⟨hc,clean⟩))⟩
      · obtain ⟨z,hz,mb⟩:=Finset.not_disjoint_iff.mp clean
        exact ⟨z,hz,Finset.mem_union_left _ mb⟩
    obtain ⟨z,hz,hm⟩:=witness
    by_contra no
    have same (i : Nat) : key (((h^i) x))=key x := by
      induction i with
      | zero => simp
      | succ i ih =>
        have off : ((h^i) x)∉B := by
          intro hit
          exact no (Finset.mem_image.mpr ⟨_,Finset.mem_union_left _ hit,ih⟩)
        simpa [pow_succ',Perm.mul_apply,ih] using (step _ off).trans ih
    obtain ⟨i,_,_,eq⟩:=(Perm.mem_support_cycleOf_iff.mp hz).1.exists_pow_eq h
    exact no (Finset.mem_image.mpr ⟨z,hm,eq ▸ same i⟩)
  have localSize (y) : (h.support.filter (fun x=>key x=y)).card≤6 :=
    (Finset.card_le_card (Finset.filter_subset_filter _ (Finset.subset_univ _))).trans (cap y)
  have img : (h.support.image key).card≤B.card+E.card :=
    (Finset.card_le_card covers).trans ((Finset.card_image_le).trans
      ((Finset.card_union_le B (E.image rep)).trans (Nat.add_le_add_left Finset.card_image_le _)))
  have bound : h.support.card ≤ 6*(B.card+E.card) := by
    calc
      _ = ∑y∈h.support.image key,(h.support.filter (fun x=>key x=y)).card :=
        Finset.card_eq_sum_card_image _ _
      _ ≤ ∑_y∈h.support.image key,6 := Finset.sum_le_sum (fun y _=>localSize y)
      _ = 6*(h.support.image key).card := by simp [Nat.mul_comm]
      _ ≤ _ := Nat.mul_le_mul_left _ img
  have bad : h.cycleOf seed∈H := Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr moved
  have off : h.cycleOf seed ∉ E := by
    intro included
    exact Finset.disjoint_left.mp (Finset.mem_filter.mp included).2
      (Perm.mem_support_cycleOf_iff.mpr ⟨.refl _ _,moved⟩) marked
  have strict : E.card<H.card := Finset.card_lt_card <|
    Finset.ssubset_iff_of_subset (Finset.filter_subset _ _) |>.mpr ⟨_,bad,off⟩
  have num : H.card=h.cycleType.card := by simp [H,Perm.cycleType_def]
  exact ⟨bound,num ▸ strict⟩

/-- The length-5904 budget allows genus at most eight after normalization.
In particular expensive paid moves must have total extra cost at least
19+12g, plus six for each additional correction cycle with a marked break. -/
theorem canonical_budget {m k s g b u : Nat}
    (rank : m = k + 719 + 2 * g) (short : k + s + 2 * g ≤ 140)
    (capacity : m ≤ 6 * (b + u)) (markBound : b ≤ s + 1) (exceptional : u < k) :
    g ≤ 8 ∧ 19 + 12 * g + 6 * (k - u - 1) ≤ s := by omega

#print axioms neutral_fibre_capacity
#print axioms canonical_budget
end ExactWordFlow.PermutationGenus

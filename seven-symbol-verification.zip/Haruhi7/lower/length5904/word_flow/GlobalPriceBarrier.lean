import AverageCore
import PriceActionFast

namespace ExactWordFlow.GlobalPriceBarrier
open SevenWordWindows ExtremeWheelCut PriceAction

/-- Every candidate support of 390 tags admits a letter relabelling fixing
0 whose outside price fits 66 wheels. This rules out a single fixed price
table as a separating certificate for an entire label orbit. -/
theorem some_renaming (price : Block→ℝ) (K : ℝ) (A : Finset Block)
    (board : A⊆allClasses) (size : A.card=390)
    (cap : ∀w∈allRows,∀p∈w,∑x∈w.erase p,price x≤K) :
    ∃g∈allClasses,(∑x∈allClasses\A.image (rename g),price x)≤66*K :=
  AveragePrice.obstruction rename five _ _ latin geometry price K A board size cap

#print axioms some_renaming
end ExactWordFlow.GlobalPriceBarrier

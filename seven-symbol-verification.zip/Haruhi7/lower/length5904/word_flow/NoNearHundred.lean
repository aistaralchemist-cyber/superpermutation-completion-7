import NearHundredShape
import NoHundred
import ExtremeWheelFamilies

namespace ExactWordFlow.NoNearHundred
open SevenWordWindows DirectedEuler ResidualDensity RotationComponentCount RotationCore
open WeightedMarks ExtremalRealizations ExtremeWheelCut SuperpermutationBounds

/-- Any genuine flow in this band yields an alphabet-normalized root family
and a connected cover of the whole board by its N real wheel rows. -/
theorem cover_certificate {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    {N : Nat} (card : (occupied X s).card=N) (near : 96≤N) :
    ∃R∈realizations (NearExtrema.profiles N),∃W⊆allRows,
      W.card≤N ∧ SeedWheelCut.ClosedCover R allClasses W := by
  classical
  obtain ⟨es,ws,z,u,I,r,len,wd,colors,num,fullW,_,split,_⟩:=NearHundredShape.decompose h budget card near
  have high := card ▸ MarkedComponentCap.component_limit h budget
  have length : es.length+1=859-6*N := by omega
  have count : 720-5*N≤classCount s es := by omega
  obtain ⟨f,bij,zero,norm⟩:=route_coverage_at r wd length count (NearExtrema.profiles N)
    (fun v I walk mark observed=>NearExtrema.extreme_mask N near high walk mark 0 observed)
  have closed:=WheelRelabel.transport_closed fullW (HundredDecomposition.closed_cover h r fullW split) f bij.1 zero
  let vs:=ws.map (List.map f)
  have legal : vs.toFinset.image WheelContacts.wheel⊆allRows := by
    intro row hr
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hr
    obtain ⟨x,old,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hv)
    have fullX:=fullW x old
    have fullV : full (x.map f) := ⟨by simpa using fullX.1,fullX.2.map bij.1⟩
    obtain ⟨base,admissible,rows⟩:=WheelContacts.complete fullV
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨base,admissible,rows⟩)
  exact ⟨_,norm,_,legal,Finset.card_image_le.trans ((List.toFinset_card_le vs).trans
    (by simpa [vs] using num.le)),closed⟩

theorem component_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) : (occupied X s).card≤98 := by
  have prior:=NoHundred.component_limit h budget
  by_contra! many
  obtain ⟨root,profile,W,legal,cap,closed⟩:=cover_certificate h budget
    (show (occupied X s).card=99 by omega) (by decide)
  exact ExtremeWheelFamilies.no_99 profile legal cap closed

theorem exact_1550 :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
      ∃v : Block,6≤v.length ∧ v.length≤1550 ∧ (visited v).card=720 ∧ 98≤(complete v).card :=
  ComponentCurve.exact_threshold (k:=98) (m:=98) (@component_limit) (by decide) (by decide)

theorem completion_curve (k : Nat) (lo : 98≤k) (hi : k≤720) :
    IsLeast (lengthsFor k) (SuperpermBridge.HR.Ssuper 7-7*(720-k)) :=
  ComponentCurve.completion_curve (@component_limit) k (by omega) lo hi

theorem reference622 :
    RotationCoreControls.summary (RotationCoreControls.coreWord 622)=(1551,720,98) ∧
    RotationCoreControls.summary (RotationCoreControls.coreTruncated 622)=(1550,720,97) := by
  native_decide

#print axioms component_limit
#print axioms exact_1550
#print axioms completion_curve
#print axioms reference622
end ExactWordFlow.NoNearHundred

import GenusWitnesses

namespace ExactWordFlow.PermutationGenus
open Equiv

/-- Count every moved point where the correction agrees with the rotation.
The artificial closing edge is included if it satisfies these conditions.
In each correction cycle every charged tag has an uncharged survivor:
otherwise its entire nonempty fibre would be invariant under the
transitive permutation R*h. -/
theorem rotation_switch_bound {X Y : Type*} [Fintype X] [DecidableEq X]
    [Fintype Y] [DecidableEq Y] {R h : Perm X} (seed : X)
    (oneOrbit : ∀y,(R*h).SameCycle seed y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat}
    (genus : h.support.card=h.cycleType.card+719+2*g) :
    (h.support.filter (fun x=>h x=R x)).card ≤ 2*g := by
  classical
  let chosen (c : Perm X) := c.support.filter (fun x=>h x=R x)
  have keep (c : Perm X) (hc : c∈h.cycleFactorsFinset) (x) (hx : x∈chosen c) :
      ∃y∈c.support,y∉chosen c ∧ tag y=tag x := by
    by_contra missing
    let S (y : X):= y∈c.support ∧ tag y=tag x
    have start : S x := ⟨(Finset.mem_filter.mp hx).1,rfl⟩
    have agrees (y) (hy : S y) : h y=R y := by
      by_contra bad
      exact missing ⟨y,hy.1,fun mem=>bad (Finset.mem_filter.mp mem).2,hy.2⟩
    have singleStep (y) (hy : S y) : S (h y) := by
      have cy:= (Perm.mem_cycleFactorsFinset_iff.mp hc).2 y hy.1
      exact ⟨cy ▸ Perm.apply_mem_support.mpr hy.1,by rw [agrees y hy,rot,hy.2]⟩
    have step (y) (hy : S y) : S ((R*h) y) := by
      have h₁:=singleStep y hy
      change S (R (h y))
      rw [←agrees (h y) h₁]
      exact singleStep (h y) h₁
    have reach (n : Nat) : S (((R*h)^n) x) := by
      induction n with
      | zero => simpa using start
      | succ n ih => simpa [pow_succ',Perm.mul_apply] using step _ ih
    have every (z : X) : tag z=tag x := by
      obtain ⟨n,_,_,hn⟩:=((oneOrbit x).symm.trans (oneOrbit z)).exists_pow_eq _
      exact hn ▸ (reach n).2
    have all : (Finset.univ : Finset Y)⊆{tag x} := by
      intro y _
      obtain ⟨z,rfl⟩:=onto y
      simp [every z]
    have lim:=Finset.card_le_card all
    simp [classes] at lim
  have bound:=charge_contacts seed oneOrbit tag onto rot classes genus chosen
    (fun c _=>Finset.filter_subset _ _) keep
  have sub : h.support.filter (fun x=>h x=R x)⊆h.cycleFactorsFinset.biUnion chosen := by
    intro x hx
    obtain ⟨moved,equal⟩:=Finset.mem_filter.mp hx
    obtain ⟨c,hc,member⟩:=Perm.mem_support_iff_mem_support_of_mem_cycleFactorsFinset.mp moved
    exact Finset.mem_biUnion.mpr ⟨c,hc,Finset.mem_filter.mpr ⟨member,equal⟩⟩
  exact (Finset.card_le_card sub).trans ((Finset.card_biUnion_le).trans bound)

#print axioms rotation_switch_bound
end ExactWordFlow.PermutationGenus

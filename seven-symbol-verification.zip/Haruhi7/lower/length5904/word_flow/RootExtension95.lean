import RootExtension
import NinetyFour

namespace ExactWordFlow.RootExtension
open SeedWheelCut SevenWordWindows ExtremeWheelCut ResidualDensity ExtremalRealizations
open DirectedEuler RotationCore

/-- The entire family of optimal 245-tag roots transfers to every root
reachable with additional full wheels, charging each added wheel once. -/
theorem all95 {A B : Finset Block} {D W : Finset (Finset Block)}
    (root : A∈realizations (Cap95Profiles.profiles 95))
    (first : ClosedCover A B D) (dOK : D⊆allRows) (wOK : W⊆allRows)
    (bill : D.card+W.card≤95) : ¬ClosedCover B allClasses W :=
  inherit_cut 95 (fun h n=>NinetyFour.no_root_cover root h n) first dOK wOK bill

theorem add_one {A w : Finset Block} {W : Finset (Finset Block)}
    (root : A∈realizations (Cap95Profiles.profiles 95)) (meet : (A∩w).Nonempty)
    (row : w∈allRows) (legal : W⊆allRows) (count : W.card≤94) : ¬ClosedCover (A∪w) allClasses W :=
  all95 root (one_wheel A w meet) (Finset.singleton_subset_iff.mpr row) legal (by rw [Finset.card_singleton]; omega)

/-- No normalized-set membership hypothesis is needed for a genuine
288-edge root. The covers are transported along its alphabet relabelling. -/
theorem path95 {a b : Block} {es : List Block} (r : Route src dst a es b)
    (width : ∀t∈es,t.length=7) (len : es.length+1=289) (seen : 245≤classCount a es)
    (ws : List Block) (fullW : ∀v∈ws,full v) (count : ws.length≤95) :
    ¬ClosedCover (touched (a::es.map dst)) allClasses (ws.toFinset.image WheelContacts.wheel) := by
  classical
  intro cov
  obtain ⟨f,bij,z,geo⟩:=route_coverage_at r width len seen (Cap95Profiles.profiles 95)
    (fun v I walk mark observed=>Cap95Profiles.extreme_mask walk mark 0 observed)
  have closed:=WheelRelabel.transport_closed fullW cov f bij.1 z
  let vs:=ws.map (List.map f)
  have legal : vs.toFinset.image WheelContacts.wheel⊆allRows := by
    intro row hr
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hr
    obtain ⟨x,hx,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hv)
    have hx':=fullW _ hx
    have good:full (x.map f):=⟨by simpa using hx'.1,hx'.2.map bij.1⟩
    obtain ⟨base,ok,eq⟩:=WheelContacts.complete good
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨base,ok,eq⟩)
  have n : vs.length≤95 := by simpa [vs] using count
  exact NinetyFour.no_root_cover geo legal
    (Finset.card_image_le.trans ((List.toFinset_card_le vs).trans n)) closed

#print axioms all95
#print axioms path95
#print axioms add_one
end ExactWordFlow.RootExtension

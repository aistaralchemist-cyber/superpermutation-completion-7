import Target107
import ExactBoundary

namespace ExactWordFlow.LastCompletion
open SevenWordWindows SuperpermutationBounds RotationCore RotationReinsert ResidualDensity

/-- Below the four-letter interval the desired ceiling follows from the
existing public floor. At 1620 only a single further completion is possible. -/
theorem cap_from_floor {lower n c : Nat} (floor : Transfer5901.WordFloor lower)
    (csmall : c < 720) (bound : n+7*(720-(c+1)) < lower) : Target107.ceiling n c := by
  intro w small hit
  by_contra! larger
  have many:=LapSkeleton.completed_floor w
  have wins : (good w).length ≤ w.length-6 := by
    rw [←windows_length]; exact List.length_filter_le ..
  obtain ⟨z,yes,sz⟩:=expand_remaining (v:=w) (by omega) hit
  have floorz:=floor z yes
  omega

theorem at_most_108 (floor : Transfer5901.WordFloor 5898) : Target107.ceiling 1620 108 :=
  cap_from_floor floor (by decide) (by decide)

theorem through_1616 (floor : Transfer5901.WordFloor 5901) : Target107.ceiling 1616 107 :=
  cap_from_floor floor (by decide) (by decide)

/-- Any violating word in the research target has exactly 108 completions
and one of four lengths, without padding or a minimality requirement. -/
theorem only_boundary (floor : Transfer5901.WordFloor 5901) {w : Block}
    (small : w.length≤1620) (hit : (visited w).card=720) (violates : 107<(complete w).card) :
    (complete w).card=108 ∧ 1617≤w.length := by
  have weak : Transfer5901.WordFloor 5898 := fun z hz => Nat.le_trans (by decide) (floor z hz)
  have cap:=at_most_108 weak w small hit
  have shorter := through_1616 floor w
  omega

#print axioms cap_from_floor
#print axioms at_most_108
#print axioms only_boundary
end ExactWordFlow.LastCompletion

import ExactBoundary
import PacketJoin

namespace ExactWordFlow.PartialRepair
open SevenWordWindows SuperpermutationBounds RotationReinsert RotationCore ResidualDensity

private theorem fill (S : Finset Block) {w : Block} (long : 6≤w.length)
    (hit : ∀c∈S, HasAnchor w c) :
    ∃z : Block,z.length=w.length+7*S.card ∧ (∀p∈windows w,p∈windows z) ∧
        ∀p∈representatives,classKey p∈S → p∈windows z := by
  classical
  induction S using Finset.induction_on generalizing w with
  | empty => exact ⟨w,by simp,fun _ h=>h,by simp⟩
  | @insert c S no ih =>
    obtain ⟨u,size,remain,old,new⟩:=insert_class long (hit c (Finset.mem_insert_self ..))
    have hits (d) (hd : d∈S) : HasAnchor u d := by
      obtain ⟨v,hv,ok,eq⟩:=hit d (Finset.mem_insert_of_mem hd)
      exact ⟨v,remain v hv,ok,eq⟩
    obtain ⟨z,len,retain,seen⟩:=ih (by omega : 6≤u.length) hits
    refine ⟨z,by rw [Finset.card_insert_of_notMem no]; omega,fun p hp=>retain p (old p hp),?_⟩
    intro p hp sel
    rcases Finset.mem_insert.mp sel with eq|mem
    · exact retain p (new p hp eq)
    · exact seen p hp mem

/-- The six-letter anchor of a rotation whose first symbol is prescribed. -/
private def anchorFor (c : Block) (a : Fin 7) := (c.rotate (c.idxOf a)).take 6

private theorem geometry : ∀c∈allClasses,∀a : Fin 7,
    full (anchorFor c a) ∧ tag (anchorFor c a)=c ∧ (lapWord (anchorFor c a)).head?=some a ∧
    (lapWord (anchorFor c a)).length=13 := by native_decide

private theorem newPacket (c : Block) (hc : c∈allClasses) (a : Fin 7) :
    ∃tail : Block,tail.length=12 ∧ ∀p, p∈representatives ∧ classKey p=c → p <:+: (a::tail) := by
  obtain ⟨fullA,tagA,head,size⟩:=geometry c hc a
  have every:= (lap_geometry (anchorFor c a) fullA).2.2
  cases eq : lapWord (anchorFor c a) with
  | nil => simp [eq] at size
  | cons b rest =>
    have same : b=a := by simpa [eq] using head
    subst b
    refine ⟨rest,by simpa [eq] using size,?_⟩
    intro p hp
    have mem:=every p hp.1 (hp.2.trans tagA.symm)
    change p∈windows (lapWord (anchorFor c a)) at mem
    obtain ⟨u,v,occ⟩:=window_occurs _ mem
    exact ⟨u,v,occ.symm.trans eq⟩

/-- A missing visit can be bought for five extra letters beyond the
seven letters already allotted to each incomplete rotation class. -/
theorem expand_partial {w : Block} (long : 6≤w.length) :
    ∃z : Block, Covers z ∧ z.length = w.length+7*(720-(complete w).card)+5*(720-(visited w).card) := by
  classical
  let A:=visited w \ complete w
  let M:=allClasses \ visited w
  obtain ⟨u,sz,old,filled⟩:=fill (w:=w) A long (fun c hc => (mem_visited _ _).mp (Finset.mem_sdiff.mp hc).1)
  let P (c p : Block) := p∈representatives ∧ classKey p=c
  obtain ⟨z,size,keep,added⟩:=PacketJoin.glue M (fun _=>7) P u (by intro nil; simp [nil] at sz; omega)
    (fun c hc a => newPacket c (Finset.mem_sdiff.mp hc).1 a)
  refine ⟨z,?_,?_⟩
  · intro p len nd
    have hp: p∈representatives := (mem_reps _).mpr ⟨len,nd⟩
    have key : classKey p∈allClasses := List.mem_toFinset.mpr (List.mem_map_of_mem hp)
    have yes : p <:+: z := by
      by_cases h : classKey p∈visited w
      · have mid : p∈windows u := by
          by_cases done : classKey p∈complete w
          · exact old p (((mem_complete _ _).mp done).2 p hp rfl)
          · exact filled p hp (Finset.mem_sdiff.mpr ⟨h,done⟩)
        obtain ⟨l,r,eq⟩:=window_occurs u mid
        exact (show p <:+: u from ⟨l,r,eq.symm⟩).trans keep.isInfix
      · exact added _ (Finset.mem_sdiff.mpr ⟨key,h⟩) p ⟨hp,rfl⟩
    obtain ⟨l,r,eq⟩:=yes
    exact ⟨l,r,eq.symm⟩
  · have a : A.card=(visited w).card-(complete w).card := Finset.card_sdiff_of_subset (complete_subset _)
    have m : M.card=720-(visited w).card := by rw [show M=allClasses \ visited w from rfl,Finset.card_sdiff_of_subset (visited_subset _),board]
    have bounds:=(Finset.card_le_card (visited_subset w))
    have cc:=Finset.card_le_card (complete_subset w)
    rw [board] at bounds
    simp only [Finset.sum_const,smul_eq_mul] at size
    omega

theorem score_floor (floor : Transfer5901.WordFloor 5901) {u : Block} (long : 6≤u.length) :
    5901≤u.length+7*(720-(complete u).card)+5*(720-(visited u).card) := by
  obtain ⟨w,all,size⟩:=expand_partial long
  exact size ▸ floor w all

/-- Every shorter trial spelling is subject to the same deletion budget,
even when the trial has lost some of the originally visited rotation classes. -/
theorem edit_budget (floor : Transfer5901.WordFloor 5901) {u : Block} (long : 6≤u.length) :
    1529 ≤ u.length+3+7*(95-(complete u).card)+5*(720-(visited u).card) := by
  have low:=score_floor floor long
  omega

#print axioms expand_partial
#print axioms edit_budget
end ExactWordFlow.PartialRepair

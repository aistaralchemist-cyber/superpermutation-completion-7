import MarkedExtrema

namespace ResidualDensity.NearExtrema
open WeightedMarks MarkedGeometry
open private optimal runs maximizer from MarkedExtrema
open private upper initial start from MarkedDensity

/-- Empty interior runs denote a pair of consecutive unmarked positions.
All five widths begin at marked positions. -/
def profiles (N : Nat) := (optimal (859-6*N) initial).map (fun w=>runs w 0)

private def checked (N : Nat) : Bool :=
  let n:=859-6*N
  upper n initial==720-5*N &&
    (optimal n initial).all (fun bs=>
      let ns:=runs bs 0
      bs==rowsMask ns && !ns.isEmpty && 0<ns.head!)

private theorem data : ∀ d : Fin 5, checked (96+d.val)=true := by native_decide

theorem extreme_mask (N : Nat) (lo : 96≤N) (hi : N≤100)
    {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : ℕ) (many : 720-5*N≤count p i (859-6*N)) :
    ∃ns∈profiles N, ns≠[] ∧ 0<ns.head! ∧ mask p i (859-6*N)=rowsMask ns := by
  have ok:=data ⟨N-96,by omega⟩
  change checked (96+(N-96))=true at ok
  rw [show 96+(N-96)=N by omega] at ok
  unfold checked at ok
  rw [Bool.and_eq_true] at ok
  obtain ⟨maxResult,all⟩:=ok
  let bs := mask p i (859-6*N)
  have len : bs.length=859-6*N := by simp [bs,mask]
  have bound : upper bs.length initial≤bs.count true := by
    rw [len,eq_of_beq maxResult,mark_count]; exact many
  have hit:=maximizer [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i (859-6*N)) bound
  rw [len] at hit
  have row:=List.all_eq_true.mp all _ hit
  change ((bs==rowsMask (runs bs 0) && !(runs bs 0).isEmpty) && decide (0<(runs bs 0).head!))=true at row
  obtain ⟨⟨eq,nonempty⟩,pos⟩ := Bool.and_eq_true_iff.mp row |>.imp_left Bool.and_eq_true_iff.mp
  exact ⟨runs bs 0,List.mem_map_of_mem hit,by simpa using nonempty,of_decide_eq_true pos,eq_of_beq eq⟩

theorem counts : (List.range 5).map (fun d=>(profiles (100-d)).length)=[42,314,1365,6720,29872] := by
  native_decide
#print axioms extreme_mask
end ResidualDensity.NearExtrema

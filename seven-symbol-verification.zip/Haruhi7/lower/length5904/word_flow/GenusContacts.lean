import PermutationGenus

namespace ExactWordFlow.PermutationGenus
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- Different incidences of a correction cycle with the same rotation class
consume independent surplus rank. This is valid for every successor order. -/
theorem repeated_contacts {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (sevenClasses : Fintype.card Y=720) {g : Nat}
    (genus : h.support.card=h.cycleType.card+719+2*g) :
    (∑c∈h.cycleFactorsFinset, (c.support.card-(c.support.image tag).card)) ≤ 2*g := by
  classical
  let t (c : Perm X):=c.support.image tag
  let H:=h.cycleFactorsFinset
  obtain ⟨Z,base,bound,closed⟩:=GlobalWheelRank.grow {tag start} (H.image t)
  have seed:=base (Finset.mem_singleton_self _)
  have step (x) (mem : tag x∈Z) : tag ((R*h) x)∈Z := by
    rw [Perm.mul_apply,rot]
    by_cases fix : h x=x
    · simpa [fix] using mem
    · have moved:=Perm.mem_support.mpr fix
      have group : h.cycleOf x∈H:=Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr moved
      have contains (y) (hxy : h.SameCycle x y) : tag y∈t (h.cycleOf x) :=
        Finset.mem_image_of_mem _ (Perm.mem_support_cycleOf_iff.mpr ⟨hxy,moved⟩)
      exact closed _ (Finset.mem_image_of_mem _ group)
        ⟨_,Finset.mem_inter.mpr ⟨mem,contains x (.refl _ _)⟩⟩
        (contains _ (Perm.sameCycle_apply_right.mpr (.refl _ _)))
  have walk : ∀n : Nat,tag (((R*h)^n) start)∈Z := by
    intro n
    induction n with
    | zero => simpa using seed
    | succ n ih => simpa [pow_succ',Perm.mul_apply] using step _ ih
  have eq : Z=Finset.univ := by
    apply Finset.eq_univ_of_forall
    intro j
    obtain ⟨y,rfl⟩:=onto j
    obtain ⟨n,_,_,eq⟩:=(oneOrbit y).exists_pow_eq _
    exact eq ▸ walk n
  have charge : (∑u∈H.image t,(u.card-1)) ≤ ∑c∈H,((t c).card-1) :=
    Finset.sum_image_le_of_nonneg (fun _ _=>Nat.zero_le _)
  have cost : (∑c∈H, (c.support.card-(t c).card))+(∑c∈H,((t c).card-1))+H.card=
      h.support.card := by
    have e : (∑c∈H, (c.support.card-(t c).card+((t c).card-1)+1))=
        ∑c∈H,c.support.card := by
      apply Finset.sum_congr rfl
      intro c hc
      have leq : (t c).card≤c.support.card := Finset.card_image_le
      obtain ⟨x,hx,_⟩:=(Perm.mem_cycleFactorsFinset_iff.mp hc).1
      have pos:=Finset.card_pos.mpr (show (t c).Nonempty from
        ⟨tag x,Finset.mem_image_of_mem _ (Perm.mem_support.mpr hx)⟩)
      omega
    simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] at e
    exact e.trans h.sum_cycleType
  have pieces : h.cycleType.card=H.card := by simp [H,Perm.cycleType_def]
  simp only [eq,Finset.card_univ,Finset.card_singleton,sevenClasses] at bound
  change (∑c∈H,(c.support.card-(t c).card))≤2*g
  omega

#print axioms repeated_contacts
end ExactWordFlow.PermutationGenus

import SevenMoves

namespace ExactWordFlow.SevenMoves
open Equiv

def repr (v : Y) : X := Perm.decomposeFin.symm (0,v)

private theorem zero_pos : ∀i:Fin 7,(r^i.val) 0=i := by decide

theorem repr_tag (p:X) : repr (tag p)=normal p := by
  have zero : normal p 0=0:=by simp [normal,Perm.mul_apply,zero_pos]
  have fst (q:X) : (Perm.decomposeFin q).1=q 0 := by
    obtain ⟨⟨i,y⟩,rfl⟩:=Perm.decomposeFin.symm.surjective q
    simp
  apply Perm.decomposeFin.injective
  simp [repr,tag,Prod.ext_iff,fst,zero]

theorem tag_pow (p:X) (n:Nat) : tag (p*r^n)=tag p := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ,←mul_assoc]
    exact (tag_rot _).trans ih

def renameTag (u : X) (v : Y) : Y := tag (u*repr v)

theorem rename_tag (u p : X) : renameTag u (tag p)=tag (u*p) := by
  rw [renameTag,repr_tag,normal,←mul_assoc,tag_pow]

theorem rename_injective (u:X) : Function.Injective (renameTag u) := by
  intro a b eq
  obtain ⟨p,rfl⟩:=tag_surj a
  obtain ⟨q,rfl⟩:=tag_surj b
  have both:=congrArg (renameTag u⁻¹) eq
  simpa only [rename_tag,inv_mul_cancel_left] using both

theorem rename_owner (u p : X) : owner (u*p)=(owner p).image (fun y=>u*y) := by
  simp only [owner,Finset.image_image,Function.comp_def,mul_assoc]

end ExactWordFlow.SevenMoves

import CoreAssembly
import RotationSpan
import CoreControls

namespace ExactWordFlow.RotationCore
open SevenWordWindows SuperpermutationBounds RotationSpan

/-- A feasible budget of at most 858 supplies at most 108 selected
mandatory seven-cycles joining all residual components. Spell their root
component, then insert laps for any still-needed completed classes. -/
theorem exact_1620 :
    (∃w : Block, Covers w ∧ w.length≤5904) ↔
      ∃v : Block, 6≤v.length ∧ v.length≤1620 ∧
        (visited v).card=720 ∧ 108≤(complete v).card := by
  constructor
  · rintro ⟨w,hw,small⟩
    obtain ⟨a,b,decomp⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
    obtain ⟨X,cost,valid⟩ := extract_at_ends w hw (by simp [decomp]; omega)
    obtain ⟨S,sub,n,hit,must⟩ := rooted_spanning valid (by omega)
    obtain ⟨v,long,len,all,num⟩ := CoreAssembly.target valid sub n (by decide) hit must
    exact ⟨v,long,by omega,all,num⟩
  · rintro ⟨v,long,small,all,num⟩
    obtain ⟨w,yes,sz⟩ := expand_remaining long all
    exact ⟨w,yes,by omega⟩

theorem asked_iff_1620 :
    (∃v : Block, 6≤v.length ∧ v.length≤1823 ∧ (visited v).card=720 ∧ 137≤(complete v).card) ↔
    ∃v : Block, 6≤v.length ∧ v.length≤1620 ∧ (visited v).card=720 ∧ 108≤(complete v).card :=
  exact_1823.symm.trans exact_1620

theorem ceiling_108 (floor : ∀w : Block, Covers w → 5898≤w.length)
    {v : Block} (long : 6≤v.length) (cap : v.length≤1620) (all : (visited v).card=720) :
    (complete v).card≤108 := by
  obtain ⟨w,yes,sz⟩ := expand_remaining long all
  have lo := floor w yes
  omega

/-- Positive controls generated from the actual reference word (612 laps).
At length 1620 the completed count is exactly one below the decision threshold. -/
theorem reference612 :
    RotationCoreControls.summary (RotationCoreControls.coreWord 612)=(1621,720,108) ∧
    RotationCoreControls.summary (RotationCoreControls.coreTruncated 612)=(1620,720,107) := by
  native_decide

#print axioms asked_iff_1620
#print axioms reference612
end ExactWordFlow.RotationCore

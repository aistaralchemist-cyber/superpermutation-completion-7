import MacroSplit

namespace DirectedEuler.MacroAlternatives

variable {α β : Type*}

private theorem eraseDegree [DecidableEq α] {f g : α → β} {B : Multiset α}
    {s t : β} {e : α} (he : e∈B) (hs : f e=s)
    (degree : B.map f+{t}=B.map g+{s}) :
    (B.erase e).map f+{t}=(B.erase e).map g+{g e} := by
  have eq : ((e ::ₘ B.erase e).map f)+{t}=((e ::ₘ B.erase e).map g)+{s} := by
    rwa [Multiset.cons_erase he]
  rw [Multiset.map_cons,Multiset.map_cons,hs] at eq
  simp only [←Multiset.singleton_add] at eq
  exact add_left_cancel (a:=({s} : Multiset β)) (by
    simpa only [add_assoc,add_left_comm,add_comm] using eq)

/-- A finite integer flow contains a trail with its given ends and a balanced remainder. -/
theorem extract (f g : α → β) (B : Multiset α) (s t : β)
    (degree : B.map f+{t}=B.map g+{s}) :
    ∃ (p : List α) (R : Multiset α), ↑p+R=B ∧ Route f g s p t ∧ R.map f=R.map g := by
  classical
  by_cases eq : s=t
  · subst t
    exact ⟨[],B,by simp,.nil _,add_right_cancel degree⟩
  have hin : s∈B.map f+{t} := by rw [degree]; simp
  have out : ∃ e∈B, f e=s := by simpa [eq] using hin
  obtain ⟨e,he,hs⟩ := out
  obtain ⟨p,R,bag,walk,bal⟩ := extract f g (B.erase e) (g e) t (eraseDegree he hs degree)
  refine ⟨e::p,R,?_,.cons _ hs walk,bal⟩
  rw [←Multiset.cons_coe,Multiset.cons_add,bag,Multiset.cons_erase he]
termination_by B.card
decreasing_by
  classical
  simp [Multiset.card_erase_of_mem he]
  apply Multiset.card_pos.mpr
  rintro rfl
  simp at he

private theorem cycleOfBalanced (f g : α → β) (R : Multiset α) (nonempty : R≠0)
    (degree : R.map f=R.map g) :
    ∃ (v : β) (c : List α), c≠[] ∧ (↑c : Multiset α)≤R ∧ Route f g v c v := by
  classical
  obtain ⟨e,he⟩ := Multiset.exists_mem_of_ne_zero nonempty
  have eq : R.map f+{f e}=R.map g+{f e} := by rw [degree]
  obtain ⟨p,B,bag,walk,_⟩ := extract f g (R.erase e) (g e) (f e) (eraseDegree he rfl eq)
  refine ⟨f e,e::p,by simp,?_,.cons _ rfl walk⟩
  have eq' : (↑(e::p) : Multiset α)+B=R := by
    rw [←Multiset.cons_coe,Multiset.cons_add,bag,Multiset.cons_erase he]
  rw [←eq']
  exact le_self_add

private theorem dropTags (xs : List (Option α)) (clean : none∉xs) :
    ∃ ys : List α, xs=ys.map some := by
  induction xs with
  | nil => exact ⟨[],rfl⟩
  | cons o xs ih =>
    obtain ⟨ys,eq⟩ := ih (fun h => clean (List.mem_cons_of_mem _ h))
    cases o with
    | none => exact (clean List.mem_cons_self).elim
    | some e => exact ⟨e::ys,by simp [eq]⟩

private theorem plain {f g : α → β} {a b s t : β} (xs : List α)
    (r : Route (fun x : Option α => x.elim a f) (fun x => x.elim b g) s (xs.map some) t) :
    Route f g s xs t := by
  induction xs generalizing s with
  | nil => cases r; exact .nil _
  | cons e xs ih =>
    cases r with
    | cons _ hs tail => exact .cons e hs (ih tail)

private theorem concat {f g : α → β} {s m t : β} {p q : List α}
    (r : Route f g s p m) (h : Route f g m q t) : Route f g s (p++q) t := by
  induction r with
  | nil => exact h
  | cons e hs _ ih => exact .cons e hs (ih h)

private theorem forgetBound (D : Multiset α) {p : List (Option α)}
    (bound : (↑p : Multiset (Option α))≤D.map some+{none}) :
    (↑(p.filterMap id) : Multiset α)≤D := by
  have h := Multiset.filterMap_le_filterMap id bound
  have z : Multiset.filterMap id ({none} : Multiset (Option α))=0 := rfl
  simpa [Multiset.filterMap_map,Function.comp_def,z] using h

/-- Either all fresh edges are two literal end extensions, or a submultiset
of fresh edges spells a nonempty closed trail or a return from b to a. -/
theorem alternatives (f g : α → β) {a b s t : β} (D : Multiset α)
    (degree : D.map f+{a}+{t}=D.map g+{b}+{s}) :
    (∃ p q : List α, (↑(p++q) : Multiset α)=D ∧ Route f g s p a ∧ Route f g b q t) ∨
    (∃ (v : β) (c : List α), c≠[] ∧ (↑c : Multiset α)≤D ∧ Route f g v c v) ∨
    (∃ p : List α, (↑p : Multiset α)≤D ∧ Route f g b p a) := by
  classical
  let F (x : Option α) := x.elim a f
  let G (x : Option α) := x.elim b g
  let B := D.map some+{(none : Option α)}
  have bal : B.map F+{t}=B.map G+{s} := by
    simpa [B,F,G,Multiset.map_map,Function.comp_def] using degree
  obtain ⟨p,R,eq,walk,remBal⟩ := extract F G B s t bal
  by_cases empty : R=0
  · left
    exact MacroSplit.split f g D (by simpa [empty] using eq) walk
  obtain ⟨v,c,pos,sub,circ⟩ := cycleOfBalanced F G R empty remBal
  have cap : (↑c : Multiset (Option α))≤B :=
    sub.trans (eq ▸ (le_add_self : R≤(↑p : Multiset (Option α))+R))
  have fb := forgetBound D cap
  by_cases hit : none∈c
  · right; right
    obtain ⟨l,r,rfl⟩ := List.append_of_mem hit
    have count := Multiset.le_iff_count.mp cap none
    have bound : (↑(l++r) : Multiset (Option α)).count none=0 := by
      simpa [B,List.count_append,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using count
    have clean : none∉l++r := Multiset.count_eq_zero.mp bound
    obtain ⟨L,rfl⟩ := dropTags l (fun h => clean (List.mem_append_left _ h))
    obtain ⟨Q,rfl⟩ := dropTags r (fun h => clean (List.mem_append_right _ h))
    let D' : Multiset α := ↑(L++Q)
    have bag : (↑(L.map some++none::Q.map some) : Multiset (Option α))=D'.map some+{none} := by
      simp only [D',Multiset.map_add,Multiset.map_coe,←Multiset.coe_add,←Multiset.cons_coe,←Multiset.singleton_add]
      ac_rfl
    obtain ⟨u,w,eq',bef,aft⟩ := MacroSplit.split f g D' bag circ
    have small : D'≤D := by simpa [D',Function.comp_def] using fb
    exact ⟨w++u,by simpa only [←Multiset.coe_add,add_comm] using eq'.le.trans small,concat aft bef⟩
  · right; left
    obtain ⟨xs,rfl⟩ := dropTags c hit
    exact ⟨v,xs,by simpa using pos,by simpa [Function.comp_def] using fb,plain xs circ⟩

#print axioms alternatives
end DirectedEuler.MacroAlternatives

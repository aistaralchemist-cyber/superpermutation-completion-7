import Word5905

namespace SevenAlmostCover
open SuperpermutationBounds
namespace Record
open SuperpermLowerBounds.LengthBudget.Word5905
abbrev Word := List (Fin 7)
def truncated : Word := word.tail
private theorem boundary :
    word.take 7 = List.finRange 7 ∧ ¬ (List.finRange 7) <:+: truncated := by native_decide

theorem length_eq : truncated.length=5904 := by simp [truncated,length_5905]

theorem all_except (p : Word) (len : p.length=7) (hn : p.Nodup) :
    p <:+: truncated ↔ p≠List.finRange 7 := by
  constructor
  · rintro hp rfl; exact boundary.2 hp
  · intro neq
    obtain ⟨u,v,he⟩ := covers p len hn
    cases u with
    | nil =>
      exfalso
      have e := congrArg (List.take 7) he
      simp only [List.nil_append] at e
      have take : (p++v).take 7=p := List.take_left' len
      rw [boundary.1,take] at e
      exact neq e.symm
    | cons a u =>
      refine ⟨u,v,?_⟩
      exact (congrArg List.tail he).symm
end Record

open Record (Word)

noncomputable def relabel (p : Word) (h : p.length=7) (nd : p.Nodup) : Equiv.Perm (Fin 7) :=
  Equiv.ofBijective (fun i : Fin 7 => p[i.val]'(by omega)) (by
    apply Finite.injective_iff_bijective.mp
    intro i j ij
    exact Fin.ext (nd.eq_of_getElem_eq _ _ ij))

theorem relabel_map (p : Word) (h : p.length=7) (nd : p.Nodup) :
    (List.finRange 7).map (relabel p h nd) = p := by
  apply List.ext_getElem
  · simpa using h.symm
  · intro i hi hj
    simp [relabel,List.getElem_finRange]

private theorem map_infix {α β : Type*} (f : α → β) {a b : List α} (hc : a <:+: b) :
    a.map f <:+: b.map f := by
  obtain ⟨u,v,rfl⟩ := hc
  exact ⟨u.map f,v.map f,by simp⟩

/-- Every one of the 5,040 target clauses can be the sole failed clause
in a length-5,904 word. -/
theorem prescribed_omission (p : Word) (h : p.length=7) (nd : p.Nodup) :
    ∃ w : Word, w.length=5904 ∧
      ∀ q : Word, q.length=7 → q.Nodup → (q <:+: w ↔ q ≠ p) := by
  let f := relabel p h nd
  have map_eq : (List.finRange 7).map f=p := relabel_map p h nd
  refine ⟨Record.truncated.map f,by simp [Record.length_eq],?_⟩
  intro q hq nq
  have rev (x : Word) : (x.map f).map f.symm=x := by simp
  have inv (x : Word) : (x.map f.symm).map f=x := by simp
  constructor
  · intro contained eqp
    subst q
    apply (Record.all_except _ (by simp [h]) (nd.map f.symm.injective)).mp
      (by simpa [rev] using map_infix f.symm contained)
    rw [←map_eq,rev]
  · intro different
    have neq : q.map f.symm ≠ List.finRange 7 := by
      intro ee
      apply different
      exact (inv q).symm.trans ((congrArg (List.map f) ee).trans map_eq)
    have hit := (Record.all_except _ (by simpa using hq) (nq.map f.symm.injective)).mpr neq
    simpa [inv] using map_infix f hit

/-- A lower bound at 5,905 cannot follow from the presence of a fixed proper
subset of the target permutations alone. -/
theorem cover_proper_subset (S : Set Word) (p : Word) (h : p.length=7) (nd : p.Nodup)
    (omitted : p ∉ S) (valid : ∀ q∈S, q.length=7 ∧ q.Nodup) :
    ∃ w : Word, w.length=5904 ∧ ∀ q∈S, q <:+: w := by
  obtain ⟨w,lw,hits⟩ := prescribed_omission p h nd
  refine ⟨w,lw,?_⟩
  intro q hq
  obtain ⟨lq,nq⟩ := valid q hq
  exact (hits q lq nq).mpr (fun e => omitted (e ▸ hq))

end SevenAlmostCover
#print axioms SevenAlmostCover.prescribed_omission

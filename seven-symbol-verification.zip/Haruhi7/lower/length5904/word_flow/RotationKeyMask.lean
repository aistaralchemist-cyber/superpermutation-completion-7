import CoreCounts

namespace ExactWordFlow.RotationKeyMask
open SevenWordWindows ResidualDensity RotationCore

/-- The rotation of a zero-anchored class whose final symbol is a. -/
def endingAt (c : Block) (a : Fin 7) := c.rotate (c.idxOf a + 1)

private theorem endings : ∀ c ∈ allClasses, ∀ a : Fin 7,
    let p := endingAt c a
    p.length=7 ∧ p.Nodup ∧ classKey p=c ∧ p.getLast? = some a := by
  native_decide

private theorem recover : ∀ p ∈ representatives, ∀ a : Fin 7,
    p.getLast? = some a → endingAt (classKey p) a = p := by
  native_decide

private theorem zero_head : ∀ c ∈ allClasses, c = 0 :: c.tail := by native_decide

theorem tail_key_injective {c d : Block} (hc : c ∈ allClasses) (hd : d ∈ allClasses) :
    c.tail = d.tail ↔ c = d := by
  exact ⟨fun h => (zero_head c hc).trans ((congrArg (List.cons 0) h).trans (zero_head d hd).symm),
    fun h => congrArg List.tail h⟩

theorem key_last_unique {c : Block} (hc : c ∈ allClasses) (a : Fin 7) :
    ∃! p : Block, p ∈ representatives ∧ classKey p = c ∧ p.getLast? = some a := by
  obtain ⟨len,clean,key,last⟩ := endings c hc a
  refine ⟨endingAt c a,⟨(mem_reps _).mpr ⟨len,clean⟩,key,last⟩,?_⟩
  rintro p ⟨hp,eq,h⟩
  simpa [eq] using (recover p hp a h).symm

/-- The bit of a class is present precisely when a permutation of the class
with that last symbol is an actual seven-letter window of the word. -/
def bitSeen (w c : Block) (a : Fin 7) : Prop :=
  ∃ p ∈ windows w, p.Nodup ∧ classKey p = c ∧ p.getLast? = some a

theorem bitSeen_iff {w c : Block} (hc : c ∈ allClasses) (a : Fin 7) :
    bitSeen w c a ↔ endingAt c a ∈ windows w := by
  constructor
  · rintro ⟨p,hw,clean,key,last⟩
    have hp := (mem_reps p).mpr ⟨RotationReinsert.window_width w hw,clean⟩
    exact key ▸ (recover p hp a last).symm ▸ hw
  · intro hw
    obtain ⟨_,clean,key,last⟩ := endings c hc a
    exact ⟨endingAt c a,hw,clean,key,last⟩

theorem complete_iff_all_bits {w c : Block} (hc : c ∈ allClasses) :
    c ∈ complete w ↔ ∀ a : Fin 7, bitSeen w c a := by
  constructor
  · intro done a
    obtain ⟨len,clean,key,_⟩ := endings c hc a
    exact (bitSeen_iff hc a).mpr (((mem_complete w c).mp done).2 _ ((mem_reps _).mpr ⟨len,clean⟩) key)
  · intro bits
    apply (mem_complete w c).mpr
    refine ⟨hc,?_⟩
    intro p hp key
    have plen := ((mem_reps _).mp hp).1
    have nonempty : p ≠ [] := by intro h; simp [h] at plen
    let a := p.getLast nonempty
    have last : p.getLast? = some a := List.getLast?_eq_some_getLast nonempty
    have hw := (bitSeen_iff hc a).mp (bits a)
    simpa [←key,recover p hp a last] using hw

/-- In a clean six-letter anchor the missing symbol has a unique value. An
ensuing seven-letter window is clean exactly when its final symbol is that value. -/
theorem anchor_mask {u : Block} (clean : full u) (a : Fin 7) :
    let missing := (List.finRange 7).filter (fun x => x ∉ u)
    ((u ++ [a]).Nodup ↔ missing = [a]) ∧
    (missing = [a] → classKey (u ++ [a]) = tag u) := by
  have tab : ∀ u ∈ states, ∀ a : Fin 7,
      let missing := (List.finRange 7).filter (fun x => x ∉ u)
      ((u ++ [a]).Nodup ↔ missing = [a]) ∧
      (missing = [a] → classKey (u ++ [a]) = tag u) := by native_decide
  exact tab u (mem_states clean) a

private theorem route_contexts {s t : Block} {es : List Block} (h : DirectedEuler.Route src dst s es t) :
    s :: es.map dst = es.map src ++ [t] := by
  induction h with
  | nil => rfl
  | cons e start _ ih =>
    simp only [List.map_cons,List.cons_append,←ih,start]

/-- The circuit reads one six-letter prefix of each seven-letter window and
one final six-letter suffix, including a last visit with no completion bit. -/
theorem visited_iff_record {w c : Block} (long : 6 ≤ w.length) :
    c ∈ visited w ↔
      ∃ u ∈ (windows w).map src ++ [w.drop (w.length - 6)], full u ∧ tag u = c := by
  rw [mem_visited]
  unfold RotationReinsert.HasAnchor RotationReinsert.anchors
  rw [route_contexts (read_route w long)]

/-- All clean permutation windows emit the key of their starting six letters,
with the unique missing symbol as the seventh. -/
theorem permutation_record {p : Block} (hp : p ∈ representatives) :
    full (src p) ∧ tag (src p) = classKey p ∧
    (List.finRange 7).filter (fun a => a ∉ src p) = p.drop 6 ∧
    p.getLast? = (p.drop 6).head? := by
  have data : ∀ q ∈ representatives, full (src q) ∧ tag (src q) = classKey q ∧
      (List.finRange 7).filter (fun a => a ∉ src q) = q.drop 6 ∧
      q.getLast? = (q.drop 6).head? := by native_decide
  exact data p hp

#print axioms complete_iff_all_bits
#print axioms anchor_mask
end ExactWordFlow.RotationKeyMask

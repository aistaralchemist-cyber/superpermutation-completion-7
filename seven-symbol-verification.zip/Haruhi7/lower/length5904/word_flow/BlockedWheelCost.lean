import Overlap
import ExtremeWheelCut
import EmbeddedWheels

namespace ExactWordFlow.WheelCoverCapacity
open SevenWordWindows RotationCore ResidualDensity LiteralWheelCover ExtremeWheelCut

/-- Missing tags for which no legal row that meets the original visits
in just one tag is available, irrespective of physical anchor phases. -/
def blocked (V : Row) :=
  (allClasses\V) \ (allRows.filter (fun R=>(V∩R).card=1)).biUnion id

theorem missed_price {b : Block} {k : Nat} (fit : condition b k) :
    4*(allClasses\visited b).card+(blocked (visited b)).card≤20*k := by
  classical
  obtain ⟨S,valid,count,cover⟩:=fit
  let V:=visited b
  let M:=allClasses\V
  let B:=blocked V
  let U (R : Row):=R\V
  have total (R : Row) (hr : R∈S) : 4*(U R).card+((U R)∩B).card≤20 := by
    have readyRow:=valid hr
    obtain ⟨u,_,clean,rfl⟩:=mem_ready.mp readyRow
    let R:=WheelContacts.wheel u
    have size : R.card=6:=EmbeddedWheels.wheel_contacts_six u clean
    have limit : (U R).card≤5:=gain_le b readyRow
    have meet : (U R).card+(V∩R).card=6 := by
      simpa [U,Finset.inter_comm R V,size] using Finset.card_sdiff_add_card_inter R V
    by_cases allFive : (U R).card=5
    · have solo : (V∩R).card=1:=by omega
      obtain ⟨p,hp,eq⟩:=WheelContacts.complete clean
      have leg : R∈allRows:=List.mem_toFinset.mpr (List.mem_map.mpr ⟨p,hp,eq⟩)
      have empty : U R∩B=∅ := by
        apply Finset.eq_empty_iff_forall_notMem.mpr
        intro c h
        obtain ⟨cu,cb⟩:=Finset.mem_inter.mp h
        exact (Finset.mem_sdiff.mp cb).2
          (Finset.mem_biUnion.mpr ⟨R,Finset.mem_filter.mpr ⟨leg,solo⟩,(Finset.mem_sdiff.mp cu).1⟩)
      change 4*(U R).card+(U R∩B).card≤20
      rw [empty,Finset.card_empty,allFive]
    · have sub : (U R∩B).card≤(U R).card:=Finset.card_le_card Finset.inter_subset_left
      change 4*(U R).card+(U R∩B).card≤20
      omega
  have inc : M⊆S.biUnion U := by
    intro c hc
    obtain ⟨R,hr,cr⟩:=Finset.mem_biUnion.mp (cover hc)
    exact Finset.mem_biUnion.mpr ⟨R,hr,Finset.mem_sdiff.mpr ⟨cr,(Finset.mem_sdiff.mp hc).2⟩⟩
  have incB : B⊆S.biUnion (fun R=>U R∩B) := by
    intro c cb
    obtain ⟨R,hr,cu⟩:=Finset.mem_biUnion.mp (inc (Finset.mem_sdiff.mp cb).1)
    exact Finset.mem_biUnion.mpr ⟨R,hr,Finset.mem_inter.mpr ⟨cu,cb⟩⟩
  have coverM:=(Finset.card_le_card inc).trans Finset.card_biUnion_le
  have coverB:=(Finset.card_le_card incB).trans Finset.card_biUnion_le
  have cap:=Finset.sum_le_sum total
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_const,smul_eq_mul] at cap
  change 4*M.card+B.card≤20*k
  omega

theorem defect_cut {b : Block} {k : Nat} (done : (complete b).card=92)
    (budget : b.length+6*k=1508) (fit : condition b k) :
    4*(RauzyBudget.defect b+k)+(blocked (visited b)).card≤556 := by
  have price:=missed_price fit
  have total:=defect_split done budget fit
  omega

#print axioms defect_cut
end ExactWordFlow.WheelCoverCapacity

import Interval66
import EmbeddedWheels
import OverlapBudget
import ResidualControls

namespace ExactWordFlow.GlobalDensity66
open SevenWordWindows ResidualDensity ResidualDensity.Density66 DirectedEuler ResidualRoutes ResidualIncidence
open scoped Classical
open private count_add from DensityBudget
open private all_contacts from OverlapBudget
open private sizes from EmbeddedWheels

private def chunksCap (n b a : Nat) := a*(n/b)+6*(n%b/7)+(n%b)%7

/-- Combining 40- and 66-position intervals, allowing a 40-position prefix. -/
def cap (k : Nat) := let n := k+1
  min 720 (min (chunksCap n 40 34) (min (chunksCap n 66 56)
    (if 40≤n then 34+chunksCap (n-40) 66 56 else chunksCap n 66 56)))

private theorem open_cap {a b : Block} {p : List Block} (r : Route src dst a p b)
    (width : ∀e∈p,e.length=7) :
    classCount a p ≤ chunksCap (p.length+1) 40 34 ∧
    classCount a p ≤ chunksCap (p.length+1) 66 56 ∧
    classCount a p ≤ (if 40≤p.length+1 then 34+chunksCap (p.length+1-40) 66 56
      else chunksCap (p.length+1) 66 56) := by
  obtain ⟨u,I,w,hm,cc⟩ := open_observations r width
  have b40 := window_open_bound w hm (interval40 w hm) 0 (p.length+1)
  have b66 := window_open_bound w hm (interval66 w hm) 0 (p.length+1)
  rw [←cc]
  refine ⟨b40,b66,?_⟩
  split
  next long =>
    have split := count_add (·∈I) 0 40 (p.length+1-40)
    rw [show 40+(p.length+1-40)=p.length+1 by omega] at split
    exact split ▸ Nat.add_le_add (interval40 w hm 0)
      (window_open_bound w hm (interval66 w hm) (0+40) (p.length+1-40))
  next => exact b66

private theorem cyclic_cap {a : Block} {p : List Block} (r : Route src dst a p a)
    (width : ∀e∈p,e.length=7) (long : 66≤p.length) :
    66*classCount a p≤56*p.length := by
  obtain ⟨u,I,w,hm,cc⟩ := closed_observations r width (by omega)
  have n := window_cyclic_bound hm long (fun i pp _ hh => interval66 w hh i)
  simpa only [cc] using n

private theorem closed_price {a : Block} {p : List Block} (r : Route src dst a p a)
    (width : ∀e∈p,e.length=7) (small : p.length<79) : 6*(classCount a p-1)≤5*p.length := by
  by_cases h : p.length≤72
  · have z:=closed_small72 r width h
    omega
  · have z:=cyclic_cap r width (by omega)
    have ar : ∀k : Fin 79, ∀c : Fin 79, 66*c.val≤56*k.val → 6*(c.val-1)≤5*k.val := by decide +kernel
    exact ar ⟨p.length,small⟩ ⟨classCount a p,by omega⟩ z

noncomputable def large (X : Multiset Block) (s : Block) :=
  ((support X s).image (label X)).filter fun q => q≠label X s ∧ 79≤(part X q).card

private theorem prices {X : Multiset Block} {s t : Block}
    (bal : X.map src+{t}=X.map dst+{s}) (width : ∀e∈X,e.length=7) (budget : X.card≤858) :
    66*separateRank X s+66*(large X s).card≤56*X.card+82 ∧
    (large X s=∅ → let k := (part X (label X s)).card
      6*separateRank X s+5*k ≤ 5*X.card+6*(cap k-1)) := by
  classical
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  let C (q : Component X) := (contacts (support X s) (label X) q).card
  let Big (q) := q≠home ∧ 79≤K q
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q = X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have range (q : Component X) : K q≤858 := (Multiset.card_le_card (Multiset.filter_le ..)).trans budget
  have localPrice (q) (hq : q∈Q) :
      (q=home → C q≤cap (K q)) ∧ (Big q → 66*C q≤56*K q) ∧
      (q≠home → ¬Big q → 6*(C q-1)≤5*K q) := by
    obtain ⟨v,_,vv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩ := component_route bal v
    rw [vv] at eq lv ep
    have len : es.length=K q := congrArg Multiset.card eq
    have wd (e : Block) (he : e∈es) := width e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have incl : C q≤classCount a es := contacts_bound _ lv r eq
    refine ⟨fun _ => ?_,?_,?_⟩
    · obtain ⟨x,y,z⟩:=open_cap r wd
      rw [len] at x y z
      exact le_min (all_contacts ..) (le_min (incl.trans x) (le_min (incl.trans y) (incl.trans z)))
    · rintro ⟨away,big⟩
      obtain ⟨aa,bb⟩ := ep.2 away
      subst a; subst b
      have zz := cyclic_cap r wd (by omega)
      omega
    · intro away no
      obtain ⟨aa,bb⟩ := ep.2 away
      subst a; subst b
      have small : es.length<79 := by by_contra! no'; exact no ⟨away,by omega⟩
      have zz := closed_price r wd small
      omega
  constructor
  · have scalar : ∀k : Fin 859, 66*(cap k.val-1)≤56*k.val+82 := by native_decide
    have unit (q) (hq : q∈Q) : 66*(C q-1)+(if Big q then 66 else 0) ≤ 56*K q+(if q=home then 82 else 0) := by
      obtain ⟨op,bg,cl⟩ := localPrice q hq
      by_cases hh : q=home
      · have nbg : ¬Big q := fun e => e.1 hh
        simp only [ite_eq_right nbg,ite_eq_left hh,Nat.add_zero]
        exact (Nat.mul_le_mul_left 66 (Nat.sub_le_sub_right (op hh) 1)).trans (scalar ⟨K q,by have:=range q; omega⟩)
      · rw [ite_eq_right hh,Nat.add_zero]
        by_cases bb : Big q
        · rw [ite_eq_left bb]
          have z:=bg bb
          have big:=bb.2
          omega
        · rw [ite_eq_right bb,Nat.add_zero]
          have := cl hh bb
          omega
    have sum := Finset.sum_le_sum unit
    have cardB : (∑q∈Q,if Big q then 66 else 0)=66*(large X s).card := by
      rw [←Finset.sum_filter]; simp [Q,large,Big,K,home,Nat.mul_comm]
    simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_ite_eq',root,ite_true,cardB,total] at sum
    exact sum
  · intro empty
    have small (q) (hq : q∈Q.erase home) : 6*(C q-1)≤5*K q := by
      obtain ⟨away,mem⟩ := Finset.mem_erase.mp hq
      apply (localPrice q mem).2.2 away
      intro b
      have yes : q∈large X s := Finset.mem_filter.mpr ⟨mem,b⟩
      simp [empty] at yes
    have sum:=Finset.sum_le_sum small
    simp only [←Finset.mul_sum] at sum
    have cq:=Finset.sum_erase_add (s:=Q) (fun q=>C q-1) root
    have kq:=Finset.sum_erase_add (s:=Q) K root
    rw [total] at kq
    have rc := (localPrice home root).1 rfl
    change 6*(∑q∈Q,(C q-1))+5*K home≤5*X.card+6*(cap (K home)-1)
    omega

/-- Unconditional on endpoints, paths, wheels, or the number of components. -/
theorem rank_728 {X : Multiset Block} {s t : Block}
    (bal : X.map src+{t}=X.map dst+{s}) (width : ∀e∈X,e.length=7) (budget : X.card≤858) :
    separateRank X s≤728 := by
  obtain ⟨sum,anchor⟩ := prices bal width budget
  by_cases emp : large X s=∅
  · have z:=anchor emp
    let k:=(part X (label X s)).card
    have le : k≤X.card := Multiset.card_le_card (Multiset.filter_le ..)
    have ck : ∀m : Fin 859, 5*(858-m.val)+6*(cap m.val-1)<6*729 := by native_decide
    have bound := ck ⟨k,by omega⟩
    change 6*separateRank X s+5*k≤5*X.card+6*(cap k-1) at z
    change 5*(858-k)+6*(cap k-1)<6*729 at bound
    omega
  · have pos := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr emp)
    omega

/-- Away from a closed component of at least 79 edges, the open component
must have at least 210 edges to reach the required incidence rank. -/
theorem root_210_or_closed_79 {X : Multiset Block} {s t : Block}
    (yes : Feasible X s t) (budget : X.card≤858) :
    210≤(part X (label X s)).card ∨ ∃q : Component X, q≠label X s ∧ 79≤(part X q).card := by
  by_cases emp : large X s=∅
  · left
    have small:= (prices yes.balance yes.edges_seven budget).2 emp
    have rank : 719 ≤ separateRank X s := rank719 (label X) yes (fun _ he => on_edge he)
    let k:=(part X (label X s)).card
    change 6*separateRank X s+5*k≤5*X.card+6*(cap k-1) at small
    by_contra! h
    have ck : ∀m : Fin 210, 6*(cap m.val-1)<5*m.val+24 := by native_decide
    have lim := ck ⟨k,h⟩
    change 6*(cap k-1)<5*k+24 at lim
    omega
  · obtain ⟨q,hq⟩:= Finset.nonempty_iff_ne_empty.mpr emp
    exact Or.inr ⟨q,(Finset.mem_filter.mp hq).2⟩

/-- The sum of independent incidence losses is at most nine. -/
theorem loss_nine {X : Multiset Block} {s t : Block} (yes : Feasible X s t)
    (budget : X.card≤858) {d : Nat} (loss : 719+d ≤ separateRank X s) : d≤9 := by
  have hi := rank_728 yes.balance yes.edges_seven budget
  omega

/-- Removing any collection of disjoint-in-multiplicity full six-turns
from a feasible flow leaves at least 210 edges. -/
theorem turn_limit {Y : Multiset Block} {s t : Block} {ws : List Block}
    (legit : ∀w∈ws,full w) (yes : Feasible (Y+EmbeddedWheels.turns ws) s t)
    (budget : (Y+EmbeddedWheels.turns ws).card≤858) : 210≤Y.card ∧ ws.length≤108 := by
  have wheel := sizes legit
  have yb:=Essential.restBalance yes wheel.2
  have yw (e) (he : e∈Y) := yes.edges_seven e (Multiset.mem_add.mpr (Or.inl he))
  rw [Multiset.card_add,wheel.1] at budget
  have rank : 719 ≤ 5*ws.length+separateRank Y s := EmbeddedWheels.residual_rank ws legit yes
  have rem : 210≤Y.card := by
    by_cases emp : large Y s=∅
    · have b:= (prices yb yw (by omega)).2 emp
      let k := (part Y (label Y s)).card
      have l : k≤Y.card := Multiset.card_le_card (Multiset.filter_le ..)
      change 6*separateRank Y s+5*k≤5*Y.card+6*(cap k-1) at b
      by_contra! lt
      have ck : ∀m : Fin 210, 6*(cap m.val-1)<5*m.val+24 := by native_decide
      have lim := ck ⟨k,by omega⟩
      change 6*(cap k-1)<5*k+24 at lim
      omega
    · have nonempty : (largeOther Y s).Nonempty := by
        obtain ⟨q,hq⟩ := Finset.nonempty_iff_ne_empty.mpr emp
        obtain ⟨mem,other,sz⟩:= Finset.mem_filter.mp hq
        exact ⟨q,Finset.mem_filter.mpr ⟨mem,other,by omega⟩⟩
      have nonzero:=Finset.card_pos.mpr nonempty
      have price:=(component_prices yb yw).1
      have maxMass:=long_mass_le Y s
      omega
  exact ⟨rem,by omega⟩

/-- The new 66-state ceiling is attained inside the reference spine.
The first state in this segment has zero-based index five. -/
theorem window_sharp :
    let w := (ResidualControls.mainWord.drop 5).take 71
    (windows w).length=65 ∧ classCount (w.take 6) (windows w)=56 := by native_decide

#print axioms window_sharp
#print axioms loss_nine
#print axioms turn_limit
#print axioms rank_728
#print axioms root_210_or_closed_79
end ExactWordFlow.GlobalDensity66

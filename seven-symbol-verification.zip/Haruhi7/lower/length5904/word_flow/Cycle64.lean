import GlobalWheelRank
import RouteDensity

namespace ExactWordFlow.ShortFreshCycle
open DirectedEuler ResidualDensity

def mark (v : Block) : Option Block := if full v then some (tag v) else none

def starts : Nat → List Block
  | 0 => [[]]
  | n+1 => (List.finRange 7).flatMap fun a => (starts n).map (a::·)

theorem memStarts (v : Block) : v∈starts v.length := by
  induction v with
  | nil => simp [starts]
  | cons a v ih => exact List.mem_flatMap.mpr ⟨a,List.mem_finRange _,List.mem_map.mpr ⟨v,ih,rfl⟩⟩

/-- Check every return to the initial state along a trail with distinct
observations. The reversed edge list also certifies the exact wheel multiset. -/
private def scan (first cur : Block) (seen : List (Option Block)) (back : List Block) : Nat → Bool
  | 0 => decide (cur=first → 2≤back.length → full first ∧ back.reverse=GlobalWheelRank.wheel first)
  | fuel+1 =>
    decide (cur=first → 2≤back.length → full first ∧ back.reverse=GlobalWheelRank.wheel first) &&
    (if mark cur ∈ seen then true else
      (List.finRange 7).all fun a => scan first (cur.tail++[a]) (mark cur::seen) ((cur++[a])::back) fuel)

private theorem table : (starts 6).all (fun s => scan s s [] [] 12)=true := by native_decide

theorem edge_eq {e : Block} (w : e.length=7) :
    ∃ a, e=src e++[a] ∧ dst e=(src e).tail++[a] := by
  have nex : e≠[] := by intro eq; simp [eq] at w
  have t : src e=e.dropLast := by rw [List.dropLast_eq_take,w]; rfl
  have h := e.dropLast_concat_getLast nex
  have eq : e=src e++[e.getLast nex] := by rw [t,h]
  refine ⟨_,eq,?_⟩
  have non : src e≠[] := by intro he; have := congrArg List.length he; simp [src,w] at this
  rw [dst,List.drop_one]
  conv_lhs => rw [eq]
  rw [List.tail_append_of_ne_nil non]

private theorem sound (first cur : Block) (seen : List (Option Block)) (back : List Block)
    (fuel : Nat) (es : List Block) (ok : scan first cur seen back fuel=true)
    (rt : Route src dst cur es first) (width : ∀e∈es,e.length=7)
    (distinct : ((es.map (mark ∘ src))++seen).Nodup) (size : es.length≤fuel)
    (two : 2≤back.length+es.length) :
    full first ∧ back.reverse++es=GlobalWheelRank.wheel first := by
  induction fuel generalizing cur seen back es with
  | zero =>
    have enil : es=[] := List.eq_nil_of_length_eq_zero (by omega)
    subst es
    cases rt
    simpa using (of_decide_eq_true ok rfl (by simpa using two))
  | succ fuel ih =>
    obtain ⟨stop,cont⟩ := Bool.and_eq_true_iff.mp ok
    cases es with
    | nil =>
      cases rt
      simpa using (of_decide_eq_true stop rfl (by simpa using two))
    | cons e es =>
      cases rt with
      | cons _ hs tail =>
        obtain ⟨a,eq,nxt⟩ := edge_eq (width e List.mem_cons_self)
        subst cur
        have nd : (mark (src e)::((es.map (mark ∘ src))++seen)).Nodup := distinct
        obtain ⟨absent,rest⟩ := List.nodup_cons.mp nd
        have fresh : mark (src e)∉seen := fun h => absent (List.mem_append_right _ h)
        rw [ite_eq_right fresh] at cont
        have next := List.all_eq_true.mp cont a (List.mem_finRange _)
        rw [←nxt,←eq] at next
        have nd' : ((es.map (mark ∘ src))++mark (src e)::seen).Nodup := by
          exact (List.perm_middle ..).nodup_iff.mpr nd
        have out := ih _ _ _ _ next tail (fun f hf => width f (List.mem_cons_of_mem _ hf))
          nd' (by simp at size; omega) (by simp at two ⊢; omega)
        simpa using out

/-- With any common label for all dirty states, a nontrivial closed route
of at most twelve edges with no repeated projected source is a complete wheel. -/
theorem tight_cycle_twelve (d : Block) {s : Block} {es : List Block}
    (r : Route src dst s es s) (width : ∀e∈es,e.length=7)
    (lo : 2≤es.length) (hi : es.length≤12)
    (tight : (es.map (fun e => if full (src e) then tag (src e) else d)).Nodup) :
    full s ∧ es=GlobalWheelRank.wheel s := by
  have dec : ((es.map (mark ∘ src)).map (fun z : Option Block => z.getD d)).Nodup := by
    have eq (e : Block) : (mark (src e)).getD d = (if full (src e) then tag (src e) else d) := by
      by_cases h : full (src e) <;> simp [mark,h]
    simpa only [List.map_map,Function.comp_def,eq] using tight
  have nd := List.Nodup.of_map _ dec
  have len : s.length=6 := by
    cases r with
    | nil => simp at lo
    | cons e h _ => rw [←h]; simp [src,width e List.mem_cons_self]
  have mem := memStarts s
  rw [len] at mem
  exact sound s s [] [] 12 es (List.all_eq_true.mp table s mem) r width
    (by simpa using nd) hi (by simpa using lo)

theorem tight_cycle (d : Block) {s : Block} {es : List Block}
    (r : Route src dst s es s) (width : ∀e∈es,e.length=7)
    (lo : 2≤es.length) (hi : es.length≤11)
    (tight : (es.map (fun e => if full (src e) then tag (src e) else d)).Nodup) :
    full s ∧ es=GlobalWheelRank.wheel s := tight_cycle_twelve d r width lo (by omega) tight

#print axioms tight_cycle_twelve
#print axioms tight_cycle
end ExactWordFlow.ShortFreshCycle

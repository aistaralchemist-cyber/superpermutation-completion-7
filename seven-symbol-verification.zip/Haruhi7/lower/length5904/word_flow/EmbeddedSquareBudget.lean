import EmbeddedContactRows
import WheelSquareBudget
import WheelNormalization

namespace ExactWordFlow.EmbeddedWheels
open SevenWordWindows ResidualRoutes ResidualIncidence WheelSquareBudget
open scoped Classical

/-- The wheels form a submultiset of all extra edges. They may be embedded
in one long route, meet at arbitrary states, or occur more than once. -/
theorem embedded_face_loss {Y : Multiset Block} {s t : Block}
    (ws : List Block) (canonical : ∀w∈ws, w∈WheelContacts.bases)
    (h : Feasible (Y+turns ws) s t) (F : Finset Block)
    (part : F⊆doubles ws.toFinset) (proper : F.card<2520) :
    719+F.card+5*(ws.length-ws.toFinset.card) ≤ 5*ws.length+separateRank Y s := by
  classical
  let g : Block → (Component Y ⊕ Block) := Sum.inr
  have inject : Set.InjOn g (ws.toFinset : Set Block) := fun _ _ _ _ eq => Sum.inr.inj eq
  have used (w) (hw : w∈ws.toFinset) :
      g w∈boardIds Y s ws ∧ WheelContacts.wheel w⊆boardRow Y s (g w) := by
    refine ⟨?_,Finset.Subset.refl _⟩
    simpa [g,boardIds] using hw
  have bound := indexed_square_loss _ _ (board_connected ws canonical h)
    ws.toFinset g inject used F part proper
  rw [board_weight_distinct ws canonical] at bound
  have n := List.toFinset_card_le ws
  omega

/-- A repeated wheel and a double contact incur different costs. Every
geometric double contact counts, including pairs that share one wheel. -/
theorem embedded_square_budget {Y : Multiset Block} {s t : Block}
    (ws : List Block) (canonical : ∀w∈ws, w∈WheelContacts.bases)
    (h : Feasible (Y+turns ws) s t) (budget : (Y+turns ws).card≤858) :
    ws.length+10*((doubles ws.toFinset).card+5*(ws.length-ws.toFinset.card)+
      (largeOther Y s).card) ≤ 112 := by
  classical
  have fulls (w) (hw : w∈ws) : ResidualDensity.full w := by
    have table : ∀ z∈WheelContacts.bases, ResidualDensity.full z := by native_decide
    exact table w (canonical w hw)
  have few : (doubles ws.toFinset).card<12 := by
    by_contra! many
    obtain ⟨F,sub,sz⟩ := Finset.exists_subset_card_eq many
    have bound := (turns_with_loss ws fulls h budget _ (by
      simpa [Nat.add_assoc] using embedded_face_loss ws canonical h F sub (by omega))).2
    omega
  exact (turns_with_loss ws fulls h budget _ (by
    simpa [Nat.add_assoc] using embedded_face_loss ws canonical h _ (Finset.Subset.refl _) (by omega))).2

/-- No canonical initial rotation has to be assumed for the input list. -/
theorem all_wheel_presentations {Y : Multiset Block} {s t : Block}
    (ws : List Block) (legit : ∀w∈ws, ResidualDensity.full w)
    (h : Feasible (Y+turns ws) s t) (budget : (Y+turns ws).card≤858) :
    let W := (ws.map normalized).toFinset
    ws.length+10*((doubles W).card+5*(ws.length-W.card)+(largeOther Y s).card) ≤ 112 := by
  obtain ⟨legal,equal⟩ := normalized_family ws legit
  have result := embedded_square_budget (ws.map normalized) legal (equal ▸ h) (equal ▸ budget)
  simpa using result

/-- With 66 marked complete turns, no wheel repeats, and disjointness
of the pairs is not required for the four-double-contact cap. -/
theorem sixty_six_turns {Y : Multiset Block} {s t : Block}
    (ws : List Block) (legit : ∀w∈ws, ResidualDensity.full w) (size : ws.length=66)
    (h : Feasible (Y+turns ws) s t) (budget : (Y+turns ws).card≤858) :
    let W := (ws.map normalized).toFinset
    W.card=66 ∧ (doubles W).card+(largeOther Y s).card≤4 := by
  let W := (ws.map normalized).toFinset
  have count : W.card≤ws.length := by simpa [W] using List.toFinset_card_le (ws.map normalized)
  have lim := all_wheel_presentations ws legit h budget
  change ws.length+10*((doubles W).card+5*(ws.length-W.card)+(largeOther Y s).card)≤112 at lim
  change W.card=66 ∧ (doubles W).card+(largeOther Y s).card≤4
  constructor <;> omega

#print axioms sixty_six_turns
#print axioms all_wheel_presentations
#print axioms embedded_square_budget
end ExactWordFlow.EmbeddedWheels

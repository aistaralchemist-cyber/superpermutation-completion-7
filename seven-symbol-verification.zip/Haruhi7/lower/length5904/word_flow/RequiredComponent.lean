import ResidualRoutes

/-! The mandatory permutations may all lie in one weak component even while
surplus-only components remain detached. Keeping just the mandatory component
constructs an actual superpermutation within the same surplus budget. -/
namespace ExactWordFlow.RequiredComponent
open SevenWordWindows SuperpermutationBounds DirectedEuler ResidualRoutes

def RequiredTogether (X : Multiset Block) : Prop :=
  ∀ e∈required, ∀ f∈required, label (required+X) (src e) = label (required+X) (src f)

theorem feasible_together {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    RequiredTogether X := by
  let S : Set Block := {v | label (required+X) v = label (required+X) s}
  have every := h.reachable S rfl (fun e he hsrc => (on_edge he).symm.trans hsrc)
  intro e he f hf
  exact (every e (Multiset.mem_add.mpr (Or.inl he))).trans
    (every f (Multiset.mem_add.mpr (Or.inl hf))).symm

private theorem start_six {s t : Block} {es : List Block} (r : Route src dst s es t)
    (hne : es≠[]) (width : ∀e∈es, e.length=7) : s.length=6 := by
  cases r with
  | nil => exact (hne rfl).elim
  | cons e hs _ => simp [←hs, src, width e (List.mem_cons_self ..)]

theorem feasible_submultiset {X : Multiset Block} {s t : Block}
    (width : ∀ e∈X, e.length=7) (bal : X.map src+{t}=X.map dst+{s})
    (connected : RequiredTogether X) : ∃ Y ≤ X, ∃ a b, Feasible Y a b := by
  classical
  let p : Block := List.finRange 7
  have hp : p∈required := (mem_reps p).mpr ⟨List.length_finRange,List.nodup_finRange _⟩
  let q := label (required+X) (src p)
  let Y := X.filter fun e => label (required+X) (src e)=q
  have rb : required.map src=required.map dst := balanced_representatives
  have whole : (required+X).map src+{t}=(required+X).map dst+{s} := by
    rw [Multiset.map_add,Multiset.map_add,rb,add_assoc,add_assoc,bal]
  obtain ⟨a,b,es,bagEq,route,_,_⟩ := component_route whole (src p)
  have filterReq : required.filter (fun e => label (required+X) (src e)=q) = required :=
    Multiset.filter_eq_self.mpr (fun e he => connected e he p hp)
  have keepEq : part (required+X) q = required+Y := by
    simp only [part,Multiset.filter_add,filterReq,Y]
  change (↑es : Multiset Block)=part (required+X) q at bagEq
  rw [keepEq] at bagEq
  have mem (e : Block) : e∈es ↔ e∈required+Y := by
    change e∈(↑es : Multiset Block) ↔ _
    rw [bagEq]
  have yWidth : ∀ e∈Y, e.length=7 := fun e he => width e (Multiset.mem_filter.mp he).1
  have nonempty : es≠[] := fun eq => by
    have h := (mem p).mpr (Multiset.mem_add.mpr (Or.inl hp))
    simp [eq] at h
  refine ⟨Y,Multiset.filter_le _ _,a,b,?_,yWidth,?_,?_⟩
  · apply start_six route nonempty
    intro e he
    rcases Multiset.mem_add.mp ((mem e).mp he) with req | more
    · exact ((mem_reps e).mp (show e∈representatives from req)).1
    · exact yWidth e more
  · have h := route.balance
    rw [bagEq,Multiset.map_add,Multiset.map_add,rb,add_assoc,add_assoc] at h
    exact add_left_cancel h
  · intro S ha closed e he
    exact (route.closed S ha (fun f hf => closed f ((mem f).mp hf))).2 e ((mem e).mpr he)

theorem word_from_together {X : Multiset Block} {s t : Block} (size : X.card ≤ 858)
    (width : ∀ e∈X, e.length=7) (bal : X.map src+{t}=X.map dst+{s})
    (connected : RequiredTogether X) : ∃ w : Word, Covers w ∧ w.length≤5904 := by
  obtain ⟨Y,hY,a,b,h⟩ := feasible_submultiset width bal connected
  have small := Multiset.card_le_card hY
  obtain ⟨w,hw,hl⟩ := (word_iff_flow (Y.card+5046) (by omega)).mpr ⟨Y,a,b,by omega,h⟩
  exact ⟨w,hw,by omega⟩

private theorem pad {w : Word} (hw : Covers w) (hl : w.length≤5904) :
    ∃ v : Word, Covers v ∧ v.length=5904 := by
  let tail : Word := List.replicate (5904-w.length) 0
  refine ⟨w++tail,?_,by simp [tail]; omega⟩
  intro p pl pn
  obtain ⟨l,r,eq⟩ := hw p pl pn
  exact ⟨l,r++tail,by simp [eq,List.append_assoc]⟩

theorem exact_5904_iff_weak : (∃ w : Word, Covers w ∧ w.length=5904) ↔
    ∃ (X : Multiset Block) (s t : Block), X.card=858 ∧ (∀ e∈X, e.length=7) ∧
      X.map src+{t}=X.map dst+{s} ∧ RequiredTogether X := by
  constructor
  · intro hw
    obtain ⟨X,s,t,n,h⟩ := exact_5904.mp hw
    exact ⟨X,s,t,n,h.edges_seven,h.balance,feasible_together h⟩
  · rintro ⟨X,s,t,n,width,bal,conn⟩
    obtain ⟨w,hw,hl⟩ := word_from_together (by omega) width bal conn
    exact pad hw hl

theorem no_5904_iff_forced_split : (¬∃ w : Word, Covers w ∧ w.length=5904) ↔
    ∀ (X : Multiset Block) (s t : Block), X.card=858 → (∀ e∈X, e.length=7) →
      X.map src+{t}=X.map dst+{s} →
      ∃ e∈required, ∃ f∈required, label (required+X) (src e) ≠ label (required+X) (src f) := by
  classical
  rw [exact_5904_iff_weak]
  simp only [RequiredTogether,not_exists,not_and,not_forall, exists_prop]

end ExactWordFlow.RequiredComponent
#print axioms ExactWordFlow.RequiredComponent.no_5904_iff_forced_split

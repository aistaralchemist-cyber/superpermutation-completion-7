import PathTurnsGap
import GroupSplitTurns
import SplitWheelPrice

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence ResidualRoutes RotationCore
open EmbeddedWheels WeightedMarks
open private sizes from EmbeddedWheels

/-- The price of a route with whole six-wheels holds irrespective of whether
the wheels physically intersect the route or one another. -/
theorem route_turns_le_94 {s t : Block} {es ws : List Block}
    (h : Feasible ((↑es : Multiset Block)+turns ws) s t)
    (r : Route src dst s es t) (fw : ∀w∈ws,full w) (budget : es.length+6*ws.length≤858) :
    ws.length≤94 := by
  have wd (e) (he : e∈es) : e.length=7 :=h.edges_seven e (Multiset.mem_add.mpr (Or.inl he))
  have rk:=EmbeddedWheels.residual_rank ws fw h
  change 719≤5*ws.length+separateRank (↑es) s at rk
  rw [OnePath66.path_rank_eq r s] at rk
  have hi : ws.length≤100:=by
    by_contra! more
    have cap:=WeightedMarks.short_gain r wd (by omega)
    omega
  by_contra! low
  by_cases first : ws.length=95
  · exact PathTurnsGap.no_single_path_95 h r fw budget first
  exact PathTurnsGap.no_single_path h r fw budget (by omega) hi

/-- Any multiset of complete six-wheels removed from any feasible 858-edge
flow has at most 94 members, with multiplicities. -/
theorem arbitrary_turns_le_94 {Y : Multiset Block} {ws : List Block} {s t : Block}
    (fw : ∀w∈ws,full w) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) : ws.length≤94 := by
  by_contra! many
  obtain ⟨es,extra,r,fullE,split⟩:=GroupSplitTurns.group h fw (high_small_components fw h budget many)
  have fullAll (v) (hv : v∈extra++ws) :=(List.mem_append.mp hv).elim (fullE v) (fw v)
  have cost : es.length+6*(extra++ws).length≤858 :=by
    rw [split,Multiset.card_add,(sizes fullAll).1] at budget
    exact budget
  have cap:=route_turns_le_94 (split ▸ h) r fullAll cost
  simp only [List.length_append] at cap
  omega

open LiteralWheelCover
theorem equality_94 {b : Block} {k : Nat} (done : (complete b).card=92)
    (budget : b.length+6*k=1508) (fit : condition b k) :
    k≤94 ∧ 944≤b.length := by
  obtain ⟨rs,v,ins,small,vis⟩:=(budget_iff b k).mpr fit
  have len:=ins.length_eq
  have c : (complete v).card=92:=ins.complete_eq ▸ done
  have sharp:=(Boundary1508Floor.only_boundary (w:=v) (by omega) vis c.ge).2
  obtain ⟨Y,ws,s,t,count,fw,flow,total⟩:=sharp_residual ins vis done (by omega)
  have cap:=arbitrary_turns_le_94 fw flow total.le
  omega

#print axioms equality_94
#print axioms arbitrary_turns_le_94
end ExactWordFlow.WheelBaseResidual

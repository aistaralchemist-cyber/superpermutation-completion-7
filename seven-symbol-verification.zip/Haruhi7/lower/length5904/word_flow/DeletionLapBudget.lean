import LapBudget
import CoreControls

namespace ExactWordFlow.DeletionLapBudget
open SevenWordWindows RotationCore RotationCoreControls

/-- The suffix information needed when reading one new letter from the left. -/
abbrev State := Block × Nat

def state (w : Block) : State := (w.take 6,(good w).length)

private def push (a : Fin 7) (s : State) : State :=
  ((a::s.1).take 6,s.2 + if s.1.length=6 ∧ (a::s.1).Nodup then 1 else 0)

private theorem push_eq (a : Fin 7) (w : Block) : push a (state w)=state (a::w) := by
  apply Prod.ext
  · simp [push,state,List.take_take]
  · by_cases wide : 6≤w.length
    · simp [push,state,good,windows,wide,List.filter_cons]
      split <;> simp_all [Nat.add_comm]
    · have short : (windows w).length=0 := by rw [windows_length]; omega
      have empty:=List.length_eq_zero_iff.mp short
      have lt : min 6 w.length≠6 := by omega
      simp [push,state,good,windows,wide,empty,lt]

/-- States of the unedited suffix and all suffixes with one letter erased.
Sharing equal states only affects the size of the computation. -/
private def edits : Block → State × List State
  | [] => (state [],[])
  | a::xs =>
    let (old,options):=edits xs
    (push a old,(old::options.map (push a)).eraseDups)

private theorem edits_spec (w : Block) : (edits w).1=state w ∧
    ∀ i, i<w.length → state (w.eraseIdx i)∈(edits w).2 := by
  induction w with
  | nil => simp [edits]
  | cons a xs ih =>
    constructor
    · simpa [edits,ih.1] using push_eq a xs
    · intro i hi
      cases i with
      | zero => simp [edits,ih.1]
      | succ j =>
        have old:=ih.2 j (by simpa using hi)
        have next:=List.mem_map_of_mem (f:=push a) old
        simp only [push_eq] at next
        simpa [edits,List.eraseIdx_cons_succ] using
          (List.mem_cons_of_mem (edits xs).1 next)

/-- All 5,905 one-letter deletions are represented by the same count recurrence. -/
private theorem reference_check :
    ((edits source).2.all (fun s=>decide (s.2≤5039)))=true := by native_decide

private theorem checked_bound {w : Block} {cap : Nat}
    (ok : (edits w).2.all (fun s=>decide (s.2≤cap))=true) (i : Nat) (hi : i<w.length) :
    (good (w.eraseIdx i)).length≤cap := by
  have h := of_decide_eq_true (List.all_eq_true.mp ok (state (w.eraseIdx i)) ((edits_spec w).2 i hi))
  exact h

theorem erase_one (i : Nat) (hi : i<source.length) : (good (source.eraseIdx i)).length≤5039 :=
  checked_bound (w:=source) (cap:=5039) reference_check i hi

private theorem turn_good {p : Block} (h : p∈representatives) :
    ((RotationRun.turn p).filter (fun e=>decide e.Nodup)).length=7 := by
  have perm:=RotationRun.turn_fibre h
  have keep : (RotationRun.turn p).filter (fun e=>decide e.Nodup)=RotationRun.turn p := by
    apply List.filter_eq_self.mpr
    intro e he
    have inF : e∈fibre (classKey p) := by
      change e∈(fibre (classKey p)).val
      rw [←perm]
      exact he
    exact decide_eq_true ((mem_reps _).mp (List.mem_toFinset.mp (Finset.mem_filter.mp inF).1)).2
  rw [keep]
  simp [RotationRun.turn]

private theorem all_turns (ps : List Block) (legal : ∀p∈ps,p∈representatives) :
    ((ps.flatMap RotationRun.turn).filter (fun e=>decide e.Nodup)).length=7*ps.length := by
  induction ps with
  | nil => simp
  | cons p ps ih =>
    have a:=turn_good (legal p List.mem_cons_self)
    have b:=ih (fun q h=>legal q (List.mem_cons_of_mem _ h))
    simp only [List.flatMap_cons,List.filter_append,List.length_append,List.length_cons,a,b]
    omega

/-- Any ordering of the residual windows is admitted, including traversals
which do not come from consecutive deletions in the source word. -/
theorem contraction_budget {v w : Block} (ps : List Block)
    (legal : ∀p∈ps,p∈representatives)
    (sub : (↑(windows v) : Multiset Block)+↑(ps.flatMap RotationRun.turn)≤↑(windows w)) :
    7*(complete v).card+7*ps.length≤(good w).length := by
  have clean:=Multiset.card_le_card (Multiset.filter_le_filter (p:=fun e : Block=>e.Nodup) sub)
  have turns:=all_turns ps legal
  have done:=LapSkeleton.completed_floor v
  simp only [Multiset.filter_add,Multiset.filter_coe,Multiset.card_add,Multiset.coe_card] at clean
  change (good v).length+((ps.flatMap RotationRun.turn).filter (fun e=>decide e.Nodup)).length≤
    (good w).length at clean
  omega

theorem all_record_deletions {v : Block} (i : Nat) (hi : i<source.length)
    (ps : List Block) (legal : ∀p∈ps,p∈representatives) (n : ps.length=628)
    (sub : (↑(windows v) : Multiset Block)+↑(ps.flatMap RotationRun.turn)≤↑(windows (source.eraseIdx i))) :
    (complete v).card≤91 := by
  have budget:=contraction_budget ps legal sub
  have cap:=erase_one i hi
  omega

#print axioms erase_one
#print axioms all_record_deletions
end ExactWordFlow.DeletionLapBudget

import RouteDensity

namespace ResidualDensity

def rowTags (s : Six) (n : Nat) := (List.range n).map fun i => tag (s.rotate i)

/-- A finite search over the two letters in each one-hole seam.
Within a marked row, every letter is already forced by `next_unique`. -/
def rowSearch : List Nat → Six → List Six → Bool
  | [], _, _ => true
  | n::ns,s,seen =>
    let hits := rowTags s n
    full s && hits.all (fun z => decide (z∉seen)) &&
      (ns.isEmpty || (List.finRange 7).any fun a => (List.finRange 7).any fun b =>
        rowSearch ns (step (step (s.rotate (n-1)) a) b) (hits++seen))

def rowsMarked (p : ℕ → Prop) (i : ℕ) : List Nat → Prop
  | [] => True
  | n::ns => (∀ j<n, p (i+j)) ∧ rowsMarked p (i+n+1) ns

private theorem row_rigid {u : ℕ → Six} {p : ℕ → Prop} (w : Walk u) (h : Marked u p)
    (i n : ℕ) (hp : ∀j≤n,p (i+j)) : u (i+n)=(u i).rotate n := by
  induction n with
  | zero => simp
  | succ n ih =>
    obtain ⟨a,ha⟩ := w (i+n)
    have diff : tag (u (i+n)) ≠ tag (u (i+n+1)) := by
      intro e
      have := h.2 _ _ (hp n (by omega)) (hp (n+1) (by omega)) e
      omega
    have hx := next_unique _ a (h.1 _ (hp n (by omega)))
      (ha ▸ h.1 _ (hp (n+1) (by omega))) (ha ▸ diff)
    rw [Nat.add_succ,ha,hx,ih (fun j hj => hp j (by omega)),List.rotate_rotate]

private theorem search_complete {u : ℕ → Six} {p : ℕ → Prop} (w : Walk u) (h : Marked u p)
    (ns : List Nat) (nz : ∀n∈ns, 0<n) (i : ℕ) (hm : rowsMarked p i ns)
    (seen : List Six) (earlier : ∀z∈seen,∃ k < i, p k ∧ tag (u k)=z) :
    rowSearch ns (u i) seen=true := by
  induction ns generalizing i seen with
  | nil => rfl
  | cons n ns ih =>
    obtain ⟨now,later⟩ := hm
    have current := nz n List.mem_cons_self
    have fl : full (u i) := h.1 i (by simpa using now 0 current)
    have real (z : Six) (hz : z∈rowTags (u i) n) : ∃ j<n, tag (u (i+j))=z := by
      obtain ⟨j,hj,eq⟩ := List.mem_map.mp hz
      have lt := List.mem_range.mp hj
      exact ⟨j,lt,by rw [row_rigid w h i j (fun d hd => now d (by omega)),eq]⟩
    have dis : (rowTags (u i) n).all (fun z => decide (z∉seen)) = true := by
      apply List.all_eq_true.mpr
      intro z hz
      apply decide_eq_true
      intro hs
      obtain ⟨j,hj,eq⟩ := real z hz
      obtain ⟨k,hk,pk,ek⟩ := earlier z hs
      have := h.2 _ _ (now _ hj) pk (eq.trans ek.symm)
      omega
    rw [rowSearch]
    simp only [decide_eq_true fl,dis,Bool.true_and,Bool.or_eq_true]
    rcases ns with _|⟨l,ls⟩
    · exact Or.inl rfl
    · right
      obtain ⟨a,ha⟩ := w (i+(n-1))
      obtain ⟨b,hb⟩ := w (i+n)
      have last := row_rigid w h i (n-1) (fun j hj => now j (by omega))
      have eq : u (i+n+1)=step (step ((u i).rotate (n-1)) a) b := by
        rw [←last,←ha,show i+(n-1)+1=i+n by omega,←hb]
      apply List.any_eq_true.mpr; refine ⟨a,List.mem_finRange _,?_⟩
      apply List.any_eq_true.mpr; refine ⟨b,List.mem_finRange _,?_⟩
      rw [←eq]
      apply ih (fun d hd => nz d (List.mem_cons_of_mem _ hd)) _ later
      intro z hz
      rcases List.mem_append.mp hz with hit|hit
      · obtain ⟨j,hj,eq⟩ := real z hit
        exact ⟨i+j,by omega,now j hj,eq⟩
      · obtain ⟨j,hj,pp,eq⟩ := earlier z hit
        exact ⟨j,by omega,pp,eq⟩

def widths40 : List (List Nat) :=
  (List.range 6).map fun j => List.replicate j 6 ++ [5] ++ List.replicate (5-j) 6

/-- Six marked rows of lengths 6,6,6,6,6,5 in any order are impossible.
The only branching concerns two-letter seams, never word endpoints. -/
theorem no40profile {u : ℕ → Six} {p : ℕ → Prop} (w : Walk u) (h : Marked u p)
    (i : ℕ) (ns : List Nat) (hn : ns∈widths40) : ¬rowsMarked p i ns := by
  intro hp
  have cert : widths40.all (fun ns => states.all (fun s => !rowSearch ns s []))=true := by
    native_decide
  have pos : ∀l∈ns, 0<l := by
    have ck : widths40.all (fun ns => ns.all (fun l => decide (0<l)))=true := by decide +kernel
    intro l hl
    exact of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp ck ns hn) l hl)
  have fulli : full (u i) := by
    rcases ns with _|⟨n,tail⟩
    · exfalso
      have no : []∉widths40 := by decide
      exact no hn
    · apply h.1
      simpa using hp.1 0 (pos _ List.mem_cons_self)
  have no := List.all_eq_true.mp (List.all_eq_true.mp cert ns hn) _ (mem_states fulli)
  have yes := search_complete w h ns pos i hp [] (by simp)
  simp [yes] at no

end ResidualDensity
#print axioms ResidualDensity.no40profile

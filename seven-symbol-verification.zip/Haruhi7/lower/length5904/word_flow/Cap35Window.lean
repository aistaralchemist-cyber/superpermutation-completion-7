import SaturatedCyclicWindow

namespace ExactWordFlow.Cap35Window
open SevenWordWindows ResidualDensity ResidualRoutes ResidualIncidence RotationComponentCount DirectedEuler
open scoped Classical

/-- The 35-edge alternative has a closed spelling. In its actual Euler
route the marked rotation classes follow one repeated seven-position mask. -/
theorem actual {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {q : Component X} (away : q≠label X s) (size : (part X q).card=35)
    (colors : (contacts (support X s) (label X) q).card=30) :
    ∃v es, Route src dst v es v ∧ (↑es : Multiset Block)=part X q ∧ classCount v es=30 ∧
      ∃u : ℕ→Block,∃I : Finset ℕ, Walk u ∧ CyclicMarked u (fun i=>i%35∈I) 35 ∧
        (∀i,count (fun i=>i%35∈I) i 7=6) ∧ (∀i,(i+7)%35∈I ↔ i%35∈I) := by
  obtain ⟨v,_,key⟩:=residual_clean h away (by omega)
  obtain ⟨a,b,es,bag,route,lv,ends⟩:=component_route h.balance v
  rw [key] at bag lv ends
  obtain ⟨aa,bb⟩:=ends.2 away
  subst a; subst b
  have len : es.length=35 := (congrArg Multiset.card bag).trans size
  have width (z) (hz : z∈es):=h.edges_seven z (in_part.mp (bag ▸ (show z∈(↑es : Multiset Block) from hz))).1
  obtain ⟨u,I,walk,cyc,cnt⟩:=closed_observations route width (by omega)
  rw [len] at cyc cnt
  have low : (contacts (support X s) (label X) q).card≤classCount v es := contacts_bound _ lv route bag
  have cap:=cyclic_7 walk cyc (by decide : 7≤35)
  have yes : classCount v es=30 := by omega
  have pat:=SaturatedCyclicWindow.cycle35 walk cyc (cnt.trans yes)
  exact ⟨v,es,route,bag,yes,u,I,walk,cyc,pat⟩

#print axioms actual
end ExactWordFlow.Cap35Window

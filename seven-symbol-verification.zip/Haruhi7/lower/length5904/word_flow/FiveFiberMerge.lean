import SixProjection
import WheelContacts

namespace ExactWordFlow.FiveFiberMerge
open SevenWordWindows ResidualDensity SuperpermutationBounds WheelContacts
open private perm_mem perms6 from SixProjection

abbrev SixWord := List (Fin 6)
def foldLetter (x : Fin 7) : Fin 6 := ⟨min x.val 5, by omega⟩
def liftLetter (omitSix : Bool) (x : Fin 6) : Fin 7 :=
  if x.val=5 ∧ omitSix=false then 6 else ⟨x.val,by omega⟩
def omitted (omitSix : Bool) : Fin 7 := if omitSix then 6 else 5
def common (u : Block) := classKey (u.filter (fun a => decide (a.val<5)))
def group (d : Block) := allClasses.filter (fun c=>common c=d)
def fiveOrders := allClasses.image common
def basesFor (d : Block) (choice : Bool) :=
  bases.filter (fun s=>decide (omitted choice∉s ∧ common s=d))
def familyRows (d : Block) (choice : Bool) := (basesFor d choice).map wheel

private def readAfter (c : Block) (a : Fin 7) := (c.rotate (c.idxOf a+1)).take 6
private theorem read_data : ∀u∈states, ∀a∈List.finRange 7, a∉u → readAfter (tag u) a=u := by
  native_decide
private theorem lifting : ∀p∈perms6,∀v : Bool,
    let u:=p.map (liftLetter v)
    full u ∧ omitted v∉u ∧ tag u∈allClasses ∧
    common (tag u)=common (tag (p.map (liftLetter true))) ∧ u.map foldLetter=p := by
  native_decide

/-- Both disjoint wheel decompositions contain precisely the same 30 classes. -/
theorem wheel_trade : fiveOrders.card=24 ∧ ∀d∈fiveOrders, (group d).card=30 ∧
    ∀v : Bool,(familyRows d v).length=5 ∧ (familyRows d v).Pairwise Disjoint ∧
      (familyRows d v).toFinset.biUnion id = group d := by native_decide

def fromSide (w d : Block) (v : Bool) : Prop :=
  ∀c∈group d, ∃u : Block, u <:+: w ∧ full u ∧ omitted v∉u ∧ tag u=c

/-- Each of the 24 five-symbol circular orders may independently choose
its omitted symbol. The six-letter witnesses can overlap anywhere. -/
theorem merged_covers {w : Block} (all : ∀d∈fiveOrders,∃v : Bool,fromSide w d v) :
    Covers (w.map foldLetter) := by
  intro p lp distinct
  have hp:=perm_mem lp distinct
  let d:=common (tag (p.map (liftLetter true)))
  have board := (lifting p hp true).2.2.1
  have legal : d∈fiveOrders:=Finset.mem_image_of_mem _ board
  obtain ⟨v,side⟩:=all d legal
  let target:=p.map (liftLetter v)
  obtain ⟨ht,absent,legalTag,eq,projection⟩:=lifting p hp v
  have belongs : tag target∈group d:=Finset.mem_filter.mpr ⟨legalTag,eq⟩
  obtain ⟨u,⟨l,r,spell⟩,hu,miss,tagEq⟩:=side _ belongs
  have one:=read_data u (mem_states hu) (omitted v) (List.mem_finRange _) miss
  have two:=read_data target (mem_states ht) (omitted v) (List.mem_finRange _) absent
  have same : u=target:=one.symm.trans ((congrArg (fun c=>readAfter c (omitted v)) tagEq).trans two)
  refine ⟨l.map foldLetter,r.map foldLetter,?_⟩
  rw [←spell,List.map_append,List.map_append,same]
  exact congrArg (fun z=>l.map foldLetter++z++r.map foldLetter) projection

theorem length_floor {w : Block} (all : ∀d∈fiveOrders,∃v : Bool,fromSide w d v) :
    870≤w.length := by
  have h:=SuperpermLowerBounds.superperm_kisic_numerical_bounds.2.1.trans
    (SuperpermBridge.ssuper_le_length (merged_covers all))
  simpa using h

private theorem spell_wheel : ∀u∈states,∀v : Bool,omitted v∉u → ∀c∈wheel u,
    ∃i∈List.range 6, (u.rotate i) <:+: (u++u.take 5) ∧ full (u.rotate i) ∧
      omitted v∉u.rotate i ∧ tag (u.rotate i)=c := by native_decide

/-- A row is physically present if a phase and the next five rotations
are consecutive six-letter factors. -/
def literalRows (w d : Block) (v : Bool) : Prop :=
  ∀R∈familyRows d v,∃u∈states, omitted v∉u ∧ wheel u=R ∧ (u++u.take 5) <:+: w

theorem physical_floor {w : Block} (all : ∀d∈fiveOrders,∃v : Bool,literalRows w d v) :
    870≤w.length := by
  apply length_floor
  intro d hd
  obtain ⟨v,rows⟩:=all d hd
  refine ⟨v,?_⟩
  intro c hc
  have unionEq:=(wheel_trade.2 d hd).2 v |>.2.2
  rw [←unionEq] at hc
  obtain ⟨R,hr,hc⟩:=Finset.mem_biUnion.mp hc
  obtain ⟨u,hu,miss,eq,occ⟩:=rows R (List.mem_toFinset.mp hr)
  obtain ⟨i,_,hit,fullx,absent,tagged⟩:=spell_wheel u hu v miss c (eq.symm ▸ hc)
  exact ⟨u.rotate i,hit.trans occ,fullx,absent,tagged⟩

/-- Any proposed pair of letters may first be relabelled to 5,6. In each
short word there must be a five-letter circular order for which neither
omitted letter alone supplies all thirty target classes. -/
theorem incompatible_family {w : Block} (short : w.length<870)
    (e : Fin 7 ≃ Fin 7) : ∃d∈fiveOrders, ∀v : Bool, ¬fromSide (w.map e) d v := by
  classical
  by_contra! no
  have all (d) (hd : d∈fiveOrders) : ∃v : Bool, fromSide (w.map e) d v := no d hd
  have h := length_floor all
  simp only [List.length_map] at h
  omega

#print axioms incompatible_family
#print axioms merged_covers
#print axioms physical_floor
end ExactWordFlow.FiveFiberMerge

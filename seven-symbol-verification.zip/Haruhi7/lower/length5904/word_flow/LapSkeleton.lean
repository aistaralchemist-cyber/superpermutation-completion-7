import RotationCore

namespace ExactWordFlow.LapSkeleton
open SevenWordWindows SuperpermutationBounds RotationReinsert RotationCore
open DirectedEuler ResidualDensity

/-- Seven successive mandatory rotations, with an arbitrary phase. -/
def LapFree (w : Block) : Prop :=
  ¬∃ (l r : List Block) (p : Block), p∈representatives ∧ windows w=l++RotationRun.turn p++r

def score (w : Block) : ℕ := w.length+7*(720-(complete w).card)

private abbrev chain := Route src dst

private theorem join {s u t : Block} {a b : List Block} (p : chain s a u)
    (q : chain u b t) : chain s (a++b) t := by
  induction p with
  | nil => exact q
  | cons e h _ ih => exact .cons _ h (ih q)

private theorem split_at {s t : Block} (a b : List Block)
    (r : chain s (a++b) t) : ∃u, chain s a u ∧ chain u b t := by
  induction a generalizing s with
  | nil => exact ⟨s,.nil _,r⟩
  | cons e a ih =>
    cases r with
    | cons _ h rest =>
      obtain ⟨u,left,right⟩ := ih rest
      exact ⟨u,.cons _ h left,right⟩

private theorem end_eq {s t z : Block} {a : List Block} (p : chain s a t)
    (q : chain s a z) : t=z := by
  induction p with
  | nil => cases q; rfl
  | cons e h _ ih => cases q with | cons _ _ rest => exact ih rest

private theorem start_eq {s u t z : Block} {a : List Block} (ne : a≠[])
    (p : chain s a t) (q : chain u a z) : s=u := by
  cases p with
  | nil => contradiction
  | cons e h _ => cases q with | cons _ k _ => exact h.symm.trans k

private theorem end_seen {s t : Block} {a : List Block} (p : chain s a t) :
    t∈s::a.map dst := by
  induction p with
  | nil => simp
  | cons e h rest ih => simpa [List.mem_cons,or_assoc] using Or.inr ih

private theorem lap_table : ∀p∈representatives,
    full (src p) ∧ tag (src p)=classKey p ∧
    ∀q∈RotationRun.turn p, tag (dst q)=classKey p ∧ classKey q=classKey p := by native_decide

private theorem in_old {l middle r : List Block} {e : Block} (he : e∈l++r) :
    e∈l++middle++r := by simp only [List.mem_append] at *; tauto

/-- Removing a single literal lap preserves all visited classes, even if
the same class occurs at many other places in the word. -/
theorem cut_lap {w : Block} (long : 6≤w.length) {l r : List Block} {p : Block}
    (hp : p∈representatives) (word : windows w=l++RotationRun.turn p++r) :
    ∃v : Block, 6≤v.length ∧ v.length+7=w.length ∧ visited w⊆visited v ∧
      (complete w).card≤(complete v).card+1 := by
  classical
  let middle := RotationRun.turn p
  have seven : middle.length=7 := by simp [middle,RotationRun.turn]
  have route := read_route w long
  rw [word,List.append_assoc] at route
  obtain ⟨i,first,rest⟩ := split_at l _ route
  obtain ⟨j,through,last⟩ := split_at middle r rest
  have loop := RotationRun.turn_route hp
  have eq := start_eq (by intro h; simp [h] at seven) through loop
  subst i
  have eq := end_eq through loop
  subst j
  obtain ⟨v,sz,start,edges⟩ := spell_route (join first last) (by simp; omega)
    (fun e he => window_width w (word ▸ in_old he))
  have len := congrArg List.length word
  have szm : (RotationRun.turn p).length=7 := seven
  simp only [windows_length,List.length_append,szm] at len sz
  have geom := lap_table p hp
  have source : src p∈anchors v := by
    have seen := end_seen first
    simp only [anchors,start,edges,List.mem_cons,List.map_append,List.mem_append] at seen ⊢
    tauto
  refine ⟨v,by omega,by omega,?_,?_⟩
  · intro c hc
    obtain ⟨u,seen,fullu,key⟩ := (mem_visited w c).mp hc
    apply (mem_visited v c).mpr
    simp only [anchors,word,List.map_append,List.mem_cons,List.mem_append] at seen
    rcases seen with h|((h|h)|h)
    · exact ⟨u,List.mem_cons.mpr (Or.inl (h.trans start.symm)),fullu,key⟩
    · exact ⟨u,by simp [anchors,edges,h],fullu,key⟩
    · obtain ⟨e,he,rfl⟩ := List.mem_map.mp h
      exact ⟨src p,source,geom.1,geom.2.1.trans ((geom.2.2 e he).1.symm.trans key)⟩
    · exact ⟨u,by simp [anchors,edges,h],fullu,key⟩
  · have incl : complete w⊆insert (classKey p) (complete v) := by
      intro c hc
      by_cases same : c=classKey p
      · simp [same]
      apply Finset.mem_insert_of_mem
      obtain ⟨legal,old⟩ := (mem_complete w c).mp hc
      apply (mem_complete v c).mpr
      refine ⟨legal,?_⟩
      intro q hq cls
      have seen := old q hq cls
      simp only [word,List.mem_append] at seen
      rw [edges]
      rcases seen with (x|x)|x
      · exact List.mem_append_left _ x
      · exact (same (cls.symm.trans (geom.2.2 _ x).2)).elim
      · exact List.mem_append_right _ x
    exact (Finset.card_le_card incl).trans (Finset.card_insert_le _ _)

/-- Every all-class word admits a lap-free representative whose
completion score is at most the original score. -/
theorem reduce (w : Block) (long : 6≤w.length) (all : (visited w).card=720) :
    ∃v : Block, 6≤v.length ∧ (visited v).card=720 ∧ LapFree v ∧ score v ≤ score w := by
  classical
  by_cases free : LapFree w
  · exact ⟨w,long,all,free,le_rfl⟩
  · obtain ⟨l,r,p,hp,occ⟩ := Classical.not_not.mp free
    obtain ⟨v,wide,len,vis,done⟩ := cut_lap long hp occ
    have top := Finset.card_le_card (visited_subset v)
    rw [board] at top
    have bot := Finset.card_le_card vis
    have cv := Finset.card_le_card (complete_subset v)
    have cw := Finset.card_le_card (complete_subset w)
    have decr : v.length<w.length := by omega
    obtain ⟨z,ll,vv,ff,ss⟩ := reduce v wide (by omega)
    exact ⟨z,ll,vv,ff,ss.trans (by unfold score; omega)⟩
termination_by w.length

theorem exact_skeleton_minimum :
    IsLeast {n : ℕ | ∃v : Block, 6≤v.length ∧ (visited v).card=720 ∧ LapFree v ∧ score v=n}
      (SuperpermBridge.HR.Ssuper 7) := by
  have floor {v : Block} (long : 6≤v.length) (all : (visited v).card=720) :
      SuperpermBridge.HR.Ssuper 7 ≤ score v := by
    obtain ⟨w,hw,sz⟩ := expand_remaining long all
    exact (SuperpermBridge.ssuper_le_length hw).trans_eq sz
  constructor
  · obtain ⟨w,hw,size⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
    have inc : allClasses⊆complete w := by
      intro c hc
      apply (mem_complete _ _).mpr
      refine ⟨hc,?_⟩
      intro p hp _
      obtain ⟨width,nd⟩ := (mem_reps _).mp hp
      obtain ⟨left,right,form⟩ := hw p width nd
      exact form ▸ window_mem _ _ _ width
    have wa := Finset.card_le_card (inc.trans (complete_subset w))
    have wb := Finset.card_le_card (visited_subset w)
    have wc := Finset.card_le_card inc
    rw [board] at wa wb wc
    obtain ⟨l,r,form⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange 7)
    have long : 6≤w.length := by simp [form]; omega
    obtain ⟨v,wide,vis,free,cap⟩ := reduce w long (by omega)
    refine ⟨v,wide,vis,free,le_antisymm ?_ (floor wide vis)⟩
    unfold score at cap ⊢
    omega
  · rintro _ ⟨v,wide,vis,_,rfl⟩
    exact floor wide vis

#print axioms cut_lap
#print axioms exact_skeleton_minimum
end ExactWordFlow.LapSkeleton

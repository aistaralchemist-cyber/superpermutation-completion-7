import Normalization
namespace ExactWordFlow.CandidateRenaming
open SevenWordWindows RotationCore CompactWordCircuit

/-- The order in which distinct letters first occur. -/
def OrderedFirsts (w : Block) : Prop :=
  ∀ (pre : Block) (b : Fin 7) (tail : Block), w=pre++b::tail → b∉pre → ∀a<b, a∈pre

def score : Block → Nat
  | [] => 0
  | a::tl => a.val*7^tl.length + score tl

private theorem bound_score (w : Block) : score w < 7^w.length := by
  induction w with
  | nil => decide
  | cons a tl ih =>
    have bound : a.val≤6 := by omega
    have m:=Nat.mul_le_mul_right (7^tl.length) bound
    simp only [score,List.length_cons,Nat.pow_succ]
    omega

private theorem pre_mono (pre u v : Block) (len:u.length=v.length) (lt:score u<score v) :
    score (pre++u)<score (pre++v) := by
  induction pre with
  | nil => exact lt
  | cons x xs ih =>
    simp only [List.cons_append,score,List.length_append,len]
    omega

private theorem cheaper {a b : Fin 7} (lt : a<b) (pre tail : Block) (na:a∉pre) (nb:b∉pre) :
    score (rename a b (pre++b::tail)) < score (pre++b::tail) := by
  have fixed : rename a b pre=pre := by
    calc
      rename a b pre = pre.map id := by
        unfold rename
        apply List.map_congr_left
        intro x hx
        change Equiv.swap a b x = x
        apply Equiv.swap_apply_of_ne_of_ne
        · rintro rfl; exact na hx
        · rintro rfl; exact nb hx
      _ = pre := by simp
  change score ((pre++b::tail).map (Equiv.swap a b)) < _
  rw [List.map_append, List.map_cons, Equiv.swap_apply_right]
  change score (rename a b pre ++ a::rename a b tail) < _
  rw [fixed]
  apply pre_mono
  · simp [rename]
  · have h := bound_score (rename a b tail)
    have lower : a.val+1 ≤ b.val := lt
    have step:=Nat.mul_le_mul_right (7^tail.length) lower
    simp only [rename,List.length_map] at h
    simp only [score,rename,List.length_map,Nat.add_mul,Nat.one_mul] at step ⊢
    omega

def Candidate (w : Block) :=
  w.length=1501 ∧ (visited w).card=720 ∧ 91≤(complete w).card

private theorem renamed_candidate {w : Block} (cw : Candidate w) (a b : Fin 7) :
    Candidate (rename a b w) :=
  ⟨by simpa [rename] using cw.1, (swap_counts a b w).1.trans cw.2.1,
    cw.2.2.trans_eq (swap_counts a b w).2.symm⟩

/-- A counterexample exists only if a counterexample with canonical first
occurrences satisfies every raw DIMACS clause of the same strengthened instance. -/
theorem canonical_all_rows {w : Block} (cw : Candidate w) :
    ∃z : Block, Candidate z ∧ OrderedFirsts z ∧
      ∃ f v, admits (sourceTest (wordSource z f) v) 0 (goalTape true).body.toList ∧
        ∀r∈signedRows 0 (goalTape true).body.toList, r.any (wire v)=true := by
  classical
  let prop := fun n=>∃z,Candidate z ∧ score z=n
  have ex : ∃n, prop n := ⟨score w,w,cw,rfl⟩
  obtain ⟨z,zc,sz⟩ := Nat.find_spec ex
  refine ⟨z,zc,?_, counterexample_all_rows zc.1 zc.2.1 zc.2.2⟩
  intro pre b tail eq nb a lt
  by_contra na
  have low := cheaper lt pre tail na nb
  rw [←eq,sz] at low
  exact Nat.find_min ex low ⟨_,renamed_candidate zc a b,rfl⟩

#print axioms canonical_all_rows
end ExactWordFlow.CandidateRenaming

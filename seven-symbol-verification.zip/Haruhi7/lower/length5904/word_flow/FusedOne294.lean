import FusedRoots294
import NearRootMoves

namespace ExactWordFlow.FusedOne294
open SevenWordWindows ResidualDensity ResidualIncidence RotationComponentCount DirectedEuler
open WeightedMarks MarkedGeometry ExtremalRealizations NearRootMoves
open private canonical encode map_tag from Interval66
open private initial from MarkedDensity
open private dfs dfs_sound checkFrom accepted_start footprint mem_foot from FusedRoots294

def base : Six := (List.finRange 7).take 6
private def slide (w : Six) := w.map (·+1)
private def undo (c : Six) := classKey (c.map (·-1))

private def shiftCheck : Bool :=
  states.all (fun s=> tag (slide s) == move 7 (tag s) && undo (move 7 (tag s)) == tag s)

private theorem shiftData : shiftCheck=true := by native_decide

private theorem cycle_step (x : Six) (hx : full x) :
    tag (slide x)=move 7 (tag x) ∧ undo (move 7 (tag x))=tag x := by
  obtain ⟨a,b⟩:=Bool.and_eq_true_iff.mp (List.all_eq_true.mp shiftData _ (mem_states hx))
  exact ⟨eq_of_beq a,eq_of_beq b⟩

private def firstCheck : Bool := canonical.all (fun x=>(List.range 7).any fun n=>slide^[n] x == base)
private theorem firstData : firstCheck=true := by native_decide

private theorem choose_shift (x : Six) (canonicalX : x∈canonical) : ∃k : Nat,slide^[k] x=base := by
  obtain ⟨k,_,yes⟩:=List.any_eq_true.mp (List.all_eq_true.mp firstData _ canonicalX)
  exact ⟨k,eq_of_beq yes⟩

private theorem move_step (R : Finset Six) (k : Nat) :
    applyMoves (List.replicate (k+1) 7) R=(applyMoves (List.replicate k 7) R).image (move 7) := by
  rw [List.replicate_succ',applyMoves,List.foldl_append]
  rfl

private theorem shift_trace (k : Nat) (u : Nat→Six) (p : Nat→Prop) [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i n : Nat) :
    ∃v, Walk v ∧ Marked v p ∧ v i=slide^[k] (u i) ∧
      (selectedTags v i (mask p i n)).toFinset=
      applyMoves (List.replicate k 7) (selectedTags u i (mask p i n)).toFinset := by
  induction k with
  | zero => exact ⟨u,w,m,rfl,rfl⟩
  | succ k ih =>
    obtain ⟨v,vw,vm,first,tags⟩:=ih
    let t (j : Nat):=slide (v j)
    have tw : Walk t := by
      intro j
      obtain ⟨a,eq⟩:=vw j
      exact ⟨a+1,by simp [t,slide,eq,step,List.map_tail]⟩
    have tm : Marked t p := by
      constructor
      · intro j yes
        exact ⟨by simp [t,slide,(vm.1 _ yes).1],(vm.1 _ yes).2.map (add_left_injective _)⟩
      · intro j l hj hl eq
        have sj:=cycle_step _ (vm.1 _ hj)
        have sl:=cycle_step _ (vm.1 _ hl)
        exact vm.2 j l hj hl (sj.2.symm.trans ((congrArg undo (sj.1.symm.trans (eq.trans sl.1))).trans sl.2))
    refine ⟨t,tw,tm,?_,?_⟩
    · rw [Function.iterate_succ_apply',←first]
    · rw [move_step,←tags]
      ext c
      simp only [Finset.mem_image,List.mem_toFinset,mem_marked]
      constructor
      · rintro ⟨j,hj,hp,rfl⟩
        exact ⟨tag (v (i+j)),⟨j,hj,hp,rfl⟩,(cycle_step _ (vm.1 _ hp)).1.symm⟩
      · rintro ⟨z,⟨j,hj,hp,rfl⟩,rfl⟩
        exact ⟨j,hj,hp,(cycle_step _ (vm.1 _ hp)).1⟩

def check (accept : Finset Six→Bool) : Bool := checkFrom accept base
private theorem selected_accept (accept : Finset Six→Bool) (checks : check accept=true)
    {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : Nat) (many : 250≤count p i 295) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ∃k : Nat,accept (applyMoves (List.replicate k 7) ((selectedTags u i (mask p i 295)).toFinset.image (List.map f)))=true := by
  obtain ⟨first,read⟩:=accepted_start w m i many
  let f:=encode (u i)
  have ck : states.all (fun s=>decide (Function.Injective (encode s) ∧ encode s 0=0 ∧
    s.map (encode s)∈canonical))=true := by native_decide
  obtain ⟨inj,z,can⟩:=of_decide_eq_true (List.all_eq_true.mp ck _ (mem_states (m.1 i first)))
  let v (k : Nat):=(u k).map f
  have walk : Walk v := by
    intro j
    obtain ⟨a,eq⟩:=w j
    exact ⟨f a,by simp [v,eq,step,List.map_tail]⟩
  have markv : Marked v p := by
    refine ⟨fun j hj=>⟨by simp [v,(m.1 j hj).1],(m.1 j hj).2.map inj⟩,?_⟩
    intro j k hj hk eq
    apply m.2 j k hj hk
    change tag ((u j).map f)=tag ((u k).map f) at eq
    rw [map_tag f inj z _ (m.1 j hj),map_tag f inj z _ (m.1 k hk)] at eq
    exact List.map_injective_iff.mpr inj eq
  have imageEq : (selectedTags u i (mask p i 295)).toFinset.image (List.map f)=
      (selectedTags v i (mask p i 295)).toFinset := by
    ext c
    simp only [Finset.mem_image,List.mem_toFinset,mem_marked]
    constructor
    · rintro ⟨a,⟨j,hj,hp,rfl⟩,rfl⟩
      exact ⟨j,hj,hp,map_tag f inj z _ (m.1 _ hp)⟩
    · rintro ⟨j,hj,hp,rfl⟩
      exact ⟨tag (u (i+j)),⟨j,hj,hp,rfl⟩,(map_tag f inj z _ (m.1 _ hp)).symm⟩

  obtain ⟨k,hk⟩:=choose_shift _ can
  obtain ⟨t,tw,tm,hbase,tags⟩:=shift_trace k v p walk markv i 295
  have exactly : t i=base := hbase.trans hk
  have passed : dfs accept 294 initial (decide (p i)) (t i) {}=true := by
    simpa only [check,checkFrom,decide_eq_true first,exactly] using checks
  have cert:=dfs_sound accept tw tm 294 initial i {} (by simp) read passed
  have emptyFoot : footprint {}=∅ := by ext x; simp [mem_foot]
  rw [emptyFoot,Finset.union_empty,tags] at cert
  exact ⟨f,inj.bijective_of_finite,z,k,by rwa [imageEq]⟩

open private select from RouteDensity

/-- Literal reachability of a root footprint; the normalization is a single
alphabet bijection fixing zero, as required for transport of the wheel cover. -/
theorem route_coverage (accept : Finset Six→Bool) (checks : check accept=true)
    {a b : Six} {es : List Six} (r : Route src dst a es b) (width : ∀e∈es,e.length=7)
    (length : es.length+1=295) (many : 250≤classCount a es) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ∃k : Nat,accept (applyMoves (List.replicate k 7) ((touched (a::es.map dst)).image (List.map f)))=true := by
  classical
  obtain ⟨u,walk,_,_,eq⟩:=route_walk r width
  rw [length] at eq
  obtain ⟨I,marks,card⟩:=select u 295
  rw [eq] at card
  have sufficient : 250≤count (·∈I) 0 295 := by rw [card]; exact many
  obtain ⟨f,bij,z,contains⟩:=selected_accept accept checks walk marks 0 sufficient
  let J := (Finset.range 295).filter fun j=>j∈I
  have matchSet : (selectedTags u 0 (mask (·∈I) 0 295)).toFinset=J.image (tag ∘ u) := by
    ext c
    simp only [List.mem_toFinset,mem_marked,Nat.zero_add,Finset.mem_image,J,
      Finset.mem_filter,Finset.mem_range,Function.comp_apply]
    grind
  have subset : J.image (tag ∘ u)⊆touched (a::es.map dst) := by
    intro c hc
    obtain ⟨j,hj,rfl⟩:=Finset.mem_image.mp hc
    obtain ⟨hj,marked⟩:=Finset.mem_filter.mp hj
    change tag (u j)∈touched _
    rw [←eq]
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨u j,List.mem_filter.mpr
      ⟨List.mem_map.mpr ⟨j,Finset.mem_range.mp hj |> List.mem_range.mpr,rfl⟩,decide_eq_true (marks.1 _ marked)⟩,rfl⟩)
  have injective : Set.InjOn (tag ∘ u) J := by
    intro j hj k hk same
    exact marks.2 j k (Finset.mem_filter.mp hj).2 (Finset.mem_filter.mp hk).2 same
  have equal : J.image (tag ∘ u)=touched (a::es.map dst) := by
    apply Finset.eq_of_subset_of_card_le subset
    rw [Finset.card_image_of_injOn injective,←card]
    simp [J,count]
  exact ⟨f,bij,z,by rwa [matchSet,equal] at contains⟩


open RotationCore ExtremeWheelCut SuperpermutationBounds
open private partition wheel_list from HundredDecomposition
open private hits from NearHundredShape
open ResidualRoutes

theorem cover_certificate (accept : Finset Six→Bool) (checks : check accept=true)
    {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (card : (occupied X s).card=94) :
    ∃R, accept R=true ∧ ∃W⊆allRows, W.card≤94 ∧ SeedWheelCut.ClosedCover R allClasses W := by
  classical
  obtain ⟨_,root,colors,every⟩:=NoRoot265.shape h budget card
  obtain ⟨a,b,es,bag,r,eq,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len : es.length=(part X (label X s)).card:=congrArg Multiset.card bag
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have cover : hits X s (label X s)≤classCount s es:=contacts_bound _ eq r bag
  obtain ⟨ws,num,legal,_,packet⟩:=wheel_list (occupied X s) (fun q hq=>MarkedLargeCap.six_component h (Finset.mem_erase.mp hq).1 (every q hq))
  have split:=partition X s
  rw [←bag,←packet] at split
  have fullW (v) (hv : v∈ws) := (legal v hv).1
  have length : es.length+1=295 := by omega
  have count : 250≤classCount s es := by omega
  obtain ⟨f,bij,zero,k,norm⟩:=route_coverage accept checks r wd length count
  have closed:=WheelRelabel.transport_closed fullW (HundredDecomposition.closed_cover h r fullW split) f bij.1 zero
  let vs:=ws.map (List.map f)
  have legal : vs.toFinset.image WheelContacts.wheel⊆allRows := by
    intro row hr
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hr
    obtain ⟨x,old,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hv)
    have fullX:=fullW x old
    have fullV : full (x.map f) := ⟨by simpa using fullX.1,fullX.2.map bij.1⟩
    obtain ⟨base,admissible,rows⟩:=WheelContacts.complete fullV
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨base,admissible,rows⟩)
  obtain ⟨Z,good,ct,sealed⟩:=transport legal closed (List.replicate k 7)
  exact ⟨_,norm,_,good,ct.trans (Finset.card_image_le.trans ((List.toFinset_card_le vs).trans
    (by simpa [vs] using (num.trans card).le))),sealed⟩

#print axioms cover_certificate
end ExactWordFlow.FusedOne294

import CompactLimits
import CompactLayoutCheck
import FrontRawBudget

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows RotationCore FrontRawBudget

abbrev PhaseFacts (T : Test) := ∀p∈layout.pieces, admits T p.base p.log.toList

theorem input_admits {T : Test} (parts : PhaseFacts T) :
    admits T 0 layout.cols.log.toList := by
  have h := parts _ (List.get_mem layout.pieces ⟨0,by decide⟩)
  exact h

section
attribute [local irreducible] stage

theorem front_stage : layout.front = stage layout.cols.top (frontPhase layout.cols.out) := rfl

private theorem head_stage : layout.heads = stage layout.front.top
    (startPhase layout.front.out.2.1 layout.front.out.2.2) := rfl
private theorem start_cap : layout.startsLimit=stage layout.heads.top (capped layout.heads.out 720) := rfl
private theorem win_cap : layout.winsLimit=stage layout.startsLimit.top (capped layout.front.out.2.2 637) := rfl
private theorem clean_cap : layout.cleanLimit=stage layout.winsLimit.top (capped layout.front.out.2.1 1357) := rfl

end

theorem apply_phase {s : Stage α} {i : Nat} {m : M α} {T : Test} {P : α → Prop}
    (eq : s=stage i m) (ad : admits T s.base s.log.toList) (meaning : Gives T m P) :
    P s.out := by
  subst s
  exact stage_gives meaning ad

attribute [local irreducible] layout

theorem front_caps {w : Block} {T : Test} {v : Nat → Bool}
    (law : ModelsGates T v) (unit : v 0=true) (parts : PhaseFacts T)
    (len : w.length=1501) (hit : (visited w).card=720) (many : 91≤(complete w).card)
    (clean : SignalList v layout.front.out.2.1.toList (cleanSignals w))
    (wins : SignalList v layout.front.out.2.2.toList (winSignals w)) :
    wire v layout.startsLimit.out=true ∧ wire v layout.winsLimit.out=true ∧
      wire v layout.cleanLimit.out=true := by
  obtain ⟨boundS,boundW,boundC⟩ := raw_budget len hit many
  have dims : (cleanSignals w).length=(winSignals w).length+1 := by
    simp [cleanSignals,winSignals]
  have heads : SignalList v layout.heads.out.toList (startSignals w) :=
    apply_phase head_stage (parts _ (by
        iterate 2 apply List.mem_cons_of_mem
        exact List.mem_cons_self))
      (P:=fun out=> SignalList v out.toList (startVals (cleanSignals w) (winSignals w)))
      (starts_gives law unit clean wins dims)
  exact ⟨(apply_phase start_cap (parts _ (by
        iterate 3 apply List.mem_cons_of_mem
        exact List.mem_cons_self))
       (cap_gives law unit heads boundS)).2,
    (apply_phase win_cap (parts _ (by
        iterate 4 apply List.mem_cons_of_mem
        exact List.mem_cons_self))
       (cap_gives law unit wins boundW)).2,
    (apply_phase clean_cap (parts _ (by
        iterate 5 apply List.mem_cons_of_mem
        exact List.mem_cons_self))
       (cap_gives law unit clean boundC)).2⟩

theorem layout_claims {v : Nat → Bool}
    (input : ∀r∈assertionsOf layout.cols.out,r.any (wire v)=true)
    (front : wire v layout.startsLimit.out=true ∧ wire v layout.winsLimit.out=true ∧
       wire v layout.cleanLimit.out=true)
    (sorted : ∀p∈layout.adj.out, wire v p.1=true)
    (visit : wire v layout.visitLimit.out=true) (doneF : wire v layout.doneLimit.out=true) :
    ∀r∈claims (goalTape true).body.toList, r.any (wire v)=true := by
  rw [checked_layout.2.2]
  intro r hr
  simp only [Layout.clauses,List.mem_append,List.mem_cons,List.not_mem_nil,or_false,
    List.mem_map] at hr
  rcases hr with (((h|h)|h)|h)
  · exact input r h
  · rcases h with rfl|rfl|rfl <;> simp only [List.any_cons,List.any_nil,Bool.or_false,front.1,front.2.1,front.2.2]
  · obtain ⟨p,hp,rfl⟩ := h
    simp [sorted p hp]
  · rcases h with rfl|rfl <;> simp [visit,doneF]

end ExactWordFlow.CompactWordCircuit

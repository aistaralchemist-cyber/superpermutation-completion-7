import Cap35ActualShape
import WheelRelabel

namespace ExactWordFlow.Cap35Fibers
open SevenWordWindows ResidualDensity WheelContacts Cap35Rigidity
open private canonical encode from Interval66
open private shape_map from Cap35Census

/-- Restrict a circular order to the indicated letters. -/
def restrict (keep c : Six) : Six := c.filter (fun a=>a∈keep)
def fiber (s : Six) : Finset Six :=
  allClasses.filter (fun c=> (List.range 5).any (fun i=>restrict (s.take 5) c==(s.take 5).rotate i))
private def without (a : Fin 7) (c : Six) : Six := c.filter (fun b=>b != a)
private def slideSet (a : Fin 7) (c : Six) := wheel (without a c)

private theorem norm (s : Six) (hs : full s) : ∃f : Fin 7→Fin 7,Function.Injective f ∧ f 0=0 ∧ s.map f∈canonical := by
  have data : states.all (fun v=>decide (Function.Injective (encode v) ∧ encode v 0=0 ∧
      v.map (encode v)∈canonical))=true:=by native_decide
  exact ⟨_,of_decide_eq_true (List.all_eq_true.mp data _ (mem_states hs))⟩

private theorem restrict_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (k c : Six) :
    restrict (k.map f) (c.map f)=(restrict k c).map f := by
  simp only [restrict,List.filter_map]
  congr 1
  apply List.filter_congr
  intro a _
  simp [inj.eq_iff]

private theorem predicate_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (s c : Six) :
    ((List.range 5).any (fun i=>restrict ((s.map f).take 5) (c.map f)==((s.map f).take 5).rotate i))=
    ((List.range 5).any (fun i=>restrict (s.take 5) c==(s.take 5).rotate i)) := by
  simp only [←List.map_take,restrict_map f inj,←List.map_rotate]
  apply List.any_congr rfl
  intro i
  simp only [Bool.beq_eq_decide_eq,(List.map_injective_iff.mpr inj).eq_iff]

private theorem fiber_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (zero : f 0=0) (s : Six) :
    (fiber s).image (List.map f)=fiber (s.map f) := by
  ext c
  simp only [fiber,Finset.mem_image,Finset.mem_filter]
  constructor
  · rintro ⟨y,⟨hy,yes⟩,rfl⟩
    exact ⟨WheelRelabel.image_allClasses f inj zero ▸ Finset.mem_image_of_mem (List.map f) hy,
      (predicate_map f inj s y).trans yes⟩
  · rintro ⟨hc,yes⟩
    rw [←WheelRelabel.image_allClasses f inj zero] at hc
    obtain ⟨z,hz,rfl⟩ := Finset.mem_image.mp hc
    exact ⟨z,⟨hz,(predicate_map f inj s z).symm.trans yes⟩,rfl⟩

private def fiberCheck : Bool := canonical.all (fun z=>shape z == fiber z)
private theorem fiberData : fiberCheck=true := by native_decide

/-- A sharp 35-edge component meets every seven-letter circular order whose
restriction to its five fixed letters has the prescribed circular order. -/
theorem shape_eq_fiber (s : Six) (hs : full s) : shape s=fiber s := by
  obtain ⟨f,inj,zero,can⟩:=norm s hs
  apply Finset.image_injective (List.map_injective_iff.mpr inj)
  rw [shape_map f inj zero s hs,fiber_map f inj zero s]
  exact eq_of_beq (List.all_eq_true.mp fiberData _ can)

private theorem clean_delete {c : Six} (h : c∈allClasses) (a : Fin 7) : full (without a c) := by
  have small : ∀d∈allClasses,∀b : Fin 7,full (without b d):=by native_decide
  exact small _ h a

private theorem without_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (a : Fin 7) (c : Six) :
    without (f a) (c.map f)=(without a c).map f := by
  simp only [without,List.filter_map]
  congr 1
  apply List.filter_congr
  intro b _
  change (!(f b == f a))=(!(b == a))
  simp only [Bool.beq_eq_decide_eq,inj.eq_iff]

private def closedCheck : Bool := canonical.all fun s=>
  let T:=shape s
  (T.sort (· ≤ ·)).all fun c=>(List.finRange 7).all fun a=>
    if a∈s.take 5 then true else decide ((slideSet a c).card=6 ∧ slideSet a c⊆T)
private theorem closedData : closedCheck=true := by native_decide

/-- All six ways to reinsert an erased letter at a common tag remain in the fiber. -/
private theorem slides {s c : Six} (hs : full s) (hc : c∈shape s) (a : Fin 7) (free : a∉s.take 5) :
    (slideSet a c).card=6 ∧ slideSet a c⊆shape s := by
  obtain ⟨f,inj,zero,can⟩:=norm s hs
  let g:=List.map f
  have gi : Function.Injective g := List.map_injective_iff.mpr inj
  have mapped : g c∈shape (s.map f):=shape_map f inj zero s hs ▸ Finset.mem_image_of_mem _ hc
  have skip : f a∉(s.map f).take 5 := by simpa [←List.map_take,inj.eq_iff] using free
  have raw:=List.all_eq_true.mp (List.all_eq_true.mp (List.all_eq_true.mp closedData _ can)
    (g c) (by simpa using mapped)) (f a) (List.mem_finRange _)
  simp only [skip,↓reduceIte,decide_eq_true_eq] at raw
  have cb : c∈allClasses := by rw [shape_eq_fiber s hs] at hc; exact (Finset.mem_filter.mp hc).1
  have mappedSet : (slideSet a c).image g=slideSet (f a) (g c) := by
    unfold slideSet
    rw [show without (f a) (g c)=(without a c).map f from without_map f inj a c]
    exact WheelRelabel.image_wheel f inj zero (clean_delete cb a)
  have small : (slideSet a c).image g⊆(shape s).image g := by rw [mappedSet,shape_map f inj zero s hs]; exact raw.2
  refine ⟨?_,(Finset.image_subset_image_iff gi).mp small⟩
  rw [←Finset.card_image_of_injective (slideSet a c) gi,mappedSet,raw.1]

theorem six_common {s t : Six} (hs : full s) (ht : full t) (a : Fin 7)
    (left : a∉s.take 5) (right : a∉t.take 5) (met : (shape s ∩ shape t).Nonempty) :
    6≤(shape s∩shape t).card := by
  obtain ⟨c,hc⟩:=met
  obtain ⟨card,A⟩:=slides hs (Finset.mem_inter.mp hc).1 a left
  have B:=(slides ht (Finset.mem_inter.mp hc).2 a right).2
  rw [←card]
  exact Finset.card_le_card (Finset.subset_inter A B)

open ResidualIncidence ResidualRoutes RotationComponentCount DirectedEuler
open scoped Classical in
theorem component_fiber {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {q : Component X} (away : q≠label X s) (size : (part X q).card=35)
    (count : (contacts (support X s) (label X) q).card=30) :
    ∃z,full z ∧ contacts (support X s) (label X) q=fiber z := by
  obtain ⟨z,hz,eq,_⟩:=actual_ten h away size count
  exact ⟨z,hz,eq.trans (shape_eq_fiber _ hz)⟩

#print axioms component_fiber
#print axioms six_common
end ExactWordFlow.Cap35Fibers

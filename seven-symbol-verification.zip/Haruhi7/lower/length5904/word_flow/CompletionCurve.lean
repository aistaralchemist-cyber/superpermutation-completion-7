import Core1620

namespace ExactWordFlow.RotationCore
open SevenWordWindows RotationSpan SuperpermutationBounds

/-- Minimum length for a count threshold, expressed as a set of attainable
lengths so that no convention for the minimum of the empty set is needed. -/
def lengthsFor (k : Nat) : Set Nat :=
  {n | ∃v : Block, 6≤v.length ∧ (visited v).card=720 ∧ k≤(complete v).card ∧ v.length=n}

private theorem add_to {k j : Nat} (kj : k≤j) (hi : j≤720) {w : Block}
    (long : 6≤w.length) (seen : (visited w).card=720) (full : k≤(complete w).card) :
    ∃z : Block, 6≤z.length ∧ (visited z).card=720 ∧ j≤(complete z).card ∧
      z.length=w.length+7*(j-k) := by
  obtain ⟨S,sub,sz⟩ := Finset.exists_subset_card_eq full
  have good : S⊆allClasses := fun c hc => ((mem_complete _ _).mp (sub hc)).1
  have rem := Finset.card_sdiff_of_subset good
  rw [board,sz] at rem
  obtain ⟨T,st,szT⟩ := Finset.exists_subset_card_eq (s:=allClasses \ S)
    (show j-k≤_ by omega)
  have dis : Disjoint S T := Finset.disjoint_left.mpr (fun _ hs ht => (Finset.mem_sdiff.mp (st ht)).2 hs)
  obtain ⟨z,len,all,covered⟩ := CoreAssembly.add_classes T long seen (fun _ hx => (Finset.mem_sdiff.mp (st hx)).1)
  have union : S∪T⊆complete z := (Finset.union_subset_union_left sub).trans covered
  have num := Finset.card_le_card union
  rw [Finset.card_union_of_disjoint dis,sz,szT] at num
  exact ⟨z,by omega,all,by omega,by rwa [szT] at len⟩

private theorem control_counts {v : Block} {l a b : Nat}
    (h : RotationCoreControls.summary v=(l,a,b)) :
    v.length=l ∧ (visited v).card=a ∧ (complete v).card=b := by
  simpa only [RotationCoreControls.summary,Prod.mk.injEq] using h

/-- For every threshold 108 through 720 the least length has the same
intercept and a slope of seven letters per newly required completed class.
No published lower bound or external geometric hypothesis is used. -/
theorem completion_curve (k : Nat) (lo : 108≤k) (hi : k≤720) :
    IsLeast (lengthsFor k) (SuperpermBridge.HR.Ssuper 7-7*(720-k)) := by
  have bound {v : Block} (long : 6≤v.length) (all : (visited v).card=720)
      (done : k≤(complete v).card) : SuperpermBridge.HR.Ssuper 7 ≤ v.length+7*(720-k) := by
    obtain ⟨w,hw,sz⟩ := expand_remaining long all
    have best := SuperpermBridge.ssuper_le_length hw
    omega
  constructor
  · obtain ⟨w,hw,sz⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
    by_cases small : w.length≤5904
    · obtain ⟨p,q,occ⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
      obtain ⟨X,cost,h⟩ := extract_at_ends w hw (by simp [occ]; omega)
      obtain ⟨S,legal,limit,hit,root⟩ := rooted_spanning h (by omega)
      obtain ⟨z,long,len,all,done⟩ := CoreAssembly.target h legal (limit.trans lo) hi hit root
      have min := bound long all done
      exact ⟨z,long,all,done,by omega⟩
    · have up := SuperpermBridge.ssuper_le_length SuperpermLowerBounds.LengthBudget.Word5905.covers
      rw [SuperpermLowerBounds.LengthBudget.Word5905.length_5905] at up
      obtain ⟨len,va,dc⟩ := control_counts reference612.1
      obtain ⟨z,long,seen,done,size⟩ := add_to lo hi (w:=RotationCoreControls.coreWord 612)
        (by omega) va dc.ge
      have min := bound long seen done
      exact ⟨z,long,seen,done,by omega⟩
  · rintro n ⟨v,long,all,done,rfl⟩
    have min := bound long all done
    omega

/-- Raising the threshold anywhere on this interval has an exact marginal
cost, even while the numerical value of the seven-symbol optimum is unknown. -/
theorem exact_gap {i j n m : Nat} (lo : 108 ≤ i) (ord : i ≤ j) (hi : j ≤ 720)
    (first : IsLeast (lengthsFor i) n) (last : IsLeast (lengthsFor j) m) :
    m=n+7*(j-i) := by
  have a := first.unique (completion_curve i lo (ord.trans hi))
  have b := last.unique (completion_curve j (lo.trans ord) hi)
  obtain ⟨w,hw,sz⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
  obtain ⟨l,r,hit⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
  obtain ⟨X,budget,_⟩ := extract_at_ends w hw (by simp [hit]; omega)
  omega

/-- For k=120 this supplies the earlier 1,704-letter decision with no
word-to-excursion hypothesis. -/
theorem exact_threshold (k : Nat) (lo : 108 ≤ k) (hi : k ≤ 720) :
    (∃ w : Block, Covers w ∧ w.length ≤ 5904) ↔
      ∃v : Block, 6 ≤ v.length ∧ v.length ≤ 864+7*k ∧ (visited v).card=720 ∧ k ≤ (complete v).card := by
  constructor
  · intro yes
    obtain ⟨w,long,cap,all,full⟩ := exact_1620.mp yes
    obtain ⟨z,lz,az,cz,sz⟩ := add_to lo hi long all full
    exact ⟨z,lz,by omega,az,cz⟩
  · rintro ⟨v,long,cap,all,full⟩
    obtain ⟨w,hw,sz⟩ := expand_remaining long all
    exact ⟨w,hw,by omega⟩

#print axioms exact_gap
#print axioms exact_threshold
#print axioms completion_curve
end ExactWordFlow.RotationCore

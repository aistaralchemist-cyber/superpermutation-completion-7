import MarkedLargeCap
import SeedWheelCut

namespace ExactWordFlow.HundredDecomposition
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence ResidualRoutes RotationComponentCount
open RotationReinsert MarkedLargeCap
open scoped Classical
open private select from RouteDensity

private theorem partition (X : Multiset Block) (s : Block) :
    X=part X (label X s)+∑q∈occupied X s,part X q := by
  classical
  let Q:=insert (label X s) (occupied X s)
  have notHome : label X s∉occupied X s := Finset.notMem_erase _ _
  have covers (e) (he : e∈X) : label X (src e)∈Q := by
    by_cases same : label X (src e)=label X s
    · simp [Q,same]
    · refine Finset.mem_insert_of_mem (Finset.mem_erase.mpr ⟨same,?_⟩)
      exact Finset.mem_image_of_mem _ (Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,he,rfl⟩))
  have sumAll : ∑q∈Q,part X q=X := by
    ext e
    rw [Multiset.count_sum']
    simp only [part,Multiset.count_filter]
    by_cases he : e∈X
    · simpa [eq_comm] using Finset.sum_ite_eq' Q (label X (src e)) (fun _=>(Multiset.count e X))
          |>.trans (ite_eq_left (covers e he))
    · simp [Multiset.count_eq_zero.mpr he]
  rw [Finset.sum_insert notHome] at sumAll
  exact sumAll.symm

private theorem wheel_list {X : Multiset Block} (Q : Finset (Component X))
    (complete : ∀q∈Q,∃v,full v ∧ label X v=q ∧ part X q=↑(GlobalWheelRank.wheel v)) :
    ∃ws : List Block, ws.length=Q.card ∧ (∀v∈ws, full v ∧ label X v∈Q) ∧
      (ws.map (label X)).Nodup ∧ EmbeddedWheels.turns ws=∑q∈Q,part X q := by
  classical
  induction Q using Finset.induction_on with
  | empty => exact ⟨[],by simp,by simp,by simp,by simp [EmbeddedWheels.turns]⟩
  | @insert q Q fresh ih =>
    obtain ⟨v,clean,key,edge⟩:=complete q (Finset.mem_insert_self ..)
    obtain ⟨ws,size,legal,distinct,bag⟩:=ih (fun x hx=>complete x (Finset.mem_insert_of_mem hx))
    refine ⟨v::ws,by simp [size,fresh],?_,?_,?_⟩
    · intro x hx
      rcases List.mem_cons.mp hx with rfl|later
      · exact ⟨clean,by simp [key]⟩
      · exact ⟨(legal _ later).1,Finset.mem_insert_of_mem (legal _ later).2⟩
    · simp only [List.map_cons,List.nodup_cons,key,distinct,and_true,List.mem_map]
      rintro ⟨v,hv,eq⟩
      exact fresh (eq ▸ (legal _ hv).2)
    · rw [Finset.sum_insert fresh,edge,←bag]
      simp [EmbeddedWheels.turns]

/-- A realizable hundred-component placement is precisely split here into
its actual open Euler path and one complete six-wheel per other component.
The marked 259-position walk follows that exact path. -/
theorem decompose {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (hundred : (occupied X s).card=100) :
    ∃ es ws : List Block, ∃ z : Block, ∃ u : ℕ → Block, ∃ I : Finset ℕ,
      Route src dst s es t ∧ es.length=258 ∧ (∀e∈es,e.length=7) ∧ classCount s es=220 ∧
      ws.length=100 ∧ (∀v∈ws,full v) ∧ (ws.map (label X)).Nodup ∧
      X=↑es+EmbeddedWheels.turns ws ∧ z.length=264 ∧ z.take 6=s ∧ windows z=es ∧
      Walk u ∧ u 0=s ∧ u 258=t ∧ positions u 259=s::es.map dst ∧
      Marked u (·∈I) ∧ count (·∈I) 0 259=220 := by
  classical
  obtain ⟨cost,root,rank,contacts,components⟩:=hundred_shape h budget hundred
  obtain ⟨a,b,es,edges,r,eq,endInfo⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=endInfo.1 rfl
  subst a; subst b
  have len : es.length=258 := (congrArg Multiset.card edges).trans root
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (edges ▸ (show e∈(↑es : Multiset Block) from he))).1
  have incl:=contacts_bound (support X s) eq r edges
  rw [contacts] at incl
  have lim:=WeightedMarks.path_cap r wd
  have colors : classCount s es=220 := by omega
  obtain ⟨ws,num,legal,nodup,packet⟩:=wheel_list (occupied X s) (fun q hq=>(components q hq).2)
  have split:=partition X s
  rw [←edges,←packet] at split
  obtain ⟨z,sz,start,word⟩:=spell_route r h.start_six wd
  obtain ⟨u,walk,first,last,shape⟩:=route_walk r wd
  rw [len] at last shape
  obtain ⟨I,mark,count⟩:=select u 259
  rw [shape] at count
  exact ⟨es,ws,z,u,I,r,len,wd,colors,num.trans hundred,fun x hx=>(legal x hx).1,nodup,split,
    by omega,start,word,walk,first,last,shape,mark,count.trans colors⟩

open private mem_sources from ResidualRoutes
open private wheel_data from EmbeddedWheels

/-- Every class not touched by the actual root must be covered by one of
the actual wheel rows. The proof retains their original alphabet labels. -/
theorem class_cover {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {es ws : List Block} (root : Route src dst s es t) (legal : ∀v∈ws, full v)
    (split : X=↑es+EmbeddedWheels.turns ws) :
    allClasses \ touched (s::es.map dst) ⊆ ws.toFinset.biUnion (fun v=>(orbit v).toFinset) := by
  classical
  intro c hc
  obtain ⟨valid,no⟩:=Finset.mem_sdiff.mp hc
  obtain ⟨u,atU,fu,key⟩:=RotationSpan.every_tag h valid
  have notRoot (v : Block) (here : v∈s::es.map dst) (f : full v) (k : tag v=c) : False := by
    exact no (List.mem_toFinset.mpr (List.mem_map.mpr ⟨v,List.mem_filter.mpr ⟨here,decide_eq_true f⟩,k⟩))
  have inWheel (e : Block) (edge : e∈EmbeddedWheels.turns ws)
      (endTag : tag (src e)=c ∨ tag (dst e)=c) : c∈ws.toFinset.biUnion (fun v=>(orbit v).toFinset) := by
    obtain ⟨v,hv,there⟩:=List.mem_flatMap.mp (show e∈ws.flatMap GlobalWheelRank.wheel from edge)
    have tags:=(wheel_data v (mem_states (legal _ hv))).2.2.2 e there
    apply Finset.mem_biUnion.mpr
    refine ⟨v,List.mem_toFinset.mpr hv,List.mem_toFinset.mpr ?_⟩
    exact endTag.elim (fun left=>left ▸ tags.2.2.1) (fun right=>right ▸ tags.2.2.2)
  rcases Finset.mem_insert.mp atU with rfl|rest
  · exact (notRoot _ List.mem_cons_self fu key).elim
  rcases Finset.mem_union.mp rest with srcU|dstU
  · obtain ⟨e,em,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp srcU)
    rw [split] at em
    rcases Multiset.mem_add.mp em with re|wheel
    · exact (notRoot _ (mem_sources root re) fu key).elim
    · exact inWheel e wheel (Or.inl key)
  · obtain ⟨e,em,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp dstU)
    rw [split] at em
    rcases Multiset.mem_add.mp em with re|wheel
    · exact (notRoot _ (List.mem_cons_of_mem _ (List.mem_map.mpr ⟨e,re,rfl⟩)) fu key).elim
    · exact inWheel e wheel (Or.inr key)

open private required_data from ResidualIncidence

/-- The full connected-closure condition also carries over to the actual
rows; merely covering all colors by their union is weaker. -/
theorem closed_cover {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {es ws : List Block} (_root : Route src dst s es t) (legal : ∀v∈ws,full v)
    (split : X=↑es+EmbeddedWheels.turns ws) :
    SeedWheelCut.ClosedCover (touched (s::es.map dst)) allClasses
      (ws.toFinset.image (fun v=>(orbit v).toFinset)) := by
  classical
  intro C base closed
  let P : Set Block := {v | full v → tag v∈C}
  have inRoot (v) (hv : v∈s::es.map dst) : v∈P := by
    intro clean
    exact base (List.mem_toFinset.mpr (List.mem_map.mpr ⟨v,List.mem_filter.mpr ⟨hv,decide_eq_true clean⟩,rfl⟩))
  have stable (e) (he : e∈required+X) (atSrc : src e∈P) : dst e∈P := by
    rcases Multiset.mem_add.mp he with must|extra
    · obtain ⟨sf,_,equal⟩:=required_data e must
      exact fun _=>equal ▸ atSrc sf
    rw [split] at extra
    rcases Multiset.mem_add.mp extra with re|onWheel
    · exact inRoot _ (List.mem_cons_of_mem _ (List.mem_map.mpr ⟨e,re,rfl⟩))
    obtain ⟨v,hv,there⟩:=List.mem_flatMap.mp (show e∈ws.flatMap GlobalWheelRank.wheel from onWheel)
    have tags:=(wheel_data v (mem_states (legal _ hv))).2.2.2 e there
    have member:=Finset.mem_image_of_mem (fun v=>(orbit v).toFinset) (List.mem_toFinset.mpr hv)
    have meet : (C∩(orbit v).toFinset).Nonempty := ⟨_,Finset.mem_inter.mpr ⟨atSrc tags.1,List.mem_toFinset.mpr tags.2.2.1⟩⟩
    exact fun _=>closed _ member meet (List.mem_toFinset.mpr tags.2.2.2)
  intro c hc
  have tab : ∀d∈allClasses,d∈representatives ∧ tag (src d)=d := by native_decide
  obtain ⟨rep,equal⟩:=tab c hc
  have root:=h.reachable P (inRoot _ List.mem_cons_self) stable c (Multiset.mem_add.mpr (Or.inl rep))
  exact equal ▸ root (required_data c rep).1

#print axioms decompose
end ExactWordFlow.HundredDecomposition

import DirectStarData

namespace ExactWordFlow.DirectStarMask

set_option maxHeartbeats 0 in
private theorem raw : FusedPacked.check 306 acc=true := by native_decide

theorem passed : FusedAny.check 306 accept=true := by
  exact FusedPacked.certified 306 acc accept (fun _ _ yes=>yes) raw

#print axioms passed
end ExactWordFlow.DirectStarMask

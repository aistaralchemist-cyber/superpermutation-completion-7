import NearRootMoves
import NearRootSets

namespace ExactWordFlow.NearWheelBinding
open SevenWordWindows SeedWheelCut RotationCore ExtremeWheelCut NearRootMoves NearHardRoots
open ResidualDensity.ExtremalRealizations ResidualDensity.NearExtrema
open private valid eliminates from ExtremeWheelCut

inductive Answer where
  | easy (c : Certificate)
  | hard (i : Nat) (moves : List (Fin 8))
deriving Inhabited

private def chain : List String → Certificate
  | [d] => .stop (digits d)
  | d::q::tail => .force (digits d) (digits q) (chain tail)
  | [] => .stop []

private def parse (line : String) : Block × Answer :=
  match line.splitOn " " with
  | w::"E"::c => (digits w,.easy (chain c))
  | [w,"H",i,q] => (digits w,.hard i.toNat!
      (if q="-" then [] else q.toList.map fun c=>Fin.ofNat 8 (c.toNat-'0'.toNat)))
  | _ => default

private def records (n : Nat) : Array (Block × Answer) :=
  let data := match n with
    | 98 => include_str "near-roots-98.txt"
    | 97 => include_str "near-roots-97.txt"
    | 96 => include_str "near-roots-96.txt"
    | _ => ""
  ((data.trimAscii.toString.splitOn "\n").map parse).toArray

private def baseGood (n : Nat) (table : Array (Finset Block)) (p : Block × Answer) : Bool :=
  let R := visited p.1
  match p.2 with
  | .easy c => decide (R.card+5*n≤720) && valid R c
  | .hard i xs => decide (i<table.size ∧ applyMoves xs R=table[i]! ∧ (table[i]!).card=720-5*n)

-- A hash only selects a bucket. Every lookup subsequently compares the actual
-- transformed finite sets, so collisions cannot give a spurious proof.
private def fingerprint (R : Finset Block) := ∑c∈R, (hash c).toNat

private def index (v : Array (Block × Answer)) : Std.HashMap Nat (Nat × Nat) := Id.run do
  let mut lut : Std.HashMap Nat (Nat × Nat) := {}
  for i in [:v.size] do
    let mut R := visited v[i]!.1
    for shift in [:7] do
      lut := lut.insert (fingerprint R) (i,(7-shift)%7)
      R := R.image (move 7)
  return lut

private def checkLookup (v : Array (Block × Answer)) (lut : Std.HashMap Nat (Nat × Nat)) (R : Finset Block) :=
  let (i,j) := lut.getD (fingerprint R) (v.size,0)
  decide (i<v.size ∧ applyMoves (List.replicate j 7) R=visited v[i]!.1)

def verified (n : Nat) :=
  let v := records n
  let table := (NearHardRoots.hard n).toArray
  v.toList.all (baseGood n table) &&
    let lut := index v
    (realizations (profiles n)).all (checkLookup v lut)

/-- Every connected cover in one of the three complete finite geometries
can be relabelled to a remaining representative. All other rooted cases are
excluded by explicit connected-wheel forcing chains. -/
theorem exhaust_verified {n : Nat} (ver : verified n=true) {R : Finset Block}
    (geo : R∈realizations (profiles n)) {W : Finset (Finset Block)}
    (legal : W⊆allRows) (size : W.card≤n) (covered : ClosedCover R allClasses W) :
    ∃r∈NearHardRoots.hard n, ∃w : Finset (Finset Block),
      w⊆allRows ∧ w.card≤n ∧ r.card=720-5*n ∧ ClosedCover r allClasses w := by
  obtain ⟨bases,links⟩:=Bool.and_eq_true_iff.mp ver
  let v := records n
  let tab := (NearHardRoots.hard n).toArray
  let ij := (index v).getD (fingerprint R) (v.size,0)
  have look := of_decide_eq_true (List.all_eq_true.mp links R geo)
  change ij.1<v.size ∧ applyMoves (List.replicate ij.2 7) R=visited v[ij.1]!.1 at look
  have entry : v[ij.1]!∈v.toList := by
    rw [getElem!_pos v ij.1 look.1]
    exact Array.mem_toList_iff.mpr (Array.getElem_mem look.1)
  have ok := List.all_eq_true.mp bases _ entry
  obtain ⟨V,allowed,bound,link⟩:=transport legal covered (List.replicate ij.2 7)
  rw [look.2] at link
  generalize h : v[ij.1]! = p at link ok
  obtain ⟨word,ans⟩:=p
  cases ans with
  | easy c =>
    obtain ⟨budget,cert⟩:=Bool.and_eq_true_iff.mp ok
    have price := of_decide_eq_true budget
    exact False.elim (eliminates _ _ allowed (by rw [board]; omega) cert link)
  | hard i xs =>
    obtain ⟨ix,eq,sz⟩:=of_decide_eq_true ok
    change i<tab.size at ix
    change applyMoves xs (visited word)=tab[i]! at eq
    change (tab[i]!).card=720-5*n at sz
    have mem : tab[i]!∈NearHardRoots.hard n := by
      change tab[i]!∈tab.toList
      rw [getElem!_pos tab i ix]
      exact Array.mem_toList_iff.mpr (Array.getElem_mem ix)
    obtain ⟨w,l,s,cc⟩:=transport allowed link xs
    rw [eq] at cc
    exact ⟨_,mem,w,l,s.trans (bound.trans size),sz,cc⟩

#print axioms exhaust_verified
end ExactWordFlow.NearWheelBinding

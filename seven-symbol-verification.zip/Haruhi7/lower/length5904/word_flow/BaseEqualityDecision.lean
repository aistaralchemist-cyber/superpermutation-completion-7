import BaseWheelFrontier91
import VirtualComponentPrice
import Target107
import TightControl
import WheelMinimumBoundary

namespace ExactWordFlow.BaseEqualityDecision
open SevenWordWindows SuperpermutationBounds RotationCore WheelFreeBoundary LiteralWheelCover

theorem zero_iff (b : Block) : condition b 0 ↔ visited b=allClasses := by
  constructor
  · rintro ⟨S,_,count,rest⟩
    have empty : S=∅:=Finset.card_eq_zero.mp (by omega)
    rw [empty] at rest
    have eq : allClasses\visited b=∅:=by simpa using rest
    exact Finset.Subset.antisymm (visited_subset b) (Finset.sdiff_eq_empty_iff_subset.mp eq)
  · intro hit
    exact ⟨∅,Finset.empty_subset _,by simp,by simp [hit]⟩

def candidate (b : Block) (m : Nat) : Prop :=
  WheelFree b ∧ (complete b).card=92 ∧ b.length+6*m=1508 ∧
    IsLeast {j : Nat | condition b j} m

theorem exact : (∃w : Block,Covers w ∧ w.length≤5904) ↔
    ∃b m,candidate b m ∧ 962≤b.length ∧ m≤91 := by
  rw [WheelFreeBoundary.exact_minimum]
  constructor
  · rintro ⟨b,m,free,done,len,_,_,least⟩
    obtain ⟨cap,low⟩:=WheelBaseResidual.equality_91 done len least.1
    exact ⟨b,m,⟨free,done,len,least⟩,low,cap⟩
  · rintro ⟨b,m,⟨free,done,len,least⟩,low,cap⟩
    exact ⟨b,m,free,done,len,by omega,by omega,least⟩

theorem zero_candidate (b : Block) : candidate b 0 ↔
    WheelFree b ∧ (complete b).card=92 ∧ b.length=1508 ∧ visited b=allClasses := by
  constructor
  · rintro ⟨free,done,len,least⟩
    exact ⟨free,done,by simpa using len,(zero_iff b).mp least.1⟩
  · rintro ⟨free,done,len,hit⟩
    exact ⟨free,done,by simpa using len,(zero_iff b).mpr hit,fun _ _=>Nat.zero_le _⟩

open RotationComponentCount CompletedSpareRanks CoreAssembly ResidualDensity ResidualRoutes

/-- The same loss budget for every value of the minimum cover, including zero. -/
theorem candidate_price {b : Block} {m : Nat} (h : candidate b m) :
    let Y:=bag b-mandatory (complete b)
    let N:=occupied Y (b.take 6)
    let B:=N.filter fun q=>7≤(part Y q).card
    m+N.card≤92 ∧
      45*(extraAttachments Y b+((visited b).card+5*m-720))+3*(m+N.card)+22*B.card≤308 := by
  obtain ⟨_,done,total,least⟩:=h
  obtain ⟨rs,v,ins,small,vis⟩:=(budget_iff b m).mpr least.1
  have len:=ins.length_eq
  have cv : (complete v).card=92:=ins.complete_eq ▸ done
  have lower:=(Boundary1508Floor.only_boundary (w:=v) (by omega) vis cv.ge).2
  have re : rs.length=m:=by omega
  exact re ▸ WheelBaseResidual.canonical_budget ins done vis (by omega)

/-- Excluding the entire remaining equality family is exactly the 107 target. -/
theorem completion_goal : Target107.ceiling 1620 107 ↔
    ¬∃b m,candidate b m ∧ 962≤b.length ∧ m≤91 := by
  rw [←exact,Target107.goal_iff_minimum]
  constructor
  · rintro best ⟨w,hit,len⟩
    have lower:=SuperpermBridge.ssuper_le_length hit
    omega
  · intro no
    obtain ⟨w,hit,len⟩:=SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
    have upper:=SuperpermBridge.ssuper_le_length SuperpermLowerBounds.LengthBudget.Word5905.covers
    rw [SuperpermLowerBounds.LengthBudget.Word5905.length_5905] at upper
    by_contra! bad
    exact no ⟨w,hit,by omega⟩

/-- An explicit wheel-free core lies just one unit above the proposed cutoff. -/
theorem attained_1509 : ∃b : Block,WheelFree b ∧ (complete b).card=92 ∧
    IsLeast {j : Nat | condition b j} 37 ∧ b.length+6*37=1509 := by
  exact ⟨StrippedControl.base,StrippedControl.base_free,StrippedControl.verified_control.2.1,
    StrippedControl.exact_near_control⟩

#print axioms exact
#print axioms zero_candidate
#print axioms candidate_price
#print axioms completion_goal
end ExactWordFlow.BaseEqualityDecision

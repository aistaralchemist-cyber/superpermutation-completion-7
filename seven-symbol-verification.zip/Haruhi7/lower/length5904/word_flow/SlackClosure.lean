import ForcedRootClosure
import MarkedWheelBound

namespace ExactWordFlow.SlackClosure
open SeedWheelCut
variable {α : Type*} [DecidableEq α]

/-- The total cost in repeated seed contacts is charged once across all
selected wheels. Thus missing forced tags cannot each draw on the same
slack independently. No saturation or endpoint condition is assumed. -/
theorem contact_bill (P A V : Finset α) (W : Finset (Finset α)) (inside : P⊆A)
    (width : ∀w∈W,w.card≤6) (linked : ClosedCover A V W) :
    V.card + ∑ w∈W, ((P∩w).card-1) ≤ A.card + 5*W.card := by
  classical
  by_cases grow : ∃w∈W,(A∩w).Nonempty ∧ ¬w⊆A
  · obtain ⟨w,hw,hit,_⟩:=grow
    have next : ClosedCover (A∪w) V (W.erase w) := by
      intro C sub closed
      apply linked C (Finset.subset_union_left.trans sub)
      intro b hb meet
      by_cases eq : b=w
      · exact eq ▸ (Finset.subset_union_right.trans sub)
      · exact closed b (Finset.mem_erase.mpr ⟨eq,hb⟩) meet
    have rest:=contact_bill P (A∪w) V (W.erase w) (inside.trans Finset.subset_union_left)
      (fun b hb=>width b (Finset.mem_of_mem_erase hb)) next
    have old:=Finset.card_le_card (Finset.inter_subset_inter_right (u:=w) inside)
    have positive:=Finset.card_pos.mpr hit
    have union:=Finset.card_union_add_card_inter A w
    have right:=width w hw
    have cnt:=Finset.card_erase_add_one hw
    have split:=Finset.sum_erase_add (f:=fun b:Finset α=>(P∩b).card-1) W hw
    omega
  · have sub := linked A (Finset.Subset.refl _) (fun w hw hit=>by
      by_contra miss;exact grow ⟨w,hw,hit,miss⟩)
    have total:=Finset.card_le_card sub
    have sum : (∑w∈W,((P∩w).card-1)) ≤ W.card*5 := by
      apply Finset.sum_le_card_nsmul
      intro w hw
      have small:=Finset.card_le_card (Finset.inter_subset_right (s₁:=P) (s₂:=w))
      have bound:=width w hw
      omega
    omega
termination_by W.card
decreasing_by exact Finset.card_erase_lt_of_mem hw

def bad (A : Finset α) (W : Finset (Finset α)) := W.filter fun w=>2≤(A∩w).card

/-- A single family of exceptional wheels accounts for all seed choices
inside a given root, and for any number of closure iterations. -/
theorem bad_budget (A V : Finset α) (W : Finset (Finset α))
    (width : ∀w∈W,w.card≤6) (linked : ClosedCover A V W) :
    V.card+(bad A W).card≤A.card+5*W.card := by
  classical
  have n := contact_bill A A V W (Finset.Subset.refl _) width linked
  have cost : (bad A W).card ≤ ∑w∈W,((A∩w).card-1) := by
    calc
      _ = ∑w∈bad A W,1 := by simp
      _ ≤ ∑w∈bad A W,((A∩w).card-1) := by
        apply Finset.sum_le_sum
        intro w hw
        have large:=(Finset.mem_filter.mp hw).2
        omega
      _ ≤ ∑w∈W,((A∩w).card-1) := Finset.sum_le_sum_of_subset (Finset.filter_subset _ _)
  omega

private theorem reaches {A V : Finset α} {W : Finset (Finset α)} (link : ClosedCover A V W)
    {x : α} (req : x∈V) (out : x∉A) : ∃w∈W,x∈w := by
  have all := link (A ∪ W.biUnion id) Finset.subset_union_left (fun w hw _ =>
    (show w⊆W.biUnion id from fun t ht => Finset.mem_biUnion.mpr ⟨w,hw,ht⟩).trans Finset.subset_union_right)
  rcases Finset.mem_union.mp (all req) with yes | new
  · exact False.elim (out yes)
  · exact Finset.mem_biUnion.mp new

private theorem union_weight {β : Type*} [DecidableEq β] (S : Finset β)
    (region : β→Finset α) (fee : α→Nat) :
    (∑x∈S.biUnion region,fee x) ≤ ∑i∈S,∑x∈region i,fee x := by
  classical
  induction S using Finset.induction_on with
  | empty => simp
  | @insert a S ha ih =>
    rw [Finset.biUnion_insert,Finset.sum_insert ha]
    have split:= Finset.sum_union_inter (s₁:=region a) (s₂:=S.biUnion region) (f:=fee)
    omega

/-- A generic certificate can use any nonnegative weight on the demanded
tags. Each row is priced by its seed intersection, and the weights need only
satisfy one inequality per allowable row. -/
theorem weighted {P A V H : Finset α} {W : Finset (Finset α)}
    (inside : P⊆A) (need : H⊆V) (width : ∀w∈W,w.card≤6) (linked : ClosedCover A V W)
    (rate : Nat) (fee : α→Nat)
    (prices : ∀w∈W,(∑x∈(w∩H)\P,fee x) ≤ rate*((P∩w).card-1)) :
    (∑x∈H\A,fee x) ≤ rate*(A.card+5*W.card-V.card) := by
  classical
  let region (w : Finset α) := (w∩H)\P
  have all : H\A⊆W.biUnion region := by
    intro x hx
    obtain ⟨inH,outside⟩:=Finset.mem_sdiff.mp hx
    obtain ⟨w,hw,yes⟩:=reaches linked (need inH) outside
    exact Finset.mem_biUnion.mpr ⟨w,hw,Finset.mem_sdiff.mpr ⟨Finset.mem_inter.mpr ⟨yes,inH⟩,
      fun hp=>outside (inside hp)⟩⟩
  have bound:=contact_bill P A V W inside width linked
  calc
    _ ≤ ∑x∈W.biUnion region,fee x := Finset.sum_le_sum_of_subset all
    _ ≤ ∑w∈W,∑x∈region w,fee x := union_weight W region fee
    _ ≤ ∑w∈W,rate*((P∩w).card-1) := Finset.sum_le_sum prices
    _ = rate*∑w∈W,((P∩w).card-1) := (Finset.mul_sum ..).symm
    _ ≤ rate*(A.card+5*W.card-V.card) := Nat.mul_le_mul_left rate (by omega)

/-- The prototype need not be contained in the true root. A missing
prototype tag pays only for selected rows actually incident to it.
Per-row prices may be integer-scaled fractions. -/
theorem robust {P A V H : Finset α} {rows W : Finset (Finset α)}
    (legal : W⊆rows) (need : H⊆V) (width : ∀w∈W,w.card≤6) (linked : ClosedCover A V W)
    (rate : Nat) (fee : α→Nat) (toll : Finset α→Nat)
    (cap : ∀w∈W,toll w≤rate)
    (priced : ∀w∈W,(∑x∈w∩H,fee x)≤toll w*((P∩w).card-1)) :
    (∑x∈H\A,fee x) ≤ rate*(A.card+5*W.card-V.card) +
      ∑x∈P\A, ∑w∈rows, (if x∈w then toll w else 0) := by
  classical
  let drop:=P\A
  let miss (w : Finset α) := ∑x∈drop, (if x∈w then toll w else 0)
  have spill (w : Finset α) : miss w=toll w*(drop∩w).card := by
    simp [miss,Nat.mul_comm]
  have step (w : Finset α) (hw : w∈W) : (∑x∈w∩H,fee x)≤
       rate*((A∩w).card-1)+miss w := by
    have cover : P∩w⊆(A∩w) ∪ (drop∩w) := by
      intro x hx
      obtain ⟨hp,hrow⟩:=Finset.mem_inter.mp hx
      by_cases inA : x∈A
      · exact Finset.mem_union_left _ (Finset.mem_inter.mpr ⟨inA,hrow⟩)
      · exact Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨Finset.mem_sdiff.mpr ⟨hp,inA⟩,hrow⟩)
    have total:=(Finset.card_le_card cover).trans (Finset.card_union_le _ _)
    have units : (P∩w).card-1 ≤ (A∩w).card-1+(drop∩w).card := by omega
    rw [spill]
    calc
      _ ≤ toll w*((P∩w).card-1) := priced w hw
      _ ≤ toll w*((A∩w).card-1+(drop∩w).card) := Nat.mul_le_mul_left _ units
      _ ≤ _ := by rw [Nat.mul_add]; exact Nat.add_le_add_right (Nat.mul_le_mul_right _ (cap w hw)) _
  have cover : H\A⊆W.biUnion (fun w=>w∩H) := by
    intro x hx
    obtain ⟨inH,out⟩:=Finset.mem_sdiff.mp hx
    obtain ⟨w,hw,inW⟩:=reaches linked (need inH) out
    exact Finset.mem_biUnion.mpr ⟨w,hw,Finset.mem_inter.mpr ⟨inW,inH⟩⟩
  have bill:=contact_bill A A V W (Finset.Subset.refl _) width linked
  have left : (∑w∈W,rate*((A∩w).card-1))≤rate*(A.card+5*W.card-V.card) := by
    rw [←Finset.mul_sum]
    exact Nat.mul_le_mul_left _ (by omega)
  have right : (∑w∈W,miss w) ≤ ∑x∈drop, ∑w∈rows, (if x∈w then toll w else 0) := by
    simp only [miss,Finset.sum_comm (s:=W) (t:=drop)]
    exact Finset.sum_le_sum (fun x _=>Finset.sum_le_sum_of_subset legal)
  calc
    _ ≤ ∑x∈W.biUnion (fun w=>w∩H),fee x := Finset.sum_le_sum_of_subset cover
    _ ≤ ∑w∈W,∑x∈w∩H,fee x := union_weight W _ fee
    _ ≤ ∑w∈W,(rate*((A∩w).card-1)+miss w) := Finset.sum_le_sum step
    _ ≤ _ := by rw [Finset.sum_add_distrib]; exact Nat.add_le_add left right

/-- If every allowable wheel containing a demanded label meets the seed
at least twice, at most four of those labels can remain outside the root
per spare unit. This holds for arbitrary seeds and all endpoints. -/
theorem four_per_slack {P A V H : Finset α} {W : Finset (Finset α)}
    (inside : P⊆A) (need : H⊆V) (width : ∀w∈W,w.card≤6)
    (blocked : ∀d∈H,∀w∈W,d∈w → 2≤(P∩w).card) (linked : ClosedCover A V W) :
    (H \ A).card ≤ 4*(A.card+5*W.card-V.card) := by
  classical
  have ans:=weighted inside need width linked 4 (fun _=>1) (by
    intro w hw
    simp only [Finset.sum_const,smul_eq_mul,mul_one]
    by_cases empty : ((w∩H)\P)=∅
    · simp [empty]
    · obtain ⟨x,hx⟩:=Finset.nonempty_iff_ne_empty.mpr empty
      obtain ⟨one,two⟩:=Finset.mem_inter.mp (Finset.mem_sdiff.mp hx).1
      have heavy:=blocked x two w hw one
      have sub : (w∩H)\P⊆w\P := Finset.sdiff_subset_sdiff_left P Finset.inter_subset_left
      have small:=Finset.card_le_card sub
      have count:=Finset.card_sdiff_add_card_inter w P
      rw [Finset.inter_comm w P] at count
      have cap:=width w hw
      omega)
  simpa using ans

/-- Points belonging to exceptional rows may avoid the usual closure.
Suppress those rows' points as new implications, and keep the same rows
for any number of rounds. -/
def forceExcept (board : Finset α) (rows except : Finset (Finset α)) (P : Finset α) :=
  P ∪ board.filter (fun d=> d∉except.biUnion id ∧ ∀w∈rows,d∈w → 2≤(P∩w).card)

theorem iterate_debt (A V : Finset α) (rows W : Finset (Finset α))
    (legal : W⊆rows) (width : ∀w∈W,w.card≤6) (linked : ClosedCover A V W) :
    ∃E⊆W, V.card+E.card≤A.card+5*W.card ∧
      ∀P⊆A,∀n,(forceExcept V rows E)^[n] P⊆A := by
  classical
  let E:=bad A W
  refine ⟨E,Finset.filter_subset _ _,bad_budget A V W width linked,?_⟩
  have step {P : Finset α} (inside : P⊆A) : forceExcept V rows E P⊆A := by
    intro x hx
    rcases Finset.mem_union.mp hx with old|new
    · exact inside old
    · obtain ⟨req,off,blocked⟩:=Finset.mem_filter.mp new
      by_contra outside
      obtain ⟨w,hw,yes⟩:=reaches linked req outside
      have heavy:=(blocked w (legal hw) yes).trans (Finset.card_le_card
        (Finset.inter_subset_inter_right (u:=w) inside))
      have chosen : w∈E := Finset.mem_filter.mpr ⟨hw,heavy⟩
      exact off (Finset.mem_biUnion.mpr ⟨w,chosen,yes⟩)
  intro P hp n
  induction n with
  | zero => exact hp
  | succ n ih => rw [Function.iterate_succ_apply']; exact step ih

#print axioms contact_bill
#print axioms robust
#print axioms weighted
#print axioms four_per_slack
#print axioms iterate_debt
end ExactWordFlow.SlackClosure

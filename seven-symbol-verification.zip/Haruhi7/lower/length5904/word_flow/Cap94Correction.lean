import NinetyFour
import CanonicalCorrectionCap

namespace ExactWordFlow.Cap94Correction
open SevenWordWindows ResidualDensity RotationComponentCount ResidualRoutes
open DeepBridgeComponents CanonicalCorrectionCap
open private wheel_data wheel_edges from DeepBridgeComponents
private theorem isolated_with_cap {X : Multiset Block} {s t : Block} (_flow : Feasible X s t)
    (limit : (occupied X s).card≤94) (W : Finset Block) (legal : ∀w∈W,w∈WheelContacts.bases)
    (present : ∀w∈W,∀e∈GlobalWheelRank.wheel w,e∈X) (away : wheelKey s∉W)
    (D : Finset Block) (isolated : ∀w∈W,w∉D → ∀e∈X,
        wheelKey (src e)=w ↔ wheelKey (dst e)=w) : W.card ≤ 94+D.card := by
  classical
  let clear:=W \ D
  have incl : clear.image (label X) ⊆ occupied X s := by
    intro z hz
    obtain ⟨w,wm,rfl⟩:=Finset.mem_image.mp hz
    obtain ⟨hw,off⟩:=Finset.mem_sdiff.mp wm
    obtain ⟨key,_,e,elem,origin⟩:=wheel_data w (legal w hw)
    have used:=present w hw e elem
    have sep : label X w≠label X s := by
      intro same
      have m:=(invariant (fun v=>wheelKey v=w) (isolated w hw off) same).mp key
      exact away (m ▸ hw)
    exact Finset.mem_erase.mpr ⟨sep,Finset.mem_image.mpr
      ⟨w,Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,used,origin⟩),rfl⟩⟩
  have unique : Set.InjOn (label X) (clear : Set Block) := by
    intro a ha b hb eq
    obtain ⟨hA,nA⟩:=Finset.mem_sdiff.mp ha
    obtain ⟨hB,_⟩:=Finset.mem_sdiff.mp hb
    have k:=(wheel_data a (legal a hA)).1
    have bkey:=(invariant (fun v=>wheelKey v=a) (isolated a hA nA) eq).mp k
    change wheelKey b=a at bkey
    rw [(wheel_data b (legal b hB)).1] at bkey
    exact bkey.symm
  have ct:=Finset.card_le_card incl
  rw [Finset.card_image_of_injOn unique] at ct
  have eq:=Finset.card_sdiff_add_card_inter W D
  have inter:=Finset.card_le_card (Finset.inter_subset_right (s₁:=W) (s₂:=D))
  change (W\D).card≤_ at ct
  omega

theorem wheel_cap {X : Multiset Block} {s t : Block} (flow : Feasible X s t)
    (budget : X.card≤858) (W : Finset Block) (legal : ∀w∈W,w∈WheelContacts.bases)
    (present : ∀w∈W,∀e∈GlobalWheelRank.wheel w,e∈X) (away : wheelKey s∉W)
    (bridges : List (List Block))
    (decompose : ∀e∈X,(∃w∈W,e∈GlobalWheelRank.wheel w) ∨
      ∃v∈bridges,src e∈v ∧ dst e∈v)
    (guard : ∀v∈bridges,Guarded W v) (b : BlockProfile W.card)
    (cost : ∀v∈bridges,5≤v.length → ∃c∈b.blocks,5≤c.2) :
    W.card≤94 := by
  have short (many : 95≤W.card) : ∀c∈b.blocks,c.2≤4 := by
    intro c hc
    by_contra! long
    have := expensive_cut b ⟨c,hc,long⟩
    omega
  by_contra! many
  have noDeep (v) (hv : v∈bridges) : v.length≤4 := by
    by_contra! long
    obtain ⟨c,hc,dear⟩:=cost v hv long
    have :=short (by omega) c hc
    omega
  have empty : []∉W := by
    intro h
    have illegal : ([] : Block)∉WheelContacts.bases := by native_decide
    exact illegal (legal _ h)
  have bound:=isolated_with_cap flow (NinetyFour.component_limit flow budget) W legal present away ∅ (by
    intro w hw _ e he
    rcases decompose e he with ⟨k,hk,inside⟩|⟨v,hv,left,right⟩
    · obtain ⟨a,d⟩:=wheel_edges k (legal k hk) e inside
      rw [a,d]
    · let V:=guard v hv
      have off (u) (hu : u∈v) : wheelKey u≠w := by
        intro same
        have mid:=guarded_bridge empty V.px V.py V.a V.b V.start V.finish V.skipLeft V.skipRight
          V.first V.last hu (same ▸ hw)
        have zero : DeepBridgeComponents.interior v=[] := by
          unfold DeepBridgeComponents.interior
          rw [Nat.sub_eq_zero_of_le (noDeep v hv), List.take_zero]
        simp [zero] at mid
      simp [off _ left,off _ right])
  simp at bound
  omega
theorem mass_floor {q e g M : Nat} (exc : 1≤e) (count : M+5*q=719+e+2*g)
    (small : q≤94) : 250+2*g+(e-1)≤M := by omega

#print axioms wheel_cap
end ExactWordFlow.Cap94Correction

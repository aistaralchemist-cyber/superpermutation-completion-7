import CoreCounts

namespace ExactWordFlow.PhaseCount
open SevenWordWindows ResidualDensity RotationReinsert RotationCore
open private end_class from CoreCounts
open private fibre_size from Windows5904

/-- The last six symbols of a permutation determine its first symbol. -/
private theorem decode : ∀p∈representatives,
    ((List.finRange 7).filter (fun a=>a∉dst p))++dst p=p := by native_decide

/-- Count distinct six-letter contexts. Every visited rotation class uses
at least one. In each completed class the seven permutation windows have
distinct destinations, so six additional contexts must be present. -/
theorem phases (v : Block) :
    (visited v).card+6*(complete v).card≤(anchors v).toFinset.card := by
  classical
  let A := (anchors v).toFinset.filter full
  let byClass (c : Block) := A.filter (fun x=>tag x=c)
  have landing : Set.MapsTo tag (A : Set Block) (visited v) := by
    intro x hx
    obtain ⟨seen,clean⟩:=Finset.mem_filter.mp hx
    exact (mem_visited _ _).mpr ⟨x,List.mem_toFinset.mp seen,clean,rfl⟩
  have split : A.card=∑c∈visited v,(byClass c).card :=
    Finset.card_eq_sum_card_fiberwise landing
  have lower (c) (hc : c∈visited v) :
      1+(if c∈complete v then 6 else 0)≤(byClass c).card := by
    by_cases done : c∈complete v
    · obtain ⟨legal,windowsAll⟩:=(mem_complete _ _).mp done
      have distinct : Set.InjOn dst (fibre c) := by
        intro p hp q hq eq
        have pm:=List.mem_toFinset.mp (Finset.mem_filter.mp hp).1
        have qm:=List.mem_toFinset.mp (Finset.mem_filter.mp hq).1
        exact (decode p pm).symm.trans ((congrArg
          (fun d=>((List.finRange 7).filter (fun a=>a∉d))++d) eq).trans (decode q qm))
      have inside : (fibre c).image dst⊆byClass c := by
        intro u hu
        obtain ⟨p,hp,rfl⟩:=Finset.mem_image.mp hu
        obtain ⟨pMem,key⟩:=Finset.mem_filter.mp hp
        have rep:=List.mem_toFinset.mp pMem
        have actual:=windowsAll p rep key
        have ⟨clean,tagged⟩:=end_class p rep
        exact Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr
          ⟨List.mem_toFinset.mpr (List.mem_cons_of_mem _ (List.mem_map_of_mem actual)),clean⟩,
          tagged.trans key⟩
      have bound:=Finset.card_le_card inside
      rw [Finset.card_image_of_injOn distinct,fibre_size legal] at bound
      simpa [done] using bound
    · obtain ⟨u,mem,clean,key⟩:=(mem_visited _ _).mp hc
      have one : 0<(byClass c).card := Finset.card_pos.mpr
        ⟨u,Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨List.mem_toFinset.mpr mem,clean⟩,key⟩⟩
      simpa [done] using one
  have total:=Finset.sum_le_sum lower
  have keep : (visited v).filter (fun c=>c∈complete v)=complete v := by
    ext c
    exact Finset.mem_filter.trans ⟨And.right,fun h=>⟨complete_subset v h,h⟩⟩
  have size : (∑c∈visited v, if c∈complete v then 6 else 0)=6*(complete v).card := by
    rw [←Finset.sum_filter,keep]; simp [Nat.mul_comm]
  simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one,size,←split] at total
  exact total.trans (Finset.card_filter_le ..)

#print axioms phases
end ExactWordFlow.PhaseCount

import EqualityComponent91
import PhaseCount

namespace ExactWordFlow.PrefixCharge
open SevenWordWindows RotationCore RotationReinsert ResidualDensity DirectedEuler

/-- The two sets keep separate track of visited classes and chosen permutation windows. -/
def visitsAt (u : Block) : Finset Block := if full u then {tag u} else ∅
def earns (T : Finset Block) (e : Block) : Finset Block := if e∈T then {e} else ∅

def arrivals : List Block → Finset Block
  | [] => ∅
  | e::es => visitsAt (dst e) ∪ arrivals es

def credits (T : Finset Block) : List Block → Finset Block
  | [] => ∅
  | e::es => earns T e ∪ credits T es

private theorem at_permutation : ∀e∈representatives,
    full (src e) ∧ full (dst e) ∧ tag (src e)=tag (dst e) := by native_decide

/-- A newly read symbol can give a fresh visit or a fresh selected permutation,
but never both. This also applies inside a route, with any prefix history. -/
theorem route_budget {T : Finset Block} (legal : ∀e∈T,e∈representatives)
    {s t : Block} {es : List Block} (r : Route src dst s es t)
    (A G : Finset Block) (start : visitsAt s ⊆ A) :
    (A∪arrivals es).card + (G∪credits T es).card ≤ A.card+G.card+es.length := by
  induction r generalizing A G with
  | nil => simp [arrivals,credits]
  | cons e first tail ih =>
    have budget := ih (A∪visitsAt (dst e)) (G∪earns T e) Finset.subset_union_right
    have single :
        (A∪visitsAt (dst e)).card+(G∪earns T e).card≤A.card+G.card+1 := by
      by_cases sel : e∈T
      · obtain ⟨clean,ends,key⟩:=at_permutation e (legal e sel)
        have before : tag (src e)∈A := start (by simp [←first,visitsAt,clean])
        have atEnd : tag (dst e)∈A := key ▸ before
        have same : A∪visitsAt (dst e)=A := Finset.union_eq_left.mpr (by simpa [visitsAt,ends] using atEnd)
        rw [same]
        simpa [earns,sel,Finset.union_singleton] using
          (show A.card+(insert e G).card ≤ A.card+G.card+1 by
            have := Finset.card_insert_le e G
            omega)
      · have small : (A∪visitsAt (dst e)).card≤A.card+1 := by
          by_cases clean : full (dst e)
          · simpa [visitsAt,clean] using Finset.card_insert_le (tag (dst e)) A
          · simp [visitsAt,clean]
        simp only [earns,sel,ite_false,Finset.union_empty]
        omega
    simp only [arrivals,credits,List.length_cons,←Finset.union_assoc]
    omega

private theorem tags_eq (es : List Block) :
    ((((es.map dst).filter fun u=>decide (full u)).map tag).toFinset)=arrivals es := by
  induction es with
  | nil => simp [arrivals]
  | cons e es ih =>
    by_cases clean : full (dst e) <;> simp [arrivals,visitsAt,clean,ih]

theorem visited_word (v : Block) :
    visited v=visitsAt (v.take 6)∪arrivals (windows v) := by
  by_cases clean : full (v.take 6) <;>
    simp [visited,anchors,visitsAt,clean,tags_eq]

theorem credits_eq (T : Finset Block) (es : List Block) :
    credits T es = T ∩ es.toFinset := by
  ext e
  induction es with
  | nil => simp [credits]
  | cons d ds ih =>
    by_cases hit : d∈T <;> simp [credits,earns,hit,ih]

theorem arrivals_append (a b : List Block) : arrivals (a++b)=arrivals a∪arrivals b := by
  induction a with
  | nil => simp [arrivals]
  | cons x xs ih => simp [arrivals,ih,Finset.union_assoc]

private theorem tail_after {s t : Block} (p q : List Block) (r : Route src dst s (p++q) t) :
    ∃u, Route src dst u q t ∧ visitsAt u ⊆ visitsAt s∪arrivals p := by
  induction p generalizing s with
  | nil => exact ⟨s,r,Finset.subset_union_left⟩
  | cons e ps ih =>
    cases r with
    | cons _ _ tail =>
      obtain ⟨u,hr,incl⟩:=ih tail
      exact ⟨u,hr,fun a ha=>Finset.mem_union_right _ (incl ha)⟩

/-- Every cut in the list of windows of an actual word obeys this bound. -/
theorem suffix_budget {T : Finset Block} (legal : ∀e∈T,e∈representatives)
    {w : Block} {p q : List Block} (split : windows w=p++q) (long : 6≤w.length) :
    (visited w).card+(credits T (windows w)).card ≤
      (visitsAt (w.take 6)∪arrivals p).card+(credits T p).card+q.length := by
  obtain ⟨s,tail,anchor⟩:=tail_after p q (split ▸ read_route w long)
  have step := route_budget legal tail (visitsAt (w.take 6)∪arrivals p) (credits T p) anchor
  rw [visited_word,split,arrivals_append,←Finset.union_assoc]
  have add : credits T (p++q)=credits T p∪credits T q := by
    simp [credits_eq,Finset.inter_union_distrib_left]
  rwa [add]

/-- The same 91 selected classes work for every prefix of a counterexample. -/
theorem candidate_cut {w : Block} (long : 6≤w.length)
    (hit : (visited w).card=720) (many : 91≤(complete w).card) :
    ∃S⊆complete w, S.card=91 ∧
      ∀p q, windows w=p++q →
        1357 ≤ (visitsAt (w.take 6)∪arrivals p).card+
          (credits (CoreAssembly.mandatory S).toFinset p).card+q.length := by
  obtain ⟨S,sub,sz⟩:=Finset.exists_subset_card_eq many
  let T:=(CoreAssembly.mandatory S).toFinset
  have memT {e} (h:e∈T) : e∈representatives ∧ classKey e∈S :=
    Multiset.mem_filter.mp (Multiset.mem_toFinset.mp h)
  have tab := CoreAssembly.mandatory_data S (fun c h=>((mem_complete w c).mp (sub h)).1)
  have nd : required.Nodup:=Multiset.coe_nodup.mpr (List.nodup_permutations _ (List.nodup_finRange _))
  have cardT : T.card=637 := by
    change (CoreAssembly.mandatory S).dedup.card=637
    have chosenNodup : (CoreAssembly.mandatory S).Nodup := nd.filter _
    rw [Multiset.dedup_eq_self.mpr chosenNodup,tab.1,sz]
  have keep : T ⊆ (windows w).toFinset := by
    intro e he
    obtain ⟨rep,inS⟩:=memT he
    exact List.mem_toFinset.mpr (((mem_complete w _).mp (sub inS)).2 e rep rfl)
  refine ⟨S,sub,sz,?_⟩
  intro p q split
  have bound:=suffix_budget (T:=T) (fun e h=>(memT h).1) split long
  rw [hit,credits_eq,Finset.inter_eq_left.mpr keep,cardT] at bound
  exact bound

private theorem windows_prefix (u r : Block) : ∃q, windows (u++r)=windows u++q := by
  induction u with
  | nil => exact ⟨windows r,rfl⟩
  | cons a u ih =>
    by_cases enough : 6≤u.length
    · obtain ⟨q,hq⟩:=ih
      have room : 6≤u.length+r.length := by omega
      exact ⟨q,by simp [windows,enough,room,hq,List.take_append_of_le_length enough]⟩
    · exact ⟨windows ((a::u)++r),by rw [show windows (a::u)=[] by simp [windows,enough]];rfl⟩

/-- A computable bound on the number of additional letters, using every
permutation observed so far, even when the final 91 classes are not known. -/
theorem extension_bound (u r : Block) (long : 6≤u.length)
    (hit : (visited (u++r)).card=720) (many : 91≤(complete (u++r)).card) :
    1357≤ (visited u).card+((windows u).toFinset.filter fun e=>e.Nodup).card+r.length := by
  obtain ⟨q,split⟩:=windows_prefix u r
  have len:=congrArg List.length split
  simp only [windows_length,List.length_append] at len
  have qlen : q.length=r.length:=by omega
  obtain ⟨S,_,_,bound⟩:=candidate_cut (w:=u++r) (by simp; omega) hit many
  have use:=bound (windows u) q split
  rw [List.take_append_of_le_length long,←visited_word,qlen] at use
  have le : credits (CoreAssembly.mandatory S).toFinset (windows u) ⊆
      ((windows u).toFinset.filter fun e=>e.Nodup) := by
    rw [credits_eq]
    intro e he
    obtain ⟨hm,hw⟩:=Finset.mem_inter.mp he
    obtain ⟨rep,_⟩:=Multiset.mem_filter.mp (Multiset.mem_toFinset.mp hm)
    exact Finset.mem_filter.mpr ⟨hw,((mem_reps e).mp rep).2⟩
  exact use.trans (Nat.add_le_add_right (Nat.add_le_add_left (Finset.card_le_card le) _) _)

def recordPrefix := (RotationCoreControls.coreTruncated 629).take 1469

set_option maxRecDepth 10000 in
theorem prefix_data : recordPrefix.length=1469 ∧ (visited recordPrefix).card=716 ∧
    ((windows recordPrefix).toFinset.filter fun e=>e.Nodup).card=608 := by native_decide

/-- Every length-1501 continuation of this 1469-letter prefix fails. -/
theorem exclude_record_prefix (suffix : Block) (size : (recordPrefix++suffix).length≤1501)
    (all : (visited (recordPrefix++suffix)).card=720) :
    (complete (recordPrefix++suffix)).card≤90 := by
  obtain ⟨len,vis,perms⟩:=prefix_data
  by_contra! many
  have cost:=extension_bound recordPrefix suffix (by omega) all (by omega)
  simp only [List.length_append] at size
  omega

/-- Whole-word cardinality cuts for the compact seven-symbol circuit. Each
visited class starts a stretch, and each complete class has seven windows. -/
theorem circuit_budget {w : Block} (len : 6 ≤ w.length)
    (all : (visited w).card = 720) (k : Nat) (many : k ≤ (complete w).card) :
    720 ≤ (LapSkeleton.starts w).length ∧ 7*k ≤ (good w).length ∧
    LapSkeleton.dirty w + 720 + 7*k + 5 ≤ w.length := by
  have sub : visited w ⊆ (LapSkeleton.starts w).toFinset := by
    intro c hc
    exact List.mem_toFinset.mpr (LapSkeleton.starts_hit len hc)
  have starts := (Finset.card_le_card sub).trans (List.toFinset_card_le _)
  have windows := LapSkeleton.completed_floor w
  have account := LapSkeleton.accounting len
  omega

#print axioms circuit_budget
#print axioms candidate_cut
#print axioms exclude_record_prefix
end ExactWordFlow.PrefixCharge

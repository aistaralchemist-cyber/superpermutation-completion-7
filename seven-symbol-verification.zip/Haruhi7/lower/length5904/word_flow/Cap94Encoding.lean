import Cap94LookCore

namespace ExactWordFlow.Cap94Lookup
open SevenWordWindows RotationCore NearRootMoves

private theorem entries : ∀j : Fin 7,∀c∈allClasses,
    known c=true ∧ shift j.val c∈allClasses ∧ bit j.val c=2^code (shift j.val c) ∧
    shift ((7-j.val)%7) (shift j.val c)=c := by native_decide

theorem board_of_known {c : Block} (good : known c=true) : c∈allClasses := by
  have eq : board[code c]? = some c := eq_of_beq good
  have mem : c∈board := Array.mem_of_getElem? eq
  have lst : c∈boardList := by simpa only [board,List.mem_toArray] using mem
  simpa [boardList] using lst

private theorem code_inj {a b : Block} (ha : a∈allClasses) (hb : b∈allClasses)
    (eq : code a=code b) : a=b := by
  have A : board[code a]?=some a:=eq_of_beq ((entries 0 a ha).1)
  have B : board[code b]?=some b:=eq_of_beq ((entries 0 b hb).1)
  rw [eq,B] at A
  exact (Option.some.inj A).symm

private theorem bit_spec (R : Finset Block) (j : Fin 7) (boardR : R⊆allClasses) (i : Nat) :
    (bits j.val R).testBit i=true ↔ ∃c∈R,code (shift j.val c)=i := by
  induction R using Finset.induction_on with
  | empty => simp [bits]
  | @insert a s fresh ih =>
    have ha:=boardR (Finset.mem_insert_self a s)
    have sub : s⊆allClasses:=Finset.subset_insert .. |>.trans boardR
    have val:= (entries j a ha).2.2.1
    simp only [bits,Finset.fold_insert fresh]
    change (bit j.val a ||| bits j.val s).testBit i=true ↔ _
    rw [Nat.testBit_or,val,Nat.testBit_two_pow,Bool.or_eq_true,decide_eq_true_eq,ih sub]
    simp

theorem eq_shift {R T : Finset Block} (rg : R⊆allClasses) (tg : T⊆allClasses)
    (j : Fin 7) (same : bits 0 R=bits j.val T) : R=T.image (shift j.val) := by
  ext c
  constructor
  · intro hc
    have h:=(bit_spec R 0 rg (code c)).2 ⟨c,hc,rfl⟩
    change (bits 0 R).testBit (code c)=true at h
    rw [same] at h
    obtain ⟨x,hx,eq⟩:=(bit_spec T j tg _).1 h
    exact Finset.mem_image.mpr ⟨x,hx,code_inj (entries j _ (tg hx)).2.1 (rg hc) eq⟩
  · intro hc
    obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hc
    have h:=(bit_spec T j tg (code (shift j.val x))).2 ⟨x,hx,rfl⟩
    rw [←same] at h
    obtain ⟨c,cR,eq⟩:=(bit_spec R 0 rg _).1 h
    change code c=code (shift j.val x) at eq
    rwa [←code_inj (rg cR) (entries j _ (tg hx)).2.1 eq]

private theorem fold_image (ops : List (Fin 8)) (R : Finset Block) :
    applyMoves ops R=R.image (fun c=>ops.foldl (fun z i=>move i z) c) := by
  induction ops generalizing R with
  | nil => simp [applyMoves]
  | cons i ops ih =>
    change applyMoves ops (R.image (move i))=_
    rw [ih,Finset.image_image]
    rfl

theorem unshift {R T : Finset Block} (tg : T⊆allClasses) (j : Fin 7) (eq : R=T.image (shift j.val)) :
    applyMoves (List.replicate ((7-j.val)%7) 7) R=T := by
  rw [eq,fold_image,Finset.image_image]
  calc
    _=T.image id := by
      apply Finset.image_congr
      intro c h
      exact (entries j c (tg h)).2.2.2
    _=T := Finset.image_id

#print axioms eq_shift
#print axioms unshift
end ExactWordFlow.Cap94Lookup

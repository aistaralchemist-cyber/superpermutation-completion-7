import EndTrim94
import OrientedFormula
import WheelLRAT

namespace ExactWordFlow.EndTrim94
open SevenWordWindows ExtremeWheelCut RotationCore OrientedCNF WheelLRAT SeedWheelCut

private def fs := [cnf (visited path)]
private def cs := wheelCertificates% fs

/-- This actual 250-class path resists both six-edge end trims, yet the old
oriented cover obstruction excludes every possible set of 94 ordinary wheels. -/
theorem no_cover {W : Finset (Finset Block)} (legal : W⊆allRows) (size : W.card≤94) :
    ¬ClosedCover (visited path) allClasses W := by
  apply OrientedCNF.no_cover legal
  · rw [board,profile.2.1]; omega
  · exact batch_sound (fs:=fs) (cs:=cs) (by native_decide) _ (by simp [fs])

#print axioms no_cover
end ExactWordFlow.EndTrim94

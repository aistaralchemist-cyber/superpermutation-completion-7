import DisjointBaseWheels

namespace ExactWordFlow.WheelBaseExits
open SevenWordWindows RotationCore WheelFreeBoundary ExtremeWheelCut

private theorem degrees : ∀c∈allClasses,(allRows.filter fun R=>c∈R).card=7 := by native_decide

private theorem incidences (S : Finset Row) (U : Row) :
    ∑R∈S,(R∩U).card = ∑c∈U,(S.filter fun R=>c∈R).card := by
  classical
  calc
    _=∑R∈S,∑c∈U,if c∈R then 1 else 0:=by
      apply Finset.sum_congr rfl
      intro R _
      rw [←Finset.sum_filter]
      simp [Finset.filter_mem_eq_inter,Finset.inter_comm]
    _=∑c∈U,∑R∈S,if c∈R then 1 else 0:=Finset.sum_comm
    _= _ := by
      apply Finset.sum_congr rfl
      intro c _
      rw [←Finset.sum_filter]
      simp

/-- A common refinement for a family of residual wheels. Each one has at
most one shared tag; which tag is shared can vary between wheels. -/
theorem at_most_80 {b : Block} (free : WheelFree b) (done : (complete b).card=92)
    (S : Finset Row) (each : ∀R∈S,isolated b R) (legal : S⊆allRows) (H : Row)
    (one : ∀R∈S,(R∩H).card≤1)
    (apart : ∀R∈S,∀Q∈S,R≠Q → Disjoint (R\H) (Q\H)) : S.card≤80 := by
  classical
  let C:=complete b
  let P:=C\H
  let U:=C∩H
  have split : P.card+U.card=92 := (Finset.card_sdiff_add_card_inter C H).trans done
  have boardC : C⊆allClasses := (complete_subset b).trans (visited_subset b)
  have sumLow : 2*S.card≤∑R∈S,(R∩C).card := by
    have lo:=Finset.sum_le_sum (fun R (hr : R∈S)=>two_per_wheel free (each R hr))
    simpa [Nat.mul_comm] using lo
  have parts : (∑R∈S,(R∩C).card)=(∑R∈S,(R∩P).card)+(∑R∈S,(R∩U).card) := by
    rw [←Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro R _
    have a : (R∩C)\H=R∩P := by ext; simp [P]; tauto
    have q : (R∩C)∩H=R∩U := Finset.inter_assoc ..
    rw [←a,←q]
    exact (Finset.card_sdiff_add_card_inter (R∩C) H).symm
  have sep : ∀R∈S,∀Q∈S,R≠Q → Disjoint (R∩P) (Q∩P) := by
    intro R hr Q hq ne
    apply (apart R hr Q hq ne).mono <;> intro c h <;>
      exact Finset.mem_sdiff.mpr ⟨(Finset.mem_inter.mp h).1,(Finset.mem_sdiff.mp (Finset.mem_inter.mp h).2).2⟩
  have capP : (∑R∈S,(R∩P).card)≤P.card := by
    rw [←Finset.card_biUnion sep]
    exact Finset.card_le_card (Finset.biUnion_subset.mpr fun _ _=>Finset.inter_subset_right)
  have capU : (∑R∈S,(R∩U).card)≤S.card := by
    have per (R : Row) (hr : R∈S) : (R∩U).card≤1 :=
      (Finset.card_le_card (show R∩U⊆R∩H from fun _ h=>Finset.mem_inter.mpr ⟨(Finset.mem_inter.mp h).1,(Finset.mem_inter.mp (Finset.mem_inter.mp h).2).2⟩)).trans (one R hr)
    simpa using Finset.sum_le_sum per
  have cap7 : (∑R∈S,(R∩U).card)≤7*U.card := by
    rw [incidences]
    have per (c : Block) (hc : c∈U) : (S.filter fun R=>c∈R).card≤7 :=
      (Finset.card_le_card (Finset.filter_subset_filter _ legal)).trans
        (degrees c (boardC (Finset.mem_inter.mp hc).1)).le
    simpa [Nat.mul_comm] using Finset.sum_le_sum per
  omega

#print axioms at_most_80
end ExactWordFlow.WheelBaseExits

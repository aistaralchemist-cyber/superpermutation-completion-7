import FrontWord
import CompactPadding
import CompactFrontLimits
import CompactBackend
import CompactCertificate
import CompactRows

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows RotationCore
open CoreCandidateBanks (rowWires)
open SortedCoreRecords (wordRows)
open CoreRecordBits (digits)
open FrontRawBudget (cleanSignals winSignals)

attribute [local irreducible] layout

/-- Realize any bank that supplies the required sorted records and counts. -/
theorem assignment_of_backend {w : Block} (len : w.length=1501)
    (hit : (visited w).card=720) (many : 91≤(complete w).card)
    {f : BenesRouting.Bank} (switches : BackendWitness w f) :
    ∃ v, admits (sourceTest (wordSource w f) v) 0 (goalTape true).body.toList ∧
      (certFormula (goalTape true)).eval v=true := by
  let src := wordSource w f
  obtain ⟨v,events,asserts⟩ := candidate_assignment (src:=src) true
  have parts := layout_parts events
  have cols := input_admits parts
  have unit : v 0=true := source_unit cols
  have law := source_models src v
  have traces := records_gives law unit len (column_values cols)
  have front := apply_phase front_stage (parts layout.front.toPiece (by
    apply List.mem_cons_of_mem
    exact List.mem_cons_self)) traces
  obtain ⟨rows,cleans,wins⟩ := front
  have data : List.Forall₂ (ArrayRel (fun x b=>Rep v b x)) layout.front.out.1.toList
      ((wordRows digits w).map rowWires) := rows.imp fun _ _ h=>List.Forall₂.flip h
  have packed := padded_bank unit len data
  have ch : SignalList v layout.front.out.2.1.toList (cleanSignals w) := by
    unfold BitsRep at cleans
    rw [List.toList_toArray] at cleans
    exact List.Forall₂.flip cleans
  have wh : SignalList v layout.front.out.2.2.toList (winSignals w) := by
    unfold BitsRep at wins
    rw [List.toList_toArray] at wins
    exact List.Forall₂.flip wins
  have cuts := front_caps law unit parts len hit many ch wh
  obtain ⟨order,visit,completed⟩ := backend_truth switches v unit parts packed.1
  exact ⟨v,events,asserts.mpr (layout_claims (input_claims len cols) cuts order visit completed)⟩

/-- A single setting of the named switches and a single valuation realize the
source word and satisfy the strengthened formula, including every assertion. -/
theorem counterexample_assignment {w : Block} (len : w.length=1501)
    (hit : (visited w).card=720) (many : 91≤(complete w).card) :
    ∃ f v, admits (sourceTest (wordSource w f) v) 0 (goalTape true).body.toList ∧
      (certFormula (goalTape true)).eval v=true := by
  obtain ⟨f,switches,_⟩ := backend_witness len hit many
  exact ⟨f,assignment_of_backend len hit many switches⟩

theorem counterexample_models {w : Block} (len : w.length=1501) (hit : (visited w).card=720)
    (many : 91≤(complete w).card) : ∃ v,(certFormula (goalTape true)).eval v=true := by
  obtain ⟨_,v,_,yes⟩ := counterexample_assignment len hit many
  exact ⟨v,yes⟩

/-- The same valuation realizes the real word and satisfies every signed DIMACS
clause, in the numbering used by the output file. -/
theorem counterexample_all_rows {w : Block} (len : w.length=1501)
    (hit : (visited w).card=720) (many : 91≤(complete w).card) :
    ∃ f v, admits (sourceTest (wordSource w f) v) 0 (goalTape true).body.toList ∧
      ∀r∈signedRows 0 (goalTape true).body.toList,r.any (wire v)=true := by
  obtain ⟨f,v,events,yes⟩ := counterexample_assignment len hit many
  exact ⟨f,v,events,(signed_rows_iff (goal_scope true) v).mp yes⟩

theorem shorter_counterexample_models {w : Block} (len : w.length≤1501)
    (hit : (visited w).card=720) (many : 91≤(complete w).card) :
    ∃ z : Block, z.length=1501 ∧ visited z=visited w ∧ complete z=complete w ∧
      ∃ f v, admits (sourceTest (wordSource z f) v) 0 (goalTape true).body.toList ∧
        ∀r∈signedRows 0 (goalTape true).body.toList,r.any (wire v)=true := by
  have need := LapSkeleton.completed_floor w
  have room : (good w).length≤w.length-6 := by
    rw [←windows_length]
    exact List.length_filter_le ..
  obtain ⟨z,n,hv,hc⟩ := ExactBoundary.pad (by omega : 6≤w.length) len
  exact ⟨z,n,hv,hc,counterexample_all_rows n (hv ▸ hit) (hc ▸ many)⟩

theorem optimum_of_full_unsat (refute : (certFormula (goalTape true)).Unsat) :
    SuperpermBridge.HR.Ssuper 7=5905 := by
  apply CoreDecision1501.optimum_of_refutation (model:=∃v,(certFormula (goalTape true)).eval v=true)
  · intro w len occ
    obtain ⟨hit,count⟩ := (CoreDecision1501.occurrenceCover_iff w 91).mp occ
    exact counterexample_models len hit count
  · rintro ⟨v,yes⟩
    exact Bool.noConfusion (yes.symm.trans (refute v))

/-- The remaining premise is an actual successful check against the entire fixed formula. -/
theorem bounds_of_full_lrat {proof : String}
    (ok : WheelLRAT.batch [checkerFormula (goalTape true)] [proof]=true) :
    Target107.ceiling 1501 90 ∧ Target107.ceiling 1620 107 ∧ SuperpermBridge.HR.Ssuper 7=5905 := by
  have opt := optimum_of_full_unsat (checked_unsat _ (scope_checked (goal_scope true)).1 ok)
  exact ⟨EqualityComponent91.ceiling_equivalence.mp (Target107.goal_iff_minimum.mpr opt),Target107.goal_iff_minimum.mpr opt,opt⟩

theorem optimum_of_checked_actions (proof : Array Std.Tactic.BVDecide.LRAT.IntAction)
    (ok : Std.Tactic.BVDecide.LRAT.check proof (checkerFormula (goalTape true))=true) :
    SuperpermBridge.HR.Ssuper 7=5905 := by
  apply optimum_of_full_unsat
  rw [←checkerFormula_eq _ (scope_checked (goal_scope true)).1]
  exact Std.Tactic.BVDecide.LRAT.check_sound _ _ ok

#print axioms counterexample_all_rows
#print axioms counterexample_assignment
#print axioms bounds_of_full_lrat
end ExactWordFlow.CompactWordCircuit

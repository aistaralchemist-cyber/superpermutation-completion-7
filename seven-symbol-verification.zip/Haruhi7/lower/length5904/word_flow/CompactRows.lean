import CompactCertificate

namespace ExactWordFlow.CompactWordCircuit
open Std.Sat

private theorem local_rows_nonzero (e : Event) (out : W) (ho : out≠0)
    (nz : ∀x∈args e,x≠0) : ∀r∈localClauses out e,∀x∈r,x≠0 := by
  cases e with
  | fresh s => simp [localClauses]
  | assertion xs => simpa [localClauses,args] using nz
  | gateOr xs =>
    intro r hr
    rcases List.mem_cons.mp hr with rfl | h
    · exact List.forall_mem_cons.mpr ⟨neg_ne_zero.mpr ho,nz⟩
    · obtain ⟨y,hy,rfl⟩:=List.mem_map.mp h
      simp [ho,neg_ne_zero.mpr (nz y hy)]
  | gateMux c a b =>
    have hc:=nz c (by simp [args])
    have ha:=nz a (by simp [args])
    have hb:=nz b (by simp [args])
    simp [localClauses,ho,hc,ha,hb]

theorem signed_nonzero (n : Nat) (es : List Event) (nz : ∀e∈es,∀x∈args e,x≠0) :
    ∀r∈signedRows n es, ∀x∈r,x≠0 := by
  induction es generalizing n with
  | nil => simp [signedRows]
  | cons e es ih =>
    rw [signedRows,List.forall_mem_append]
    exact ⟨local_rows_nonzero e _ (Int.ofNat_ne_zero.mpr (Nat.succ_ne_zero _)) (nz e List.mem_cons_self),
      ih _ (fun e he=>nz e (List.mem_cons_of_mem _ he))⟩

private theorem eval_signed_clause {xs : List W} (nz : ∀x∈xs,x≠0) (v : Nat → Bool) :
    (CNF.Clause.ofLiterals (xs.map wireLit)).eval v = xs.any (wire v) := by
  simp only [CNF.Clause.eval,CNF.Clause.literals_ofLiterals,List.any_map]
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    have head := evaluated_lit (nz x List.mem_cons_self) v
    have tail := ih (fun y hy=>nz y (List.mem_cons_of_mem _ hy))
    exact congrArg₂ Bool.or head tail

/-- Direct semantics of the signed, one-based DIMACS data, clause for clause. -/
theorem signed_rows_iff {t : Tape} (scope : checkScope 0 t.body.toList=true) (v : Nat → Bool) :
    (certFormula t).eval v=true ↔ ∀r∈signedRows 0 t.body.toList,r.any (wire v)=true := by
  have nz := (scope_checked scope).1
  have checked := signed_nonzero 0 _ nz
  rw [CNF.eval,formula_rows t nz,Array.all_eq_true_iff_forall_mem]
  constructor
  · intro h r hr
    rw [←eval_signed_clause (checked _ hr)]
    exact h _ (List.mem_toArray.mpr (List.mem_map.mpr ⟨r,hr,rfl⟩))
  · intro h c hc
    obtain ⟨r,hr,rfl⟩:=List.mem_map.mp (List.mem_toArray.mp hc)
    rw [eval_signed_clause (checked _ hr),h r hr]

/-- This takes precisely the parsed action array as consumed by the command-line
checker, irrespective of the serialization of that array. -/
theorem checked_rows {t : Tape} (scope : checkScope 0 t.body.toList=true)
    (proof : Array Std.Tactic.BVDecide.LRAT.IntAction)
    (ok : Std.Tactic.BVDecide.LRAT.check proof (checkerFormula t)=true) :
    ¬∃v, ∀r∈signedRows 0 t.body.toList,r.any (wire v)=true := by
  rintro ⟨v,h⟩
  have sat := (signed_rows_iff scope v).mpr h
  have no := Std.Tactic.BVDecide.LRAT.check_sound _ _ ok
  rw [checkerFormula_eq _ (scope_checked scope).1] at no
  exact Bool.noConfusion (sat.symm.trans (no v))

#print axioms signed_rows_iff
end ExactWordFlow.CompactWordCircuit

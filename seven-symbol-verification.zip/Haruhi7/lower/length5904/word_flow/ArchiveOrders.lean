import GenusFamily
import CycleCutDual

namespace ExactWordFlow.ArchiveOrders
open SevenWordWindows

structure Table where
  goal : Nat
  groups : Nat
  state : Array Block
  row : Array Int
  col : Array Int
  label : Array Nat
deriving Inhabited

private def tokens (s : String) := (s.splitOn " ").toArray
private def parse (line : String) : Table :=
  match line.splitOn "\t" with
  | [_,goal,groups,states,rows,cols,labels] =>
    ⟨goal.toNat!,groups.toNat!,(tokens states).map (fun s=>s.toList.map fun c=>
      (⟨(c.toNat-48)%7,Nat.mod_lt _ (by decide)⟩ : Fin 7)),
      (tokens rows).map String.toInt!, (tokens cols).map String.toInt!,
      (tokens labels).map String.toNat!⟩
  | _ => default

private def data := (((include_str "support-prices.tsv").trimAscii.toString).splitOn "\n").toArray.map parse
abbrev Index (t : Table) := Fin (t.state.size+1)
def dummy (t : Table) : Index t := Fin.last _
def label (t : Table) (i : Index t) := t.label[i.val]?.getD t.groups
def row (t : Table) (i : Index t) := t.row[i.val]?.getD 0
def col (t : Table) (i : Index t) := t.col[i.val]?.getD 0
def leaves (t : Table) (i j : Index t) : Bool := decide (label t i < t.groups ∧ label t j ≠ label t i)

/-- Price zero at the free cut. Between distinct correction states the price
is the shortest literal shift minus two. A shift of one would force x=y. -/
def price (t : Table) (i j : Index t) : Nat :=
  if i=dummy t ∨ j=dummy t then 0
  else let x:=t.state[i.val]!
       let y:=(t.state[j.val]!).rotate 1
       ((List.range 5).find? (fun s=> x.drop (s+2) == y.take (5-s))).getD 5

def Valid (t : Table) : Prop :=
  (∀i j : Index t,i≠j → row t i+col t j+(if leaves t i j then (1:Int) else 0)≤price t i j) ∧
  (∑i : Index t,row t i)+(∑i : Index t,col t i)+(t.groups:Int)=t.goal ∧
  label t (dummy t)=t.groups ∧
  (∀g∈Finset.range t.groups,∃i : Index t,label t i=g)

private instance (t : Table) : Decidable (Valid t) := by unfold Valid; infer_instance

/-- Prices can be summed along any single orbit through the dummy, which
allows every choice of the two ends of the open order. -/
theorem lower_of_valid (t : Table) (cert : Valid t) (f : Equiv.Perm (Index t))
    (loopless : ∀i, f i≠i) (reach : ∀i,∃n:Nat,(f^[n]) i=dummy t) :
    t.goal ≤ ∑i : Index t,price t i (f i) := by
  classical
  let A:=Finset.univ.filter fun i=>leaves t i (f i)
  have sub : Finset.range t.groups ⊆ A.image (label t) := by
    intro g hg
    by_contra absent
    obtain ⟨x,hx⟩:=cert.2.2.2 g hg
    have step (i : Index t) (eq : label t i=g) : label t (f i)=g := by
      by_contra diff
      have mem : i∈A := Finset.mem_filter.mpr ⟨Finset.mem_univ _,by
        simp [leaves,eq, Finset.mem_range.mp hg,diff]⟩
      exact absent (Finset.mem_image.mpr ⟨i,mem,eq⟩)
    have stays (n : Nat) : label t ((f^[n]) x)=g := by
      induction n with
      | zero => exact hx
      | succ n prev => rw [Function.iterate_succ_apply']; exact step _ prev
    obtain ⟨n,eq⟩:=reach x
    have bad:=stays n
    rw [eq,cert.2.2.1] at bad
    exact (Nat.ne_of_lt (Finset.mem_range.mp hg)) bad.symm
  have enough : t.groups ≤ A.card := by
    simpa using (Finset.card_le_card sub).trans (Finset.card_image_le (s:=A) (f:=label t))
  have inequality:=Finset.sum_le_sum (s:=Finset.univ) fun i _=>cert.1 i (f i) (loopless i).symm
  rw [Finset.sum_add_distrib, Finset.sum_add_distrib,Equiv.sum_comp f (col t)] at inequality
  have n : (∑i : Index t, if leaves t i (f i) then (1:Int) else 0)=(A.card:Int) := by
    rw [←Finset.sum_filter]
    simp only [A,Finset.sum_const,nsmul_eq_mul,mul_one]
  rw [n] at inequality
  have values := cert.2.1
  exact_mod_cast (show (t.goal:Int)≤∑i : Index t,(price t i (f i):Int) by omega)

def archival (i : Fin 98) : Table := data[i.val]!

private theorem table_checks : data.size=98 ∧ ∀i : Fin 98, Valid (archival i) ∧
    ((archival i).state.toList.map classKey).Nodup ∧
    (∀x∈(archival i).state.toList,x.length=7 ∧ x.Nodup) ∧
    5045 + (archival i).state.size + (archival i).goal + 6*((720-(archival i).state.size)/5)=5905 ∧
    (archival i).state.size + 5*((720-(archival i).state.size)/5)=720 := by native_decide

/-- A real correction cycle need not stay intact. Every additional cycle
can avoid one exit charge, and costs one additional unit in the length
formula. The same certificates therefore apply to arbitrary partitions. -/
theorem all_cycle_partitions (i : Fin 98) (f : Equiv.Perm (Index (archival i)))
    (loopless : ∀j,f j≠j) {q g L : Nat}
    (mass : (archival i).state.size+6*q=f.cycleFactorsFinset.card+q+719+2*g)
    (length : L=5764+f.cycleFactorsFinset.card+q+(∑j : Index (archival i),price (archival i) j (f j))+2*g) :
    5905≤L := by
  let t := archival i
  obtain ⟨valid,_,_,num,den⟩:=table_checks.2 i
  have cert : Valid t := valid
  have covers (j : Nat) (hj : j<t.groups) : ∃x : Index t,label t x=j :=
    cert.2.2.2 j (Finset.mem_range.mpr hj)
  have inequality (x y : Index t) (different : x≠y) :
      row t x+col t y+(if label t x<t.groups ∧ label t y≠label t x then (1:Int) else 0) ≤ price t x y := by
    simpa only [leaves,decide_eq_true_eq] using cert.1 x y different
  have total:= CycleCutDual.cost_and_cycles f loopless (label t) t.groups (dummy t)
    cert.2.2.1.ge covers (row t) (col t) (price t) inequality
  rw [cert.2.1, ←Nat.cast_sum] at total
  have enough : t.goal+1 ≤ (∑j : Index t,price t j (f j))+f.cycleFactorsFinset.card := by exact_mod_cast total
  have pos : 0<f.cycleFactorsFinset.card := Finset.card_pos.mpr
    ⟨f.cycleOf (dummy t),Equiv.Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr
      (Equiv.Perm.mem_support.mpr (loopless _))⟩
  dsimp only [t] at enough
  omega

/-- Kernel-checked finite certificates on all 98 archived state sets, for
arbitrary open orders. The states use one alphabet normalization per word. -/
theorem all_orders (i : Fin 98) (f : Equiv.Perm (Index (archival i)))
    (loopless : ∀j,f j≠j) (reach : ∀j,∃n:Nat,(f^[n]) j=dummy (archival i)) :
    (archival i).goal ≤ ∑j : Index (archival i),price (archival i) j (f j) :=
  lower_of_valid _ ((table_checks.2 i).1) f loopless reach

/-- One exceptional cycle on the archival states, plus any number of ordinary
six-cycles. The genus and length equations allow wheel placements of any genus. -/
theorem all_completions (i : Fin 98) (f : Equiv.Perm (Index (archival i)))
    (loopless : ∀j,f j≠j) (reach : ∀j,∃n:Nat,(f^[n]) j=dummy (archival i))
    {q g L : Nat}
    (mass : (archival i).state.size + 6*q=1+q+719+2*g)
    (length : L=5765+q+(∑j : Index (archival i),price (archival i) j (f j))+2*g) :
    5905≤L := by
  have best:=all_orders i f loopless reach
  obtain ⟨_,_,_,num,den⟩:=table_checks.2 i
  omega

#print axioms lower_of_valid
#print axioms all_cycle_partitions
#print axioms all_orders
#print axioms all_completions
end ExactWordFlow.ArchiveOrders

import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Finset.Max
import Mathlib.Tactic

namespace ExactWordFlow.RotationSplice
variable {X : Type*} [Fintype X] [DecidableEq X] {n d : Nat}

/-- Actual consecutive slots occupied by a state and its ordinary successor. -/
def ordinary (R : Equiv.Perm X) (p : X → Fin n) : Finset X :=
  Finset.univ.filter fun x => (p (R x)).val=(p x).val+1

/-- Representatives can be chosen jointly to maximize the number of paid
cost-one steps in a fixed word. An admissible slot is an occurrence of that state. -/
theorem exists_optimal (R : Equiv.Perm X) (occ : X → Fin n → Prop)
    (initial : ∃p : X → Fin n,∀x,occ x (p x)) :
    ∃p : X → Fin n,(∀x,occ x (p x)) ∧ ∀q : X → Fin n,(∀x,occ x (q x)) → (ordinary R q).card≤(ordinary R p).card := by
  classical
  let options : Finset (X → Fin n) := Finset.univ.filter fun p => ∀x,occ x (p x)
  obtain ⟨p,hp⟩:=initial
  have mem : p∈options := by simpa [options] using hp
  obtain ⟨q,hq,best⟩:=Finset.exists_max_image options (fun f=>(ordinary R f).card) ⟨p,mem⟩
  refine ⟨q,(Finset.mem_filter.mp hq).2,fun f hf=>best _ ?_⟩
  simpa [options] using hf

/-- If both ends of an actual simple rotation run have been selected, so
must each intermediate slot, for any selection maximizing ordinary adjacencies. -/
theorem interpolate (R : Equiv.Perm X) (occ : X → Fin n → Prop)
    (p : X → Fin n) (valid : ∀x,occ x (p x))
    (best : ∀f,(∀x,occ x (f x)) → (ordinary R f).card≤(ordinary R p).card)
    (v : Fin (d+1) ↪ X) (slot : Fin (d+1) → Fin n)
    (available : ∀j,occ (v j) (slot j))
    (rotate : ∀j : Fin d, R (v j.castSucc)=v j.succ)
    (consecutive : ∀j : Fin d,(slot j.succ).val=(slot j.castSucc).val+1)
    (left : p (v 0)=slot 0) (right : p (v (Fin.last d))=slot (Fin.last d)) :
    ∀j,p (v j)=slot j := by
  classical
  let f (x : X) := if found : ∃j,v j=x then slot found.choose else p x
  have inside (j) : f (v j)=slot j := by
    have ex : ∃i,v i=v j := ⟨j,rfl⟩
    simp only [f,dite_eq_left ex]
    rw [v.injective ex.choose_spec]
  have outside (x) (notin : ¬∃j,v j=x) : f x=p x := by simp [f,notin]
  have ok (x) : occ x (f x) := by
    by_cases ex : ∃j,v j=x
    · obtain ⟨j,rfl⟩:=ex; rw [inside]; exact available _
    · rw [outside _ ex]; exact valid _
  have gained (j : Fin d) : v j.castSucc∈ordinary R f := by
    simp [ordinary,rotate j,inside,consecutive j]
  have preserved : ordinary R p ⊆ ordinary R f := by
    intro x hx
    by_cases affected : ∃j : Fin d,v j.castSucc=x
    · obtain ⟨j,rfl⟩:=affected; exact gained j
    have eq₁ : f x=p x := by
      by_cases hit : ∃j,v j=x
      · obtain ⟨j,rfl⟩:=hit
        have endpt : j=Fin.last d := by
          by_contra no
          let i : Fin d := ⟨j.val,by
            have ne : j.val≠d := fun same=>no (Fin.ext same)
            omega⟩
          exact affected ⟨i,congrArg v (Fin.ext rfl)⟩
        simpa only [endpt,inside] using right.symm
      · exact outside _ hit
    have eq₂ : f (R x)=p (R x) := by
      by_cases hit : ∃j,v j=R x
      · obtain ⟨j,eq⟩:=hit
        have start : j=0 := by
          by_contra no
          have nz : j.val≠0 := fun same=>no (Fin.ext same)
          let i : Fin d := ⟨j.val-1,by omega⟩
          have su : i.succ=j := Fin.ext (by dsimp [i]; omega)
          exact affected ⟨i,R.injective ((rotate i).trans (su ▸ eq))⟩
        rw [←eq,start,inside,left]
      · exact outside _ hit
    simpa only [ordinary,Finset.mem_filter,Finset.mem_univ,true_and,eq₁,eq₂] using hx
  have equal : ordinary R p=ordinary R f :=
    Finset.eq_of_subset_of_card_le preserved (best f ok)
  have paid (j : Fin d) : (p (v j.succ)).val=(p (v j.castSucc)).val+1 := by
    have mem:=gained j
    rw [←equal] at mem
    simpa [ordinary,rotate j] using mem
  intro j
  induction j using Fin.induction with
  | zero => exact left
  | succ j ih => exact Fin.ext (by rw [paid,consecutive,ih])

#print axioms exists_optimal
#print axioms interpolate
end ExactWordFlow.RotationSplice

import Mathlib.Data.List.Chain
namespace CutScope
variable {α : Type*}

def Follow (inside : α → Prop) (a b : α) := inside a → inside b

/-- If no directed arc leaves a set on a cycle, the entire cycle lies
on the same side as its first vertex. -/
theorem cycle_side (inside : α → Prop) (a : α) (xs : List α)
    (h : (a :: (xs ++ [a])).IsChain (Follow inside)) :
    ∀ x ∈ a::xs, inside x ↔ inside a := by
  let : IsTrans α (Follow inside) := ⟨fun _ _ _ h₁ h₂ h => h₂ (h₁ h)⟩
  have hp := List.isChain_iff_pairwise.mp h
  obtain ⟨head,tail⟩ := List.pairwise_cons.mp hp
  intro x hx
  rcases List.mem_cons.mp hx with rfl|hx
  · exact Iff.rfl
  · have last := (List.pairwise_append.mp tail).2.2 x hx a (by simp)
    exact ⟨last,head x (List.mem_append_left _ hx)⟩

/-- On two directed cycles covering the vertex set, any cut with no outgoing
arc is empty, full, or one entire cycle. No assumption about their lengths. -/
theorem only_empty_cuts (inside : α → Prop) (a b : α) (as bs : List α)
    (ha : (a::(as++[a])).IsChain (Follow inside))
    (hb : (b::(bs++[b])).IsChain (Follow inside))
    (cover : ∀ x, x ∈ a::as ∨ x ∈ b::bs) :
    (∀ x, ¬inside x) ∨ (∀ x, inside x) ∨ (∀ x, inside x ↔ x∈a::as) ∨
      (∀ x, inside x ↔ x∈b::bs) := by
  have A := cycle_side inside a as ha
  have B := cycle_side inside b bs hb
  by_cases ia : inside a <;> by_cases ib : inside b
  · exact Or.inr (Or.inl fun x => (cover x).elim (fun h => (A x h).2 ia) (fun h => (B x h).2 ib))
  · right; right; left
    intro x
    exact ⟨fun hx => (cover x).elim id (fun h => (ib ((B x h).1 hx)).elim),fun h => (A x h).2 ia⟩
  · right; right; right
    intro x
    exact ⟨fun hx => (cover x).elim (fun h => (ia ((A x h).1 hx)).elim) id,fun h => (B x h).2 ib⟩
  · left
    intro x hx
    exact (cover x).elim (fun h => ia ((A x h).1 hx)) (fun h => ib ((B x h).1 hx))

end CutScope
#print axioms CutScope.only_empty_cuts

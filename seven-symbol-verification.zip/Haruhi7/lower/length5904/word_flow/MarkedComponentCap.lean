import CompletionCurve
import MarkedDensity

namespace ExactWordFlow.MarkedComponentCap
open SevenWordWindows ResidualDensity ResidualDensity.Density66 DirectedEuler ResidualRoutes ResidualIncidence GlobalDensity66 RotationComponentCount
open scoped Classical
open private open_cap cyclic_cap closed_price chunksCap from GlobalDensity66
open private all_contacts from OverlapBudget

theorem component_prices
    {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858) :
    66*separateRank X s+6*(active X s).card+60*(large X s).card≤56*X.card+66 ∧
    (large X s=∅ → 258≤(part X (label X s)).card) := by
  classical
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  let C (q : Component X) := (contacts (support X s) (label X) q).card
  let Big (q) := q≠home ∧ 79≤K q
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q = X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have range (q : Component X) : K q≤858 := (Multiset.card_le_card (Multiset.filter_le ..)).trans budget
  have localPrice (q) (hq : q∈Q) :
      (q=home → (C q≤(min (cap (K q)) ((38*(K q+1)+66)/45)) ∧ (K q<258 → 6*(C q-1)≤5*K q+23))) ∧ (Big q → 66*C q≤56*K q) ∧
      (q≠home → ¬Big q → 6*(C q-1)≤5*K q) := by
    obtain ⟨v,_,vv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩ := component_route h.balance v
    rw [vv] at eq lv ep
    have len : es.length=K q := congrArg Multiset.card eq
    have wd (e : Block) (he : e∈es) := h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have incl : C q≤classCount a es := contacts_bound _ lv r eq
    refine ⟨fun _ => ?_,?_,?_⟩
    · obtain ⟨x,y,z⟩:=open_cap r wd
      rw [len] at x y z
      have a:=WeightedMarks.path_cap r wd
      have b:=WeightedMarks.short_gain r wd
      rw [len] at a b
      exact ⟨le_min (le_min (all_contacts ..) (le_min (incl.trans x) (le_min (incl.trans y) (incl.trans z))))
        (by omega), fun hq => by have := b hq; omega⟩
    · rintro ⟨away,big⟩
      obtain ⟨aa,bb⟩ := ep.2 away
      subst a; subst b
      have zz := cyclic_cap r wd (by omega)
      omega
    · intro away no
      obtain ⟨aa,bb⟩ := ep.2 away
      subst a; subst b
      have small : es.length<79 := by by_contra! no'; exact no ⟨away,by omega⟩
      have zz := closed_price r wd small
      omega
  let Act (q : Component X) := q≠home ∧ 6≤K q
  have scalar : ∀k : Fin 859, 66*(min (cap k.val) ((38*(k.val+1)+66)/45)-1)≤56*k.val+66 := by native_decide
  have unit (q) (hq : q∈Q) :
      66*(C q-1)+(if Act q then 6 else 0)+(if Big q then 60 else 0) ≤
      56*K q+(if q=home then 66 else 0) := by
    obtain ⟨op,bg,cl⟩:=localPrice q hq
    by_cases hr : q=home
    · have na : ¬Act q := fun e => e.1 hr
      have nb : ¬Big q := fun e => e.1 hr
      simp only [ite_eq_right na,ite_eq_right nb,ite_eq_left hr,Nat.add_zero]
      exact (Nat.mul_le_mul_left 66 (Nat.sub_le_sub_right (op hr).1 1)).trans (scalar ⟨K q,by have:=range q; omega⟩)
    · rw [ite_eq_right hr,Nat.add_zero]
      by_cases big : Big q
      · have a : Act q := ⟨hr,by have:=big.2; omega⟩
        have n:=bg big
        have l:=big.2
        rw [ite_eq_left a,ite_eq_left big]
        omega
      · have v:=cl hr big
        rw [ite_eq_right big,Nat.add_zero]
        by_cases a : Act q
        · rw [ite_eq_left a]
          have l:=a.2
          omega
        · rw [ite_eq_right a,Nat.add_zero]
          omega
  have cost:=Finset.sum_le_sum unit
  have actCard : (∑q∈Q,if Act q then 6 else 0)=6*(active X s).card := by
    rw [←Finset.sum_filter]; simp [Q,active,Act,K,home,Nat.mul_comm]
  have bigCard : (∑q∈Q,if Big q then 60 else 0)=60*(large X s).card := by
    rw [←Finset.sum_filter]; simp [Q,large,Big,K,home,Nat.mul_comm]
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_ite_eq',root,ite_true,actCard,bigCard,total] at cost
  refine ⟨cost,?_⟩
  intro noBig
  by_contra! shortRoot
  have smallCost (q) (hq : q∈Q) : 6*(C q-1)≤5*K q+(if q=home then 23 else 0) := by
    by_cases rootAt : q=home
    · subst q
      simpa using ((localPrice home hq).1 rfl).2 shortRoot
    · have small : ¬Big q := by
        intro yes
        have mem : q∈large X s := Finset.mem_filter.mpr ⟨hq,yes⟩
        rw [noBig] at mem
        exact Finset.notMem_empty _ mem
      simpa [rootAt] using (localPrice q hq).2.2 rootAt small
  have sum:=Finset.sum_le_sum smallCost
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_ite_eq',root,ite_true,total] at sum
  have rk : 719 ≤ separateRank X s:=rank719 (label X) h fun _ he=>on_edge he
  change 6*separateRank X s≤_ at sum
  omega


/-- A long closed component consumes sixty extra units in the 66-position
bound. Otherwise the open component needs 258 edges, leaving at most six
hundred edges for the other components. -/
private theorem count_of_prices {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858)
    (cost : 66*separateRank X s+6*(active X s).card+60*(large X s).card≤56*X.card+66)
    (rootLower : large X s=∅ → 258≤(part X (label X s)).card) : (occupied X s).card≤100 := by
  classical
  rw [occupied_active h]
  by_cases big : (large X s).Nonempty
  · have pos:=Finset.card_pos.mpr big
    have rk : 719 ≤ separateRank X s:=rank719 (label X) h fun _ he=>on_edge he
    omega
  let Q := (support X s).image (label X)
  let K (q : Component X) := (part X q).card
  let home := label X s
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q = X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have rootSize : 258≤K home := rootLower (Finset.not_nonempty_iff_eq_empty.mp big)
  have each (q) (hq : q∈Q.erase home) : (if q∈active X s then 6 else 0)≤K q := by
    split
    next yes => exact (Finset.mem_filter.mp yes).2.2
    next => omega
  have size:=Finset.sum_le_sum each
  have sub : active X s ⊆ Q.erase home := by
    intro q hq
    obtain ⟨m,a,_⟩:=Finset.mem_filter.mp hq
    exact Finset.mem_erase.mpr ⟨a,m⟩
  have eq : ((Q.erase home).filter fun q => q∈active X s)=active X s := by ext x; simp +contextual [Finset.mem_erase]; grind
  rw [←Finset.sum_filter,eq] at size
  simp at size
  have split := Finset.sum_erase_add (s:=Q) K root
  rw [total] at split
  omega




open RotationSpan CoreAssembly RotationCore SuperpermutationBounds
open private required_data from ResidualIncidence
open private add_to control_counts from CompletionCurve

theorem component_limit {X : Multiset Block} {s t : Block}
    (h : Feasible X s t) (budget : X.card≤858) : (occupied X s).card≤100 :=
  let ⟨price,rootLower⟩ := component_prices h budget
  count_of_prices h budget price rootLower

private theorem rooted100 {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) : ∃S⊆allClasses, S.card≤100 ∧
      (∀c∈allClasses, ∃u, full u ∧ tag u=c ∧ label (selected X S) u=label (selected X S) s) ∧
      (∀p∈representatives, classKey p∈S → label (selected X S) (src p)=label (selected X S) s) := by
  obtain ⟨S,sub,size,span⟩:=spanning h
  have count := component_limit h budget
  refine ⟨S,sub,size.trans count,?_,?_⟩
  · intro c hc
    obtain ⟨u,hu,clean,key⟩:=every_tag h hc
    exact ⟨u,clean,key,span u hu⟩
  · intro p hp inS
    have inBoard:=sub inS
    obtain ⟨u,hu,clean,key⟩:=every_tag h inBoard
    have tab : ∀p∈representatives,tag (src p)=classKey p := by native_decide
    have here:=tab p hp
    exact (join_same (required_data p hp).1 clean (here.trans key.symm) (here ▸ inS)).trans (span u hu)


/-- The 620-lap contraction of W-0021 attains the threshold at 1,565.
Removing its first letter retains all anchors and exactly 99 completed classes. -/
theorem reference620 :
    RotationCoreControls.summary (RotationCoreControls.coreWord 620)=(1565,720,100) ∧
    RotationCoreControls.summary (RotationCoreControls.coreTruncated 620)=(1564,720,99) := by
  native_decide

/-- The least length rises by exactly seven per completed class from one
hundred through all 720. The numerical length of a shortest superpermutation
is left symbolic. -/
theorem completion_curve (k : Nat) (lo : 100≤k) (hi : k≤720) :
    IsLeast (lengthsFor k) (SuperpermBridge.HR.Ssuper 7-7*(720-k)) := by
  have bound {v : Block} (long : 6≤v.length) (all : (visited v).card=720)
      (done : k≤(complete v).card) : SuperpermBridge.HR.Ssuper 7 ≤ v.length+7*(720-k) := by
    obtain ⟨w,hw,sz⟩ := expand_remaining long all
    have best := SuperpermBridge.ssuper_le_length hw
    omega
  constructor
  · obtain ⟨w,hw,sz⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
    by_cases small : w.length≤5904
    · obtain ⟨p,q,occ⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
      obtain ⟨X,cost,h⟩ := extract_at_ends w hw (by simp [occ]; omega)
      obtain ⟨S,legal,limit,hit,root⟩ := rooted100 h (by omega)
      obtain ⟨z,long,len,all,done⟩ := CoreAssembly.target h legal (limit.trans lo) hi hit root
      have min := bound long all done
      exact ⟨z,long,all,done,by omega⟩
    · have up := SuperpermBridge.ssuper_le_length SuperpermLowerBounds.LengthBudget.Word5905.covers
      rw [SuperpermLowerBounds.LengthBudget.Word5905.length_5905] at up
      obtain ⟨len,va,dc⟩ := control_counts reference620.1
      obtain ⟨z,long,seen,done,size⟩ := add_to lo hi (w:=RotationCoreControls.coreWord 620)
        (by omega) va dc.ge
      have min := bound long seen done
      exact ⟨z,long,seen,done,by omega⟩
  · rintro n ⟨v,long,all,done,rfl⟩
    have min := bound long all done
    omega

/-- The original full-word decision is exactly the 1,564/100 decision. -/
theorem exact_1564 :
    (∃w : Block, Covers w ∧ w.length≤5904) ↔
    ∃v : Block, 6≤v.length ∧ v.length≤1564 ∧ (visited v).card=720 ∧ 100≤(complete v).card := by
  constructor
  · rintro ⟨w,hw,small⟩
    obtain ⟨a,b,hword⟩:=hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
    obtain ⟨X,cost,h⟩:=extract_at_ends w hw (by simp [hword]; omega)
    obtain ⟨S,sub,num,hit,must⟩:=rooted100 h (by omega)
    obtain ⟨v,long,cap,all,done⟩:=CoreAssembly.target h sub num (by decide) hit must
    exact ⟨v,long,by omega,all,done⟩
  · rintro ⟨v,long,cap,all,done⟩
    obtain ⟨w,hw,sz⟩:=expand_remaining long all
    exact ⟨w,hw,by omega⟩

#print axioms component_limit
#print axioms exact_1564
#print axioms completion_curve
#print axioms reference620

end ExactWordFlow.MarkedComponentCap

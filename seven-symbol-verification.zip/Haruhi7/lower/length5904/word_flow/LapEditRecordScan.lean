import LapEditRecordData
import LapEditFocus
import LapEditCost

namespace ExactWordFlow.LapEditRecordScan
set_option maxHeartbeats 0 in
theorem checked : LapEditContexts.scan LapEditCost.rejects [] LapEditRecordData.tiles=true := by
  native_decide

#print axioms checked
end ExactWordFlow.LapEditRecordScan

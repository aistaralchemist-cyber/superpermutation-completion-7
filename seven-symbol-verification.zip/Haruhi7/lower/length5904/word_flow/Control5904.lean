import AlmostCover
import Windows5904

namespace SevenWordControl
open SevenWordWindows SevenAlmostCover.Record
/-- The 5,904-letter word missing exactly 0123456 passes all three aggregate
window bounds. One-time computation of the lists makes replay efficient. -/
theorem checks :
    (invalid truncated=859) ∧ (good truncated).length=5039 ∧
    (uniqueWords truncated).card=5039 ∧ (completeClasses truncated).card=653 := by
  let xs := good truncated
  let ys := visits truncated
  let zs := runEnds (labels truncated)
  change (invalid truncated=859) ∧ xs.length=5039 ∧
    (allPerms.filter (fun p => xs.count p=1)).card=5039 ∧
    (allClasses.filter (fun c => ys.count c=7 ∧ zs.count c=1)).card=653
  native_decide +revert
end SevenWordControl
#print axioms SevenWordControl.checks

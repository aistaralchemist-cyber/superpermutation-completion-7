import KeyWireOrder
import BenesArray
import PrefixCharge

namespace ExactWordFlow.CoreCandidateBanks
open SevenWordWindows RotationCore ResidualDensity SortedCoreRecords CoreRecordBits BenesRouting

def dummy : Row := ⟨Sum.inrₗ (List.replicate 6 0),∅⟩
def extra := List.replicate 552 dummy

def rowWires (r : Row) : Array Bool :=
  (encodeKey r.key ++ (List.finRange 7).map (fun a => decide (a∈r.mask))).toArray

def sourceRows (w : Block) := wordRows digits w ++ extra
def bankInput (w : Block) := ((sourceRows w).map rowWires).toArray

private theorem extra_pad : padding extra := by
  intro r hr
  have eq : r=dummy := (List.mem_replicate.mp hr).2
  subst r
  exact ⟨_,rfl⟩

private theorem source_length {w : Block} (len : w.length=1501) :
    (sourceRows w).length=2048 := by
  simp only [sourceRows,wordRows,extra,List.length_append,List.length_map,List.length_singleton,
    List.length_replicate,windows_length,len]

theorem source_encodable {w : Block} {r : Row} (mem : r∈sourceRows w) :
    encodable r.key := by
  rcases List.mem_append.mp mem with hw|he
  · exact rows_encodable hw
  · obtain rfl := (List.mem_replicate.mp he).2
    change ∀n∈List.replicate 6 0,n<8
    simp

private theorem clean_length : ∀u∈states,(tag u).tail.length=6 := by native_decide

theorem source_width {w : Block} {r : Row} (mem : r∈sourceRows w) :
    (encodeKey r.key).length=19 := by
  have width (u : Block) : (encodeKey (contextKey digits u)).length=19 := by
    by_cases h : full u
    · have eq := clean_length u (mem_states h)
      simp only [List.length_tail] at eq
      simp [contextKey,h,encodeKey,bits3,Sum.inlₗ,List.length_flatMap,eq]
    · simp [contextKey,h,encodeKey,bits3,Sum.inrₗ,digits,List.length_flatMap,Function.comp_def]
  rcases List.mem_append.mp mem with hw|he
  · rcases List.mem_append.mp hw with p|r
    · obtain ⟨p,_,rfl⟩ := List.mem_map.mp p
      exact width _
    · obtain rfl := List.mem_singleton.mp r
      exact width _
  · obtain rfl := (List.mem_replicate.mp he).2
    decide

theorem first19 {w : Block} {r : Row} (mem : r∈sourceRows w) :
    (rowWires r).toList.take 19 = encodeKey r.key := by
  have wid := source_width mem
  simp [rowWires,←wid]

private theorem ofFn_read {α : Type} (xs : List α) {n : Nat} (len : xs.length=n) :
    List.ofFn (fun j : Fin n => xs[j.val]'(by omega)) = xs := by
  subst n
  exact List.ofFn_getElem

set_option maxRecDepth 4096 in
/-- All 2047 nondecreasing adjacent comparisons and the two final flag counts
are true under a single bank assignment for the real 2048 padded *wire rows*. -/
theorem candidate_banks {w : Block} (len : w.length=1501)
    (hit : (visited w).card=720) (many : 91≤(complete w).card) :
    ∃ (f : Bank) (rs : List Row),
      (arrayRun f 11 1 (bankInput w)).toList = rs.map rowWires ∧
      rs.Perm (sourceRows w) ∧ rs.length=2048 ∧
      rs.Pairwise (fun a b => wireLE (encodeKey a.key) (encodeKey b.key)=true) ∧
      (flags rs).countP Prod.fst=720 ∧ 91≤(flags rs).countP Prod.snd ∧
      720≤(LapSkeleton.starts w).length ∧ 637≤(good w).length ∧
      LapSkeleton.dirty w+1357≤1496 := by
  let src := sourceRows w
  have size : src.length=2048 := source_length len
  let read (j : Fin 2048) := src[j.val]'(by omega)
  have member (j : Fin 2048) : read j ∈ sourceRows w := List.getElem_mem ..
  have sz : (bankInput w).size=2048 := by simpa [bankInput] using size
  have wire (j : Fin 2048) : (bankInput w)[j.val]! = rowWires (read j) := by
    rw [getElem!_pos _ _ (by rw [sz]; exact j.isLt)]
    simp [bankInput,read,src]
  obtain ⟨f,p,mono,outs,atIndex⟩ := sort_array (fun (r : Array Bool)=>r.toList.take 19) (bankInput w) sz
  let rs := List.ofFn (read ∘ p)
  have perm : rs.Perm src := by
    have h := p.ofFn_comp_perm read
    rwa [ofFn_read src size] at h
  have keymono (i j : Fin 2048) (le : i≤j) :
      encodeKey (read (p i)).key ≤ encodeKey (read (p j)).key := by
    have h := mono le
    simpa only [wire,first19 (member _)] using h
  have ord : ordered rs := by
    apply List.pairwise_ofFn.mpr
    intro i j lt
    exact (wireLE_keys (source_encodable (member _)) (source_encodable (member _))).mp
      ((wireLE_iff ..).mpr (keymono i j lt.le))
  have adj : rs.Pairwise (fun a b => wireLE (encodeKey a.key) (encodeKey b.key)=true) := by
    apply List.pairwise_ofFn.mpr
    intro i j lt
    exact (wireLE_iff ..).mpr (keymono i j lt.le)
  have total := sorted_flags (by omega : 6≤w.length) digits extra_pad perm ord
  have cuts := PrefixCharge.circuit_budget (by omega : 6≤w.length) hit 91 many
  have rsSize : rs.length=2048 := List.length_ofFn
  have yes : (flags rs).countP Prod.fst=720 := (congrArg Prod.fst total).trans hit
  have done : 91≤(flags rs).countP Prod.snd := many.trans_eq (congrArg Prod.snd total).symm
  refine ⟨f,rs,?_,perm,rsSize,adj,yes,done,cuts.1,cuts.2.1,by omega⟩
  apply List.ext_getElem
  · simp only [Array.length_toList,outs,List.length_map,rsSize]
  · intro i hi hj
    have bound : i<2048 := by simpa [outs] using hi
    have value := (atIndex ⟨i,bound⟩).trans (wire _)
    rw [getElem!_pos _ _ (by rwa [outs])] at value
    rw [List.getElem_map]
    change _ = rowWires ((List.ofFn (read ∘ p))[i]'_)
    rw [List.getElem_ofFn]
    exact value

#print axioms candidate_banks
end ExactWordFlow.CoreCandidateBanks

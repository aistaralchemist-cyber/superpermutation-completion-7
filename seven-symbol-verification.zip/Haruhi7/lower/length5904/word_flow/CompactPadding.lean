import CompactLayout
import CompactBenes
import CandidateBanks

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows RotationCore RotationReinsert
open SortedCoreRecords CoreRecordBits CoreCandidateBanks BenesRouting

private theorem enhanceRows {R S : α → β → Prop} {xs : List α} {ys : List β}
    (h : List.Forall₂ R xs ys) (f : ∀x y,y∈ys → R x y → S x y) :
    List.Forall₂ S xs ys := by
  induction h with
  | nil => exact .nil
  | cons h _ ih =>
    exact .cons (f _ _ List.mem_cons_self h) (ih (fun x y hy=>f x y (List.mem_cons_of_mem _ hy)))

private theorem replicateRows {R : α → β → Prop} {x : α} {y : β} (h : R x y) (n : Nat) :
    List.Forall₂ R (List.replicate n x) (List.replicate n y) := by
  induction n with
  | zero => exact .nil
  | succ _ ih => exact .cons h ih

private theorem fillerRep {v : Nat→Bool} (unit : v 0=true) :
    RowRep v 26 (#[1] ++ Array.replicate 25 (-1)) (rowWires dummy) := by
  have shape : rowWires dummy = #[true] ++ Array.replicate 25 false := by decide
  rw [shape]
  refine ⟨by decide,?_⟩
  change List.Forall₂ (fun x b=>Rep v b x) ((1:W)::List.replicate 25 (-1)) (true::List.replicate 25 false)
  exact .cons (one_rep unit) (replicateRows (R:=fun x b=>Rep v b x) (zero_rep unit) 25)

theorem padded_bank {w : Block} {v : Nat → Bool} {raw : Rows} (unit : v 0=true)
    (len : w.length=1501)
    (rows : List.Forall₂ (ArrayRel (fun x b=>Rep v b x)) raw.toList ((wordRows digits w).map rowWires)) :
    ArrayRel (RowRep v 26) (padded raw) (bankInput w) ∧ (padded raw).size=2048 := by
  have width : List.Forall₂ (RowRep v 26) raw.toList ((wordRows digits w).map rowWires) :=
    enhanceRows rows (fun x b hb hr=>by
      obtain ⟨r,hr',rfl⟩:=List.mem_map.mp hb
      have source : r∈sourceRows w := List.mem_append_left _ hr'
      exact ⟨hr.size.trans (by simp [rowWires,source_width source]),hr⟩)
  have finalRows : ArrayRel (RowRep v 26) (padded raw) (bankInput w) := by
    simpa only [ArrayRel,padded,bankInput,sourceRows,extra,Array.toList_append,Array.toList_replicate,
      List.toList_toArray,List.map_append,List.map_replicate] using
      List.rel_append width (replicateRows (fillerRep unit) 552)
  refine ⟨finalRows,finalRows.size.trans ?_⟩
  simp only [bankInput,sourceRows,wordRows,extra,List.size_toArray,List.length_map,
    List.length_append,List.length_replicate,List.length_singleton,windows_length,len]

#print axioms padded_bank
end ExactWordFlow.CompactWordCircuit

import WordFlow
import EndpointPairs

namespace ExactWordFlow
open SevenWordWindows SevenEndpointPairs SuperpermutationBounds

/-- An exact formulation with fixed starting context and a permutation at
the far end. It applies to an input word of any length up to the cutoff. -/
theorem canonical_858 :
    (∃ w : Word, Covers w ∧ w.length≤5904) ↔
    ∃ (X : Multiset Block) (p : Word), X.card=858 ∧ p∈endpointReps ∧
      Feasible X ((List.finRange 7).take 6) (p.drop 1) := by
  constructor
  · rintro ⟨w,hw,bound⟩
    obtain ⟨u,ul,hu,⟨suffix,front⟩,p,member,⟨before,back⟩⟩ :=
      normalized_endpoint_representative hw bound
    have pl := ((mem_reps p).mp (List.mem_filter.mp member).1).1
    obtain ⟨X,sz,f⟩ := extract_at_ends u hu (by omega)
    have first : u.take 6=(List.finRange 7).take 6 := by
      rw [←front,List.take_append_of_le_length (by simp)]
    have last : u.drop (u.length-6)=p.drop 1 := by
      rw [←back,List.length_append,pl]
      rw [show before.length+7-6=before.length+1 by omega]
      simp
    rw [first,last] at f
    exact ⟨X,p,by omega,member,f⟩
  · rintro ⟨X,p,sz,_,f⟩
    obtain ⟨w,hw,wl⟩ := exact_5904.mpr ⟨X,_,_,sz,f⟩
    exact ⟨w,hw,wl.le⟩

#print axioms canonical_858
end ExactWordFlow

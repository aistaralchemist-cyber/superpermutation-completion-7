import SeedWheelCut

namespace ExactWordFlow.MultipleRootContacts
open SeedWheelCut
variable {Y B : Type*} [Fintype Y] [DecidableEq Y] [DecidableEq B]

/-- Transport a cover such as TourWheelPrice.from_order to physical
permutation labels, whose ambient type need not itself be finite. -/
theorem named_closed_cover (name : Y ↪ B) {A V : Finset Y} {W : Finset (Finset Y)}
    (cover : ClosedCover A V W) :
    ClosedCover (A.map name) (V.map name) (W.image (fun w=>w.map name)) := by
  classical
  intro C base closed
  let pre:=Finset.univ.filter fun y=>name y∈C
  have iff (y : Y) : y∈pre ↔ name y∈C:=by simp [pre]
  have seen : A⊆pre:=fun y hy=>(iff y).mpr (base (Finset.mem_map_of_mem _ hy))
  have full:=cover pre seen (by
    intro w hw joined y hy
    obtain ⟨j,hj⟩:=joined
    obtain ⟨old,hit⟩:=Finset.mem_inter.mp hj
    have outcome:=closed (w.map name) (Finset.mem_image_of_mem _ hw)
      ⟨name j,Finset.mem_inter.mpr ⟨(iff j).mp old,Finset.mem_map_of_mem _ hit⟩⟩
    exact (iff y).mpr (outcome (Finset.mem_map_of_mem _ hy)))
  intro j hj
  obtain ⟨y,hy,rfl⟩:=Finset.mem_map.mp hj
  exact (iff y).mp (full hy)

#print axioms named_closed_cover
end ExactWordFlow.MultipleRootContacts

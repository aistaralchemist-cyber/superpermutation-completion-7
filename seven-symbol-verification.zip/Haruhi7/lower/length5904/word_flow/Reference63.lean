import Reference64
import SeventeenBranches
import CriticalRemainder
import CyclePacket63

set_option maxRecDepth 4096
set_option maxHeartbeats 900000
namespace ExactWordFlow.Reference63
open DirectedEuler ResidualDensity SevenWordWindows OnePath66 EmbeddedWheels
open SuperpermutationBounds SeventeenBranches
open SuperpermLowerBounds.LengthBudget

private abbrev W := ResidualControls.mainWord
private abbrev a := W.take 6
private abbrev b := W.drop (W.length-6)
private theorem board : 6≤W.length ∧ a≠b ∧ classCount a (windows W)=390 ∧ (bag W).card=463 := by
  native_decide

private theorem turn_count (ws : List Block) : (turns ws).card=6*ws.length := by
  induction ws with
  | nil => rfl
  | cons w ws ih =>
    change ((↑(GlobalWheelRank.wheel w) : Multiset Block)+turns ws).card=6*(ws.length+1)
    simp [ih,GlobalWheelRank.wheel,Nat.mul_add,Nat.add_comm]

private theorem move_turn (A B C D : Multiset Block) : A+B+(C+D)=A+(C+B)+D := by ac_rfl
private theorem move_loop (A R : Multiset Block) (e : Block) : A+({e}+R)=A+R+{e} := by ac_rfl
private theorem absorb_ends (E P Q : List Block) (T K : Multiset Block) :
    (↑(P++E++Q) : Multiset Block)+T+(K+0)=(↑E+T+K)+↑(P++Q) := by
  simp only [←Multiset.coe_add,add_zero]; ac_rfl

private theorem add_balanced {A B : Multiset Block} {u v : Block}
    (ba : A.map src+{v}=A.map dst+{u}) (bb : B.map src=B.map dst) :
    (A+B).map src+{v}=(A+B).map dst+{u} := by
  simp only [Multiset.map_add,bb,add_right_comm _ (B.map dst) _,ba]

/-- Every non-wheel circuit with two or more edges consumes both spare rank
units. Consequently the residual windows are bridges and must all spell
end extensions. The circuit has at most twelve edges, leaving at least
five such letters and an unavoidable third loss. -/
private theorem exclude_packet {ws cp : List Block} {u s t : Block} {R : Multiset Block}
    (legit : ∀w∈ws,full w) (k : ws.length=63) (cycle : Route src dst u cp u)
    (two : 2≤cp.length) (width : ∀e∈cp,e.length=7)
    (otherWidth : ∀e∈R,e.length=7) (budget : cp.length+R.card≤17)
    (notWheel : ¬(full u ∧ cp=GlobalWheelRank.wheel u))
    (total : (bag W+turns ws+↑cp+R).map src+{t}=(bag W+turns ws+↑cp+R).map dst+{s})
    (together : RequiredComponent.ClassesTogether (bag W+turns ws+↑cp+R)) : False := by
  let spine := read_route W board.1
  have pos : cp≠[] := by intro e; simp [e] at two
  have hd : anchor∈pathClasses a (windows W) := by
    simpa only [List.nil_append,List.append_nil] using (anchor_mem a [] [])
  let z := (cp.map (Packet64.project anchor ∘ src)).toFinset.card
  have zpos : 0<z := by
    cases cp with
    | nil => contradiction
    | cons x xs => exact Finset.card_pos.mpr ⟨_,List.mem_toFinset.mpr (List.mem_cons_self ..)⟩
  have tt : RequiredComponent.ClassesTogether ((bag W+turns ws)+(↑cp+R)) := by
    rwa [←add_assoc]
  have low := CyclePacket63.packet_bound spine legit hd cycle pos tt
  change 720 ≤ classCount a (windows W)+5*ws.length+(z-1)+R.card at low
  rw [board.2.2.1,k] at low
  have near : cp.length≤z+1 := by omega
  obtain ⟨short,loss⟩ := CyclePacket63.inefficient anchor cycle width pos two (by omega) near notWheel
  change z<cp.length at loss
  have enough : 5≤R.card := by omega
  let base := bag W+turns ws+↑cp
  have critical (e) (he : e∈R) : ¬RequiredComponent.ClassesTogether (base+R.erase e) := by
    intro left
    have remaining : RequiredComponent.ClassesTogether ((bag W+turns ws)+(↑cp+R.erase e)) := by
      rw [←add_assoc]; exact left
    have bad := CyclePacket63.packet_bound spine legit hd cycle pos remaining
    change 720 ≤ classCount a (windows W)+5*ws.length+(z-1)+(R.erase e).card at bad
    rw [board.2.2.1,k] at bad
    have erase := Multiset.card_erase_add_one he
    omega
  have balWheel := EndpointSaving.turns_balance ws legit
  have balCycle : (↑cp : Multiset Block).map src=(↑cp : Multiset Block).map dst :=
    add_right_cancel cycle.balance
  have baseDegree : base.map src+{b}=base.map dst+{a} :=
    add_balanced (add_balanced spine.balance balWheel) balCycle
  have degree := fresh_endpoints baseDegree total
  obtain ⟨p,q,eq,pre,post⟩ := bridge_ends (base:=base) spine (le_trans le_self_add le_self_add)
    board.2.1 degree together critical
  have sz := congrArg Multiset.card eq
  simp only [Multiset.coe_card,List.length_append] at sz
  have w (e) (he : e∈p++q) : e.length=7 := otherWidth e (eq ▸ (show e∈(↑(p++q) : Multiset Block) from he))
  have cap := SeventeenCaps.extension_loss pre post
    (fun e he => w e (List.mem_append_left _ he)) (fun e he => w e (List.mem_append_right _ he))
    (by omega) (by omega)
  change classCount s (p++windows W++q)+1≤390+(p.length+q.length) at cap
  have joined := join_routes (join_routes pre spine) post
  have all : RequiredComponent.ClassesTogether
      ((↑(p++windows W++q) : Multiset Block)+turns ws+(↑cp+0)) := by
    rw [absorb_ends,eq]; exact together
  have rank := CyclePacket63.packet_bound joined legit (anchor_mem s p q) cycle pos all
  change 720 ≤ classCount s (p++windows W++q)+5*ws.length+(z-1)+0 at rank
  omega

/-- Seventeen free windows cannot join all mandatory rotations while
the W-0021 spine and 63 selected complete turns are retained. -/
theorem no_seventeen {ws : List Block} {s t : Block} (k : ws.length=63)
    (legit : ∀u∈ws,full u) (F : Multiset Block) (small : F.card≤17) :
    ¬Feasible (bag W+turns ws+F) s t := by
  intro yes
  have together := (RequiredComponent.together_iff_classes _).mp (RequiredComponent.feasible_together yes)
  have width (e) (he : e∈F) := yes.edges_seven e (Multiset.mem_add.mpr (Or.inr he))
  obtain ⟨u,cp,pos,sub,cycle⟩ := must_cycle legit k.le small width yes.balance together
  obtain ⟨R,split⟩ := exists_add_of_le sub
  have size : cp.length+R.card≤17 := by simpa only [split,Multiset.card_add,Multiset.coe_card] using small
  by_cases two : 2≤cp.length
  · by_cases wh : full u ∧ cp=GlobalWheelRank.wheel u
    · obtain ⟨fl,h⟩ := wh
      have reform : bag W+turns ws+F=bag W+turns (u::ws)+R := by
        rw [split,h]; exact move_turn .. 
      have len : cp.length=6 := by simp [h,GlobalWheelRank.wheel]
      exact Reference64.no_eleven (by simp [k]) (ws:=u::ws)
        (by intro v hv; rcases List.mem_cons.mp hv with rfl|hw; exact fl; exact legit _ hw)
        R (by omega) (reform ▸ yes)
    · have reform : bag W+turns ws+F=bag W+turns ws+↑cp+R := by rw [split,←add_assoc (bag W+turns ws)]
      have all : Feasible (bag W+turns ws+↑cp+R) s t := reform ▸ yes
      exact exclude_packet legit k cycle two
        (fun e he => width e (Multiset.mem_of_le sub he))
        (fun e he => width e (split ▸ (Multiset.mem_add.mpr (Or.inr he) : e∈(↑cp : Multiset Block)+R)))
        size wh all.balance (reform ▸ together)
  · have one : cp.length=1 := by have := List.length_pos_iff.mpr pos; omega
    obtain ⟨e,rfl⟩ := List.length_eq_one_iff.mp one
    have loop : src e=dst e := by cases cycle with | cons _ hs tail => cases tail; exact hs
    have reform : bag W+turns ws+F=(bag W+turns ws+R)+{e} := by rw [split]; exact move_loop _ _ _
    have smaller := SpineWheelTrimming.drop_loop loop (reform ▸ yes)
    exact no_seventeen k legit R (by omega) smaller
termination_by F.card
decreasing_by rw [split,Multiset.card_add,Multiset.coe_card]; simp

theorem classes_disconnected {ws : List Block} {F : Multiset Block} {s t : Block}
    (k : ws.length=63) (legit : ∀u∈ws,full u) (small : F.card≤17)
    (width : ∀e∈bag W+turns ws+F,e.length=7)
    (bal : (bag W+turns ws+F).map src+{t}=(bag W+turns ws+F).map dst+{s}) :
    ¬RequiredComponent.ClassesTogether (bag W+turns ws+F) := by
  intro together
  obtain ⟨R,sub,s',t',yes⟩ := SpineWheelTrimming.trim_reference legit width bal together
  exact no_seventeen k legit R ((Multiset.card_le_card sub).trans small) yes

private theorem drop_turn (A B C D : Multiset Block) : A+(B+C)+D=A+C+(B+D) := by ac_rfl

/-- Choosing 63 of the already exhibited wheels leaves eighteen free windows. -/
theorem eighteen_attainable :
    ∃ (ws : List Block) (F : Multiset Block) (s t : Block), ws.length=63 ∧
      (∀u∈ws,full u) ∧ F.card=18 ∧
      Feasible (bag W+turns ws+F) s t ∧ RequiredComponent.ClassesTogether (bag W+turns ws+F) := by
  obtain ⟨ws,F,s,t,k,lg,sz,yes,together⟩ := SpineWheelTrimming.twelve_attainable
  cases ws with
  | nil => simp at k
  | cons u ws =>
    let K : Multiset Block := ↑(GlobalWheelRank.wheel u)
    have form : bag W+turns (u::ws)+F=bag W+turns ws+(K+F) := by
      change bag W+(K+turns ws)+F=_
      exact drop_turn ..
    have cu : K.card=6 := by simp [K,GlobalWheelRank.wheel]
    refine ⟨ws,K+F,s,t,?_,fun z hz => lg z (List.mem_cons_of_mem _ hz),?_,form ▸ yes,form ▸ together⟩
    · simp at k; omega
    · rw [Multiset.card_add,cu,sz]

theorem least_extra : IsLeast {k : Nat | ∃ (ws : List Block) (F : Multiset Block) (s t : Block),
    ws.length=63 ∧ (∀u∈ws,full u) ∧ F.card=k ∧
    (∀e∈bag W+turns ws+F,e.length=7) ∧
    (bag W+turns ws+F).map src+{t}=(bag W+turns ws+F).map dst+{s} ∧
    RequiredComponent.ClassesTogether (bag W+turns ws+F)} 18 := by
  constructor
  · obtain ⟨ws,F,s,t,k,lg,sz,yes,together⟩ := eighteen_attainable
    exact ⟨ws,F,s,t,k,lg,sz,yes.edges_seven,yes.balance,together⟩
  · rintro k ⟨ws,F,s,t,n,leg,sz,width,bal,together⟩
    by_contra! small
    exact classes_disconnected n leg (by omega) width bal together

def Keeps63 (w : Block) : Prop :=
  ∃ (ws : List Block) (F : Multiset Block), 63≤ws.length ∧
    (∀u∈ws,full u) ∧ bag w=required+(bag W+turns ws+F)

theorem restricted_minimum :
    (∃ w : Block, Covers w ∧ Keeps63 w ∧ w.length=5905) ∧
    (∀w : Block, Covers w → Keeps63 w → 5905≤w.length) := by
  constructor
  · obtain ⟨w,hw,⟨ws,F,n,leg,eq⟩,sz⟩ := Reference64.restricted_minimum.1
    exact ⟨w,hw,⟨ws,F,by omega,leg,eq⟩,sz⟩
  · rintro w hw ⟨ws,F,n,leg,eq⟩
    by_cases more : 64≤ws.length
    · exact Reference64.restricted_minimum.2 w hw ⟨ws,F,more,leg,eq⟩
    obtain ⟨l,r,hw'⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
    have long := congrArg List.length hw'
    simp only [List.length_append,List.length_finRange] at long
    obtain ⟨X,ex,cost,yes⟩ := extract_windows_at_ends w hw (by omega)
    have same := add_left_cancel (ex.trans eq)
    subst X
    by_contra! small
    rw [Multiset.card_add,Multiset.card_add,board.2.2.2,turn_count] at cost
    exact no_seventeen (by omega) leg F (by omega) yes

#print axioms no_seventeen
#print axioms classes_disconnected
#print axioms least_extra
#print axioms restricted_minimum
end ExactWordFlow.Reference63

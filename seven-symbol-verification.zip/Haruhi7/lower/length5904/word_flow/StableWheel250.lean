import FixedSeed250
namespace ExactWordFlow.StableWheel250
open SevenWordWindows SeedWheelCut ExtremeWheelCut FixedSeed250
open private digits from ExtremeWheelCut

/-- A partition maps each tag to the representative of its current
component. Equalities of labels, rather than the label values, define it. -/
private abbrev Partition := Std.HashMap Block Block
private def rootLabel : Block := [0,1,2,3,4,5,6]
private def initial : Partition := Id.run do
  let mut part : Partition := {}
  for d in allClasses.sort (·≤·) do
    part:=part.insert d (if d∈rootClasses then rootLabel else d)
  return part

private def rep (p : Partition) (d : Block) := p[d]?.getD []
private def faces (p : Partition) (w : Finset Block) := w.image (rep p)
/-- A usable step has six distinct components, as required for a
six-wheel to introduce five new classes in a saturated tree. -/
private def enabled (p : Partition) := allRows.filter fun w=>(faces p w).card=6

private def join (p : Partition) (w : Finset Block) : Partition := Id.run do
  let labels := faces p w
  let first := ((labels.sort (·≤·)).head?).getD []
  let mut result := p
  for x in allClasses.sort (·≤·) do
    if rep p x∈labels then result:=result.insert x first
  return result

private def uniqueAt (p : Partition) (d : Block) (w : Finset Block) : Bool :=
  let opts := (enabled p).filter fun t=>rep p d∈faces p t
  decide (d∈allClasses ∧ opts={w})

private def steps : List (String × String) := [  ("0143526","014326"),
  ("0231456","023156"),
  ("0245163","163245"),
  ("0261453","145326"),
  ("0354216","035416"),
  ("0364215","153642"),
  ("0413562","135624"),
  ("0425136","042536"),
  ("0526341","152634"),
  ("0532416","053216"),
  ("0216453","016453"),
  ("0163425","016325"),
  ("0321645","032165"),
  ("0214653","014653"),
  ("0465321","046531"),
  ("0562341","156234"),
  ("0613542","061542"),
  ("0614253","061425"),
  ("0621435","062435"),
  ("0634251","063251"),
  ("0653214","065314")]
private def replay : List (String × String) → Partition → Bool × Partition
  | [], p => (true,p)
  | (d,w)::rest, p =>
      let edge := WheelContacts.wheel (digits w)
      if uniqueAt p (digits d) edge then replay rest (join p edge) else (false,p)

/-- The complete wheel incidence system, before applying the CNF test.
Every forced merge is checked on the whole current partition. At the
end, every one of 366 components has at least two available wheels. -/
theorem stalls : steps.length=21 ∧
    let out:=replay steps initial
    let cells:=allClasses.image (rep out.2)
    let options:=enabled out.2
    out.1=true ∧ cells.card=366 ∧ options.card=272 ∧
      ∀x∈cells,2≤(options.filter fun w=>x∈faces out.2 w).card := by native_decide

#print axioms stalls
end ExactWordFlow.StableWheel250

import PeakBudget

namespace ExactWordFlow.DeepBridgeCost

/-- A block with at least five paid letters necessarily consumes two
extra units past a usual three-letter break, and at least eight loss units
after paying once for the gap it can separate. -/
theorem dear_block {r d : Nat} (phase : r≤5) (dear : 5≤d) :
    1+2 ≤ d-2 ∧ 1+8 ≤ 5*(d-2)-(r+1) := by omega

/-- On a whole list of paid block endpoints, the existence of one
five-letter endpoint strictly tightens both the number of breaks and
the number of negative separators, independently of all other endpoints. -/
theorem dear_sums (bs : List (Nat × Nat))
    (paid : ∀b∈bs,3≤b.2 ∧ b.1≤5)
    (dear : ∃b∈bs,5≤b.2) :
    bs.length+2 ≤ (bs.map (fun b=>b.2-2)).sum ∧
    (bs.filter (fun b=>decide (b.1+1<5*(b.2-2)))).length+8 ≤
      (bs.map (fun b=>5*(b.2-2)-(b.1+1))).sum := by
  have plain (xs : List (Nat × Nat)) (ok : ∀b∈xs,3≤b.2) :
      xs.length ≤ (xs.map (fun b=>b.2-2)).sum ∧
      (xs.filter (fun b=>decide (b.1+1<5*(b.2-2)))).length ≤
        (xs.map (fun b=>5*(b.2-2)-(b.1+1))).sum := by
    induction xs with
    | nil => simp
    | cons b xs ih =>
      obtain ⟨m,n⟩:=ih (fun t ht=>ok t (List.mem_cons_of_mem _ ht))
      have v:=ok b (by simp)
      by_cases sign : b.1+1<5*(b.2-2)
      · simp [sign]; omega
      · simp [sign]; omega
  obtain ⟨b,hb,db⟩:=dear
  obtain ⟨l,r,eq⟩:=List.append_of_mem hb
  subst bs
  have a:=plain l (fun t ht=>(paid t (by simp [ht])).1)
  have c:=plain r (fun t ht=>(paid t (by simp [ht])).1)
  have close:=dear_block (paid b (by simp)).2 db
  have neg : b.1+1<5*(b.2-2) := by omega
  simp [neg]
  omega

/-- Seed-independent arithmetic for the canonical block decomposition.
q counts physical correction wheels, not components of the word graph. -/
theorem correction_wheel_limit {q e s g p loss r : Nat}
    (exceptions : 1≤e) (budget : q+e+s+2*g≤140)
    (score : 719+12*g+6*(e-1)+loss ≤ p+5*(q+e+s+2*g))
    (pool : 6*p≤30*r+2*g)
    (planar : g=0 → p≤4*r+e-1)
    (ifMany : 96≤q → (p + r + 2 ≤ s + e ∧ r + 8 ≤ loss + e + g)) : q≤95 := by
  by_contra! many
  obtain ⟨x,y⟩:=ifMany many
  by_cases flat : g=0
  · have z:=planar flat
    omega
  · omega

theorem mass_floor {q e g M : Nat} (exc : 1≤e)
    (count : M+5*q=719+e+2*g) (small : q≤95) : 245+2*g+(e-1)≤M := by omega

#print axioms dear_sums
#print axioms correction_wheel_limit
#print axioms mass_floor
end ExactWordFlow.DeepBridgeCost

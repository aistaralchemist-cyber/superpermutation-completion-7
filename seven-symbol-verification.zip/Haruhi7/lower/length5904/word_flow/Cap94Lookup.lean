import Cap94Encoding
import Cap94RowsChecked
import Cap94Hard
import OrientedCNF

namespace ExactWordFlow.Cap94Lookup
open private baseGood from NearBindingCheck
open SevenWordWindows RotationCore NearRootMoves ExtremeWheelCut NearWheelBinding Cap94Catalog

private def buildKeys (rs : Array (Block × Answer)) :=
  (rs.map fun p=>visited p.1).map (fun R=>((List.range 7).map (fun j=>bits j R)).toArray)

private theorem key_at (rs : Array (Block × Answer)) {i j : Nat} (hi : i<rs.size) (hj : j<7) :
    ((buildKeys rs)[i]!)[j]! = (bits j (visited (rs[i]!).1)) := by
  have bound : i<(buildKeys rs).size := by simpa [buildKeys] using hi
  rw [getElem!_pos _ i bound,getElem!_pos rs i hi]
  simp only [buildKeys,Array.getElem_map]
  have enough : j<(((List.range 7).map (fun k=>bits k (visited rs[i].1))).toArray).size := by simpa using hj
  rw [getElem!_pos _ j enough]
  simp

private theorem reject {R : Finset Block} (rs : Array (Block × Answer))
    (ok : rs.toList.all (baseGood 94 Cap94Data.hard.toArray)=true)
    {i j : Nat} (hi : i<rs.size) (hj : j<7) (bitsEq : ((buildKeys rs)[i]!)[j]! = (bits 0 R))
    (knownR : ∀c∈R,known c=true)
    {W : Finset (Finset Block)} (leg : W⊆allRows) (size : W.card≤94) (cover : SeedWheelCut.ClosedCover R allClasses W) :
    False := by
  let p:=rs[i]!
  have inTable : p∈rs.toList := by
    dsimp only [p]
    rw [getElem!_pos rs i hi]
    exact Array.mem_toList_iff.mpr (Array.getElem_mem hi)
  have eq : bits 0 R=bits j (visited p.1) := by rw [←bitsEq,key_at rs hi hj]
  have belongs : R⊆allClasses:=fun c hc=>board_of_known (knownR c hc)
  have back:=unshift (visited_subset p.1) ⟨j,hj⟩ (eq_shift belongs (visited_subset p.1) _ eq)
  obtain ⟨V,l,s,yes⟩:=transport leg cover (List.replicate ((7-j)%7) 7)
  rw [back] at yes
  obtain ⟨r,hard,w,rows,small,card,linked⟩:=Cap94Catalog.entry rs ok inTable l (s.trans size) yes
  have tight : r.card+5*w.card≤allClasses.card := by rw [RotationCore.board,card];omega
  exact OrientedCNF.no_cover rows tight (Cap94Hard.unsat hard) linked

theorem no_cover {R : Finset Block} (accepted : accept R=true)
    {W : Finset (Finset Block)} (leg : W⊆allRows) (size : W.card≤94) :
    ¬SeedWheelCut.ClosedCover R allClasses W := by
  intro cover
  unfold accept at accepted
  generalize lookup.getD (bits 0 R) (rows.size,7)=ij at accepted
  rcases ij with ⟨i,j⟩
  obtain ⟨hi,hj,eq,knownR⟩:=of_decide_eq_true accepted
  exact reject rows rows_ok hi hj eq knownR leg size cover

#print axioms no_cover
end ExactWordFlow.Cap94Lookup

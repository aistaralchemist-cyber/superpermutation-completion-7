import CoreCounts

namespace ExactWordFlow.RunCollision
open SevenWordWindows
/-- The six states traversed by the ordinary cost-two switch in the
adjusted successor: keep the head, rotate the remaining six symbols. -/
def atPhase (p : Block) (i : Nat) := p.take 1 ++ p.tail.rotate i
def footprint (p : Block) :=
  ((List.range 6).map fun i => classKey (atPhase p i)).toFinset

inductive Jump where | abc | acb | bac | bca | cab | cba
  deriving DecidableEq, Repr

def jumps : List Jump := [.abc,.acb,.bac,.bca,.cab,.cba]
private def reorder (j : Jump) (a b c : Fin 7) : Block :=
  match j with
  | .abc => [a,b,c] | .acb => [a,c,b] | .bac => [b,a,c]
  | .bca => [b,c,a] | .cab => [c,a,b] | .cba => [c,b,a]

/-- Use five cost-two turns, then a real cost-three move, and undo the
ordinary seven-symbol rotation to enter the next switch cycle state. -/
def next (p : Block) (j : Jump) : Block :=
  let u:=atPhase p 5
  (u.drop 3 ++ reorder j (u[0]?.getD 0) (u[1]?.getD 0) (u[2]?.getD 0)).rotate 6

def predicted : Jump → Nat
  | .abc => 1 | .acb => 2 | .bac => 2 | .bca => 6 | .cab => 1 | .cba => 0

private theorem local_geometry : ∀p∈representatives,
    (∀j∈jumps, (footprint p ∩ footprint (next p j)).card=predicted j ∧
       next p j∈representatives) ∧ ((fun x=>next x .cba)^[5]) p=p := by
  native_decide

theorem overlap_count {p : Block} (hp : p∈representatives) (j : Jump) :
    (footprint p ∩ footprint (next p j)).card=predicted j := by
  exact ((local_geometry p hp).1 j (by cases j <;> decide)).1

theorem five_period {p : Block} (hp : p∈representatives) :
    ((fun x=>next x .cba)^[5]) p=p := (local_geometry p hp).2

private theorem forced {p : Block} (hp : p∈representatives) (j : Jump)
    (sep : Disjoint (footprint p) (footprint (next p j))) : j=.cba := by
  have z:=overlap_count hp j
  rw [Finset.disjoint_iff_inter_eq_empty.mp sep,Finset.card_empty] at z
  cases j <;> simp_all [predicted]

/-- Six consecutive six-state blocks joined by five real cost-three
transitions have an incidence collision. Locally disjoint adjacent blocks
force the sixth starting permutation to be the first one. -/
theorem six_blocks {p : Block} (hp : p∈representatives) (j : Fin 5 → Jump)
    (v : Nat → Block) (start : v 0=p)
    (steps : ∀i : Fin 5,v (i.val+1)=next (v i.val) (j i))
    (sep : ∀i : Fin 5,Disjoint (footprint (v i.val)) (footprint (v (i.val+1)))) :
    v 5=v 0 := by
  have ok : ∀n≤5,v n∈representatives := by
    intro n
    induction n with
    | zero => intro _; simpa [start] using hp
    | succ n ih =>
      intro small
      let i : Fin 5 := ⟨n,by omega⟩
      rw [show v (n+1)=next (v n) (j i) from steps i]
      exact ((local_geometry _ (ih (by omega))).1 _ (by cases j i <;> decide)).2
  let f := fun x=>next x .cba
  have spelling : ∀n≤5,v n=(f^[n]) p := by
    intro n
    induction n with
    | zero => intro _; exact start
    | succ n ih =>
      intro small
      let i : Fin 5 := ⟨n,by omega⟩
      have d:=sep i
      rw [steps i] at d
      have yes:=forced (ok n (by omega)) (j i) d
      rw [show v (n+1)=next (v n) (j i) from steps i,yes,ih (by omega)]
      exact (Function.iterate_succ_apply' f n p).symm
  rw [spelling 5 (by decide),start]
  exact five_period hp

#print axioms six_blocks
end ExactWordFlow.RunCollision

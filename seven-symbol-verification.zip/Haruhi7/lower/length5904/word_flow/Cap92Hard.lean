import WheelLRAT
import OrientedFormula
import Cap92Data

namespace ExactWordFlow.Cap92Hard
open WheelLRAT Cap92Data OrientedCNF

set_option maxRecDepth 50000
set_option maxHeartbeats 0

private def formulas := (hard).map cnf
private def certificates := wheelCertificates% formulas

/-- Each formula is constructed from the actual footprint. Lean checks
every proof against that same formula before deriving unsatisfiability. -/
theorem unsat {R} (member : R∈hard) : (cnf R).Unsat :=
  batch_sound (fs:=formulas) (cs:=certificates) (by native_decide)
    (cnf R) (List.mem_map_of_mem member)

#print axioms unsat
end ExactWordFlow.Cap92Hard

import Tight858

/-! Complete incidence data for the 67 residual components of the concrete
858-edge placement. Index 0 is the open route. Indices 1 through 66
follow the stored wheel order. Sorted words start at letter 0. -/
namespace Dense462.RankTight.IncidenceMap
open ExactWordFlow SevenWordWindows ResidualDensity DirectedEuler

private def digits (s : String) : Block := s.toList.map fun c => Fin.ofNat 7 (c.toNat-48)

def wheelIds : List String := [
  "043615","031245","015342","012345","013542","062134","021634","051324",
  "045213","012453","043521","051234","012534","026134","021364","032641",
  "012435","021346","013254","051243","054213","045321","034152","034251",
  "035142","053124","032461","035124","034125","013245","013452","036241",
  "031425","051342","043251","031452","035412","053412","053142","012354",
  "063241","042513","015324","013425","013524","043165","032416","015234",
  "043156","064315","165432","154623","154326","046315","123645","156423",
  "123465","156342","024563","045632","036521","142356","063421","014562",
  "025463","016423"]

def walks : List Block := Dense462.word :: wheelIds.map (fun s => let w:=digits s; w++w)
def contexts (w : Block) := w.take 6 :: (windows w).map dst
def labels (w : Block) := touched (contexts w)
def classes := walks.map labels
def meeting (i j : Nat) : Finset Block := classes[i]! ∩ classes[j]!

/-- One row for each nonempty unordered intersection. -/
def rows : List (Nat × Nat × List Block) := ([
  (0,49,["0423156"]),
  (0,50,["0642315"]),
  (0,51,["0654321"]),
  (0,52,["0315462","0462315"]),
  (0,53,["0154326"]),
  (0,54,["0426315","0462315"]),
  (0,55,["0364512"]),
  (0,56,["0315642","0423156","0642315"]),
  (0,57,["0346512"]),
  (0,58,["0421563","0563421"]),
  (0,59,["0214563","0241563","0245631"]),
  (0,60,["0145632","0415632","0456312"]),
  (0,61,["0365214","0365421"]),
  (0,62,["0142356","0235614","0423561","0561423","0614235"]),
  (0,63,["0563421","0634521","0635421","0653421"]),
  (0,64,["0143562","0145362","0145623","0145632"]),
  (0,65,["0125463","0215463","0251463","0254163","0254613","0254631"]),
  (0,66,["0164235","0164253","0164523","0165423","0516423"]),
  (1,53,["0432615"]),
  (3,58,["0156342"]),
  (4,55,["0123645"]),
  (4,57,["0123465"]),
  (7,58,["0215634"]),
  (10,59,["0124563"]),
  (11,61,["0436521"]),
  (12,55,["0512364"]),
  (12,57,["0512346","0651234"]),
  (22,60,["0456321"]),
  (24,63,["0634251"]),
  (25,62,["0356142"]),
  (31,64,["0134562"]),
  (32,61,["0365241"]),
  (36,64,["0314562"]),
  (46,51,["0432165"]),
  (49,56,["0423156"]),
  (50,56,["0642315"]),
  (52,54,["0462315"]),
  (56,66,["0156423"]),
  (58,63,["0563421","0634215"]),
  (60,64,["0145632"])
] : List (Nat × Nat × List String)).map fun (i,j,xs) => (i,j,xs.map digits)

private def pairs := (List.range 67).flatMap fun i => ((List.range 67).filter (i < ·)).map fun j => (i,j)
def nonemptyPairs := pairs.filter fun (i,j) => (meeting i j).Nonempty

/-- The input is the actual placement in Tight858, and the route supports
are pairwise disjoint at the level of six-letter states. -/
theorem actual_placement :
    (↑(walks.flatMap windows) : Multiset Block) = Dense462.RankTight.X ∧
    walks.length=67 ∧
    (walks.map (fun w => (contexts w).toFinset)).Pairwise Disjoint := by native_decide

/-- Filtering *all* pairs at once also checks the pairs omitted from the table. -/
theorem all_meetings : pairs.length=2211 ∧ rows.length=40 ∧
    nonemptyPairs=rows.map (fun (i,j,_) => (i,j)) ∧
    (rows.all fun (i,j,zs) => decide (zs.Nodup ∧ zs.toFinset=meeting i j)) = true := by
  native_decide

def isolated : List Nat := [2,5,6,8,9,13,14,15,16,17,18,19,20,21,23,26,27,28,29,30,33,34,35,37,38,39,40,41,42,43,44,45,47,48]
def central : List Nat := [0,1,3,4,7,10,11,12,22,24,25,31,32,36,46,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66]
def metBy (c : Block) := (List.range 67).filter fun i => c∈classes[i]!
def classList := (representatives.map classKey).eraseDups

/-- Edges crossing from the already reached indices to the next are exactly
the intersections of their label sets; iterating lists an entire component. -/
private def grow (r : Finset Nat) : Finset Nat := r ∪ (Finset.range 67).filter (fun j =>
  ∃ i∈r, (meeting i j).Nonempty)

theorem clusters :
    ((List.range 67).filter fun i => ((List.range 67).all fun j => i==j || decide (meeting i j=∅)))=isolated ∧
    isolated.length=34 ∧ central.length=33 ∧
    (grow {0}).card=19 ∧ grow (grow {0})=central.toFinset ∧ grow central.toFinset=central.toFinset ∧
    (central.toFinset.biUnion fun i => classes[i]!).card=516 ∧
    (isolated.all fun i => (classes[i]!).card==6)=true := by native_decide

private def counts := classList.map (fun c => (metBy c).length)
theorem incidence_counts :
    classList.length=720 ∧ counts.count 1=659 ∧ counts.count 2=56 ∧ counts.count 3=5 ∧
    (classes.map Finset.card).sum=786 ∧ (classes.map (fun C => C.card-1)).sum=719 ∧
    786+35=720+67+34 ∧ 720-35=685 ∧ 719=685+34 := by native_decide

def tripleList : List (Block × List Nat) := ([
  ("0145632",[0,60,64]),
  ("0423156",[0,49,56]),
  ("0462315",[0,52,54]),
  ("0563421",[0,58,63]),
  ("0642315",[0,50,56])
] : List (String × List Nat)).map fun (s,ids) => (digits s,ids)

theorem triple_meetings :
    ((classList.filter (fun c => (metBy c).length=3)).map (fun c => (c,metBy c))).toFinset = tripleList.toFinset := by native_decide

#print axioms actual_placement
#print axioms all_meetings
#print axioms clusters
#print axioms incidence_counts
#print axioms triple_meetings
end Dense462.RankTight.IncidenceMap

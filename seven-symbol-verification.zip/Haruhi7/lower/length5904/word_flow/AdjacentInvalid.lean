import RotationReinsert
import CleanFlow
import NormalizedWord

namespace ExactWordFlow.AdjacentInvalid
open SevenWordWindows SuperpermutationBounds DirectedEuler

private def pay : Option Word → Option Word → Nat
  | none,none => 1
  | _,_ => 0

/-- Number of adjacent pairs of invalid windows, counting overlapping pairs
inside a longer run. -/
def adjacent : List (Option Word) → Nat
  | a::b::xs => pay a b + adjacent (b::xs)
  | _ => 0

theorem run_bound_gap (xs : List (Option Word)) :
    (runEnds xs).length+adjacent xs ≤ xs.count none+firstPay xs := by
  induction xs with
  | nil => rfl
  | cons a xs ih =>
    rcases xs with _ | ⟨b,t⟩
    · cases a <;> simp [adjacent,runEnds,firstPay]
    · cases a <;> cases b <;> simp [adjacent,pay,runEnds,firstPay] at ih ⊢ <;> omega

private theorem classes_size : allClasses.card=720 := by native_decide

private theorem sum_counts_le {α : Type*} [DecidableEq α] [BEq α] [LawfulBEq α] (s : Finset α) (xs : List α) :
    ∑ a ∈ s, xs.count a ≤ xs.length := by
  induction xs with
  | nil => simp
  | cons a xs ih =>
    simp only [List.count_cons,List.length_cons,Finset.sum_add_distrib]
    have b : (∑ x∈s, if a==x then 1 else 0) ≤ 1 := by
      simp only [beq_iff_eq]
      rw [Finset.sum_boole]
      exact (Finset.card_le_one.mpr (by intro y hy z hz; simp at hy hz; grind))
    omega


private theorem first_pay_le (xs : List (Option Word)) : firstPay xs ≤ 1 := by
  rcases xs with _ | ⟨a,ys⟩ <;> try trivial
  cases a <;> simp [firstPay]


theorem complete_with_gaps (w : Word) (hw : Covers w) (length : w.length≤5904) :
    581 + adjacent (labels w) ≤ (completeClasses w).card := by
  have lower : ∀ c ∈ allClasses, 9 ≤
      (visits w).count c + (runEnds (labels w)).count c +
        if (visits w).count c=7 ∧ (runEnds (labels w)).count c=1 then 1 else 0 := by
    intro c hc
    have v := class_visits_ge w hw hc
    have e := class_ends_ge w hw hc
    split <;> omega
  have s := Finset.sum_le_sum lower
  simp only [Finset.sum_const,smul_eq_mul,classes_size,Finset.sum_add_distrib,Finset.sum_boole] at s
  have t := good_add_invalid w
  have v := sum_counts_le allClasses (visits w)
  have e := sum_counts_le allClasses (runEnds (labels w))
  have b := run_bound_gap (labels w)
  have f := first_pay_le (labels w)
  have vl : (visits w).length=(good w).length := by simp [visits]
  rw [vl] at v
  change (runEnds (labels w)).length + adjacent (labels w) ≤ invalid w + firstPay (labels w) at b
  change 6480 ≤ (∑ c ∈ allClasses, (visits w).count c) +
    (∑ c ∈ allClasses, (runEnds (labels w)).count c) + (completeClasses w).card at s
  omega



private def dirty (v : Block) : Nat := if v.Nodup then 0 else 1
private def bad (e : Block) : Bool := decide (¬(src e).Nodup ∨ ¬(dst e).Nodup)

private theorem one (e : Block) : (if bad e then 1 else 0) ≤ dirty (src e)+dirty (dst e) := by
  by_cases a : (src e).Nodup <;> by_cases b : (dst e).Nodup <;> simp [bad,dirty,a,b]

private theorem shared (e f : Block) (neighbor : dst e=src f) :
    dirty (dst e) ≤ pay (mark e) (mark f) := by
  by_cases h : (dst e).Nodup
  · simp [dirty,h]
  · have p : ¬e.Nodup := fun n => h n.drop
    have q : ¬f.Nodup := fun n => h (neighbor ▸ n.take)
    simp [dirty,h,mark,p,q,pay]

private theorem overlap_source {a b : Block} {e : Block} {es : List Block}
    (r : Route src dst a (e::es) b) : src e=a := by cases r; assumption

private theorem charge {a b : Block} {es : List Block} (r : Route src dst a es b) :
    (es.filter bad).length ≤ 2*adjacent (es.map mark)+dirty a+dirty b := by
  induction r with
  | nil => simp [adjacent]
  | @cons v b es e first tail ih =>
    have localCost := one e
    rw [first] at localCost
    cases es with
    | nil =>
      cases tail
      by_cases eb : bad e
      · simpa [eb,adjacent] using localCost
      · simp [eb]
    | cons f fs =>
      have seam := shared e f (overlap_source tail).symm
      have step : adjacent ((e::f::fs).map mark)=pay (mark e) (mark f)+adjacent ((f::fs).map mark) := by
        rw [List.map_cons,List.map_cons,adjacent]
      rw [step]
      by_cases eb : bad e
      · simp only [eb,ite_true,List.filter_cons_of_pos eb,List.length_cons] at localCost ⊢
        omega
      · simp only [List.filter_cons_of_neg eb]
        omega

/-- All four distinct compulsory exceptional raw edges have a non-clean
end. Each interior non-clean state can pay for at most two such edges. -/
theorem at_least_two {w : Block} (hw : Covers w) (limit : w.length≤5904)
    (left : (w.take 6).Nodup) (right : (w.drop (w.length-6)).Nodup) :
    2≤adjacent (labels w) := by
  obtain ⟨l,r,eq⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
  have size := congrArg List.length eq
  simp only [List.length_append, List.length_finRange] at size
  have long : 6≤w.length := by omega
  obtain ⟨X,ex,cost,yes⟩ := extract_windows_at_ends w hw long
  have many := CleanFlow.four_exceptional (by omega : X.card≤858) yes
  have sub : CleanFlow.exceptional X ⊆ ((windows w).filter bad).toFinset := by
    intro e he
    obtain ⟨xin,noReq,noTurn⟩ := Finset.mem_filter.mp he
    have ew : e∈windows w := by
      change e∈bag w
      rw [←ex]
      exact Multiset.mem_add.mpr (Or.inr (Multiset.mem_toFinset.mp xin))
    apply List.mem_toFinset.mpr
    apply List.mem_filter.mpr
    refine ⟨ew,decide_eq_true ?_⟩
    by_contra! only
    exact (CleanFlow.clean_classification (RotationReinsert.window_width w ew) only.1 only.2).elim noReq noTurn
  have card := (Finset.card_le_card sub).trans (List.toFinset_card_le _)
  have price := charge (read_route w long)
  simp only [dirty,left,right,ite_true,Nat.add_zero] at price
  change 2≤adjacent ((windows w).map mark)
  omega

theorem some_583 {w : Block} (hw : Covers w) (small : w.length≤5904) :
    ∃z : Block, Covers z ∧ z.length=5904 ∧ 583≤(completeClasses z).card := by
  obtain ⟨z,sz,cover,first,p,plen,np,last⟩ := SevenNormalizedWord.normalize_5904 hw small
  have lft : (z.take 6).Nodup := by
    obtain ⟨xs,form⟩ := first
    rw [←form,List.take_append_of_le_length (by simp : 6≤(List.finRange 7).length)]
    exact (List.nodup_finRange 7).take
  have rgt : (z.drop (z.length-6)).Nodup := by
    obtain ⟨xs,form⟩ := last
    rw [←form,List.length_append,plen,show xs.length+7-6=xs.length+1 by omega,
      List.drop_append, List.drop_of_length_le (show xs.length≤xs.length+1 by omega)]
    simp only [List.nil_append, Nat.add_sub_cancel_left]
    exact np.drop
  have big := at_least_two cover sz.le lft rgt
  have cmp := complete_with_gaps z cover sz.le
  exact ⟨z,cover,sz,by omega⟩

#print axioms complete_with_gaps
#print axioms some_583
end ExactWordFlow.AdjacentInvalid

import WitnessRadius

namespace Dense462.RankTight.Neighborhood
open ExactWordFlow SevenWordWindows ResidualDensity DirectedEuler

private def P : Finset ℕ := {17,21,23,35,37}
private def allowedPairs : Finset (Finset ℕ) :=
  {{17,20},{21,9},{23,29},{37,38}}
private def ca (e : Block) := oldColor (src e)
private def cb (e : Block) := oldColor (dst e)
private def shape (e : Block) : Prop := ca e ≠ cb e →
  ¬(ca e∈P ∧ cb e∈P) ∧
    ((ca e∈P ∨ cb e∈P) → ca e=0 ∨ cb e=0 ∨ endpoints e∈allowedPairs)

private instance (e : Block) : Decidable (shape e) := by
  unfold shape
  infer_instance

private theorem leaf_table : P.card=5 ∧ P⊆palette ∧ 0∉P ∧ allowedPairs.card=4 ∧
    (states.all fun v => (List.finRange 7).all fun a => decide (shape (v++[a])))=true := by
  native_decide

private theorem local_geometry {e : Block} (size : e.length=7) : shape e := by
  by_cases good : full (src e)
  · obtain ⟨x,eq⟩ : ∃x : Fin 7, e=src e++[x] := by
      have nn : e≠[] := by intro he; simp [he] at size
      refine ⟨e.getLast nn,?_⟩
      have six : src e=e.dropLast := by simp [src,List.dropLast_eq_take,size]
      rw [six]; exact (List.dropLast_concat_getLast nn).symm
    have table := List.all_eq_true.mp leaf_table.2.2.2.2 _ (mem_states good)
    have ok := of_decide_eq_true (List.all_eq_true.mp table x (List.mem_finRange _))
    rwa [←eq] at ok
  · have zero : ca e=0 := by simp [ca,oldColor,good]
    intro _
    exact ⟨fun pair => leaf_table.2.2.1 (zero ▸ pair.1),fun _ => Or.inl zero⟩

private theorem erase_at_least (F : Finset ℕ) (c : ℕ) : F.card-1 ≤ (F.erase c).card := by
  by_cases hit : c∈F
  · have := Finset.card_erase_add_one hit; omega
  · rw [Finset.erase_eq_of_notMem hit]; omega

private theorem ends_covered {Y : Multiset Block} {s t : Block} (h : Feasible Y s t) :
    palette.erase (oldColor t) ⊆ (crossings Y).image ca ∧
    palette.erase (oldColor s) ⊆ (crossings Y).image cb := by
  have bal : (required+Y).map src+{t}=(required+Y).map dst+{s} := by
    have rb : required.map src=required.map dst := balanced_representatives
    rw [Multiset.map_add,Multiset.map_add,rb,add_assoc,add_assoc,h.balance]
  obtain ⟨es,bag,route⟩ := exists_route src dst (required+Y) s t bal h.reachable
  constructor
  · intro c hc
    obtain ⟨off,hit⟩ := Finset.mem_erase.mp hc
    obtain ⟨p,hp,cp⟩ := List.mem_map.mp (List.mem_toFinset.mp hit)
    have vis : p∈es := by
      change p∈(↑es : Multiset Block); rw [bag]; exact Multiset.mem_add.mpr (Or.inl hp)
    by_contra absent
    let S : Set Block := {v | oldColor v=c}
    have step (e) (he : e∈es) (hs : src e∈S) : dst e∈S := by
      have all : e∈required+Y := bag ▸ (show e∈(↑es : Multiset Block) from he)
      rcases Multiset.mem_add.mp all with req|extra
      · exact (old_data.2.1 _ req).symm.trans hs
      · by_contra out
        have neq : ca e≠cb e := fun eq => out (show cb e=c from eq ▸ hs)
        exact absent (Finset.mem_image.mpr ⟨e,
          Finset.mem_filter.mpr ⟨Multiset.mem_toFinset.mpr extra,neq⟩,hs⟩)
    exact off (terminal route S step ⟨_,vis,cp⟩).symm
  · intro c hc
    obtain ⟨off,hit⟩ := Finset.mem_erase.mp hc
    obtain ⟨p,hp,cp⟩ := List.mem_map.mp (List.mem_toFinset.mp hit)
    by_contra absent
    let S : Set Block := {v | oldColor v≠c}
    have root : s∈S := Ne.symm off
    have step (e) (he : e∈required+Y) (hs : src e∈S) : dst e∈S := by
      rcases Multiset.mem_add.mp he with req|extra
      · exact fun eq => hs ((old_data.2.1 _ req).trans eq)
      · intro same
        have neq : ca e≠cb e := fun eq => hs (eq.trans same)
        exact absent (Finset.mem_image.mpr ⟨e,
          Finset.mem_filter.mpr ⟨Multiset.mem_toFinset.mpr extra,neq⟩,same⟩)
    exact h.reachable S root step p (Multiset.mem_add.mpr (Or.inl hp)) cp

/-- The five satellite colors demand at least eight incoming or outgoing
incidences altogether. Only four different noncentral links are available
to them. With just 34 distinct crossings, source, target, and unordered
pair would all be injective; the central color could supply only two more. -/
theorem repair_needs_35_new_types {Y : Multiset Block} {s t : Block} (h : Feasible Y s t) :
    35 ≤ (Y.toFinset \ Dense462.RankTight.X.toFinset).card := by
  classical
  let K := crossings Y
  apply le_trans (b:=K.card) _ (Finset.card_le_card cross_fresh)
  by_contra! small
  have source := (ends_covered h).1
  have dest := (ends_covered h).2
  have injAt (f : Block → ℕ) (v : ℕ) (cover : palette.erase v ⊆ K.image f) :
      Set.InjOn f (K:Set Block) := by
    have m := Finset.card_le_card cover
    have n := erase_at_least palette v
    rw [old_data.1] at n
    apply Finset.injOn_of_card_image_eq
    exact le_antisymm Finset.card_image_le (by omega)
  have ia := injAt ca _ source
  have ib := injAt cb _ dest
  have ie : Set.InjOn endpoints (K:Set Block) := by
    apply Finset.injOn_of_card_image_eq
    have many : 34≤(K.image endpoints).card := thirty_four_links h
    exact le_antisymm Finset.card_image_le (by omega)
  let left := K.filter (fun e => ca e∈P)
  let right := K.filter (fun e => cb e∈P)
  have demand (f : Block→ℕ) (v : ℕ) (cover : palette.erase v ⊆ K.image f) :
      4 ≤ (K.filter fun e => f e∈P).card := by
    have inner : P.erase v ⊆ (K.filter (fun e => f e∈P)).image f := by
      intro c hc
      obtain ⟨ne,cp⟩ := Finset.mem_erase.mp hc
      obtain ⟨e,ek,eq⟩ := Finset.mem_image.mp (cover (Finset.mem_erase.mpr ⟨ne,leaf_table.2.1 cp⟩))
      exact Finset.mem_image.mpr ⟨e,Finset.mem_filter.mpr ⟨ek,eq ▸ cp⟩,eq⟩
    have bound := erase_at_least P v
    rw [leaf_table.1] at bound
    exact bound.trans ((Finset.card_le_card inner).trans Finset.card_image_le)
  have needL : 4≤left.card := demand ca _ source
  have needR : 4≤right.card := demand cb _ dest
  have geom (e) (he : e∈K) :=
    local_geometry (h.edges_seven e (Multiset.mem_toFinset.mp (Finset.mem_filter.mp he).1))
      (Finset.mem_filter.mp he).2
  have dis : Disjoint left right := Finset.disjoint_left.mpr (by
    intro e hl hr
    exact (geom e (Finset.mem_filter.mp hl).1).1 ⟨(Finset.mem_filter.mp hl).2,(Finset.mem_filter.mp hr).2⟩)
  let A := K.filter (fun e => ca e=0)
  let B := K.filter (fun e => cb e=0)
  let E := K.filter (fun e => endpoints e∈allowedPairs)
  have central (f : Block→ℕ) (inj : Set.InjOn f (K:Set Block)) :
      (K.filter fun e => f e=0).card≤1 := by
    apply Finset.card_le_one.mpr
    intro x hx y hy
    obtain ⟨xk,x0⟩ := Finset.mem_filter.mp hx
    obtain ⟨yk,y0⟩ := Finset.mem_filter.mp hy
    exact inj xk yk (x0.trans y0.symm)
  have a : A.card≤1 := central ca ia
  have b : B.card≤1 := central cb ib
  have fixed : E.card≤4 := by
    have img : E.image endpoints ⊆ allowedPairs := by
      rintro x hx
      obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp hx
      exact (Finset.mem_filter.mp he).2
    have same := Finset.card_image_of_injOn (s:=E) (f:=endpoints)
      (fun x hx y hy eq => ie (Finset.mem_filter.mp hx).1 (Finset.mem_filter.mp hy).1 eq)
    rw [←leaf_table.2.2.2.1,←same]
    exact Finset.card_le_card img
  have incl : left∪right ⊆ (A∪B)∪E := by
    intro e he
    have ch : e∈K ∧ (ca e∈P ∨ cb e∈P) := by
      rcases Finset.mem_union.mp he with hl|hr
      · exact ⟨(Finset.mem_filter.mp hl).1,Or.inl (Finset.mem_filter.mp hl).2⟩
      · exact ⟨(Finset.mem_filter.mp hr).1,Or.inr (Finset.mem_filter.mp hr).2⟩
    rcases (geom e ch.1).2 ch.2 with za|zb|pair
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨ch.1,za⟩))
    · exact Finset.mem_union_left _ (Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨ch.1,zb⟩))
    · exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨ch.1,pair⟩)
  have cap := Finset.card_le_card incl
  rw [Finset.card_union_of_disjoint dis] at cap
  have cap1 := Finset.card_union_le A B
  have cap2 := Finset.card_union_le (A∪B) E
  omega

#print axioms repair_needs_35_new_types
end Dense462.RankTight.Neighborhood

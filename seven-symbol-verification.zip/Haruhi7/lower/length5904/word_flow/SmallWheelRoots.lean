import RunSpelling
import TwinAt859
import NearHundredShape
namespace ExactWordFlow.WheelDemand
open SevenWordWindows ResidualDensity ForcedRuns WeightedMarks DirectedEuler ResidualIncidence ResidualRoutes RotationComponentCount
open private initial start from MarkedDensity
open private upper read from TwinAt859
open private select from RouteDensity
open private partition from HundredDecomposition
open private rank_partition hits Cost local_rank from NearHundredShape
open scoped Classical

private theorem pairedBudget : ∀n : Fin 860,
    upper n.val initial+115*min 85 ((859-n.val)/6)≤16483 := by native_decide

theorem wheel_marks {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] (w : Walk u) (h : Marked u p)
    (i n N : Nat) (many:N≤85) (budget:n+6*N≤859) (needed:720≤count p i n+5*N) :
    22080≤380*endings six [] (mask p i n)+111*N ∧ 20≤endings twin [] (mask p i n) := by
  have root:=(marks w h i n).1
  have width:(mask p i n).length=n:=by simp [mask]
  have tight:=read [] (mask p i n) initial (by omega) start.1 (by simp [start.2.1])
    (by simpa using MarkedGeometry.safe w h i n)
  rw [width,MarkedGeometry.mark_count] at tight
  have cap:=pairedBudget ⟨n,by omega⟩
  change upper n initial+115*min 85 ((859-n)/6)≤16483 at cap
  omega

/-- For every wheel-only residual assembly up to 85 wheels the actual open
spelling necessarily includes at least twenty adjacent pairs of complete
six-rows, even though the number of classes it must visit falls with N. -/
theorem wheel_only {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤858)
    (many:(occupied X s).card≤85) (wheels:∀q∈occupied X s,(part X q).card=6) :
    let N:=(occupied X s).card
    ∃es,Route src dst s es t ∧ (↑es : Multiset Block)=part X (label X s) ∧
      ∃T P, Realized s es T P ∧ 22080≤380*T+111*N ∧ 20≤P := by
  classical
  let Q:=occupied X s
  let home:=label X s
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨as',bt'⟩:=ends.1 rfl
  subst a;subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have sizeEq : (∑q∈Q,Cost X q)=6*Q.card:=by
    calc _ = ∑_∈Q,6 := Finset.sum_congr rfl wheels
         _ = _ := by simp [Nat.mul_comm]
  have mass:=congrArg Multiset.card (partition X s)
  simp only [Multiset.card_add,Multiset.card_sum] at mass
  change X.card=Cost X home+∑q∈Q,Cost X q at mass
  rw [sizeEq] at mass
  have rank:=rank719 _ h (fun _ he=>on_edge he)
  change 719 ≤ separateRank X s at rank
  rw [rank_partition h] at rank
  change 719≤hits X s home-1+∑q∈Q,(hits X s q-1) at rank
  have small (q) (hq:q∈Q) : hits X s q-1≤5:=by
    have p:=local_rank h q hq
    have six:Cost X q=6:=wheels q hq
    rw [six] at p
    omega
  have agg:=Finset.sum_le_sum small
  simp only [Finset.sum_const,smul_eq_mul] at agg
  have incl:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  obtain ⟨u,w,hu,hk,actual⟩:=route_walk r wd
  obtain ⟨I,hI,cnt⟩:=select u (es.length+1)
  rw [actual] at cnt
  change count (·∈I) 0 (es.length+1)=classCount s es at cnt
  change Q.card≤85 at many
  obtain ⟨x,y⟩:=wheel_marks w hI 0 (es.length+1) Q.card many (by omega) (by omega)
  exact ⟨es,r,bag,_,_,⟨u,I,0,es.length+1,w,actual,Or.inl (by omega),hI,cnt,rfl,rfl⟩,x,y⟩

#print axioms wheel_only
end ExactWordFlow.WheelDemand

import NoNearHundred
import ShortBudget95
import NearWheelBinding
import HardWheelProofs
import OrientedCNF

namespace ExactWordFlow.NinetyFive
open SevenWordWindows SuperpermutationBounds RotationComponentCount RotationCore
open ResidualDensity ExtremalRealizations ExtremeWheelCut

private theorem bound_from_families {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858)
    (ruled : ∀N,96≤N → N≤98 → ∀R∈realizations (NearExtrema.profiles N),
      ∀W⊆allRows,W.card≤N → ¬SeedWheelCut.ClosedCover R allClasses W) : (occupied X s).card≤95 := by
  have hi:=NoNearHundred.component_limit h budget
  by_contra! many
  obtain ⟨R,which,W,sub,size,closed⟩:=NoNearHundred.cover_certificate h budget rfl many
  exact ruled _ many hi R which W sub size closed

/-- No selection of 96 through 100 nonroot six-wheels can complete the
tight residual incidence tree. The hard-root proofs are checked against
the concrete CNF; the shorter seed certificates cover all other roots. -/
theorem component_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) : (occupied X s).card≤95 := by
  apply bound_from_families h budget
  intro N lo hi R geo W legal size covers
  obtain ⟨r,hard,w,rows,small,actual,cover⟩:=NearWheelBinding.exhaust lo hi geo legal size covers
  have tight : r.card+5*w.card≤allClasses.card := by rw [board,actual]; omega
  exact OrientedCNF.no_cover rows tight (HardWheelProofs.hard_unsat lo hi hard) cover

theorem exact_1529 :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
      ∃v : Block,6≤v.length ∧ v.length≤1529 ∧ (visited v).card=720 ∧ 95≤(complete v).card :=
  ComponentCurve.exact_threshold (k:=95) (m:=95) (@component_limit) (by decide) (by decide)

theorem completion_curve (k : Nat) (lo : 95≤k) (hi : k≤720) :
    IsLeast (lengthsFor k) (SuperpermBridge.HR.Ssuper 7-7*(720-k)) :=
  ComponentCurve.completion_curve (@component_limit) k (by omega) lo hi

theorem asked_iff :
    (∃v : Block,6≤v.length ∧ v.length≤1823 ∧ (visited v).card=720 ∧ 137≤(complete v).card) ↔
      ∃v : Block,6≤v.length ∧ v.length≤1529 ∧ (visited v).card=720 ∧ 95≤(complete v).card :=
  RotationCore.exact_1823.symm.trans exact_1529

/-- With the published 5,901 lower bound as an explicit premise, the
single 95-completion decision has only four remaining attainable lengths. -/
theorem exact_with_floor (floor : Transfer5901.WordFloor 5901) :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
      ∃v : Block,1526≤v.length ∧ v.length≤1529 ∧ (visited v).card=720 ∧ (complete v).card=95 := by
  rw [exact_1529]
  constructor
  · rintro ⟨v,long,lim,all,done⟩
    have bounds:=ShortBudget95.floor_transfer floor long lim all done
    exact ⟨v,bounds.1,lim,all,bounds.2⟩
  · rintro ⟨v,low,lim,all,done⟩
    exact ⟨v,by omega,lim,all,done.ge⟩

#print axioms component_limit
#print axioms exact_1529
#print axioms completion_curve
#print axioms asked_iff
#print axioms exact_with_floor
end ExactWordFlow.NinetyFive

import ExtremeWheelCut
import NearHardRoots

namespace ExactWordFlow.NearRootMoves
open SevenWordWindows SeedWheelCut ExtremeWheelCut

/-- Indices 0 through 5 swap adjacent symbol values, 6 reverses the cycle,
and 7 adds one to every symbol modulo seven. Cycles are reoriented at zero. -/
def move (i : Fin 8) (c : Block) : Block :=
  if i.val=6 then classKey c.reverse
  else if i.val=7 then classKey (c.map (·+1))
  else classKey (c.map (fun a => if a.val=i.val then a+1 else if a.val=i.val+1 then a-1 else a))

private theorem catalog : ∀i : Fin 8, allClasses.image (move i)=allClasses ∧
    ∀w∈allRows, w.image (move i)∈allRows := by native_decide

/-- Transport connectivity itself, allowing intermediate wheels to meet
one another. This only requires surjectivity on the finite label board. -/
private theorem step {R : Finset Block} {W : Finset (Finset Block)}
    (legal : W⊆allRows) (covered : ClosedCover R allClasses W) (i : Fin 8) :
    let W' := W.image (Finset.image (move i))
    W'⊆allRows ∧ W'.card≤W.card ∧ ClosedCover (R.image (move i)) allClasses W' := by
  let g := move i
  obtain ⟨onto,images⟩ := catalog i
  refine ⟨?_,Finset.card_image_le,?_⟩
  · intro w hw; obtain ⟨q,hq,rfl⟩:=Finset.mem_image.mp hw; exact images q (legal hq)
  · intro C init closed
    let P := (R∪allClasses∪W.biUnion id).filter (fun x=>g x∈C)
    have seed : R⊆P := fun c hc=>Finset.mem_filter.mpr
      ⟨Finset.mem_union_left _ (Finset.mem_union_left _ hc),init (Finset.mem_image_of_mem g hc)⟩
    have stable (q) (hq : q∈W) (meet : (P∩q).Nonempty) : q⊆P := by
      obtain ⟨a,hm⟩:=meet
      obtain ⟨hp,ha⟩:=Finset.mem_inter.mp hm
      have enters : (C∩q.image g).Nonempty := ⟨g a,Finset.mem_inter.mpr
        ⟨(Finset.mem_filter.mp hp).2,Finset.mem_image_of_mem _ ha⟩⟩
      intro x hx
      exact Finset.mem_filter.mpr ⟨Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨q,hq,hx⟩),
        closed _ (Finset.mem_image_of_mem _ hq) enters (Finset.mem_image_of_mem _ hx)⟩
    have full := covered P seed stable
    intro x hx
    rw [←onto] at hx
    obtain ⟨a,ha,rfl⟩:=Finset.mem_image.mp hx
    exact (Finset.mem_filter.mp (full ha)).2

def applyMoves (ops : List (Fin 8)) (R : Finset Block) :=
  ops.foldl (fun S i=>S.image (move i)) R

theorem transport {R : Finset Block} {W : Finset (Finset Block)}
    (legal : W⊆allRows) (covered : ClosedCover R allClasses W) (ops : List (Fin 8)) :
    ∃W' : Finset (Finset Block), W'⊆allRows ∧ W'.card≤W.card ∧
      ClosedCover (applyMoves ops R) allClasses W' := by
  induction ops generalizing R W with
  | nil => exact ⟨W,legal,le_rfl,covered⟩
  | cons i ops ih =>
    obtain ⟨allowed,size,next⟩:=step legal covered i
    obtain ⟨V,hV,small,h⟩:=ih allowed next
    exact ⟨V,hV,small.trans size,h⟩

#print axioms transport
end ExactWordFlow.NearRootMoves

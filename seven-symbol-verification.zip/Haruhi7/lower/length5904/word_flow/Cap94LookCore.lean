import Cap94Rows

namespace ExactWordFlow.Cap94Lookup
open SevenWordWindows RotationCore NearRootMoves
open Cap94Catalog

def boardList := allClasses.sort (· ≤ ·)
def board := boardList.toArray
def reverseIndex : Std.HashMap Block Nat := Id.run do
  let mut map : Std.HashMap Block Nat := {}
  for i in [:board.size] do map:=map.insert board[i]! i
  return map

def code (c : Block) := reverseIndex.getD c 720
def known (c : Block) : Bool := board[code c]? == some c
def shift (j : Nat) (c : Block) :=
  (List.replicate j (7 : Fin 8)).foldl (fun z i => move i z) c

def masks : Std.HashMap Block (Array Nat) := Id.run do
  let mut table : Std.HashMap Block (Array Nat) := {}
  for c in board do
    table:=table.insert c ((List.range 7).map (fun j=>2^(code (shift j c)))).toArray
  return table

def bit (j : Nat) (c : Block) := ((masks[c]?.getD #[])[j]?).getD (2^720)
def bits (j : Nat) (R : Finset Block) := R.fold (β:=Nat) (fun (x y : Nat) => x ||| y) 0 (bit j)
def seeds := rows.map (fun p=>visited p.1)
def keys := seeds.map (fun R=>((List.range 7).map (fun j=>bits j R)).toArray)
def lookup : Std.HashMap Nat (Nat × Nat) := Id.run do
  let mut lut : Std.HashMap Nat (Nat × Nat) := {}
  for i in [:keys.size] do
    let key:=keys[i]!
    for j in [:key.size] do lut:=lut.insert key[j]! (i,j)
  return lut

def accept (R : Finset Block) : Bool :=
  let b:=bits 0 R
  let (i,j):=lookup.getD b (rows.size,7)
  decide (i<rows.size ∧ j<7 ∧ (keys[i]!)[j]! = b ∧ ∀c∈R,known c=true)

end ExactWordFlow.Cap94Lookup

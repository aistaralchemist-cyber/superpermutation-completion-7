import LocalDeletion

namespace ExactWordFlow.LapEditCost
open SevenWordWindows LocalDeletion

/-- Left flank is stored nearest letter first. Any selected witness p identifies
a rotation with just one surviving visit before editing the contracted record. -/
def rejects (left : Block) (x : Fin 7) (right : Block) (seen : List Block) : Bool :=
  let before := left.reverse++[x]++right
  let after := left.reverse++right
  (good after).length < (good before).length ||
    seen.any fun p=>
      let l:=(left.take 5).reverse
      let r:=right.take 5
      freq6 (l++r) (classKey p) < freq6 (l++[x]++r) (classKey p)

theorem dichotomy (l : Block) (x : Fin 7) (r : Block) (seen : List Block)
    (h : rejects (l.reverse.take 6) x (r.take 6) seen=true) :
    (good (l++r)).length < (good (l++[x]++r)).length ∨
      ∃p∈seen, freq6 (l++r) (classKey p) < freq6 (l++[x]++r) (classKey p) := by
  have model (n : Nat) : (l.reverse.take n).reverse=lastPart n l := by
    simp [List.reverse_take,lastPart]
  unfold rejects at h
  simp only [Bool.or_eq_true,decide_eq_true_eq,List.any_eq_true,List.take_take,
    show min 5 6=5 by decide,model] at h
  rcases h with small|⟨p,hm,loss⟩
  · have eq:=clean7_length l x r
    simp only [localPart,List.append_nil] at eq
    exact Or.inl (by omega)
  · have eq:=visit6_count l x r (classKey p)
    simp only [localPart,List.append_nil] at eq
    exact Or.inr ⟨p,hm,by omega⟩

end ExactWordFlow.LapEditCost

import CompactCertificate

open ExactWordFlow.CompactWordCircuit Std.Tactic.BVDecide

/-- The default case reconstructs the entire strengthened formula from the Lean
emitter. The smaller instance is kept as a fast positive control for this checker. -/
def main (args : List String) : IO UInt32 := do
  let [mode,path] := args | throw (IO.userError "expected full|control certificate.lrat")
  let t ← match mode with
    | "full" => pure (compact 7 1501 91 true)
    | "control" => pure (compact 3 8 2 false)
    | _ => throw (IO.userError "unknown instance")
  let f := checkerFormula t
  IO.println s!"variables={t.vars} clauses={f.clauses.size}"
  let steps ← LRAT.loadLRATProof path
  IO.println s!"LRAT actions={steps.size}"
  if LRAT.check steps f then
    IO.println "LRAT.check=true"
    return 0
  IO.eprintln "LRAT.check=false"
  return 1

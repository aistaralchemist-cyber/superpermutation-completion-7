import CompactGateLaws

namespace ExactWordFlow.CompactWordCircuit

def assertRows (es : List Event) := es.filterMap fun e=>
  match e with | .assertion xs=>some xs | _=>none

def Reports (m : M α) (f : α → List (List W)) := ∀st,
  assertRows ((m st).2.body.toList.drop st.body.size) = f (m st).1

theorem report_pure (a : α) : Reports (pure a) (fun _=>[]) := by
  intro st
  change assertRows (st.body.toList.drop st.body.toList.length) = []
  rw [List.drop_length]
  rfl

private theorem no_rows {es : List Event} (quiet : ∀e∈es,IsGate e) : assertRows es=[] := by
  induction es with
  | nil => rfl
  | cons e es ih =>
    have h:=ih (fun f hf=>quiet f (List.mem_cons_of_mem _ hf))
    have head:=quiet e List.mem_cons_self
    cases e <;> simp_all [assertRows,IsGate]

theorem report_quiet {m : M α} (quiet : Quiet m) : Reports m (fun _=>[]) :=
  fun st=>no_rows (quiet st)

theorem report_bind {m : M α} {k : α → M β} {f : α → List (List W)} {q : β → List (List W)}
    (gm : Grows m) (gk : ∀a,Grows (k a)) (hm : Reports m f)
    (hk : ∀a,∀st,f a ++ assertRows ((k a st).2.body.toList.drop st.body.size) = q (k a st).1) :
    Reports (m >>= k) q := by
  intro st
  obtain ⟨ea,ra,na⟩:=gm st
  obtain ⟨eb,rb,nb⟩:=gk (m st).1 (m st).2
  change assertRows (((k (m st).1 (m st).2).2.body.toList).drop st.body.size) = _
  rw [rb,ra,List.append_assoc,← Array.length_toList, List.drop_left]
  have a:=hm st
  rw [ra,← Array.length_toList,List.drop_left] at a
  have b:=hk (m st).1 (m st).2
  rw [rb,← Array.length_toList,List.drop_left] at b
  rw [←a] at b
  change assertRows (ea++eb) = q (k (m st).1 (m st).2).1
  simpa [assertRows,List.filterMap_append] using b

theorem no_report_bind {m : M α} {k : α → M β} {q : β → List (List W)}
    (gm : Grows m) (gk : ∀a,Grows (k a)) (hm : Reports m (fun _=>[]))
    (hk : ∀a, Reports (k a) q) : Reports (m >>= k) q :=
  report_bind gm gk hm (fun a st=>by simpa using hk a st)

theorem insist_grows (xs : List W) : Grows (insist xs) := by
  intro st
  exact ⟨[.assertion xs],Array.toList_push,rfl⟩

theorem insist_reports (xs : List W) : Reports (insist xs) (fun _=>[xs]) := by
  intro st
  change assertRows ((st.body.push (.assertion xs)).toList.drop st.body.size) = _
  simp [assertRows]

theorem insist_gives {T : Test} (xs : List W) : Gives T (insist xs) (fun _=>True) := fun _ _=>trivial

theorem no_reports_map {f : α → M β} (growth : ∀x,Grows (f x)) (silent : ∀x,Reports (f x) (fun _=>[])) :
    ∀xs : List α, Reports (xs.mapM f) (fun _=>[])
  | [] => report_pure _
  | a::as => by
    rw [List.mapM_cons]
    exact no_report_bind (growth a) (fun _=>bind_grows (mapList_grows growth as) (fun _=>pure_grows _))
      (silent a) (fun _=>no_report_bind (mapList_grows growth as) (fun _=>pure_grows _)
      (no_reports_map growth silent as) (fun _=>report_pure _))

end ExactWordFlow.CompactWordCircuit

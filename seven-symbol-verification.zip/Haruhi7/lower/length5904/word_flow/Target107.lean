import NinetyFive
import LapBudget

namespace ExactWordFlow.Target107
open SevenWordWindows SuperpermutationBounds RotationCore

/-- A universal bound on the actual number of complete classes of a word.
The quantifier covers even words shorter than one six-letter context. -/
def ceiling (lengthLimit countLimit : Nat) : Prop :=
  ∀ v : Block, v.length≤lengthLimit → (visited v).card=720 → (complete v).card≤countLimit

private theorem neg_witness (m k : Nat) :
    ceiling m k ↔ ¬ ∃ v : Block, 6 ≤ v.length ∧ v.length ≤ m ∧ (visited v).card=720 ∧ k+1 ≤ (complete v).card := by
  constructor
  · rintro upper ⟨v,_,small,all,larger⟩
    have lim:=upper v small all
    omega
  · intro exclude v small all
    by_contra! larger
    have floor:=LapSkeleton.completed_floor v
    have space : (good v).length≤v.length-6 := by rw [←windows_length]; exact List.length_filter_le ..
    exact exclude ⟨v,by omega,small,all,larger⟩

/-- The original universal claim, with the exact N=7 optimum as its
necessary and sufficient condition. The concrete 5905 word gives the upper bound. -/
theorem goal_iff_minimum : ceiling 1620 107 ↔ SuperpermBridge.HR.Ssuper 7=5905 := by
  rw [neg_witness]
  change (¬∃v : Block, 6 ≤ v.length ∧ v.length≤1620 ∧ (visited v).card=720 ∧ 108≤(complete v).card) ↔ _
  rw [←exact_1620]
  have attainable:=SuperpermBridge.ssuper_le_length SuperpermLowerBounds.LengthBudget.Word5905.covers
  rw [SuperpermLowerBounds.LengthBudget.Word5905.length_5905] at attainable
  constructor
  · intro no
    obtain ⟨w,yes,len⟩:=SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
    by_contra! unequal
    exact no ⟨w,yes,by omega⟩
  · rintro val ⟨w,yes,short⟩
    have best:=SuperpermBridge.ssuper_le_length yes
    omega

/-- Both caps refer to all words, with no fixed endpoints, path order, or record. -/
theorem goal_iff_smaller : ceiling 1620 107 ↔ ceiling 1529 94 := by
  rw [neg_witness 1620 107,neg_witness 1529 94]
  exact not_congr (RotationCore.exact_1620.symm.trans NinetyFive.exact_1529)

theorem witnesses :
    (∃ v : Block, v.length=1620 ∧ (visited v).card=720 ∧ (complete v).card=107) ∧
    (∃ v : Block, v.length=1529 ∧ (visited v).card=720 ∧ (complete v).card=94) := by
  constructor
  · exact ⟨RotationCoreControls.coreTruncated 612,by simpa [RotationCoreControls.summary]
      using reference612.2⟩
  · exact ⟨RotationCoreControls.coreTruncated 625,by simpa [RotationCoreControls.summary]
      using ShortBudget95.reference625.2⟩

#print axioms goal_iff_minimum
#print axioms goal_iff_smaller
#print axioms witnesses
end ExactWordFlow.Target107

import GenusContacts
import Mathlib.Tactic

namespace ExactWordFlow.PermutationGenus
open Equiv
variable {X Y : Type*} [DecidableEq X] [DecidableEq Y]

/-- The number of repeated tags within a set of positions. -/
def duplicateTags (tag : X→Y) (s : Finset X) := s.card - (s.image tag).card

/-- Adding a set that intersects the earlier positions in an injectively tagged
boundary cannot erase any of the already charged duplicate-tag deficit. -/
theorem duplicate_join (tag : X→Y) (s t : Finset X)
    (boundary : (s∩t).card=((s∩t).image tag).card) :
    duplicateTags tag s + duplicateTags tag t ≤ duplicateTags tag (s∪t) := by
  classical
  have pos₁ : (s.image tag).card ≤ s.card := Finset.card_image_le
  have pos₂ : (t.image tag).card ≤ t.card := Finset.card_image_le
  have card := Finset.card_union_add_card_inter s t
  have imgs := Finset.card_union_add_card_inter (s.image tag) (t.image tag)
  have sub : (s∩t).image tag ⊆ s.image tag ∩ t.image tag := by
    intro j hj
    obtain ⟨x,mem,rfl⟩:=Finset.mem_image.mp hj
    obtain ⟨left,right⟩:=Finset.mem_inter.mp mem
    exact Finset.mem_inter.mpr ⟨Finset.mem_image_of_mem _ left,Finset.mem_image_of_mem _ right⟩
  have lim := Finset.card_le_card sub
  unfold duplicateTags
  rw [Finset.image_union]
  omega

def mergedCells : List (Finset X) → Finset X
  | []=>∅
  | s::rest=>s∪mergedCells rest

/-- A chain of local certificates may share its clean boundary block. -/
def cleanBoundaries (tag : X→Y) : List (Finset X) → Prop
  | []=>True
  | s::rest=> (s∩mergedCells rest).card=((s∩mergedCells rest).image tag).card ∧
    cleanBoundaries tag rest

theorem charge_cells (tag : X→Y) (cells : List (Finset X)) (inside : Finset X)
    (boundary : cleanBoundaries tag cells) (cover : mergedCells cells ⊆ inside) :
    (cells.map (duplicateTags tag)).sum ≤ duplicateTags tag inside := by
  have combine (l : List (Finset X)) (ok : cleanBoundaries tag l) :
      (l.map (duplicateTags tag)).sum ≤ duplicateTags tag (mergedCells l) := by
    induction l with
    | nil => simp [mergedCells,duplicateTags]
    | cons x xs ih =>
        change _ ∧ _ at ok
        simpa only [List.map_cons,List.sum_cons,mergedCells] using
          (Nat.add_le_add_left (ih ok.2) (duplicateTags tag x)).trans
            (duplicate_join tag x _ ok.1)
  have before := combine cells boundary
  let U:=mergedCells cells
  have dis : Disjoint U (inside \ U) := Finset.disjoint_sdiff
  have reuse:=duplicate_join tag U (inside \ U) (by simp [Finset.disjoint_iff_inter_eq_empty.mp dis])
  have unite : U ∪ (inside \ U)=inside := Finset.union_sdiff_of_subset cover
  rw [unite] at reuse
  exact before.trans (le_trans (Nat.le_add_right _ _) reuse)

theorem global_cell_budget [Fintype X] [Fintype Y]
    {R h : Perm X} (seed : X) (oneOrbit : ∀y,(R*h).SameCycle seed y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (cells : Perm X→List (Finset X))
    (bounds : ∀c∈h.cycleFactorsFinset,cleanBoundaries tag (cells c) ∧ mergedCells (cells c)⊆c.support) :
    (∑c∈h.cycleFactorsFinset,((cells c).map (duplicateTags tag)).sum) ≤ 2*g := by
  calc
    _ ≤ ∑c∈h.cycleFactorsFinset,duplicateTags tag c.support :=
      Finset.sum_le_sum (fun c hc =>charge_cells tag _ _ (bounds c hc).1 (bounds c hc).2)
    _ ≤ _ := repeated_contacts seed oneOrbit tag onto rot classes genus

#print axioms global_cell_budget
end ExactWordFlow.PermutationGenus

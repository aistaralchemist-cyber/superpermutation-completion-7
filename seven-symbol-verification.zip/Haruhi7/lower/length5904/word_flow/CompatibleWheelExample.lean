import RouteDensity

namespace CompatibleWheelExample
open ResidualDensity SevenWordWindows ExactWordFlow DirectedEuler

private def ofDigits (s : String) : Six :=
  s.toList.map fun c => ⟨(c.toNat-48)%7, Nat.mod_lt _ (by decide)⟩

def raw := ofDigits "023415023410523410253410235410234510243510245310245130241530241350241305241302541302145302143502143052143025143021543012543015243015423014523014253014235014230514230415230412530412350412305412304512034512043512045312045132041532041352041325041320541320145320143520143250143205143201543210543120543102543105243105423104523104253104235104231504321503421503241503214503215403251403254103254013254031245031240531240351240315240135240153240152340125340123540123450124350124"

def rawCtx : List Six := raw.take 6 :: (windows raw).map dst
def A := touched rawCtx
def wheel (v : Six) := (orbit v).toFinset
def rows : List (Finset Six) := ((states.filter (fun s =>
  (List.range 6).all (fun j => decide (s ≤ s.rotate j)))).map wheel)
def goodRows := rows.filter (fun r => decide ((r ∩ A).card ≤ 1))
def x := tag (ofDigits "125403")
def y := tag (ofDigits "150423")
def z := tag (ofDigits "125043")
def W := wheel (ofDigits "036125")
def V := wheel (ofDigits "043615")

theorem actual_route : Route src dst (raw.take 6) (windows raw) (raw.drop (raw.length-6)) :=
  read_route raw (by decide +kernel)

theorem rows_complete {s : Six} (hs : full s) : wheel s ∈ rows := by
  have ck : states.all (fun s => decide (wheel s ∈ rows))=true := by native_decide
  exact of_decide_eq_true (List.all_eq_true.mp ck s (mem_states hs))

theorem witnessed : raw.length=468 ∧ (windows raw).length=462 ∧ A.card=390 := by native_decide

/-- Every omitted class passes the test that some incident wheel has at most one initial class.
The two named holes each have only one such choice; those choices collide at a third hole. -/
theorem compatible_data :
    rows.length=840 ∧ goodRows.length=183 ∧
    (((allClasses \ A).sort (· ≤ ·)).all (fun v => goodRows.any (fun r => decide (v∈r))))=true ∧
    x∉A ∧ y∉A ∧ z∉A ∧
    goodRows.filter (fun r => decide (x∈r))=[W] ∧
    goodRows.filter (fun r => decide (y∈r))=[V] ∧
    W≠V ∧ z∈W ∧ z∈V ∧ (W∩A).Nonempty ∧ (V∩A).Nonempty := by native_decide

/-- Two distinct attachment points make an overlap of at least two. -/
private theorem two_points {S R : Finset Six} {v b : Six}
    (vs : v∈S) (vr : v∈R) (bs : b∈S) (br : b∈R) (ne : v≠b) :
    2 ≤ (R∩S).card := by
  have sub : ({v,b} : Finset Six) ⊆ R∩S := by
    intro t ht
    simp only [Finset.mem_insert,Finset.mem_singleton] at ht
    rcases ht with rfl|rfl <;> exact Finset.mem_inter.mpr (by constructor <;> assumption)
  simpa [ne] using Finset.card_le_card sub

/-- Each wheel may acquire five new classes at its time of attachment. -/
def tight (s : Finset Six) : List (Finset Six) → Prop
  | [] => True
  | r::rs => (r∩s).card ≤ 1 ∧ tight (s∪r) rs

private theorem initial_small {S : Finset Six} {rs : List (Finset Six)}
    (h : tight S rs) {r : Finset Six} (mem : r∈rs) : (r∩S).card≤1 := by
  induction rs generalizing S with
  | nil => simp at mem
  | cons a rest ih =>
    rcases List.mem_cons.mp mem with rfl|m
    · exact h.1
    · have up := ih h.2 m
      exact (Finset.card_le_card (Finset.inter_subset_inter_left Finset.subset_union_left)).trans up

private theorem no_both {S : Finset Six} {rs : List (Finset Six)} (h : tight S rs)
    {r q : Finset Six} (rq : r≠q) (rm : r∈rs) (qm : q∈rs)
    {v : Six} (vr : v∈r) (vq : v∈q)
    {a b : Six} (ar : a∈r) (as_ : a∈S) (bq : b∈q) (bs : b∈S)
    (va : v≠a) (vb : v≠b) : False := by
  induction rs generalizing S with
  | nil => simp at rm
  | cons z rs ih =>
    by_cases sr : z=r
    · subst z
      have later := (List.mem_cons.mp qm).resolve_left (Ne.symm rq)
      have one := initial_small h.2 later
      have two := two_points (Finset.mem_union_right S vr) vq (Finset.mem_union_left _ bs) bq vb
      omega
    have rtail := (List.mem_cons.mp rm).resolve_left (Ne.symm sr)
    by_cases sq : z=q
    · subst z
      have one := initial_small h.2 rtail
      have two := two_points (Finset.mem_union_right S vq) vr (Finset.mem_union_left _ as_) ar va
      omega
    have qtail := (List.mem_cons.mp qm).resolve_left (Ne.symm sq)
    exact ih h.2 rtail qtail (Finset.mem_union_left _ as_) (Finset.mem_union_left _ bs)

/-- No ordering of compatible six-wheels can add five new classes per wheel
and cover the two specified holes, despite every hole being individually admissible. -/
theorem no_tight_cover (rs : List (Finset Six)) (leg : ∀r∈rs, r∈rows)
    (h : tight A rs) (cover : ∀ c∈allClasses \ A, ∃r∈rs, c∈r) : False := by
  obtain ⟨_,_,_,nx,ny,nz,fx,fy,wv,zw,zv,wa,va⟩ := compatible_data
  have cx : x∈allClasses := by native_decide
  have cy : y∈allClasses := by native_decide
  obtain ⟨r,rm,xr⟩ := cover x (Finset.mem_sdiff.mpr ⟨cx,nx⟩)
  obtain ⟨q,qm,yq⟩ := cover y (Finset.mem_sdiff.mpr ⟨cy,ny⟩)
  have eligible (v : Finset Six) (m : v∈rs) : v∈goodRows := List.mem_filter.mpr
    ⟨leg v m,decide_eq_true (initial_small h m)⟩
  have ww : r∈goodRows.filter (fun t => decide (x∈t)) := List.mem_filter.mpr ⟨eligible r rm,decide_eq_true xr⟩
  have vv : q∈goodRows.filter (fun t => decide (y∈t)) := List.mem_filter.mpr ⟨eligible q qm,decide_eq_true yq⟩
  rw [fx,List.mem_singleton] at ww
  rw [fy,List.mem_singleton] at vv
  subst r;subst q
  obtain ⟨a,ha⟩ := wa
  obtain ⟨b,hb⟩ := va
  obtain ⟨aw,aa⟩ := Finset.mem_inter.mp ha
  obtain ⟨bv,ba⟩ := Finset.mem_inter.mp hb
  exact no_both h wv rm qm zw zv aw aa bv ba (fun e => nz (e ▸ aa)) (fun e => nz (e ▸ ba))

end CompatibleWheelExample
#print axioms CompatibleWheelExample.no_tight_cover

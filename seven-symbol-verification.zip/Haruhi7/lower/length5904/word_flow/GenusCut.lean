import PermutationGenus

namespace ExactWordFlow.PermutationGenus
open Equiv

variable {X : Type*} [Fintype X] [DecidableEq X]

/-- One can cut at a moved tail of maximum actual closed overlap weight.
This works for every cyclic order, including one initially obtained by
taking first occurrences in a word. -/
theorem choose_cut (h : Perm X) (d : X → Nat)
    (nontrivial : h.support.Nonempty) (positive : ∀x, 1 ≤ d x)
    (ordinary : ∀x, d x = 1 ↔ h x = x) :
    ∃cut : X, h cut ≠ cut ∧ ∀other : X,
        (∑x∈Finset.univ.erase cut,d x) ≤ ∑x∈Finset.univ.erase other,d x := by
  classical
  obtain ⟨m,hm⟩ := nontrivial
  have nonempty : (Finset.univ : Finset X).Nonempty := ⟨m,Finset.mem_univ _⟩
  obtain ⟨cut,hcut,high⟩ := Finset.exists_max_image Finset.univ d nonempty
  have low := high m (Finset.mem_univ _)
  have large : d m ≠ 1 := (ordinary m).not.mpr (Perm.mem_support.mp hm)
  have pos := positive m
  have cut_high : d cut ≠ 1 := by omega
  refine ⟨cut,(ordinary cut).not.mp cut_high,?_⟩
  intro other
  have bound := high other (Finset.mem_univ _)
  have hc := Finset.sum_erase_add Finset.univ d hcut
  have ho := Finset.sum_erase_add Finset.univ d (Finset.mem_univ other)
  omega

#print axioms choose_cut
end ExactWordFlow.PermutationGenus

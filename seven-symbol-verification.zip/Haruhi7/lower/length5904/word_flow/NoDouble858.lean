import TightIncidence
import WheelContacts

/-! The same actual 462-edge open route still covers all 720 classes with
66 wheels even when no two chosen wheels meet twice. -/
namespace Dense462.NoDouble
open ExactWordFlow SevenWordWindows ResidualDensity WheelContacts
open Dense462.RankTight.IncidenceMap (wheelIds contexts classList)

private def block (s : String) : Block := s.toList.map fun c => Fin.ofNat 7 (c.toNat-48)
def ids := wheelIds.map (fun s =>
  if s="063421" then "065123" else if s="123465" then "023461" else s)
def wheels := ids.map block
def routes := Dense462.word :: wheels.map (fun s => s++s)
def families := routes.map RankTight.IncidenceMap.labels
def X : Multiset Block := ↑(routes.flatMap windows)
private def oneColor (v : Block) := decide (full v ∧ tag v∈wheel (block "012354"))

/-- Complete coverage, geometry, balance, and rank on an actual 858-edge
placement, with zero double contacts between distinct physical six-wheels. -/
theorem counterprofile : wheels.length=66 ∧ wheels.Nodup ∧
    (∀s∈wheels, s∈bases) ∧
    wheels.Pairwise (fun s t => (wheel s ∩ wheel t).card ≤ 1) ∧
    X.card=858 ∧ X.map src + {Dense462.last}=X.map dst+{Dense462.first} ∧
    (routes.map fun w => (contexts w).toFinset).Pairwise Disjoint ∧
    (RankTight.IncidenceMap.labels Dense462.word).card=390 ∧
    families.toFinset.biUnion id = classList.toFinset ∧
    (families.map fun C => C.card-1).sum=719 := by native_decide

private theorem split_check :
    (∀e∈required+X, oneColor (src e)=oneColor (dst e)) ∧
    block "0123546"∈required ∧ block "0123456"∈required ∧
    oneColor (src (block "0123546"))≠oneColor (src (block "0123456")) := by native_decide

theorem disconnected (s t : Block) : ¬ Feasible X s t := by
  intro h
  let S : Set Block := {v | oneColor v = oneColor s}
  have step (e : Block) (he : e∈required+X) (mem : src e∈S) : dst e∈S :=
    (split_check.1 e he).symm.trans mem
  have every := h.reachable S rfl step
  obtain ⟨hu,hv,different⟩ := split_check.2
  exact different ((every _ (Multiset.mem_add.mpr (Or.inl hu))).trans
    (every _ (Multiset.mem_add.mpr (Or.inl hv))).symm)

#print axioms counterprofile
#print axioms disconnected
end Dense462.NoDouble

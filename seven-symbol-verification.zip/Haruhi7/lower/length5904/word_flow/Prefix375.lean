import CompatiblePackets

namespace ExactWordFlow.Prefix375
open SevenWordWindows SeedWheelCut ExtremeWheelCut ComplementResidue CompatiblePackets
open private digits from ExtremeWheelCut

def prefixTags := ((PlanarScore390.walk.take 375).map classKey).toFinset

private def table : List (Block × Nat) :=
  ([("0143562",1),
   ("0143652",2),
   ("0163425",3),
   ("0256314",4),
   ("0261435",5),
   ("0265314",6),
   ("0314526",7),
   ("0456132",8),
   ("0516342",9),
   ("0526143",10),
   ("0561324",11),
   ("0564321",12),
   ("0654231",13),
   ("0156234",14),
   ("0234156",14),
   ("0341562",14),
   ("0415623",14),
   ("0562341",14),
   ("0623415",14),
   ("0123465",15),
   ("0132465",15),
   ("0134265",15),
   ("0134625",15),
   ("0134652",15),
   ("0213456",15),
   ("0213465",15),
   ("0213645",15),
   ("0216345",15),
   ("0234651",15),
   ("0246513",15),
   ("0251346",15),
   ("0265134",15),
   ("0324651",15),
   ("0342651",15),
   ("0346251",15),
   ("0346512",15),
   ("0346521",15),
   ("0426513",15),
   ("0462513",15),
   ("0465123",15),
   ("0465132",15),
   ("0465213",15),
   ("0512346",15),
   ("0513246",15),
   ("0513426",15),
   ("0513462",15),
   ("0521346",15),
   ("0521364",15),
   ("0521634",15),
   ("0562134",15),
   ("0621345",15),
   ("0625134",15),
   ("0651234",15),
   ("0651324",15),
   ("0651342",15),
   ("0652134",15)] : List (String × Nat)).map (fun (s,c)=>(digits s,c))

private def shade (x : Block) := (table.lookup x).getD 0
private def colors := Finset.range 16

-- Thirteen singleton components and three further blocks of sizes
-- 6, 37, 289 have total residues 13 + 1 + 2 + 4 = 20.
private theorem data :
    prefixTags.card=375 ∧ residue shade colors (allClasses\prefixTags)=20 ∧
    (∀w∈allRows,5≤(w\prefixTags).card → ∃z∈colors,∀x∈w\prefixTags,shade x=z) := by native_decide

/-- Every extension of these 375 tags obeys the same inequality,
independently of the positions of the remaining tags and the wheel order.
In particular a saturated extension needs at least 395 root tags. -/
theorem all_supersets {A : Finset Block} {W : Finset (Finset Block)}
    (inside : prefixTags⊆A) (legal : W⊆allRows) (linked : ClosedCover A allClasses W) :
    395 ≤ A.card+4*(A.card+5*W.card-720) := by
  obtain ⟨n,r,row⟩:=data
  have bound:=partial_bound prefixTags A shade colors inside legal linked
    (fun w hw cap=>by obtain ⟨z,_,all⟩:=row w hw cap; exact ⟨z,all⟩)
  omega

theorem no_completion {A : Finset Block} {W : Finset (Finset Block)}
    (inside : prefixTags⊆A) (legal : W⊆allRows)
    (size : A.card≤390) (budget : W.card≤66) : ¬ClosedCover A allClasses W := by
  intro linked
  have bound:=all_supersets inside legal linked
  omega

#print axioms no_completion
end ExactWordFlow.Prefix375

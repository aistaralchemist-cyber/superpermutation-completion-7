import SevenBlockerCore
import HitColor

namespace ExactWordFlow.SevenBlockerData
theorem join49 : HitColor.chain {root} (ws 49)=true := by decide +native
theorem join59 : HitColor.chain {root} (ws 59)=true := by decide +native
#print axioms join49
#print axioms join59
end ExactWordFlow.SevenBlockerData

import PhaseReturn
import WheelContraction

namespace ExactWordFlow.PlanarTransversal
open Equiv PhaseReturn
variable {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq X] [DecidableEq Y]

/-- An actual connected completion at minimal incidence rank forces one mark
on each physical orbit left by the selected wheels. -/
theorem from_tour (R W J : Perm X) (tag : X→Y) (onto : Function.Surjective tag)
    (rot : ∀x,tag (R x)=tag x) (S : Finset X)
    (width : ∀c∈W.cycleFactorsFinset,c.support.card≤6)
    (mass : S.card+5*W.cycleFactorsFinset.card ≤ Fintype.card Y)
    (off : ∀x∉S,J x=x) (start : X) (hs : start∈S)
    (all : ∀y,((R*W)*J).SameCycle start y) :
    Hits (R*W) S ∧ (∀x∈S,∀y∈S,(R*W).SameCycle x y → x=y) := by
  classical
  obtain ⟨visits,_⟩:=(one_orbit_iff off hs).1 all
  let H:=W.cycleFactorsFinset.image (fun c=>c.support.image tag)
  have narrow (w) (hw:w∈H) : w.card≤6:=by
    obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp hw
    exact Finset.card_image_le.trans (width c hc)
  obtain ⟨f,num,mono⟩:=WheelContraction.colors Finset.univ H narrow
  let col:=f ∘ tag
  have inv (x:X) : col ((R*W) x)=col x := by
    change f (tag (R (W x)))=f (tag x)
    rw [rot]
    by_cases fixed : W x=x
    · rw [fixed]
    · have mv:=Perm.mem_support.mpr fixed
      let c:=W.cycleOf x
      have hc:c∈W.cycleFactorsFinset:=Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr mv
      have h (y:X) (sy:W.SameCycle x y) : tag y∈c.support.image tag:=
        Finset.mem_image_of_mem _ (Perm.mem_support_cycleOf_iff.mpr ⟨sy,mv⟩)
      apply mono _ (Finset.mem_image_of_mem _ hc) _ (h _ (Perm.sameCycle_apply_right.mpr (.refl _ _))) _ (h _ (.refl _ _))
  have it (x:X) (n:Nat) : col (((R*W)^n) x)=col x:=by
    induction n with
    | zero => simp
    | succ n ih => rw [pow_succ',Perm.mul_apply,inv,ih]
  have cover : Finset.univ.image f⊆S.image col:=by
    intro a ha
    obtain ⟨y,_,rfl⟩:=Finset.mem_image.mp ha
    obtain ⟨x,rfl⟩:=onto y
    obtain ⟨n,hit⟩:=visits x
    exact Finset.mem_image.mpr ⟨_,hit,it x n⟩
  have colours:=Finset.card_le_card cover
  have cap:H.card≤W.cycleFactorsFinset.card:=Finset.card_image_le
  simp only [Finset.card_univ] at num
  have tight : (S.image col).card=S.card:=by
    have top: (S.image col).card≤S.card:=Finset.card_image_le
    omega
  refine ⟨visits,fun x hx y hy same=>Finset.injOn_of_card_image_eq tight hx hy ?_⟩
  obtain ⟨n,_,eq⟩:=same.exists_pow_eq'
  rw [←eq,it]

/-- The order of a single exceptional cycle may be replaced arbitrarily.
Changing that order can change the overlap cost. -/
theorem any_order (R W J : Perm X) (tag : X→Y) (onto : Function.Surjective tag)
    (rot : ∀x,tag (R x)=tag x) (S : Finset X)
    (width : ∀c∈W.cycleFactorsFinset,c.support.card≤6)
    (mass : S.card+5*W.cycleFactorsFinset.card ≤ Fintype.card Y)
    (off : ∀x∉S,J x=x) (start : X) (hs : start∈S)
    (all : ∀y,((R*W)*J).SameCycle start y) (K : Perm X)
    (outside : ∀x∉S,K x=x) (one : ∀x∈S,K.SameCycle start x) :
    ∀y,((R*W)*K).SameCycle start y := by
  obtain ⟨visits,unique⟩:=from_tour R W J tag onto rot S width mass off start hs all
  exact transversal outside visits unique hs one

#print axioms from_tour
#print axioms any_order
end ExactWordFlow.PlanarTransversal

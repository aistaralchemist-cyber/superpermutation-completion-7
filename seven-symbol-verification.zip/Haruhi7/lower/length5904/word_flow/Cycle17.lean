import Cycle64
import Packet64

namespace ExactWordFlow.ShortFreshCycle
open DirectedEuler ResidualDensity OnePath66.Packet64

private def scanOne (first cur : Block) (seen : List (Option Block)) (slack len : Nat) : Nat → Bool
  | 0 => decide (cur=first → len≤12)
  | fuel+1 =>
    decide (cur=first → len≤12) &&
    (if mark cur∈seen then
       if slack=0 then true else (List.finRange 7).all fun z =>
         scanOne first (cur.tail++[z]) seen (slack-1) (len+1) fuel
     else (List.finRange 7).all fun z =>
       scanOne first (cur.tail++[z]) (mark cur::seen) slack (len+1) fuel)

private theorem table17 : (starts 6).all (fun s => scanOne s s [] 1 0 17)=true := by native_decide

private def freshCount {α : Type*} [DecidableEq α] (xs seen : List α) :=
  (xs.toFinset \ seen.toFinset).card

private theorem fresh_old {α : Type*} [DecidableEq α] {v : α} (xs seen : List α) (h : v∈seen) :
    freshCount (v::xs) seen=freshCount xs seen := by
  unfold freshCount
  congr 1
  ext x
  simp only [Finset.mem_sdiff,List.mem_toFinset,List.mem_cons]
  aesop

private theorem fresh_new {α : Type*} [DecidableEq α] {v : α} (xs seen : List α) (h : v∉seen) :
    freshCount (v::xs) seen=freshCount xs (v::seen)+1 := by
  have eq : (v::xs).toFinset \ seen.toFinset = insert v (xs.toFinset \ (v::seen).toFinset) := by
    ext x
    simp only [Finset.mem_sdiff,List.mem_toFinset,List.mem_cons,Finset.mem_insert]
    by_cases same : x=v <;> simp_all
  unfold freshCount
  rw [eq,Finset.card_insert_of_notMem]
  simp

private theorem soundOne (first cur : Block) (seen : List (Option Block)) (slack len fuel : Nat)
    (es : List Block) (ok : scanOne first cur seen slack len fuel=true)
    (rt : Route src dst cur es first) (width : ∀e∈es,e.length=7)
    (low : es.length≤freshCount (es.map (mark ∘ src)) seen+slack) (small : es.length≤fuel) :
    len+es.length≤12 := by
  induction fuel generalizing cur seen slack len es with
  | zero =>
    have e : es=[] := List.eq_nil_of_length_eq_zero (by omega)
    subst es
    cases rt
    exact (by simpa using (of_decide_eq_true ok rfl))
  | succ fuel ih =>
    obtain ⟨stop,cont⟩ := Bool.and_eq_true_iff.mp ok
    cases es with
    | nil =>
      cases rt
      simpa using (of_decide_eq_true stop rfl)
    | cons e es =>
      cases rt with
      | cons _ hs tail =>
        subst cur
        obtain ⟨z,_,nxt⟩ := edge_eq (width e List.mem_cons_self)
        have ww (f) (hf : f∈es) := width f (List.mem_cons_of_mem _ hf)
        have n : es.length≤fuel := by simp at small; omega
        change es.length+1≤freshCount (mark (src e)::es.map (mark ∘ src)) seen+slack at low
        by_cases h : mark (src e)∈seen
        · rw [fresh_old _ _ h] at low
          have hs : slack≠0 := by
            have b : freshCount (es.map (mark ∘ src)) seen≤es.length := by
              exact (Finset.card_le_card Finset.sdiff_subset).trans
                ((List.toFinset_card_le _).trans_eq (List.length_map ..))
            omega
          rw [ite_eq_left h,ite_eq_right hs] at cont
          have go := List.all_eq_true.mp cont z (List.mem_finRange _)
          rw [←nxt] at go
          have cap := ih _ _ _ _ _ go tail ww (by omega) n
          simp at cap ⊢; omega
        · rw [fresh_new _ _ h] at low
          rw [ite_eq_right h] at cont
          have go := List.all_eq_true.mp cont z (List.mem_finRange _)
          rw [←nxt] at go
          have cap := ih _ _ _ _ _ go tail ww (by omega) n
          simp at cap ⊢; omega

theorem one_loss_short {s : Block} {es : List Block} (d : Block)
    (r : Route src dst s es s) (ww : ∀e∈es,e.length=7)
    (ne : es≠[]) (small : es.length≤17)
    (near : es.length≤(es.map (project d ∘ src)).toFinset.card+1) : es.length≤12 := by
  let l := es.map (mark ∘ src)
  have form : es.map (project d ∘ src)=l.map (fun o => Option.getD o d) := by
    rw [List.map_map]
    apply List.map_congr_left
    intro e _
    by_cases clean : full (src e) <;> simp [Function.comp_def,project,mark,clean]
  have im : (l.map (fun o => Option.getD o d)).toFinset=l.toFinset.image (fun o => Option.getD o d) := by
    ext x
    simp
  rw [form,im] at near
  have count := Finset.card_image_le (s:=l.toFinset) (f:=fun o => Option.getD o d)
  have len : s.length=6 := by
    cases r with
    | nil => contradiction
    | cons e h _ => rw [←h]; simp [src,ww e List.mem_cons_self]
  have mem := memStarts s
  rw [len] at mem
  have low : es.length≤freshCount (es.map (mark ∘ src)) []+1 := by
    simpa [freshCount,l] using (show es.length≤l.toFinset.card+1 by omega)
  simpa using soundOne s s [] 1 0 17 es (List.all_eq_true.mp table17 s mem) r ww low small

#print axioms one_loss_short
end ExactWordFlow.ShortFreshCycle

import SeedWheelCut

namespace ExactWordFlow.LargeRowParent
open SeedWheelCut

/-- In a connected cover, run all ordinary rows reachable before entering
the large row F. Some point of F is already reachable. The other points of F
may be made seeds without changing the ability of the ordinary rows to span. -/
theorem cut {α : Type*} [DecidableEq α] {A V F : Finset α} {W : Finset (Finset α)}
    (seed : A⊆V) (large : F⊆V) (ne : F.Nonempty) (inside : ∀R∈W,R⊆V)
    (cover : ClosedCover A V (insert F W)) :
    ∃p∈F, ClosedCover (A∪F.erase p) V W := by
  classical
  let D:=V.filter (fun c=>ClosedCover A {c} W)
  have ad : A⊆D:=by
    intro c hc
    apply Finset.mem_filter.mpr
    exact ⟨seed hc,fun C hh _=>Finset.singleton_subset_iff.mpr (hh hc)⟩
  have sealed (R) (hr:R∈W) (meet:(D∩R).Nonempty) : R⊆D := by
    obtain ⟨x,hxr⟩:=meet
    obtain ⟨hx,hR⟩:=Finset.mem_inter.mp hxr
    intro c hc
    apply Finset.mem_filter.mpr
    refine ⟨inside R hr hc,?_⟩
    intro C hA cuts
    have yes: x∈C:=Finset.singleton_subset_iff.mp ((Finset.mem_filter.mp hx).2 C hA cuts)
    exact Finset.singleton_subset_iff.mpr (cuts R hr ⟨x,Finset.mem_inter.mpr ⟨yes,hR⟩⟩ hc)
  have cross : (D∩F).Nonempty := by
    by_contra no
    have total : V⊆D := cover D ad (by
      intro R hr hR
      rcases Finset.mem_insert.mp hr with rfl|hold
      · exact False.elim (no hR)
      · exact sealed R hold hR)
    obtain ⟨c,hc⟩:=ne
    exact no ⟨c,Finset.mem_inter.mpr ⟨total (large hc),hc⟩⟩
  obtain ⟨p,pp⟩:=cross
  obtain ⟨hp,fp⟩:=Finset.mem_inter.mp pp
  refine ⟨p,fp,?_⟩
  intro C incl cuts
  have aC : A⊆C:=Finset.subset_union_left.trans incl
  have pC : p∈C:=Finset.singleton_subset_iff.mp ((Finset.mem_filter.mp hp).2 C aC cuts)
  apply cover C aC
  intro R hr hR
  rcases Finset.mem_insert.mp hr with rfl|old
  · intro c hc
    by_cases same : c=p
    · exact same ▸ pC
    · exact incl (Finset.mem_union_right _ (Finset.mem_erase.mpr ⟨same,hc⟩))
  · exact cuts R old hR

theorem cardinal {α : Type*} [DecidableEq α] {A V : Finset α} {W : Finset (Finset α)}
    (linked : ClosedCover A V W) (width : ∀w∈W,w.card≤6) : V.card≤A.card+5*W.card := by
  obtain ⟨C,sub,cap,cls⟩:=GlobalWheelRank.grow A W
  have count:=Finset.card_le_card (linked C sub cls)
  have low : (∑r∈W,(r.card-1))≤W.card*5 := by
    apply Finset.sum_le_card_nsmul
    intro r hr
    have bound:=width r hr
    omega
  omega

#print axioms cut
end ExactWordFlow.LargeRowParent

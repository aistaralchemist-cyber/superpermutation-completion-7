import PermutationGenus

namespace ExactWordFlow.PermutationGenus

/-- e is the number and M the total length of all non-pure correction
cycles, including the cycle of the free cut. Each of the remaining q cycles
uses six ordinary cost-two switches. Fixing just M,e,s fixes the spelled
length modulo twelve regardless of the wheel placements and endpoints. -/
theorem extension_residue {M e s q g L : Nat}
    (genus : M+6*q=e+q+719+2*g)
    (length : L=5764+e+q+s+2*g) :
    L=5045+M+s+6*q ∧ q%2=(M+e+1)%2 ∧ L%12=(11+7*M+6*e+s)%12 := by
  omega

/-- In fact any two realizations in a band of width less than twelve agree
in length, number of neutral wheels, and genus. -/
theorem unique_nearby_completion {M e s q q' g g' L L' : Nat}
    (genus : M+6*q=e+q+719+2*g) (length : L=5764+e+q+s+2*g)
    (genus' : M+6*q'=e+q'+719+2*g') (length' : L'=5764+e+q'+s+2*g')
    (near : L<L'+12) (near' : L'<L+12) :
    L=L' ∧ q=q' ∧ g=g' := by
  obtain ⟨a,b,c⟩:=extension_residue genus length
  obtain ⟨x,y,z⟩:=extension_residue genus' length'
  omega

/-- A forbidden residue eliminates an entire family of exceptional cycles
when the resulting spelled length lies in the public-floor band. -/
theorem threshold_residues {M e s q g L : Nat}
    (genus : M+6*q=e+q+719+2*g) (length : L=5764+e+q+s+2*g)
    (low : 5901≤L) (high : L≤5904) :
    let t:=(7*M+6*e+s)%12
    t=10 ∨ t=11 ∨ t=0 ∨ t=1 := by
  have h := (extension_residue genus length).2.2
  have h' : L%12=(11+(7*M+6*e+s))%12 := by simpa only [Nat.add_assoc] using h
  dsimp
  generalize 7*M+6*e+s=t at h' ⊢
  clear h genus length
  rw [Nat.add_mod] at h'
  have ht := Nat.mod_lt t (by decide : 0<12)
  have bounds : L=5901 ∨ L=5902 ∨ L=5903 ∨ L=5904 := by omega
  rcases bounds with rfl | rfl | rfl | rfl <;> norm_num at h' <;> omega

#print axioms extension_residue
#print axioms unique_nearby_completion
#print axioms threshold_residues
end ExactWordFlow.PermutationGenus

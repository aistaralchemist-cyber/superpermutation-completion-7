import WheelExchangeFloor

namespace ExactWordFlow.OnePath66
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels ResidualRoutes
open scoped Classical

/-- Fresh steps must absorb the old endpoint imbalance and supply the new one. -/
theorem fresh_endpoints {base fresh : Multiset Block} {a b s t : Block}
    (old : base.map src+{b}=base.map dst+{a})
    (new : (base+fresh).map src+{t}=(base+fresh).map dst+{s}) :
    fresh.map src+{a}+{t}=fresh.map dst+{b}+{s} := by
  apply add_left_cancel (a:=base.map dst)
  rw [Multiset.map_add,Multiset.map_add] at new
  calc
    _ = (base.map dst+{a}) + fresh.map src + {t} := by ac_rfl
    _ = ((base.map src + fresh.map src)+{t}) + {b} := by rw [←old]; ac_rfl
    _ = _ := by rw [new]; ac_rfl

theorem changed_end_incidence {base fresh : Multiset Block} {a b s t : Block}
    (old : base.map src+{b}=base.map dst+{a}) (h : Feasible (base+fresh) s t)
    (different : a≠b) :
    (s≠a → ∃e∈fresh, dst e=a) ∧ (t≠b → ∃e∈fresh, src e=b) := by
  have eq := fresh_endpoints old h.balance
  constructor
  · intro hs
    have atA := congrArg (Multiset.count a) eq
    simp [Multiset.count_singleton,different,hs.symm] at atA
    exact Multiset.mem_map.mp (Multiset.count_pos.mp (by omega : 0<(fresh.map dst).count a))
  · intro ht
    have atB := congrArg (Multiset.count b) eq
    simp [Multiset.count_singleton,different.symm,ht.symm] at atB
    exact Multiset.mem_map.mp (Multiset.count_pos.mp (by omega : 0<(fresh.map src).count b))

/-- Sharp rank leaves no dispensable fresh edge, even if the alternate
connection uses mandatory windows or arbitrarily many kept wheels. -/
theorem every_fresh_is_bridge {a b : Block} {es ws : List Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (classes : classCount a es=390)
    (k : ws.length≤65) {fresh : Multiset Block} (five : fresh.card=5)
    (together : RequiredComponent.ClassesTogether (((↑es : Multiset Block)+turns ws)+fresh))
    {e : Block} (he : e∈fresh) :
    let G := required + (((↑es : Multiset Block)+turns ws)+fresh.erase e)
    label G (src e) ≠ label G (dst e) := by
  classical
  let base := (↑es : Multiset Block)+turns ws
  let G := required+(base+fresh.erase e)
  change label G (src e) ≠ label G (dst e)
  intro alt
  have split : fresh.erase e+{e}=fresh := by
    rw [add_comm,Multiset.singleton_add,Multiset.cons_erase he]
  have eq : required+(base+fresh) = G+{e} := by
    calc
      required+(base+fresh) = required+(base+(fresh.erase e+{e})) := by rw [split]
      _ = G+{e} := by dsimp only [G]; ac_rfl
  have kept : RequiredComponent.ClassesTogether (base+fresh.erase e) := by
    intro c hc d hd
    let S : Set Block := {v | label G v=label G (src c)}
    have stable (f) (hf : f∈required+(base+fresh)) : src f∈S ↔ dst f∈S := by
      rw [eq] at hf
      rcases Multiset.mem_add.mp hf with old|removed
      · change _=_ ↔ _=_
        rw [on_edge old]
      · have fe : f=e := by simpa using removed
        subst f
        change _=_ ↔ _=_
        rw [alt]
    exact ((invariant S stable (together c hc d hd)).mp rfl).symm
  have lo := replacement_floor r legit classes k _ kept
  have card := Multiset.card_erase_add_one he
  omega

/-- A strict replacement of one saturated wheel must change an endpoint
and enter the former start or depart from the former finish. -/
theorem tight_five_endpoint {a b s t : Block} {es ws : List Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (classes : classCount a es=390)
    (k : ws.length≤65) {fresh : Multiset Block} (small : fresh.card<6) (ab : a≠b)
    (kept : ((↑es : Multiset Block)+turns ws).map src+{b}=
      ((↑es : Multiset Block)+turns ws).map dst+{a})
    (h : Feasible (((↑es : Multiset Block)+turns ws)+fresh) s t) :
    (s≠a ∧ ∃e∈fresh,dst e=a) ∨ (t≠b ∧ ∃e∈fresh,src e=b) := by
  have need := changed_end_incidence kept h ab
  by_cases hs : s=a
  · have ht : t≠b := by
      intro ht; subst s; subst t
      have := fixed_endpoint_floor r legit classes k fresh kept h
      omega
    exact Or.inr ⟨ht,need.2 ht⟩
  · exact Or.inl ⟨hs,need.1 hs⟩

/-- If both old endpoints change, their incident fresh steps must
be two distinct edge types: one step straight from b to a would lie inside
the weak component of the retained spine and could not be a bridge. -/
theorem both_ends_need_distinct {a b s t : Block} {es ws : List Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (classes : classCount a es=390)
    (k : ws.length≤65) {fresh : Multiset Block} (five : fresh.card=5) (ab : a≠b)
    (kept : ((↑es : Multiset Block)+turns ws).map src+{b}=
      ((↑es : Multiset Block)+turns ws).map dst+{a})
    (h : Feasible (((↑es : Multiset Block)+turns ws)+fresh) s t) (sa : s≠a) (tb : t≠b) :
    ∃u∈fresh, ∃v∈fresh, dst u=a ∧ src v=b ∧ u≠v := by
  obtain ⟨atA,atB⟩ := changed_end_incidence kept h ab
  obtain ⟨u,hu,du⟩ := atA sa
  obtain ⟨v,hv,sv⟩ := atB tb
  refine ⟨u,hu,v,hv,du,sv,?_⟩
  intro eq
  subst v
  let G := required+(((↑es : Multiset Block)+turns ws)+fresh.erase u)
  have separates := every_fresh_is_bridge r legit classes k five
    ((RequiredComponent.together_iff_classes _).mp (RequiredComponent.feasible_together h)) hu
  change label G (src u) ≠ label G (dst u) at separates
  rw [du,sv] at separates
  apply separates
  refine (r.closed {z | label G z=label G a} rfl ?_).1
  intro f hf same
  have member : f∈G := Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inl
    (Multiset.mem_add.mpr (Or.inl (show f∈(↑es : Multiset Block) from hf))))))
  exact (on_edge member).symm.trans same

#print axioms both_ends_need_distinct
#print axioms changed_end_incidence
#print axioms every_fresh_is_bridge
#print axioms tight_five_endpoint
end ExactWordFlow.OnePath66

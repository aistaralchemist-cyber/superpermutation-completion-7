import ElevenExtensionCaps

namespace ExactWordFlow.SeventeenCaps
open DirectedEuler ResidualDensity SevenWordWindows ResidualControls
open FiveExtensionCaps ElevenExtensionCaps OnePath66

private def allSplits (n : Nat) (gain : Int) := (List.range (n+1)).all fun l =>
  extensionCheck mainWord l (n-l) gain (fun _ => true)

private def closes (w : Block) : Bool := decide (w.drop (w.length-6)=mainWord.take 6)

private theorem bounds :
    ((List.range 18).all fun n => allSplits n 15)=true ∧
    ((List.range 13).all fun i => allSplits (5+i) (5+i : Nat))=true ∧
    ((List.range 18).all fun n => extensionCheck mainWord 0 n ((n : Int)-2) closes)=true := by
  native_decide

private theorem data : 6 ≤ mainWord.length ∧ (extension_classes mainWord).card=390 := by native_decide

private theorem fromSplit (p q : Block) (gain : Int) (check : allSplits (p.length+q.length) gain=true) :
    ((extension_classes (p++mainWord++q)).card : Int) < 390+gain := by
  have tab := List.all_eq_true.mp check p.length (List.mem_range.mpr (by omega))
  have res := extension_check_bound (w:=mainWord) (p:=p) (q:=q) data.1 gain
    (fun _ => true) rfl (by simpa using tab)
  rw [data.2] at res
  exact res

theorem word_cap (p q : Block) (short : p.length+q.length≤17) :
    (extension_classes (p++mainWord++q)).card≤404 := by
  have h := fromSplit p q 15 (List.all_eq_true.mp bounds.1 _ (List.mem_range.mpr (by omega)))
  omega

theorem word_loss (p q : Block) (lo : 5≤p.length+q.length) (hi : p.length+q.length≤17) :
    (extension_classes (p++mainWord++q)).card+1≤390+(p.length+q.length) := by
  let n := p.length+q.length
  have size : 5+(n-5)=p.length+q.length := by dsimp [n]; omega
  have ck := List.all_eq_true.mp bounds.2.1 (n-5) (List.mem_range.mpr (by dsimp [n]; omega))
  rw [size] at ck
  have cap := fromSplit p q _ ck
  omega

theorem word_return (p : Block) (short : p.length≤17)
    (closed : (mainWord++p).drop ((mainWord++p).length-6)=mainWord.take 6) :
    (extension_classes (mainWord++p)).card+3≤390+p.length := by
  have ch := List.all_eq_true.mp bounds.2.2 p.length (List.mem_range.mpr (by omega))
  have cap := extension_check_bound (w:=mainWord) (p:=[]) (q:=p) data.1
    ((p.length : Int)-2) closes (by simpa [closes] using closed) ch
  simp only [List.nil_append,data.2] at cap
  omega

/-- Achieves the exact ceiling with three prefix and fourteen suffix symbols. -/
theorem attained :
    (extension_classes ([6,4,5]++mainWord++[4,5,2,3,1,0,4,2,5,3,1,0,4,2])).card=404 := by
  native_decide

theorem extension_cap {p q : List Block} {s t : Block}
    (rp : Route src dst s p (mainWord.take 6))
    (rq : Route src dst (mainWord.drop (mainWord.length-6)) q t)
    (wp : ∀e∈p,e.length=7) (wq : ∀e∈q,e.length=7)
    (hi : p.length+q.length≤17) :
    (pathClasses s (p++windows mainWord++q)).card≤404 := by
  obtain ⟨u,v,hu,hv,eq,head⟩ := spell_extensions mainWord data.1 rp rq wp wq
  have cap := word_cap u v (by rwa [hu,hv])
  change (pathClasses ((u++mainWord++v).take 6) (windows (u++mainWord++v))).card≤404 at cap
  simpa only [head,eq] using cap

theorem extension_loss {p q : List Block} {s t : Block}
    (rp : Route src dst s p (mainWord.take 6))
    (rq : Route src dst (mainWord.drop (mainWord.length-6)) q t)
    (wp : ∀e∈p,e.length=7) (wq : ∀e∈q,e.length=7)
    (lo : 5≤p.length+q.length) (hi : p.length+q.length≤17) :
    (pathClasses s (p++windows mainWord++q)).card+1≤390+(p.length+q.length) := by
  obtain ⟨u,v,hu,hv,eq,head⟩ := spell_extensions mainWord data.1 rp rq wp wq
  have cap := word_loss u v (by rwa [hu,hv]) (by rwa [hu,hv])
  change (pathClasses ((u++mainWord++v).take 6) (windows (u++mainWord++v))).card+1≤_ at cap
  simpa only [head,eq,hu,hv] using cap

theorem return_cap {p : List Block}
    (rp : Route src dst (mainWord.drop (mainWord.length-6)) p (mainWord.take 6))
    (widths : ∀e∈p,e.length=7) (short : p.length≤17) :
    (pathClasses (mainWord.take 6) (windows mainWord++p)).card+3≤390+p.length := by
  obtain ⟨pre,q,hpre,hq,eq,head⟩ := spell_extensions mainWord data.1 (.nil _) rp (by simp) widths
  have no : pre=[] := List.eq_nil_of_length_eq_zero hpre
  subst pre
  simp only [List.nil_append] at eq head
  have rt := read_route (mainWord++q) (by have := data.1; simp; omega)
  rw [eq,head] at rt
  have e := add_left_cancel (rt.balance.trans (join_routes (read_route mainWord data.1) rp).balance.symm)
  have closed : (mainWord++q).drop ((mainWord++q).length-6)=mainWord.take 6 := by simpa using e
  have cap := word_return q (by omega) closed
  change (pathClasses ((mainWord++q).take 6) (windows (mainWord++q))).card+3≤_ at cap
  simpa only [head,eq,hq] using cap

#print axioms extension_cap
#print axioms extension_loss
#print axioms return_cap
#print axioms attained
end ExactWordFlow.SeventeenCaps

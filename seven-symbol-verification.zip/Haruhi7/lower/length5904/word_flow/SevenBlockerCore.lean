import SevenOverlap

namespace ExactWordFlow.SevenBlockerData
open Equiv SevenMoves

/-- Each literal gives the images of positions 0 through 6. Successively
swapping the requested image into its position also works on arbitrary data. -/
private def decode (s : String) : X :=
  let v:=s.toList.toArray
  (List.finRange 7).foldl (fun p i=>
    (Equiv.swap (p i) (Fin.ofNat 7 (v[i.val]!.toNat-'0'.toNat))) * p) (1:X)

def root : Y := tag 1

private def seeds : List String := ["6012345",
  "3016245",
  "1023456",
  "5031624",
  "6031254",
  "3024561",
  "0126543",
  "2043561",
  "5024613",
  "0123645",
  "4026153",
  "6042153",
  "3054126",
  "2063154",
  "4035621",
  "6043251",
  "0143625",
  "1053426",
  "1052364",
  "1052463",
  "1063542",
  "3012564",
  "0145326",
  "2043165",
  "3041652",
  "5062314",
  "6051342",
  "2016435",
  "1046523",
  "3056421",
  "6051243",
  "4036125",
  "6014235",
  "5036241",
  "2015634",
  "4032165",
  "3062541",
  "0163425",
  "6043152",
  "0135462",
  "2045631",
  "4061352",
  "1054362",
  "3016542",
  "0132564",
  "0132465",
  "6045312",
  "2031456",
  "3052146",
  "5023614",
  "1026345",
  "0162534",
  "2064531",
  "2045136",
  "3014562",
  "5061423",
  "2041365",
  "5013264",
  "3054612"]

private def guardsFor : Nat → List String
  | 49 => ["0236154",
  "0253416",
  "0135264",
  "0142563",
  "0154632",
  "0241365",
  "0263415",
  "0263514",
  "0345216",
  "0461235",
  "0461253",
  "0645321",
  "0132645",
  "0145362",
  "0164253",
  "0235614",
  "0514236"]
  | 50 => ["0253416",
  "0135264",
  "0142563",
  "0154632",
  "0241365",
  "0263415",
  "0345216",
  "0461235",
  "0461253",
  "0645321",
  "0132645",
  "0145362",
  "0164253",
  "0246351",
  "0514236"]
  | 51 => ["0253416",
  "0135264",
  "0142563",
  "0154632",
  "0241365",
  "0461235",
  "0461253",
  "0645321",
  "0132645",
  "0145362",
  "0164253",
  "0345216",
  "0514236"]
  | 52 => ["0135264",
  "0142563",
  "0154632",
  "0241365",
  "0461235",
  "0645321",
  "0132645",
  "0145362",
  "0164253",
  "0345216",
  "0461253",
  "0514236"]
  | 53 => ["0135264",
  "0142563",
  "0154632",
  "0241365",
  "0461235",
  "0132645",
  "0145362",
  "0345216",
  "0461253",
  "0514236"]
  | 54 => ["0135264",
  "0142563",
  "0154632",
  "0461235",
  "0145362",
  "0213465",
  "0461253",
  "0514236"]
  | 55 => ["0135264",
  "0461235",
  "0614253",
  "0154632",
  "0213465",
  "0514236"]
  | 56 => ["0135264",
  "0461235",
  "0154632",
  "0213465"]
  | 57 => ["0135264",
  "0123546",
  "0154632"]
  | 58 => ["0123546",
  "0154632"]
  | 59 => []
  | _ => []

def ws (n : Nat) : List (Finset Y) :=
  (seeds.take n).map (fun s=>(owner (decode s)).image tag)

def guards (n : Nat) : Finset Y := ((guardsFor n).map (fun s=>tag (decode s))).toFinset
def C (n : Nat) : Finset Y := (ws n).foldl (·∪·) {root}

private def code (y : Y) : List (Fin 6) := (List.finRange 6).map y
private theorem code_inj : Function.Injective code := by
  intro x y eq
  apply Perm.ext
  intro i
  exact List.map_inj_left.mp eq i (List.mem_finRange i)

private def hitTest (B : Finset Y) : Bool :=
  let cached:=B.image code
  (permsOfList (List.finRange 7)).all (fun p=>
    (List.range 6).any (fun j=>decide (code (tag (p*t^j))∈cached)))

private theorem reflects {B : Finset Y} (ok : hitTest B=true) :
    ∀p:X,∃x∈owner p,tag x∈B := by
  intro p
  have member := mem_permsOfList_of_mem (f:=p) (fun i _=>List.mem_finRange i)
  obtain ⟨j,hj,v⟩:=List.any_eq_true.mp (List.all_eq_true.mp ok p member)
  have hit : code (tag (p*t^j))∈B.image code:=of_decide_eq_true v
  obtain ⟨a,ha,eq⟩:=Finset.mem_image.mp hit
  refine ⟨p*t^j,?_,(code_inj eq) ▸ ha⟩
  exact Finset.mem_image.mpr ⟨t^j,Finset.mem_image_of_mem _ (Finset.mem_range.mpr (List.mem_range.mp hj)),rfl⟩

theorem guard49 : (guards 49).card=17 := by decide +native
theorem guard59 : (guards 59).card=0 := by decide +native
private theorem test49 : hitTest (C 49∪guards 49)=true := by decide +native
private theorem test59 : hitTest (C 59∪guards 59)=true := by decide +native
theorem hits49 : ∀p:X,∃x∈owner p,tag x∈C 49∪guards 49 := reflects test49
theorem hits59 : ∀p:X,∃x∈owner p,tag x∈C 59∪guards 59 := reflects test59

#print axioms hits49
#print axioms hits59
end ExactWordFlow.SevenBlockerData

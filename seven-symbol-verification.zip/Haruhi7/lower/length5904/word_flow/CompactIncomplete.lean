module

public import Std.Tactic.BVDecide.LRAT.Checker
import all Std.Tactic.BVDecide.LRAT.Internal.Checker

namespace ExactWordFlow.CompactWordCircuit
open Std.Sat Std.Tactic.BVDecide

private theorem go_needs_empty {st : LRAT.Internal.State} {actions : Array LRAT.IntAction}
    {i : Nat} (ok : LRAT.Internal.check.go st actions i=true) :
    ∃ id hints, LRAT.Action.addEmpty id hints ∈ actions := by
  fun_induction LRAT.Internal.check.go st actions i
  case case1 =>
    rename_i _st _idx bounded _step id hints eqStep
    exact ⟨id,hints,eqStep ▸ Array.getElem_mem bounded⟩
  case case2 ih => exact ih ok
  case case3 => contradiction
  case case4 ih => exact ih ok
  case case5 => contradiction
  case case6 ih => exact ih ok
  case case7 => contradiction

/-- Any proof accepted by this checker contains an explicit empty-clause action. -/
public theorem check_needs_empty {actions : Array LRAT.IntAction} {F : CNF Nat}
    (ok : LRAT.check actions F=true) :
    ∃ id hints, LRAT.Action.addEmpty id hints ∈ actions :=
  go_needs_empty ok

/-- A trace stopped before its first empty-clause action is rejected for every formula. -/
public theorem check_false_of_no_empty (actions : Array LRAT.IntAction) (F : CNF Nat)
    (none : ∀ id hints, LRAT.Action.addEmpty id hints ∉ actions) :
    LRAT.check actions F=false := by
  cases value : LRAT.check actions F with
  | false => rfl
  | true =>
    obtain ⟨id,hints,mem⟩:=check_needs_empty value
    exact (none id hints mem).elim

#print axioms check_false_of_no_empty
end ExactWordFlow.CompactWordCircuit

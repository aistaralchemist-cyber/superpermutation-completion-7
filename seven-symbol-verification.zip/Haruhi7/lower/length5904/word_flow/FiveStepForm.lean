import BridgeRoute
import MacroSplit
import EndExchange
import EndpointSaving

namespace ExactWordFlow.OnePath66
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels ResidualRoutes

/-- Every five-edge repair necessarily splits into a literal prefix and a
literal suffix of the retained open spine. The endpoints of the repair
are unrestricted. No assumption on the kinds or multiplicities of the
five proposed edges is made. -/
theorem five_step_form {a b s t : Block} {es ws : List Block}
    (r : Route src dst a es b) (openEnds : a≠b) (legit : ∀w∈ws, full w)
    (classes : classCount a es=390) (k : ws.length≤65)
    (fresh : Multiset Block) (five : fresh.card=5)
    (h : Feasible (((↑es : Multiset Block)+turns ws)+fresh) s t) :
    ∃ p q : List Block, (↑(p++q) : Multiset Block)=fresh ∧
      Route src dst s p a ∧ Route src dst b q t := by
  classical
  let base := (↑es : Multiset Block)+turns ws
  have wb := EndpointSaving.turns_balance ws legit
  have rb := r.balance
  have bal : base.map src+{b}=base.map dst+{a} := by
    simp only [base,Multiset.map_add,wb,add_right_comm _ ((turns ws).map dst) _,rb]
  have degree := fresh_endpoints bal h.balance
  have allReq := (RequiredComponent.together_iff_classes _).mp (RequiredComponent.feasible_together h)
  have cut (e) (he : e∈fresh) : ∃ U : Set Block, dst e∈U ∧ src e∉U ∧ (a∈U ↔ b∈U) ∧
      ∀ d∈fresh, d≠e → (src d∈U ↔ dst d∈U) := by
    let graph := required+(base+fresh.erase e)
    let U : Set Block := {v | label graph v=label graph (dst e)}
    have key := every_fresh_is_bridge r legit classes k five allReq he
    change label graph (src e)≠label graph (dst e) at key
    have edge (f) (hf : f∈es) : f∈graph :=
      Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inl (Multiset.mem_add.mpr
        (Or.inl (show f∈(↑es : Multiset Block) from hf))))))
    have spine := (r.closed {v | label graph v=label graph a} rfl
      (fun d hd prev => (on_edge (edge d hd)).symm.trans prev)).1
    refine ⟨U,rfl,key,?_,?_⟩
    · change (label graph a=_) ↔ (label graph b=_)
      rw [spine]
    · intro d hd ne
      have keep : d∈graph := Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr
        (Or.inr ((Multiset.mem_erase_of_ne ne).mpr hd))))
      change (label graph (src d)=_) ↔ (label graph (dst d)=_)
      rw [on_edge keep]
  obtain ⟨xs,bag,walk⟩ := BridgeRoute.through_macro src dst openEnds fresh degree cut
  exact MacroSplit.split src dst fresh bag walk

#print axioms five_step_form
end ExactWordFlow.OnePath66

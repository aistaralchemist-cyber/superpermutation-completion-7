import SynchronizedCycles

namespace ExactWordFlow.LongCyclePrice105
open ResidualDensity MarkedGeometry DirectedEuler
open private periodic_laps from DensityBudget

/-- Retain precisely those previously proved forbidden patterns that fit
on every cycle of length at least 105. -/
private def shortMasks:=forbidden.filter (fun v=>decide (v.length≤105))

/-- The last remembered suffix is a prefix of one of the shortMasks masks.
Order the choices longest first to retain as much information as possible. -/
private def prefixes : Array (List Bool) :=
  ((shortMasks.flatMap List.inits).eraseDups.mergeSort
    (fun a b => decide (b.length≤a.length))).toArray

private def memoryWord (s : Nat) := prefixes[s]?.getD []

private def nextState (s : List Bool) (b : Bool) : Nat :=
  let ext := s++[b]
  if shortMasks.any (fun w => w.isSuffixOf ext) then prefixes.size
  else prefixes.findIdx (fun w => w.isSuffixOf ext)

private def steps := prefixes.map fun s => (nextState s false,nextState s true)
private def move (s : Nat) (b : Bool) :=
  let pair := steps[s]?.getD (prefixes.size,prefixes.size)
  if b then pair.2 else pair.1

/-- Credit sufficient for a continuation of at most n steps. A shortMasks
transition contributes zero. A fixed point is checked below, edge by edge. -/
private def credits : Nat → Array Nat
  | 0 => Array.replicate prefixes.size 0
  | n+1 =>
    let prev := credits n
    steps.map fun (l,r) => max (prev[l]?.getD 0-60)
      (if r<prefixes.size then 71+prev[r]?.getD 0-60 else 0)

private def creditTable := credits 186
private def credit (s : Nat) := creditTable[s]?.getD 0
private def initial := prefixes.findIdx List.isEmpty

private theorem start : initial<prefixes.size ∧ memoryWord initial=[] ∧ credit initial=96 := by
  native_decide

/-- The numerical choices are untrusted. Each accepted edge must remember a
real suffix and pay for its bit. Each rejected edge must exhibit a shortMasks
suffix. These checks, plus initial credit, suffice for the global bound. -/
private def valid (s : Nat) (b : Bool) : Bool :=
  let j:=move s b
  let ext:=memoryWord s++[b]
  if j<prefixes.size then (memoryWord j).isSuffixOf ext &&
    decide (71*b.toNat+credit j≤60+credit s)
  else shortMasks.any fun q=>q.isSuffixOf ext

private theorem verified : ∀s : Fin prefixes.size, valid s.val false=true ∧ valid s.val true=true := by
  native_decide

private theorem accepted (s : Nat) (b : Bool) (pre bs : List Bool) (ok : s<prefixes.size)
    (suffix : memoryWord s <:+ pre) (safeWord : ∀x∈shortMasks, ¬x <:+: pre++b::bs) :
    let j:=move s b
    j<prefixes.size ∧ memoryWord j <:+ pre++[b] ∧ 71*b.toNat+credit j≤60+credit s := by
  let j := move s b
  let ext := memoryWord s++[b]
  have checked : valid s b=true := by
    cases b
    · exact (verified ⟨s,ok⟩).1
    · exact (verified ⟨s,ok⟩).2
  have longer : ext <:+ pre++[b] := by
    obtain ⟨left,eq⟩:=suffix
    exact ⟨left,by simp [ext,←List.append_assoc,eq]⟩
  by_cases inside : j<prefixes.size
  · change (if j<prefixes.size then _ else _)=true at checked
    rw [ite_eq_left inside,Bool.and_eq_true] at checked
    exact ⟨inside, (List.isSuffixOf_iff_suffix.mp checked.1).trans longer,of_decide_eq_true checked.2⟩
  · change (if j<prefixes.size then _ else _)=true at checked
    rw [ite_eq_right inside] at checked
    obtain ⟨x,hx,bad⟩:=List.any_eq_true.mp checked
    have bad' := ((List.isSuffixOf_iff_suffix.mp bad).trans longer).isInfix
    exact False.elim (safeWord _ hx (by simpa using bad'.trans (List.prefix_append (pre++[b]) bs).isInfix))

private theorem price (pre rest : List Bool) (s : Nat) (ok : s<prefixes.size)
    (suffix : memoryWord s <:+ pre) (safeWord : ∀x∈shortMasks, ¬x <:+: pre++rest) :
    71*rest.count true ≤ 60*rest.length+credit s := by
  induction rest generalizing s pre with
  | nil => simp
  | cons b bs ih =>
    obtain ⟨inside,suff,cost⟩:=accepted s b pre bs ok suffix safeWord
    have n:=ih (pre++[b]) _ inside suff (by simpa using safeWord)
    cases b <;> simp at cost ⊢ <;> omega


/-- A periodic 105-or-longer word has no endpoint credit. The short forbidden
profiles alone bound its circular mark density by sixty seventy-firsts. -/
theorem periodic_price {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] {k : Nat}
    (w : Walk u) (cy:CyclicMarked u p k) (lo:105≤k) : 71*count p 0 k≤60*k := by
  have safeCut (v) (hv:v∈shortMasks) : ¬v <:+:mask p 0 (k*97):=by
    obtain ⟨old,width⟩:=List.mem_filter.mp hv
    exact SynchronizedCycles.safe_all_laps w cy 0 _ v old ((of_decide_eq_true width).trans lo)
  have h:=price [] (mask p 0 (k*97)) initial start.1 (by simp [start.2.1]) (by simpa using safeCut)
  rw [mark_count,periodic_laps cy.periodic 97,start.2.2] at h
  simp only [mask,List.length_map,List.length_range] at h
  omega

theorem closed_route {s : Block} {es : List Block} (r:Route src dst s es s)
    (wd : ∀e∈es,e.length=7) (lo:105≤es.length) : 71*classCount s es≤60*es.length := by
  obtain ⟨u,I,w,cy,eq⟩:=closed_observations r wd (by omega)
  exact eq ▸ periodic_price w cy lo

/-- The former 11/13 bound cannot be attained by any closed component
long enough to contain every forbidden pattern used here. -/
theorem strict_eleven_thirteenths {s : Block} {es : List Block} (r:Route src dst s es s)
    (wd : ∀e∈es,e.length=7) (large:105≤es.length) :
    13*classCount s es<11*es.length := by
  have paid:=closed_route r wd large
  omega

#print axioms strict_eleven_thirteenths
#print axioms closed_route
end ExactWordFlow.LongCyclePrice105

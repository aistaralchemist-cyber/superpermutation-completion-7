import WheelCharge
import FixedSeed390

namespace ExactWordFlow.PairedAnchor
open SevenWordWindows SeedWheelCut ExtremeWheelCut ForcedRootClosure
open private digits from ExtremeWheelCut

def anchors : Finset Block :=
  (("0162345 0345162 0345621 0435216 0621435 0162453 0436521 0453162 0124365 0164325 0423561 0436512 0143562 0351624 0453621 0124635 0162354 0162543 0164352 0356214 0431625 0432516 0432561 0463512 0624135".splitOn " ").map digits).toFinset
def a := digits "0162435"
def b := digits "0435621"
def c := digits "0435162"
private def point (x t : Block) : Int := if x=t then 1 else 0
private def charge (t : Block) := point a t + point b t - point c t

theorem geometry : anchors.card=25 ∧ force anchors=anchors ∧
    anchors ⊆ FixedSeed390.rootClasses ∧ a∉FixedSeed390.rootClasses ∧
    b∉FixedSeed390.rootClasses ∧ c∉FixedSeed390.rootClasses ∧
    a∈allClasses ∧ b∈allClasses ∧ c∈allClasses := by native_decide

private theorem options : ∀w∈allRows,w⊆allClasses ∧ w.card≤6 ∧
    ∀p∈w,Disjoint (w.erase p) anchors → ∑t∈w.erase p,charge t=0 := by native_decide

private theorem count_point (x : Block) (T : Finset Block) :
    ∑t∈T,point x t = if x∈T then (1:Int) else 0 := by
  classical
  simp [point]

private theorem count_charge (T : Finset Block) :
    ∑t∈T,charge t = (if a∈T then (1:Int) else 0) +
      (if b∈T then 1 else 0) - (if c∈T then 1 else 0) := by
  simp [charge,Finset.sum_add_distrib,Finset.sum_sub_distrib,count_point]

/-- The 25 supplied anchors force this joint equation on every saturated
root containing them, of arbitrary cardinality and with any legal wheel order. -/
theorem relation {A : Finset Block} {W : Finset (Finset Block)} (seed : anchors⊆A)
    (legal : W⊆allRows) (tight : A.card+5*W.card≤allClasses.card)
    (link : ClosedCover A allClasses W) :
    (if a∈A then (1:Int) else 0) + (if b∈A then 1 else 0) =
      1+(if c∈A then 1 else 0) := by
  have zero:=WheelCharge.outside_sum seed legal (fun w hw=>
    ⟨(options w (legal hw)).1,(options w (legal hw)).2.1⟩) tight link charge
    (fun w hw=>(options w hw).2.2)
  obtain ⟨_,_,_,_,_,_,ha,hb,hc⟩:=geometry
  rw [count_charge] at zero
  simp only [Finset.mem_sdiff,ha,hb,hc,true_and] at zero
  split_ifs at * <;> omega

/-- Any connected root that omits both alternatives must pay at least one
unit of extra attachment capacity, even with an unrestricted root size. -/
theorem one_extra {A : Finset Block} {W : Finset (Finset Block)} (seed : anchors⊆A)
    (legal : W⊆allRows) (link : ClosedCover A allClasses W) (ha : a∉A) (hb : b∉A) :
    721 ≤ A.card+5*W.card := by
  by_contra! less
  have size : allClasses.card=720 := by native_decide
  have z:=relation seed legal (by omega) link
  by_cases hc : c∈A <;> simp [ha,hb,hc] at z

#print axioms relation
#print axioms one_extra
end ExactWordFlow.PairedAnchor

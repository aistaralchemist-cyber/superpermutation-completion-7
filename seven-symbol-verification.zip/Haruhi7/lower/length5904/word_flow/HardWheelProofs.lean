import WheelProof96
import WheelProof97
import WheelProof98

namespace ExactWordFlow.HardWheelProofs
theorem hard_unsat {N : Nat} (lo : 96≤N) (hi : N≤98) {R} (h : R∈NearHardRoots.hard N) :
    (OrientedCNF.cnf R).Unsat := by
  rcases (show N=96 ∨ N=97 ∨ N=98 by omega) with rfl|rfl|rfl
  · exact WheelProof96.unsat h
  · exact WheelProof97.unsat h
  · exact WheelProof98.unsat h
end ExactWordFlow.HardWheelProofs

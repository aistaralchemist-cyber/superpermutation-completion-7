import ChordFaces

namespace ExactWordFlow.MarkedPairReturn
open Equiv PhaseReturn ChordFaces
open private marked compressed mark_id from PhaseReturn
variable {X : Type*} [Fintype X] [DecidableEq X]

/-- A rotation orbit with exactly two distinct marked points necessarily
returns from each of them to the other at its first positive return. -/
theorem pair {R : Perm X} {S : Finset X} (h : Hits R S) {x y : X} (hx : x∈S)
    (hy : y∈S) (different : x≠y) (same : R.SameCycle x y)
    (only : ∀z∈S,R.SameCycle x z → z=x ∨ z=y) : mark h (R x)=y := by
  have along : R.SameCycle x (mark h (R x)) := by
    unfold mark
    exact Perm.sameCycle_pow_right.mpr (Perm.sameCycle_apply_right.mpr (.refl _ _))
  rcases only _ (marked h _) along with fixed|yes
  · have steady : jump h (1 : Perm X) x=x:=by simpa only [jump,Perm.one_apply] using fixed
    have constant (k : Nat) : (jump h (1 : Perm X))^[k] x=x := by
      induction k with
      | zero => rfl
      | succ k ih => rw [Function.iterate_succ_apply',ih,steady]
    obtain ⟨n,_,atY⟩:=same.exists_pow_eq'
    obtain ⟨k,atMark⟩:=compressed (F:=R) (J:=1) h (fun _ _=>rfl) hx n
    rw [mul_one,atY,mark_id h hy,constant k] at atMark
    exact (different atMark).elim
  · exact yes

/-- The reorder function can be checked one original rotation orbit at a
time. A singleton index stays fixed. A distinct pair exchanges indices.
This criterion asks only about the baseline R-orbits, of size seven in
the application. Dummy marks on untouched tags carry index none. -/
theorem underlying {R J : Perm X} {S : Finset X} (h : Hits R S) (off : ∀x∉S,J x=x)
    (index : X→Option Nat) (m : Nat) (reorder : Nat→Nat)
    (order : ∀x∈S,index (J x)=(index x).map (nextIndex m))
    (list : ∀x∈S,
      ((∀z∈S,R.SameCycle x z→index z=index x) ∧ (index x).map reorder=index x) ∨
      ∃y∈S,x≠y ∧ R.SameCycle x y ∧ (∀z∈S,R.SameCycle x z→z=x∨z=y) ∧
        index y=(index x).map reorder) :
    ∀x∈S,index (jump h J x)=(index x).map (fun n=>reorder (nextIndex m n)) := by
  have exactReturn (x) (hx : x∈S) : index (mark h (R x))=(index x).map reorder := by
    rcases list x hx with same | ⟨y,hy,ne,same,only,idx⟩
    · have along : R.SameCycle x (mark h (R x)) := by
        unfold mark
        exact Perm.sameCycle_pow_right.mpr (Perm.sameCycle_apply_right.mpr (.refl _ _))
      exact (same.1 _ (marked h _) along).trans same.2.symm
    · rw [pair h hx hy ne same only,idx]
  have keeps (x) (hx : x∈S) : J x∈S := by
    by_contra no
    have eq:=J.injective (off (J x) no)
    exact no (eq.symm ▸ hx)
  intro x hx
  unfold jump
  rw [exactReturn _ (keeps _ hx), order _ hx]
  cases index x <;> rfl

#print axioms pair
#print axioms underlying
end ExactWordFlow.MarkedPairReturn

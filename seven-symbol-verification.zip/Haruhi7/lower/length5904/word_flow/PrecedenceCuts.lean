import FirstOccurrence
namespace ExactWordFlow.CandidateRenaming
open SevenWordWindows CompactWordCircuit

private theorem earlier {w pre tail : Block} {a b : Fin 7} (ord : OrderedFirsts w)
    (ab : a<b) (eq : w=pre++b::tail) : a∈pre := by
  by_cases h : b∈pre
  · obtain ⟨l,r,eq',notin⟩ := List.eq_append_cons_of_mem h
    subst pre
    apply List.mem_append_left
    exact ord l b (r++b::tail) (by simpa [List.append_assoc] using eq) notin a ab
  · exact ord pre b tail eq h a ab

/-- Single clause for value precedence at one position, on the unmodified DIMACS variable IDs. -/
def precedenceRow (i : Fin 1501) (a : Fin 6) : List W :=
  (-slot i.val (a.val+1)) :: (List.range i.val).map (fun j=>slot j a.val)

theorem canonical_precedence_rows {w : Block} (cw : Candidate w) :
    ∃v, (∀r∈signedRows 0 (goalTape true).body.toList, r.any (wire v)=true) ∧
        ∀i a,(precedenceRow i a).any (wire v)=true := by
  obtain ⟨z,zc,ord,f,v,events,rows⟩ := canonical_all_rows cw
  have rg (i:Fin 1501) (a:Fin 7) := source_slot (input_admits (layout_parts events)) i a
  refine ⟨v,rows,?_⟩
  intro i a
  let b : Fin 7 := a.succ
  have hi : i.val<z.length := by rw [zc.1]; exact i.isLt
  let x : Fin 7 := z[i.val]'hi
  have ix : z[i.val]? = some x := List.getElem?_eq_getElem hi
  have bd := rg i b
  have face : wire v (slot i.val (a.val+1))=decide (x=b) := by
    simpa [wordSource,ix,Fin.ext_iff,b] using bd.2
  unfold precedenceRow
  apply List.any_eq_true.mpr
  by_cases yes : x=b
  · have part : z=z.take i.val ++ b :: z.drop (i.val+1) := by
      rw [←yes, ←List.drop_eq_getElem_cons hi, List.take_append_drop]
    have old : a.castSucc ∈ z.take i.val := earlier ord (Fin.castSucc_lt_succ (i:=a)) part
    obtain ⟨j,inRange,old⟩:=List.mem_iff_getElem.mp old
    have ji : j < i.val := inRange.trans_le (List.length_take_le i.val z)
    have jl : j<z.length := by omega
    have val : z[j]? = some a.castSucc := by
      rw [List.getElem?_eq_getElem jl]
      congr 1
      simpa only [List.getElem_take] using old
    have jn : j<1501 := by omega
    have ok := (rg ⟨j,jn⟩ a.castSucc).2
    have wire_j : wire v (slot j a.val)=true := by simpa [wordSource,val] using ok
    exact ⟨_,List.mem_cons_of_mem _ (List.mem_map.mpr ⟨j,List.mem_range.mpr ji,rfl⟩),wire_j⟩
  · have nz : slot i.val (a.val+1) ≠ 0 := bd.1
    exact ⟨_,List.mem_cons_self,by rw [wire_neg nz,face]; simp [yes]⟩

theorem optimum_of_precedence_refutation
    (no : ¬∃v, (∀r∈signedRows 0 (goalTape true).body.toList, r.any (wire v)=true) ∧
        ∀i a,(precedenceRow i a).any (wire v)=true) :
    SuperpermBridge.HR.Ssuper 7=5905 := by
  apply CoreDecision1501.optimum_of_refutation _ no
  intro w len occ
  obtain ⟨vis,many⟩ := (CoreDecision1501.occurrenceCover_iff w 91).mp occ
  exact canonical_precedence_rows (w:=w) ⟨len,vis,many⟩

#print axioms canonical_precedence_rows
end ExactWordFlow.CandidateRenaming

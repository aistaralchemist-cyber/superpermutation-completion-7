import GlobalWheelRank

namespace CleanFlow
open ExactWordFlow SevenWordWindows GlobalWheelRank

/-- A canonical orientation of a six-wheel. -/
def orientation (v : Block) :=
  v.rotate (v.idxOf (v.mergeSort.headD 0))
def key (e : Block) := orientation (src e)
def wheelSet (q : Block) := (wheel q).toFinset
def rowList := ((representatives.map src).map orientation).eraseDups

/-- Each proper nonempty portion of a wheel has a first used step after
a gap. The original wheel has six distinct edges and a unique orbit label. -/
private theorem rowData :
    rowList.all (fun q => decide (
      q∈roots ∧ (wheelSet q).card=6 ∧
      (∀ e∈wheelSet q, key e=q ∧ orientation (dst e)=q) ∧
      (∀ a∈(wheelSet q).powerset, a.Nonempty → ¬wheelSet q⊆a →
        ∃ e∈a, ∀ f∈a, dst f≠src e)))=true := by native_decide

private theorem rotateTable :
    (representatives.map src).all (fun q => (wheel q).all fun e =>
      decide (key e∈rowList ∧ e∈wheelSet (key e)))=true := by native_decide

private theorem row {q : Block} (h : q∈rowList) :
    q∈roots ∧ (wheelSet q).card=6 ∧
    (∀ e∈wheelSet q, key e=q ∧ orientation (dst e)=q) ∧
    (∀ a∈(wheelSet q).powerset, a.Nonempty → ¬wheelSet q⊆a →
      ∃ e∈a, ∀ f∈a, dst f≠src e) :=
  of_decide_eq_true (List.all_eq_true.mp rowData q h)

private theorem locate {e : Block} (h : ∃q∈roots, e∈wheel q) :
    key e∈rowList ∧ e∈wheelSet (key e) := by
  obtain ⟨q,hq,he⟩ := h
  exact of_decide_eq_true (List.all_eq_true.mp
    (List.all_eq_true.mp rotateTable q (List.mem_toFinset.mp hq)) e he)

private theorem incoming {X : Multiset Block} {s t e : Block}
    (bal : X.map src + {t}=X.map dst + {s}) (he : e∈X) (ne : src e≠s) :
    ∃ f∈X, dst f=src e := by
  have a : src e∈X.map dst + {s} := bal ▸
    (Multiset.mem_add.mpr (Or.inl (Multiset.mem_map.mpr ⟨e,he,rfl⟩)) :
        src e ∈ X.map src + {t})
  exact Multiset.mem_map.mp ((Multiset.mem_add.mp a).resolve_right (by simpa using ne))

/-- Distinct seven-windows that are neither required permutations nor
ordinary six-wheel steps. Multiplicity is discarded deliberately. -/
def exceptional (X : Multiset Block) : Finset Block :=
  X.toFinset.filter fun e => e∉required ∧ ¬∃ q∈roots, e∈wheel q

/-- A support-level necessary inequality for every placement. Distinct
surplus windows are charged only once no matter how high their multiplicity. -/
theorem weighted_exception_bound {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    4314 ≤ 5*X.toFinset.card + 5 + 6*(exceptional X).card := by
  classical
  let D := X.toFinset.filter (fun e => ¬∃ q∈roots, e∈wheel q)
  let O := X.toFinset \ D
  let F := (O.image key).filter (fun q => wheelSet q ⊆ O)
  let A := O.filter (fun e => key e∉F)
  let I := A.image key
  let E := (A∪exceptional X).image (fun e => (cls (src e),cls (dst e)))
  have od {e} (he : e∈O) : e∈X ∧ ∃q∈roots, e∈wheel q := by
    have mem := Finset.mem_sdiff.mp he
    refine ⟨Multiset.mem_toFinset.mp mem.1,?_⟩
    by_contra no
    exact mem.2 (Finset.mem_filter.mpr ⟨mem.1,no⟩)
  have loc {e} (he : e∈O) := locate (od he).2
  have rowF {q} (hq : q∈F) : q∈rowList := by
    obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp (Finset.mem_filter.mp hq).1
    exact (loc he).1
  have rowI {q} (hq : q∈I) : q∈rowList := by
    obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp hq
    exact (loc (Finset.mem_filter.mp he).1).1
  have occ {q} (hq : q∈I) : (O∩wheelSet q).Nonempty := by
    obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp hq
    have ho := (Finset.mem_filter.mp he).1
    exact ⟨e,Finset.mem_inter.mpr ⟨ho,(loc ho).2⟩⟩
  have miss {q} (hq : q∈I) : ¬wheelSet q⊆O := by
    obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp hq
    obtain ⟨ho,nf⟩ := Finset.mem_filter.mp he
    exact fun covered => nf (Finset.mem_filter.mpr ⟨Finset.mem_image_of_mem _ ho,covered⟩)
  have mainRank := wheel_bound h F (fun q hq => (row (rowF hq)).1) E (by
    intro e he
    by_cases good : e∈required
    · exact Or.inl good
    · by_cases ho : e∈O
      · by_cases full : key e∈F
        · exact Or.inr (Or.inl ⟨key e,full,List.mem_toFinset.mp (loc ho).2⟩)
        · exact Or.inr (Or.inr (Finset.mem_image_of_mem _ (Finset.mem_union_left _
            (Finset.mem_filter.mpr ⟨ho,full⟩ : e∈A))))
      · have bad : e∈exceptional X := by
          apply Finset.mem_filter.mpr
          refine ⟨Multiset.mem_toFinset.mpr he,good,fun yes => ho ?_⟩
          exact Finset.mem_sdiff.mpr ⟨Multiset.mem_toFinset.mpr he,
            fun hd => (Finset.mem_filter.mp hd).2 yes⟩
        exact Or.inr (Or.inr (Finset.mem_image_of_mem _ (Finset.mem_union_right _ bad))))
  have pairCap : E.card ≤ A.card + (exceptional X).card :=
    Finset.card_image_le.trans (Finset.card_union_le _ _)
  let complete := F.biUnion wheelSet
  have disj : (↑F : Set Block).PairwiseDisjoint wheelSet := by
    intro q hq r hr hqr
    apply Finset.disjoint_left.mpr
    intro e he hf
    have hk := (row (rowF hq)).2.2.1 e he
    have hl := (row (rowF hr)).2.2.1 e hf
    exact hqr (hk.1.symm.trans hl.1)
  have fullSize : complete.card=6*F.card := by
    rw [show complete=F.biUnion wheelSet from rfl,Finset.card_biUnion disj]
    calc
      ∑ q ∈ F, (wheelSet q).card = ∑ _ ∈ F, 6 := by
        apply Finset.sum_congr rfl
        exact fun q hq => (row (rowF hq)).2.1
      _ = _ := by simp [Nat.mul_comm]
  have inO : complete∪A ⊆ O := by
    intro e he
    rcases Finset.mem_union.mp he with full | part
    · obtain ⟨q,hq,hw⟩ := Finset.mem_biUnion.mp full
      exact (Finset.mem_filter.mp hq).2 hw
    · exact (Finset.mem_filter.mp part).1
  have sep : Disjoint complete A := by
    apply Finset.disjoint_left.mpr
    intro e he ha
    obtain ⟨q,hq,hw⟩ := Finset.mem_biUnion.mp he
    have k := ((row (rowF hq)).2.2.1 e hw).1
    exact (Finset.mem_filter.mp ha).2 (k ▸ hq)
  have used := Finset.card_le_card inO
  rw [Finset.card_union_of_disjoint sep,fullSize] at used
  have area : O.card + D.card=X.toFinset.card := Finset.card_sdiff_add_card_eq_card (Finset.filter_subset ..)
  have total : X.toFinset.card ≤ X.card := Multiset.toFinset_card_le _
  have contain : A ⊆ I.biUnion (fun q => O∩wheelSet q) := by
    intro e he
    have ho := (Finset.mem_filter.mp he).1
    exact Finset.mem_biUnion.mpr ⟨key e,Finset.mem_image_of_mem _ he,
      Finset.mem_inter.mpr ⟨ho,(loc ho).2⟩⟩
  have partSize := (Finset.card_le_card contain).trans Finset.card_biUnion_le
  have five : ∑ q∈I, (O∩wheelSet q).card ≤ I.card*5 := by
    apply Finset.sum_le_card_nsmul
    intro q hq
    have small : (O∩wheelSet q).card < (wheelSet q).card := by
      by_contra! bad
      have eq := Finset.eq_of_subset_of_card_le (Finset.inter_subset_right (s₁:=O)) bad
      exact miss hq (fun v hv => (Finset.mem_inter.mp (eq ▸ hv)).1)
    have six := (row (rowI hq)).2.1
    omega
  have sources : I ⊆ insert (orientation s) (D.image fun e => orientation (dst e)) := by
    intro q hq
    let part := O∩wheelSet q
    have incomplete : ¬ wheelSet q ⊆ part := fun eq => miss hq (eq.trans Finset.inter_subset_left)
    obtain ⟨e,he,gap⟩ := (row (rowI hq)).2.2.2 part
      (Finset.mem_powerset.mpr Finset.inter_subset_right) (occ hq) incomplete
    obtain ⟨oe,we⟩ := Finset.mem_inter.mp he
    have ke := ((row (rowI hq)).2.2.1 e we).1
    by_cases atStart : src e=s
    · apply Finset.mem_insert.mpr; left
      change orientation (src e)=q at ke
      rw [atStart] at ke
      exact ke.symm
    · obtain ⟨f,hf,arr⟩ := incoming h.balance (od oe).1 atStart
      have tag : orientation (dst f)=q := (congrArg orientation arr).trans ke
      have dup : f ∈ D := by
        by_contra nope
        have fo : f∈O := Finset.mem_sdiff.mpr ⟨Multiset.mem_toFinset.mpr hf,nope⟩
        obtain ⟨rr,hw⟩ := loc fo
        have kf := ((row rr).2.2.1 f hw).2
        have kq : key f=q := kf.symm.trans tag
        exact gap f (Finset.mem_inter.mpr ⟨fo,kq ▸ hw⟩) arr
      exact Finset.mem_insert_of_mem (Finset.mem_image.mpr ⟨f,dup,tag⟩)
  have partialBound := Finset.card_le_card sources
  have inserted := Finset.card_insert_le (orientation s) (D.image fun e => orientation (dst e))
  have imageSize : (D.image fun e => orientation (dst e)).card ≤ D.card := Finset.card_image_le
  omega

/-- For every pair of endpoints and every placement at the target budget,
at least four distinct exceptional raw transitions are necessary. -/
theorem four_exceptional {X : Multiset Block} {s t : Block} (hsize : X.card ≤ 858)
    (h : Feasible X s t) : 4 ≤ (exceptional X).card := by
  have cost := weighted_exception_bound h
  have total := Multiset.toFinset_card_le X
  omega

/-- Without excursions, arbitrary partial wheels and repeated permutations
require at least 862 distinct surplus windows. -/
theorem clean_support_floor {X : Multiset Block} {s t : Block}
    (moves : ∀ e∈X, e∈required ∨ ∃ q∈roots, e∈wheel q)
    (h : Feasible X s t) : 862 ≤ X.toFinset.card := by
  have none : exceptional X=∅ := by
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro e he
    obtain ⟨mem,perm,tr⟩ := Finset.mem_filter.mp he
    exact (moves e (Multiset.mem_toFinset.mp mem)).elim perm tr
  have cost := weighted_exception_bound h
  rw [none,Finset.card_empty] at cost
  omega

theorem no_clean_flow {X : Multiset Block} {s t : Block} (hsize : X.card ≤ 858)
    (moves : ∀ e∈X, e∈required ∨ ∃ q∈roots, e∈wheel q) : ¬Feasible X s t := by
  intro h
  have floor := clean_support_floor moves h
  have total := Multiset.toFinset_card_le X
  omega

private theorem shapeTable :
    (representatives.map src).all (fun q =>
       (List.finRange 7).all fun x => decide ((dst (q++[x])).Nodup →
         (q++[x]).Nodup ∨ q++[x]∈wheel q)) = true := by native_decide

/-- Every seven-letter window between two contexts with six different
letters is exactly a permutation transition or an ordinary wheel step. -/
theorem clean_classification {e : Block} (len : e.length=7)
    (ha : (src e).Nodup) (hb : (dst e).Nodup) :
    e∈required ∨ ∃ q∈roots, e∈wheel q := by
  let q := src e
  have qlen : q.length=6 := by simp [q,src,len]
  have miss : ∃ z : Fin 7, z∉q := by
    have cap := q.toFinset_card_le
    have card : q.toFinset.card < (Finset.univ : Finset (Fin 7)).card := by
      simpa [qlen] using (show q.toFinset.card < 7 by omega)
    obtain ⟨z,_,hz⟩ := Finset.exists_mem_notMem_of_card_lt_card card
    exact ⟨z,fun h => hz (List.mem_toFinset.mpr h)⟩
  obtain ⟨z,absent⟩ := miss
  have perm : q++[z]∈representatives := (mem_reps _).mpr ⟨by simp [qlen],by
    simp [List.nodup_append,show q.Nodup from ha]
    rintro a hm rfl
    exact absent hm⟩
  have rootq : q∈representatives.map src := by
    apply List.mem_map.mpr
    refine ⟨_,perm,?_⟩
    change (q++[z]).take 6=q
    rw [←qlen,List.take_left]
  have en : ∃ x : Fin 7, e=q++[x] := by
    have size : (e.drop 6).length=1 := by simp [len]
    obtain ⟨x,hx⟩ := List.length_eq_one_iff.mp size
    exact ⟨x,by simp [q,src,←hx]⟩
  obtain ⟨x,eq⟩ := en
  have table := of_decide_eq_true (List.all_eq_true.mp
    (List.all_eq_true.mp shapeTable q rootq) x (List.mem_finRange x))
  rw [←eq] at table
  rcases table hb with good | ord
  · exact Or.inl ((mem_reps e).mpr ⟨len,good⟩)
  · exact Or.inr ⟨q,List.mem_toFinset.mpr rootq,ord⟩

/-- Every feasible placement at 858 actually visits a repeated-letter
six-context, even when the two endpoints are arbitrary. -/
theorem dirty_context_required {X : Multiset Block} {s t : Block}
    (budget : X.card≤858) (h : Feasible X s t) :
    ∃ e∈X, ¬ (src e).Nodup ∨ ¬ (dst e).Nodup := by
  classical
  by_contra! clean
  apply no_clean_flow budget _ h
  intro e he
  exact clean_classification (h.edges_seven _ he) (clean e he).1 (clean e he).2

end CleanFlow
#print axioms CleanFlow.weighted_exception_bound
#print axioms CleanFlow.four_exceptional
#print axioms CleanFlow.no_clean_flow

#print axioms CleanFlow.dirty_context_required

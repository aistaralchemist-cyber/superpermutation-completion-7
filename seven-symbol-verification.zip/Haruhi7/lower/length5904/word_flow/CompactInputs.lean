import CompactLayout
import CompactBenes

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows BenesRouting

def wordSource (w : Block) (bank : Bank) : Source → Bool
  | .one => true
  | .symbol i a => decide ((w[i]?).map Fin.val = some a)
  | .switch n b j => bank n b j

def slot (i a : Nat) : W := Int.ofNat (2+7*i+a)
def slotRow (i : Nat) : Bits := (Array.range 7).map (slot i)
def hot (w : Block) (i : Nat) := (Array.range 7).map fun a=>decide ((w[i]?).map Fin.val = some a)

def registers : List Event → List Event := List.filter fun e=>match e with
  | .assertion _ => false | _ => true

theorem reads_registers {src : Source → Bool} {v : Nat → Bool} {es : List Event} {n : Nat}
    (ad : admits (sourceTest src v) n es) {i : Nat} {s : Source}
    (read : (registers es)[i]?=some (.fresh s)) : v (n+i)=src s := by
  induction es generalizing n i with
  | nil => simp [registers] at read
  | cons e es ih =>
    have tail := ad.2
    cases e with
    | assertion xs => exact ih tail (by simpa [registers] using read)
    | fresh a =>
      cases i with
      | zero =>
        have eq : a=s := by simpa [registers] using read
        subst s
        simpa [sourceTest] using ad.1
      | succ i =>
        have h := ih tail (i:=i) (by simpa [registers] using read)
        simpa [advance,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using h
    | gateOr xs =>
      cases i with
      | zero => simp [registers] at read
      | succ i =>
        have h := ih tail (i:=i) (by simpa [registers] using read)
        simpa [advance,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using h
    | gateMux c a b =>
      cases i with
      | zero => simp [registers] at read
      | succ i =>
        have h := ih tail (i:=i) (by simpa [registers] using read)
        simpa [advance,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using h

def inputReg := (registers layout.cols.log.toList).toArray

set_option maxRecDepth 100000 in
theorem input_table : layout.cols.base=0 ∧ layout.cols.out = (Array.range 1501).map slotRow ∧
    inputReg[0]? = some (.fresh .one) ∧
    ∀i : Fin 1501,∀a : Fin 7, inputReg[1+7*i.val+a.val]? = some (.fresh (.symbol i.val a.val)) := by
  native_decide

theorem source_unit {src : Source → Bool} {v : Nat → Bool}
    (h : admits (sourceTest src v) 0 layout.cols.log.toList) : v 0=src .one := by
  apply reads_registers (n:=0) (i:=0) h
  simpa [inputReg] using input_table.2.2.1

theorem source_slot {src : Source → Bool} {v : Nat → Bool}
    (h : admits (sourceTest src v) 0 layout.cols.log.toList) (i : Fin 1501) (a : Fin 7) :
    Rep v (src (.symbol i a)) (slot i a) := by
  have id : (registers layout.cols.log.toList)[1+7*i.val+a.val]? = some (.fresh (.symbol i a)) := by
    simpa [inputReg] using input_table.2.2.2 i a
  have eq := reads_registers h id
  have pos : 0 < (2+7*i.val+a.val : Nat) := by omega
  have rwIndex : 2+7*i.val+a.val-1 = 1+7*i.val+a.val := by omega
  refine ⟨Int.ofNat_ne_zero.mpr (by omega),?_⟩
  change v (2+7*i.val+a.val-1) = _
  simpa only [rwIndex,Nat.zero_add] using eq

theorem column_values {w : Block} {f : Bank} {v : Nat → Bool}
    (h : admits (sourceTest (wordSource w f) v) 0 layout.cols.log.toList) :
    ArrayRel (RowRep v 7) layout.cols.out ((Array.range 1501).map (hot w)) := by
  rw [input_table.2.1]
  unfold ArrayRel
  simp only [Array.toList_map, Array.toList_range]
  apply List.forall₂_of_length_eq_of_get (by simp)
  intro i hi hj
  simp only [List.get_eq_getElem,List.getElem_map,List.getElem_range]
  refine ⟨by simp [slotRow],?_⟩
  unfold slotRow hot ArrayRel
  simp only [Array.toList_map,Array.toList_range]
  apply List.forall₂_of_length_eq_of_get (by simp)
  intro a ha hb
  simp only [List.get_eq_getElem,List.getElem_map,List.getElem_range]
  exact source_slot h ⟨i,by simpa using hi⟩ ⟨a,by simpa using ha⟩

theorem input_claims {w : Block} {f : Bank} {v : Nat → Bool} (len : w.length = 1501)
    (h : admits (sourceTest (wordSource w f) v) 0 layout.cols.log.toList) :
    ∀r∈assertionsOf layout.cols.out,r.any (wire v)=true := by
  rw [input_table.2.1]
  intro r mem
  obtain unit := source_unit h
  rcases List.mem_append.mp mem with one|other
  · obtain rfl := List.mem_singleton.mp one
    simpa [wire,wordSource] using unit
  obtain ⟨row,hr,member⟩:=List.mem_flatMap.mp other
  simp only [Array.toList_map,Array.toList_range,List.mem_map,List.mem_range] at hr
  obtain ⟨i,hi,rfl⟩:=hr
  have valid : i<w.length := len ▸ hi
  let a := w[i]'valid
  have atI : w[i]? = some a := getElem?_pos w i valid
  have val (j : Nat) (hj : j<7) : wire v ((slotRow i)[j]!) = decide (a.val=j) := by
    have z := (source_slot h ⟨i,hi⟩ ⟨j,hj⟩).2
    simpa [slotRow,getElem!_pos,wordSource,atI,hj] using z
  rcases List.mem_cons.mp member with rfl|pair
  · apply List.any_eq_true.mpr
    exact ⟨(slotRow i)[a.val]!, Array.mem_toList_iff.mpr
      (by rw [getElem!_pos _ _ (by simp [slotRow])]; exact Array.getElem_mem ..),
      by simpa using val a.val a.isLt⟩
  obtain ⟨j,hj,element⟩:=List.mem_flatMap.mp pair
  obtain ⟨b,hb,rfl⟩:=List.mem_map.mp element
  have j7 := List.mem_range.mp hj
  have lb : j+1 ≤ b ∧ b<7 := by
    obtain ⟨k,hk,eqk⟩:=List.mem_iff_getElem.mp hb
    simp only [List.getElem_drop,List.getElem_range] at eqk
    simp only [List.length_drop,List.length_range] at hk
    omega
  have nz (t : Nat) (ht : t<7) : (slotRow i)[t]! ≠ 0 := by
    simpa [slotRow,getElem!_pos,ht] using (source_slot h ⟨i,hi⟩ ⟨t,ht⟩).1
  simp only [List.any_cons,List.any_nil,Bool.or_false,wire_neg (nz j j7),wire_neg (nz b lb.2),
    val j j7,val b lb.2]
  by_cases eq:a.val=j <;> simp_all
  omega

end ExactWordFlow.CompactWordCircuit

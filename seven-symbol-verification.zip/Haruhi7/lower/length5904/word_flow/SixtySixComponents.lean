import LongComponent
import LongDensity

namespace ExactWordFlow
open ResidualIncidence ResidualRoutes ResidualDensity
open scoped Classical

noncomputable def activeOther (X : Multiset Block) (s : Block) :=
  ((((support X s).image (label X)).erase (label X s)).filter (fun q => (part X q).card≠0))

/-- Arbitrary endpoints, wheel labels and component shapes. If the 66
nonempty components off the start each have size six, the main component
has 462 edges and must touch between 390 and 394 rotation classes. -/
theorem sixty_six_components {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card=858) (n : (activeOther X s).card=66)
    (six : ∀ q∈activeOther X s, (part X q).card=6) :
    (part X (label X s)).card=462 ∧
    390 ≤ (contacts (support X s) (label X) (label X s)).card ∧
    (contacts (support X s) (label X) (label X s)).card≤394 := by
  classical
  let home := label X s
  let D := support X s
  let Q := D.image (label X)
  let K (q) := (part X q).card
  let C (q) := (contacts D (label X) q).card
  let A := activeOther X s
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have Qc (e) (he : e∈X) : label X (src e)∈Q := by
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩)))
  have active (q) (hq : q∈Q.erase home) : q∈A ↔ K q≠0 := by
    change q∈((Q.erase home).filter _) ↔ _
    simp [hq,K]
  have kform (q) (hq : q∈Q.erase home) : K q = if q∈A then 6 else 0 := by
    split
    next yes => exact six q yes
    next no => by_contra bad; exact no ((active q hq).mpr bad)
  have elem : (Q.erase home).filter (·∈A)=A := by
    apply Finset.filter_mem_eq_inter.trans
    exact Finset.inter_eq_right.mpr (Finset.filter_subset ..)
  have total := sum_part_card X Q Qc
  rw [← Finset.sum_erase_add _ _ root] at total
  change (∑ q∈Q.erase home, K q) + K home = X.card at total
  rw [Finset.sum_congr rfl kform, Finset.sum_ite, elem] at total
  have na : A.card=66 := n
  simp [na,budget] at total
  have main : K home=462 := by omega
  have caps (q) (hq : q∈Q.erase home) : C q-1 ≤ if q∈A then 5 else 0 := by
    obtain ⟨qh,hm⟩ := Finset.mem_erase.mp hq
    obtain ⟨v,_,lv⟩ := Finset.mem_image.mp hm
    obtain ⟨a,b,es,eq,r,lab,ends⟩ := component_route h.balance v
    rw [lv] at eq lab ends
    obtain ⟨ra,rb⟩ := ends.2 qh
    subst a; subst b
    have wl : es.length=K q := congrArg Multiset.card eq
    have ww (e) (he : e∈es) : e.length=7 := by
      exact h.edges_seven _ (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have ck := contacts_bound D lab r eq
    change C q≤_ at ck
    have form := kform q hq
    by_cases hit : q∈A <;> simp [hit] at form ⊢ <;>
      have bd := closed_route_gain r ww (by omega) <;> omega
  have leftSum := Finset.sum_le_sum caps
  rw [Finset.sum_ite,elem] at leftSum
  simp [na] at leftSum
  have rank := rank719 (label X) h (fun _ he => on_edge he)
  change 719 ≤ ∑ q∈Q, (C q-1) at rank
  rw [← Finset.sum_erase_add _ _ root] at rank
  obtain ⟨a,b,es,eq,r,lab,_⟩ := component_route h.balance s
  have len : es.length=K home := congrArg Multiset.card eq
  have ww (e) (he : e∈es) : e.length=7 :=
    h.edges_seven _ (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
  exact ⟨main,(by change 390≤C home; omega),(contacts_bound D lab r eq).trans (open_route_462 r ww (len.trans main))⟩

#print axioms sixty_six_components
end ExactWordFlow

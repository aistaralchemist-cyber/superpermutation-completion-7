import Interval66

namespace ResidualDensity.MarkedGeometry
open SevenWordWindows
open private normalize canonical from Interval66
open private search_complete from Geometry40
open private unmask mask_cons from StrongerDensity
open private count_add from DensityBudget

/-- Run lengths of marked positions; one unmarked position separates the runs. -/
def profileList : List (List Nat) := [
  [5, 5, 5],
  [4, 5, 6, 4],
  [4, 6, 5, 4],
  [3, 5, 6, 6, 3],
  [3, 6, 6, 5, 3],
  [2, 5, 6, 6, 6, 2],
  [2, 6, 6, 6, 5, 2],
  [1, 6, 6, 6, 6, 6],
  [3, 6, 6, 6, 6, 4],
  [4, 6, 6, 6, 6, 3],
  [6, 6, 6, 6, 6, 1],
  [1, 6, 4, 6, 4, 6, 6],
  [6, 6, 4, 6, 4, 6, 1],
  [3, 2, 6, 6, 6, 6, 4, 6, 6, 6, 4],
  [3, 6, 2, 6, 6, 6, 6, 4, 6, 6, 4],
  [4, 6, 6, 4, 6, 6, 6, 6, 2, 6, 3],
  [4, 6, 6, 6, 4, 6, 6, 6, 6, 2, 3],
  [6, 4, 6, 6, 6, 3, 6, 6, 6, 4, 6],
  [3, 6, 6, 4, 6, 6, 4, 6, 6, 4, 6, 6, 3],
  [3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6],
  [6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3],
  [2, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3],
  [3, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4],
  [3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 2],
  [4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 3],
  [1, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 3, 6, 6, 4],
  [2, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4],
  [4, 6, 6, 3, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 1],
  [4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 2],
  [2, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 3],
  [3, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 4, 6, 6, 6, 2]
]

def forbidden := (List.replicate 7 true)::profileList.map rowsMask

private theorem rejected : profileList.all (fun ns =>
    !ns.isEmpty && ns.all (fun n=>decide (0<n)) &&
    canonical.all (fun s => !rowSearch ns s []))=true := by native_decide

private theorem no_profile {u : ℕ→Six} {p : ℕ→Prop} (w : Walk u) (h : Marked u p)
    (ns : List Nat) (hn : ns∈profileList) (i : ℕ) (marks : rowsMarked p i ns) : False := by
  have ⟨⟨nonempty,positive⟩,bad⟩ := Bool.and_eq_true_iff.mp (List.all_eq_true.mp rejected ns hn)
    |>.imp_left Bool.and_eq_true_iff.mp
  have pos (n) (hm : n∈ns) := of_decide_eq_true (List.all_eq_true.mp positive n hm)
  have first : p i := by
    cases ns with
    | nil => simp at nonempty
    | cons n rest => simpa using marks.1 0 (pos n List.mem_cons_self)
  obtain ⟨v,vw,vm,initial⟩:=normalize w h i first
  have yes:=search_complete vw vm ns pos i marks [] (by simp)
  have no:=List.all_eq_true.mp bad _ initial
  simp [yes] at no

private theorem submask {p : ℕ→Prop} [DecidablePred p] (i n : ℕ) (l xs r : List Bool)
    (eq : l++xs++r=mask p i n) : mask p (i+l.length) xs.length=xs := by
  have width := congrArg List.length eq
  simp only [mask,List.length_append,List.length_map,List.length_range] at width
  apply List.ext_getElem
  · simp [mask]
  · intro j hj hk
    have bound : l.length+j<n := by omega
    have v := congrArg (fun words : List Bool => words[l.length+j]?) eq
    simpa [mask,List.append_assoc,List.getElem?_append_right,show l.length≤l.length+j by omega,
      List.getElem?_append_left hk,bound,hk,Nat.add_assoc] using v.symm

theorem safe {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i n : ℕ) : ∀x∈forbidden, ¬ x <:+: mask p i n := by
  rintro x mem ⟨l,r,eq⟩
  have sub := submask i n l x r eq
  rcases List.mem_cons.mp mem with rfl|other
  · simp only [List.length_replicate] at sub
    apply no_seven w m (i+l.length)
    intro j hj
    have h := congrArg (fun bs : List Bool => bs[j]?) sub
    rw [List.getElem?_replicate_of_lt (by omega : j<7)] at h
    simpa [mask,show j<7 by omega,Nat.add_assoc] using h
  · obtain ⟨ns,hn,rfl⟩:=List.mem_map.mp other
    exact no_profile w m ns hn _ (unmask _ _ ns sub)

theorem mark_count (p : ℕ→Prop) [DecidablePred p] (i n : ℕ) :
    (mask p i n).count true=count p i n := by
  induction n generalizing i with
  | zero => simp [mask,count]
  | succ n ih =>
    have h := count_add p i 1 n
    rw [show 1+n=n+1 by omega] at h
    rw [mask_cons,h,List.count_cons,ih]
    have one : count p i 1=if p i then 1 else 0 := by
      simp only [count,Finset.card_filter,Finset.range_one,Finset.sum_singleton,Nat.add_zero]
    rw [one]
    by_cases yes : p i <;> simp [yes,Nat.add_comm]
end ResidualDensity.MarkedGeometry

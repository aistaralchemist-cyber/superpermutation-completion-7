import LongMass

namespace ExactWordFlow
open ResidualIncidence ResidualRoutes ResidualDensity DirectedEuler SevenWordWindows
open scoped Classical

theorem long_mass_le (X : Multiset Block) (s : Block) : largeMass X s≤X.card := by
  classical
  let g := label X
  let Q := (support X s).image g
  let K (q : Component X) := (part X q).card
  have hs : ∀e∈X, g (src e)∈Q := by
    intro e he
    change label X (src e)∈Q
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩)))
  have n := sum_part_card X Q hs
  have start : g s∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have sub : largeOther X s ⊆ Q.erase (g s) := by
    intro q hq
    obtain ⟨hit,away,_⟩ := Finset.mem_filter.mp hq
    exact Finset.mem_erase.mpr ⟨away,hit⟩
  have bound := Finset.sum_le_sum_of_subset (f:=K) sub
  have k := Finset.sum_erase_add (s:=Q) K start
  change (∑ q∈Q, K q)=X.card at n
  change K (g s)+(∑q∈largeOther X s,K q)≤X.card
  omega

private theorem all_contacts (D : Finset Block) {ι : Type*} [DecidableEq ι]
    (g : Block → ι) (q : ι) : (contacts D g q).card ≤ 720 := by
  classical
  have tb : states.all (fun v => decide (tag v∈allClasses)) = true := by native_decide
  have sz : allClasses.card=720 := by native_decide
  rw [←sz]
  apply Finset.card_le_card
  intro c hc
  obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hc
  exact of_decide_eq_true (List.all_eq_true.mp tb _ (mem_states (Finset.mem_filter.mp hv).2.2))

/-- Upper bound on the classes seen by an open component of length k.
It combines the global 720 ceiling with the 40- and 7-position windows. -/
def rootClassCap (k : Nat) :=
  min 720 (34*((k+1)/40)+6*((k+1)%40/7)+(k+1)%40%7)

theorem root_class_cap {X : Multiset Block} {s t : Block}
    (bal : X.map src+{t}=X.map dst+{s}) (width : ∀e∈X, e.length=7) :
    (contacts (support X s) (label X) (label X s)).card≤rootClassCap (part X (label X s)).card := by
  classical
  let q := label X s
  let C := (contacts (support X s) (label X) q).card
  let k := (part X q).card
  obtain ⟨a,b,es,eq,r,lab,_⟩ := component_route bal s
  have len : es.length=k := congrArg Multiset.card eq
  have ww (e) (h : e∈es) := width e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from h))).1
  have cnt := contacts_bound (support X s) lab r eq
  change C ≤ classCount a es at cnt
  obtain ⟨u,I,w,hm,hc⟩ := open_observations r ww
  have b40 := window_open_bound w hm (interval40 w hm) 0 (es.length+1)
  rw [hc,len] at b40
  have finite : C ≤720 := all_contacts .. 
  exact le_min finite (cnt.trans b40)

/-- This upper bound is valid even for a disconnected, degree-balanced
placement. No test of individual starts or ends is needed. -/
theorem separate_rank_at_most_729 {X : Multiset Block} {s t : Block}
    (bal : X.map src+{t}=X.map dst+{s}) (width : ∀ e∈X, e.length=7)
    (budget : X.card≤858) : separateRank X s≤729 := by
  classical
  have prices := component_prices bal width
  have lm := long_mass_le X s
  by_cases emp : largeOther X s=∅
  · let q := label X s
    let C := (contacts (support X s) (label X) q).card
    let k := (part X q).card
    have cap (j : Fin 859) :
        6*(min 720 (34*((j.val+1)/40)+6*((j.val+1)%40/7)+(j.val+1)%40%7)-1) +
          5*(858-j.val) < 6*730 := by
      revert j
      decide +kernel
    have short : k≤X.card := Multiset.card_le_card (by classical exact Multiset.filter_le ..)
    have upper := cap ⟨k,by omega⟩
    change 6*(min 720 (34*((k+1)/40)+6*((k+1)%40/7)+(k+1)%40%7)-1)+5*(858-k)<6*730 at upper
    have both : C ≤ min 720 (34*((k+1)/40)+6*((k+1)%40/7)+(k+1)%40%7) := root_class_cap bal width
    have remain := prices.2.2 emp
    change 6*separateRank X s+5*k ≤ 5*X.card+6*(C-1) at remain
    omega
  · have pos : 0<(largeOther X s).card := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr emp)
    have sum := prices.1
    omega

/-- A structural certificate showing a loss of eleven rank units rules out
every arrangement of at most 858 edges, for arbitrary global endpoints. -/
theorem exclude_eleven_loss {X : Multiset Block} {s t : Block}
    (budget : X.card≤858) (loss : Feasible X s t → 719+11 ≤ separateRank X s) :
    ¬Feasible X s t := by
  intro h
  have hi := separate_rank_at_most_729 h.balance h.edges_seven budget
  have lo := loss h
  omega

#print axioms separate_rank_at_most_729
#print axioms exclude_eleven_loss
end ExactWordFlow

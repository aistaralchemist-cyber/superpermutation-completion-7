import WordFlow

namespace ExactWordFlow.PacketJoin

/-- Append one packet at a time, using the existing last letter as the
prescribed first letter of the next packet. The original seed remains a
prefix and every required substring of every packet remains an infix. -/
theorem glue {κ : Type*} [DecidableEq κ] (S : Finset κ) (K : κ→Nat) (P : κ→Block→Prop)
    (w : Block) (seed : w≠[]) (packets : ∀q∈S,∀a : Fin 7,∃tail : Block,
        tail.length=K q+5 ∧ ∀e,P q e→e <:+: (a::tail)) :
    ∃z : Block, z.length=w.length+∑q∈S,(K q+5) ∧ w <+: z ∧
      ∀q∈S, ∀e,P q e→e <:+: z := by
  induction S using Finset.induction_on with
  | empty => exact ⟨w,by simp,⟨[],by simp⟩,by simp⟩
  | @insert q S new ih =>
    obtain ⟨u,len,pref,prior⟩:=ih (fun j hj=>packets j (Finset.mem_insert_of_mem hj))
    have nonempty : u≠[] := by
      have pos:=List.length_pos_iff.mpr seed
      intro nil
      simp [nil] at len
      omega
    let a:=u.getLast nonempty
    obtain ⟨tail,size,inside⟩:=packets q (Finset.mem_insert_self ..) a
    have suffix : a::tail <:+: u++tail := by
      refine ⟨u.dropLast,[],?_⟩
      simp only [List.append_nil]
      rw [show u++tail=(u.dropLast++[a])++tail by rw [List.dropLast_concat_getLast nonempty]]
      simp
    refine ⟨u++tail,by rw [List.length_append,len,size,Finset.sum_insert new]; omega,
      pref.trans (List.prefix_append ..),?_⟩
    intro k hk e required
    rcases Finset.mem_insert.mp hk with rfl|old
    · exact (inside e required).trans suffix
    · exact (prior k old e required).trans List.infix_append_left

#print axioms glue
end ExactWordFlow.PacketJoin

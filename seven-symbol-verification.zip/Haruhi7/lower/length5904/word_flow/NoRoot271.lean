import NoRoot265

namespace ExactWordFlow.NoRoot271
open SevenWordWindows ResidualDensity DirectedEuler WeightedMarks MarkedGeometry Cap95Marked
open private optimal maximizer from Cap95Profiles
open private initial start from MarkedDensity
open private unmask mask_cons from StrongerDensity
open private canonical normalize from Interval66
open private search_complete from Geometry40
open private runs from MarkedExtrema

private def failed (bs : List Bool) : Bool :=
  let ns := runs bs 0
  bs==rowsMask ns && bs.head?==some true && ns.all (fun k=>decide (0<k)) &&
    canonical.all (fun s=> !rowSearch ns s [])

theorem number_of_maximizers : (optimal 272 initial).length=20 := by native_decide

private theorem data : upper 272 initial=231 ∧ (optimal 272 initial).all failed=true := by native_decide

/-- All maximizers of the relaxed 272-position window fail the forced
row transitions. No physical path with 271 edges can therefore hit 231 tags. -/
theorem marks (u : Nat→Six) (p : Nat→Prop) [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i : Nat) : count p i 272≤230 := by
  by_contra! many
  let bs:=mask p i 272
  have len : bs.length=272:=by simp [bs,mask]
  have hi : upper bs.length initial≤bs.count true := by rw [len,data.1,mark_count]; omega
  have hit:=maximizer [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i 272) hi
  rw [len] at hit
  have h:=List.all_eq_true.mp data.2 _ hit
  unfold failed at h
  simp only [Bool.and_eq_true,beq_iff_eq] at h
  obtain ⟨⟨⟨pattern,head⟩,positive⟩,dead⟩:=h
  have first : p i := by
    change (mask p i (271+1)).head?=some true at head
    rw [mask_cons] at head
    exact of_decide_eq_true (Option.some.inj head)
  have marked:=unmask i 272 (runs bs 0) pattern
  obtain ⟨v,vw,vm,iv⟩:=normalize w m _ first
  have nz (k) (mem : k∈runs bs 0) : 0<k := of_decide_eq_true (List.all_eq_true.mp positive k mem)
  have feasible:=search_complete vw vm _ nz _ marked [] (by simp)
  have no:=List.all_eq_true.mp dead _ iv
  simp [feasible] at no

theorem route {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀e∈es,e.length=7) (len : es.length=271) : classCount s es≤230 := by
  obtain ⟨u,I,walk,mark,eq⟩:=open_observations r wd
  rw [len] at eq
  exact eq ▸ marks u (·∈I) walk mark 0

#print axioms route
end ExactWordFlow.NoRoot271

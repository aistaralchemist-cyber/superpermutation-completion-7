import CompactInputs
import FrontRecordGates

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows CoreRecordBits

def rawBinary (bs : Array Bool) := ((List.range 3).reverse.map fun bit =>
  (((List.range bs.size).filter (·.testBit bit)).map fun a=>bs[a]!).any id).toArray

theorem binary_grows (row : Bits) : Grows (binary row 3) :=
  map_grows _ (mapList_grows (fun _=>anyGate_grows _) _)

theorem binary_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {bs : Array Bool} {row : Bits} (h : BitsRep v bs row) :
    Gives T (binary row 3) (BitsRep v (rawBinary bs)) := by
  let f (bit : Nat) := (((List.range bs.size).filter (·.testBit bit)).map fun a=>bs[a]!).any id
  have sizes : row.size=bs.size := by simpa using h.length_eq.symm
  have same (a : Nat) (ha : a<bs.size) : Rep v bs[a]! row[a]! :=
    ArrayRel.get (R:=Rep v) h a ha
  let op (bit : Nat) := anyGate (((List.range row.size).filter (·.testBit bit)).map fun a=>row[a]!)
  have each (bit : Nat) : Gives T (op bit) (Rep v (f bit)) := by
    unfold op f
    rw [sizes]
    apply bool_or_gives law unit
    apply rep_map
    exact fun a mem => same _ (List.mem_range.mp (List.mem_filter.mp mem).1)
  exact map_gives (mapList_grows (fun _=>anyGate_grows _) _) (mapList_gives (f:=op)
    (fun _=>anyGate_grows _) (List.range 3).reverse (fun a _=>each a))
    (fun _ pr=>by simpa [BitsRep,rawBinary,f] using replace_left pr)

private theorem mapPair_gives {T : Test} {f : α→M β} {R : α→γ→Prop} {S : β→γ→Prop}
    (g : ∀x,Grows (f x)) (step : ∀x y,R x y → Gives T (f x) (S · y)) {xs ys}
    (h : List.Forall₂ R xs ys) :
    Gives T (xs.mapM f) (fun bs=> List.Forall₂ S bs ys) := by
  induction h with
  | nil => exact pure_gives .nil
  | @cons x y xs ys xy _ ih =>
    rw [List.mapM_cons]
    exact bind_gives (m:=f x) (k:=fun r=>do let rs ← xs.mapM f; pure (r::rs))
      (P:=fun r => S r y) (g x) (fun _=>bind_grows (mapList_grows g _) (fun _=>pure_grows _)) (step x y xy)
      (fun r hand=>bind_gives (mapList_grows g _) (fun _=>pure_grows _) ih
        (fun rs hrest=>pure_gives (List.Forall₂.cons hand hrest)))

theorem binary_cols_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {rows : Rows} {bss : Array (Array Bool)} (h : ArrayRel (RowRep v 7) rows bss) :
    Gives T (rows.mapM (binary · 3)) (fun rs=> ArrayRel (fun r bs=>BitsRep v (rawBinary bs) r) rs bss) := by
  rw [Array.mapM_eq_mapM_toList]
  exact bind_gives (mapList_grows binary_grows _) (fun _=>pure_grows _)
    (mapPair_gives binary_grows (R:=RowRep v 7) (S:=fun r bs=>BitsRep v (rawBinary bs) r)
      (fun _ _ hr=>binary_gives law unit (List.Forall₂.flip hr.2)) h)
    (fun _ hv=>pure_gives (by simpa [ArrayRel] using hv))

private def onehot (x : Fin 7) := (Array.range 7).map fun a=>decide (x.val=a)

private theorem hot_table : ∀x : Fin 7, ∀j : Fin 3,
    ((rawBinary (onehot x))[j.val]?).getD false = x.val.testBit (2-j.val) := by native_decide

theorem binary_symbol {w : Block} {i : Nat} (hi : i<w.length) (j : Fin 3) :
    ((rawBinary (hot w i))[j.val]?).getD false =
    (w[i]?.map (fun a=>a.val.testBit (2-j.val))).getD false := by
  have hh : w[i]? = some (w[i]'hi) := List.getElem?_eq_getElem hi
  rw [hh]
  have eq : hot w i=onehot (w[i]'hi) := by simp [hot,onehot,hh]
  rw [eq]
  exact hot_table _ j

#print axioms binary_cols_gives
end ExactWordFlow.CompactWordCircuit

import LocalDeletion
import LapMultiplicity

namespace ExactWordFlow.LocalDeletion
open SevenWordWindows ResidualDensity
open private cleanTags from LapMultiplicity

theorem frequency_eq (w c : Block) : freq6 w c=(LapMultiplicity.tags w).count c := by
  rw [freq6_anchors]
  simp only [LapMultiplicity.tags,cleanTags,Multiset.coe_count,List.count_eq_countP,Bool.beq_eq_decide_eq]

theorem tag_count (l : Block) (x : Fin 7) (r c : Block) :
    (LapMultiplicity.tags (l++[x]++r)).count c + (LapMultiplicity.tags (localPart 5 l [] r)).count c =
      (LapMultiplicity.tags (l++r)).count c + (LapMultiplicity.tags (localPart 5 l [x] r)).count c := by
  simpa only [frequency_eq] using visit6_count l x r c

#print axioms tag_count
end ExactWordFlow.LocalDeletion

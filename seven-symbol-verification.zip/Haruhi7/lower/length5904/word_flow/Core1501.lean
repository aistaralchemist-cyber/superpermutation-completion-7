import BudgetCoreCurve
import Boundary1508Floor

namespace ExactWordFlow.Core1501
open SevenWordWindows SuperpermutationBounds RotationCore RotationComponentCount

/-- The previously proved lower bound on seven-symbol words gives an
absolute completion ceiling, independent of the component census. -/
theorem ceiling : Target107.ceiling 1501 91 :=
  LastCompletion.cap_from_floor (lower:=5899)
    SuperpermLowerBounds.covers_lower_bound_7_k16_native (by decide) (by decide)

theorem exact (cap : ∀{X : Multiset Block} {s t : Block}, Feasible X s t →
    X.card≤858 → (occupied X s).card≤91) :
    (∃w:Block,Covers w ∧ w.length≤5904) ↔
    ∃v:Block,v.length=1501 ∧ (visited v).card=720 ∧ (complete v).card=91 := by
  have threshold := BudgetCoreCurve.threshold 858 91 (by decide) cap
  change (∃w:Block,Covers w ∧ w.length≤5904) ↔
    ∃v:Block,v.length=1501 ∧ (visited v).card=720 ∧ 91≤(complete v).card at threshold
  rw [threshold]
  constructor
  · rintro ⟨v,size,all,done⟩
    exact ⟨v,size,all,le_antisymm (ceiling v size.le all) done⟩
  · rintro ⟨v,size,all,done⟩
    exact ⟨v,size,all,done.ge⟩

/-- Both words use the designated 5905-letter record as their source. -/
theorem controls :
    RotationCoreControls.summary (RotationCoreControls.coreTruncated 629)=(1501,720,90) ∧
    RotationCoreControls.summary (RotationCoreControls.coreWord 629)=(1502,720,91) := by native_decide

theorem completion_goal (cap : ∀{X : Multiset Block} {s t : Block}, Feasible X s t →
    X.card≤858 → (occupied X s).card≤91) :
    (¬∃w:Block,Covers w ∧ w.length≤5904) ↔ Target107.ceiling 1501 90 := by
  rw [exact cap]
  constructor
  · intro bad v size hit
    by_contra! more
    have top:=ceiling v size hit
    have low:=LapSkeleton.completed_floor v
    have room : (good v).length≤v.length-6 := by rw [←windows_length];exact List.length_filter_le ..
    obtain ⟨z,len,vis,fin⟩:=ExactBoundary.pad (n:=1501) (by omega : 6≤v.length) size
    exact bad ⟨z,len,vis ▸ hit,fin ▸ (by omega : (complete v).card=91)⟩
  · rintro bound ⟨v,len,hit,done⟩
    have:=bound v len.le hit
    omega

#print axioms exact
#print axioms controls
#print axioms completion_goal
end ExactWordFlow.Core1501

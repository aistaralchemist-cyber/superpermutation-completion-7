import SharedRootForcing
namespace ExactWordFlow.MultipleRootContacts
open Equiv
variable {X Y Z : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y] [DecidableEq Z]

/-- Contract connected pieces of the known correction cycles. Two tags
may receive the same colour when closure under E always transfers one to
the other; a chain of several distinct exceptional cycles is permitted.
An ordinary wheel is charged for every visit beyond its distinct colours.
Repetitions on the known cycles are paid from the very same budget. -/
theorem contracted_rank {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (colour : Y→Z)
    (sound : ∀C : Finset Y,(∀e∈E,(C∩e.support.image tag).Nonempty → e.support.image tag⊆C) →
      ∀a b,colour a=colour b → a∈C → b∈C) :
    (∑c∈h.cycleFactorsFinset,(c.support.card-
      (if c∈E then (c.support.image tag).card else ((c.support.image tag).image colour).card)))≤2*g := by
  classical
  let T (c : Perm X):=c.support.image tag
  let F (c : Perm X):=(T c).image colour
  let pick (c : Perm X) (z : Z):= if yes : z∈F c then (Finset.mem_image.mp yes).choose else tag start
  have good (c) (z) (yes : z∈F c) : pick c z∈T c ∧ colour (pick c z)=z := by
    simpa [pick,yes] using (Finset.mem_image.mp yes).choose_spec
  let K (c : Perm X):=if c∈E then T c else (F c).image (pick c)
  have inside (c) (_ : c∈h.cycleFactorsFinset) : K c⊆T c := by
    by_cases e : c∈E
    · simp [K,e]
    · intro x hx
      obtain ⟨z,hz,rfl⟩:=Finset.mem_image.mp (show x∈(F c).image (pick c) by simpa [K,e] using hx)
      exact (good c z hz).1
  have witness (c) (x) (hx : x∈T c) : ∃y∈K c,colour y=colour x := by
    by_cases e : c∈E
    · exact ⟨x,by simpa [K,e] using hx,rfl⟩
    · have z : colour x∈F c := Finset.mem_image_of_mem _ hx
      exact ⟨pick c (colour x),by simpa [K,e] using Finset.mem_image_of_mem (pick c) z,(good c _ z).2⟩
  have present (c) (hc : c∈h.cycleFactorsFinset) : (K c).Nonempty := by
    obtain ⟨x,hx,_⟩:=(Perm.mem_cycleFactorsFinset_iff.mp hc).1
    obtain ⟨y,hy,_⟩:=witness c (tag x) (Finset.mem_image_of_mem _ (Perm.mem_support.mpr hx))
    exact ⟨y,hy⟩
  have repair (C : Finset Y) (closed : ∀c∈h.cycleFactorsFinset,(C∩K c).Nonempty → K c⊆C) :
      ∀c∈h.cycleFactorsFinset,∀j∈T c,j∈C → T c⊆C := by
    have link := sound C (fun c hc => by
      simpa only [K,ite_eq_left hc,T] using closed c (known hc))
    intro c hc j hj seen x hx
    obtain ⟨a,ha,sameJ⟩:=witness c j hj
    obtain ⟨b,hb,dest⟩:=witness c x hx
    exact link b x dest (closed c hc ⟨a,Finset.mem_inter.mpr ⟨link j a sameJ.symm seen,ha⟩⟩ hb)
  have rank:=closure_rank start oneOrbit tag onto rot classes genus K inside present repair
  refine le_trans (Finset.sum_le_sum ?_) rank
  intro c _
  apply Nat.sub_le_sub_left
  by_cases e : c∈E
  · simp [K,T,e]
  · simpa only [K,T,F,ite_eq_right e] using (Finset.card_image_le (s:=F c) (f:=pick c))

#print axioms contracted_rank
end ExactWordFlow.MultipleRootContacts

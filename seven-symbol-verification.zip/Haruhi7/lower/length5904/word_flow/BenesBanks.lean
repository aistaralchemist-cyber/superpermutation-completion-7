import BenesRouting

namespace ExactWordFlow.BenesRouting
abbrev Bank := Nat → Bool → Nat → Bool

/-- Match the numeric switch names emitted by the Python and Lean circuits. -/
def readSettings (f : Bank) : (d : Nat) → Nat → Settings d
  | 0, _ => ()
  | 1, node => f node false 0
  | d+2, node =>
    (fun i => f node false (index (d+1) i).val,
     fun i => f node true (index (d+1) i).val,
     readSettings f (d+1) (2*node), readSettings f (d+1) (2*node+1))

private def child (node : Nat) (b : Bool) := 2*node + if b then 1 else 0
private def follow : Nat → List Bool → Nat
  | n, [] => n
  | n, b::bs => follow (child n b) bs

private def address (n : Nat) : List Bool :=
  if _h : n<2 then [] else address (n/2) ++ [decide (n%2=1)]
termination_by n

private theorem address_child (n : Nat) (pos : 0<n) (b : Bool) :
    address (child n b) = address n ++ [b] := by
  have big : ¬child n b<2 := by cases b <;> simp [child] <;> omega
  rw [address, dite_eq_right big]
  cases b <;> simp [child,show (2*n+1)/2=n by omega]

private theorem address_follow (n : Nat) (pos : 0<n) (p : List Bool) :
    address (follow n p) = address n ++ p := by
  induction p generalizing n with
  | nil => simp [follow]
  | cons b bs ih =>
    have positive : 0 < child n b := by unfold child; split <;> omega
    simpa [follow,address_child n pos] using ih _ positive

private def lookup : (d : Nat) → Settings d → List Bool → Bool → Nat → Bool
  | 0, _, _, _, _ => false
  | 1, flip, _, _, _ => flip
  | d+2, (a,z,_,_), [], back, j =>
    if h : j<2^(d+1) then (if back then z else a) ((index (d+1)).symm ⟨j,h⟩) else false
  | d+2, (_,_,top,bottom), b::rest, back, j =>
    if b then lookup (d+1) bottom rest back j else lookup (d+1) top rest back j

private theorem read_local (f : Bank) : ∀ (d : Nat) (node : Nat) (s : Settings d),
    (∀ p b i, f (follow node p) b i = lookup d s p b i) → readSettings f d node = s
  | 0,_,_,_ => rfl
  | 1,n,s,h => h [] false 0
  | d+2,n,(a,z,high,low),h => by
    have front (i : Wire (d+1)) : f n false (index (d+1) i).val = a i := by
      simpa [follow,lookup,(index (d+1) i).isLt] using h [] false (index (d+1) i).val
    have back (i : Wire (d+1)) : f n true (index (d+1) i).val = z i := by
      simpa [follow,lookup,(index (d+1) i).isLt] using h [] true (index (d+1) i).val
    have top := read_local f (d+1) (2*n) high (fun p b i => by
      simpa [follow,child,lookup] using h (false::p) b i)
    have bottom := read_local f (d+1) (2*n+1) low (fun p b i => by
      simpa [follow,child,lookup] using h (true::p) b i)
    exact Prod.ext (funext front) (Prod.ext (funext back) (Prod.ext top bottom))

/-- One global interpretation of numeric source names realizes arbitrary
independently chosen settings at every switch, including both banks. -/
theorem assign_banks (d : Nat) (s : Settings d) : ∃ f : Bank, readSettings f d 1 = s := by
  let f := fun n back i => lookup d s (address n) back i
  exact ⟨f,read_local f d 1 s (fun p b i => by
    simp [f,address_follow 1 (by decide),show address 1=[] by rw [address]; decide])⟩

theorem sort_with_named_banks {V K : Type} [LinearOrder K] (key : V → K) (xs : Fin 2048 → V) :
    ∃ (f : Bank) (p : Equiv.Perm (Fin 2048)), Monotone (fun i => key (xs (p i))) ∧
      ∀ j, run 11 (readSettings f 11 1) (fun w => xs (index 11 w)) ((index 11).symm j) =
        xs (p j) := by
  obtain ⟨s,p,h,sorted⟩ := sorted_records key xs
  obtain ⟨f,hf⟩ := assign_banks 11 s
  exact ⟨f,p,h,hf ▸ sorted⟩

#print axioms sort_with_named_banks
end ExactWordFlow.BenesRouting

import CompactWordCircuit
open ExactWordFlow.CompactWordCircuit

def writeFormula (file : System.FilePath) (t : Tape) : IO Unit := do
  let h ← IO.FS.Handle.mk file .write
  h.putStrLn s!"p cnf {t.vars} {clauseCount t}"
  let mut chunks : Array String := #[]
  let mut i := 0
  for e in t.body do
    for row in localClauses (Int.ofNat (i+1)) e do
      chunks := chunks.push ((String.intercalate " " (row.map toString)) ++ " 0\n")
    if chunks.size ≥ 4096 then
      h.putStr (String.join chunks.toList)
      chunks := #[]
    i := advance i e
  h.putStr (String.join chunks.toList)
  h.flush

def main (args : List String) : IO Unit := do
  let [symbols,len,count,mode,path] := args
    | throw (IO.userError "expected: symbols length target plain|cuts file.cnf")
  let some n := symbols.toNat? | throw (IO.userError "invalid alphabet")
  let some l := len.toNat? | throw (IO.userError "invalid length")
  let some k := count.toNat? | throw (IO.userError "invalid target")
  unless 2 ≤ n && n ≤ 7 && n-1 ≤ l && k ≤ (n-1).factorial &&
      (mode == "plain" || (mode == "cuts" && n == 7)) do
    throw (IO.userError "unsupported parameters")
  let t := compact n l k (mode == "cuts")
  IO.println s!"variables={t.vars} clauses={clauseCount t} events={t.body.size}"
  writeFormula path t

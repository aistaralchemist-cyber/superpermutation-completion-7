import FrontGateMeaning

namespace ExactWordFlow.CompactWordCircuit
open CompactFrontPlan FrontLocalMeaning

def pureMask (get : Ref→Bool) (next : Array Bool) (present : Bool) :=
  if present then (Array.range 7).map fun a =>
    get template.1.clean && get (missRef a) && (next[a]?).getD false
  else Array.replicate 7 false

def pureRow (ports next : Array Bool) (present cuts : Bool) : Array Bool × Bool × Bool :=
  let env := runPure (!·) false (fun xs=>xs.any id) ports template.2
  let get := lookup (!·) false env
  let mask := pureMask get next present
  (template.1.row.map get ++ mask,get template.1.clean, if present && cuts then mask.toList.any id else false)

def rowRep (v : Nat→Bool) (y : Array Bool × Bool × Bool) (x : Bits × W × W) :=
  BitsRep v y.1 x.1 ∧ Rep v y.2.1 x.2.1 ∧ Rep v y.2.2 x.2.2

theorem rep_map {v : Nat→Bool} {f : α→Bool} {g : α→W} (xs : List α)
    (h : ∀a∈xs,Rep v (f a) (g a)) : List.Forall₂ (Rep v) (xs.map f) (xs.map g) := by
  induction xs with
  | nil => exact .nil
  | cons a xs ih => exact .cons (h _ List.mem_cons_self) (ih fun x hx => h _ (List.mem_cons_of_mem _ hx))

theorem replace_left {f : α→β} {R : β→γ→Prop} {xs : List α} {ys : List γ}
    (h : List.Forall₂ (fun a b => R (f a) b) xs ys) : List.Forall₂ R (xs.map f) ys := by
  induction h with
  | nil => exact .nil
  | cons h _ ih => exact .cons h ih

theorem weaken_gives {T : Test} {m : M α} {P Q : α→Prop}
    (old : Gives T m P) (imp : ∀a,P a→Q a) : Gives T m Q :=
  fun st ok => imp _ (old st ok)

private def maskAction (e : Array W) (next : Array W) (present : Bool) : M Bits :=
  let get := lookup (-·) (-1) e
  if present then (Array.range 7).mapM (fun a =>
      allGate [get template.1.clean,get (missRef a),(next[a]?).getD (-1)])
  else pure (Array.replicate 7 (-1))

private theorem mask_grows (e next : Array W) (present : Bool) : Grows (maskAction e next present) := by
  cases present with
  | false => exact pure_grows _
  | true => exact mapArray_grows (fun a => allGate_grows _) _

private theorem mask_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {bs bn : Array Bool} {e next : Array W} (he : BitsRep v bs e) (hn : BitsRep v bn next)
    (present : Bool) :
    Gives T (maskAction e next present) (BitsRep v (pureMask (lookup (!·) false bs) bn present)) := by
  cases present with
  | false =>
    apply pure_gives
    change List.Forall₂ (Rep v) (Array.replicate 7 false).toList (Array.replicate 7 (-1 : W)).toList
    simp only [Array.toList_replicate]
    repeat first | apply List.Forall₂.cons (zero_rep unit) | exact List.Forall₂.nil
  | true =>
    let f (a : Nat) := lookup (!·) false bs template.1.clean && lookup (!·) false bs (missRef a) && (bn[a]?).getD false
    let g (a : Nat) := allGate [lookup (-·) (-1) e template.1.clean,lookup (-·) (-1) e (missRef a),(next[a]?).getD (-1)]
    have each (a : Nat) : Gives T (g a) (Rep v (f a)) := by
      have n := default_rep unit hn a
      simp only [Array.getElem?_toList] at n
      have h := bool_and_gives law unit (List.Forall₂.cons (plan_lookup unit he template.1.clean)
        (.cons (plan_lookup unit he (missRef a)) (.cons n .nil)))
      simpa [g,f,Bool.and_assoc] using h
    exact weaken_gives (mapArray_gives (Array.range 7) (fun _ => allGate_grows _) (fun a _ => each a))
      (fun _ val => by simpa only [pureMask,ite_true,Array.toList_map,BitsRep] using replace_left val)

private def winAction (mask : Bits) (enabled : Bool) : M W :=
  if enabled then anyGate mask.toList else pure (-1)

private theorem win_grows (mask : Bits) (enabled : Bool) : Grows (winAction mask enabled) := by
  cases enabled with
  | false => exact pure_grows _
  | true => exact anyGate_grows _

private theorem win_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {m : Bits} {b : Array Bool} (hm : BitsRep v b m) (enabled : Bool) :
    Gives T (winAction m enabled) (Rep v (if enabled then b.toList.any id else false)) := by
  cases enabled with
  | false => exact pure_gives (zero_rep unit)
  | true => exact bool_or_gives law unit hm

private theorem front_record_form (p next : Bits) (present cuts : Bool) :
    frontRecord p next present cuts = (do
      let env ← realizeFront p template.2
      let get := lookup (-·) (-1) env
      let m ← maskAction env next present
      let w ← winAction m (present && cuts)
      pure (template.1.row.map get ++ m, get template.1.clean, w)) := by
  cases present <;> cases cuts <;> rfl

theorem frontRecord_grows (p next : Array W) (present cuts : Bool) : Grows (frontRecord p next present cuts) := by
  rw [front_record_form]
  exact bind_grows (front_grows p template.2) (fun env =>
    bind_grows (mask_grows env next present) (fun m =>
      bind_grows (win_grows m (present && cuts)) (fun _ => pure_grows _)))

theorem frontRecord_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {bs bn : Array Bool} {p next : Bits} (hp : BitsRep v bs p) (hn : BitsRep v bn next)
    (present cuts : Bool) :
    Gives T (frontRecord p next present cuts) (rowRep v (pureRow bs bn present cuts)) := by
  rw [front_record_form]
  let b := runPure (!·) false (fun xs=>xs.any id) bs template.2
  let msk := pureMask (lookup (!·) false b) bn present
  refine bind_gives (m:=realizeFront p template.2) (P:=BitsRep v b) (front_grows _ _)
    (fun env=>bind_grows (mask_grows env next present) (fun m=>bind_grows (win_grows m _) (fun _=>pure_grows _)))
    (front_gives law unit hp _) ?_
  intro env he
  refine bind_gives (m:=maskAction env next present) (P:=BitsRep v msk) (mask_grows _ _ _)
    (fun m=>bind_grows (win_grows m _) (fun _=>pure_grows _)) (mask_gives law unit he hn present) ?_
  intro m hm
  refine bind_gives (m:=winAction m (present && cuts)) (win_grows _ _) (fun _=>pure_grows _)
    (win_gives law unit hm _) ?_
  intro _ hw
  apply pure_gives
  refine ⟨?_,plan_lookup unit he template.1.clean,hw⟩
  have keys := rep_map template.1.row.toList (fun i _=>plan_lookup unit he i)
  simpa only [BitsRep,pureRow,Array.toList_append,Array.toList_map] using List.rel_append keys hm

#print axioms frontRecord_gives
end ExactWordFlow.CompactWordCircuit

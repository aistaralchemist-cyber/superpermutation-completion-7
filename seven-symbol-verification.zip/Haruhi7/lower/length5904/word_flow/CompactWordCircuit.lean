import CompactFrontPlan
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Nat.Factorial.Basic

namespace ExactWordFlow.CompactWordCircuit

/-- A switch is named by its recursion node (root 1), bank, and pair index.
These names have no influence on DIMACS numbering. -/
inductive Source
  | one | symbol (i a : Nat) | switch (node : Nat) (back : Bool) (i : Nat)
  deriving Inhabited, Repr, DecidableEq

/-- Positive and negative DIMACS IDs, with the first variable fixed true. -/
abbrev W := Int
inductive Event
  | fresh (s : Source) | gateOr (xs : List W) | gateMux (c a b : W)
  | assertion (xs : List W)
  deriving Inhabited, Repr, DecidableEq

structure Tape where
  vars : Nat := 0
  body : Array Event := #[]
  deriving Inhabited

abbrev M := StateM Tape
def alloc (e : Event) : M W := fun st =>
  let i := st.vars+1
  (Int.ofNat i, ⟨i, st.body.push e⟩)
def insist (xs : List W) : M Unit :=
  modify fun st => {st with body := st.body.push (.assertion xs)}

def anyGate (xs : List W) : M W := do
  let ts := (xs.filter (· != -1)).eraseDups
  if ts.contains 1 || ts.any (fun x => ts.contains (-x)) then return 1
  match ts with
  | [] => return -1
  | [a] => return a
  | _ => alloc (.gateOr (ts.mergeSort (· ≤ ·)))

def allGate (xs : List W) : M W := return -(← anyGate (xs.map (-·)))

def mux (c a b : W) : M W := do
  if c == 1 || a == b then return a
  if c == -1 then return b
  if a == 1 then return ← anyGate [c,b]
  if b == 1 then return ← anyGate [-c,a]
  if a == -1 then return ← allGate [-c,b]
  if b == -1 then return ← allGate [c,a]
  alloc (.gateMux c a b)

def bitXor (a b : W) : M W := do
  if a == b then return -1
  if a == -b then return 1
  mux a (-b) b

abbrev Bits := Array W
abbrev Rows := Array Bits

private def swapped (s : Source) (a b : Bits) : M (Bits × Bits) := do
  let flip ← alloc (.fresh s)
  let left ← (Array.range a.size).mapM fun i => mux flip b[i]! a[i]!
  let right ← (Array.range a.size).mapM fun i => mux flip a[i]! b[i]!
  return (left,right)

def benes : Nat → Nat → Rows → M Rows
  | 0, _, rows => pure rows
  | 1, node, rows => do
    let (a,b) ← swapped (.switch node false 0) rows[0]! rows[1]!
    return #[a,b]
  | d+2, node, rows => do
    let n := rows.size/2
    let pairs ← (Array.range n).mapM fun i =>
      swapped (.switch node false i) rows[2*i]! rows[2*i+1]!
    let top ← benes (d+1) (2*node) (pairs.map Prod.fst)
    let bottom ← benes (d+1) (2*node+1) (pairs.map Prod.snd)
    let mut out := #[]
    for i in [:n] do
      let (a,b) ← swapped (.switch node true i) top[i]! bottom[i]!
      out := (out.push a).push b
    return out

def depth (n : Nat) := if n ≤ 1 then 0 else (n-1).log2 + 1

/-- Padding and traversal order coincide with zip_longest on little-endian operands. -/
def aligned : List W → List W → List (W × W)
  | [], ys => ys.map fun y => (-1,y)
  | x::xs, [] => (x,-1)::aligned xs []
  | x::xs, y::ys => (x,y)::aligned xs ys

def addWires : List (W × W) → W → M (List W)
  | [], carry => pure [carry]
  | (x,y)::rest, carry => do
    let d ← bitXor x y
    let s ← bitXor d carry
    let c ← mux d carry x
    let tail ← addWires rest c
    pure (s::tail)

def pairWires : List (List W) → M (List (List W))
  | a::b::rest => do
    let sum ← addWires (aligned a b) (-1)
    let others ← pairWires rest
    pure (sum::others)
  | xs => pure xs

def countWires : Nat → List (List W) → M (List W)
  | _, [] => pure []
  | _, [a] => pure a
  | 0, _::_::_ => pure []
  | fuel+1, a::b::rest => do
    let next ← pairWires (a::b::rest)
    countWires fuel next

def compareWires : List W → Nat → W → M W
  | [], _, ge => pure ge
  | x::xs, need, ge => do
    let next ← if need%2=1 then allGate [x,ge] else anyGate [x,ge]
    compareWires xs (need/2) next

def threshold (flags : Bits) (need : Nat) : M W := do
  let digits ← countWires flags.size (flags.toList.map fun x=>[x])
  if need ≥ 2^digits.length then return -1
  compareWires digits need 1


def binary (row : Bits) (width : Nat) : M Bits :=
  ((List.range width).reverse.mapM fun bit =>
    anyGate (((List.range row.size).filter fun a => a.testBit bit).map fun a => row[a]!)) |>.map List.toArray

/-- Run the verified local OR plan against the actual simplifying emitter. -/
def realizeFront (p : Array W) (ops : CompactFrontPlan.Ops) : M (Array W) :=
  ops.toList.foldlM (fun env args => do
    let out ← anyGate (args.map (CompactFrontPlan.lookup (-·) (-1) env))
    return env.push out) p

def frontRecord (p next : Array W) (withNext cuts : Bool) : M (Bits × W × W) := do
  let (indices,ops) := CompactFrontPlan.template
  let env ← realizeFront p ops
  let get := CompactFrontPlan.lookup (-·) (-1) env
  let clean := get indices.clean
  let mask ← if withNext then
    (Array.range 7).mapM (fun a => allGate [clean,get (CompactFrontPlan.missRef a),(next[a]?).getD (-1)])
  else pure (Array.replicate 7 (-1))
  let win ← if withNext && cuts then anyGate mask.toList else pure (-1)
  return (indices.row.map get ++ mask,clean,win)

def recordPorts (cols bits : Rows) (i : Nat) : Bits :=
  CompactFrontPlan.ports 1 (fun lane a => if lane<6 then ((cols[i+lane]?).getD #[])[a]?.getD (-1) else -1)
    (fun lane b => ((bits[i+lane]?).getD #[])[b]?.getD (-1))

def frontSeven (cols bits : Rows) (len : Nat) (cuts : Bool) : M (Rows × Bits × Bits) := do
  let triples ← (List.range (len+2-7)).mapM fun i =>
    frontRecord (recordPorts cols bits i) ((cols[i+6]?).getD #[]) (decide (i+7≤len)) cuts
  let records := (triples.map Prod.fst).toArray
  let cleans := if cuts then (triples.map (fun r=>r.2.1)).toArray else #[]
  let wins := if cuts then ((triples.take (len+1-7)).map (fun r=>r.2.2)).toArray else #[]
  return (records,cleans,wins)


/-- The rightmost (least significant) decision is made first in the mux chain. -/
def leFrom : List (W × W) → M W
  | [] => pure 1
  | (eqbit,left)::rest => do
    let next ← leFrom rest
    mux eqbit next (-left)

def compareRows (nk : Nat) (a b : Bits) : M (W × W) := do
  let left := a.toList.take nk
  let pairs := left.zip (b.toList.take nk)
  let same ← pairs.mapM fun (x,y) => do return -(← bitXor x y)
  let le ← leFrom (same.zip left)
  insist [le]
  let equal ← allGate same
  return (le,equal)

def adjacentRows (nk : Nat) : List Bits → M (List (W × W))
  | [] | [_] => pure []
  | a::b::rest => do
    let pair ← compareRows nk a b
    let others ← adjacentRows nk (b::rest)
    return pair::others


/-- Physical mask propagation at one row, in increasing symbol order. -/
def maskStep (n nk : Nat) (row : Bits) (eq : W) (prev : Bits) : M Bits :=
  (Array.range n).mapM fun a => do
    let carry ← allGate [eq,prev[a]!]
    anyGate [row[nk+a]!,carry]

def groupCell (n nk : Nat) (row : Bits) (eq last : W) (prev : Bits) : M (Bits × W × W) := do
  let cur ← maskStep n nk row eq prev
  let stop ← allGate [-row[0]!,last]
  let done_ ← allGate (stop::cur.toList)
  return (cur,stop,done_)

/-- The initial equality wire is false. Each next equality determines whether
the current group ends. The last row always ends its group. -/
def groupRows (n nk : Nat) : List Bits → List W → Bits → M (List (W × W))
  | [],_,_ => pure []
  | row::rs, equal, prev => do
    let eq := equal.head?.getD (-1)
    let rest := equal.tail
    let last := -rest.head?.getD (-1)
    let (mask,hit,done_) ← groupCell n nk row eq last prev
    let tail ← groupRows n nk rs rest mask
    return (hit,done_)::tail


def emit (n len k : Nat) (cuts : Bool) : M Unit := do
  let one ← alloc (.fresh .one)
  insist [one]
  let cols ← (Array.range len).mapM fun i =>
    (Array.range n).mapM fun a => alloc (.fresh (.symbol i a))
  for row in cols do
    insist row.toList
    for a in [:n] do
      for b in [a+1:n] do insist [-row[a]!, -row[b]!]
  let width := depth n
  let bits ← cols.mapM fun row => binary row width
  let mut records := #[]
  let mut cleans := #[]
  let mut wins := #[]
  let nk := 1+width*(n-1)
  for i in [:len+2-n] do
    let miss ← (Array.range n).mapM fun a => do
      return -(← anyGate ((List.range (n-1)).map fun t => cols[i+t]![a]!))
    let mut pairs := #[]
    for a in [:n] do
      for b in [a+1:n] do pairs := pairs.push (← allGate [miss[a]!,miss[b]!])
    let clean := -(← anyGate pairs.toList)
    let bs := (bits.extract i (i+n-1)).push (← binary miss width)
    let zs := ((cols.extract i (i+n-1)).map fun row => row[0]!).push miss[0]!
    let mut row := #[-clean]
    for offset in [1:n] do
      for bit in [:width] do
        let terms ← (List.range n).mapM fun j => allGate [zs[j]!,bs[(j+offset)%n]![bit]!]
        row := row.push (← anyGate terms)
    let mask ← if i+n ≤ len then
      (Array.range n).mapM fun a => allGate [clean,miss[a]!,cols[i+n-1]![a]!]
      else pure (Array.replicate n (-1 : W))
    records := records.push (row++mask)
    if cuts then
      cleans := cleans.push clean
      if i+n ≤ len then wins := wins.push (← anyGate mask.toList)
  if cuts then
    let mut starts := #[cleans[0]!]
    for i in [:wins.size] do starts := starts.push (← allGate [cleans[i+1]!, -wins[i]!])
    insist [← threshold starts 720]
    if !wins.isEmpty then insist [← threshold wins (7*k)]
    else if k != 0 then insist [-1]
    insist [← threshold cleans (720+7*k)]
  let d := depth records.size
  let size := 2^d
  let dummy := #[1] ++ Array.replicate (nk+n-1) (-1 : W)
  let rows ← benes d 1 (records ++ Array.replicate (size-records.size) dummy)
  let mut equal : Bits := #[-1]
  for i in [:size-1] do
    let a := rows[i]!
    let b := rows[i+1]!
    let same ← (Array.range nk).mapM fun j => do return -(← bitXor a[j]! b[j]!)
    let mut le : W := 1
    for j in (List.range nk).reverse do le ← mux same[j]! le (-a[j]!)
    insist [le]
    equal := equal.push (← allGate same.toList)
  let mut visits := #[]
  let mut doneFlags := #[]
  let mut prev := Array.replicate n (-1 : W)
  for i in [:size] do
    let row := rows[i]!
    let mut cur := #[]
    for a in [:n] do cur := cur.push (← anyGate [row[nk+a]!, ← allGate [equal[i]!,prev[a]!]])
    let last : W := if i+1<size then -equal[i+1]! else 1
    let stop ← allGate [-row[0]!,last]
    visits := visits.push stop
    doneFlags := doneFlags.push (← allGate (stop::cur.toList))
    prev := cur
  insist [← threshold visits (n-1).factorial]
  insist [← threshold doneFlags k]

def compact (n len k : Nat) (cuts : Bool) := ((emit n len k cuts).run {}).2

/-- Signed DIMACS expansion. The output variable of each allocating event
is assigned its next consecutive positive ID. -/
def localClauses (out : W) : Event → List (List W)
  | .fresh _ => []
  | .assertion xs => [xs]
  | .gateOr xs => ((-out)::xs)::(xs.map fun x => [-x,out])
  | .gateMux c a b => [[-c,-a,out],[-c,a,-out],[c,-b,out],[c,b,-out]]

def advance (i : Nat) : Event → Nat
  | .assertion _ => i
  | _ => i+1

def clauseCount (t : Tape) : Nat := t.body.foldl (init := 0) fun n e =>
  n + match e with
  | .fresh _ => 0
  | .assertion _ => 1
  | .gateMux .. => 4
  | .gateOr xs => xs.length+1

end ExactWordFlow.CompactWordCircuit

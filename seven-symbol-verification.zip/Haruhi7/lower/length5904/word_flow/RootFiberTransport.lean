import SixRoots277
import Cap35Fibers
import Cap35Census

namespace ExactWordFlow.RootFiberTransport
open SevenWordWindows RotationCore ResidualDensity DirectedEuler ExtremeWheelCut NearRootMoves
open Cap35Rigidity SeedWheelCut
open private catalog from NearRootMoves
open private board_map shape_map from Cap35Census

/-- Image of a connected hypergraph, including its distinguished large row. -/
private theorem push {R : Finset Block} {S : Finset (Finset Block)} {g : Block→Block}
    (onto : allClasses.image g=allClasses) (closed : ClosedCover R allClasses S) :
    ClosedCover (R.image g) allClasses (S.image (Finset.image g)) := by
  intro C init stable
  let P:=(R∪allClasses∪S.biUnion id).filter (fun c=>g c∈C)
  have seed : R⊆P:=fun c hc=>Finset.mem_filter.mpr
    ⟨Finset.mem_union_left _ (Finset.mem_union_left _ hc),init (Finset.mem_image_of_mem g hc)⟩
  have keep (q) (hq : q∈S) (meet : (P∩q).Nonempty) : q⊆P := by
    obtain ⟨c,hc⟩:=meet
    obtain ⟨cp,cq⟩:=Finset.mem_inter.mp hc
    have hit : (C∩q.image g).Nonempty:=⟨g c,Finset.mem_inter.mpr
      ⟨(Finset.mem_filter.mp cp).2,Finset.mem_image_of_mem g cq⟩⟩
    intro x hx
    exact Finset.mem_filter.mpr ⟨Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨q,hq,hx⟩),
      stable _ (Finset.mem_image_of_mem _ hq) hit (Finset.mem_image_of_mem _ hx)⟩
  intro c hc
  rw [←onto] at hc
  obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hc
  exact (Finset.mem_filter.mp (closed P seed keep hx)).2

def possible (R : Finset Block) : Prop :=
  ∃z,full z ∧ ∃W⊆allRows,W.card≤91 ∧ ClosedCover R allClasses (insert (shape z) W)

private theorem transfer {R : Finset Block} (h : possible R) (g : Block→Block)
    (onBoard : allClasses.image g=allClasses)
    (onWheel : ∀w∈allRows,w.image g∈allRows)
    (onShape : ∀z,full z → ∃t,full t ∧ (shape z).image g=shape t) :
    possible (R.image g) := by
  obtain ⟨z,clean,W,legal,n,cc⟩:=h
  obtain ⟨t,good,same⟩:=onShape z clean
  refine ⟨t,good,W.image (Finset.image g),?_,Finset.card_image_le.trans n,?_⟩
  · rintro _ hrow
    obtain ⟨r,hr,rfl⟩:=Finset.mem_image.mp hrow
    exact onWheel _ (legal hr)
  · simpa [same] using push onBoard cc

private theorem stepData : ∀z∈states,full (z.map (·+1)) ∧
    (shape z).image (move 7)=shape (z.map (·+1)) := by native_decide

private theorem relabel {R : Finset Block} (h : possible R) (f : Fin 7→Fin 7)
    (bi : Function.Bijective f) (zero : f 0=0) : possible (R.image (List.map f)) := by
  apply transfer h _ (WheelRelabel.image_allClasses f bi.1 zero)
  · intro w hw
    rw [←board_map f bi.1 zero]
    exact Finset.mem_image_of_mem _ hw
  · intro z hz
    exact ⟨z.map f,⟨by simp [hz.1],hz.2.map bi.1⟩,shape_map f bi.1 zero z hz⟩

private theorem steps {R : Finset Block} (h : possible R) (k : Nat) :
    possible (applyMoves (List.replicate k 7) R) := by
  induction k generalizing R with
  | zero=>simpa [applyMoves] using h
  | succ k ih=>
    have st:=transfer h (move 7) (catalog 7).1 (catalog 7).2 (fun z hz=>
      ⟨_,stepData z (mem_states hz)⟩)
    exact ih st

theorem normalize {s t : Block} {es : List Block} (r : Route src dst s es t)
    (width : ∀e∈es,e.length=7) (len : es.length=277) (counted : 236≤classCount s es)
    (hyp : possible (touched (s::es.map dst))) : ∃R∈SixRoots277.roots,possible R := by
  obtain ⟨f,bi,zero,k,norm⟩:=SixRoots277.all_routes r width len counted
  exact ⟨_,norm,steps (relabel hyp f bi zero) k⟩

#print axioms normalize
end ExactWordFlow.RootFiberTransport

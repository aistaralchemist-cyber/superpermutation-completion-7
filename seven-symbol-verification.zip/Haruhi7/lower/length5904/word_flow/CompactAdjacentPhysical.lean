import CompactAdjacent
import CompactBenes
import PhysicalFlags

namespace ExactWordFlow.CompactWordCircuit
open CoreCandidateBanks (pk)
open CoreRecordBits (wireLE)

private theorem wire_word {xs : List W} {bs : List Bool} (h : List.Forall₂ (fun x b=>Rep v b x) xs bs) :
    xs.map (wire v)=bs ∧ ∀x∈xs,x≠0 := by
  induction h with
  | nil => simp
  | cons hp ht ih =>
    rw [List.map_cons,hp.2,ih.1]
    exact ⟨rfl,List.forall_mem_cons.mpr ⟨hp.1,ih.2⟩⟩

theorem physical_key {xs : Bits} {bs : Array Bool} (h : RowRep v 26 xs bs) :
    keyBits v 19 xs = pk bs := by
  obtain ⟨eq,_⟩:=wire_word h.2
  rw [keyBits,List.map_take,eq,pk]

private theorem physical_ready {xs : Bits} {bs : Array Bool} (h : RowRep v 26 xs bs) :
    rowReady 19 xs := ⟨by rw [h.1];decide,(wire_word h.2).2⟩

private theorem ready_all {xs : List Bits} {bs : List (Array Bool)} (h : List.Forall₂ (RowRep v 26) xs bs) :
    ∀x∈xs,rowReady 19 x := by
  induction h with
  | nil => simp
  | cons h t ih => exact List.forall_mem_cons.mpr ⟨physical_ready h,ih⟩

private theorem paired_edges {R : α → β → Prop} {xs : List α} {ys : List β} (h : List.Forall₂ R xs ys) :
    List.Forall₂ (fun (a : α × α) (b : β × β)=> R a.1 b.1 ∧ R a.2 b.2) (rowEdges xs) (rowEdges ys) := by
  induction h with
  | nil => exact .nil
  | cons h t ih =>
    cases t with
    | nil => exact .nil
    | cons k u => exact .cons ⟨h,k⟩ ih

private theorem physical_links {ids : List (Bits×Bits)} {phys : List (Array Bool × Array Bool)} {os : List (W×W)}
    (a : List.Forall₂ (fun (p : Bits×Bits) (q : Array Bool × Array Bool)=>RowRep v 26 p.1 q.1 ∧ RowRep v 26 p.2 q.2) ids phys)
    (b : List.Forall₂ (edgeRep v 19) ids os) :
    List.Forall₂ (fun (p : W×W) (q : Array Bool×Array Bool)=>
      Rep v (wireLE (pk q.1) (pk q.2)) p.1 ∧ Rep v (pk q.1==pk q.2) p.2) os phys := by
  induction a generalizing os with
  | nil => cases b; exact .nil
  | cons hp ht ih =>
    cases b with
    | cons hw tail =>
      refine .cons ?_ (ih tail)
      unfold edgeRep at hw
      rw [physical_key hp.1,physical_key hp.2] at hw
      exact ⟨hw.1,by simpa only [Bool.beq_eq_decide_eq] using hw.2⟩

private theorem order_edges {xs : List (Array Bool)}
    (h : xs.Pairwise (fun a b=>wireLE (pk a) (pk b)=true)) :
    ∀p∈rowEdges xs,wireLE (pk p.1) (pk p.2)=true := by
  induction xs with
  | nil => simp [rowEdges]
  | cons a xs ih =>
    cases xs with
    | nil => simp [rowEdges]
    | cons b xs =>
      obtain ⟨head,rest⟩:=List.pairwise_cons.mp h
      exact List.forall_mem_cons.mpr ⟨head b List.mem_cons_self,ih rest⟩

private theorem flags_correct {os : List (W×W)} {qs : List (Array Bool×Array Bool)}
    (h : List.Forall₂ (fun (p : W×W) (q : Array Bool×Array Bool)=>
      Rep v (wireLE (pk q.1) (pk q.2)) p.1 ∧ Rep v (pk q.1==pk q.2) p.2) os qs)
    (ord : ∀q∈qs,wireLE (pk q.1) (pk q.2)=true) :
    (∀p∈os,wire v p.1=true) ∧
    List.Forall₂ (fun x b=>Rep v b x) (os.map Prod.snd) (qs.map fun q=>pk q.1==pk q.2) := by
  induction h with
  | nil => exact ⟨by simp,.nil⟩
  | cons h t ih =>
    obtain ⟨head,rest⟩:=List.forall_mem_cons.mp ord
    obtain ⟨le,eq⟩:=ih rest
    exact ⟨List.forall_mem_cons.mpr ⟨h.1.2.trans head,le⟩,.cons h.2 eq⟩

theorem adjacent_physical {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {ids : List Bits} {phys : List (Array Bool)} (represented : List.Forall₂ (RowRep v 26) ids phys)
    (sorted : phys.Pairwise (fun a b=>wireLE (pk a) (pk b)=true)) :
    Gives T (adjacentRows 19 ids) (fun os=>
      (∀p∈os,wire v p.1=true) ∧ List.Forall₂ (fun x b=>Rep v b x) (os.map Prod.snd)
      ((rowEdges phys).map fun q=>pk q.1==pk q.2)) := by
  exact (adjacentRows_gives law unit 19 ids (ready_all represented)).imp fun os h=>
    flags_correct (physical_links (paired_edges represented) h) (order_edges sorted)

#print axioms adjacent_physical
end ExactWordFlow.CompactWordCircuit

import SparseTourBounds

namespace ExactWordFlow.ActualPackingCost
open Equiv SevenWordWindows ExtremeWheelCut OpenWheelPacking
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- Count the cost of the paid open transitions themselves.  Restoring the
closing incidence accounts for both possible kinds of cut. This identity
uses no genus relation. -/
theorem open_packing_cost (h : Perm X) (last : X) (d : X→Nat)
    (card : Fintype.card X=5040)
    (positive : ∀x,x≠last → 1≤d x)
    (ordinary : ∀x,x≠last → (d x=1 ↔ h x=x))
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset)
    (six : ∀c∈h.cycleFactorsFinset \ E,c.support.card=6) :
    let A:=Finset.univ.erase last
    7+(∑x∈A,d x)+(if h last=last then 0 else 1)
      =5046+(∑c∈E,c.support.card)+(∑x∈A,(d x-2))+6*(h.cycleFactorsFinset \ E).card := by
  classical
  let A:=Finset.univ.erase last
  let χ (x : X):=if x∈h.support then 1 else 0
  have each (x) (hx : x∈A) : d x=1+χ x+(d x-2):=by
    have diff:=(Finset.mem_erase.mp hx).1
    have pos:=positive x diff
    by_cases inS : x∈h.support
    · have nonunit:=(ordinary x diff).not.mpr (Perm.mem_support.mp inS)
      simp only [χ,ite_eq_left inS]
      omega
    · have fixed : h x=x:=by simpa using inS
      simp only [χ,ite_eq_right inS,(ordinary x diff).mpr fixed]
  have cost : (∑x∈A,d x)=A.card+(∑x∈A,χ x)+(∑x∈A,(d x-2)):=by
    rw [Finset.sum_congr rfl each]
    simp [Finset.sum_add_distrib]
  have span:A.card=5039:=by simp [A,card]
  have total : ∑x : X,χ x=h.support.card:=by
    change (∑ x : X, if x∈h.support then 1 else 0)=_
    rw [←Finset.sum_filter]
    simp only [Finset.filter_mem_eq_inter,Finset.univ_inter,Finset.sum_const,smul_eq_mul,mul_one]
  have lost : χ last=(if h last=last then 0 else 1):=by
    by_cases fixed : h last=last <;> simp [χ,Perm.mem_support,fixed]
  have restore:=Finset.sum_erase_add Finset.univ χ (Finset.mem_univ last)
  change (∑x∈A,χ x)+χ last = _ at restore
  rw [total,lost] at restore
  have split : (∑c∈h.cycleFactorsFinset \ E,c.support.card)+(∑c∈E,c.support.card)=h.support.card :=
    (Finset.sum_sdiff known).trans h.sum_cycleType
  rw [Finset.sum_congr rfl six] at split
  simp only [Finset.sum_const,smul_eq_mul] at split
  dsimp only
  change 7+(∑x∈A,d x)+(if h last=last then 0 else 1)=
    5046+(∑c∈E,c.support.card)+(∑x∈A,(d x-2))+6*(h.cycleFactorsFinset \ E).card
  omega

/-- The sparse packet cut applies to a genuine paid open path with both
its length and surcharge evaluated from edge weights, for either kind of cut. -/
theorem from_paid_successor {R h : Perm X} (start last : X) (orbit : ∀y,(R*h).SameCycle start y)
    (d : X→Nat) (card : Fintype.card X=5040) (positive : ∀x,x≠last → 1≤d x)
    (ordinary : ∀x,x≠last → (d x=1 ↔ h x=x))
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (name : Y ↪ Block) (board : Finset.univ.map name=allClasses)
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (present : E.Nonempty)
    (six : ∀c∈h.cycleFactorsFinset \ E,c.support.card=6)
    (legal : ∀c∈h.cycleFactorsFinset \ E,(c.support.image tag).map name∈allRows)
    {P : Finset Block} (seen : P⊆(E.biUnion (fun c=>c.support.image tag)).map name)
    (short : 7+(∑x∈Finset.univ.erase last,d x)≤5904) :
    let A:=(E.biUnion (fun c=>c.support.image tag)).map name
    let M:=∑c∈E,c.support.card
    let s:=∑x∈Finset.univ.erase last,(d x-2)
    let L:=7+∑x∈Finset.univ.erase last,d x
    ∃T : Finset (Finset Block),
      (∀t∈T,Packet allRows t ∧ t⊆allClasses \ P) ∧
      (∀t∈T,∀u∈T,t≠u → Disjoint t u) ∧
      442+2*s+3*(M-A.card)+2*(5904-L) ≤ M+3*T.card := by
  have cost:=open_packing_cost h last d card positive ordinary E known six
  let M:=∑c∈E,c.support.card
  let s:=∑x∈Finset.univ.erase last,(d x-2)
  let q:=(h.cycleFactorsFinset \ E).card
  let L:=7+∑x∈Finset.univ.erase last,d x
  let base:=5045+M+s+6*q
  change L+(if h last=last then 0 else 1)=5046+M+s+6*q at cost
  have lower : base≤L:=by dsimp only [base]; split at cost <;> omega
  have lim : base≤5904:=lower.trans short
  obtain ⟨T,pack,apart,bound⟩:=SparseTourBounds.from_successor start orbit tag onto rot name board
    E known present legal seen lim (show base=5045+M+s+6*q from rfl)
  refine ⟨T,pack,apart,?_⟩
  have gap:=Nat.sub_le_sub_left lower 5904
  change 442+2*s+3*(M-((E.biUnion fun c=>c.support.image tag).map name).card)+2*(5904-L)≤M+3*T.card
  change 442+2*s+3*(M-((E.biUnion fun c=>c.support.image tag).map name).card)+2*(5904-base)≤M+3*T.card at bound
  omega

#print axioms open_packing_cost
#print axioms from_paid_successor
end ExactWordFlow.ActualPackingCost

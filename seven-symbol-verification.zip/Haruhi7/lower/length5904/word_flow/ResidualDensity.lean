import Windows5904

namespace ResidualDensity
open SevenWordWindows
abbrev Six := List (Fin 7)

def step (s : Six) (a : Fin 7) := s.tail ++ [a]
def full (s : Six) : Prop := s.length=6 ∧ s.Nodup
instance (s : Six) : Decidable (full s) := inferInstanceAs (Decidable (_ ∧ _))
def tag (s : Six) : Word := classKey (s ++ ((List.finRange 7).filter (fun a => a ∉ s)))
def states : List Six := representatives.map (·.take 6)

theorem mem_states {s : Six} (hs : full s) : s ∈ states := by
  have cc : s.toFinset.card=6 := by rw [List.toFinset_card_of_nodup hs.2,hs.1]
  have ne : s.toFinset ≠ Finset.univ := by
    intro hh
    rw [hh] at cc
    simp at cc
  have hh : ∃ a, a ∉ s.toFinset := by
    by_contra! he
    exact ne (Finset.eq_univ_of_forall he)
  obtain ⟨a,ha⟩ := hh
  have ha' : a ∉ s := by simpa using ha
  have pp : s++[a] ∈ representatives := (mem_reps _).mpr ⟨by simp [hs.1], by rw [List.nodup_append_comm]; simpa using And.intro ha' hs.2⟩
  apply List.mem_map.mpr
  exact ⟨s++[a],pp,by rw [←hs.1,List.take_left]⟩

/-- The only overlapping full context in a different class rotates its six letters. -/
theorem next_unique (s : Six) (a : Fin 7) (hs : full s) (hn : full (step s a))
    (diff : tag s ≠ tag (step s a)) : step s a = s.rotate 1 := by
  have checked : states.all (fun s => (List.finRange 7).all fun a =>
    decide (full (step s a) → tag s ≠ tag (step s a) → step s a=s.rotate 1))=true := by
    native_decide
  exact (of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp checked s (mem_states hs))
    a (List.mem_finRange _))) hn diff

def orbit (s : Six) := (List.range 6).map fun i => tag (s.rotate i)
def hop (s : Six) := (s.take 5).rotate 1 ++ s.drop 5

/-- A seam with one intermediate context between two disjoint complete wheels
must cycle the first five letters of the starting six and fix the sixth. -/
theorem seam_unique (s : Six) (a b : Fin 7) (hs : full s)
    (hnext : full (step (step (s.rotate 5) a) b))
    (hdis : (orbit s).Disjoint (orbit (step (step (s.rotate 5) a) b))) :
    step (step (s.rotate 5) a) b=hop s := by
  have checked : states.all (fun s => (List.finRange 7).all fun a =>
    (List.finRange 7).all fun b => let t := step (step (s.rotate 5) a) b
       decide (full t → (orbit s).all (fun x => decide (x ∉ orbit t)) = true → t=hop s))=true := by
    native_decide
  exact (of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp
    (List.all_eq_true.mp checked s (mem_states hs)) a (List.mem_finRange _)) b
       (List.mem_finRange _))) hnext (List.all_eq_true.mpr fun x hx => decide_eq_true (hdis hx))

theorem hop_five (s : Six) (hs : full s) : hop (hop (hop (hop (hop s))))=s := by
  have checked : states.all (fun s => decide (hop (hop (hop (hop (hop s))))=s))=true := by
    native_decide
  exact of_decide_eq_true (List.all_eq_true.mp checked s (mem_states hs))

def Walk (u : ℕ → Six) := ∀ i, ∃ a, u (i+1) = step (u i) a

def Marked (u : ℕ → Six) (good : ℕ → Prop) :=
  (∀ i, good i → full (u i)) ∧
  (∀ i j, good i → good j → tag (u i) = tag (u j) → i=j)

private theorem rigid {u : ℕ → Six} {good : ℕ → Prop} (walk : Walk u) (h : Marked u good)
    (i n : ℕ) (allgood : ∀ j≤n, good (i+j)) : u (i+n) = (u i).rotate n := by
  induction n with
  | zero => simp
  | succ n ih =>
    obtain ⟨a,ha⟩ := walk (i+n)
    have diff : tag (u (i+n)) ≠ tag (u (i+n+1)) := by
      intro e
      have := h.2 _ _ (allgood n (by omega)) (allgood (n+1) (by omega)) e
      omega
    have hx := next_unique _ a (h.1 _ (allgood n (by omega)))
      (ha ▸ h.1 _ (allgood (n+1) (by omega))) (ha ▸ diff)
    rw [Nat.add_succ,ha,hx,ih (fun j hj => allgood j (by omega)),List.rotate_rotate]

theorem no_seven {u : ℕ → Six} {good : ℕ → Prop} (walk : Walk u) (h : Marked u good)
    (i : ℕ) : ¬ ∀ j≤6, good (i+j) := by
  intro hg
  have eq := rigid walk h i 6 hg
  have hi := (h.1 i (by simpa using hg 0 (by decide))).1
  rw [show (u i).rotate 6=u i by nth_rw 1 [←hi]; exact List.rotate_length _] at eq
  have ex := h.2 _ _ (hg 6 (by decide)) (by simpa using hg 0 (by decide)) (congrArg tag eq)
  omega

private theorem rigid_hop {u : ℕ → Six} {good : ℕ → Prop} (walk : Walk u) (h : Marked u good)
    (i : ℕ) (hg : ∀ j≤5, good (i+j)) (hk : ∀ j≤5, good ((i+7)+j)) :
    u (i+7)=hop (u i) := by
  obtain ⟨a,ha⟩ := walk (i+5)
  obtain ⟨b,hb⟩ := walk (i+6)
  have five := rigid walk h i 5 hg
  have repr : u (i+7)=step (step ((u i).rotate 5) a) b := by rw [←five,←ha,←hb]
  have dis : (orbit (u i)).Disjoint (orbit (u (i+7))) := by
    intro z hz hkz
    obtain ⟨m,hm,hmz⟩ := List.mem_map.mp hz
    obtain ⟨n,hn,hnz⟩ := List.mem_map.mp hkz
    have hm' := List.mem_range.mp hm
    have hn' := List.mem_range.mp hn
    have e : tag (u (i+m))=tag (u ((i+7)+n)) := by
      rw [rigid walk h i m (fun j hj => hg _ (by omega)),
        rigid walk h (i+7) n (fun j hj => hk _ (by omega)),hmz,hnz]
    have ec := h.2 _ _ (hg m (by omega)) (hk n (by omega)) e
    omega
  have ii : full (u i) := h.1 _ (by simpa using hg 0 (by decide))
  have jj : full (u (i+7)) := h.1 _ (by simpa using hk 0 (by decide))
  simpa [←repr] using seam_unique (u i) a b ii (repr ▸ jj) (repr ▸ dis)

theorem no_six_wheels {u : ℕ → Six} {good : ℕ → Prop} (walk : Walk u) (h : Marked u good)
    (i : ℕ) : ¬ ∀ k≤5, ∀ j≤5, good ((i+7*k)+j) := by
  intro hg
  have hh (k : ℕ) (hk : k<5) : u (i+7*(k+1))=hop (u (i+7*k)) := by
    have t := rigid_hop walk h (i+7*k) (hg k (by omega))
      (by simpa [Nat.mul_succ, Nat.add_assoc] using hg (k+1) (by omega))
    simpa [Nat.mul_succ, Nat.add_assoc] using t
  have hi : full (u i) := h.1 _ (by simpa using hg 0 (by decide) 0 (by decide))
  have a0 : u (i+7) = hop (u i) := by simpa only [Nat.reduceAdd,Nat.reduceMul,Nat.add_zero] using hh 0 (by decide)
  have a1 : u (i+14) = hop (u (i+7)) := hh 1 (by decide)
  have a2 : u (i+21) = hop (u (i+14)) := hh 2 (by decide)
  have a3 : u (i+28) = hop (u (i+21)) := hh 3 (by decide)
  have a4 : u (i+35) = hop (u (i+28)) := hh 4 (by decide)
  have e : u (i+35)=u i := by rw [a4,a3,a2,a1,a0,hop_five _ hi]
  have ex := h.2 _ _ (by simpa using hg 5 (by decide) 0 (by decide))
    (by simpa using hg 0 (by decide) 0 (by decide)) (congrArg tag e)
  omega

/-- Every interval of 41 consecutive contexts has at most 35 marked distinct
rotation classes, even when both endpoints and all intermediate letters are free. -/
theorem interval41 {u : ℕ → Six} {good : ℕ → Prop} [DecidablePred good]
    (walk : Walk u) (h : Marked u good) (i : ℕ) :
    ((Finset.range 41).filter fun j => good (i+j)).card ≤ 35 := by
  classical
  by_contra! many
  let F := (Finset.range 41).filter (fun j => ¬good (i+j))
  have cap : F.card ≤ 5 := by
    have e := (Finset.range 41).card_filter_add_card_filter_not (fun j => good (i+j))
    simp only [Finset.card_range] at e
    change ((Finset.range 41).filter (fun j => good (i+j))).card + F.card = 41 at e
    omega
  apply no_six_wheels walk h i
  intro B hB t ht
  by_contra bad
  let off (k : ℕ) := if k<B then 7*k else 7*k+6
  have pick (k : Fin 5) : ∃ j : Nat, off k ≤ j ∧ j ≤ off k+6 ∧ ¬good (i+j) := by
    have no := no_seven walk h (i+off k)
    push Not at no
    obtain ⟨d,hd,hn⟩ := no
    exact ⟨off k+d,by omega,by omega,by simpa [Nat.add_assoc] using hn⟩
  choose v hvlo hvhi hvbad using pick
  have ve (k : Fin 5) : v k ∈ F := by
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_range.mpr ?_,hvbad _⟩
    have up := hvhi k
    have small := k.isLt
    unfold off at up
    split at up <;> omega
  have ordered (k l : Fin 5) (ord : k.val < l.val) : v k < v l := by
    have up := hvhi k
    have lo := hvlo l
    unfold off at up lo
    split at up <;> split at lo <;> omega
  have aside (k : Fin 5) : v k ≠ 7*B+t := by
    have up := hvhi k
    have lo := hvlo k
    unfold off at up lo
    split at up <;> split at lo <;> omega
  have fail : 7*B+t∈F := Finset.mem_filter.mpr
    ⟨Finset.mem_range.mpr (by omega), by simpa [Nat.add_assoc] using bad⟩
  let f (k : Fin 6) : ↥F := if hk : k.val<5 then ⟨v ⟨k,hk⟩,ve _⟩ else ⟨7*B+t,fail⟩
  have inj : Function.Injective f := by
    intro k l he
    have he' := congrArg Subtype.val he
    change (f k).val=(f l).val at he'
    dsimp only [f] at he'
    split at he' <;> split at he'
    next hk hl =>
      by_contra n
      have dv : k.val≠l.val := fun e => n (Fin.ext e)
      rcases lt_or_gt_of_ne dv with lt | gt
      · exact (ne_of_lt (ordered ⟨k,hk⟩ ⟨l,hl⟩ lt)) he'
      · exact (ne_of_gt (ordered ⟨l,hl⟩ ⟨k,hk⟩ gt)) he'
    next hk hl => exact False.elim (aside ⟨k,hk⟩ he')
    next hk hl => exact False.elim (aside ⟨l,hl⟩ he'.symm)
    next hk hl => exact Fin.ext (by have := k.isLt; have := l.isLt; omega)
  have card := Fintype.card_le_of_injective f inj
  simp only [Fintype.card_fin,Fintype.card_coe] at card
  omega

end ResidualDensity
#print axioms ResidualDensity.interval41

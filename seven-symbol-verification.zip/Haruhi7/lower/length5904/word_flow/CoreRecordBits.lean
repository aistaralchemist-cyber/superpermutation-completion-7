import SortedCoreRecords

namespace ExactWordFlow.CoreRecordBits
open SevenWordWindows ResidualDensity SortedCoreRecords

/-- Missing-symbol indicator computed from the six one-hot rows. -/
def missing (u : Block) (a : Fin 7) := decide (a ∉ u)

def symbols := List.finRange 7

/-- The encoder rejects a context if two distinct symbols are missing. -/
def clean (u : Block) : Bool := !(symbols.any fun a =>
  symbols.any fun b => decide (a < b) && missing u a && missing u b)

/-- Bit of the seventh, missing-symbol lane. The disjunction is defined
also for invalid contexts with several missing symbols. -/
def missingDigitBit (u : Block) (bit : Nat) : Bool :=
  symbols.any fun a => missing u a && a.val.testBit bit

def laneBit (u : Block) (lane bit : Nat) : Bool :=
  if lane < 6 then (u[lane]?.map (fun a => a.val.testBit bit)).getD false
  else missingDigitBit u bit

def laneZero (u : Block) (lane : Nat) : Bool :=
  if lane < 6 then decide (u[lane]? = some 0) else missing u 0

def tailBit (u : Block) (offset bit : Nat) : Bool := (List.range 7).any fun j =>
  laneZero u j && laneBit u ((j+offset+1)%7) bit

def bits3 (n : Nat) := [n.testBit 2,n.testBit 1,n.testBit 0]

def digit (hi mid lo : Bool) := 4*hi.toNat + 2*mid.toNat + lo.toNat

def digits (u : Block) := (List.range 6).map fun i => digit (tailBit u i 2) (tailBit u i 1) (tailBit u i 0)

def keyWires (u : Block) := (!clean u) :: (List.range 6).flatMap fun i =>
  [tailBit u i 2, tailBit u i 1, tailBit u i 0]

def encodeKey (k : Key) : List Bool := match ofLex k with
  | .inl c => false :: c.tail.flatMap (fun a => bits3 a.val)
  | .inr junk => true :: junk.flatMap bits3

def mask (u : Block) (next : Option (Fin 7)) : Finset (Fin 7) :=
  Finset.univ.filter fun a => clean u && missing u a && decide (next=some a)

private def blocks : Nat → List Block
  | 0 => [[]]
  | n+1 => (blocks n).flatMap fun u => symbols.map (· :: u)

private theorem enumerated (u : Block) : u∈blocks u.length := by
  induction u with
  | nil => simp [blocks]
  | cons a u ih =>
    exact List.mem_flatMap.mpr ⟨u,ih,List.mem_map.mpr ⟨a,List.mem_finRange a,rfl⟩⟩

private theorem all_flags :
    (blocks 6).all (fun u => clean u == decide (full u)) = true := by native_decide

theorem clean_eq {u : Block} (len : u.length=6) :
    clean u = decide (full u) := by
  have mem : u∈blocks 6 := len ▸ enumerated u
  exact beq_iff_eq.mp (List.all_eq_true.mp all_flags u mem)

private theorem clean_keys :
    states.all (fun u => keyWires u == encodeKey (Sum.inlₗ (tag u)))=true := by native_decide

private theorem digit_bits (a b c : Bool) : bits3 (digit a b c)=[a,b,c] := by
  cases a <;> cases b <;> cases c <;> decide

/-- Equality for all six-letter contexts, including the dirty key's 18 junk bits. -/
theorem key_eq {u : Block} (len : u.length=6) :
    keyWires u = encodeKey (contextKey digits u) := by
  by_cases h : full u
  · rw [contextKey,ite_eq_left h]
    exact beq_iff_eq.mp (List.all_eq_true.mp clean_keys u (mem_states h))
  · simp [keyWires,contextKey,h,clean_eq len,encodeKey,Sum.inrₗ,digits,List.flatMap_map,
      digit_bits]

theorem mask_last (u : Block) : mask u none=∅ := by ext a; simp [mask]

private theorem permutation_end (u : Block) (a : Fin 7) :
    (u++[a]).Nodup ↔ u.Nodup ∧ a∉u := by
  rw [List.nodup_append_comm]
  simp [and_comm]

theorem mask_eq {u : Block} (len : u.length=6) (a : Fin 7) :
    mask u (some a) = (windowRow digits (u++[a])).mask := by
  change mask u (some a) = if (u++[a]).Nodup then (u++[a]).getLast?.toFinset else ∅
  simp only [List.getLast?_append,List.getLast?_singleton,Option.some_or,permutation_end]
  ext x
  by_cases hx : a=x
  · subst x
    by_cases hu : u.Nodup <;> by_cases ha : a∈u <;> simp [mask,clean_eq len,full,len,hu,ha,missing]
  · by_cases good : u.Nodup ∧ a∉u <;> simp [mask,hx,Ne.symm hx,good]

/-- The three operations used to construct a circuit record give exactly the
class key and the seven membership bits of the semantic window record. -/
theorem window_wires (p : Block) (width : p.length=7) :
    keyWires (src p)=encodeKey (windowRow digits p).key ∧
    mask (src p) p.getLast?=(windowRow digits p).mask := by
  induction p using List.reverseRecOn with
  | nil => simp at width
  | append_singleton u a _ =>
    have len : u.length=6 := by simpa using width
    have front : src (u++[a]) = u := by simp [src,←len]
    constructor
    · exact key_eq (u:=src (u++[a])) (by rw [front]; exact len)
    · simpa [front] using mask_eq len a

#print axioms window_wires
end ExactWordFlow.CoreRecordBits

import Cap95Marked

namespace ResidualDensity.Cap95Profiles
open MarkedGeometry WeightedMarks Cap95Marked
open private prefixes initial start move memoryWord accepted from MarkedDensity
open private upper_read upper_step from Cap95Marked
open private runs from MarkedExtrema

private def optimal : Nat → Nat → List (List Bool)
  | 0,_ => [[]]
  | n+1,s =>
    [false,true].flatMap fun b =>
      let j:=move s b
      if j<prefixes.size ∧ b.toNat+upper n j=upper (n+1) s then
        (optimal n j).map (b::·)
      else []

private theorem maximizer (pre bs : List Bool) (s : Nat) (valid : s<prefixes.size)
    (small : bs.length≤289) (suff : memoryWord s <:+ pre)
    (safeWord : ∀x∈forbidden, ¬x <:+: pre++bs) (maximal : upper bs.length s≤bs.count true) :
    bs∈optimal bs.length s := by
  induction bs generalizing s pre with
  | nil => simp [optimal]
  | cons b bs ih =>
    obtain ⟨next,suffix,_⟩:=accepted s b pre bs valid suff safeWord
    have hsz : bs.length<289 := by simpa using small
    have sm : bs.length≤289 := by omega
    have good : ∀x∈forbidden, ¬x <:+: (pre++[b])++bs := by simpa using safeWord
    have tail := upper_read _ _ _ next sm suffix good
    have pay:=upper_step ⟨bs.length,hsz⟩ ⟨s,valid⟩ b next
    change b.toNat+upper bs.length (move s b)≤upper (bs.length+1) s at pay
    have cnt : (b::bs).count true=b.toNat+bs.count true := by cases b <;> simp [Nat.add_comm]
    simp only [List.length_cons,cnt] at maximal
    have win : b.toNat+upper bs.length (move s b)=upper (bs.length+1) s := by omega
    have child:=ih _ _ next sm suffix good (by omega)
    apply List.mem_flatMap.mpr
    refine ⟨b,by cases b <;> simp,?_⟩
    dsimp only
    rw [ite_eq_left ⟨next,win⟩]
    exact List.mem_map.mpr ⟨bs,child,rfl⟩

def profiles (N : Nat) := (optimal (859-6*N) initial).map (fun w=>runs w 0)

private def checked (N : Nat) : Bool :=
  let n:=859-6*N
  upper n initial==720-5*N &&
    (optimal n initial).all (fun bs=>
      let ns:=runs bs 0
      bs==rowsMask ns && !ns.isEmpty && 0<ns.head!)

private theorem data : checked 95=true := by native_decide

theorem extreme_mask
    {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : ℕ) (many : 245≤count p i 289) :
    ∃ns∈profiles 95, ns≠[] ∧ 0<ns.head! ∧ mask p i 289=rowsMask ns := by
  have ok:=data
  unfold checked at ok
  rw [Bool.and_eq_true] at ok
  obtain ⟨maxResult,all⟩:=ok
  let bs := mask p i 289
  have len : bs.length=289 := by simp [bs,mask]
  have bound : upper bs.length initial≤bs.count true := by
    rw [len,eq_of_beq maxResult,mark_count]; exact many
  have hit:=maximizer [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i 289) bound
  rw [len] at hit
  have row:=List.all_eq_true.mp all _ hit
  change ((bs==rowsMask (runs bs 0) && !(runs bs 0).isEmpty) && decide (0<(runs bs 0).head!))=true at row
  obtain ⟨⟨eq,nonempty⟩,pos⟩ := Bool.and_eq_true_iff.mp row |>.imp_left Bool.and_eq_true_iff.mp
  exact ⟨runs bs 0,List.mem_map_of_mem hit,by simpa using nonempty,of_decide_eq_true pos,eq_of_beq eq⟩

#print axioms extreme_mask
end ResidualDensity.Cap95Profiles

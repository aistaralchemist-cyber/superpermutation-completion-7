import BenesBanks

namespace ExactWordFlow.BenesRouting
universe u

private def turned {V : Type u} (f : Bool) (a b : V) := if f then (b,a) else (a,b)

/-- Interleaved output of the last switch bank, in the order of the two pushes. -/
def backRows {V : Type u} (n : Nat) (q : Nat → V × V) : Array V :=
  (List.range n).foldl (fun acc i => (acc.push (q i).1).push (q i).2) #[]

theorem backRows_succ {V : Type u} (n : Nat) (q : Nat → V × V) :
    backRows (n+1) q = ((backRows n q).push (q n).1).push (q n).2 := by
  simp [backRows,List.range_succ]

@[simp] theorem backRows_size {V : Type u} (n : Nat) (q : Nat → V × V) :
    (backRows n q).size = 2*n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [backRows_succ]; simp [ih]; omega

private theorem get_push_old {V : Type u} [Inhabited V] (a : Array V) (x : V) {i : Nat}
    (h : i<a.size) : (a.push x)[i]! = a[i]! := by
  rw [getElem!_pos (a.push x) i (by simp;omega),getElem!_pos a i h]
  exact Array.getElem_push_lt h

private theorem get_push_last {V : Type u} [Inhabited V] (a : Array V) (x : V) :
    (a.push x)[a.size]! = x := by
  rw [getElem!_pos _ _ (by simp)]
  simp

theorem backRows_get {V : Type u} [Inhabited V] {n : Nat} (q : Nat → V × V)
    (i : Nat) (b : Bool) (h : i<n) :
    (backRows n q)[2*i+(if b then 1 else 0)]! = if b then (q i).2 else (q i).1 := by
  induction n with
  | zero => omega
  | succ n ih =>
    rw [backRows_succ]
    by_cases old : i<n
    · have pos : 2*i+(if b then 1 else 0)<(backRows n q).size := by rw [backRows_size]; split <;> omega
      have pos2 := Nat.lt_succ_of_lt pos
      rw [get_push_old _ _ (by simpa only [Array.size_push] using pos2),get_push_old _ _ pos]
      exact ih old
    · have eq : i=n := by omega
      subst i
      cases b with
      | false =>
        simp only [Bool.false_eq_true,ite_false,Nat.add_zero]
        rw [get_push_old _ _ (by simp),←backRows_size n q,get_push_last]
      | true =>
        simp only [ite_true]
        have len : 2*n+1=((backRows n q).push (q n).1).size := by simp
        rw [len,get_push_last]

private theorem range_get {V : Type u} [Inhabited V] (n i : Nat) (f : Nat → V) (h : i<n) :
    ((Array.range n).map f)[i]! = f i := by
  rw [getElem!_pos _ _ (by simpa using h)]
  simp

/-- An array of wires indexed by the natural numbers in the emitter. -/
def Represents {V : Type u} [Inhabited V] (d : Nat) (rows : Array V) (xs : Wire d → V) : Prop :=
  rows.size=2^d ∧ ∀i, rows[(index d i).val]! = xs i

/-- Projection of the pair selected at each input switch, exactly at 2*i and 2*i+1. -/
def frontRows {V : Type u} [Inhabited V] (f : Bank) (node : Nat) (rows : Array V)
    (lane : Bool) : Array V :=
  (Array.range (rows.size/2)).map fun j =>
    let pair := turned (f node false j) rows[2*j]! rows[2*j+1]!
    if lane then pair.2 else pair.1

private theorem front_correct {V : Type u} [Inhabited V] {d : Nat} (f : Bank) (node : Nat)
    (rows : Array V) (xs : Wire (d+1) → V) (h : Represents (d+1) rows xs) (lane : Bool) :
    Represents d (frontRows f node rows lane) (fun i =>
      xs (i, if lane then !(f node false (index d i).val) else f node false (index d i).val)) := by
  have size : rows.size/2=2^d := by rw [h.1,pow_succ]; omega
  refine ⟨by simp [frontRows,size],fun i => ?_⟩
  have bound : (index d i).val < rows.size/2 := by rw [size]; exact (index d i).isLt
  unfold frontRows
  rw [range_get _ _ _ bound]
  have e := h.2 (i,false)
  have o := h.2 (i,true)
  rw [index_pair d i false] at e
  rw [index_pair d i true] at o
  simp only [Bool.false_eq_true, ite_false, ite_true, Nat.zero_add, Nat.add_comm 1] at e o
  cases lane <;> cases hb : f node false (index d i).val <;> simp [turned,hb,e,o]

/-- Value interpretation of the two ordered switch banks with array indices. -/
def arrayRun {V : Type u} [Inhabited V] (f : Bank) : Nat → Nat → Array V → Array V
  | 0,_,xs => xs
  | 1,node,xs =>
    let (a,b) := turned (f node false 0) xs[0]! xs[1]!
    #[a,b]
  | d+2,node,xs =>
    let high := arrayRun f (d+1) (2*node) (frontRows f node xs false)
    let low := arrayRun f (d+1) (2*node+1) (frontRows f node xs true)
    backRows (xs.size/2) (fun j => turned (f node true j) high[j]! low[j]!)

theorem arrayRun_correct {V : Type} [Inhabited V] (f : Bank) : ∀ (d node : Nat)
    (rows : Array V) (xs : Wire d → V), Represents d rows xs →
    Represents d (arrayRun f d node rows) (run d (readSettings f d node) xs)
  | 0,_,_,_,h => h
  | 1,node,rows,xs,h => by
    have e := h.2 ((),false)
    have o := h.2 ((),true)
    change rows[0]! = (xs ((),false)) at e
    change rows[1]! = (xs ((),true)) at o
    refine ⟨by simp [arrayRun],?_⟩
    rintro ⟨⟨⟩,b⟩
    cases b <;> cases hf : f node false 0 <;>
      simp [arrayRun,readSettings,turned,hf,run,e,o,index] <;> rfl 
  | d+2,node,rows,xs,h => by
    have hi := arrayRun_correct f (d+1) (2*node) _ _ (front_correct f node rows xs h false)
    have lo := arrayRun_correct f (d+1) (2*node+1) _ _ (front_correct f node rows xs h true)
    have ns : rows.size/2 = 2^(d+1) := by rw [h.1,pow_succ]; omega
    refine ⟨by simp [arrayRun,ns,pow_succ 2 (d+1), Nat.mul_comm],?_⟩
    rintro ⟨i,b⟩
    let j := (index (d+1) i).val
    have hj : j<rows.size/2 := by rw [ns]; exact (index (d+1) i).isLt
    rw [index_pair (d+1) i b, Nat.add_comm (if b then 1 else 0)]
    unfold arrayRun
    rw [backRows_get _ _ b hj]
    have L := hi.2 i
    have R := lo.2 i
    cases b <;> cases hf : f node true (index (d+1) i).val <;>
      simp [run,readSettings,turned,hf,j,L,R]

theorem sort_array {V K : Type} [Inhabited V] [LinearOrder K]
    (key : V → K) (rows : Array V) (size : rows.size = 2048) :
    ∃ (f : Bank) (p : Equiv.Perm (Fin 2048)),
      Monotone (fun j => key (rows[(p j).val]!)) ∧
      (arrayRun f 11 1 rows).size = 2048 ∧
      ∀j, (arrayRun f 11 1 rows)[j.val]! = rows[(p j).val]! := by
  let xs := fun j : Fin 2048 => rows[j.val]!
  obtain ⟨f,p,mono,back⟩ := sort_with_named_banks key xs
  have rep : Represents 11 rows (fun w => xs (index 11 w)) := ⟨size,fun _=>rfl⟩
  have vals := arrayRun_correct f 11 1 rows _ rep
  refine ⟨f,p,mono,vals.1,fun j => ?_⟩
  have v := vals.2 ((index 11).symm j)
  simpa [xs] using v.trans (back j)

#print axioms sort_array
#print axioms arrayRun_correct
end ExactWordFlow.BenesRouting

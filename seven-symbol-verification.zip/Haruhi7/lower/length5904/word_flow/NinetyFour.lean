import Cap95Geometry
import Cap95Transport
import Cap95Ground
import Cap95Hard
import Target107

namespace ExactWordFlow.NinetyFour
open SevenWordWindows SuperpermutationBounds RotationComponentCount RotationCore
open ResidualDensity ExtremalRealizations ExtremeWheelCut

/-- Every realized 95-component root excludes a connected cover by 95 or fewer
whole wheels. The set of wheel rows may be chosen arbitrarily. -/
theorem no_root_cover {R : Finset Block} (geo : R∈realizations (Cap95Profiles.profiles 95))
    {W : Finset (Finset Block)} (legal : W⊆allRows) (size : W.card≤95) :
    ¬SeedWheelCut.ClosedCover R allClasses W := by
  have checked:=Cap95Catalog.checkedGround
  unfold Cap95Catalog.indexed at checked
  apply Cap95Transport.excluded _ geo legal size
  unfold Cap95Transport.ground Cap95Transport.fast
  exact checked

theorem component_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) : (occupied X s).card≤94 := by
  have older:=NinetyFive.component_limit h budget
  by_contra! many
  obtain ⟨R,geo,W,legal,size,covers⟩:=Cap95Geometry.cover_certificate h budget (by omega)
  exact no_root_cover geo legal size covers

theorem exact_1522 :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
      ∃v : Block,6≤v.length ∧ v.length≤1522 ∧ (visited v).card=720 ∧ 94≤(complete v).card :=
  ComponentCurve.exact_threshold (k:=94) (m:=94) (@component_limit) (by decide) (by decide)

theorem completion_curve (k : Nat) (lo : 94≤k) (hi : k≤720) :
    IsLeast (lengthsFor k) (SuperpermBridge.HR.Ssuper 7-7*(720-k)) :=
  ComponentCurve.completion_curve (@component_limit) k (by omega) lo hi

theorem asked_iff :
    (∃v : Block,6≤v.length ∧ v.length≤1823 ∧ (visited v).card=720 ∧ 137≤(complete v).card) ↔
      ∃v : Block,6≤v.length ∧ v.length≤1522 ∧ (visited v).card=720 ∧ 94≤(complete v).card :=
  RotationCore.exact_1823.symm.trans exact_1522

theorem exact_with_floor (lower : Transfer5901.WordFloor 5901) :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
      ∃v : Block,1519≤v.length ∧ v.length≤1522 ∧ (visited v).card=720 ∧ (complete v).card=94 := by
  rw [exact_1522]
  constructor
  · rintro ⟨v,long,lim,all,done⟩
    obtain ⟨w,cover,size⟩:=expand_remaining long all
    have floor:=lower w cover
    exact ⟨v,by omega,lim,all,by omega⟩
  · rintro ⟨v,low,lim,all,done⟩
    exact ⟨v,by omega,lim,all,done.ge⟩

open private neg_witness from Target107

theorem ceiling_iff : Target107.ceiling 1620 107 ↔ Target107.ceiling 1522 93 := by
  rw [neg_witness 1620 107,neg_witness 1522 93]
  exact not_congr (RotationCore.exact_1620.symm.trans exact_1522)

#print axioms ceiling_iff
#print axioms component_limit
#print axioms exact_1522
end ExactWordFlow.NinetyFour

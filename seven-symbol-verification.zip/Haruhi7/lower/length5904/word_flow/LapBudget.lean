import LapSkeleton

namespace ExactWordFlow.LapSkeleton
open SevenWordWindows SuperpermutationBounds RotationReinsert RotationCore
open DirectedEuler ResidualDensity

/-- The initial six-letter context and all contexts reached by an invalid
seven-window begin stretches. Only full starting contexts carry class labels. -/
private def token (s : Block) : List Block := if full s then [tag s] else []

private def entries : List Block → List Block
  | [] => []
  | e::es => (if e.Nodup then [] else token (dst e)) ++ entries es

def starts (w : Block) := token (w.take 6) ++ entries (windows w)

def dirty (w : Block) := ((anchors w).filter fun s => decide (¬full s)).length

def extraVisits (w : Block) := (good w).length-7*(complete w).card

private def leading (es : List Block) := (es.takeWhile (fun e => decide e.Nodup)).length

private def ShortRuns (es : List Block) :=
  ∀l suffix : List Block, es=l++suffix → leading suffix≤6

private theorem table : ∀p∈representatives,
    full (src p) ∧ full (dst p) ∧ tag (src p)=classKey p ∧ tag (dst p)=classKey p ∧
      src p++((List.finRange 7).filter (fun a=>a∉src p))=p ∧
      ∀q∈RotationRun.turn p, q∈representatives := by native_decide

private theorem unique_legal_run {s t u : Block} {xs ys : List Block}
    (r : Route src dst s xs t) (q : Route src dst s ys u)
    (legal : ∀e∈xs, e∈representatives) (legaly : ∀e∈ys, e∈representatives)
    (len : xs.length=ys.length) : xs=ys := by
  induction r generalizing ys u with
  | nil => exact (List.eq_nil_of_length_eq_zero len.symm).symm
  | cons e hs tail ih =>
    cases q with
    | nil => simp at len
    | cons f hf ft =>
      have ex := (table e (legal e List.mem_cons_self)).2.2.2.2.1
      have ey := (table f (legaly f List.mem_cons_self)).2.2.2.2.1
      have eq : e=f := by rw [←ex,←ey,hs,hf]
      subst f
      exact congrArg (e::·) (ih ft (fun x hx=>legal x (List.mem_cons_of_mem _ hx))
        (fun y hy=>legaly y (List.mem_cons_of_mem _ hy)) (by simpa using len))

private theorem split_route {s t : Block} (l r : List Block)
    (walk : Route src dst s (l++r) t) : ∃ u, Route src dst s l u ∧ Route src dst u r t := by
  induction l generalizing s with
  | nil => exact ⟨s,.nil _,walk⟩
  | cons e l ih =>
    cases walk with
    | cons _ atSrc tail =>
      obtain ⟨u,first,last⟩ := ih tail
      exact ⟨u,.cons e atSrc first,last⟩

theorem free_short {w : Block} (long : 6≤w.length) (free : LapFree w) :
    ShortRuns (windows w) := by
  intro l xs form
  by_contra! many
  let valid := xs.takeWhile (fun e => decide e.Nodup)
  let mid := valid.take 7
  let rest := valid.drop 7 ++ xs.dropWhile (fun e => decide e.Nodup)
  have part : xs=mid++rest := by
    dsimp [mid,rest]
    rw [←List.append_assoc,List.take_append_drop]
    exact List.takeWhile_append_dropWhile.symm
  have width : mid.length=7 := by
    have : 6<valid.length := many
    simp [mid]; omega
  have legal (e : Block) (he : e∈mid) : e∈representatives := by
    have orig : e∈windows w := by rw [form,part]; simp [he]
    have pos := List.mem_of_mem_take he
    have nd := List.mem_takeWhile_imp pos
    exact (mem_reps _).mpr ⟨window_width w orig,of_decide_eq_true nd⟩
  have route := read_route w long
  rw [form,part] at route
  obtain ⟨u,_,tail⟩ := split_route l _ route
  obtain ⟨t,middle,_⟩ := split_route mid rest tail
  cases hm : mid with
  | nil => simp [hm] at width
  | cons p ps =>
    have hp := legal p (by simp [hm])
    have srcp : src p=u := by rw [hm] at middle; cases middle; assumption
    have lap := RotationRun.turn_route hp
    rw [srcp] at lap
    have same := unique_legal_run middle lap legal (table p hp).2.2.2.2.2
      (by simpa [RotationRun.turn] using width)
    apply free
    exact ⟨l,rest,p,hp,by rw [form,part,same,List.append_assoc]⟩

private def hits (es : List Block) := (es.filter (fun e => decide e.Nodup)).map classKey

private theorem entry_limit {s t : Block} {es : List Block} (walk : Route src dst s es t)
    (widths : ∀e∈es, e.length=7) (short : ShortRuns es) (c : Block) :
    (hits es).count c ≤ 6*(entries es).count c +
      (if full s ∧ tag s=c then leading es else 0) := by
  induction walk with
  | nil => simp [hits,entries,leading]
  | @cons s t es e first tail ih =>
    have st : ShortRuns es := by
      intro l v eq
      exact short (e::l) v (by simp [eq])
    have past := ih (fun f hf=>widths f (List.mem_cons_of_mem _ hf)) st
    by_cases nd : e.Nodup
    · have ⟨fs,fd,cs,cd,_⟩ := table e ((mem_reps _).mpr ⟨widths e List.mem_cons_self,nd⟩)
      rw [←first] at *
      by_cases same : classKey e=c
      · simp [hits,entries,nd,cs,fs,leading,same]
        simp [hits,fd,cd,same,leading] at past
        omega
      · simpa [hits,entries,nd,fs,fd,cs,cd,same,List.count_cons] using past
    · have lead := st [] es (by simp)
      by_cases f : full (dst e)
      · by_cases same : tag (dst e)=c
        · simp [hits,entries,nd,token,f,same,leading] at ⊢
          simp only [f,same,and_self,ite_true] at past
          dsimp [hits,leading] at past lead
          omega
        · simp [hits,entries,nd,token,f,same,leading] at ⊢
          simpa [hits,f,same] using past
      · simp [hits,entries,nd,token,f,leading] at ⊢
        simpa [hits,f] using past

/-- A completed class needs two visited stretches once literal laps have
been removed. More generally each stretch supplies at most six occurrences. -/
theorem visit_capacity {w : Block} (long : 6≤w.length) (free : LapFree w) (c : Block) :
    (visits w).count c ≤ 6*(starts w).count c := by
  have short := free_short long free
  have bound := entry_limit (read_route w long) (fun _ he=>window_width w he) short c
  have prefixLength := short [] (windows w) (by simp)
  change (hits (windows w)).count c ≤ _
  by_cases f : full (w.take 6)
  · by_cases eq : tag (w.take 6)=c
    · simp only [f,eq,and_self,ite_true] at bound
      simp [starts,token,f,eq]
      omega
    · simpa [starts,token,f,eq,List.count_cons] using bound
  · simpa [starts,token,f] using bound

private theorem reach {s t : Block} {es : List Block} (walk : Route src dst s es t)
    (widths : ∀e∈es,e.length=7) {c : Block} {u : Block}
    (here : u∈s::es.map dst) (fu : full u) (eq : tag u=c) :
    c∈token s++entries es := by
  induction walk with
  | nil => simp only [List.map_nil,List.mem_singleton] at here; subst u; simp [token,fu,eq]
  | @cons s t es e first tail ih =>
    rcases List.mem_cons.mp here with rfl|later
    · simp [token,fu,eq]
    have was := ih (fun e he=>widths e (List.mem_cons_of_mem _ he)) later
    by_cases nd : e.Nodup
    · have ⟨fs,fd,cs,cd,_⟩ := table e ((mem_reps _).mpr ⟨widths e List.mem_cons_self,nd⟩)
      simpa [entries,token,nd,←first,fs,fd,cs,cd] using was
    · simp [entries,nd,List.mem_append] at ⊢
      exact Or.inr (List.mem_append.mp was)

theorem starts_hit {w : Block} (long : 6≤w.length) {c : Block} (hc : c∈visited w) : c∈starts w := by
  obtain ⟨u,pos,fu,eq⟩ := (mem_visited w c).mp hc
  exact reach (read_route w long) (fun _ he=>window_width w he) pos fu eq

private theorem fibre_num : ∀c∈allClasses, (fibre c).card=7 := by native_decide

private theorem hits_count (es : List Block) (c : Block) :
    (es.map classKey).count c=(es.filter fun e=>decide (classKey e=c)).length := by
  induction es with
  | nil => rfl
  | cons e es ih => by_cases h : classKey e=c <;> simp [h,ih]

theorem completed_hits {w c : Block} (hc : c∈complete w) : 7≤(visits w).count c := by
  obtain ⟨inBoard,all⟩ := (mem_complete _ _).mp hc
  rw [visits,hits_count]
  apply (fibre_num _ inBoard).ge.trans
  apply le_trans _ (List.toFinset_card_le _)
  apply Finset.card_le_card
  intro e he
  obtain ⟨rep,key⟩ := Finset.mem_filter.mp he
  have hp := List.mem_toFinset.mp rep
  exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨List.mem_filter.mpr
    ⟨all e hp key,decide_eq_true ((mem_reps _).mp hp).2⟩,decide_eq_true key⟩)

private theorem sum_counts_le {α : Type*} [DecidableEq α] [BEq α] [LawfulBEq α] (s : Finset α) (xs : List α) :
    ∑ a ∈ s, xs.count a ≤ xs.length := by
  induction xs with
  | nil => simp
  | cons a xs ih =>
    simp only [List.count_cons,List.length_cons,Finset.sum_add_distrib]
    have b : (∑ x∈s, if a==x then 1 else 0) ≤ 1 := by
      simp only [beq_iff_eq]
      rw [Finset.sum_boole]
      exact (Finset.card_le_one.mpr (by intro y hy z hz; simp at hy hz; grind))
    omega

theorem split_floor {w : Block} (long : 6≤w.length) (all : (visited w).card=720)
    (free : LapFree w) : 720+(complete w).card≤(starts w).length := by
  have enough (c : Block) (hc : c∈visited w) :
      1+(if c∈complete w then 1 else 0) ≤ (starts w).count c := by
    by_cases h : c∈complete w
    · have x := completed_hits h
      have y := visit_capacity long free c
      simp [h]; omega
    · simpa [h] using List.count_pos_iff.mpr (starts_hit long hc)
  have bound := Finset.sum_le_sum enough
  simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one,Finset.sum_boole] at bound
  have same : ((visited w).filter (fun c=>c∈complete w))=complete w := by
    ext c
    simp only [Finset.mem_filter]; exact ⟨And.right,fun h=>⟨complete_subset w h,h⟩⟩
  rw [same,all] at bound
  exact bound.trans (sum_counts_le (visited w) (starts w))

theorem completed_floor (w : Block) : 7*(complete w).card≤(good w).length := by
  have bound := Finset.sum_le_sum (s:=complete w) (fun _ hc=>completed_hits hc)
  simp only [Finset.sum_const,smul_eq_mul] at bound
  rw [Nat.mul_comm] at bound
  exact bound.trans (by simpa [visits] using sum_counts_le (complete w) (visits w))

private theorem account_tail {es : List Block} (widths : ∀e∈es, e.length=7) :
    ((es.map dst).filter (fun s=>decide (¬full s))).length+(entries es).length+
      (hits es).length=es.length := by
  induction es with
  | nil => rfl
  | cons e es ih =>
    have prev := ih (fun f hf=>widths f (List.mem_cons_of_mem _ hf))
    by_cases nd : e.Nodup
    · have fd := (table e ((mem_reps _).mpr ⟨widths _ List.mem_cons_self,nd⟩)).2.1
      simp [entries,hits,nd,fd] at prev ⊢; omega
    · by_cases fd : full (dst e) <;>
        simp [entries,hits,token,nd,fd] at prev ⊢ <;> omega

theorem accounting {w : Block} (long : 6≤w.length) :
    dirty w+(starts w).length+(good w).length+5=w.length := by
  have bound := account_tail (fun e he=>window_width w he)
  have align : (hits (windows w)).length=(good w).length := by simp [hits,good]
  rw [align] at bound
  have num := windows_length w
  by_cases fs : full (w.take 6) <;>
    simp [dirty,starts,anchors,token,fs] at bound ⊢ <;> omega

/-- The full three-term loss budget used in the 98-record audit. The terms
on the left are dirty six-contexts, excess class stretches, and excess
permutation windows, respectively. -/
theorem score_budget {w : Block} (long : 6≤w.length) (all : (visited w).card=720) (free : LapFree w) :
    score w=5765+dirty w+((starts w).length-720)+extraVisits w ∧
    (complete w).card≤(starts w).length-720 := by
  have sp := split_floor long all free
  have num := accounting long
  have min := completed_floor w
  have upper := Finset.card_le_card (complete_subset w)
  unfold score extraVisits
  omega

theorem threshold_139 :
    SuperpermBridge.HR.Ssuper 7≤5904 ↔
      ∃w : Block, 6≤w.length ∧ (visited w).card=720 ∧ LapFree w ∧
        dirty w+((starts w).length-720)+extraVisits w≤139 := by
  constructor
  · obtain ⟨w,long,all,free,ss⟩ := exact_skeleton_minimum.1
    intro bound
    exact ⟨w,long,all,free,by have h := (score_budget long all free).1; omega⟩
  · rintro ⟨w,long,all,free,limit⟩
    have low := exact_skeleton_minimum.2
      (show score w∈{n : ℕ | ∃v : Block, 6≤v.length ∧ (visited v).card=720 ∧ LapFree v ∧ score v=n}
        from ⟨w,long,all,free,rfl⟩)
    have h := (score_budget long all free).1
    omega

#print axioms threshold_139
end ExactWordFlow.LapSkeleton

import SeedWheelCut

namespace MarkedWheelBound
open SeedWheelCut

/-- Count each target once, and count a distinguished target in H once more. -/
def weight {α : Type*} [DecidableEq α] (H C : Finset α) := C.card + (C∩H).card

private theorem attach {α : Type*} [DecidableEq α] {P H A w : Finset α} {k : Nat}
    (seed : P ⊆ A) (meet : (A∩w).Nonempty) (small : w.card ≤ k)
    (bonus : (w∩H).card ≤ max 1 (P∩w).card) :
    weight H (A∪w) ≤ weight H A + k := by
  have once : 1 ≤ (A∩w).card := Finset.card_pos.mpr meet
  have old : (P∩w).card ≤ (A∩w).card := Finset.card_le_card (Finset.inter_subset_inter_right seed)
  have charged := bonus.trans (max_le once old)
  have base := Finset.card_union_add_card_inter A w
  have colored : ((A∪w) ∩ H).card ≤ (A∩H).card + (w∩H).card := by
    rw [Finset.union_inter_distrib_right]
    exact Finset.card_union_le _ _
  unfold weight
  omega

/-- In any connected completion by sets of width k, each new set can pay
at most k weighted units, provided its distinguished targets are paid for
by overlap with a fixed seed. The initial set and all attachment orders are free. -/
theorem connected_bound {α : Type*} [DecidableEq α] (P H A V : Finset α)
    (W : Finset (Finset α)) (k : Nat) (seed : P ⊆ A)
    (price : ∀ w∈W, w.card ≤ k ∧ (w∩H).card ≤ max 1 (P∩w).card)
    (cover : ClosedCover A V W) : weight H V ≤ weight H A + k * W.card := by
  classical
  by_cases grow : ∃ w∈W, (A∩w).Nonempty ∧ ¬w⊆A
  · obtain ⟨w,hw,meet,_⟩ := grow
    have next : ClosedCover (A∪w) V (W.erase w) := by
      intro C hC closed
      apply cover C (Finset.subset_union_left.trans hC)
      intro x hx hit
      by_cases eq : x=w
      · exact eq ▸ Finset.subset_union_right.trans hC
      · exact closed x (Finset.mem_erase.mpr ⟨eq,hx⟩) hit
    have tail := connected_bound P H (A∪w) V (W.erase w) k
      (seed.trans Finset.subset_union_left) (fun v hv => price v (Finset.mem_of_mem_erase hv)) next
    have change := attach seed meet (price w hw).1 (price w hw).2
    rw [←Finset.card_erase_add_one hw, Nat.mul_add, Nat.mul_one]
    omega
  · have sub := cover A (Finset.Subset.refl _) (fun w hw meet => by
      by_contra missing; exact grow ⟨w,hw,meet,missing⟩)
    have v := Finset.card_le_card sub
    have vH : (V∩H).card ≤ (A∩H).card := Finset.card_le_card (Finset.inter_subset_inter_right sub)
    unfold weight
    omega
termination_by W.card
decreasing_by have size := Finset.card_erase_add_one hw; omega

/-- Independent of geometry: if every allowable wheel meets H at most once,
covering H requires at least as many distinct wheels as target classes. -/
theorem packing_bound {α : Type*} [DecidableEq α] (H : Finset α) (W : Finset (Finset α))
    (cover : ∀ x∈H, ∃ w∈W, x∈w) (unique : ∀ w∈W, (w∩H).card≤1) :
    H.card ≤ W.card := by
  have incl : H ⊆ W.biUnion (fun w => w∩H) := by
    intro x hx
    obtain ⟨w,hw,member⟩ := cover x hx
    exact Finset.mem_biUnion.mpr ⟨w,hw,Finset.mem_inter.mpr ⟨member,hx⟩⟩
  have size := (Finset.card_le_card incl).trans (Finset.card_biUnion_le)
  exact size.trans (by simpa using Finset.sum_le_sum unique)

end MarkedWheelBound
#print axioms MarkedWheelBound.connected_bound
#print axioms MarkedWheelBound.packing_bound

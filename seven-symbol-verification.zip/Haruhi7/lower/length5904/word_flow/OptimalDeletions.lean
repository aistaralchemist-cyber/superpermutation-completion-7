import PartialRepair
import PacketRepair
import TwelveBudget

namespace ExactWordFlow.OptimalDeletions
open SevenWordWindows SuperpermutationBounds ResidualDensity RotationCore RotationComponentCount
open private packet_data from TwelveBudget

noncomputable def Opt := SuperpermBridge.HR.Ssuper 7

/-- In a globally shortest candidate no rounding or external-floor
slack is available to any balanced deletion, at either endpoint. -/
theorem cut {A B : Multiset Block} {s t : Block} (feas : Feasible (A+B) s t)
    (opt : (A+B).card+5046=Opt) (closed : Essential.Balanced B) :
    B.card ≤ 5*((PacketRepair.groups A).card-1) := by
  obtain ⟨z,all,sz⟩:=PacketRepair.repair feas.start_six
    (fun e he=>feas.edges_seven e (Multiset.mem_add.mpr (Or.inl he))) (Essential.restBalance feas closed)
  have low : Opt≤z.length := SuperpermBridge.ssuper_le_length all
  rw [Multiset.card_add] at opt
  omega

theorem six {A B : Multiset Block} {s t : Block} (feas : Feasible (A+B) s t)
    (opt : (A+B).card+5046=Opt) (closed : Essential.Balanced B) (size : B.card=6) :
    3≤(PacketRepair.groups A).card := by
  have price:=cut feas opt closed
  omega

theorem twelve {w : Block} {X : Multiset Block} {s t q : Block} (feas : Feasible X s t)
    (opt : X.card+5046=Opt) (actual : required+X=bag w)
    (done : q∈TwelveCycleRank.completed w) :
    4 ≤ (PacketRepair.groups (X-(TwelveCycleRank.edges q).val)).card := by
  obtain ⟨base,all⟩:=Finset.mem_filter.mp done
  obtain ⟨size,bal,bad⟩:=packet_data q base
  have le : (TwelveCycleRank.edges q).val≤X := by
    apply (Multiset.le_iff_subset (TwelveCycleRank.edges q).nodup).mpr
    intro e mem
    have total : e∈required+X := actual ▸ (show e∈bag w from List.mem_toFinset.mp (all mem))
    exact (Multiset.mem_add.mp total).resolve_left (fun req=>bad e mem ((mem_reps e).mp req).2)
  have eq := tsub_add_cancel_of_le le
  have price:=cut (eq.symm ▸ feas) (eq.symm ▸ opt) bal
  change (TwelveCycleRank.edges q).card ≤ 5*((PacketRepair.groups (X-(TwelveCycleRank.edges q).val)).card-1) at price
  omega

theorem minimum_price {v : Block} (long : 6≤v.length) :
    Opt+7*(complete v).card ≤ v.length+5040+5*(720-(visited v).card) := by
  obtain ⟨z,all,sz⟩:=PartialRepair.expand_partial long
  have low : Opt≤z.length := SuperpermBridge.ssuper_le_length all
  have sub:=((complete_subset v).trans (visited_subset v))
  have cap:=Finset.card_le_card sub
  rw [board] at cap
  omega

/-- If there is a counterexample, one may choose a shortest core with no
profitable edit. A lost visit is allowed and charged five letters. -/
theorem exact_minimal_core (floor : Transfer5901.WordFloor 5901) (small : Opt≤5904) :
    ∃v : Block, 1526≤v.length ∧ v.length≤1529 ∧ (visited v).card=720 ∧
       (complete v).card=95 ∧ v.length+4375=Opt ∧
       ∀u : Block,6≤u.length → v.length+7*(complete u).card≤
           u.length+665+5*(720-(visited u).card) := by
  obtain ⟨z,cover,attain⟩:=SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
  have lo : 5901≤Opt := by simpa only [Opt,←attain] using floor z cover
  obtain ⟨v,long,vis,completed,size⟩:=(NinetyFive.completion_curve 95 (by decide) (by decide)).1
  change v.length=Opt-4375 at size
  obtain ⟨low,eq⟩:=ShortBudget95.floor_transfer floor long (by omega) vis completed
  refine ⟨v,low,by omega,vis,eq,by omega,?_⟩
  intro u hu
  have edit:=minimum_price hu
  omega

#print axioms cut
#print axioms twelve
#print axioms exact_minimal_core
end ExactWordFlow.OptimalDeletions

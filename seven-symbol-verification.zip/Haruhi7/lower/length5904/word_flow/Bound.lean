import WheelMinimumBoundary

namespace ExactWordFlow.WheelCoverCapacity
open SevenWordWindows ResidualDensity RotationCore LiteralWheelCover

theorem gain_le (b : Block) {R : Row} (hr : R ∈ ready b) : (R \ visited b).card ≤ 5 := by
  obtain ⟨u,hu,fl,rfl⟩ := mem_ready.mp hr
  have seen : tag u ∈ visited b := (mem_visited _ _).mpr ⟨u,hu,fl,rfl⟩
  have inside : tag u ∈ WheelContacts.wheel u := by
    apply List.mem_toFinset.mpr
    apply List.mem_map.mpr
    exact ⟨0,by decide,by simp⟩
  obtain ⟨t,ht,eq⟩ := WheelContacts.complete fl
  have cnt := WheelContacts.wheel_contacts ht ht
  have six : (WheelContacts.wheel u).card=6 := by simpa [WheelContacts.gapCount,eq] using cnt
  have fewer : (WheelContacts.wheel u \ visited b).card < (WheelContacts.wheel u).card := by
    apply Finset.card_lt_card
    refine Finset.ssubset_iff_subset_ne.mpr ⟨Finset.sdiff_subset,?_⟩
    intro e
    exact (Finset.mem_sdiff.mp (e.symm ▸ inside)).2 seen
  omega

theorem cover_bound {b : Block} {k : Nat} (cover : condition b k) :
    720 ≤ (visited b).card + 5*k := by
  classical
  obtain ⟨S,valid,count,all⟩ := cover
  have inc : allClasses \ visited b ⊆ S.biUnion (fun R => R \ visited b) := by
    intro c hc
    obtain ⟨R,hR,wit⟩ := Finset.mem_biUnion.mp (all hc)
    exact Finset.mem_biUnion.mpr ⟨R,hR,Finset.mem_sdiff.mpr ⟨wit,(Finset.mem_sdiff.mp hc).2⟩⟩
  have sumle := Finset.sum_le_sum (fun R (hR:R∈S) => gain_le b (valid hR))
  have many := (Finset.card_le_card inc).trans (Finset.card_biUnion_le)
  rw [Finset.card_sdiff_of_subset (visited_subset b),board] at many
  simp only [Finset.sum_const,smul_eq_mul] at sumle
  omega

#print axioms cover_bound
end ExactWordFlow.WheelCoverCapacity

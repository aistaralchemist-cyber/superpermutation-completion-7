import FusedPacked92
import Cap92Lookup
import NormalizedClosed306

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows DirectedEuler ResidualDensity EmbeddedWheels

/-- Even without imposing the literal base-word condition, no 92 full
turns, including intersecting turns, fit in a feasible flow of cost 858. -/
theorem arbitrary_turns_le_91 {Y : Multiset Block} {ws : List Block} {s t : Block}
    (fw : ∀w∈ws,full w) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) : ws.length≤91 := by
  have high:=arbitrary_turns_le_92 fw h budget
  by_contra! many
  obtain ⟨P,yes,W,legal,size,closed⟩:=NormalizedClosed306.certificate fw h budget (by omega)
    Cap92Lookup.accept FusedPacked92.checked
  exact Cap92Lookup.no_cover yes legal size closed

#print axioms arbitrary_turns_le_91
end ExactWordFlow.WheelBaseResidual

import Mathlib.GroupTheory.Perm.Cycle.Type
import GlobalWheelRank
open Equiv
namespace ExactWordFlow.PermutationGenus

variable {X : Type*} [Fintype X] [DecidableEq X]

private noncomputable def packs (f : Perm X) := by
  classical exact f.cycleFactorsFinset.image Equiv.Perm.support

private theorem pack_cost (f : Perm X) :
    (∑ s ∈ packs f, (s.card-1)) + f.cycleType.card ≤ f.support.card := by
  classical
  have h : (∑ s ∈ packs f, (s.card-1)) ≤
       ∑ c ∈ f.cycleFactorsFinset, (c.support.card-1) :=
    Finset.sum_image_le_of_nonneg (fun _ _ => Nat.zero_le _)
  have h1 : (∑ c ∈ f.cycleFactorsFinset, (c.support.card-1)) + f.cycleFactorsFinset.card
      = ∑ c ∈ f.cycleFactorsFinset, c.support.card := by
    calc _ = ∑ c ∈ f.cycleFactorsFinset, (c.support.card-1+1) := by simp [Finset.sum_add_distrib]
         _ = _ := by
           apply Finset.sum_congr rfl
           intro c hc
           obtain ⟨x,hx,_⟩ := (Equiv.Perm.mem_cycleFactorsFinset_iff.mp hc).1
           have pos := Finset.card_pos.mpr (show c.support.Nonempty from ⟨x,Perm.mem_support.mpr hx⟩)
           omega
  have h2 : f.cycleType.card = f.cycleFactorsFinset.card := by simp [Perm.cycleType_def]
  have h3 : (∑ c ∈ f.cycleFactorsFinset, c.support.card) = f.support.card := by
    change (f.cycleFactorsFinset.val.map (Finset.card ∘ Perm.support)).sum = _
    exact f.sum_cycleType
  omega

private theorem step {B : Finset (Finset X)} {Z : Finset X}
    (closed : ∀ s∈B,(Z∩s).Nonempty→s⊆Z) (f : Perm X) (contained : packs f⊆B) {x} (hx : x∈Z) :
    f x ∈ Z := by
  classical
  by_cases fixed : f x=x
  · simpa [fixed] using hx
  · have moved := Perm.mem_support.mpr fixed
    have inside : (f.cycleOf x).support∈B :=
      contained (Finset.mem_image_of_mem _ (Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr moved))
    exact closed _ inside ⟨x,Finset.mem_inter.mpr ⟨hx,
      Perm.mem_support_cycleOf_iff.mpr ⟨.refl _ _,moved⟩⟩⟩
      (Perm.mem_support_cycleOf_iff.mpr ⟨Perm.sameCycle_apply_right.mpr (.refl _ _),moved⟩)

/-- The rank needed to join separated rotation cycles follows from the full
successor orbit. Both actual permutations act on the same finite set. -/
theorem incidence_rank (R h : Perm X) (start : X)
    (oneOrbit : ∀y, (R*h).SameCycle start y) :
    Fintype.card X + R.cycleType.card + h.cycleType.card ≤
      1+R.support.card+h.support.card := by
  classical
  obtain ⟨Z,root,bound,closed⟩:=GlobalWheelRank.grow {start} (packs R ∪ packs h)
  have hx : start∈Z := root (Finset.mem_singleton_self _)
  have grow (x) (mem : x∈Z) : (R*h) x∈Z :=
    step closed R Finset.subset_union_left (step closed h Finset.subset_union_right mem)
  have all : ∀ n : Nat, ((R*h)^n) start∈Z := by
    intro n
    induction n with
    | zero => simpa using hx
    | succ n ih => simpa [pow_succ',Perm.mul_apply] using grow _ ih
  have whole : Z=Finset.univ := Finset.eq_univ_of_forall (fun y => by
    obtain ⟨n,_,_,eq⟩:=(oneOrbit y).exists_pow_eq _
    exact eq ▸ all n)
  have sum := Finset.sum_union_inter (s₁:=packs R) (s₂:=packs h) (f:=fun s => s.card-1)
  have r:=pack_cost R
  have u:=pack_cost h
  simp only [whole,Finset.card_univ,Finset.card_singleton] at bound
  omega

/-- For seven-symbol permutations the surplus incidence rank is always
even. This is the one-face genus in the Euler characteristic formula. -/
theorem genus_seven (R h : Perm X) (start : X) (N : Fintype.card X=5040)
    (rotations : R.cycleType=Multiset.replicate 720 7)
    (single : (R*h).cycleType={5040}) (oneOrbit : ∀y,(R*h).SameCycle start y) :
    ∃g : Nat, h.support.card = h.cycleType.card + 719 + 2*g := by
  have lower:=incidence_rank R h start oneOrbit
  have cntR : R.cycleType.card=720 := by rw [rotations,Multiset.card_replicate]
  have supR : R.support.card≤5040 := N ▸ Finset.card_le_univ _
  have signR : Perm.sign R=1 := by rw [R.sign_of_cycleType,rotations,Multiset.sum_replicate,Multiset.card_replicate]; exact Even.neg_one_pow (by exact ⟨2880,by decide⟩)
  have signP : Perm.sign (R*h) = -1 := by rw [(R*h).sign_of_cycleType,single,Multiset.sum_singleton,Multiset.card_singleton]; exact Odd.neg_one_pow (by exact ⟨2520,by decide⟩)
  rw [map_mul,signR,one_mul,h.sign_of_cycleType,h.sum_cycleType] at signP
  have odd := (neg_one_pow_eq_neg_one_iff_odd (by decide : (-1 : ℤˣ)≠1)).mp signP
  obtain ⟨j,hj⟩:=odd
  refine ⟨(h.support.card-h.cycleType.card-719)/2,?_⟩
  omega

/-- Count the open overlap cost, with the artificial closing arc excluded
and with the genuine nonnegative weight surcharge above distance two.
The weights need only certify the ordinary cost-one rotation. -/
theorem open_cost_seven (R h : Perm X) (start last : X) (d : X → Nat)
    (N : Fintype.card X=5040) (rotations : R.cycleType=Multiset.replicate 720 7)
    (single : (R*h).cycleType={5040}) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (positive : ∀x,x≠last → 1≤d x)
    (ordinary : ∀x,x≠last → (d x=1 ↔ h x=x)) :
    ∃g : Nat, h.support.card=h.cycleType.card+719+2*g ∧
      7+(∑ x ∈ Finset.univ.erase last,d x)+(if h last=last then 0 else 1)=
      5765+h.cycleType.card+(∑ x ∈ Finset.univ.erase last,(d x-2))+2*g := by
  classical
  let A : Finset X := Finset.univ.erase last
  have card : A.card=5039 := by simp [A,N]
  let indicator (x : X) := if x∈h.support then 1 else 0
  have local_cost (x : X) (hx : x∈A) : d x=1+indicator x+(d x-2) := by
    have ne := (Finset.mem_erase.mp hx).1
    have pos := positive x ne
    by_cases moved : x∈h.support
    · have diff := Perm.mem_support.mp moved
      have high : d x≠1 := (ordinary x ne).not.mpr diff
      simp only [indicator,ite_eq_left moved]
      omega
    · have fix : h x=x := by simpa using moved
      simp only [indicator,ite_eq_right moved,(ordinary x ne).mpr fix]
  have total : ∑ x ∈ A,d x=A.card+(∑x∈A,indicator x)+(∑x∈A,(d x-2)) := by
    rw [Finset.sum_congr rfl local_cost]
    simp [Finset.sum_add_distrib]
  have all : ∑ x : X,indicator x=h.support.card := by
    change (∑ x : X, if x∈h.support then 1 else 0)=_
    rw [←Finset.sum_filter]
    simp only [Finset.filter_mem_eq_inter,Finset.univ_inter,Finset.sum_const,smul_eq_mul,mul_one]
  have close : indicator last=(if h last=last then 0 else 1) := by
    by_cases yes : h last=last <;> simp [indicator,Perm.mem_support,yes]
  have restore:=Finset.sum_erase_add Finset.univ indicator (Finset.mem_univ last)
  change (∑x∈A,indicator x)+indicator last = _ at restore
  rw [all,close] at restore
  obtain ⟨g,eq⟩:=genus_seven R h start N rotations single oneOrbit
  refine ⟨g,eq,?_⟩
  change 7+(∑ x∈A,d x)+(if h last=last then 0 else 1)=_
  change _=5765+h.cycleType.card+(∑ x∈A,(d x-2))+2*g
  omega

#print axioms open_cost_seven
#print axioms incidence_rank
#print axioms genus_seven
end ExactWordFlow.PermutationGenus

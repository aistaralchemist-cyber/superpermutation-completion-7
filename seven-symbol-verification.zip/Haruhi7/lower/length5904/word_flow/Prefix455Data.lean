import Dense462
import SeedWheelCut

namespace Prefix455
open ExactWordFlow SevenWordWindows ResidualDensity GlobalWheelRank DirectedEuler

def baseWord := Dense462.word.take 461
def seen := touched (baseWord.take 6 :: (windows baseWord).map dst)
def last := baseWord.drop 455

def dead := ["0154623","0156423","0231546","0231564","0546231","0564231","0623154"].map
  (fun s => s.toList.map (fun c => Fin.ofNat 7 (c.toNat-48)))
def forbidden := dead.toFinset
def allWheels := roots.image GlobalWheelRank.touches

theorem prefix_geometry :
    (windows baseWord).length=455 ∧ seen.card=384 ∧ forbidden.card=7 ∧
    allClasses.card=720 ∧ forbidden ⊆ allClasses ∧ Disjoint seen forbidden ∧
    (∀ w∈allWheels, w.card=6 ∧ ∀ d∈forbidden, d∈w → 2≤(seen∩w).card) := by
  native_decide

/-- Seven further edges meet at most six distinct clean classes at their
seven destinations. This counts only the continuation, without either end
specified in advance. -/
theorem seven_destinations {a b : Block} {es : List Block} (r : Route src dst a es b)
    (ww : ∀ e∈es, e.length=7) (k : es.length=7) :
    (touched (es.map dst)).card ≤ 6 := by
  cases r with
  | nil => simp at k
  | @cons z f qs e hs tail =>
    have len : qs.length=6 := by simpa using k
    have ok (t) (ht : t∈qs) := ww t (List.mem_cons_of_mem _ ht)
    obtain ⟨u,I,w,hm,hc⟩ := open_observations tail ok
    have lim := open_count w hm 0 (qs.length+1)
    rw [hc,len] at lim
    exact lim

#print axioms prefix_geometry
#print axioms seven_destinations
end Prefix455

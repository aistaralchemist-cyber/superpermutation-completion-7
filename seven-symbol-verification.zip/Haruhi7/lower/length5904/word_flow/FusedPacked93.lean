import FusedPacked
import WheelAcceptBits
import WheelBitsFacts

namespace ExactWordFlow.FusedPacked93
open SevenWordWindows RotationCore

private def raw : Bool := FusedPacked.check 300 Cap93Lookup.acceptBits
set_option maxHeartbeats 0 in
private theorem raw_ok : raw=true := by native_decide

theorem checked : FusedAny.check 300 Cap93Lookup.accept=true := by
  apply FusedPacked.certified 300 Cap93Lookup.acceptBits _ _ raw_ok
  intro R board accepted
  rw [←Cap93Lookup.acceptBits_eq,accepted]
  simpa using fun c hc=>Cap94Lookup.known_of_board (board hc)

#print axioms checked
end ExactWordFlow.FusedPacked93

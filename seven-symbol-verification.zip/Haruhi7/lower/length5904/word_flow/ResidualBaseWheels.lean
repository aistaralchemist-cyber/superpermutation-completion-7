import DisjointBaseWheels
import CanonicalBaseSpare

namespace ExactWordFlow.WheelBaseExits
open SevenWordWindows RotationCore RotationReinsert ResidualDensity ResidualRoutes WheelFreeBoundary

private theorem wheelFacts : ∀s∈states,∀u∈phases s,
    (∃e∈GlobalWheelRank.wheel s,src e=u) ∧ prefixAt u 1∈GlobalWheelRank.wheel s ∧
    ∀a : Fin 7,u++[a]∈GlobalWheelRank.wheel s → a=u.headD 0 := by native_decide

/-- Translate the two-departure obstruction to a component of the actual
remaining edge multiset, with the endpoint tested on the same base. -/
theorem component {b s : Block} {q : Component (spare b)} (clean : full s)
    (only : part (spare b) q=↑(GlobalWheelRank.wheel s))
    (away : label (spare b) (b.drop (b.length-6))≠q) : isolated b (WheelContacts.wheel s) := by
  have table:=wheelFacts s (mem_states clean)
  have lab (u : Block) (uh : u∈phases s) : label (spare b) u=q := by
    obtain ⟨e,he,srcEq⟩:=(table u uh).1
    have inc : e∈part (spare b) q:=only ▸ he
    exact srcEq ▸ (in_part.mp inc).2
  have widths : ∀u∈phases s,full u := by
    have hs:=mem_states clean
    have checked : ∀v∈states,∀u∈phases v,full u := by native_decide
    exact checked s hs
  refine ⟨s,clean,rfl,?_,?_,?_⟩
  · intro u uh
    have here : prefixAt u 1∈part (spare b) q:=only ▸ (table u uh).2.1
    have le : spare b≤bag b := Multiset.sub_le_self ..
    have seen:=Multiset.mem_of_le le (in_part.mp here).1
    exact window_occurs b seen
  · intro u uh l eq
    have len:=(widths u uh).1
    have endEq : b.drop (b.length-6)=u := by
      rw [eq]
      simp [len]
    exact away (endEq ▸ lab u uh)
  · intro u uh a edge
    have srcEq : src (u++[a])=u:=by simp [src,(widths u uh).1]
    have mem : u++[a]∈part (spare b) q := in_part.mpr ⟨edge,by rw [srcEq];exact lab u uh⟩
    rw [only] at mem
    exact (table u uh).2.2 a mem

theorem zero_flow {b : Block} (size : b.length=1508)
    (seen : (visited b).card=720) (done : (complete b).card=92) :
    Feasible (spare b) (b.take 6) (b.drop (b.length-6)) ∧ (spare b).card=858 := by
  have boardEq : visited b=allClasses:=Finset.eq_of_subset_of_card_le (visited_subset b) (by rw [seen,board])
  apply WheelBaseResidual.zero_spare done size
  exact ⟨∅,Finset.empty_subset _,by simp,by simp [boardEq]⟩

#print axioms component
end ExactWordFlow.WheelBaseExits

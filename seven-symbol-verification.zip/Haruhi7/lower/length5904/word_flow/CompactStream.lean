import CompactSwitchOrientation
import Std.Tactic.BVDecide.LRAT.Internal.Checker

namespace ExactWordFlow.CompactStream
open Std.Sat Std.Tactic.BVDecide.LRAT
open Internal (State)

inductive Result
  | next (s : State)
  | finish (accepted : Bool)

private def clauseOf (xs : Array Int) : CNF.Clause Nat := .ofLiterals <|
  xs.toList.filterMap fun x=>if x>0 then some (x.natAbs-1,true)
    else if x<0 then some (x.natAbs-1,false) else none

/-- The state transitions are Std LRAT's empty, RUP, RAT and deletion checks.
An exhausted list never certifies unsatisfiability. -/
def step (s : State) : IntAction → Result
  | .addEmpty _ hints => .finish (s.checkEmpty hints)
  | .addRup _ lits hints =>
    let c:=clauseOf lits
    if s.checkRup c hints then .next (s.add c) else .finish false
  | .addRat _ lits pivot hints rats =>
    let c:=clauseOf lits
    if s.checkRat c (pivot.1-1,pivot.2) hints rats then .next (s.add c) else .finish false
  | .del ids => .next (s.deleteMany ids)

def Result.sound : Result → Prop
  | .next s => s.toCNF.Unsat
  | .finish b => b=true

theorem step_sound (s : State) (a : IntAction) : (step s a).sound → s.toCNF.Unsat := by
  cases a with
  | addEmpty _ hs =>
    intro h
    exact CNF.unsat_of_entails_clause_unsat (c:=.empty) (by simp)
      (State.entails_clause_empty_of_checkEmpty h)
  | addRup _ cs hs =>
    simp only [step]
    split
    next valid =>
      exact fun tail=>CNF.unsat_of_entails_unsat tail
        (State.entails_add_of_entails_clause (State.entails_clause_of_checkRup valid))
    next => intro h; contradiction
  | addRat _ cs p hs rats =>
    simp only [step]
    split
    next valid =>
      intro tail
      exact CNF.unsat_of_forall_exists (fun _ hv=>State.unsat_of_unsat_of_checkRat valid hv) tail
    next => intro h; contradiction
  | del ids => exact fun tail=>CNF.unsat_of_entails_unsat tail State.entails_deleteMany

def runList (s : State) : List IntAction → Bool
  | [] => false
  | a::rest => match step s a with
    | .finish b => b
    | .next t => runList t rest

theorem runList_sound (s : State) (actions : List IntAction) :
    runList s actions=true → s.toCNF.Unsat := by
  induction actions generalizing s with
  | nil => intro h; contradiction
  | cons a rest ih =>
    intro h
    apply step_sound s a
    rw [runList] at h
    cases e : step s a <;> simp only [e] at h ⊢
    · exact ih _ h
    · exact h

/-- The file loop keeps a predecessor implication as erased proof data. -/
inductive Checked (f : CNF Nat)
  | next (st : State) (transfer : st.toCNF.Unsat → f.Unsat)
  | yes (proof : f.Unsat)
  | no

def feed {f : CNF Nat} (c : Checked f) (action : IntAction) : Checked f := by
  cases c with
  | no => exact .no
  | yes h => exact .yes h
  | next s transfer =>
    cases e : step s action with
    | next t => exact .next t (fun h=>transfer (step_sound s action (e ▸ h)))
    | finish b =>
      cases b with
      | false => exact .no
      | true => exact .yes (transfer (step_sound s action (by rw [e];rfl)))

def start (f : CNF Nat) : Checked f :=
  .next (State.ofCNF f) (by simp)

def endResult {f : CNF Nat} : Checked f → Option (PLift f.Unsat)
  | .yes h => some ⟨h⟩
  | _ => none

/-- File lines include their line delimiter. The Std ASCII parser consumes each
line completely, including empty-clause additions, deletions and comments.
Only the current line and checker state are retained. -/
def fromHandle (f : CNF Nat) (h : IO.FS.Handle) : IO (Nat × Option (PLift f.Unsat)) := do
  let mut check := start f
  let mut lineNo := 0
  let mut count := 0
  repeat
    let line ← h.getLine
    if line.isEmpty then return (count,endResult check)
    lineNo := lineNo+1
    match Std.Tactic.BVDecide.LRAT.Parser.Text.parseActions.run line.toUTF8 with
    | .error e => throw (IO.userError s!"LRAT line {lineNo}: {e}")
    | .ok actions =>
      for action in actions do
        count := count+1
        check := feed check action
        if let .no := check then return (count,none)
  return (count,endResult check)

#print axioms runList_sound
end ExactWordFlow.CompactStream

open ExactWordFlow.CompactWordCircuit in
def main (args : List String) : IO UInt32 := do
  let [mode,path] := args | throw (IO.userError "expected full|full-oriented|control proof.lrat")
  let t ← match mode with
    | "full" | "full-oriented" => pure (goalTape true)
    | "control" => pure (compact 3 8 2 false)
    | _ => throw (IO.userError "unknown instance")
  let f := if mode == "full-oriented" then checkerFormula t ++ orientationUnits else checkerFormula t
  IO.println s!"variables={t.vars} clauses={f.clauses.size}"
  let (count,result) ← IO.FS.withFile path .read (ExactWordFlow.CompactStream.fromHandle f)
  IO.println s!"LRAT actions={count}"
  if result.isSome then
    IO.println "stream check=true"
    return 0
  IO.eprintln "stream check=false"
  return 1

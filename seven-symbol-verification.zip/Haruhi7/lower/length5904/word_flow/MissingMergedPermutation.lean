import FiveFiberMerge
namespace ExactWordFlow.FiveFiberMerge
open SevenWordWindows SuperpermutationBounds
open private lifting from FiveFiberMerge
open private perm_mem from SixProjection

/-- For every merged pair, the same missing six-permutation forbids both of
its unmerged six-letter words as contiguous factors. -/
theorem two_missing_contexts {w : Block} (short : w.length<870) (e : Fin 7 ≃ Fin 7) :
    ∃p : SixWord, p.length=6 ∧ p.Nodup ∧
      ∀v : Bool, ¬p.map (liftLetter v) <:+: w.map e := by
  have no : ¬Covers ((w.map e).map foldLetter) := by
    intro yes
    have h := SuperpermLowerBounds.superperm_kisic_numerical_bounds.2.1.trans
      (SuperpermBridge.ssuper_le_length yes)
    simp only [List.length_map] at h
    omega
  unfold Covers at no
  push_neg at no
  obtain ⟨p,hp,nd,miss⟩:=no
  refine ⟨p,hp,nd,?_⟩
  intro v hit
  obtain ⟨l,r,eq⟩:=hit
  apply miss (l.map foldLetter) (r.map foldLetter)
  have recov:=(lifting p (perm_mem hp nd) v).2.2.2.2
  rw [←eq,List.map_append,List.map_append,recov]
#print axioms two_missing_contexts
end ExactWordFlow.FiveFiberMerge

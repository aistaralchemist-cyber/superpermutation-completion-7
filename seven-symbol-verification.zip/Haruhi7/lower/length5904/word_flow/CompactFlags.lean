import CompactBenes
import PhysicalFlags

namespace ExactWordFlow.CompactWordCircuit
open CoreCandidateBanks (pk pm physicalFinish physicalRun physicalFlags)
open private from_indices from CompactBenes

abbrev SymbolMask := Finset (Fin 7)

def maskVec (m : SymbolMask) : Array Bool := Array.ofFn fun i : Fin 7=>decide (i∈m)
@[simp] theorem maskVec_size (m : SymbolMask) : (maskVec m).size=7 := by simp [maskVec]
theorem maskVec_at (m : SymbolMask) (i : Nat) (hi : i<7) :
    (maskVec m)[i]! = decide (⟨i,hi⟩∈m) := by
  rw [getElem!_pos _ _ (by simpa using hi)]
  simp [maskVec]

private theorem pm_at (r : Array Bool) (width : r.size=26) (i : Nat) (hi : i<7) :
    decide (⟨i,hi⟩∈pm r) = r[19+i]! := by
  have bound : 19+i<r.size := by omega
  simp [pm, getElem?_pos r (19+i) bound,getElem!_pos r (19+i) bound]

def flagMask (r : Array Bool) (keep : Bool) (m : SymbolMask) : SymbolMask :=
  pm r ∪ if keep then m else ∅

theorem flagMask_at (r : Array Bool) (width : r.size=26) (keep : Bool) (m : SymbolMask)
    (i : Nat) (hi : i<7) :
    (maskVec (flagMask r keep m))[i]! = (r[19+i]! || (keep && (maskVec m)[i]!)) := by
  rw [maskVec_at _ _ hi,maskVec_at _ _ hi,←pm_at r width i hi]
  cases keep <;> simp [flagMask]

theorem maskStep_grows (n nk : Nat) (r : Bits) (eq : W) (prev : Bits) :
    Grows (maskStep n nk r eq prev) :=
  mapArray_grows (fun _=>bind_grows (allGate_grows _) (fun _=>anyGate_grows _)) _

theorem groupCell_grows (n nk : Nat) (r : Bits) (eq last : W) (prev : Bits) :
    Grows (groupCell n nk r eq last prev) :=
  bind_grows (maskStep_grows _ _ _ _ _) (fun _=>bind_grows (allGate_grows _) (fun _=>
    bind_grows (allGate_grows _) (fun _=>pure_grows _)))

theorem groupRows_grows (n nk : Nat) : ∀ (rows : List Bits) (ids : List W) (prev : Bits),
    Grows (groupRows n nk rows ids prev)
  | [],_,_ => pure_grows _
  | _::xs,_,_ => bind_grows (groupCell_grows _ _ _ _ _ _)
    (fun p=>bind_grows (groupRows_grows n nk xs _ p.1) (fun _=>pure_grows _))

theorem maskStep_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    {ids prev : Bits} {r : Array Bool} {eq : W} {keep : Bool} {m : SymbolMask}
    (hr : RowRep v 26 ids r) (hp : RowRep v 7 prev (maskVec m)) (he : Rep v keep eq) :
    Gives T (maskStep 7 19 ids eq prev) (fun out=>RowRep v 7 out (maskVec (flagMask r keep m))) := by
  let step := fun i:Nat=>do
    let ca ← allGate [eq,prev[i]!]
    anyGate [ids[19+i]!,ca]
  have gm (i : Nat) : Grows (step i) := bind_grows (allGate_grows _) (fun _=>anyGate_grows _)
  have prep := mapArray_gives (f:=step) (T:=T) (Array.range 7) gm
    (R:=fun i x=>Rep v (maskVec (flagMask r keep m))[i]! x) (fun i hi=>by
      have bound : i<7 := by simpa using hi
      rw [flagMask_at r (hr.2.size.symm.trans hr.1) keep m i bound]
      exact bind_gives (m:=allGate [eq,prev[i]!]) (allGate_grows _) (fun _=>anyGate_grows _)
        (and2_gives law unit he (hp.2.get i (by rw [hp.1];exact bound)))
        (fun _ h=>or2_gives law unit (hr.2.get _ (by rw [hr.1];omega)) h))
  exact prep.imp (fun _ h=>from_indices _ 7 (maskVec_size _)
    (R:=fun x b=>Rep v b x) (by simpa using h))

theorem flag_neg {v : Nat → Bool} {x : W} {b : Bool} (h : Rep v b x) : Rep v (!b) (-x) :=
  ⟨neg_ne_zero.mpr h.1,by rw [wire_neg h.1,h.2]⟩

private theorem all_bits {v : Nat→Bool} {ids : List W} {bs : List Bool}
    (h : List.Forall₂ (fun x b=>Rep v b x) ids bs) :
    (∀x∈ids,x≠0) ∧ ids.all (wire v)=bs.all id := by
  induction h with
  | nil => simp
  | cons h _ ih =>
    exact ⟨by simpa using And.intro h.1 ih.1,by simp [h.2,ih.2]⟩

theorem allBits_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    {ids : List W} {bs : List Bool} (h : List.Forall₂ (fun x b=>Rep v b x) ids bs) :
    Gives T (allGate ids) (Rep v (bs.all id)) := by
  obtain ⟨nz,val⟩:=all_bits h
  rw [←val]
  exact lift_primitive law (all_quiet _) fun st=>allGate_realizes _ st v unit nz

private theorem mask_all (m : SymbolMask) : (maskVec m).toList.all id=decide (m=Finset.univ) := by
  apply Bool.eq_iff_iff.mpr
  simp [maskVec,Finset.eq_univ_iff_forall]
  constructor
  · intro h x
    fin_cases x <;> simp_all
  · intro h
    exact ⟨h 0,h 1,h 2,h 3,h 4,h 5,h 6⟩

private theorem head_at (r : Array Bool) (width : r.size=26) :
    r.toList.head?.getD true = r[0]! := by
  have bound : 0<r.size := by omega
  rw [List.head?_eq_getElem?,List.getElem?_eq_getElem (by simpa using bound),
    getElem!_pos r 0 bound]
  rfl

def emitsFlags (r : Array Bool) (m : SymbolMask) (last : Bool) : Bool×Bool :=
  if last then physicalFinish r m else (false,false)

def FlagRep (v : Nat → Bool) (ids : W×W) (bs : Bool×Bool) : Prop :=
  Rep v bs.1 ids.1 ∧ Rep v bs.2 ids.2

theorem groupCell_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    {ids prev : Bits} {r : Array Bool} {eq last : W} {keep final : Bool} {m : SymbolMask}
    (hr : RowRep v 26 ids r) (hp : RowRep v 7 prev (maskVec m))
    (he : Rep v keep eq) (hf : Rep v final last) :
    Gives T (groupCell 7 19 ids eq last prev) (fun out=>
      RowRep v 7 out.1 (maskVec (flagMask r keep m)) ∧ FlagRep v out.2 (emitsFlags r (flagMask r keep m) final)) := by
  unfold groupCell
  refine bind_gives (maskStep_grows _ _ _ _ _) (fun _=>bind_grows (allGate_grows _) (fun _=>
    bind_grows (allGate_grows _) (fun _=>pure_grows _))) (maskStep_gives law unit hr hp he) ?_
  intro cur hc
  have stop := and2_gives law unit (flag_neg (hr.2.get 0 (by rw [hr.1];decide))) hf
  refine bind_gives (allGate_grows _) (fun _=>bind_grows (allGate_grows _) (fun _=>pure_grows _)) stop ?_
  intro hit hh
  have done_ := allBits_gives law unit (List.Forall₂.cons hh hc.2)
  refine bind_gives (allGate_grows _) (fun _=>pure_grows _) done_ ?_
  intro doneId hd
  refine pure_gives ⟨hc,?_⟩
  have front := head_at r (hr.2.size.symm.trans hr.1)
  simp only [List.all_cons,id_eq,mask_all] at hd
  cases final <;> simpa [emitsFlags,physicalFinish,FlagRep,front,mask_all] using And.intro hh hd


def linkBits (rs : List (Array Bool)) : List Bool :=
  (rs.zip rs.tail).map fun p=>pk p.1 == pk p.2

@[simp] theorem linkBits_nil : linkBits []=[] := rfl
@[simp] theorem linkBits_one (r : Array Bool) : linkBits [r]=[] := rfl
@[simp] theorem linkBits_more (r s : Array Bool) (rs : List (Array Bool)) :
    linkBits (r::s::rs) = (pk r==pk s)::linkBits (s::rs) := rfl

private theorem emits_next (r : Array Bool) (m : SymbolMask) (b : Bool) :
    emitsFlags r m (!b) = (if b then (false,false) else physicalFinish r m) := by
  cases b <;> rfl

theorem runFlags_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    {tail : List Bits} {bs : List (Array Bool)} (rows : List.Forall₂ (RowRep v 26) tail bs) :
    ∀ {r : Array Bool} {ids prev : Bits} {rest : List W} {eq : W} {keep : Bool} {m : SymbolMask},
    RowRep v 26 ids r →
    List.Forall₂ (fun x b=>Rep v b x) rest (linkBits (r::bs)) →
    Rep v keep eq → RowRep v 7 prev (maskVec m) →
    Gives T (groupRows 7 19 (ids::tail) (eq::rest) prev)
      (fun out=>List.Forall₂ (FlagRep v) out (physicalRun r (flagMask r keep m) bs)) := by
  induction rows with
  | nil =>
    intro r ids prev rest eq keep m hr edges he hp
    cases edges
    unfold groupRows
    have cell := groupCell_gives law unit hr hp he (one_rep unit)
    refine bind_gives (groupCell_grows _ _ _ _ _ _) (fun _=>bind_grows (groupRows_grows _ _ _ _ _) (fun _=>pure_grows _)) cell ?_
    rintro ⟨mask,hit,doneId⟩ ⟨_,h⟩
    exact pure_gives (.cons h .nil)
  | @cons row s tail bs hrow _ ih =>
    intro r ids prev rest eq keep m hr edges he hp
    rw [linkBits_more] at edges
    cases edges with
    | @cons next _ rest _ hnext hrest =>
      unfold groupRows
      have cell := groupCell_gives law unit hr hp he (flag_neg hnext)
      refine bind_gives (groupCell_grows _ _ _ _ _ _) (fun _=>bind_grows (groupRows_grows _ _ _ _ _) (fun _=>pure_grows _)) cell ?_
      rintro ⟨mask,hit,doneId⟩ ⟨hm,hf⟩
      rw [emits_next] at hf
      have rec_ := ih hrow hrest hnext hm
      exact map_gives (m:=groupRows 7 19 (row::tail) (next::rest) mask) (f:=fun xs=>(hit,doneId)::xs)
        (groupRows_grows _ _ _ _ _) rec_ (fun _ hs=>List.Forall₂.cons hf hs)

private theorem mask_empty (v : Nat → Bool) (unit : v 0=true) :
    RowRep v 7 (Array.replicate 7 (-1)) (maskVec ∅) := by
  constructor
  · simp
  apply List.forall₂_of_length_eq_of_get (by simp [maskVec])
  intro i hi hj
  have ib : i<7 := by simpa using hi
  interval_cases i <;> exact zero_rep unit

theorem groupRows_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    {ids : List Bits} {bs : List (Array Bool)} {es : List W}
    (rows : List.Forall₂ (RowRep v 26) ids bs)
    (edges : List.Forall₂ (fun x b=>Rep v b x) es (linkBits bs)) :
    Gives T (groupRows 7 19 ids ((-1)::es) (Array.replicate 7 (-1)))
      (fun out=>List.Forall₂ (FlagRep v) out (physicalFlags bs)) := by
  cases rows with
  | nil => exact pure_gives .nil
  | @cons row r ids bs hr ht =>
    simpa [flagMask,physicalFlags] using
      (runFlags_gives law unit ht hr edges (zero_rep unit) (mask_empty v unit))


/-- Split the flag pairs into the two lists given to the threshold circuits. -/
theorem flagProjections {v : Nat→Bool} {ids : List (W×W)} {bs : List (Bool×Bool)}
    (h : List.Forall₂ (FlagRep v) ids bs) :
    List.Forall₂ (fun x b=>Rep v b x) (ids.map Prod.fst) (bs.map Prod.fst) ∧
    List.Forall₂ (fun x b=>Rep v b x) (ids.map Prod.snd) (bs.map Prod.snd) := by
  induction h with
  | nil => exact ⟨.nil,.nil⟩
  | cons h _ ih => exact ⟨.cons h.1 ih.1,.cons h.2 ih.2⟩

#print axioms groupRows_gives

end ExactWordFlow.CompactWordCircuit

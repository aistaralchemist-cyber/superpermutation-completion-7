import Cap35Census

namespace ExactWordFlow.Cap35Rigidity
open DirectedEuler ResidualDensity ResidualIncidence ResidualRoutes RotationComponentCount
open private select per_walk from RouteDensity

private theorem observations {s : Six} {es : List Six} (route : Route src dst s es s)
    (widths : ∀ e∈es, e.length=7) (positive : 0<es.length) :
    ∃ (u : ℕ → Six) (I : Finset ℕ), Walk u ∧
      CyclicMarked u (fun i => i%es.length∈I) es.length ∧
      count (fun i => i%es.length∈I) 0 es.length=classCount s es ∧ (∀j,u j∈s::es.map dst) := by
  classical
  obtain ⟨u,walk,h0,hk,eq⟩ := route_walk route widths
  let k := es.length
  have pos : 0<k := positive
  have endeq : u k=u 0 := hk.trans h0.symm
  have t : touched (positions u (k+1))=touched (positions u k) := by
    have first : u 0 ∈ positions u k :=
      List.mem_map.mpr ⟨0, List.mem_range.mpr pos,rfl⟩
    ext z
    simp only [touched,List.mem_toFinset,List.mem_map,List.mem_filter,decide_eq_true_eq,
      positions,List.range_succ,List.map_append,List.map_cons,List.map_nil,
      List.mem_append,List.mem_singleton] at *
    constructor
    · rintro ⟨x,⟨h|ex,ff⟩,id⟩
      · exact ⟨x,⟨h,ff⟩,id⟩
      · subst x
        exact ⟨u 0,⟨first,by simpa [endeq] using ff⟩,by simpa [endeq] using id⟩
    · rintro ⟨x,⟨h,ff⟩,id⟩; exact ⟨x,⟨Or.inl h,ff⟩,id⟩
  obtain ⟨I,hm,hc⟩ := select u k
  let p (i : Nat) := i%k ∈ I
  have cy : CyclicMarked (fun i => u (i%k)) p k := by
    refine ⟨fun i => by simp [p], fun i hi => hm.1 _ hi,?_⟩
    intro i j ij near pi pj eq
    have same : i%k=j%k := hm.2 _ _ pi pj eq
    exact le_antisymm ij (Nat.ModEq.le_of_lt_add (show j ≡ i [MOD k] from same.symm) near)
  have cc : count p 0 k=count (·∈I) 0 k := by
    unfold count
    congr 1
    ext j
    simp only [Finset.mem_filter,Finset.mem_range,Nat.zero_add,p]
    by_cases jj : j<k <;> simp [jj,Nat.mod_eq_of_lt]
  refine ⟨_,I,per_walk walk pos endeq,cy,?_,?_⟩
  · change count p 0 k=classCount s es
    rw [cc,hc,←t,eq]
    rfl
  · intro j
    rw [←eq]
    exact List.mem_map.mpr ⟨j%k,List.mem_range.mpr (by have := Nat.mod_lt j pos; change j%k<k+1; omega),rfl⟩
 

/-- The contact set computed on the actual residual route has exactly the
five-hop shape; marked occurrences in the proof are vertices of this very route. -/
theorem route_shape {v : Six} {es : List Six} (r : Route src dst v es v)
    (size : es.length=35) (width : ∀e∈es,e.length=7) (num : classCount v es=30) :
    ∃z,full z ∧ touched (v::es.map dst)=shape z := by
  classical
  obtain ⟨u,I,w,cy,marks,membership⟩:=observations r width (by omega)
  rw [size] at cy marks
  obtain ⟨b,hs,rows⟩:=spelling w cy (marks.trans num)
  refine ⟨u b,hs,Eq.symm (Finset.eq_of_subset_of_card_le ?_ ?_)⟩
  · intro t ht
    obtain ⟨k,hk,hw⟩:=Finset.mem_biUnion.mp ht
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hw)
    obtain ⟨good,ctx⟩:=rows k (Finset.mem_range.mp hk) j (List.mem_range.mp hj)
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨u (b+7*k+j),List.mem_filter.mpr
      ⟨membership _,decide_eq_true (cy.clean _ good)⟩,congrArg tag ctx⟩)
  · change classCount v es≤(shape (u b)).card
    rw [num,(ten _ hs).1]

open scoped Classical

/-- A closed component of 35 real residual edges meeting 30 rotation classes
has a rigid contact set and contains exactly ten complete wheel supports. -/
theorem actual_ten {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {q : Component X} (away:q≠label X s) (size:(part X q).card=35)
    (num:(contacts (support X s) (label X) q).card=30) :
    ∃z,full z ∧ contacts (support X s) (label X) q=shape z ∧
      (contained (contacts (support X s) (label X) q)).card=10 := by
  classical
  obtain ⟨v,_,key⟩:=residual_clean h away (by omega)
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance v
  rw [key] at bag lv ends
  obtain ⟨aa,bb⟩:=ends.2 away
  subst a; subst b
  have len:es.length=35:=(congrArg Multiset.card bag).trans size
  have width (x) (hx:x∈es):=h.edges_seven x (in_part.mp (bag ▸ (show x∈(↑es : Multiset Block) from hx))).1
  have sub:contacts (support X s) (label X) q⊆touched (v::es.map dst):=by
    intro c hc
    obtain ⟨u,hu,rfl⟩:=Finset.mem_image.mp hc
    obtain ⟨_,lu,clean⟩:=Finset.mem_filter.mp hu
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨u,List.mem_filter.mpr ⟨visits lv r bag lu,decide_eq_true clean⟩,rfl⟩)
  obtain ⟨u,I,w,cy,m⟩:=closed_observations r width (by omega)
  rw [len] at cy m
  have cap:=cyclic_7 w cy (by decide : 7≤35)
  have low:=Finset.card_le_card sub
  change (contacts (support X s) (label X) q).card≤classCount v es at low
  have count : classCount v es=30:=by omega
  obtain ⟨z,hz,shape'⟩:=route_shape r len width count
  have identical : contacts (support X s) (label X) q=touched (v::es.map dst):=
    Finset.eq_of_subset_of_card_le sub (by change classCount v es≤_; omega)
  exact ⟨z,hz,identical.trans shape',by rw [identical,shape']; exact (ten _ hz).2⟩

#print axioms actual_ten
end ExactWordFlow.Cap35Rigidity

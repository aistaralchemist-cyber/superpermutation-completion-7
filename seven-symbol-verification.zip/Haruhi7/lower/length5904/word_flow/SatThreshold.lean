import Mathlib.Tactic

namespace ExactWordFlow.SatThreshold

/-- Binary numbers used by the compiler are little-endian. -/
def value : List Bool → Nat
  | [] => 0
  | x::xs => x.toNat + 2*value xs

/-- The two output bits of the compiler's XOR/MUX full adder. -/
def bit (a b carry : Bool) := (a ^^ b) ^^ carry
def carryOut (a b carry : Bool) := if a ^^ b then carry else a

theorem full_adder (a b c : Bool) :
    (bit a b c).toNat + 2*(carryOut a b c).toNat = a.toNat + b.toNat + c.toNat := by
  cases a <;> cases b <;> cases c <;> decide

def add : List Bool → List Bool → Bool → List Bool
  | [], [], c => [c]
  | a::as, [], c => bit a false c :: add as [] (carryOut a false c)
  | [], b::bs, c => bit false b c :: add [] bs (carryOut false b c)
  | a::as, b::bs, c => bit a b c :: add as bs (carryOut a b c)

theorem add_value (as bs : List Bool) (c : Bool) :
    value (add as bs c) = value as + value bs + c.toNat := by
  induction as, bs, c using add.induct with
  | case1 => simp [add,value]
  | case2 a as c ih =>
    simp only [add,value,ih]
    have h:=full_adder a false c
    simp only [Bool.toNat_false,Nat.add_zero] at h
    omega
  | case3 b bs c ih =>
    simp only [add,value,ih]
    have h:=full_adder false b c
    simp only [Bool.toNat_false,Nat.zero_add] at h
    omega
  | case4 a as b bs c ih =>
    simp only [add,value,ih]
    have h:=full_adder a b c
    omega

def pairs : List (List Bool) → List (List Bool)
  | a::b::rest => add a b false :: pairs rest
  | xs => xs

private theorem pairs_length (ls : List (List Bool)) : (pairs ls).length ≤ ls.length := by
  induction ls using pairs.induct with
  | case1 a b ls ih => simp only [pairs,List.length_cons]; omega
  | case2 => simp [pairs]

private theorem pairs_value (ls : List (List Bool)) :
    ((pairs ls).map value).sum = (ls.map value).sum := by
  induction ls using pairs.induct with
  | case1 a b ls ih => simp [pairs,add_value,ih,Nat.add_assoc]
  | case2 => simp [pairs]

def reduce : List (List Bool) → List Bool
  | [] => []
  | [a] => a
  | a::b::rest => reduce (add a b false :: pairs rest)
termination_by xs => xs.length
decreasing_by simp only [List.length_cons]; have := pairs_length rest; omega

theorem reduce_value (ls : List (List Bool)) : value (reduce ls) = (ls.map value).sum := by
  induction ls using reduce.induct with
  | case1 => simp [reduce,value]
  | case2 a => simp [reduce]
  | case3 a b rest ih =>
    rw [reduce,ih]
    simp [add_value,pairs_value,Nat.add_assoc]

/-- Discarding the bits of the bound beyond the end of the data implements
the Python guard required >= 2^len(bits). The initial carry is true for >=. -/
def compareBits : List Bool → Nat → Bool → Bool
  | [], k, ge => decide (k=0) && ge
  | a::xs, k, ge =>
    compareBits xs (k/2) (if k%2=1 then a && ge else a || ge)

theorem compareBits_iff (xs : List Bool) (k : Nat) (ge : Bool) :
    compareBits xs k ge = true ↔ k < value xs ∨ (k = value xs ∧ ge = true) := by
  induction xs generalizing k ge with
  | nil => simp [compareBits,value]
  | cons a as ih =>
    rw [compareBits,ih]
    cases a <;> cases ge <;> by_cases h:k%2=1 <;> simp [h,value] <;> omega

def geCount (flags : List Bool) (k : Nat) : Bool :=
  compareBits (reduce (flags.map fun f => [f])) k true

theorem geCount_iff (flags : List Bool) (k : Nat) :
    geCount flags k = true ↔ k ≤ flags.count true := by
  rw [geCount,compareBits_iff,reduce_value]
  have h : ((flags.map fun f=>[f]).map value).sum = flags.count true := by
    induction flags with
    | nil => rfl
    | cons a rest ih => cases a <;> simp_all [value,Nat.add_comm]
  rw [h]
  simp only [and_true]
  omega

#print axioms geCount_iff
end ExactWordFlow.SatThreshold

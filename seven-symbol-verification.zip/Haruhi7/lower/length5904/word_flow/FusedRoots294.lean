import ShortMarked
import NoRoot265
import NoNearHundred
import Std.Data.HashSet.Lemmas

namespace ExactWordFlow.FusedRoots294
open SevenWordWindows ResidualDensity ResidualIncidence RotationComponentCount DirectedEuler
open WeightedMarks MarkedGeometry ExtremalRealizations ShortMarked
open private prefixes initial start move memoryWord accepted from MarkedDensity
open private upper_read upper_step from ShortMarked
open private canonical encode map_tag from Interval66
open private mask_cons from StrongerDensity

private def win (n st : Nat) (b : Bool) : Bool :=
  let j:=move st b
  j<prefixes.size && b.toNat+upper n j==upper (n+1) st

private inductive Accepted : Nat → List Bool → Prop
  | nil (st) : Accepted st []
  | cons {st b bs} (edge : win bs.length st b=true) (tail : Accepted (move st b) bs) :
      Accepted st (b::bs)

/-- Bellman's equality propagates along any word attaining the upper bound. -/
private theorem max_accept (pre bs : List Bool) (st : Nat) (ok : st<prefixes.size)
    (small : bs.length≤478) (suff : memoryWord st <:+ pre)
    (allowed : ∀x∈forbidden, ¬x <:+: pre++bs) (maximal : upper bs.length st≤bs.count true) :
    Accepted st bs := by
  induction bs generalizing st pre with
  | nil => exact .nil _
  | cons b bs ih =>
    obtain ⟨inside,suffix,_⟩:=accepted st b pre bs ok suff allowed
    have sz : bs.length<478 := by simpa using small
    have rest : ∀x∈forbidden, ¬x <:+: (pre++[b])++bs := by simpa using allowed
    have tail := upper_read _ _ _ inside (by omega) suffix rest
    have price:=upper_step ⟨bs.length,sz⟩ ⟨st,ok⟩ b inside
    change b.toNat+upper bs.length (move st b)≤upper (bs.length+1) st at price
    have count_eq : (b::bs).count true=b.toNat+bs.count true := by cases b <;> simp [Nat.add_comm]
    simp only [List.length_cons,count_eq] at maximal
    exact .cons (by simp only [win,Bool.and_eq_true,decide_eq_true_eq,beq_iff_eq]; exact ⟨inside,by omega⟩)
      (ih _ _ inside (by omega) suffix rest (by omega))

private abbrev Visited := Std.HashSet Six

/-- A hash set already has distinct keys, so the leaf operation needs no second deduplication. -/
private def footprint (v : Visited) : Finset Six :=
  ⟨v.toList,Multiset.coe_nodup.mpr (v.distinct_toList.imp (fun {a b} h eq=>by simpa [eq] using h))⟩

private theorem mem_foot {v : Visited} {z : Six} : z∈footprint v ↔ z∈v :=
  by change z∈v.toList ↔ z∈v; exact Std.HashSet.mem_toList

private theorem add_foot (v : Visited) (z : Six) :
    footprint (v.insert z)=insert z (footprint v) := by
  ext a
  simp only [mem_foot,Finset.mem_insert,Std.HashSet.mem_insert,beq_iff_eq]
  exact or_congr eq_comm Iff.rfl

private def nextContexts (b c : Bool) (x : Six) : List Six :=
  if b && c then [x.rotate 1] else (List.finRange 7).map (step x)

private theorem next_mem {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : Nat) : u (i+1)∈nextContexts (decide (p i)) (decide (p (i+1))) (u i) := by
  obtain ⟨a,ha⟩:=w i
  by_cases curr : p i ∧ p (i+1)
  · rw [nextContexts,ite_eq_left (by simp [curr.1,curr.2]),List.mem_singleton]
    refine ha.trans (next_unique _ a (m.1 _ curr.1) (ha ▸ m.1 _ curr.2) ?_)
    intro eq
    have no:=m.2 _ _ curr.1 curr.2 (eq.trans (congrArg tag ha).symm)
    omega
  · have off : ¬(decide (p i) && decide (p (i+1)))=true := by simpa using curr
    rw [nextContexts,ite_eq_right off]
    exact List.mem_map.mpr ⟨a,List.mem_finRange _,ha.symm⟩

private def usable (b : Bool) (x : Six) (v : Visited) : Bool :=
  !b || (decide (full x) && !v.contains (tag x))

private def add (b : Bool) (x : Six) (v : Visited) : Visited :=
  if b then v.insert (tag x) else v

/-- With the bit at the current position already chosen, intersect the DP-optimal
next bits with their actual six-context successors before recursing. -/
private def dfs (accept : Finset Six→Bool) : Nat → Nat → Bool → Six → Visited → Bool
  | 0,st,b,x,v => if win 0 st b && usable b x v then accept (footprint (add b x v)) else true
  | n+1,st,b,x,v => if win (n+1) st b && usable b x v then
      let st' := move st b
      let v' := add b x v
      [false,true].all (fun c=> !(win n st' c) ||
        (nextContexts b c x).all (fun y=>dfs accept n st' c y v'))
    else true

private def checkFrom (accept : Finset Six→Bool) (x : Six) : Bool :=
  dfs accept 294 initial true x {}

def checkAt (accept : Finset Six→Bool) (i : Nat) := checkFrom accept (canonical[i]?.getD [])
def check (accept : Finset Six→Bool) : Bool := canonical.all (checkFrom accept)

private theorem usable_now {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (m : Marked u p) (i : Nat) (v : Visited)
    (past : ∀z∈v,∃k < i,p k ∧ tag (u k)=z) : usable (decide (p i)) (u i) v=true := by
  by_cases now : p i
  · have absent : (tag (u i))∉v := by
      intro old
      obtain ⟨k,lt,pk,eq⟩:=past _ old
      have :=m.2 _ _ pk now eq
      omega
    simp [usable,now,m.1 _ now,show v.contains (tag (u i))=false from
      Bool.eq_false_iff.mpr (fun h=>absent (Std.HashSet.contains_iff_mem.mp h))]
  · simp [usable,now]

private theorem past_next {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (i : Nat) (v : Visited) (past : ∀z∈v,∃k < i,p k ∧ tag (u k)=z) :
    ∀z∈add (decide (p i)) (u i) v,∃k < i+1,p k ∧ tag (u k)=z := by
  intro z hz
  by_cases now : p i
  · simp only [add,decide_eq_true now,ite_true,Std.HashSet.mem_insert,beq_iff_eq] at hz
    rcases hz with yes|old
    · exact ⟨i,by omega,now,yes⟩
    · obtain ⟨k,lt,pk,eq⟩:=past _ old
      exact ⟨k,by omega,pk,eq⟩
  · simp [add,now] at hz
    obtain ⟨k,lt,pk,eq⟩:=past _ hz
    exact ⟨k,by omega,pk,eq⟩

private theorem shift_foot (u : Nat→Six) (i : Nat) (b : Bool) (bs : List Bool) (v : Visited) :
    (selectedTags u i (b::bs)).toFinset ∪ footprint v =
      (selectedTags u (i+1) bs).toFinset ∪ footprint (add b (u i) v) := by
  cases b <;> simp [selectedTags,add,add_foot]

private theorem dfs_sound (accept : Finset Six→Bool) {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (w : Walk u) (m : Marked u p) (n st i : Nat) (v : Visited)
    (past : ∀z∈v,∃k < i,p k ∧ tag (u k)=z)
    (path : Accepted st (mask p i (n+1)))
    (passed : dfs accept n st (decide (p i)) (u i) v=true) :
    accept ((selectedTags u i (mask p i (n+1))).toFinset ∪ footprint v)=true := by
  induction n generalizing st i v with
  | zero =>
    rw [mask_cons] at path ⊢
    cases path with
    | cons edge _ =>
      have edge0 : win 0 st (decide (p i))=true := by simpa [mask] using edge
      rw [dfs,edge0,usable_now m i v past] at passed
      rw [shift_foot]
      simpa [mask,selectedTags] using passed
  | succ n ih =>
    rw [mask_cons] at path ⊢
    cases path with
    | cons edge tail =>
      have edge1 : win (n+1) st (decide (p i))=true := by simpa [mask] using edge
      rw [dfs,edge1,usable_now m i v past] at passed
      let b:=decide (p i)
      let c:=decide (p (i+1))
      change [false,true].all _=true at passed
      have pc:=List.all_eq_true.mp passed c (by cases c <;> simp)
      have after : win n (move st b) c=true := by
        rw [mask_cons] at tail
        cases tail with
        | cons ok _ => simpa [mask,b,c] using ok
      change (!(win n (move st b) c) || (nextContexts b c (u i)).all
        (fun y=>dfs accept n (move st b) c y (add b (u i) v)))=true at pc
      simp only [after,Bool.not_true,Bool.false_or] at pc
      have child:=List.all_eq_true.mp pc _ (next_mem w m i)
      rw [shift_foot]
      exact ih _ _ _ (past_next i v past) tail child

private def startCheck : Bool := (upper 295 initial == 250) && !(win 294 initial false)
private theorem startData : startCheck=true := by native_decide

private theorem accepted_start {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i : Nat) (many : 250≤count p i 295) :
    p i ∧ Accepted initial (mask p i 295) := by
  obtain ⟨size,bad⟩:=Bool.and_eq_true_iff.mp startData
  have cap : upper 295 initial=250 := eq_of_beq size
  let bs := mask p i 295
  have width : bs.length=295 := by simp [bs,mask]
  have maximal : upper bs.length initial≤bs.count true := by rw [width,cap,mark_count]; exact many
  have read:=max_accept [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i 295) maximal
  refine ⟨?_,read⟩
  by_contra fail
  change Accepted initial (mask p i (294+1)) at read
  rw [mask_cons] at read
  cases read with
  | cons edge _ =>
    have yes : win 294 initial false=true := by simpa [mask,fail] using edge
    simp only [yes,Bool.not_true,Bool.false_eq_true] at bad

private theorem selected_accept (accept : Finset Six→Bool) (checks : check accept=true)
    {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : Nat) (many : 250≤count p i 295) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      accept ((selectedTags u i (mask p i 295)).toFinset.image (List.map f))=true := by
  obtain ⟨first,read⟩:=accepted_start w m i many
  let f:=encode (u i)
  have ck : states.all (fun s=>decide (Function.Injective (encode s) ∧ encode s 0=0 ∧
    s.map (encode s)∈canonical))=true := by native_decide
  obtain ⟨inj,z,can⟩:=of_decide_eq_true (List.all_eq_true.mp ck _ (mem_states (m.1 i first)))
  let v (k : Nat):=(u k).map f
  have walk : Walk v := by
    intro j
    obtain ⟨a,eq⟩:=w j
    exact ⟨f a,by simp [v,eq,step,List.map_tail]⟩
  have markv : Marked v p := by
    refine ⟨fun j hj=>⟨by simp [v,(m.1 j hj).1],(m.1 j hj).2.map inj⟩,?_⟩
    intro j k hj hk eq
    apply m.2 j k hj hk
    change tag ((u j).map f)=tag ((u k).map f) at eq
    rw [map_tag f inj z _ (m.1 j hj),map_tag f inj z _ (m.1 k hk)] at eq
    exact List.map_injective_iff.mpr inj eq
  have imageEq : (selectedTags u i (mask p i 295)).toFinset.image (List.map f)=
      (selectedTags v i (mask p i 295)).toFinset := by
    ext c
    simp only [Finset.mem_image,List.mem_toFinset,mem_marked]
    constructor
    · rintro ⟨a,⟨j,hj,hp,rfl⟩,rfl⟩
      exact ⟨j,hj,hp,map_tag f inj z _ (m.1 _ hp)⟩
    · rintro ⟨j,hj,hp,rfl⟩
      exact ⟨tag (u (i+j)),⟨j,hj,hp,rfl⟩,(map_tag f inj z _ (m.1 _ hp)).symm⟩

  have passed:=List.all_eq_true.mp checks _ can
  have eval : dfs accept 294 initial (decide (p i)) (v i) {}=true := by
    simpa only [checkFrom,decide_eq_true first] using passed
  have cert:=dfs_sound accept walk markv 294 initial i {} (by simp) read eval
  have emptyFoot : footprint {}=∅ := by ext x; simp [mem_foot]
  rw [emptyFoot,Finset.union_empty] at cert
  exact ⟨f,inj.bijective_of_finite,z,imageEq ▸ cert⟩

open private select from RouteDensity

/-- Literal reachability of a root footprint; the normalization is a single
alphabet bijection fixing zero, as required for transport of the wheel cover. -/
theorem route_coverage (accept : Finset Six→Bool) (checks : check accept=true)
    {a b : Six} {es : List Six} (r : Route src dst a es b) (width : ∀e∈es,e.length=7)
    (length : es.length+1=295) (many : 250≤classCount a es) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      accept ((touched (a::es.map dst)).image (List.map f))=true := by
  classical
  obtain ⟨u,walk,_,_,eq⟩:=route_walk r width
  rw [length] at eq
  obtain ⟨I,marks,card⟩:=select u 295
  rw [eq] at card
  have sufficient : 250≤count (·∈I) 0 295 := by rw [card]; exact many
  obtain ⟨f,bij,z,contains⟩:=selected_accept accept checks walk marks 0 sufficient
  let J := (Finset.range 295).filter fun j=>j∈I
  have matchSet : (selectedTags u 0 (mask (·∈I) 0 295)).toFinset=J.image (tag ∘ u) := by
    ext c
    simp only [List.mem_toFinset,mem_marked,Nat.zero_add,Finset.mem_image,J,
      Finset.mem_filter,Finset.mem_range,Function.comp_apply]
    grind
  have subset : J.image (tag ∘ u)⊆touched (a::es.map dst) := by
    intro c hc
    obtain ⟨j,hj,rfl⟩:=Finset.mem_image.mp hc
    obtain ⟨hj,marked⟩:=Finset.mem_filter.mp hj
    change tag (u j)∈touched _
    rw [←eq]
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨u j,List.mem_filter.mpr
      ⟨List.mem_map.mpr ⟨j,Finset.mem_range.mp hj |> List.mem_range.mpr,rfl⟩,decide_eq_true (marks.1 _ marked)⟩,rfl⟩)
  have injective : Set.InjOn (tag ∘ u) J := by
    intro j hj k hk same
    exact marks.2 j k (Finset.mem_filter.mp hj).2 (Finset.mem_filter.mp hk).2 same
  have equal : J.image (tag ∘ u)=touched (a::es.map dst) := by
    apply Finset.eq_of_subset_of_card_le subset
    rw [Finset.card_image_of_injOn injective,←card]
    simp [J,count]
  exact ⟨f,bij,z,by rwa [matchSet,equal] at contains⟩


open RotationCore ExtremeWheelCut SuperpermutationBounds
open private partition wheel_list from HundredDecomposition
open private hits from NearHundredShape
open ResidualRoutes

theorem cover_certificate (accept : Finset Six→Bool) (checks : check accept=true)
    {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (card : (occupied X s).card=94) :
    ∃R, accept R=true ∧ ∃W⊆allRows, W.card≤94 ∧ SeedWheelCut.ClosedCover R allClasses W := by
  classical
  obtain ⟨_,root,colors,every⟩:=NoRoot265.shape h budget card
  obtain ⟨a,b,es,bag,r,eq,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len : es.length=(part X (label X s)).card:=congrArg Multiset.card bag
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have cover : hits X s (label X s)≤classCount s es:=contacts_bound _ eq r bag
  obtain ⟨ws,num,legal,_,packet⟩:=wheel_list (occupied X s) (fun q hq=>MarkedLargeCap.six_component h (Finset.mem_erase.mp hq).1 (every q hq))
  have split:=partition X s
  rw [←bag,←packet] at split
  have fullW (v) (hv : v∈ws) := (legal v hv).1
  have length : es.length+1=295 := by omega
  have count : 250≤classCount s es := by omega
  obtain ⟨f,bij,zero,norm⟩:=route_coverage accept checks r wd length count
  have closed:=WheelRelabel.transport_closed fullW (HundredDecomposition.closed_cover h r fullW split) f bij.1 zero
  let vs:=ws.map (List.map f)
  have legal : vs.toFinset.image WheelContacts.wheel⊆allRows := by
    intro row hr
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hr
    obtain ⟨x,old,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hv)
    have fullX:=fullW x old
    have fullV : full (x.map f) := ⟨by simpa using fullX.1,fullX.2.map bij.1⟩
    obtain ⟨base,admissible,rows⟩:=WheelContacts.complete fullV
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨base,admissible,rows⟩)
  exact ⟨_,norm,_,legal,Finset.card_image_le.trans ((List.toFinset_card_le vs).trans
    (by simpa [vs] using (num.trans card).le)),closed⟩

#print axioms route_coverage
#print axioms cover_certificate
end ExactWordFlow.FusedRoots294

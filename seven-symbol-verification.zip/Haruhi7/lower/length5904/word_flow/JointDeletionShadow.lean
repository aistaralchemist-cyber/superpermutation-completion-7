import DeletionShadow

namespace ExactWordFlow.DeletionShadow
open SevenWordWindows RotationCore
open private capacityOn from DeletionShadow

private def row (w : Block) (a : Fin 7) :=
  let words:=sixWindows (erase a w)
  ((board6 a).sort (· ≤ ·)).map fun d=>(d,capacityOn words d)

private def lookupPos (a : Fin 7) (c : Block) (table : List (Block×Nat)) :=
  let d:=proj a c
  table.any fun (e,n)=>e==d && 0<n

private theorem pos_iff (a : Fin 7) (w c : Block) (hc : c∈allClasses) :
    lookupPos a c (row w a)=true ↔ 0<capacity a w (proj a c) := by
  simp only [lookupPos,row,List.any_eq_true,List.mem_map,Finset.mem_sort,Bool.and_eq_true,beq_iff_eq,decide_eq_true_eq]
  constructor
  · rintro ⟨_,⟨d,_,rfl⟩,rfl,n⟩
    exact n
  · intro yes
    exact ⟨_,⟨_,Finset.mem_image_of_mem _ hc,rfl⟩,rfl,yes⟩

/-- The simultaneous positivity filter reuses all 840 projected capacities. -/
def pool (w : Block) : Finset Block :=
  let tabs:=Vector.ofFn (row w)
  allClasses.filter fun c=>(List.finRange 7).all fun a=>lookupPos a c (tabs.get a)

theorem pool_eq (w : Block) : pool w=eligible w := by
  ext c
  simp only [pool,eligible,Finset.mem_filter,List.all_eq_true,Vector.get_ofFn,List.mem_finRange,
    forall_const]
  constructor
  · rintro ⟨hc,p⟩
    exact ⟨hc,fun a=>(pos_iff a w c hc).mp (p a)⟩
  · rintro ⟨hc,p⟩
    exact ⟨hc,fun a=>(pos_iff a w c hc).mpr (p a)⟩

private def thinned (w : Block) (P : Finset Block) (a : Fin 7) : Nat :=
  let words:=sixWindows (erase a w)
  ∑d∈board6 a,min (capacityOn words d) ((P.filter (fun c=>proj a c=d)).card)

def jointUpper (a : Fin 7) (w : Block) := thinned w (pool w) a

theorem joint_bound (a : Fin 7) (w : Block) : (complete w).card≤jointUpper a w := by
  have member {c} (hc:c∈complete w) : proj a c∈board6 a:=
    Finset.mem_image_of_mem _ ((mem_complete _ _).mp hc).1
  rw [Finset.card_eq_sum_card_fiberwise (f:=proj a) (t:=board6 a) (fun _ h=>member h)]
  apply Finset.sum_le_sum
  intro d hd
  apply le_min (load_bound a w d hd)
  rw [pool_eq]
  exact Finset.card_le_card (Finset.filter_subset_filter _ (within_eligible w))

def jointVector (w : Block) :=
  let P:=pool w
  (List.finRange 7).map (thinned w P)

#print axioms joint_bound
end ExactWordFlow.DeletionShadow

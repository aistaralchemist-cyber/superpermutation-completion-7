import Interval66

namespace ResidualDensity.ExtremalRealizations
open SevenWordWindows
open private canonical encode map_tag from Interval66
open private row_rigid from Geometry40
open private unmask mask_cons from StrongerDensity

/-- All sets of tags reachable by spelling the chosen marked rows. Every
single gap following a marked row uses two appended letters. An empty
row records an additional unmarked context and uses one further letter.
A leaf returns the full set accumulated along its root-to-leaf path. -/
private def rowSets : List Nat → Six → List Six → List (Finset Six)
  | [], _, seen => [seen.toFinset]
  | n::ns, s, seen =>
    if n=0 then
      if ns.isEmpty then [seen.toFinset]
      else (List.finRange 7).flatMap fun a=>rowSets ns (step s a) seen
    else
    let hits := rowTags s n
    if full s && hits.all (fun z => decide (z∉seen)) then
      if ns.isEmpty then [(hits++seen).toFinset]
      else (List.finRange 7).flatMap fun a => (List.finRange 7).flatMap fun b =>
        rowSets ns (step (step (s.rotate (n-1)) a) b) (hits++seen)
    else []

def realizations (profiles : List (List Nat)) : List (Finset Six) :=
  profiles.flatMap fun ns => canonical.flatMap fun s => rowSets ns s []

/-- Read only the marked tags of the given mask, in their original order. -/
def selectedTags (u : ℕ→Six) (i : Nat) : List Bool → List Six
  | [] => []
  | b::xs => (if b then [tag (u i)] else [])++selectedTags u (i+1) xs

theorem mem_marked {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (i n : Nat) (z : Six) :
    z∈selectedTags u i (mask p i n) ↔ ∃j<n, p (i+j) ∧ tag (u (i+j))=z := by
  induction n generalizing i with
  | zero => simp [mask,selectedTags]
  | succ n ih =>
    rw [mask_cons,selectedTags,List.mem_append,ih]
    constructor
    · rintro (first|⟨j,hj,mark,eq⟩)
      · by_cases now : p i
        · exact ⟨0,by omega,by simpa using now,by simpa [now,eq_comm] using first⟩
        · simp [now] at first
      · exact ⟨j+1,by omega,by simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using mark,
          by simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using eq⟩
    · rintro ⟨j,hj,mark,eq⟩
      cases j with
      | zero => left; simp only [Nat.add_zero] at mark eq; simp [mark,eq]
      | succ j =>
        right
        exact ⟨j,by omega,by simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using mark,
          by simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using eq⟩

private theorem select_append (u : ℕ→Six) (i : Nat) (a b : List Bool) :
    selectedTags u i (a++b)=selectedTags u i a ++ selectedTags u (i+a.length) b := by
  induction a generalizing i with
  | nil => simp [selectedTags]
  | cons x a ih =>
    simp only [List.cons_append,selectedTags,ih,List.length_cons,List.append_assoc]
    rw [show i+1+a.length=i+(a.length+1) by omega]

private theorem select_row (u : ℕ→Six) (i n : Nat) :
    selectedTags u i (List.replicate n true)=(List.range n).map (fun j=>tag (u (i+j))) := by
  induction n generalizing i with
  | zero => simp [selectedTags]
  | succ n ih =>
    rw [List.replicate_succ,List.range_succ_eq_map,selectedTags,ih]
    simp only [List.map_cons,List.map_map,Nat.add_zero,ite_true,List.singleton_append]
    congr 1
    apply List.map_congr_left
    intro j _
    simp [Nat.add_comm,Nat.add_left_comm]

private theorem complete {u : ℕ→Six} {p : ℕ→Prop} (w : Walk u) (m : Marked u p)
    (ns : List Nat) (i : Nat) (hm : rowsMarked p i ns)
    (seen : List Six) (past : ∀z∈seen,∃k < i,p k ∧ tag (u k)=z) :
    (selectedTags u i (rowsMask ns)).toFinset ∪ seen.toFinset ∈ rowSets ns (u i) seen := by
  induction ns generalizing i seen with
  | nil => simp [rowsMask,selectedTags,rowSets]
  | cons n ns ih =>
    obtain ⟨now,later⟩:=hm
    by_cases empty : n=0
    · subst n
      cases ns with
      | nil => simp [rowsMask,selectedTags,rowSets]
      | cons n ns =>
        obtain ⟨a,next⟩:=w i
        have tail:=ih (i+1) (by simpa using later) seen (fun z hz=>by
          obtain ⟨k,hk,pk,key⟩:=past z hz
          exact ⟨k,by omega,pk,key⟩)
        rw [rowSets]
        simp only [ite_true,List.isEmpty_cons,Bool.false_eq_true,ite_false,List.mem_flatMap]
        refine ⟨a,List.mem_finRange _,?_⟩
        rw [←next]
        simpa only [rowsMask,List.replicate_zero,List.nil_append,List.isEmpty_cons,Bool.false_eq_true,
          ite_false,selectedTags] using tail
    have positive : 0<n := by omega
    have fulli:=m.1 i (by simpa using now 0 positive)
    have hits : (List.range n).map (fun j=>tag (u (i+j)))=rowTags (u i) n := by
      apply List.map_congr_left
      intro j hj
      rw [row_rigid w m i j (fun d hd=>now d (by have:=List.mem_range.mp hj; omega))]
    have times (z) (hz : z∈rowTags (u i) n) : ∃ j<n, tag (u (i+j))=z := by
      rw [←hits] at hz
      obtain ⟨j,hj,eq⟩:=List.mem_map.mp hz
      exact ⟨j,List.mem_range.mp hj,eq⟩
    have dis : (rowTags (u i) n).all (fun z=>decide (z∉seen))=true := by
      apply List.all_eq_true.mpr
      intro z hz
      apply decide_eq_true
      intro used
      obtain ⟨j,hj,eq⟩:=times z hz
      obtain ⟨k,hk,pk,earlier⟩:=past z used
      have := m.2 _ _ (now j hj) pk (eq.trans earlier.symm)
      omega
    rw [rowSets,ite_eq_right empty]
    simp only [decide_eq_true fulli,dis,Bool.true_and,ite_true]
    cases ns with
    | nil => simp [rowsMask,select_row,hits,List.toFinset_append]
    | cons r rest =>
      obtain ⟨a,ha⟩:=w (i+(n-1))
      obtain ⟨b,hb⟩:=w (i+n)
      have last:=row_rigid w m i (n-1) (fun j hj=>now j (by omega))
      have eq : u (i+n+1)=step (step ((u i).rotate (n-1)) a) b := by
        rw [←last,←ha,show i+(n-1)+1=i+n by omega,←hb]
      have early (z) (hz : z∈rowTags (u i) n++seen) : ∃k < i+n+1,p k ∧ tag (u k)=z := by
        rcases List.mem_append.mp hz with hit|old
        · obtain ⟨j,hj,key⟩:=times z hit
          exact ⟨i+j,by omega,now j hj,key⟩
        · obtain ⟨k,hk,pk,key⟩:=past z old
          exact ⟨k,by omega,pk,key⟩
      have tail:=ih _ later _ early
      simp only [List.isEmpty_cons,Bool.false_eq_true,ite_false,List.mem_flatMap]
      refine ⟨a,List.mem_finRange _,b,List.mem_finRange _,?_⟩
      rw [←eq]
      simpa only [rowsMask,select_append,select_row,hits,List.isEmpty_cons,Bool.false_eq_true,
        ite_false,List.length_replicate,selectedTags,List.nil_append,List.toFinset_append,
        Finset.union_assoc,Finset.union_comm,Finset.union_left_comm] using tail

/-- Any extremal actual walk has, after one alphabet bijection fixing 0,
precisely one of the enumerated marked class sets. Unmarked states and other
occurrences of the same class need not be first visits. -/
theorem coverage {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i n : Nat) (profiles : List (List Nat)) {ns : List Nat} (inside : ns∈profiles)
    (nonempty : ns≠[]) (first : 0<ns.head!) (maskEq : mask p i n=rowsMask ns) :
    ∃f : Fin 7 → Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ((selectedTags u i (mask p i n)).toFinset.image (List.map f))∈realizations profiles := by
  have marks:=unmask i n ns maskEq
  have start : p i := by cases ns with
                        | nil => exact (nonempty rfl).elim
                        | cons n tail => simpa using marks.1 0 (by simpa using first)
  let f:=encode (u i)
  have ck : states.all (fun s=>decide (Function.Injective (encode s) ∧ encode s 0=0 ∧
    s.map (encode s)∈canonical))=true := by native_decide
  obtain ⟨inj,z,can⟩:=of_decide_eq_true (List.all_eq_true.mp ck _ (mem_states (m.1 i start)))
  let v (k : Nat):=(u k).map f
  have walk : Walk v := by
    intro j
    obtain ⟨a,eq⟩:=w j
    exact ⟨f a,by simp [v,eq,step,List.map_tail]⟩
  have markv : Marked v p := by
    refine ⟨fun j hj=>⟨by simp [v,(m.1 j hj).1],(m.1 j hj).2.map inj⟩,?_⟩
    intro j k hj hk eq
    apply m.2 j k hj hk
    change tag ((u j).map f)=tag ((u k).map f) at eq
    rw [map_tag f inj z _ (m.1 j hj),map_tag f inj z _ (m.1 k hk)] at eq
    exact List.map_injective_iff.mpr inj eq
  have sets := complete walk markv ns i marks [] (by simp)
  have imageEq : (selectedTags u i (mask p i n)).toFinset.image (List.map f)=
      (selectedTags v i (mask p i n)).toFinset := by
    ext c
    simp only [Finset.mem_image,List.mem_toFinset,mem_marked]
    constructor
    · rintro ⟨a,⟨j,hj,hp,rfl⟩,rfl⟩
      exact ⟨j,hj,hp,map_tag f inj z _ (m.1 _ hp)⟩
    · rintro ⟨j,hj,hp,rfl⟩
      exact ⟨tag (u (i+j)),⟨j,hj,hp,rfl⟩,(map_tag f inj z _ (m.1 _ hp)).symm⟩
  refine ⟨f,inj.bijective_of_finite,z,?_⟩
  rw [imageEq,maskEq]
  exact List.mem_flatMap.mpr ⟨ns,inside,List.mem_flatMap.mpr ⟨v i,can,by simpa using sets⟩⟩

open ExactWordFlow DirectedEuler
open private select from RouteDensity

/-- The combinatorial mark selector and the actual tag set of an Euler
path agree on every class, so saturation can be used at the set level. -/
theorem route_coverage_at {goal n : Nat} {a b : Six} {es : List Six}
    (r : Route src dst a es b) (width : ∀e∈es,e.length=7) (length : es.length+1=n)
    (many : goal≤classCount a es) (profiles : List (List Nat))
    (profile : ∀ (v : ℕ→Six) (I : Finset ℕ), Walk v → Marked v (·∈I) → goal≤count (·∈I) 0 n →
      ∃ns∈profiles, ns≠[] ∧ 0<ns.head! ∧ mask (·∈I) 0 n=rowsMask ns) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ((touched (a::es.map dst)).image (List.map f))∈realizations profiles := by
  classical
  obtain ⟨u,walk,_,_,eq⟩:=route_walk r width
  rw [length] at eq
  obtain ⟨I,marks,card⟩:=select u n
  rw [eq] at card
  have sufficient : goal≤count (·∈I) 0 n := by rw [card]; exact many
  obtain ⟨ns,legit,nonempty,pos,spec⟩:=profile u I walk marks sufficient
  obtain ⟨f,bij,z,contains⟩:=coverage walk marks 0 n profiles legit nonempty pos spec
  let J := (Finset.range n).filter fun j=>j∈I
  have matchSet : (selectedTags u 0 (mask (·∈I) 0 n)).toFinset=J.image (tag ∘ u) := by
    ext c
    simp only [List.mem_toFinset,mem_marked,Nat.zero_add,Finset.mem_image,J,
      Finset.mem_filter,Finset.mem_range,Function.comp_apply]
    grind
  have subset : J.image (tag ∘ u)⊆touched (a::es.map dst) := by
    intro c hc
    obtain ⟨j,hj,rfl⟩:=Finset.mem_image.mp hc
    obtain ⟨hj,marked⟩:=Finset.mem_filter.mp hj
    change tag (u j)∈touched _
    rw [←eq]
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨u j,List.mem_filter.mpr
      ⟨List.mem_map.mpr ⟨j,Finset.mem_range.mp hj |> List.mem_range.mpr,rfl⟩,decide_eq_true (marks.1 _ marked)⟩,rfl⟩)
  have injective : Set.InjOn (tag ∘ u) J := by
    intro j hj k hk same
    exact marks.2 j k (Finset.mem_filter.mp hj).2 (Finset.mem_filter.mp hk).2 same
  have equal : J.image (tag ∘ u)=touched (a::es.map dst) := by
    apply Finset.eq_of_subset_of_card_le subset
    rw [Finset.card_image_of_injOn injective,←card]
    simp [J,count]
  exact ⟨f,bij,z,by rwa [matchSet,equal] at contains⟩

theorem route_coverage_of_masks {a b : Six} {es : List Six}
    (r : Route src dst a es b) (width : ∀e∈es,e.length=7) (length : es.length=258)
    (many : 220≤classCount a es) (profiles : List (List Nat))
    (profile : ∀ (v : ℕ→Six) (I : Finset ℕ), Walk v → Marked v (·∈I) → 220≤count (·∈I) 0 259 →
      ∃ns∈profiles, ns≠[] ∧ (∀j∈ns,0<j) ∧ mask (·∈I) 0 259=rowsMask ns) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ((touched (a::es.map dst)).image (List.map f))∈realizations profiles :=
  route_coverage_at r width (by omega : es.length+1=259) many profiles (by
    intro u I walk mark threshold
    obtain ⟨ns,legit,nonempty,pos,eq⟩:=profile u I walk mark threshold
    exact ⟨ns,legit,nonempty,by cases ns with
                              | nil => exact (nonempty rfl).elim
                              | cons a rest => exact pos a List.mem_cons_self,eq⟩)

#print axioms route_coverage_of_masks
#print axioms coverage
end ResidualDensity.ExtremalRealizations

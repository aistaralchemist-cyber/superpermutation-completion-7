import FiveStepForm

namespace ExactWordFlow.SeventeenBranches
open DirectedEuler ResidualRoutes

/-- When erasing a remaining edge disconnects the mandatory classes, it
separates its own endpoints in the graph after erasure. -/
private theorem separated {base R : Multiset Block} {e : Block}
    (together : RequiredComponent.ClassesTogether (base+R)) (he : e∈R)
    (critical : ¬RequiredComponent.ClassesTogether (base+R.erase e)) :
    let G := required+(base+R.erase e)
    label G (src e) ≠ label G (dst e) := by
  classical
  let G := required+(base+R.erase e)
  change label G (src e) ≠ label G (dst e)
  intro alt
  apply critical
  have split : R.erase e+{e}=R := by
    rw [add_comm,Multiset.singleton_add,Multiset.cons_erase he]
  have eq : required+(base+R)=G+{e} := by
    rw [←split]
    simp only [G,split,add_assoc]
  intro c hc d hd
  let S : Set Block := {v | label G v=label G (src c)}
  have stable (f) (hf : f∈required+(base+R)) : src f∈S ↔ dst f∈S := by
    rw [eq] at hf
    rcases Multiset.mem_add.mp hf with h|one
    · change _=_ ↔ _=_
      rw [on_edge h]
    · obtain rfl := Multiset.mem_singleton.mp one
      change _=_ ↔ _=_
      rw [alt]
  exact ((invariant S stable (together c hc d hd)).mp rfl).symm

/-- An arbitrary fixed base may contain a balanced packet along with the
spine. If every spare window is indispensable for the required classes
and their degree is that of the contracted spine, the spare windows
must be two literal end extensions of that spine. -/
theorem bridge_ends {a b s t : Block} {es : List Block} {base R : Multiset Block}
    (spine : Route src dst a es b) (included : (↑es : Multiset Block)≤base)
    (ends : a≠b) (degree : R.map src+{a}+{t}=R.map dst+{b}+{s})
    (together : RequiredComponent.ClassesTogether (base+R))
    (critical : ∀e∈R, ¬ RequiredComponent.ClassesTogether (base+R.erase e)) :
    ∃ p q : List Block, (↑(p++q) : Multiset Block)=R ∧
      Route src dst s p a ∧ Route src dst b q t := by
  classical
  have cut (e) (he : e∈R) : ∃ U : Set Block, dst e∈U ∧ src e∉U ∧
      (a∈U ↔ b∈U) ∧ ∀ f∈R, f≠e → (src f∈U ↔ dst f∈U) := by
    let G := required+(base+R.erase e)
    let U : Set Block := {v | label G v=label G (dst e)}
    have key := separated together he (critical _ he)
    change label G (src e) ≠ label G (dst e) at key
    have edge (f) (hf : f∈es) : f∈G :=
      Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inl (Multiset.mem_of_le included hf))))
    have sr := (spine.closed {v | label G v=label G a} rfl
      (fun f hf prev => (on_edge (edge f hf)).symm.trans prev)).1
    refine ⟨U,rfl,key,?_,?_⟩
    · change (label G a=_) ↔ (label G b=_)
      rw [sr]
    · intro f hf ne
      have mem : f∈G := Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr
        (Or.inr ((Multiset.mem_erase_of_ne ne).mpr hf))))
      change (label G (src f)=_) ↔ (label G (dst f)=_)
      rw [on_edge mem]
  obtain ⟨xs,bag,walk⟩ := BridgeRoute.through_macro src dst ends R degree cut
  exact MacroSplit.split src dst R bag walk

#print axioms bridge_ends
end ExactWordFlow.SeventeenBranches

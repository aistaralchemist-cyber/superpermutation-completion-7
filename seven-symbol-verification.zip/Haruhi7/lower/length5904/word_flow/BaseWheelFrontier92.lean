import BaseWheelCeiling
import PathTurnsLow
import SplitWheelFrontier

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence ResidualRoutes RotationCore
open EmbeddedWheels WeightedMarks LiteralWheelCover
open private sizes from EmbeddedWheels

theorem path_turns_le_92 {s t : Block} {es ws : List Block}
    (h : Feasible ((↑es : Multiset Block)+turns ws) s t)
    (r : Route src dst s es t) (fw : ∀w∈ws,full w) (budget : es.length+6*ws.length≤858) :
    ws.length≤92 := by
  have hi:=route_turns_le_94 h r fw budget
  by_contra! lo
  exact PathTurnsGap.no_single_path_93_94 h r fw budget lo hi

theorem arbitrary_turns_le_92 {Y : Multiset Block} {ws : List Block} {s t : Block}
    (fw : ∀w∈ws,full w) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) : ws.length≤92 := by
  by_contra! many
  obtain ⟨es,extra,r,fullE,split⟩:=GroupSplitTurns.group h fw (all_short_92 fw h budget (by omega))
  have fullAll (v) (hv : v∈extra++ws) :=(List.mem_append.mp hv).elim (fullE v) (fw v)
  have cost : es.length+6*(extra++ws).length≤858 :=by
    rw [split,Multiset.card_add,(sizes fullAll).1] at budget
    exact budget
  have cap:=path_turns_le_92 (split ▸ h) r fullAll cost
  simp only [List.length_append] at cap
  omega

/-- At the surviving endpoint, deleting the specified 92 wheels leaves
only the 306-edge open route itself. All 260 of its contacts are needed. -/
theorem pure_92 {Y : Multiset Block} {ws : List Block} {s t : Block}
    (fw : ∀w∈ws,full w) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (exactCount : ws.length=92) :
    ∃es : List Block, Route src dst s es t ∧ Y=↑es ∧ es.length=306 ∧ classCount s es=260 ∧
      SeedWheelCut.ClosedCover (touched (s::es.map dst)) allClasses
        (ws.toFinset.image (fun v =>(orbit v).toFinset)) := by
  obtain ⟨es,extra,r,fullE,split⟩:=GroupSplitTurns.group h fw (all_short_92 fw h budget exactCount.ge)
  have fullAll (v) (hv : v∈extra++ws) :=(List.mem_append.mp hv).elim (fullE v) (fw v)
  have cost : es.length+6*(extra++ws).length≤858 :=by
    rw [split,Multiset.card_add,(sizes fullAll).1] at budget
    exact budget
  have cap:=path_turns_le_92 (split ▸ h) r fullAll cost
  have len : (extra++ws).length=extra.length+ws.length:=by simp
  have empty : extra=[]:=List.length_eq_zero_iff.mp (by omega)
  simp only [empty,List.nil_append] at split cost
  have eq : Y=(↑es : Multiset Block):=add_right_cancel split
  have wd (e) (he : e∈es) : e.length=7 :=by
    apply h.edges_seven e (Multiset.mem_add.mpr (Or.inl ?_))
    rw [eq]
    exact he
  have rk:=EmbeddedWheels.residual_rank ws fw h
  change 719≤5*ws.length+separateRank Y s at rk
  rw [eq,OnePath66.path_rank_eq r s] at rk
  have maxColors:=WeightedMarks.path_cap r wd
  exact ⟨es,r,eq,by omega,by omega,HundredDecomposition.closed_cover h r fw split⟩

theorem equality_92 {b : Block} {k : Nat} (done : (complete b).card=92)
    (budget : b.length+6*k=1508) (fit : condition b k) :
    k≤92 ∧ 956≤b.length := by
  obtain ⟨rs,v,ins,small,vis⟩:=(budget_iff b k).mpr fit
  have len:=ins.length_eq
  have c : (complete v).card=92:=ins.complete_eq ▸ done
  have sharp:=(Boundary1508Floor.only_boundary (w:=v) (by omega) vis c.ge).2
  obtain ⟨Y,ws,s,t,count,fw,flow,total⟩:=sharp_residual ins vis done (by omega)
  have cap:=arbitrary_turns_le_92 fw flow total.le
  omega

#print axioms equality_92
#print axioms pure_92
end ExactWordFlow.WheelBaseResidual

import PlacementCertificate

namespace ExactWordFlow.PlacementCertificate
open SevenWordWindows SuperpermutationBounds Std.Sat

def EntireModel (v : Nat → Bool) : Prop := ∀ s, legal s=true → (clause s).eval v=true

private theorem enabled {v : Nat → Bool} (all : EntireModel v) (r : Nat) (hr : r<table.length) :
    ∃ i<5898, v (var r i)=true := by
  have h := all (.required r) (decide_eq_true hr)
  rw [clause,CNF.Clause.eval,CNF.Clause.literals_ofLiterals,List.any_eq_true] at h
  obtain ⟨_,mem,on⟩ := h
  obtain ⟨i,hi,rfl⟩ := List.mem_map.mp mem
  exact ⟨i,List.mem_range.mp hi,by simpa using on⟩

private def written (v : Nat → Bool) (t : Nat) (a : Fin 7) : Prop :=
  ∃ r i k, r<table.length ∧ i<5898 ∧ k<7 ∧ v (var r i)=true ∧ i+k=t ∧ (row r)[k]?=some a

private theorem agree {v : Nat → Bool} (all : EntireModel v) {t a b}
    (ha : written v t a) (hb : written v t b) : a=b := by
  obtain ⟨r,i,k,hr,hi,hk,u,t1,p⟩ := ha
  obtain ⟨s,j,l,hs,hj,hl,z,t2,q⟩ := hb
  by_contra dif
  have ne : (row r)[k]? ≠ (row s)[l]? := by simp [p,q,dif]
  have legal_pair : legal (.conflict r i k s j l)=true :=
    decide_eq_true ⟨hr,hs,hi,hj,hk,hl,t1.trans t2.symm,ne⟩
  have both := all _ legal_pair
  simp [clause,CNF.Clause.eval,CNF.Clause.literals_ofLiterals,u,z] at both

private noncomputable def color (v : Nat → Bool) (t : Nat) : Fin 7 := by
  classical
  exact if h : ∃ a, written v t a then h.choose else 0

private theorem paint {v : Nat → Bool} (all : EntireModel v) {t a}
    (h : written v t a) : color v t=a := by
  classical
  unfold color
  rw [dite_eq_left (show ∃ b, written v t b from ⟨a,h⟩)]
  exact agree all (Classical.choose_spec _) h

private noncomputable def materialize (v : Nat → Bool) : Block :=
  List.ofFn fun t : Fin 5904 => color v t

private theorem slot {v : Nat → Bool} (all : EntireModel v) {r i : Nat}
    (hr : r<table.length) (hi : i<5898) (on : v (var r i)=true) :
    occurs (materialize v) (row r) i := by
  have rep := row_mem hr
  have width := ((mem_reps _).mp rep).1
  unfold occurs
  apply List.ext_getElem?
  intro k
  by_cases hk : k<7
  · have inrow : k<(row r).length := by omega
    have dest : i+k<5904 := by omega
    have get := List.getElem?_eq_getElem inrow
    have key := paint all (a:=(row r)[k]) (t:=i+k) ⟨r,i,k,hr,hi,hk,on,rfl,get⟩
    rw [List.getElem?_take_of_lt hk,List.getElem?_drop,materialize,List.getElem?_ofFn,
      dite_eq_left dest]
    simp only [key,get]
  · have high : (row r).length ≤ k := by omega
    simp [hk,List.getElem?_eq_none high]

private theorem split {w p : Block} {i : Nat} (h : occurs w p i) :
    w=w.take i ++ p ++ (w.drop i).drop 7 := by
  rw [List.append_assoc,←h,List.take_append_drop,List.take_append_drop]

theorem word_of_entire {v : Nat → Bool} (all : EntireModel v) :
    ∃ w : Block, Covers w ∧ w.length=5904 := by
  refine ⟨materialize v,?_,by simp only [materialize,List.length_ofFn]⟩
  intro p width clean
  have inRep : p∈representatives := (mem_reps p).mpr ⟨width,clean⟩
  have inTable : p∈table := by simpa [table,allPerms] using inRep
  obtain ⟨r,eq⟩ := List.mem_iff_get.mp inTable
  have rrow : row r=p := by simpa [row,List.getElem?_eq_getElem r.isLt] using eq
  obtain ⟨i,hi,on⟩ := enabled all r r.isLt
  have h := slot all r.isLt hi on
  exact ⟨_,_,by simpa [rrow] using split h⟩

theorem entire_iff : (∃ v, EntireModel v) ↔ ∃ w : Block, Covers w ∧ w.length≤5904 := by
  constructor
  · rintro ⟨v,sat⟩
    obtain ⟨w,cov,sz⟩ := word_of_entire sat
    exact ⟨w,cov,sz.le⟩
  · rintro ⟨w,cov,sz⟩
    exact ⟨truth w,clause_sound cov sz⟩

#print axioms entire_iff
end ExactWordFlow.PlacementCertificate

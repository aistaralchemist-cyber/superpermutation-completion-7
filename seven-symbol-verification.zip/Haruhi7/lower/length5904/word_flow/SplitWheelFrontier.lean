import SplitWheelPrice
import NoRoot271

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows ResidualDensity EmbeddedWheels ResidualIncidence ResidualRoutes
open scoped Classical
open DirectedEuler
open private sizes from EmbeddedWheels
open private closeCap cyclic_price rootCap root_price from Cap93Mass
namespace ShortRoot
open private root_price from ShortComponentCaps
theorem bound {a b : Block} {es : List Block} (r:Route src dst a es b)
    (width:∀e∈es,e.length=7) (small:es.length+1≤478) :
    classCount a es≤ShortScalars.openCap es.length := root_price r width small
end ShortRoot

private def openUpper (a : Nat) := min (min (rootCap a) (ShortScalars.openCap a))
  (if a=271 then 230 else rootCap a)

private theorem impossible_long : ∀a:Fin 307, ∀d:Fin 307, 7≤d.val → a.val+d.val≤306 →
    6*(openUpper a.val-1+(closeCap d.val-1))<5*(a.val+d.val)+24 := by native_decide

/-- A budget-858 presentation with at least 92 marked wheels cannot have a
longer nonstart component left over. The sole numerical candidate with the
weaker open cap has length pair (271,35); the actual 271-window cap removes it. -/
theorem all_short_92 {Y : Multiset Block} {s t : Block} {ws : List Block}
    (clean : ∀u∈ws,full u) (flow : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (many : 92≤ws.length) :
    ∀q∈((support Y s).image (label Y)).erase (label Y s),(part Y q).card≤6 := by
  classical
  let home:=label Y s
  let Q:=(support Y s).image (label Y)
  let K (q:Component Y):=(part Y q).card
  let C (q:Component Y):=(contacts (support Y s) (label Y) q).card
  let B:=(Q.erase home).filter (fun q=>7≤K q)
  have hroot : home∈Q:=Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q=Y.card := sum_part_card Y Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have sz:=(sizes clean).1
  rw [Multiset.card_add,sz] at budget
  have rank : 719≤5*ws.length+separateRank Y s:=residual_rank ws clean flow
  have balance:=Essential.restBalance flow (sizes clean).2
  have width (x) (hx:x∈Y):=flow.edges_seven x (Multiset.mem_add.mpr (Or.inl hx))
  have price:=(rest_price balance width).1
  change 45*separateRank Y s+25*B.card≤38*Y.card+59 at price
  have lone : B.card≤1:=by omega
  intro q hq
  change q∈Q.erase home at hq
  change K q≤6
  by_contra! big
  have qb : q∈B:=Finset.mem_filter.mpr ⟨hq,big⟩
  have single (i) (mem:i∈B) : i=q := Finset.card_le_one.mp lone i mem q qb
  have localCap (i) (hi:i∈Q) :
      (i=home → C i≤openUpper (K i)) ∧
      (i≠home → (7≤K i → C i≤closeCap (K i)) ∧ (K i≤6 → 6*(C i-1)≤5*K i)) := by
    obtain ⟨v,_,vv⟩:=Finset.mem_image.mp hi
    obtain ⟨a,b,es,equal,route,lv,ep⟩:=component_route balance v
    rw [vv] at equal lv ep
    have len:es.length=K i:=congrArg Multiset.card equal
    have wd (e) (he:e∈es):=width e (in_part.mp (equal ▸ (show e∈(↑es : Multiset Block) from he))).1
    have inc:C i≤classCount a es:=contacts_bound _ lv route equal
    have lim : K i≤Y.card := Multiset.card_le_card (Multiset.filter_le ..)
    constructor
    · intro _
      rw [←len,openUpper]
      have p:=inc.trans (root_price route wd)
      have shortP:=inc.trans (ShortRoot.bound route wd (by omega))
      apply le_min (le_min p shortP)
      split
      · rename_i eq
        exact inc.trans (NoRoot271.route route wd eq)
      · exact p
    · intro away
      obtain ⟨aa,bb⟩:=ep.2 away
      subst a; subst b
      constructor
      · intro bigI
        rw [←len]
        exact inc.trans (cyclic_price route wd (by omega))
      · intro small
        have z:=closed_small72 route wd (by omega)
        omega
  have others (i) (h : i∈(Q.erase home).erase q) : 6*(C i-1)≤5*K i := by
    obtain ⟨neq,mem⟩:=Finset.mem_erase.mp h
    have small : K i≤6:=by
      by_contra! b
      exact neq (single i (Finset.mem_filter.mpr ⟨mem,b⟩))
    exact ((localCap i (Finset.mem_erase.mp mem).2).2 (Finset.mem_erase.mp mem).1).2 small
  have sum:=Finset.sum_le_sum others
  simp only [←Finset.mul_sum] at sum
  have cr:=(localCap home hroot).1 rfl
  have cq:=((localCap q (Finset.mem_erase.mp hq).2).2 (Finset.mem_erase.mp hq).1).1 big
  have csum:=Finset.sum_erase_add (s:=Q) (fun i=>C i-1) hroot
  have ksum:=Finset.sum_erase_add (s:=Q) K hroot
  have csum':=Finset.sum_erase_add (s:=Q.erase home) (fun i=>C i-1) hq
  have ksum':=Finset.sum_erase_add (s:=Q.erase home) K hq
  change 719≤5*ws.length+∑i∈Q,(C i-1) at rank
  have joint : K home+K q≤306:=by omega
  have win:=impossible_long ⟨K home,by omega⟩ ⟨K q,by omega⟩ big joint
  simp only at win
  omega

#print axioms all_short_92
end ExactWordFlow.WheelBaseResidual

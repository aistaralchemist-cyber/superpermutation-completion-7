import SlackClosure

namespace ExactWordFlow.ComplementResidue
open SeedWheelCut
variable {α β : Type*} [DecidableEq α] [DecidableEq β]

private def pop (f : α→β) (T : Finset α) (b : β) := (T.filter fun x=>f x=b).card
def residue (f : α→β) (colors : Finset β) (T : Finset α) :=
  ∑b∈colors,(pop f T b)%5

private theorem gain_step (f : α→β) (colors : Finset β) (S G : Finset α)
    (apart : Disjoint S G) (cap : G.card≤5)
    (mono : G.card=5 → ∃z,∀x∈G,f x=z) :
    residue f colors (S∪G) ≤ residue f colors S + 4*(5-G.card) := by
  classical
  have counts (c) : pop f (S∪G) c=pop f S c+pop f G c := by
    unfold pop; rw [Finset.filter_union, Finset.card_union_of_disjoint]
    exact apart.mono (Finset.filter_subset _ _) (Finset.filter_subset _ _)
  by_cases five : G.card=5
  · obtain ⟨z,all⟩:=mono five
    have exact (c) : (pop f (S∪G) c)%5=(pop f S c)%5 := by
      rw [counts]
      by_cases yes : z=c
      · have same : G.filter (fun x=>f x=c)=G := Finset.filter_eq_self.mpr (fun x hx=>(all x hx).trans yes)
        have eq : pop f G c=5 := by rw [pop,same,five]
        omega
      · have empty : G.filter (fun x=>f x=c)=∅ := Finset.filter_eq_empty_iff.mpr
          (fun x hx eq=>yes ((all x hx).symm.trans eq))
        have eq : pop f G c=0 := by simp [pop,empty]
        omega
    simp only [five, Nat.sub_self,mul_zero,add_zero,residue,exact]
    rfl
  · have inequality (c) : (pop f (S∪G) c)%5≤(pop f S c)%5+pop f G c := by
      rw [counts];omega
    have bounds:=Finset.sum_le_sum (s:=colors) (fun c _=>inequality c)
    rw [Finset.sum_add_distrib] at bounds
    have small : (∑c∈colors,pop f G c)≤G.card := by
      unfold pop;rw [Finset.sum_card_fiberwise_eq_card_filter]
      exact Finset.card_le_card (Finset.filter_subset _ _)
    unfold residue
    omega

/-- A palette may be chosen separately for each initial root, such as the
components of its complement. Every saturated wheel adds a monochromatic
packet of five new vertices. Each unused unit of rank pays for at most four
vertices outside such packets, simultaneously across all colours. -/
theorem palette_bound (f : α→β) (colors : Finset β) (P A V : Finset α)
    (W : Finset (Finset α)) (inside : P⊆A) (rows : ∀w∈W,w⊆V ∧ w.card≤6)
    (mono : ∀w∈W,∀U⊆w,U.card=5 → Disjoint U P → ∃z,∀x∈U,f x=z)
    (linked : ClosedCover A V W) :
    4*V.card+residue f colors (V\A) ≤ 4*(A.card+5*W.card) := by
  classical
  by_cases grow : ∃w∈W,(A∩w).Nonempty ∧ ¬w⊆A
  · obtain ⟨w,hw,hit,_⟩:=grow
    obtain ⟨eligible,width⟩:=rows w hw
    have next : ClosedCover (A∪w) V (W.erase w) := by
      intro C sub closed
      apply linked C (Finset.subset_union_left.trans sub)
      intro b hb meet
      by_cases eq : b=w
      · exact eq ▸ (Finset.subset_union_right.trans sub)
      · exact closed b (Finset.mem_erase.mpr ⟨eq,hb⟩) meet
    have later:=palette_bound f colors P (A∪w) V (W.erase w) (inside.trans Finset.subset_union_left)
      (fun b hb=>rows b (Finset.mem_of_mem_erase hb))
      (fun b hb=>mono b (Finset.mem_of_mem_erase hb)) next
    let S:=V\(A∪w)
    let G:=w\A
    have parts : V\A=S∪G := by
      ext x
      simp [S,G] at *
      grind
    have disj : Disjoint S G := by
      apply Finset.disjoint_left.mpr; intro x hx hg
      exact (Finset.mem_sdiff.mp hx).2 (Finset.mem_union_right _ (Finset.mem_sdiff.mp hg).1)
    have small:=Finset.card_sdiff_add_card_inter w A
    rw [Finset.inter_comm w A] at small
    have atLeast:=Finset.card_pos.mpr hit
    have cap : G.card≤5 := by dsimp [G];omega
    have mono' (full : G.card=5) : ∃z,∀x∈G,f x=z :=
      mono w hw G Finset.sdiff_subset full (Finset.disjoint_left.mpr
        (fun _ g p=>(Finset.mem_sdiff.mp g).2 (inside p)))
    have change:=gain_step f colors S G disj cap mono'
    have cost := Finset.card_union_add_card_inter A w
    have count := Finset.card_erase_add_one hw
    rw [parts]
    change 4*V.card+residue f colors S ≤ 4*((A∪w).card+5*(W.erase w).card) at later
    change (w\A).card+(A∩w).card=w.card at small
    change G.card+(A∩w).card=w.card at small
    omega
  · have sub := linked A (Finset.Subset.refl _) (fun w hw hit=>by
      by_contra miss;exact grow ⟨w,hw,hit,miss⟩)
    have total:=Finset.card_le_card sub
    have empty : V\A=∅ := Finset.sdiff_eq_empty_iff_subset.mpr sub
    simp [residue,pop,empty]
    omega
termination_by W.card
decreasing_by exact Finset.card_erase_lt_of_mem hw

#print axioms palette_bound
end ExactWordFlow.ComplementResidue

import PrefixCharge

namespace ExactWordFlow.PrefixCertificate
open SevenWordWindows SuperpermutationBounds RotationCore PrefixCharge

inductive Tree
  | budget
  | terminal
  | split (children : Fin 7 → Tree)

/-- This is a finite test, including the two counts in the actual prefix. -/
def budgetFails (u : Block) : Bool :=
  decide (6 ≤ u.length ∧
    (visited u).card + ((windows u).toFinset.filter fun e => e.Nodup).card
      + (1501-u.length) < 1357)

def check : Tree → Block → Bool
  | .budget, u => budgetFails u
  | .terminal, u => decide (u.length=1501 ∧ ((visited u).card ≠ 720 ∨ (complete u).card ≤ 90))
  | .split children, u => decide (u.length < 1501) &&
      (List.finRange 7).all fun a => check (children a) (u++[a])

/-- The certificate excludes every full-length extension of this prefix. -/
def Closed (u : Block) : Prop :=
  ∀ r : Block, (u++r).length=1501 →
    (visited (u++r)).card=720 → (complete (u++r)).card≤90

theorem sound (cert : Tree) (u : Block) (ok : check cert u=true) : Closed u := by
  induction cert generalizing u with
  | budget =>
    obtain ⟨long,low⟩:=of_decide_eq_true (show decide _=true from ok)
    intro r size hit
    by_contra! more
    have need:=extension_bound u r long hit (by omega)
    simp only [List.length_append] at size
    omega
  | terminal =>
    obtain ⟨len,h⟩:=of_decide_eq_true (show decide _=true from ok)
    intro r size hit
    have empty : r=[]:=List.length_eq_zero_iff.mp (by simp only [List.length_append] at size; omega)
    subst r
    simpa using h.resolve_left (by simpa using hit)
  | split children ih =>
    obtain ⟨smaller,all⟩:=Bool.and_eq_true_iff.mp ok
    have room := of_decide_eq_true smaller
    intro r size hit
    cases r with
    | nil => simp at size; omega
    | cons x xs =>
      have child:=List.all_eq_true.mp all x (List.mem_finRange x)
      simpa using ih x (u++[x]) child xs (by simpa using size) (by simpa using hit)

/-- A uniformly expanded tree is complete when resources permit checking all of it. -/
def exhaustive : Nat → Tree
  | 0 => .terminal
  | d+1 => .split fun _ => exhaustive d

theorem exhaustive_accepts (d : Nat) (u : Block) (length : u.length+d=1501)
    (closed : Closed u) : check (exhaustive d) u = true := by
  induction d generalizing u with
  | zero =>
    have len : u.length=1501:=by omega
    have terminal := closed [] (by simpa) 
    have claim : (visited u).card ≠ 720 ∨ (complete u).card ≤ 90 := by
      by_cases hit : (visited u).card=720
      · exact Or.inr (by simpa using terminal (by simpa using hit))
      · exact Or.inl hit
    exact decide_eq_true ⟨len,claim⟩
  | succ d ih =>
    refine Bool.and_eq_true_iff.mpr ⟨decide_eq_true (by omega),List.all_eq_true.mpr ?_⟩
    intro a _
    apply ih (u++[a]) (by simp;omega)
    intro r size hit
    simpa using closed (a::r) (by simpa using size) (by simpa using hit)

theorem root_sound {cert : Tree} (ok : check cert []=true) : Target107.ceiling 1501 90 := by
  intro v small hit
  by_contra! many
  have floor:=LapSkeleton.completed_floor v
  have space : (good v).length≤v.length-6 := by
    rw [← windows_length]
    exact List.length_filter_le ..
  obtain ⟨z,len,vis,done⟩:=ExactBoundary.pad (v:=v) (by omega) small
  have cap:=sound cert [] ok z (by simpa using len) (by simpa [vis] using hit)
  simp only [List.nil_append,done] at cap
  omega

theorem complete_decision :
    Target107.ceiling 1501 90 ↔ ∃ cert, check cert []=true := by
  constructor
  · intro cap
    refine ⟨exhaustive 1501,exhaustive_accepts 1501 [] rfl ?_⟩
    intro r len hit
    exact cap _ len.le hit
  · rintro ⟨cert,ok⟩
    exact root_sound ok

set_option maxRecDepth 10000 in
theorem control_cut : check .budget recordPrefix=true := by native_decide

set_option maxRecDepth 10000 in
theorem control_fork : check (.split fun _ => .budget) recordPrefix=true := by native_decide

#print axioms complete_decision
#print axioms control_fork
end ExactWordFlow.PrefixCertificate

import WheelExchangeFloor

namespace ExactWordFlow.OnePath66.Packet64
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels ResidualRoutes
open scoped Classical

/-- A repeated-letter state carries the label of a chosen old class. -/
def project (d v : Block) := if full v then tag v else d

/-- All projected states of the packet, including the first state. -/
def labels (d u : Block) (p : List Block) :=
  (((u::p.map dst).map (project d))).toFinset

private theorem geometry :
    allClasses.card=720 ∧ (∀c∈allClasses, full (src c) ∧ tag (src c)=c) ∧
    (∀e∈representatives, full (src e) ∧ full (dst e) ∧ tag (src e)=tag (dst e)) ∧
    ∀w∈states, (orbit w).toFinset.card=6 ∧ ∀e∈GlobalWheelRank.wheel w,
      full (src e) ∧ full (dst e) ∧ tag (src e)∈orbit w ∧ tag (dst e)∈orbit w := by native_decide

private theorem class_labels : ∀v∈states, tag v∈allClasses := by native_decide

private theorem rowStays {C V : Finset Block} (closed : (C∩V).Nonempty → V⊆C)
    {x y : Block} (hx : x∈V) (hy : y∈V) : x∈C ↔ y∈C :=
  ⟨fun h => closed ⟨_,Finset.mem_inter.mpr ⟨h,hx⟩⟩ hy,
   fun h => closed ⟨_,Finset.mem_inter.mpr ⟨h,hy⟩⟩ hx⟩

private theorem sum_union_le (W P : Finset (Finset Block)) :
    (∑w∈W∪P,(w.card-1)) ≤ (∑w∈W,(w.card-1)) + (∑w∈P,(w.card-1)) :=
  (Nat.le_add_right _ _).trans (Finset.sum_union_inter ..).le

/-- A packet inside the root costs nothing further. A packet in a single additional
row B costs at most |B|-1, even if it uses many literal arcs. -/
theorem packet_rank {a b d : Block} {es ws : List Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (hd : d∈pathClasses a es)
    (R B : Finset Block) (oldClasses : pathClasses a es ⊆ R) (K F : Multiset Block)
    (packet : ∀e∈K, (project d (src e)∈R ∧ project d (dst e)∈R) ∨
                     (project d (src e)∈B ∧ project d (dst e)∈B))
    (together : RequiredComponent.ClassesTogether (((↑es : Multiset Block)+turns ws)+(K+F))) :
    720 ≤ R.card + 5*ws.length +(B.card-1)+F.card := by
  classical
  let W := wheelSets ws
  let ends (e : Block) : Finset Block := {project d (src e), project d (dst e)}
  let P := F.toFinset.image ends
  obtain ⟨C,old,cost,closed⟩ := GlobalWheelRank.grow R ((W∪P)∪{B})
  have clean (v : Block) (hv : full v) : project d v=tag v := by simp [project,hv]
  have onPath (v) (seen : v∈a::es.map dst) : project d v∈C := by
    apply old
    apply oldClasses
    by_cases fl : full v
    · rw [clean _ fl]
      exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨v,List.mem_filter.mpr ⟨seen,decide_eq_true fl⟩,rfl⟩)
    · simpa [project,fl] using hd
  let X := ((↑es : Multiset Block)+turns ws)+(K+F)
  let G := required+X
  let T : Set Block := {v | project d v∈C}
  have dstVisit (e) (he : e∈es) : dst e∈a::es.map dst :=
    List.mem_cons_of_mem _ (List.mem_map.mpr ⟨e,he,rfl⟩)
  have srcVisit := (r.closed {v | v∈a::es.map dst} List.mem_cons_self
    (fun e he _ => dstVisit e he)).2
  have preserves (e) (he : e∈G) : src e∈T ↔ dst e∈T := by
    change project d (src e)∈C ↔ project d (dst e)∈C
    rcases Multiset.mem_add.mp he with req|other
    · have v := geometry.2.2.1 e req
      rw [clean _ v.1,clean _ v.2.1,v.2.2]
    rcases Multiset.mem_add.mp other with oldEdges|newEdge
    · rcases Multiset.mem_add.mp oldEdges with pe|turn
      · exact iff_of_true (onPath _ (srcVisit e pe)) (onPath _ (dstVisit e pe))
      obtain ⟨w,hw,edge⟩ := List.mem_flatMap.mp (show e∈ws.flatMap GlobalWheelRank.wheel from turn)
      have g := (geometry.2.2.2 w (mem_states (legit w hw))).2 e edge
      rw [clean _ g.1, clean _ g.2.1]
      have m : (orbit w).toFinset∈W := Finset.mem_image_of_mem _ (List.mem_toFinset.mpr hw)
      apply rowStays (closed _ (Finset.mem_union_left _ (Finset.mem_union_left P m)))
      · exact List.mem_toFinset.mpr g.2.2.1
      · exact List.mem_toFinset.mpr g.2.2.2
    rcases Multiset.mem_add.mp newEdge with h|f
    · rcases packet e h with hr|hb
      · exact iff_of_true (old hr.1) (old hr.2)
      · exact rowStays (closed B (by simp)) hb.1 hb.2
    · have m : ends e∈P := Finset.mem_image_of_mem _ (Multiset.mem_toFinset.mpr f)
      apply rowStays (closed _ (Finset.mem_union_left _ (Finset.mem_union_right W m))) <;> simp [ends]
  have dm : d∈allClasses := by
    obtain ⟨v,hv,eq⟩ := List.mem_map.mp (List.mem_toFinset.mp hd)
    rw [←eq]
    exact class_labels v (mem_states (of_decide_eq_true (List.mem_filter.mp hv).2))
  have sub : allClasses⊆C := by
    intro c hc
    have side := invariant T preserves (together c hc d dm)
    change project d (src c)∈C ↔ project d (src d)∈C at side
    have v := geometry.2.1 c hc
    have w := geometry.2.1 d dm
    rw [clean _ v.1,clean _ w.1,v.2,w.2] at side
    exact side.mpr (old (oldClasses hd))
  have prices : ∑w∈W,(w.card-1) ≤ W.card*5 := by
    apply Finset.sum_le_card_nsmul
    intro w hw
    obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hw
    have n := (geometry.2.2.2 v (mem_states (legit v (List.mem_toFinset.mp hv)))).1
    omega
  have others : ∑w∈P,(w.card-1) ≤ P.card*1 := by
    apply Finset.sum_le_card_nsmul
    intro w hw
    obtain ⟨v,_,rfl⟩ := Finset.mem_image.mp hw
    have sz : (ends v).card≤2 := Finset.card_insert_le ..
    omega
  have cW : W.card≤ws.length := Finset.card_image_le.trans (List.toFinset_card_le ws)
  have cP : P.card≤F.card := Finset.card_image_le.trans (Multiset.toFinset_card_le F)
  have un := (sum_union_le W P).trans (Nat.add_le_add prices others)
  have plus := sum_union_le (W∪P) {B}
  simp only [Finset.sum_singleton] at plus
  have allRows := plus.trans (Nat.add_le_add_right un (B.card-1))
  have cost' := cost.trans (Nat.add_le_add_left allRows R.card)
  have low := Finset.card_le_card sub
  have n := geometry.1
  omega

theorem packet_ends {d u v : Block} {p : List Block} (rp : Route src dst u p v) :
    ∀e∈p, project d (src e)∈labels d u p ∧ project d (dst e)∈labels d u p := by
  have mem (z) (hz : z∈u::p.map dst) : project d z∈labels d u p :=
    List.mem_toFinset.mpr (List.mem_map.mpr ⟨_,hz,rfl⟩)
  have dest (e) (he : e∈p) : dst e∈u::p.map dst :=
    List.mem_cons_of_mem _ (List.mem_map.mpr ⟨_,he,rfl⟩)
  have source := (rp.closed {x | x∈u::p.map dst} List.mem_cons_self (fun e he _ => dest e he)).2
  exact fun e he => ⟨mem _ (source e he), mem _ (dest e he)⟩

/-- At the 64-wheel budget a separate packet must touch at least as many projected
vertices as it has edges, whether its chosen literal route is open or closed. -/
theorem closed_packet_rank {a b d u v : Block} {es ws p : List Block} {F : Multiset Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (hd : d∈pathClasses a es)
    (c : classCount a es=390) (n : ws.length≤64) (rp : Route src dst u p v)
    (budget : p.length+F.card≤11)
    (together : RequiredComponent.ClassesTogether (((↑es : Multiset Block)+turns ws)+(↑p+F))) :
    p.length ≤ (labels d u p).card := by
  classical
  have rank := packet_rank r legit hd (pathClasses a es) (labels d u p) (Finset.Subset.refl _)
    (↑p) F (fun e he => Or.inr (packet_ends rp e he)) together
  change (pathClasses a es).card=390 at c
  have ne : (labels d u p).Nonempty := ⟨project d u, by simp [labels]⟩
  have pos := Finset.card_pos.mpr ne
  omega

/-- If all packet labels are added to the initial root, their only cost is the
number outside the spine. At this budget a k-edge return path must add k-1. -/
theorem return_path_rank {a b d u v : Block} {es ws p : List Block} {F : Multiset Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (hd : d∈pathClasses a es)
    (c : classCount a es=390) (n : ws.length≤64) (rp : Route src dst u p v)
    (budget : p.length+F.card≤11)
    (together : RequiredComponent.ClassesTogether (((↑es : Multiset Block)+turns ws)+(↑p+F))) :
    p.length ≤ ((labels d u p) \ pathClasses a es).card + 1 := by
  classical
  let A := pathClasses a es
  let L := labels d u p
  have rank := packet_rank r legit hd (A∪L) ∅ Finset.subset_union_left
    (↑p) F (fun e he => Or.inl
      ⟨Finset.mem_union_right A (packet_ends rp e he).1,
       Finset.mem_union_right A (packet_ends rp e he).2⟩) together
  have eq := Finset.card_sdiff_add_card_eq_card (s := A) (t := A ∪ L) Finset.subset_union_left
  have diff : (A∪L) \ A = L \ A := by ext x; simp; tauto
  rw [diff] at eq
  change A.card=390 at c
  change p.length≤(L \ A).card+1
  simp only [Finset.card_empty,Nat.zero_sub,Nat.add_zero] at rank
  omega

theorem source_list {a b : Block} {es : List Block} (r : Route src dst a es b) :
    es.map src ++ [b] = a::es.map dst := by
  induction r with
  | nil => rfl
  | cons e he _ ih => simpa only [List.map_cons,List.cons_append,List.cons.injEq] using And.intro he ih

theorem cycle_nodup {a b d u : Block} {es ws p : List Block} {F : Multiset Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (hd : d∈pathClasses a es)
    (c : classCount a es=390) (n : ws.length≤64) (rp : Route src dst u p u)
    (positive : p ≠ []) (budget : p.length+F.card≤11)
    (together : RequiredComponent.ClassesTogether (((↑es : Multiset Block)+turns ws)+(↑p+F))) :
    (p.map (project d ∘ src)).Nodup := by
  have cap := closed_packet_rank r legit hd c n rp budget together
  have visited : u∈p.map src := by
    cases rp with
    | nil => contradiction
    | cons e he _ => simp [he]
  have dup : project d u ∈ (p.map (project d ∘ src)).toFinset := by
    simpa [List.map_map] using List.mem_map_of_mem (f:=project d) visited
  have roweq : labels d u p = (p.map (project d ∘ src)).toFinset := by
    unfold labels
    rw [←source_list rp,List.map_append,List.map_map]
    simp [dup]
  rw [roweq] at cap
  let m : Multiset Block := ↑(p.map (project d ∘ src))
  have eq : m.toFinset.card=m.card :=
    le_antisymm (Multiset.toFinset_card_le _) (by simpa [m] using cap)
  exact Multiset.coe_nodup.mp (Multiset.toFinset_card_eq_card_iff_nodup.mp eq)

#print axioms cycle_nodup
#print axioms packet_rank
#print axioms closed_packet_rank
#print axioms return_path_rank
end ExactWordFlow.OnePath66.Packet64

import GlobalWheelRank

namespace SeedWheelCut
open ExactWordFlow SevenWordWindows

/-- Start from A and close under every selected set that touches the current
set. A connected cover must reach all required labels in V. -/
def ClosedCover {α : Type*} [DecidableEq α] (A V : Finset α)
    (W : Finset (Finset α)) : Prop :=
  ∀ C : Finset α, A⊆C → (∀ w∈W, (C∩w).Nonempty → w⊆C) → V⊆C

/-- In a saturated cover each joining wheel must contribute five new
classes. A wheel already meeting the seed twice cannot perform this role.
The backbone A may contain arbitrarily many anchors outside the fixed seed P. -/
theorem forced_by_seed {α : Type*} [DecidableEq α] (P A V : Finset α)
    (W : Finset (Finset α)) (d : α) (inside : P⊆A) (required : d∈V)
    (width : ∀ w∈W, w.card≤6) (tight : A.card+5*W.card≤V.card)
    (blocked : ∀ w∈W, d∈w → 2≤(P∩w).card) (linked : ClosedCover A V W) :
    d∈A := by
  classical
  by_contra missing
  have need : ∃ w∈W, d∈w := by
    by_contra! no
    let C := A∪W.biUnion id
    have covers := linked C Finset.subset_union_left (fun w hw _ x hx =>
      Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨w,hw,hx⟩))
    rcases Finset.mem_union.mp (covers required) with old | fresh
    · exact missing old
    · obtain ⟨w,hw,member⟩ := Finset.mem_biUnion.mp fresh
      exact no w hw member
  obtain ⟨w,hw,dw⟩ := need
  have two := (blocked w hw dw).trans (Finset.card_le_card
    (show P∩w⊆A∩w by
      intro x hx
      have t := Finset.mem_inter.mp hx
      exact Finset.mem_inter.mpr ⟨inside t.1,t.2⟩))
  have circ := Finset.card_union_add_card_inter A w
  have wide := width w hw
  obtain ⟨C,sub,cost,rest⟩ := GlobalWheelRank.grow (A∪w) (W.erase w)
  have closed (q) (hq : q∈W) (meet : (C∩q).Nonempty) : q⊆C := by
    by_cases eq : q=w
    · exact eq ▸ Finset.subset_union_right.trans sub
    · exact rest q (Finset.mem_erase.mpr ⟨eq,hq⟩) meet
  have total := Finset.card_le_card (linked C (Finset.subset_union_left.trans sub) closed)
  have low : ∑ q∈W.erase w, (q.card-1) ≤ (W.erase w).card*5 := by
    apply Finset.sum_le_card_nsmul
    intro q hq
    have six := width q (Finset.mem_erase.mp hq).2
    omega
  have count := Finset.card_erase_add_one hw
  omega

/-- Relate an actual integer flow to closure of any proposed backbone and
selected wheels. The projected start can lie on either side of the cut. -/
theorem of_feasible {α : Type*} [DecidableEq α] (label : Block → α)
    (A V : Finset α) (W : Finset (Finset α)) {X : Multiset Block} {s t : Block}
    (h : Feasible X s t)
    (required_labels : V ⊆ (representatives.map (fun e => label (src e))).toFinset)
    (anchor : ∃e∈required, label (src e)∈A)
    (required_stays : ∀e∈required, label (src e)=label (dst e))
    (account : ∀e∈X, label (src e)=label (dst e) ∨
        (label (src e)∈A ∧ label (dst e)∈A) ∨
        ∃w∈W, label (src e)∈w ∧ label (dst e)∈w) : ClosedCover A V W := by
  classical
  intro C old closed
  have side (e) (he : e∈required+X) : label (src e)∈C ↔ label (dst e)∈C := by
    rcases Multiset.mem_add.mp he with req | x
    · rw [required_stays e req]
    · rcases account e x with same | ⟨hs,ht⟩ | ⟨w,hw,hs,ht⟩
      · rw [same]
      · exact ⟨fun _ => old ht,fun _ => old hs⟩
      · exact ⟨fun hi => closed w hw ⟨_,Finset.mem_inter.mpr ⟨hi,hs⟩⟩ ht,
          fun hi => closed w hw ⟨_,Finset.mem_inter.mpr ⟨hi,ht⟩⟩ hs⟩
  have root : label s ∈ C := by
    by_contra no
    obtain ⟨e,req,here⟩ := anchor
    have impossible := h.reachable {v | label v∉C} no
      (fun f hf hs ht => hs ((side f hf).mpr ht)) e (Multiset.mem_add.mpr (Or.inl req))
    exact impossible (old here)
  intro v hv
  obtain ⟨e,he,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp (required_labels hv))
  exact h.reachable {v | label v∈C} root (fun f hf => (side f hf).mp) e
    (Multiset.mem_add.mpr (Or.inl he))

end SeedWheelCut
#print axioms SeedWheelCut.forced_by_seed
#print axioms SeedWheelCut.of_feasible

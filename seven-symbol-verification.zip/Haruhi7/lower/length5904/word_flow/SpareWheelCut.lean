import HiddenWheelMaximum

namespace ExactWordFlow.HiddenWheelMaximum
open SevenWordWindows DirectedEuler RotationCore ResidualDensity WheelBaseResidual
open private sizes from EmbeddedWheels
open private mem_sources from ResidualRoutes

/-- Every full wheel present in a rigid base is an actual reachability cut if
one of its phases is still a vertex after deletion. The cut uses the exact
residual plus the 92 mandatory cycles of the base. -/
theorem cut_after_turn {b u : Block} {A : Multiset Block} (rigid : Rigid b)
    (long:6≤b.length) (clean:full u) (removed:bag b=A+↑(GlobalWheelRank.wheel u))
    (attach:u=b.take 6 ∨ ∃e∈A, src e=u ∨ dst e=u) :
    ∃S : Set Block,b.take 6∈S ∧ (∀e∈A,src e∈S → dst e∈S) ∧ ∃e∈A,src e∉S := by
  classical
  by_contra! no
  have reach (S : Set Block) (h:b.take 6∈S) (closed:∀e∈A,src e∈S → dst e∈S) :
      ∀e∈A,src e∈S:=no S h closed
  have r:=read_route b long
  have bal:=r.balance
  change (bag b).map src+_=(bag b).map dst+_ at bal
  have cleanOne : ∀w∈[u], full w:=by simpa
  have balance:=(sizes cleanOne).2
  change (↑((GlobalWheelRank.wheel u)++([] : List Block)) : Multiset Block).map src=
    (↑((GlobalWheelRank.wheel u)++([] : List Block)) : Multiset Block).map dst at balance
  simp only [List.append_nil] at balance
  rw [removed,Multiset.map_add,Multiset.map_add,balance,add_comm (A.map src),add_comm (A.map dst),
    add_assoc,add_assoc] at bal
  obtain ⟨es,eq,trail⟩:=exists_route src dst A _ _ (add_left_cancel bal) reach
  have wd (e) (he:e∈es) : e.length=7:=by
    apply RotationReinsert.window_width b
    change e∈bag b
    rw [removed]
    exact Multiset.mem_add.mpr (Or.inl (eq ▸ (show e∈(↑es:Multiset Block) from he)))
  have atU : u∈b.take 6::es.map dst :=by
    rcases attach with h|⟨e,mem,he⟩
    · exact List.mem_cons.mpr (Or.inl h)
    have inside:e∈es:=show e∈(↑es : Multiset Block) from eq ▸ mem
    rcases he with hs|hd
    · exact hs ▸ mem_sources trail inside
    · exact hd ▸ List.mem_cons_of_mem _ (List.mem_map.mpr ⟨e,inside,rfl⟩)
  exact no_removable_turn rigid long clean trail wd atU (by rw [eq,removed])

#print axioms cut_after_turn
end ExactWordFlow.HiddenWheelMaximum

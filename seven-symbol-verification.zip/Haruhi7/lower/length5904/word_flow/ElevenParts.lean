import ElevenScalar
namespace ExactWordFlow.ElevenLong
open private closeCap from Cap93Mass
open private openCap from ElevenScalar

/-- An extremal multiset has ten length-35 parts, two further long parts,
and at most two ordinary wheels. Mass and incidence rank are additive. -/
theorem parts {ι : Type*} [DecidableEq ι] (Q : Finset ι) (cost rank : ι→Nat)
    (r a : Nat) (B := Q.filter (fun q=>6<cost q))
    (D := Q.filter (fun q=>6<cost q ∧ cost q≠35))
    (bdef : B=Q.filter (fun q=>6<cost q)) (ddef : D=Q.filter (fun q=>6<cost q ∧ cost q≠35))
    (nt : B.card=12) (ineq : 3*Q.card+22*B.card+4*D.card≤308)
    (base : ∀q∈Q,6≤cost q ∧ rank q≤closeCap (cost q)-1)
    (mass : r+∑q∈Q,cost q≤858) (floor : 719≤a-1+∑q∈Q,rank q)
    (weighted : 45*(a-1)≤38*r+59) (op : r≤466 → a≤openCap r) : False := by
  classical
  have bq : B⊆Q := by rw [bdef]; exact Finset.filter_subset .. 
  have db : D⊆B := by
    rw [bdef,ddef]
    intro q h
    exact Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp h).1,(Finset.mem_filter.mp h).2.1⟩
  have total:=Finset.card_le_card bq
  have cd:=Finset.card_sdiff_of_subset db
  obtain ⟨T,ts,ct⟩:=Finset.exists_subset_card_eq (show 10≤(B\D).card by omega)
  have tb : T⊆B:=fun q hq=>(Finset.mem_sdiff.mp (ts hq)).1
  have ct' := Finset.card_sdiff_of_subset tb
  obtain ⟨x,y,xy,pair⟩:=Finset.card_eq_two.mp (show (B\T).card=2 by omega)
  have xb : x∈B:= (Finset.mem_sdiff.mp (show x∈B\T by rw [pair]; simp)).1
  have yb : y∈B:= (Finset.mem_sdiff.mp (show y∈B\T by rw [pair]; simp)).1
  have hx : 6<cost x:= by rw [bdef] at xb; exact (Finset.mem_filter.mp xb).2
  have hy : 6<cost y:= by rw [bdef] at yb; exact (Finset.mem_filter.mp yb).2
  let O:=Q\B
  have co : O.card≤2:=by have ee:=Finset.card_sdiff_of_subset bq; change (Q\B).card≤2; omega
  have tsize (q) (hq:q∈T) : cost q=35:=by
    obtain ⟨b,d⟩:=Finset.mem_sdiff.mp (ts hq)
    rw [bdef] at b
    have bmem:=Finset.mem_filter.mp b
    by_contra z
    rw [ddef] at d
    exact d (Finset.mem_filter.mpr ⟨bmem.1,bmem.2,z⟩)
  have osize (q) (hq:q∈O) : cost q=6:=by
    obtain ⟨inside,out⟩:=Finset.mem_sdiff.mp hq
    have low:=(base _ inside).1
    by_contra z
    rw [bdef] at out
    exact out (Finset.mem_filter.mpr ⟨inside,by omega⟩)
  have sumconst (S : Finset ι) (f : ι→Nat) (c : Nat) (h : ∀q∈S,f q=c) :
      (∑q∈S,f q)=c*S.card := by
    calc _ = ∑_∈S,c := Finset.sum_congr rfl h
         _ = _ := by simp [Nat.mul_comm]
  have boundconst (S : Finset ι) (f : ι→Nat) (c : Nat) (h : ∀q∈S,f q≤c) :
      (∑q∈S,f q)≤c*S.card := by
    calc _ ≤ ∑_∈S,c := Finset.sum_le_sum h
         _ = _ := by simp [Nat.mul_comm]
  have stk:=sumconst T cost 35 tsize
  have sok:=sumconst O cost 6 osize
  have str:=boundconst T rank 29 (by
    intro q hq
    have h:=(base q (bq (tb hq))).2
    rwa [tsize q hq,show closeCap 35-1=29 by decide] at h)
  have sor:=boundconst O rank 5 (by
    intro q hq
    have h:=(base q (Finset.mem_sdiff.mp hq).1).2
    rwa [osize q hq,show closeCap 6-1=5 by decide] at h)
  have pairK : (∑q∈B\T,cost q)=cost x+cost y:=by rw [pair]; simp [xy]
  have pairR : (∑q∈B\T,rank q)=rank x+rank y:=by rw [pair]; simp [xy]
  have rx:=(base x (bq xb)).2
  have ry:=(base y (bq yb)).2
  have km:=Finset.sum_sdiff (f:=cost) tb
  have ko:=Finset.sum_sdiff (f:=cost) bq
  have rm:=Finset.sum_sdiff (f:=rank) tb
  have ro:=Finset.sum_sdiff (f:=rank) bq
  change (∑q∈O,cost q)+_= _ at ko
  change (∑q∈O,rank q)+_= _ at ro
  exact scalar (cost x) (cost y) r O.card a hx hy co (by omega) (by omega) weighted op
end ExactWordFlow.ElevenLong

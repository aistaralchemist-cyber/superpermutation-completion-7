import ResidualDensity

namespace ResidualDensity

def count (p : ℕ → Prop) [DecidablePred p] (i n : ℕ) :=
  ((Finset.range n).filter fun j => p (i+j)).card

private theorem count_add (p : ℕ → Prop) [DecidablePred p] (i n m : ℕ) :
    count p i (n+m) = count p i n + count p (i+n) m := by
  simp only [count,Finset.card_filter,Finset.sum_range_add,Nat.add_assoc]

private theorem count_cap (p : ℕ → Prop) [DecidablePred p] (i n : ℕ) :
    count p i n ≤ n := Finset.card_filter_le .. |>.trans_eq (Finset.card_range _)

private theorem interval7 {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p]
    (walk : Walk u) (h : Marked u p) (i : ℕ) : count p i 7 ≤ 6 := by
  have cap := count_cap p i 7
  by_contra! no
  have eq : (Finset.range 7).filter (fun j => p (i+j))=Finset.range 7 := by
    apply Finset.eq_of_subset_of_card_le (Finset.filter_subset ..)
    change _≤count p i 7
    simp only [Finset.card_range]; omega
  apply no_seven walk h i
  intro j hj
  have mem : j ∈ (Finset.range 7).filter (fun j => p (i+j)) :=
    by rw [eq]; exact Finset.mem_range.mpr (by omega)
  exact (Finset.mem_filter.mp mem).2

private theorem chunks {p : ℕ → Prop} [DecidablePred p] {b a : ℕ}
    (cap : ∀ i, count p i b ≤ a) (i q : ℕ) : count p i (b*q) ≤ a*q := by
  induction q with
  | zero => simp [count]
  | succ q ih => rw [Nat.mul_succ,Nat.mul_succ,count_add]; have := cap (i+b*q); omega

private theorem rem7 {p : ℕ → Prop} [DecidablePred p]
    (cap : ∀ i, count p i 7 ≤ 6) (i n : ℕ) : count p i n ≤ 6*(n/7)+n%7 := by
  nth_rw 1 [←Nat.div_add_mod n 7]
  rw [count_add]
  have a := chunks cap i (n/7)
  have b := count_cap p (i+7*(n/7)) (n%7)
  omega

/-- Maximum number of distinct chosen class witnesses in an open walk of n contexts,
partitioning into disjoint 41-blocks, then seven-blocks and a remainder. -/
theorem open_count {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p]
    (walk : Walk u) (h : Marked u p) (i n : ℕ) :
    count p i n ≤ 35*(n/41) + 6*(n%41/7) + (n%41)%7 := by
  nth_rw 1 [←Nat.div_add_mod n 41]
  rw [count_add]
  have a := chunks (show ∀j,count p j 41≤35 from interval41 walk h) i (n/41)
  have b := rem7 (interval7 walk h) (i+41*(n/41)) (n%41)
  omega

/-- An open trail of k edges contributing a total gain of 24 must be long.
The rank contribution is bounded by C-1, where C class witnesses are marked. -/
theorem open_gain_24 {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p]
    (walk : Walk u) (h : Marked u p) (i k C : ℕ)
    (hc : count p i (k+1) = C) (gain : 5*k+30 ≤ 6*C) : 156 ≤ k := by
  have cap := open_count walk h i (k+1)
  by_contra! small
  have check : ∀ k : Fin 156, let n := k.val+1
      6*(35*(n/41) + 6*(n%41/7) + (n%41)%7) < 5*k.val+30 := by decide +kernel
  have bad := check ⟨k,small⟩
  dsimp at bad
  omega

/-- Marks repeat after k steps, but no two different positions less than one period apart
can mark the same clean rotation class. -/
structure CyclicMarked (u : ℕ → Six) (p : ℕ → Prop) (k : ℕ) : Prop where
  periodic : ∀ i, p (i+k) ↔ p i
  clean : ∀ i, p i → full (u i)
  unique : ∀ i j, i≤j → j < i+k → p i → p j → tag (u i)=tag (u j) → i=j

private theorem localMark {u : ℕ → Six} {p : ℕ → Prop} {k i b : ℕ}
    (h : CyclicMarked u p k) (le : b≤k) :
    Marked u (fun j => p j ∧ i ≤ j ∧ j < i+b) := by
  refine ⟨fun j x => h.clean j x.1,?_⟩
  rintro x y ⟨px,xl,xh⟩ ⟨py,yl,yh⟩ eq
  rcases le_total x y with aa | aa
  · exact h.unique x y aa (by omega) px py eq
  · exact (h.unique y x aa (by omega) py px eq.symm).symm

private theorem localCount {p : ℕ → Prop} [DecidablePred p] (i b : ℕ) :
    count (fun j => p j ∧ i≤j ∧ j < i+b) i b=count p i b := by
  unfold count
  congr 1
  ext j
  simp only [Finset.mem_filter,Finset.mem_range]
  constructor
  · rintro ⟨hj,hp,_,_⟩; exact ⟨hj,hp⟩
  · rintro ⟨hj,hp⟩; exact ⟨hj,hp,by omega,by omega⟩

private theorem periodic_laps {p : ℕ → Prop} [DecidablePred p] {k : ℕ}
    (per : ∀i,p (i+k) ↔ p i) (q : ℕ) : count p 0 (k*q)=count p 0 k*q := by
  have per' (x m : ℕ) : p (x + k*m) ↔ p x := by
    induction m with
    | zero => simp
    | succ m ih => rw [Nat.mul_succ,←Nat.add_assoc,per,ih]
  induction q with
  | zero => simp [count]
  | succ q ih =>
    rw [Nat.mul_succ,Nat.mul_succ,count_add,ih]
    congr 1
    simp only [Nat.zero_add,count]
    congr 1
    ext j
    simp only [Finset.mem_filter,Nat.add_comm (k*q) j,per']

private theorem cyclic_count {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p] {k b a : ℕ}
    (h : CyclicMarked u p k) (le : b≤k)
    (lim : ∀j (p' : ℕ → Prop) [DecidablePred p'], Marked u p' → count p' j b≤a) :
    b*count p 0 k ≤ a*k := by
  have loc (i : ℕ) : count p i b ≤ a := by
    rw [←localCount i b]
    exact lim i _ (localMark h le)
  have xx := chunks loc 0 k
  rw [Nat.mul_comm b k,periodic_laps h.periodic,Nat.mul_comm] at xx
  exact xx

/-- In a circuit of at least 41 edges, averaging all cyclic shifts of the 41-window
bound counts each chosen class exactly 41 times. -/
theorem cyclic_41 {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p] {k : ℕ}
    (walk : Walk u) (h : CyclicMarked u p k) (le : 41≤k) : 41*count p 0 k ≤ 35*k :=
  cyclic_count h le fun i _ _ hh => interval41 walk hh i

theorem cyclic_7 {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p] {k : ℕ}
    (walk : Walk u) (h : CyclicMarked u p k) (le : 7≤k) : 7*count p 0 k ≤ 6*k :=
  cyclic_count h le fun i _ _ hh => interval7 walk hh i

/-- No closed trail of at most sixty edges can improve on five rank units per six
units of cost. The hypotheses allow every choice of starting six letters. -/
theorem short_cycle_gain {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p] {k : ℕ}
    (walk : Walk u) (h : CyclicMarked u p k) (short : k≤60) :
    6*count p 0 k ≤ 5*k+6 := by
  have cnt := count_cap p 0 k
  by_cases seven : 7≤k
  · have a := cyclic_7 walk h seven
    by_cases forty : 41≤k
    · have b := cyclic_41 walk h forty
      have kk : k<61 := by omega
      have dd : count p 0 k<61 := by omega
      have ck : ∀ m n : Fin 61, 41*n.val≤35*m.val → 6*n.val≤5*m.val+6 := by decide +kernel
      exact ck ⟨k,kk⟩ ⟨_,dd⟩ b
    · omega
  · omega

/-- Reuse disjoint window blocks with the universal seven-window remainder bound. -/
theorem window_open_bound {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p] {a b : ℕ}
    (w : Walk u) (h : Marked u p) (lim : ∀ i, count p i b ≤ a) (i n : ℕ) :
    count p i n ≤ a*(n/b) + 6*(n%b/7) + (n%b)%7 := by
  nth_rw 1 [←Nat.div_add_mod n b]
  rw [count_add]
  have x := chunks lim i (n/b)
  have z := rem7 (interval7 w h) (i+b*(n/b)) (n%b)
  omega

theorem window_cyclic_bound {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p] {k b a : ℕ}
    (h : CyclicMarked u p k) (le : b≤k)
    (lim : ∀j (p' : ℕ → Prop) [DecidablePred p'], Marked u p' → count p' j b≤a) :
    b*count p 0 k ≤ a*k := cyclic_count h le lim

end ResidualDensity
#print axioms ResidualDensity.open_gain_24
#print axioms ResidualDensity.short_cycle_gain

import SquareDual
import WheelContacts

namespace SquareDual
open ExactWordFlow SevenWordWindows ResidualDensity

/-- Rotate the six surviving letters to the least of those letters. -/
def canonicalWheel (s : Block) : Block :=
  let least := ((List.finRange 7).find? (fun a => a∈s)).getD 0
  s.rotate (s.idxOf least)

def incidence (e : Block) : Block × Block := (classKey e, canonicalWheel e.tail)
def classPair (f : Block) : Finset Block := {(incidence f).1,(incidence (swap f)).1}
def wheelPair (f : Block) : Finset Block := {(incidence f).2,(incidence (swap f)).2}

private def decodeIncidence (p : Block × Block) := p.1.rotate (p.1.idxOf (WheelContacts.missing p.2))

private def fromWheels (s t : Block) : Block :=
  let a := WheelContacts.missing s
  let b := WheelContacts.missing t
  normal (a :: b :: WheelContacts.afterGap s b)

private def decodePair (q : Finset Block) : Block :=
  if h:q.Nonempty then
    let s := q.min' h
    let r := q.erase s
    if k:r.Nonempty then fromWheels s (r.min' k) else []
  else []

private theorem checked_incidences :
    (representatives.all fun e => decide (
      decodeIncidence (incidence e)=e ∧ (incidence e).2 ∈ WheelContacts.bases ∧
      (incidence e).1 ∈ WheelContacts.wheel (incidence e).2))=true := by native_decide

theorem incidence_injective {e d : Block} (he : e∈representatives) (hd : d∈representatives)
    (eq : incidence e=incidence d) : e=d := by
  have a := (of_decide_eq_true (List.all_eq_true.mp checked_incidences e he)).1
  have b := (of_decide_eq_true (List.all_eq_true.mp checked_incidences d hd)).1
  exact a.symm.trans ((congrArg decodeIncidence eq).trans b)

theorem attachments {e : Block} (he : e∈representatives) :
    (incidence e).2∈WheelContacts.bases ∧ (incidence e).1∈WheelContacts.wheel (incidence e).2 :=
  (of_decide_eq_true (List.all_eq_true.mp checked_incidences e he)).2

private theorem square_table :
    (faceList.all fun f => decide ((classPair f).card=2 ∧ (wheelPair f).card=2 ∧
      (boundary f).image incidence=(classPair f).product (wheelPair f) ∧
      (∀e∈corners f,e∈representatives) ∧
      decodePair (wheelPair f)=f ∧ ∀s∈wheelPair f, ∀t∈wheelPair f, s≠t →
        (WheelContacts.wheel s ∩ WheelContacts.wheel t)=classPair f))=true := by
  native_decide

theorem face_square {f : Block} (hf : f∈faces) : (classPair f).card=2 ∧ (wheelPair f).card=2 ∧
    (boundary f).image incidence=(classPair f).product (wheelPair f) ∧ boundary f ⊆ representatives.toFinset := by
  let data := of_decide_eq_true (List.all_eq_true.mp square_table f (List.mem_toFinset.mp hf))
  exact ⟨data.1,data.2.1,data.2.2.1,fun _ he =>
    List.mem_toFinset.mpr (data.2.2.2.1 _ (List.mem_toFinset.mp he))⟩

theorem square_intersection {f s t : Block} (hf : f∈faces) (hs : s∈wheelPair f) (ht : t∈wheelPair f)
    (ne : s≠t) : (WheelContacts.wheel s ∩ WheelContacts.wheel t)=classPair f :=
  (of_decide_eq_true (List.all_eq_true.mp square_table f (List.mem_toFinset.mp hf))).2.2.2.2.2 _ hs _ ht ne

theorem wheel_pair_injective {f g : Block} (hf : f∈faces) (hg : g∈faces)
    (eq : wheelPair f=wheelPair g) : f=g := by
  have a := (of_decide_eq_true (List.all_eq_true.mp square_table f (List.mem_toFinset.mp hf))).2.2.2.2.1
  have b := (of_decide_eq_true (List.all_eq_true.mp square_table g (List.mem_toFinset.mp hg))).2.2.2.2.1
  exact a.symm.trans ((congrArg decodePair eq).trans b)

/-- Six geometrically specified partners for a given wheel. They exhaust
all double intersections by the degree-six census. -/
private def atWheel (s : Block) := s.map (fun b =>
  normal (WheelContacts.missing s :: b :: WheelContacts.afterGap s b))
private def mates (s : Block) := ((atWheel s).flatMap fun f =>
  [(incidence f).2,(incidence (swap f)).2]).toFinset.erase s

private theorem mate_table :
    (WheelContacts.bases.all fun s => decide ((mates s).card=6 ∧
      ∀t∈mates s, t∈WheelContacts.bases ∧ WheelContacts.gapCount s t=2 ∧
        ∃f∈atWheel s, f∈faces ∧ wheelPair f={s,t}))=true := by native_decide

theorem double_has_face {s t : Block} (hs : s∈WheelContacts.bases) (ht : t∈WheelContacts.bases)
    (two : (WheelContacts.wheel s ∩ WheelContacts.wheel t).card=2) :
    ∃f∈faces, wheelPair f={s,t} := by
  let ls := WheelContacts.bases.filter (fun v => WheelContacts.gapCount s v == 2)
  have data := of_decide_eq_true (List.all_eq_true.mp mate_table s hs)
  have len : ls.length=6 := (WheelContacts.census.2.2 s hs).2.1
  have eq : mates s = ls.toFinset := by
    apply Finset.eq_of_subset_of_card_le
    · intro v hv
      have row := data.2 v hv
      exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨row.1,beq_iff_eq.mpr row.2.1⟩)
    · exact (List.toFinset_card_le _).trans_eq (len.trans data.1.symm)
  have good := (WheelContacts.wheel_contacts hs ht).symm.trans two
  have m : t∈mates s := eq ▸ (List.mem_toFinset.mpr (List.mem_filter.mpr ⟨ht,beq_iff_eq.mpr good⟩))
  obtain ⟨f,_,hf,id⟩ := (data.2 t m).2.2
  exact ⟨_,hf,id⟩

#print axioms face_square
#print axioms incidence_injective
#print axioms double_has_face
end SquareDual

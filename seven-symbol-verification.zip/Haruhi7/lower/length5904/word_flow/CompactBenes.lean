import Batteries.Tactic.OpenPrivate
import CompactGateLaws
import BenesArray
import Mathlib.Data.List.Forall2

namespace ExactWordFlow.CompactWordCircuit
open BenesRouting
open private swapped from CompactWordCircuit
open private turned from BenesArray
open private range_get from BenesArray

def ArrayRel (R : α → β → Prop) (xs : Array α) (ys : Array β) := List.Forall₂ R xs.toList ys.toList

theorem ArrayRel.size {R : α → β → Prop} {xs : Array α} {ys : Array β} (h : ArrayRel R xs ys) :
    xs.size=ys.size := by simpa using (List.Forall₂.length_eq h)

theorem ArrayRel.get {R : α → β → Prop} [Inhabited α] [Inhabited β]
    {xs : Array α} {ys : Array β} (h : ArrayRel R xs ys) (i : Nat) (bound : i<xs.size) :
    R xs[i]! ys[i]! := by
  have hb : i<ys.size := h.size ▸ bound
  rw [getElem!_pos xs i bound,getElem!_pos ys i hb]
  exact List.Forall₂.get h (by simpa using bound) (by simpa using hb)

theorem ArrayRel.push {R : α → β → Prop} {xs : Array α} {ys : Array β} (h : ArrayRel R xs ys)
    {x y} (hx : R x y) : ArrayRel R (xs.push x) (ys.push y) := by
  simpa [ArrayRel,Array.toList_push] using List.rel_append h (.cons hx .nil)

theorem forallMapAux {R : α → β → Prop} (f : γ → α) {gs : List γ} {ys : List β}
    (h : List.Forall₂ (fun g y=>R (f g) y) gs ys) : List.Forall₂ R (gs.map f) ys := by
  induction h with
  | nil => exact .nil
  | cons _ _ ih => exact .cons ‹_› ih

theorem forallMapRightAux {R : α → β → Prop} (f : γ → β) {gs : List γ} {ys : List α}
    (h : List.Forall₂ (fun g y=>R y (f g)) gs ys) : List.Forall₂ R ys (gs.map f) := by
  induction h with
  | nil => exact .nil
  | cons _ _ ih => exact .cons ‹_› ih

theorem Gives.imp {T : Test} {m : M α} {P Q : α → Prop} (h : Gives T m P) (g : ∀ x, P x → Q x) :
    Gives T m Q := fun st valid => g _ (h st valid)

private theorem swapped_grows (s : Source) (x y : Bits) : Grows (swapped s x y) := by
  unfold swapped
  exact bind_grows (alloc_grows _ (by simp)) (fun _=>bind_grows
    (mapArray_grows (fun _=>mux_grows _ _ _) _) (fun _=>bind_grows
    (mapArray_grows (fun _=>mux_grows _ _ _) _) (fun _=>pure_grows _)))

/-- The final switch bank emits switches in ascending order and pushes both outputs. -/
private def bankLoop {A : Type} (sw : Nat → M (A × A)) (n : Nat) : M (Array A) :=
  (List.range n).foldlM (fun acc i => (fun p => (acc.push p.1).push p.2) <$> sw i) #[]

private theorem bank_grows {A : Type} (sw : Nat → M (A × A)) (n : Nat) (g : ∀i,Grows (sw i)) :
    Grows (bankLoop sw n) := foldList_grows (fun _ i=>map_grows _ (g i)) _ _

private theorem bank_gives {A B : Type} {T : Test} {R : A → B → Prop} (n : Nat)
    (sw : Nat → M (A × A)) (q : Nat → B × B) (g : ∀i,Grows (sw i))
    (h : ∀i,i<n → Gives T (sw i) (fun p=>R p.1 (q i).1 ∧ R p.2 (q i).2)) :
    Gives T (bankLoop sw n) (fun out=>ArrayRel R out (backRows n q)) := by
  apply foldList_gives (g:=fun acc i=>(acc.push (q i).1).push (q i).2) (R:=ArrayRel R)
    (fun _ i=>map_grows _ (g i)) (List.range n) #[] #[] (.nil)
  intro i hi u v huv
  exact map_gives (g i) (h i (List.mem_range.mp hi)) (fun p hp=>(huv.push hp.1).push hp.2)

private theorem final_loop {a b : Rows} (n node : Nat) :
    (do
      let mut out : Rows := #[]
      for i in [:n] do
        let (l,r) ← swapped (.switch node true i) a[i]! b[i]!
        out := (out.push l).push r
      return out) =
    bankLoop (fun i=>swapped (.switch node true i) a[i]! b[i]!) n := by
  exact range_fold n #[] (fun acc i=>(fun p => (acc.push p.1).push p.2) <$>
    swapped (.switch node true i) a[i]! b[i]!)

theorem benes_grows : ∀ (d node : Nat) (rows : Rows), Grows (benes d node rows)
  | 0,_,rows => pure_grows rows
  | 1,node,rows => bind_grows (swapped_grows (.switch node false 0) rows[0]! rows[1]!)
      (fun _=>pure_grows _)
  | d+2,node,rows => by
    rw [benes]
    refine bind_grows (mapArray_grows (fun _=>swapped_grows _ _ _) _) (fun pairs=>?_)
    refine bind_grows (benes_grows (d+1) _ _) (fun high=>?_)
    refine bind_grows (benes_grows (d+1) _ _) (fun low=>?_)
    rw [final_loop]
    exact bank_grows _ _ (fun _=>swapped_grows _ _ _)


private theorem projections {A B : Type} (R : A → B → Prop) (qs : Nat → B × B) {ns : List Nat}
    {ps : List (A×A)}
    (h : List.Forall₂ (fun i x => R x.1 (qs i).1 ∧ R x.2 (qs i).2) ns ps) :
    List.Forall₂ R (ps.map Prod.fst) (ns.map fun i => (qs i).1) ∧
    List.Forall₂ R (ps.map Prod.snd) (ns.map fun i => (qs i).2) := by
  induction h with
  | nil => exact ⟨.nil,.nil⟩
  | cons hv _ ih => exact ⟨.cons hv.1 ih.1,.cons hv.2 ih.2⟩

private theorem array_size_run {V : Type} [Inhabited V] (f : Bank) (d node : Nat) (bs : Array V)
    (h : bs.size=2^d) : (arrayRun f d node bs).size=2^d := by
  rcases d with _|d
  · exact h
  rcases d with _|d
  · simp [arrayRun]
  · simp [arrayRun,h,pow_succ,Nat.mul_comm]

/-- Correctness of the actual sequence of `benes` calls, parameterized by the
gate-level contract for a single pair of input rows of equal width. -/
theorem benes_simulates {V : Type} [Inhabited V] {T : Test} (f : Bank)
    (R : Bits → V → Prop)
    (switch : ∀ nd b j x y a c, R x a → R y c →
      Gives T (swapped (.switch nd b j) x y)
        (fun p=>R p.1 (turned (f nd b j) a c).1 ∧ R p.2 (turned (f nd b j) a c).2)) :
    ∀ d node (rows : Rows) (bs : Array V), ArrayRel R rows bs → rows.size=2^d →
      Gives T (benes d node rows) (fun out=>ArrayRel R out (arrayRun f d node bs))
  | 0,_,_,_,h,_ => pure_gives h
  | 1,node,rows,bs,h,size => by
    rw [benes]
    refine map_gives (m:=swapped (.switch node false 0) rows[0]! rows[1]!)
      (f:=fun p => #[p.1,p.2]) (swapped_grows _ _ _) (switch node false 0 _ _ _ _
      (h.get 0 (by omega)) (h.get 1 (by omega))) ?_
    intro ⟨a,b⟩ pair
    cases flip : f node false 0 <;> simpa [arrayRun,turned,flip,ArrayRel] using
      (List.Forall₂.cons pair.1 (.cons pair.2 .nil))
  | d+2,node,rows,bs,h,size => by
    let n := rows.size/2
    have bs_size := h.size.symm.trans size
    have ns : n=2^(d+1) := by simp [n,size,pow_succ]
    have bsn : bs.size/2=n := by rw [←h.size]
    let q := fun j => turned (f node false j) bs[2*j]! bs[2*j+1]!
    let fstStage := fun j => swapped (.switch node false j) rows[2*j]! rows[2*j+1]!
    have first := mapArray_gives (T:=T)
      (R:=fun j (p : Bits×Bits)=>R p.1 ((q j).1) ∧ R p.2 ((q j).2))
      (Array.range n) (fun j=>swapped_grows (.switch node false j) _ _)
      (fun j hj=>by
        have bound : j<n := by simpa using hj
        have bound' : 2*j+1<rows.size := by unfold n at bound; omega
        exact switch node false j _ _ _ _ (h.get _ (by omega)) (h.get _ bound'))
    rw [benes]
    refine bind_gives (m:=(Array.range n).mapM fstStage) (mapArray_grows (fun _=>swapped_grows _ _ _) _)
      (fun pairs => bind_grows (benes_grows _ _ _) (fun high => bind_grows (benes_grows _ _ _)
        (fun low=> by rw [final_loop]; exact bank_grows _ _ (fun _=>swapped_grows _ _ _)))) first ?_
    intro pairs hp
    have proj := projections R q (by simpa using hp)
    have highR : ArrayRel R (pairs.map Prod.fst) (frontRows f node bs false) := by
      simpa [ArrayRel,frontRows,q,bsn] using proj.1
    have lowR : ArrayRel R (pairs.map Prod.snd) (frontRows f node bs true) := by
      simpa [ArrayRel,frontRows,q,bsn] using proj.2
    have sz : pairs.size=2^(d+1) := by
      have len := List.Forall₂.length_eq hp
      simpa [ns] using len.symm
    refine bind_gives (benes_grows _ _ _) (fun high=>bind_grows (benes_grows _ _ _)
      (fun low=>by rw [final_loop]; exact bank_grows _ _ (fun _=>swapped_grows _ _ _)))
      (benes_simulates f R switch (d+1) (2*node) _ _ highR (by simpa using sz)) ?_
    intro high highOK
    refine bind_gives (benes_grows _ _ _) (fun low=> by rw [final_loop]; exact bank_grows _ _ (fun _=>swapped_grows _ _ _))
      (benes_simulates f R switch (d+1) (2*node+1) _ _ lowR (by simpa using sz)) ?_
    intro low lowOK
    rw [final_loop]
    have hsz := (highOK.size.trans (array_size_run f (d+1) (2*node) _ (by simp [frontRows,bsn,ns])))
    have lsz := (lowOK.size.trans (array_size_run f (d+1) (2*node+1) _ (by simp [frontRows,bsn,ns])))
    unfold arrayRun
    rw [bsn]
    exact bank_gives n _ _ (fun _=>swapped_grows _ _ _) (fun j hj=>switch node true j _ _ _ _
      (highOK.get j (by omega)) (lowOK.get j (by omega)))


theorem fresh_gives (input : Source → Bool) (v : Nat → Bool) (s : Source) :
    Gives (sourceTest input v) (alloc (.fresh s)) (Rep v (input s)) := by
  intro st h
  refine ⟨?_,?_⟩
  · change ((st.vars+1 : Nat) : Int) ≠ 0
    exact_mod_cast Nat.succ_ne_zero st.vars
  · change v st.vars = input s
    simpa [alloc,admits,sourceTest] using h

/-- A fixed-width emitted register represents a Boolean record, field by field. -/
def RowRep (v : Nat → Bool) (width : Nat) (ws : Bits) (bs : Array Bool) :=
  ws.size = width ∧ ArrayRel (fun x b=>Rep v b x) ws bs

private theorem from_indices {V : Type} [Inhabited V] {R : W → V → Prop} {ws : Bits}
    (bs : Array V) (n : Nat) (size : bs.size=n)
    (h : List.Forall₂ (fun i x=>R x bs[i]!) (List.range n) ws.toList) :
    ws.size=n ∧ ArrayRel R ws bs := by
  have len := h.length_eq
  simp only [List.length_range,Array.length_toList] at len
  refine ⟨len.symm,List.forall₂_of_length_eq_of_get (by simpa [len] using size.symm) ?_⟩
  intro i hi hj
  have hv := h.get (i:=i) (by simpa [len] using hi) hi
  simp [List.get_eq_getElem] at hv ⊢
  have hz : i < n := by simpa [len] using hi
  simpa [List.getElem_range, getElem!_pos bs i (by simpa using hj)] using hv

private theorem muxRegister (input : Source → Bool) (v : Nat → Bool) (unit : v 0=true)
    {width : Nat} {flip : W} {bit : Bool} (control : Rep v bit flip)
    {x y : Bits} {a b : Array Bool} (xr : RowRep v width x a) (yr : RowRep v width y b)
    (n : Nat) (size : n=width) :
    Gives (sourceTest input v) ((Array.range n).mapM (fun i=>mux flip x[i]! y[i]!))
      (fun out=>RowRep v width out (if bit then a else b)) := by
  have asize := xr.2.size.symm.trans xr.1
  have bsize := yr.2.size.symm.trans yr.1
  have h := mapArray_gives (T:=sourceTest input v)
    (R:=fun i w => Rep v (if bit then a[i]! else b[i]!) w) (Array.range n)
    (fun i=>mux_grows flip x[i]! y[i]!) (fun i hi=>by
      have bnd : i<n := by simpa using hi
      exact mux_gives (source_models input v) unit control
        (xr.2.get i (by rw [xr.1,←size]; exact bnd)) (yr.2.get i (by rw [yr.1,←size]; exact bnd)))
  refine h.imp (fun out ok=>?_)
  cases bit with
  | false =>
    simpa [RowRep,←size] using from_indices b n (by omega)
      (R:=fun w d=>Rep v d w) (by simpa using ok)
  | true =>
    simpa [RowRep,←size] using from_indices a n (by omega)
      (R:=fun w d=>Rep v d w) (by simpa using ok)

private theorem switched_rows (input : Source → Bool) (v : Nat → Bool) (unit : v 0=true)
    (s : Source) {width : Nat} (x y : Bits) (a b : Array Bool)
    (xr : RowRep v width x a) (yr : RowRep v width y b) :
    Gives (sourceTest input v) (swapped s x y)
      (fun p=>RowRep v width p.1 (turned (input s) a b).1 ∧
        RowRep v width p.2 (turned (input s) a b).2) := by
  unfold swapped
  refine bind_gives (alloc_grows _ (by simp))
    (fun flip=>bind_grows (mapArray_grows (fun _=>mux_grows _ _ _) _)
      (fun _=>bind_grows (mapArray_grows (fun _=>mux_grows _ _ _) _) (fun _=>pure_grows _)))
    (fresh_gives input v s) ?_
  intro flip control
  refine bind_gives (mapArray_grows (fun _=>mux_grows _ _ _) _)
    (fun _=>bind_grows (mapArray_grows (fun _=>mux_grows _ _ _) _) (fun _=>pure_grows _))
    (muxRegister input v unit control yr xr x.size xr.1) ?_
  intro left leftOK
  refine bind_gives (mapArray_grows (fun _=>mux_grows _ _ _) _) (fun _=>pure_grows _)
    (muxRegister input v unit control xr yr x.size xr.1) ?_
  intro right rightOK
  apply pure_gives
  cases hh : input s <;> simp_all [turned]

theorem benes_records (input : Source → Bool) (v : Nat → Bool) (unit : v 0=true)
    (width d node : Nat) (rows : Rows) (bs : Array (Array Bool))
    (rel : ArrayRel (RowRep v width) rows bs) (size : rows.size=2^d) :
    Gives (sourceTest input v) (benes d node rows) (fun out=>ArrayRel (RowRep v width) out
      (arrayRun (fun nd back i=>input (.switch nd back i)) d node bs)) :=
  benes_simulates _ _ (fun nd back j=>switched_rows input v unit (.switch nd back j))
    d node rows bs rel size

/-- For any actual list of 2048 records, fix named fresh switch inputs once.
The monadic numeric port then emits rows describing exactly the sorted records
under every satisfying circuit evaluation with those source values. -/
theorem emitted_can_sort {K : Type} [LinearOrder K] (key : Array Bool → K)
    (bs : Array (Array Bool)) (count : bs.size=2048) :
    ∃ (f : Bank) (p : Equiv.Perm (Fin 2048)) (sorted : Array (Array Bool)),
      Monotone (fun j=>key bs[(p j).val]!) ∧ sorted.size=2048 ∧
      (∀j,sorted[j.val]! = bs[(p j).val]!) ∧
      ∀ (input : Source → Bool) (_hl : ∀n back i,input (.switch n back i) = f n back i)
        (v : Nat → Bool), v 0=true → ∀ width rows, ArrayRel (RowRep v width) rows bs →
        Gives (sourceTest input v) (benes 11 1 rows) (fun out=>ArrayRel (RowRep v width) out sorted) := by
  obtain ⟨f,p,h,sz,pres⟩ := sort_array key bs count
  refine ⟨f,p,arrayRun f 11 1 bs,h,sz,pres,?_⟩
  intro input bankEq v unit width rows rep
  have eq : (fun n b i=>input (.switch n b i)) = f := by funext n b i; exact bankEq n b i
  simpa only [eq] using benes_records input v unit width 11 1 rows bs rep (rep.size.trans count)

#print axioms emitted_can_sort

end ExactWordFlow.CompactWordCircuit

import CompactGateLaws
import SatThreshold

namespace ExactWordFlow.CompactWordCircuit
open SatThreshold (value)

def nonzero (xs : List W) := ∀x∈xs,x≠0
def wvalue (v : Nat → Bool) (xs : List W) := value (xs.map (wire v))
def bitsOK (v : Nat → Bool) (value : Nat) (xs : List W) := nonzero xs ∧ wvalue v xs=value
def pairValue (v : Nat → Bool) : List (W×W) → Nat
  | [] => 0
  | (x,y)::xs => (wire v x).toNat + (wire v y).toNat + 2*pairValue v xs

def pairOK (xs : List (W×W)) := ∀p∈xs,p.1≠0 ∧ p.2≠0

theorem addWires_grows (xs : List (W×W)) (carry : W) : Grows (addWires xs carry) := by
  induction xs generalizing carry with
  | nil => exact pure_grows _
  | cons p xs ih =>
    obtain ⟨x,y⟩:=p
    rw [addWires]
    exact bind_grows (xor_grows x y) fun d=>
      bind_grows (xor_grows d carry) fun s=>
      bind_grows (mux_grows d carry x) fun c=>
      bind_grows (ih c) fun out=>pure_grows (s::out)

theorem addWires_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0 = true)
    (xs : List (W×W)) (carry : W) (nz : pairOK xs) (nc : carry≠0) :
    Gives T (addWires xs carry) (bitsOK v (pairValue v xs + (wire v carry).toNat)) := by
  induction xs generalizing carry with
  | nil =>
    apply pure_gives
    exact ⟨by simpa [nonzero] using nc,by simp [wvalue,pairValue,SatThreshold.value]⟩
  | cons p xs ih =>
    obtain ⟨x,y⟩:=p
    obtain ⟨nx,ny⟩:=nz (x,y) List.mem_cons_self
    have tail : pairOK xs := fun a ha=>nz a (List.mem_cons_of_mem _ ha)
    rw [addWires]
    refine bind_gives (m:=bitXor x y) (P:=Rep v (wire v x ^^ wire v y))
      (xor_grows _ _) (fun d=>bind_grows (xor_grows _ _) (fun s=>bind_grows (mux_grows _ _ _)
      (fun c=>bind_grows (addWires_grows _ _) (fun out=>pure_grows (s::out)))))
      (xor_gives law unit ⟨nx,rfl⟩ ⟨ny,rfl⟩) ?_
    intro d hd
    refine bind_gives (m:=bitXor d carry) (P:=Rep v ((wire v x ^^ wire v y) ^^ wire v carry))
      (xor_grows _ _) (fun s=>bind_grows (mux_grows _ _ _) (fun c=>bind_grows (addWires_grows _ _)
      (fun out=>pure_grows (s::out)))) (xor_gives law unit hd ⟨nc,rfl⟩) ?_
    intro s hs
    refine bind_gives (m:=mux d carry x) (P:=Rep v (if wire v x ^^ wire v y then wire v carry else wire v x))
      (mux_grows _ _ _) (fun c=>bind_grows (addWires_grows _ _) (fun out=>pure_grows (s::out)))
      (mux_gives law unit hd ⟨nc,rfl⟩ ⟨nx,rfl⟩) ?_
    intro c hc
    refine bind_gives (m:=addWires xs c) (P:=bitsOK v (pairValue v xs + (wire v c).toNat))
      (addWires_grows _ _) (fun out=>pure_grows (s::out)) (ih c tail hc.1) ?_
    intro out hout
    apply pure_gives
    refine ⟨?_,?_⟩
    · intro l hl
      rcases List.mem_cons.mp hl with rfl|hl
      · exact hs.1
      · exact hout.1 _ hl
    · change (wire v s).toNat + 2*wvalue v out = _
      rw [hout.2,hs.2,hc.2,pairValue]
      have bits:=SatThreshold.full_adder (wire v x) (wire v y) (wire v carry)
      simp only [SatThreshold.bit,SatThreshold.carryOut] at bits
      omega

private theorem aligned_value {v : Nat → Bool} (unit : v 0=true) (a b : List W) :
    pairValue v (aligned a b) = wvalue v a + wvalue v b := by
  induction a generalizing b with
  | nil =>
    induction b with
    | nil => rfl
    | cons y ys ih =>
      change (wire v (-1)).toNat+(wire v y).toNat+2*pairValue v (aligned [] ys) = 0+((wire v y).toNat + 2*wvalue v ys)
      rw [ih,(zero_rep unit).2]
      simp [wvalue,SatThreshold.value]
  | cons x xs ih =>
    cases b with
    | nil =>
      change (wire v x).toNat+(wire v (-1)).toNat+2*pairValue v (aligned xs []) = ((wire v x).toNat+2*wvalue v xs)+0
      rw [ih,(zero_rep unit).2]
      simp [wvalue,SatThreshold.value]
    | cons y ys =>
      change (wire v x).toNat+(wire v y).toNat+2*pairValue v (aligned xs ys) = ((wire v x).toNat+2*wvalue v xs)+((wire v y).toNat+2*wvalue v ys)
      rw [ih]
      omega

private theorem aligned_ok {a b : List W} (na : nonzero a) (nb : nonzero b) : pairOK (aligned a b) := by
  induction a generalizing b with
  | nil =>
    intro p hp
    obtain ⟨y,hy,rfl⟩:=List.mem_map.mp hp
    exact ⟨by change (-1:Int)≠0; decide,nb _ hy⟩
  | cons x xs ih =>
    have nx:=na x List.mem_cons_self
    have tx : nonzero xs := fun y hy=>na y (List.mem_cons_of_mem _ hy)
    cases b with
    | nil =>
      intro p hp
      rcases List.mem_cons.mp hp with rfl|hp
      · exact ⟨nx,by change (-1:Int)≠0; decide⟩
      · exact ih tx nb p hp
    | cons y ys =>
      intro p hp
      rcases List.mem_cons.mp hp with rfl|hp
      · exact ⟨nx,nb y List.mem_cons_self⟩
      · exact ih tx (fun l hl=>nb l (List.mem_cons_of_mem _ hl)) p hp

theorem add_aligned {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    {a b : List W} (na : nonzero a) (nb : nonzero b) :
    Gives T (addWires (aligned a b) (-1)) (bitsOK v (wvalue v a + wvalue v b)) := by
  simpa [aligned_value unit,(zero_rep unit).2] using
    addWires_gives law unit (aligned a b) (-1) (aligned_ok na nb) (by decide)


def rowsSum (v : Nat → Bool) (rows : List (List W)) := (rows.map (wvalue v)).sum
def rowsOK (rows : List (List W)) := ∀ row∈rows, nonzero row

theorem pairWires_grows (ws : List (List W)) : Grows (pairWires ws) := by
  induction ws using pairWires.induct with
  | case1 a b rest ih =>
    rw [pairWires]
    exact bind_grows (addWires_grows _ _) (fun sum=>bind_grows ih fun others=>pure_grows (sum::others))
  | case2 ls h => rw [pairWires]; exact pure_grows _; exact h

def pairedSummary (v : Nat → Bool) (ws out : List (List W)) :=
  rowsOK out ∧ rowsSum v out = rowsSum v ws ∧ out.length = (ws.length+1)/2

theorem pairWires_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    (ws : List (List W)) (valid : rowsOK ws) :
    Gives T (pairWires ws) (pairedSummary v ws) := by
  induction ws using pairWires.induct with
  | case1 a b rest ih =>
    have va := valid a List.mem_cons_self
    have vb := valid b (List.mem_cons_of_mem _ List.mem_cons_self)
    have tail : rowsOK rest := fun r hr=>valid r (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hr))
    rw [pairWires]
    refine bind_gives (m:=addWires (aligned a b) (-1)) (P:=bitsOK v (wvalue v a+wvalue v b))
      (addWires_grows _ _) (fun sum=>bind_grows (pairWires_grows _) (fun others=>pure_grows (sum::others)))
      (add_aligned law unit va vb) ?_
    intro sum hs
    refine bind_gives (m:=pairWires rest) (P:=pairedSummary v rest) (pairWires_grows _)
      (fun others=>pure_grows (sum::others)) (ih tail) ?_
    intro others ho
    apply pure_gives
    obtain ⟨ok,num,size⟩:=ho
    refine ⟨?_,?_,?_⟩
    · intro r hr
      rcases List.mem_cons.mp hr with rfl|hr
      · exact hs.1
      · exact ok r hr
    · change wvalue v sum + rowsSum v others = wvalue v a + (wvalue v b + rowsSum v rest)
      rw [hs.2,num,Nat.add_assoc]
    · simp only [List.length_cons,size]; omega
  | case2 ls h =>
    rw [pairWires]
    case x_1 => exact h
    apply pure_gives
    refine ⟨valid,rfl,?_⟩
    cases ls with
    | nil => rfl
    | cons a r =>
      cases r with
      | nil => simp
      | cons b r => exact (h a b r rfl).elim

theorem countWires_grows (fuel : Nat) (ws : List (List W)) : Grows (countWires fuel ws) := by
  induction fuel generalizing ws with
  | zero => cases ws with
            | nil => exact pure_grows _
            | cons a l => cases l <;> exact pure_grows _
  | succ n ih =>
    cases ws with
    | nil => exact pure_grows _
    | cons a l =>
      cases l with
      | nil => exact pure_grows _
      | cons b rest =>
        rw [countWires]
        exact bind_grows (pairWires_grows _) (ih)

theorem countWires_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    (fuel : Nat) (ws : List (List W)) (valid : rowsOK ws) (size : ws.length≤fuel+1) :
    Gives T (countWires fuel ws) (bitsOK v (rowsSum v ws)) := by
  induction fuel generalizing ws with
  | zero =>
    cases ws with
    | nil => exact pure_gives ⟨by simp [nonzero],rfl⟩
    | cons a rest =>
      cases rest with
      | nil => exact pure_gives ⟨valid a List.mem_cons_self,by simp [rowsSum]⟩
      | cons b rest => simp at size
  | succ fuel ih =>
    cases ws with
    | nil => exact pure_gives ⟨by simp [nonzero],rfl⟩
    | cons a rest =>
      cases rest with
      | nil => exact pure_gives ⟨valid a List.mem_cons_self,by simp [rowsSum]⟩
      | cons b rest =>
        rw [countWires]
        refine bind_gives (m:=pairWires (a::b::rest)) (P:=pairedSummary v (a::b::rest)) (pairWires_grows _)
          (fun next=>countWires_grows fuel next) (pairWires_gives law unit _ valid) ?_
        intro out ho
        obtain ⟨clean,num,len⟩:=ho
        rw [←num]
        apply ih out clean
        simp only [List.length_cons] at len size
        omega

theorem compareWires_grows (xs : List W) (k : Nat) (ge : W) : Grows (compareWires xs k ge) := by
  induction xs generalizing k ge with
  | nil => exact pure_grows _
  | cons x xs ih =>
    rw [compareWires]
    split
    · exact bind_grows (allGate_grows _) (ih (k/2))
    · exact bind_grows (anyGate_grows _) (ih (k/2))

theorem compareWires_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    (xs : List W) (k : Nat) (ge : W) (nz : nonzero xs) (ng : ge≠0) (room : k < 2^xs.length) :
    Gives T (compareWires xs k ge) (Rep v (SatThreshold.compareBits (xs.map (wire v)) k (wire v ge))) := by
  induction xs generalizing k ge with
  | nil =>
    have eq : k=0 := by simpa using room
    subst k
    exact pure_gives ⟨ng,by simp [SatThreshold.compareBits]⟩
  | cons x xs ih =>
    have nx:=nz x List.mem_cons_self
    have tail : nonzero xs := fun y hy=>nz y (List.mem_cons_of_mem _ hy)
    rw [compareWires]
    let bg := if k%2=1 then wire v x && wire v ge else wire v x || wire v ge
    have small : k/2 < 2^xs.length := by
      simp only [List.length_cons,Nat.pow_succ] at room
      omega
    have cont (next : W) (h : Rep v bg next) :
        Gives T (compareWires xs (k/2) next)
          (Rep v (SatThreshold.compareBits ((x::xs).map (wire v)) k (wire v ge))) := by
      have ev := ih (k/2) next tail h.1 small
      rw [h.2] at ev
      exact ev
    split
    next h =>
      exact bind_gives (P:=Rep v bg) (allGate_grows _) (fun next=>compareWires_grows xs (k/2) next)
        (by simpa [bg,h] using and2_gives law unit (a:=x) (b:=ge) ⟨nx,rfl⟩ ⟨ng,rfl⟩) cont
    next h =>
      exact bind_gives (P:=Rep v bg) (anyGate_grows _) (fun next=>compareWires_grows xs (k/2) next)
        (by simpa [bg,h] using or2_gives law unit (a:=x) (b:=ge) ⟨nx,rfl⟩ ⟨ng,rfl⟩) cont

private theorem value_range (xs : List Bool) : value xs < 2^xs.length := by
  induction xs with
  | nil => decide
  | cons b xs ih => cases b <;> simp only [SatThreshold.value,Bool.toNat_false,Bool.toNat_true,List.length_cons,Nat.pow_succ] <;> omega

theorem threshold_grows (flags : Bits) (k : Nat) : Grows (threshold flags k) := by
  rw [threshold]
  apply bind_grows (countWires_grows _ _)
  intro digits
  split
  · exact pure_grows _
  · exact compareWires_grows _ _ _

theorem threshold_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    (flags : Bits) (k : Nat) (nz : nonzero flags.toList) :
    Gives T (threshold flags k) (Rep v (decide (k ≤ (flags.toList.map (wire v)).count true))) := by
  unfold threshold
  let ws:=flags.toList.map (fun x=>[x])
  have good : rowsOK ws := by
    intro r hr
    obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hr
    simpa [nonzero] using nz x hx
  have exactSize : ws.length ≤ flags.size+1 := by simp [ws]
  have total (xs : List W) : rowsSum v (xs.map (fun x=>[x])) = (xs.map (wire v)).count true := by
    induction xs with
    | nil => rfl
    | cons x xs ih =>
      change wvalue v [x] + rowsSum v (xs.map (fun x=>[x])) = _
      rw [ih]
      cases h : wire v x <;> simp [wvalue,SatThreshold.value,h,Nat.add_comm]
  refine bind_gives (P:=bitsOK v (rowsSum v ws)) (countWires_grows _ _) ?_
    (countWires_gives law unit flags.size ws good exactSize) ?_
  · intro ds
    split
    · exact pure_grows _
    · exact compareWires_grows _ _ _
  · intro ds info
    have valEq := info.2.trans (total _)
    split
    next h =>
      have lim := value_range (ds.map (wire v))
      rw [←wvalue,List.length_map,valEq] at lim
      have fail : ¬ k ≤ (flags.toList.map (wire v)).count true := by omega
      simpa [fail] using (pure_gives (T:=T) (zero_rep unit))
    next h =>
      have c := compareWires_gives law unit ds k 1 info.1 (by decide) (Nat.lt_of_not_ge h)
      have equ : SatThreshold.compareBits (ds.map (wire v)) k (wire v 1) =
          decide (k ≤ (flags.toList.map (wire v)).count true) := by
        apply Bool.eq_iff_iff.mpr
        rw [SatThreshold.compareBits_iff,←wvalue,valEq,wire_one,unit]
        simp only [and_true,decide_eq_true_eq]
        omega
      rwa [equ] at c

#print axioms threshold_gives
end ExactWordFlow.CompactWordCircuit

import WheelTable
import Cap93LookCore
import Cap93RowsChecked
import Cap93Hard
import OrientedCNF

namespace ExactWordFlow.Cap93Lookup
open private baseGood from NearBindingCheck
open SevenWordWindows RotationCore NearRootMoves ExtremeWheelCut NearWheelBinding Cap93Catalog
open Cap94Lookup (bits known board_of_known eq_shift unshift)

theorem no_cover {R : Finset Block} (accepted : accept R=true)
    {W : Finset (Finset Block)} (leg : W⊆allRows) (size : W.card≤93) :
    ¬SeedWheelCut.ClosedCover R allClasses W := by
  intro cover
  unfold accept at accepted
  generalize lookup.getD (bits 0 R) (rows.size,7)=ij at accepted
  rcases ij with ⟨i,j⟩
  obtain ⟨hi,hj,eq,knownR⟩:=of_decide_eq_true accepted
  exact WheelTable.reject 93 Cap93Data.hard (by decide) (fun _ m=>Cap93Hard.unsat m)
    rows rows_ok hi hj eq knownR leg size cover

#print axioms no_cover
end ExactWordFlow.Cap93Lookup

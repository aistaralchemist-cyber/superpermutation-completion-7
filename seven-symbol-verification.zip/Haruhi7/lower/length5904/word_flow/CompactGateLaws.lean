import CompactTraverse

namespace ExactWordFlow.CompactWordCircuit

theorem anyGate_grows (xs : List W) : Grows (anyGate xs) := by
  unfold anyGate
  dsimp only
  split
  · exact pure_grows _
  · split
    · exact pure_grows _
    · exact pure_grows _
    · exact alloc_grows _ (by simp)

theorem allGate_grows (xs : List W) : Grows (allGate xs) :=
  bind_grows (anyGate_grows _) (fun x=>pure_grows (-x))

theorem mux_grows (c a b : W) : Grows (mux c a b) := by
  unfold mux
  repeat' first | split | exact pure_grows _ | exact anyGate_grows _ | exact alloc_grows _ (by simp)

theorem xor_grows (a b : W) : Grows (bitXor a b) := by
  unfold bitXor
  repeat' first | split | exact pure_grows _ | exact mux_grows _ _ _

/-- A stronger tape test may additionally fix the values at named input events. -/
def IsGate (e : Event) := ∀xs, e ≠ .assertion xs
def Quiet (m : M α) := ∀ st, ∀ e∈(m st).2.body.toList.drop st.body.size, IsGate e
theorem pure_quiet (x : α) : Quiet (pure x) := by
  intro st e he
  change e∈st.body.toList.drop st.body.toList.length at he
  rw [List.drop_of_length_le (Nat.le_refl _)] at he
  contradiction
theorem alloc_quiet (e : Event) (h : IsGate e) : Quiet (alloc e) := by
  intro st g hg
  have eq : g=e := by simpa [alloc] using hg
  exact eq ▸ h
theorem any_quiet (xs : List W) : Quiet (anyGate xs) := by
  unfold anyGate
  dsimp only
  split
  · exact pure_quiet _
  · split
    · exact pure_quiet _
    · exact pure_quiet _
    · exact alloc_quiet _ (by simp [IsGate])
theorem all_quiet (xs : List W) : Quiet (allGate xs) := any_quiet _
theorem mux_quiet (c a b : W) : Quiet (mux c a b) := by
  unfold mux
  repeat' first | split | exact pure_quiet _ | exact any_quiet _ | exact alloc_quiet _ (by simp [IsGate])
theorem xor_quiet (a b : W) : Quiet (bitXor a b) := by
  unfold bitXor
  repeat' first | split | exact pure_quiet _ | exact mux_quiet _ _ _

def ModelsGates (T : Test) (v : Nat → Bool) :=
  ∀ n e, IsGate e → T n e → gateMeaning v (Int.ofNat (n+1)) e

theorem admits_meaning {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (n : Nat) (xs : List Event)
    (quiet : ∀e∈xs,IsGate e) (ok : admits T n xs) : tailMeaning v n xs := by
  induction xs generalizing n with
  | nil => trivial
  | cons e xs ih => exact ⟨law n e (quiet e List.mem_cons_self) ok.1,ih _ (fun f hf=>quiet f (List.mem_cons_of_mem _ hf)) ok.2⟩

theorem source_models (input : Source → Bool) (v : Nat → Bool) :
    ModelsGates (sourceTest input v) v := by
  intro n e quiet h
  cases e with
  | fresh _ => trivial
  | assertion xs => exact (quiet xs rfl).elim
  | gateOr _ => exact h
  | gateMux _ _ _ => exact h

def Rep (v : Nat → Bool) (b : Bool) (x : W) := x≠0 ∧ wire v x=b

theorem lift_primitive {T : Test} {v : Nat → Bool} (law : ModelsGates T v) {m : M W} {b : Bool}
    (quiet : Quiet m) (localLaw : ∀st, realizes m st v b) : Gives T m (Rep v b) :=
  fun st valid => ⟨(localLaw st).1,(localLaw st).2 (admits_meaning law _ _ (quiet st) valid)⟩

theorem zero_rep {v : Nat → Bool} (unit : v 0=true) : Rep v false (-1) :=
  ⟨by decide,by simp [wire,unit]⟩

theorem one_rep {v : Nat → Bool} (unit : v 0=true) : Rep v true 1 :=
  ⟨by decide,unit⟩

theorem xor_gives {T : Test} {v : Nat → Bool} {a b : W} {x y : Bool}
    (law : ModelsGates T v) (unit : v 0=true) (ha : Rep v x a) (hb : Rep v y b) :
    Gives T (bitXor a b) (Rep v (x ^^ y)) := by
  rw [←ha.2,←hb.2]
  exact lift_primitive law (xor_quiet _ _) fun st=>bitXor_realizes _ _ st v unit ha.1 hb.1

theorem mux_gives {T : Test} {v : Nat → Bool} {s a b : W} {i x y : Bool}
    (law : ModelsGates T v) (unit : v 0=true) (hs : Rep v i s) (ha : Rep v x a) (hb : Rep v y b) :
    Gives T (mux s a b) (Rep v (if i then x else y)) := by
  rw [←hs.2,←ha.2,←hb.2]
  exact lift_primitive law (mux_quiet _ _ _) fun st=>mux_realizes _ _ _ st v unit hs.1 ha.1 hb.1

theorem or2_gives {T : Test} {v : Nat → Bool} {a b : W} {x y : Bool}
    (law : ModelsGates T v) (unit : v 0=true) (ha : Rep v x a) (hb : Rep v y b) :
    Gives T (anyGate [a,b]) (Rep v (x||y)) := by
  apply lift_primitive law (any_quiet _)
  intro st
  simpa [ha.2,hb.2] using anyGate_realizes [a,b] st v unit (by simpa using And.intro ha.1 hb.1)

theorem and2_gives {T : Test} {v : Nat → Bool} {a b : W} {x y : Bool}
    (law : ModelsGates T v) (unit : v 0=true) (ha : Rep v x a) (hb : Rep v y b) :
    Gives T (allGate [a,b]) (Rep v (x&&y)) := by
  apply lift_primitive law (all_quiet _)
  intro st
  simpa [ha.2,hb.2] using allGate_realizes [a,b] st v unit (by simpa using And.intro ha.1 hb.1)

end ExactWordFlow.CompactWordCircuit

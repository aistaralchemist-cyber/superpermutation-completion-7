import FusedPacked
import WheelBitsFacts

namespace ExactWordFlow.DirectStarMask
open SevenWordWindows RotationCore ResidualDensity ExtremeWheelCut
open WheelContacts (wheel)
open Cap94Lookup (code bits)
abbrev Row := Finset Block

private def decode (s : String) : Block := s.toList.map (fun c=>Fin.ofNat 7 (c.toNat-'0'.toNat))

-- The order affects only early termination of the finite check.
def tests : List Block := (["0123654", "0125436", "0153624", "0621354", "0451236", "0623451", "0126453", "0154236", "0461235", "0521634", "0263541", "0534612", "0654213", "0153264", "0645321", "0632154", "0435621", "0251463", "0436125", "0342615", "0631524", "0643512", "0523146", "0624315", "0216345", "0346512", "0463251", "0164352", "0341526", "0126534", "0134265", "0563241", "0423516", "0365124", "0132645", "0314256", "0246351", "0426531", "0312456", "0236145", "0312564"].map decode)

def shape (c : Block) (a : Fin 7) := wheel (c.erase a)
def rowCode (r : Row) := r.image code

private theorem legalTests : ∀c∈tests,c∈allClasses ∧
    (∀a : Fin 7,shape c a⊆allClasses) ∧
    ∀r∈allRows,c∈r → ∃a : Fin 7,shape c a=r := by native_decide

def table := tests.map (fun c=>(code c,(List.finRange 7).map (fun a=>rowCode (shape c a))))

def acc (m : Nat) : Bool :=
  table.any fun (i,rows)=> !m.testBit i && rows.all
    (fun r=>decide ((r.filter (fun j=>m.testBit j)).card ≠ 1))

def accept (R : Row) := acc (bits 0 R)

open private entries bit_spec code_inj from Cap94Encoding
private theorem reads {A : Row} (boardA : A⊆allClasses) {c : Block} (boardC : c∈allClasses) :
    (bits 0 A).testBit (code c)=true ↔ c∈A := by
  apply Iff.trans (bit_spec A 0 boardA (code c))
  constructor
  · rintro ⟨p,pa,h⟩
    have eq : p=c:=code_inj (boardA pa) boardC h
    exact eq ▸ pa
  · intro h
    exact ⟨c,h,rfl⟩

private theorem counts {A R : Row} (boardA : A⊆allClasses) (boardR : R⊆allClasses) :
    ((rowCode R).filter (fun i=>(bits 0 A).testBit i)).card=(A∩R).card := by
  have eq : (rowCode R).filter (fun i=>(bits 0 A).testBit i)=(A∩R).image code := by
    ext j
    constructor
    · intro h
      obtain ⟨inRow,marked⟩:=Finset.mem_filter.mp h
      obtain ⟨c,cr,rfl⟩:=Finset.mem_image.mp inRow
      exact Finset.mem_image.mpr ⟨c,Finset.mem_inter.mpr ⟨(reads boardA (boardR cr)).mp marked,cr⟩,rfl⟩
    · intro h
      obtain ⟨c,inter,rfl⟩:=Finset.mem_image.mp h
      obtain ⟨ca,cr⟩:=Finset.mem_inter.mp inter
      exact Finset.mem_filter.mpr ⟨Finset.mem_image_of_mem _ cr,(reads boardA (boardR cr)).mpr ca⟩
  rw [eq,Finset.card_image_of_injOn]
  intro x hx y hy xy
  exact code_inj (boardR (Finset.mem_inter.mp hx).2) (boardR (Finset.mem_inter.mp hy).2) xy

theorem reject {R : Finset Block} (boardR : R⊆allClasses) (yes : accept R=true) :
    ∃c∈allClasses,c∉R ∧ ∀row∈allRows,c∈row → (R∩row).card≠1 := by
  obtain ⟨p,pt,valid⟩:=List.any_eq_true.mp yes
  obtain ⟨c,ct,rfl⟩:=List.mem_map.mp pt
  obtain ⟨boardC,inside,inc⟩:=legalTests c ct
  obtain ⟨miss,off⟩:=Bool.and_eq_true_iff.mp valid
  refine ⟨c,boardC,fun hc=>?_,?_⟩
  · have h:=(reads boardR boardC).mpr hc
    simp [h] at miss
  · intro row hrow cRow
    obtain ⟨a,rfl⟩:=inc row hrow cRow
    have mem : a∈List.finRange 7:=by simp
    have test:=List.all_eq_true.mp off _ (List.mem_map_of_mem (f:=fun a=>rowCode (shape c a)) mem)
    have sound:=of_decide_eq_true test
    rwa [counts boardR (inside a)] at sound

#print axioms reject
end ExactWordFlow.DirectStarMask

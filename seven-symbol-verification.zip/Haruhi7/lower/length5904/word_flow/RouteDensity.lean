import DensityBudget
import WordFlow

namespace ResidualDensity
open ExactWordFlow DirectedEuler

def touched (xs : List Six) : Finset Six := ((xs.filter (fun s => decide (full s))).map tag).toFinset
def positions (u : ℕ → Six) (n : ℕ) := (List.range n).map u
def classCount (s : Six) (es : List Six) := (touched (s::es.map dst)).card

private theorem edge_step {e : Six} (h : e.length=7) : ∃ a, dst e=step (src e) a := by
  cases e with
  | nil => simp at h
  | cons v vs =>
    have hl : vs.length=6 := by simpa using h
    have nn : vs ≠ [] := by intro hh; simp [hh] at hl
    refine ⟨vs.getLast nn,?_⟩
    change vs = vs.take 5 ++ [vs.getLast nn]
    rw [show vs.take 5=vs.dropLast by rw [List.dropLast_eq_take,hl]]
    exact (List.dropLast_concat_getLast nn).symm

/-- The finite route is precisely the initial segment of an infinite overlapping walk.
Only the irrelevant suffix is extended with zeroes. -/
theorem route_walk {s t : Six} {es : List Six} (route : Route src dst s es t)
    (widths : ∀ e∈es, e.length=7) :
    ∃ u : ℕ → Six, Walk u ∧ u 0=s ∧ u es.length=t ∧
      positions u (es.length+1)=s::es.map dst := by
  induction route with
  | nil s =>
    let u : ℕ → Six := Nat.rec s (fun _ v => step v 0)
    exact ⟨u,fun _ => ⟨0,rfl⟩,rfl,rfl,by simp [positions,u]⟩
  | @cons s t es e he tail ih =>
    obtain ⟨v,hv,h0,he',hx⟩ := ih (fun z hz => widths z (List.mem_cons_of_mem _ hz))
    let u : ℕ → Six | 0 => s | k+1 => v k
    refine ⟨u,?_,rfl,he',?_⟩
    · intro i
      cases i with
      | zero =>
        change ∃ a, v 0 = step s a
        rw [h0,←he]
        exact edge_step (widths e List.mem_cons_self)
      | succ i => exact hv i
    · change (List.range ((es.length+1)+1)).map u = s::dst e::es.map dst
      rw [List.range_succ_eq_map]
      simp only [List.map_cons,List.map_map]
      exact congrArg (s::·) hx

private theorem select (u : ℕ → Six) (n : ℕ) :
    ∃ I : Finset ℕ, Marked u (·∈I) ∧ count (·∈I) 0 n=(touched (positions u n)).card := by
  classical
  let T := touched (positions u n)
  have pick (c : T) : ∃ j, j<n ∧ full (u j) ∧ tag (u j)=c.val := by
    obtain ⟨s,hs,eq⟩ := List.mem_map.mp (List.mem_toFinset.mp c.property)
    obtain ⟨mem,fl⟩ := List.mem_filter.mp hs
    obtain ⟨j,hj,rfl⟩ := List.mem_map.mp mem
    exact ⟨j,List.mem_range.mp hj,of_decide_eq_true fl,eq⟩
  choose f hf hfull htag using pick
  let I : Finset ℕ := Finset.univ.image f
  have iffmem (i : ℕ) : i∈I ↔ ∃ z, f z=i := by simp [I]
  refine ⟨I,⟨?_,?_⟩,?_⟩
  · intro i hi
    obtain ⟨z,rfl⟩ := (iffmem i).mp hi
    exact hfull z
  · intro i j hi hj eq
    obtain ⟨a,rfl⟩ := (iffmem i).mp hi
    obtain ⟨b,rfl⟩ := (iffmem j).mp hj
    rw [htag,htag] at eq
    exact congrArg f (Subtype.ext eq)
  · have small : (Finset.range n).filter (fun j => j∈I) = I := by
      ext j
      simp only [Finset.mem_filter,Finset.mem_range,and_iff_right_iff_imp]
      intro hj
      obtain ⟨c,rfl⟩ := (iffmem j).mp hj
      exact hf _
    have inj : Function.Injective f := by
      intro a b eq
      exact Subtype.ext ((htag a).symm.trans ((congrArg (tag ∘ u) eq).trans (htag b)))
    simp only [count,Nat.zero_add,small]
    simp [I,Finset.card_image_of_injective _ inj,T]

theorem open_route_gain_24 {s t : Six} {es : List Six} (route : Route src dst s es t)
    (widths : ∀ e∈es, e.length=7) (gain : 5*es.length+30≤6*classCount s es) :
    156 ≤ es.length := by
  obtain ⟨u,wu,_,_,eq⟩ := route_walk route widths
  obtain ⟨I,hm,hc⟩ := select u (es.length+1)
  rw [eq] at hc
  exact open_gain_24 wu hm 0 es.length _ hc gain

private theorem per_walk {u : ℕ → Six} (walk : Walk u) {k : ℕ} (pos : 0<k)
    (close : u k=u 0) : Walk (fun i => u (i%k)) := by
  intro i
  have lo := Nat.mod_lt i pos
  obtain ⟨a,ha⟩ := walk (i%k)
  refine ⟨a,?_⟩
  change u ((i+1)%k)=step (u (i%k)) a
  rw [←Nat.mod_add_mod]
  by_cases lt : i%k+1 < k
  · simpa [Nat.mod_eq_of_lt lt] using ha
  · have eq : i%k+1=k := by omega
    simpa [eq,close] using ha

/-- Choose one occurrence for each clean rotation class met by the closed route;
the choices repeat periodically on the circle. -/
theorem closed_observations {s : Six} {es : List Six} (route : Route src dst s es s)
    (widths : ∀ e∈es, e.length=7) (positive : 0<es.length) :
    ∃ (u : ℕ → Six) (I : Finset ℕ), Walk u ∧
      CyclicMarked u (fun i => i%es.length∈I) es.length ∧
      count (fun i => i%es.length∈I) 0 es.length=classCount s es := by
  classical
  obtain ⟨u,walk,h0,hk,eq⟩ := route_walk route widths
  let k := es.length
  have pos : 0<k := positive
  have endeq : u k=u 0 := hk.trans h0.symm
  have t : touched (positions u (k+1))=touched (positions u k) := by
    have first : u 0 ∈ positions u k :=
      List.mem_map.mpr ⟨0, List.mem_range.mpr pos,rfl⟩
    ext z
    simp only [touched,List.mem_toFinset,List.mem_map,List.mem_filter,decide_eq_true_eq,
      positions,List.range_succ,List.map_append,List.map_cons,List.map_nil,
      List.mem_append,List.mem_singleton] at *
    constructor
    · rintro ⟨x,⟨h|ex,ff⟩,id⟩
      · exact ⟨x,⟨h,ff⟩,id⟩
      · subst x
        exact ⟨u 0,⟨first,by simpa [endeq] using ff⟩,by simpa [endeq] using id⟩
    · rintro ⟨x,⟨h,ff⟩,id⟩; exact ⟨x,⟨Or.inl h,ff⟩,id⟩
  obtain ⟨I,hm,hc⟩ := select u k
  let p (i : Nat) := i%k ∈ I
  have cy : CyclicMarked (fun i => u (i%k)) p k := by
    refine ⟨fun i => by simp [p], fun i hi => hm.1 _ hi,?_⟩
    intro i j ij near pi pj eq
    have same : i%k=j%k := hm.2 _ _ pi pj eq
    exact le_antisymm ij (Nat.ModEq.le_of_lt_add (show j ≡ i [MOD k] from same.symm) near)
  have cc : count p 0 k=count (·∈I) 0 k := by
    unfold count
    congr 1
    ext j
    simp only [Finset.mem_filter,Finset.mem_range,Nat.zero_add,p]
    by_cases jj : j<k <;> simp [jj,Nat.mod_eq_of_lt]
  refine ⟨_,I,per_walk walk pos endeq,cy,?_⟩
  change count p 0 k=classCount s es
  rw [cc,hc,←t,eq]
  rfl
 
theorem open_observations {s t : Six} {es : List Six} (route : Route src dst s es t)
    (widths : ∀ e∈es, e.length=7) :
    ∃ (u : ℕ → Six) (I : Finset ℕ), Walk u ∧ Marked u (·∈I) ∧
      count (·∈I) 0 (es.length+1)=classCount s es := by
  obtain ⟨u,walk,_,_,eq⟩ := route_walk route widths
  obtain ⟨I,hp,cc⟩ := select u (es.length+1)
  rw [eq] at cc
  exact ⟨u,I,walk,hp,cc⟩

theorem closed_route_gain {s : Six} {es : List Six} (route : Route src dst s es s)
    (widths : ∀ e∈es, e.length=7) (short : es.length≤60) :
    6*classCount s es ≤ 5*es.length+6 := by
  by_cases pos : 0<es.length
  · obtain ⟨u,I,w,hp,cc⟩ := closed_observations route widths pos
    exact cc ▸ short_cycle_gain w hp short
  · have zero : es=[] := List.length_eq_zero_iff.mp (by omega)
    subst es
    simp only [classCount,List.map_nil,touched,List.length_nil,Nat.mul_zero,Nat.zero_add]
    by_cases hh : full s <;> simp [hh]

end ResidualDensity
#print axioms ResidualDensity.open_route_gain_24
#print axioms ResidualDensity.closed_route_gain

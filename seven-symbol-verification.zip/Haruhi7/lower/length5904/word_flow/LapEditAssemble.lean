import LapEditContexts
import LapReached
import LocalTagCounts
import LapBudget

namespace ExactWordFlow.LapEditAssemble
open SevenWordWindows RotationCore RotationCoreControls LapEditContexts LapDeletionShadow LocalDeletion

theorem member {ts w ps} (r : Render ts w ps) : ∀p∈ps,p∈ts.filterMap Tile.skip := by
  induction r with
  | nil=>simp
  | keep t rest ih=>
    intro p hp
    have old:=ih p hp
    cases may : t.skip <;> simp [List.filterMap_cons,may,old]
  | passLap may _ ih=>
    intro p hp
    rcases List.mem_cons.mp hp with rfl|prev
    · simp [List.filterMap_cons,may]
    · simp [List.filterMap_cons,may,ih _ prev]

private theorem selected {S w ps} (r : Cuts S ps w) : ∀p∈ps,p∈representatives := by
  induction r with
  | stop=>simp
  | remove hp rest ih=>
    intro p mem
    rcases List.mem_cons.mp mem with rfl|tail
    · exact hp
    · exact ih p tail

theorem spell_length {S w ps} (r : Cuts S ps w) : S.length=w.length+7*ps.length := by
  induction r with
  | stop=>simp
  | remove hp rest ih=>
    have len:=((mem_reps _).mp hp).1
    simp only [List.length_append,List.length_cons] at ih ⊢
    omega

theorem erase_center (l : Block) (x : Fin 7) (r : Block) :
    (l++[x]++r).eraseIdx l.length=l++r := by
  rw [List.append_assoc,List.eraseIdx_append_of_length_le (le_refl _)]
  simp

/-- The only two possible failures are a missing permutation window or the
last surviving visit to a genuinely selected rotation class. -/
theorem from_loss {base w z : Block} {ps : List Block} (cut : Cuts base ps w)
    (sourceGood : (good base).length=5040)
    (eight : ∀p∈ps,(LapMultiplicity.tags base).count (classKey p)=8)
    (loss : (good z).length<(good w).length ∨
      ∃p∈ps,freq6 z (classKey p)<freq6 w (classKey p))
    (all : (visited z).card=720) : (complete z).card+ps.length<720 := by
  rcases loss with fewer|⟨p,present,moved⟩
  · have size:=LapMultiplicity.good_after cut
    rw [sourceGood] at size
    have need:=LapSkeleton.completed_floor z
    omega
  · have before:=eight p present
    have counted:=LapMultiplicity.count_after cut (classKey p)
    have occurs:=List.count_pos_iff.mpr (List.mem_map_of_mem (f:=classKey) present)
    have alive:=LapMultiplicity.reached z all (selected cut p present)
    rw [frequency_eq,frequency_eq] at moved
    omega

#print axioms from_loss
end ExactWordFlow.LapEditAssemble

import CompactWitness
import CompactGateLaws

namespace ExactWordFlow.CompactWordCircuit

/-- A phase runs with the actual global variable counter and a local event log. -/
structure Piece where
  base : Nat
  log : Array Event
  deriving Inhabited

structure Stage (α : Type) extends Piece where
  out : α
  top : Nat
  deriving Inhabited

def stage (base : Nat) (m : M α) : Stage α :=
  let r := m ⟨base,#[]⟩
  ⟨⟨base,r.2.body⟩,r.1,r.2.vars⟩

theorem stage_gives {T : Test} {m : M α} {P : α → Prop} {base : Nat}
    (good : Gives T m P) (adm : admits T base (stage base m).log.toList) :
    P (stage base m).out := by
  exact good ⟨base,#[]⟩ (by simpa [stage] using adm)

def assertionsOf (cols : Rows) : List (List W) :=
  [([1] : List W)] ++ cols.toList.flatMap fun row =>
    row.toList :: (List.range 7).flatMap fun a =>
      ((List.range 7).drop (a+1)).map fun b=>[-row[a]!,-row[b]!]

def columnPhase : M Rows := do
  let one ← alloc (.fresh .one)
  insist [one]
  let cols ← (Array.range 1501).mapM fun i =>
    (Array.range 7).mapM fun a => alloc (.fresh (.symbol i a))
  for row in cols do
    insist row.toList
    for a in [:7] do
      for b in [a+1:7] do insist [-row[a]!, -row[b]!]
  return cols

def frontPhase (cols : Rows) : M (Rows × Bits × Bits) := do
  let bits ← cols.mapM fun row => binary row 3
  frontSeven cols bits 1501 true

def startPhase (clean hits : Bits) : M Bits := do
  let ends ← (Array.range hits.size).mapM fun i=>allGate [clean[i+1]!, -hits[i]!]
  return #[clean[0]!]++ends

def capped (flags : Bits) (k : Nat) : M W := do
  let x ← threshold flags k
  insist [x]
  return x

def padded (rows : Rows) := rows ++ Array.replicate 552 (#[1] ++ Array.replicate 25 (-1 : W))

structure Layout where
  cols : Stage Rows
  front : Stage (Rows × Bits × Bits)
  heads : Stage Bits
  startsLimit : Stage W
  winsLimit : Stage W
  cleanLimit : Stage W
  bank : Stage Rows
  adj : Stage (List (W × W))
  groups : Stage (List (W × W))
  visitLimit : Stage W
  doneLimit : Stage W
  deriving Inhabited

/-- Independent cuts between proofs. Equality below checks original order,
including the adjacency assertion between the comparator and its equality gate. -/
def layout : Layout := Id.run do
  let cols := stage 0 columnPhase
  let front := stage cols.top (frontPhase cols.out)
  let heads := stage front.top (startPhase front.out.2.1 front.out.2.2)
  let a := stage heads.top (capped heads.out 720)
  let b := stage a.top (capped front.out.2.2 637)
  let c := stage b.top (capped front.out.2.1 1357)
  let bank := stage c.top (benes 11 1 (padded front.out.1))
  let adj := stage bank.top (adjacentRows 19 bank.out.toList)
  let groups := stage adj.top
    (groupRows 7 19 bank.out.toList ((-1)::adj.out.map Prod.snd) (Array.replicate 7 (-1)))
  let visit := stage groups.top (capped (groups.out.map Prod.fst).toArray 720)
  let doneF := stage visit.top (capped (groups.out.map Prod.snd).toArray 91)
  return ⟨cols,front,heads,a,b,c,bank,adj,groups,visit,doneF⟩

def Layout.pieces (l : Layout) : List Piece :=
  [l.cols.toPiece,l.front.toPiece,l.heads.toPiece,l.startsLimit.toPiece,l.winsLimit.toPiece,
    l.cleanLimit.toPiece,l.bank.toPiece,l.adj.toPiece,l.groups.toPiece,l.visitLimit.toPiece,l.doneLimit.toPiece]

def Layout.clauses (l : Layout) : List (List W) :=
  assertionsOf l.cols.out ++ [[l.startsLimit.out],[l.winsLimit.out],[l.cleanLimit.out]] ++
    l.adj.out.map (fun p=>[p.1]) ++ [[l.visitLimit.out],[l.doneLimit.out]]

def alignedAt : Nat → List Piece → Bool
  | _, [] => true
  | i, p::ps => decide (p.base=i) && alignedAt (p.log.foldl advance i) ps

theorem all_parts {T : Test} {ps : List Piece} {n : Nat}
    (alignment : alignedAt n ps = true) (admissible : admits T n (ps.flatMap (fun p=>p.log.toList))) :
    ∀p∈ps, admits T p.base p.log.toList := by
  induction ps generalizing n with
  | nil => simp
  | cons p ps ih =>
    obtain ⟨base,next⟩:=Bool.and_eq_true_iff.mp alignment
    obtain ⟨front,rest⟩:=(admits_append ..).mp admissible
    have off : p.base=n := of_decide_eq_true base
    have go := ih (n:=p.log.foldl advance n) next (by simpa only [List.flatMap_def, Array.foldl_toList] using rest)
    intro q hq
    rcases List.mem_cons.mp hq with rfl|later
    · simpa only [off] using front
    · exact go _ later

end ExactWordFlow.CompactWordCircuit

import Cap95Profiles
import Cap94Shape

namespace ExactWordFlow.NoRoot265
open SevenWordWindows ResidualDensity DirectedEuler ResidualRoutes ResidualIncidence RotationComponentCount
open MarkedGeometry Cap95Marked
open private optimal maximizer from Cap95Profiles
open private initial start from MarkedDensity
open private submask from MarkedGeometry
open private unmask from StrongerDensity
open private canonical normalize from Interval66
open private search_complete from Geometry40
open private hits from NearHundredShape

private def core : List Nat :=
  [6,6,6,4,6,6,6,4,6,6,4,6,6,6,4,6,6,4,6,6,6,4,6,6,4,6,6,6,4,6,6,4,6,6,6,4]
private def front := rowsMask [6] ++ [false]
private def back := false :: rowsMask [6,6,6,6]

private def maskCheck : Bool :=
  upper 266 initial == 226 && (optimal 266 initial).all
    (fun z => z == front ++ rowsMask core ++ back)

private def rowsCheck : Bool :=
  core.all (fun n=>decide (0<n)) && canonical.all (fun v=>!rowSearch core v [])

private theorem maskData : maskCheck=true := by native_decide
private theorem rowsData : rowsCheck=true := by native_decide

/-- The unique relaxed maximizer has a 231-position subword that cannot
be spelled with distinct marked rotation classes in actual six-letter contexts. -/
theorem marks (u : Nat→Six) (p : Nat→Prop) [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i : Nat) : count p i 266 ≤ 225 := by
  by_contra! many
  obtain ⟨high,all⟩:=Bool.and_eq_true_iff.mp maskData
  have highN : upper 266 initial=226 := eq_of_beq high
  let bs:=mask p i 266
  have len : bs.length=266 := by simp [bs,mask]
  have bound : upper bs.length initial≤bs.count true := by
    rw [len,highN,mark_count]
    omega
  have hit:=maximizer [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i 266) bound
  rw [len] at hit
  have pat : bs=front++rowsMask core++back := eq_of_beq (List.all_eq_true.mp all _ hit)
  have lm := submask i 266 front (rowsMask core) back pat.symm
  have marked := unmask _ _ core lm
  have first : p (i+front.length) := by
    simpa only [Nat.add_zero] using marked.1 0 (by decide : 0<6)
  obtain ⟨v,vw,vm,iv⟩:=normalize w m _ first
  obtain ⟨positive,denied⟩:=Bool.and_eq_true_iff.mp rowsData
  have nz (n) (mem : n∈core) : 0<n := of_decide_eq_true (List.all_eq_true.mp positive n mem)
  have yes := search_complete vw vm core nz _ marked [] (by simp)
  have no := List.all_eq_true.mp denied _ iv
  simp only [yes,Bool.not_true,Bool.false_eq_true] at no

/-- Every actual 265-edge path, with arbitrary endpoints, meets at most 225 distinct rotation classes. -/
theorem route {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀e∈es,e.length=7) (len : es.length=265) : classCount s es≤225 := by
  obtain ⟨u,I,walk,mark,eq⟩:=open_observations r wd
  rw [len] at eq
  exact eq ▸ marks u (·∈I) walk mark 0

/-- At 94 non-start components, only the 294-edge start and 94 full wheels survive. -/
theorem shape {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤858)
    (n : (occupied X s).card=94) :
    X.card=858 ∧ (part X (label X s)).card=294 ∧ hits X s (label X s)=250 ∧
    ∀q∈occupied X s,(part X q).card=6 := by
  obtain ⟨size,poss⟩:=Cap94Shape.shape h bd n
  refine ⟨size,poss.resolve_right ?_⟩
  rintro ⟨root,count,_⟩
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len : es.length=265:=(congrArg Multiset.card bag).trans root
  have wd (e) (he : e∈es) := h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have low : hits X s (label X s)≤classCount s es := contacts_bound _ lv r bag
  have cap:=route r wd len
  omega

#print axioms route
#print axioms shape
end ExactWordFlow.NoRoot265

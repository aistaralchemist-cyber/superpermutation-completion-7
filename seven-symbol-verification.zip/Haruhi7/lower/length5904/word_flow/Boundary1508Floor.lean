import LowerBounds.PFinalK16Native
import LastCompletion
import NinetyTwo
import RauzyBudget

namespace ExactWordFlow.Boundary1508Floor
open SevenWordWindows SuperpermutationBounds RotationCore

theorem ceiling92 : Target107.ceiling 1508 92 :=
  LastCompletion.cap_from_floor (lower:=5899)
    SuperpermLowerBounds.covers_lower_bound_7_k16_native (by decide) (by decide)

theorem only_boundary {w : Block} (small : w.length≤1508) (hit : (visited w).card=720)
    (many : 92≤(complete w).card) : (complete w).card=92 ∧ 1503≤w.length := by
  have top:=ceiling92 w small hit
  have low:=LastCompletion.cap_from_floor (lower:=5899) (n:=1502) (c:=91)
    SuperpermLowerBounds.covers_lower_bound_7_k16_native (by decide) (by decide)
  by_cases short : w.length≤1502
  · have := low w short hit
    omega
  · omega

theorem sharp_alternatives : Target107.ceiling 1508 92 ∧ ¬Target107.ceiling 1508 90 := by
  refine ⟨ceiling92,?_⟩
  intro cap
  obtain ⟨len,hit,many⟩ : (RotationCoreControls.coreTruncated 628).length=1508 ∧
      (visited (RotationCoreControls.coreTruncated 628)).card=720 ∧
      (complete (RotationCoreControls.coreTruncated 628)).card=91 := by
    simpa [RotationCoreControls.summary] using Boundary1508.reference628.2
  have upper:=cap _ len.le hit
  omega

theorem sharp_1620 : Target107.ceiling 1620 108 ∧ ¬Target107.ceiling 1620 106 := by
  refine ⟨LastCompletion.cap_from_floor (lower:=5899)
    SuperpermLowerBounds.covers_lower_bound_7_k16_native (by decide) (by decide),?_⟩
  intro cap
  obtain ⟨w,len,hit,done⟩:=Target107.witnesses.1
  have bound:=cap w len.le hit
  omega

theorem exact_obstruction : (∃w : Block,Covers w ∧ w.length≤5904) ↔
    ∃v : Block,v.length=1508 ∧ (visited v).card=720 ∧
      (complete v).card=92 ∧ RauzyBudget.defect v=139 := by
  rw [NinetyTwo.exact_length]
  constructor
  · rintro ⟨v,len,hit,many⟩
    have eq:=(only_boundary len.le hit many).1
    have score:=RauzyBudget.length_eq v (by omega)
    exact ⟨v,len,hit,eq,by omega⟩
  · rintro ⟨v,len,hit,eq,_⟩
    exact ⟨v,len,hit,eq.ge⟩

#print axioms sharp_alternatives
#print axioms exact_obstruction
end ExactWordFlow.Boundary1508Floor

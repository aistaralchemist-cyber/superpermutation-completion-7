import DirectedEuler

namespace DirectedEuler.BridgeRoute
variable {α β : Type*}

/-- An open integral flow has no edge entering a forward-closed set that
contains its initial vertex. -/
private theorem no_entry (f g : α → β) (A : Multiset α) {s t : β}
    (bal : A.map f+{t}=A.map g+{s}) (S : Set β) (start : s∈S)
    (closed : ∀e∈A, f e∈S → g e∈S) : ∀e∈A, g e∈S → f e∈S := by
  classical
  let F := A.filter fun e => f e∈S
  let G := A.filter fun e => g e∈S
  have sub : F≤G := Multiset.le_filter.mpr ⟨Multiset.filter_le _ _,fun e he =>
    closed e (Multiset.mem_filter.mp he).1 (Multiset.mem_filter.mp he).2⟩
  have eq := congrArg (Multiset.filter fun x => x∈S) bal
  simp only [Multiset.filter_add,Multiset.filter_map,Multiset.filter_singleton,ite_eq_left start] at eq
  change F.map f+(if t∈S then {t} else 0)=G.map g+{s} at eq
  have n := congrArg Multiset.card eq
  have bound : G.card≤F.card := by
    by_cases ht : t∈S <;> simp [ht] at n <;> omega
  have same := Multiset.eq_of_le_of_card_le sub bound
  intro e he hg
  have mem : e∈F := same ▸ (Multiset.mem_filter.mpr ⟨he,hg⟩ : e∈G)
  exact (Multiset.mem_filter.mp mem).2

/-- Treat one prescribed, nonclosed route from a to b as a single edge.
If each new edge has a separating cut across which the prescribed route
and all the other edge types stay, the five-step (or any such) augmentation
is one Euler path through that indivisible edge. -/
theorem through_macro (f g : α → β) {a b s t : β} (ab : a≠b) (D : Multiset α)
    (degree : D.map f+{a}+{t}=D.map g+{b}+{s})
    (cut : ∀e∈D, ∃U : Set β, g e∈U ∧ f e∉U ∧ (a∈U ↔ b∈U) ∧
      ∀d∈D, d≠e → (f d∈U ↔ g d∈U)) :
    ∃ xs : List (Option α), (↑xs : Multiset (Option α))=D.map some+{none} ∧
      Route (fun x : Option α => x.elim a f) (fun x => x.elim b g) s xs t := by
  classical
  let F (x : Option α) := x.elim a f
  let G (x : Option α) := x.elim b g
  let A := D.map some+{none}
  have bal : A.map F+{t}=A.map G+{s} := by
    simpa [A,F,G,Multiset.map_map,Function.comp_def] using degree
  apply exists_route F G A s t bal
  intro S start step
  have someIn (d) (hd : d∈D) : some d∈A :=
    Multiset.mem_add.mpr (Or.inl (Multiset.mem_map.mpr ⟨d,hd,rfl⟩))
  have noneIn : (none : Option α)∈A := Multiset.mem_add.mpr (Or.inr (Multiset.mem_singleton_self _))
  have allFresh (e) (he : e∈D) : f e∈S := by
    obtain ⟨U,into,out,macroSide,other⟩ := cut e he
    let T := S∪U
    have closed (o) (ho : o∈A) (hsrc : F o∈T) : G o∈T := by
      rcases Multiset.mem_add.mp ho with via|only
      · obtain ⟨d,hd,rfl⟩ := Multiset.mem_map.mp via
        rcases hsrc with sin|uin
        · exact Or.inl (step _ (someIn d hd) sin)
        · by_cases eq : d=e
          · exact Or.inr (eq ▸ into)
          · exact Or.inr ((other d hd eq).mp uin)
      · obtain rfl := Multiset.mem_singleton.mp only
        rcases hsrc with sin|uin
        · exact Or.inl (step _ noneIn sin)
        · exact Or.inr (macroSide.mp uin)
    have back := no_entry F G A bal T (Or.inl start) closed _ (someIn e he) (Or.inr into)
    exact back.elim id (fun fail => (out fail).elim)
  have atMacro : a∈S := by
    let T := S∪{b}
    have closed (o) (ho : o∈A) (_ : F o∈T) : G o∈T := by
      rcases Multiset.mem_add.mp ho with edge|only
      · obtain ⟨d,hd,rfl⟩ := Multiset.mem_map.mp edge
        exact Or.inl (step _ (someIn d hd) (allFresh d hd))
      · obtain rfl := Multiset.mem_singleton.mp only
        exact Or.inr rfl
    have back := no_entry F G A bal T (Or.inl start) closed _ noneIn (Or.inr rfl)
    exact back.elim id (fun eq => (ab eq).elim)
  intro o ho
  rcases Multiset.mem_add.mp ho with edge|only
  · obtain ⟨d,hd,rfl⟩ := Multiset.mem_map.mp edge
    exact allFresh d hd
  · obtain rfl := Multiset.mem_singleton.mp only
    exact atMacro

#print axioms through_macro
end DirectedEuler.BridgeRoute

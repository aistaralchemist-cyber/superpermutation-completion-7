import CandidateBanks

namespace ExactWordFlow.FrontRawBudget
open SevenWordWindows RotationCore RotationReinsert ResidualDensity CoreRecordBits LapSkeleton

def cleanSignals (w : Block) := ((windows w).map src ++ [w.drop (w.length-6)]).map clean
def winSignals (w : Block) := (windows w).map fun p => decide p.Nodup
def startSignals (w : Block) := (cleanSignals w).take 1 ++
  List.zipWith (fun b p => b && !p) (cleanSignals w).tail (winSignals w)

open private route_contexts from RotationKeyMask
open private token entries from LapBudget

theorem clean_anchors {w : Block} (long : 6≤w.length) :
    cleanSignals w = (anchors w).map (fun u => decide (full u)) := by
  unfold cleanSignals
  rw [← route_contexts (read_route w long)]
  apply List.map_congr_left
  intro u hu
  apply clean_eq
  rcases List.mem_cons.mp hu with rfl|later
  · simp [long]
  · obtain ⟨p,hp,rfl⟩ := List.mem_map.mp later
    simp [dst,window_width w hp]

private theorem start_entries (es : List Block) :
    (List.zipWith (fun b p => b && !p) (es.map fun e=>decide (full (dst e)))
      (es.map fun e=>decide e.Nodup)).count true = (entries es).length := by
  induction es with
  | nil => rfl
  | cons e es ih =>
    simp at ih
    by_cases nd : e.Nodup <;> by_cases f : full (dst e) <;>
      simp [entries,token,nd,f,ih]

theorem starts_count {w : Block} (long : 6≤w.length) :
    (startSignals w).count true = (starts w).length := by
  rw [startSignals,clean_anchors long]
  simp only [anchors,List.map_cons,List.take_succ_cons,List.take_zero,List.tail_cons,
    List.map_map,List.count_append,starts,List.length_append,winSignals]
  rw [show ((fun u => decide (full u)) ∘ dst) = (fun e => decide (full (dst e))) from rfl,start_entries]
  by_cases f : full (w.take 6) <;> simp [token,f]

private theorem count_yes (f : α → Bool) (xs : List α) :
    (xs.map f).count true = (xs.filter f).length := by
  induction xs with
  | nil => rfl
  | cons a xs ih => cases val : f a <;> simp [val,ih]

theorem wins_count (w : Block) : (winSignals w).count true = (good w).length :=
  count_yes _ _

private theorem count_clean_dirty (xs : List Block) :
    ((xs.map fun u => decide (full u)).count true) +
     (xs.filter (fun u=>decide (¬full u))).length = xs.length := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    simp only [decide_not] at ih
    by_cases f : full x <;> simp [f] <;> omega

theorem cleans_count {w : Block} (long : 6≤w.length) :
    (cleanSignals w).count true + dirty w = (anchors w).length := by
  rw [clean_anchors long]
  exact count_clean_dirty _

theorem raw_budget {w : Block} (len : w.length=1501) (hit : (visited w).card=720)
    (many : 91≤(complete w).card) :
    720≤(startSignals w).count true ∧ 637≤(winSignals w).count true ∧
      1357≤(cleanSignals w).count true := by
  have long : 6≤w.length := by omega
  have cut := PrefixCharge.circuit_budget long hit 91 many
  have yes := cleans_count long
  simp [anchors,windows_length,len] at yes
  rw [starts_count long,wins_count]
  omega

#print axioms raw_budget
end ExactWordFlow.FrontRawBudget

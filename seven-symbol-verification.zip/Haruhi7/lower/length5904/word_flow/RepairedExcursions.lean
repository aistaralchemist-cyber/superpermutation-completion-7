import ExcursionCore

namespace ExactWordFlow.RepairedExcursions
open SevenWordWindows RotationCore RotationReinsert LapSkeleton DirectedEuler ResidualDensity ExcursionCore
open private splice from DirectedEuler

/-- Compare the score after erasing a family of excursions and splicing a
possibly different closed repair walk into any retained context. Missing tags
may be supplied by the repair. Every surviving permutation remains available. -/
theorem repair_price {w : Block} {limit : Nat} (min : Minimal limit w)
    {s t u : Block} {keep fix : List Block} (track : Route src dst s keep t)
    (joinAt : u∈s::keep.map dst) (loop : Route src dst u fix u)
    (start : s.length=6) (wd : ∀e∈keep++fix,e.length=7)
    (tags : HoldsAll s (keep++fix))
    (smaller : keep.length+fix.length<(windows w).length) :
    limit-score w+((windows w).length-(keep.length+fix.length))<7*(lost w (keep++fix)).card := by
  have site : u=s ∨ ∃e∈keep,dst e=u := by
    simpa [List.mem_map] using joinAt
  obtain ⟨es,bg,route⟩:=splice track site loop
  have same (e : Block) : e∈es ↔ e∈keep++fix := by
    change e∈(↑es : Multiset Block) ↔ _
    rw [bg]
    simp
  have num : es.length=keep.length+fix.length := by
    simpa using congrArg Multiset.card bg
  have member (c : Block) : c∈s::es.map dst ↔ c∈s::(keep++fix).map dst := by
    simp only [List.mem_cons,List.mem_map,same]
  have visits : HoldsAll s es := by
    intro c hc
    obtain ⟨v,hv,clean,eq⟩:=tags c hc
    exact ⟨v,(member _).mpr hv,clean,eq⟩
  have loss : lost w es=lost w (keep++fix) := by
    ext c
    simp only [lost,Finset.mem_filter,same]
  have h:=retained_route min route start (fun e he=>wd e ((same _).mp he)) visits (num ▸ smaller)
  rwa [num,loss] at h

/-- One six-edge repair cannot replace thirteen or more original edges if
at most one completed class would be sacrificed and all visits are restored. -/
theorem no_thirteen_for_six {w : Block} {limit : Nat} (min : Minimal limit w)
    {s t u : Block} {keep fix : List Block} (track : Route src dst s keep t)
    (joinAt : u∈s::keep.map dst) (loop : Route src dst u fix u)
    (start : s.length=6) (wd : ∀e∈keep++fix,e.length=7)
    (tags : HoldsAll s (keep++fix)) (six : fix.length=6)
    (saved : keep.length+13≤(windows w).length) : 2≤(lost w (keep++fix)).card := by
  have p:=repair_price min track joinAt loop start wd tags (by omega)
  omega

#print axioms repair_price
#print axioms no_thirteen_for_six
end ExactWordFlow.RepairedExcursions

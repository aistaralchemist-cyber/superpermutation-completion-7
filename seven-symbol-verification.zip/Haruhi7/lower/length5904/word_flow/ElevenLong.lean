import ElevenParts
import LongOpenWindows

namespace ExactWordFlow.ElevenLong
open SevenWordWindows ResidualDensity DirectedEuler ResidualIncidence ResidualRoutes RotationComponentCount
open scoped Classical
open private closeCap cyclic_price from Cap93Mass
open private hits Cost totals rank_partition from NearHundredShape
open private openCap from ElevenScalar

/-- Twelve longer closed parts cannot appear in an 858-edge residual flow,
uniformly in the number of ordinary wheels and the choice of endpoints. -/
theorem at_most_eleven {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget:X.card≤858) :
    ((occupied X s).filter (fun q=>6<(part X q).card)).card≤11 := by
  classical
  let Q:=occupied X s
  let home:=label X s
  let B:=Q.filter (fun q=>6<Cost X q)
  let D:=Q.filter (fun q=>6<Cost X q ∧ Cost X q≠35)
  change B.card≤11
  by_contra! large
  have ceiling:=GlobalClosedPrice.at_most_twelve h budget
  change B.card≤12 at ceiling
  have nt : B.card=12:=by omega
  have costBound:=GlobalClosedPrice.count_bound h budget
  change 3*Q.card+22*B.card+4*D.card+_≤308 at costBound
  have base (q) (hq:q∈Q) : 6≤Cost X q ∧ hits X s q-1≤closeCap (Cost X q)-1 := by
    have active:q∈active X s:=occupied_active h ▸ hq
    have size:6≤Cost X q:=(Finset.mem_filter.mp active).2.2
    have away:q≠home:=(Finset.mem_erase.mp hq).1
    obtain ⟨v,_,eq⟩:=residual_clean h away (by change 0<Cost X q; omega)
    obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance v
    rw [eq] at bag lv ends
    obtain ⟨aa,bb⟩:=ends.2 away
    subst a; subst b
    have len:es.length=Cost X q:=congrArg Multiset.card bag
    have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
    have cap:=cyclic_price r wd (by omega)
    rw [len] at cap
    have hit : hits X s q≤closeCap (Cost X q):=(contacts_bound _ lv r bag).trans cap
    exact ⟨size,by omega⟩
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have root:=WeightedMarks.path_cap r wd
  have hit:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  have weighted : 45*(hits X s home-1)≤38*Cost X home+59:=by omega
  have openBound (low : Cost X home≤466) : hits X s home≤openCap (Cost X home):=by
    rw [←len]
    exact hit.trans (open_price (@LongOpenWindows.route) r wd (by omega))
  have floor := rank719 _ h (fun _ he=>on_edge he)
  change 719≤ separateRank X s at floor
  rw [rank_partition h] at floor
  change 719≤hits X s home-1+∑q∈Q,(hits X s q-1) at floor
  have total:=(totals h).1
  change Cost X home+6*Q.card+(∑q∈Q,(Cost X q-6))=X.card at total
  have split:(∑q∈Q,Cost X q)=6*Q.card+∑q∈Q,(Cost X q-6) := by
    calc
      _ = ∑q∈Q,(6+(Cost X q-6)) := by
        apply Finset.sum_congr rfl
        intro q hq
        have size:=(base q hq).1
        omega
      _ = _ :=by simp [Finset.sum_add_distrib,Nat.mul_comm]
  exact parts Q (Cost X) (fun q=>hits X s q-1) (Cost X home) (hits X s home)
    B D rfl rfl nt (by omega) base (by omega) floor weighted openBound

#print axioms at_most_eleven
end ExactWordFlow.ElevenLong

import Hunter.Words
import SevenReference

namespace IntegralSplit
open Hunter
abbrev Word := List Nat

def alphabet : Word := [1,2,3,4,5,6,7]
def windows : List Word := Id.run do
  let ds := SevenReference.word.toList.toArray.map (fun c => c.toNat - 47)
  let mut result := #[]
  for i in [0:ds.size-6] do
    let p := (ds.extract i (i+7)).toList
    if p.mergeSort == alphabet then result := result.push p
  return result.toList

def loopBlock : List Word := windows.take 7
def openBlock : List Word := windows.drop 7

def arcs (vs : List Word) := vs.zip vs.tail
def splitEdges := (arcs openBlock) ++ (arcs (loopBlock ++ loopBlock.take 1))
def allowed (a b : Word) : Finset Nat :=
  (Finset.Icc 1 7).filter (fun d => a.drop d = b.take (7-d))
def cost (a b : Word) : Nat :=
  if h : (allowed a b).Nonempty then (allowed a b).min' h else 7

theorem cost_eq (a b : Word) (ha : a.length ≤ 7) : cost a b = wt 7 a b := by
  obtain ⟨hd, h7, hv⟩ := wt_spec (k:=7) (u:=a) (v:=b) (by decide) ha
  have hm : wt 7 a b ∈ allowed a b := by simp [allowed, hd,h7,hv]
  have hn : (allowed a b).Nonempty := ⟨_,hm⟩
  rw [cost, dite_eq_left hn]
  apply Nat.le_antisymm (Finset.min'_le _ _ hm)
  have hh := (allowed a b).min'_mem hn
  simp only [allowed, Finset.mem_filter, Finset.mem_Icc] at hh
  exact wt_le hh.1.1 hh.1.2 hh.2

set_option maxHeartbeats 0
theorem split_certificate :
    (loopBlock ++ openBlock).mergeSort = alphabet.permutations.mergeSort ∧
    loopBlock.length = 7 ∧ openBlock.length = 5033 ∧
    splitEdges.all (fun p => decide (p.1.length ≤ 7)) = true ∧
    (splitEdges.map (fun p => cost p.1 p.2)).sum = 5897 := by native_decide

theorem exact_vertex_multiset : (loopBlock ++ openBlock).Perm alphabet.permutations := by
  have l := List.mergeSort_perm (loopBlock ++ openBlock) (fun a b => decide (a≤b))
  have r := List.mergeSort_perm alphabet.permutations (fun a b => decide (a≤b))
  exact l.symm.trans (split_certificate.1.symm ▸ r)

theorem split_weight :
    7 + (splitEdges.map (fun p => wt 7 p.1 p.2)).sum = 5904 := by
  obtain ⟨_,_,_,hlen,h⟩ := split_certificate
  have eqn : splitEdges.map (fun p => wt 7 p.1 p.2) =
      splitEdges.map (fun p => cost p.1 p.2) := by
    apply List.map_congr_left
    intro p hp
    exact (cost_eq _ _ (of_decide_eq_true (List.all_eq_true.mp hlen _ hp))).symm
  rw [eqn, h]

/-- Cut one cycle edge (a,b) and insert the entire cycle in the open path.
The two end cases charge one replacement edge. Interior insertions charge
two edges and remove the old open-path edge. -/
def allSplices : Bool :=
  (arcs (loopBlock ++ loopBlock.take 1)).all fun (a,b) =>
    cost a b + 1 ≤ cost a openBlock.head! &&
    cost a b + 1 ≤ cost openBlock.getLast! b &&
    (arcs openBlock).all fun (u,v) =>
      cost a b + cost u v + 1 ≤ cost u b + cost a v

theorem optimal_single_splice : allSplices = true ∧
    cost loopBlock.getLast! openBlock.head! = cost loopBlock.getLast! loopBlock.head! + 1 := by
  native_decide

/-- Orient each rotation class at the symbol 1 (all inputs are permutations). -/
def cycleClass (a : Word) := a.rotate (a.idxOf 1)

/-- With the open path closed through a dummy vertex, the extra term
is its last real vertex's outgoing arc to the dummy. The isolated cycle
has no exits from its own rotation class. -/
def exits := 1 + splitEdges.countP (fun e => cycleClass e.1 != cycleClass e.2)

theorem class_table :
    loopBlock = (List.range 7).map (fun k => alphabet.rotate k) ∧
    (alphabet.permutations.map cycleClass).eraseDups.length = 720 ∧ exits = 785 := by
  native_decide

theorem rename_cost (f : Nat → Nat) (inj : Function.Injective f) (a b : Word) :
    wt 7 (a.map f) (b.map f) = wt 7 a b := by
  unfold wt
  congr 1
  ext d
  simp only [Set.mem_ofPred_eq, ← List.map_drop, ← List.map_take]
  constructor
  · rintro ⟨hd, hn, h⟩
    exact ⟨hd,hn,List.map_injective_iff.mpr inj h⟩
  · rintro ⟨hd,hn,h⟩
    exact ⟨hd,hn,congrArg (List.map f) h⟩

end IntegralSplit
#print axioms IntegralSplit.split_weight
#print axioms IntegralSplit.exact_vertex_multiset

#print axioms IntegralSplit.optimal_single_splice

#print axioms IntegralSplit.class_table
#print axioms IntegralSplit.rename_cost

import NearBindingFast

namespace ExactWordFlow.NearWheelBinding
theorem checked96 : verified 96=true := verified_of_batched 96 (by native_decide)
#print axioms checked96
end ExactWordFlow.NearWheelBinding

import NearHardRoots

namespace ExactWordFlow.Cap93Data
open SevenWordWindows NearHardRoots RotationCore

def words := (include_str "hard300-words.txt").trimAscii.toString.splitOn "\n"
def hard := words.map (fun w=>visited (digits w))

end ExactWordFlow.Cap93Data

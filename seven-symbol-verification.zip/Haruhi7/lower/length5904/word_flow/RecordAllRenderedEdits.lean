import AllRenderedEdits
import LapEditRecordScan

namespace ExactWordFlow.RecordAllRenderedEdits
open SevenWordWindows RotationCore RotationCoreControls LapEditContexts LapEditAssemble LapDeletionShadow
open LapEditRecordData (tiles)

theorem all_edits {w ps} (r : Render tiles w ps) (i : Nat) (inside : i<w.length)
    (all : (visited (w.eraseIdx i)).card=720) : (complete (w.eraseIdx i)).card+ps.length<720 := by
  apply after_cut_and_edit LapEditRecordData.valid _ _ LapEditRecordScan.checked r i inside all
  · rw [LapEditRecordData.uncut_source,LapEditRecordData.original_good]
  · intro p hp
    rw [LapEditRecordData.uncut_source]
    apply LapMultiplicity.source_eight.2.2
    rw [←LapEditRecordData.tags]
    exact List.mem_map_of_mem hp

private theorem generic_lengths {ts : List Tile} (valid : Valid ts) (n : Nat)
    (size : (uncut ts).length=n+1) {w ps} (r : Render ts w ps) (i : Nat) (inside : i<w.length) :
    w.length+7*ps.length=n+1 ∧ (w.eraseIdx i).length+7*ps.length=n := by
  have cut : Cuts (uncut ts) ps w := by simpa only [List.nil_append] using cuts r valid []
  have total:=spell_length cut
  have eq : w.length+7*ps.length=n+1:=total.symm.trans size
  exact ⟨eq,by rw [List.length_eraseIdx_of_lt inside];omega⟩

private theorem record_length : (uncut tiles).length=5905 :=
  (congrArg List.length LapEditRecordData.uncut_source).trans SuperpermLowerBounds.LengthBudget.Word5905.length_5905

theorem lengths {w ps} (r : Render tiles w ps) (i : Nat) (inside : i<w.length) :
    w.length+7*ps.length=5905 ∧ (w.eraseIdx i).length+7*ps.length=5904 :=
  generic_lengths LapEditRecordData.valid 5904 record_length r i inside

theorem cut628 {w ps} (r : Render tiles w ps) (count : ps.length=628) (i : Nat) (inside : i<w.length)
    (all : (visited (w.eraseIdx i)).card=720) :
    (w.eraseIdx i).length=1508 ∧ (complete (w.eraseIdx i)).card≤91 := by
  have a:=(lengths r i inside).2
  have b:=all_edits r i inside all
  omega

theorem cut612 {w ps} (r : Render tiles w ps) (count : ps.length=612) (i : Nat) (inside : i<w.length)
    (all : (visited (w.eraseIdx i)).card=720) :
    (w.eraseIdx i).length=1620 ∧ (complete (w.eraseIdx i)).card≤107 := by
  have a:=(lengths r i inside).2
  have b:=all_edits r i inside all
  omega

#print axioms all_edits
#print axioms cut628
#print axioms cut612
end ExactWordFlow.RecordAllRenderedEdits

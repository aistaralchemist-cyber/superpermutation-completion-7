import NearExtrema
import ExtremalRealizations

namespace ResidualDensity.NearRootSets
open ExactWordFlow DirectedEuler ExtremalRealizations

/-- For any of the five extremal component counts, all actual root
classes occur together in one enumerated set. A single permutation of
the alphabet is used consistently throughout the original path. -/
theorem route_coverage (N : Nat) (lo : 96≤N) (hi : N≤100)
    {s t : Six} {es : List Six} (r : Route src dst s es t) (wd : ∀e∈es,e.length=7)
    (len : es.length=858-6*N) (many : 720-5*N≤classCount s es) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ((touched (s::es.map dst)).image (List.map f))∈realizations (NearExtrema.profiles N) := by
  exact route_coverage_at r wd (by omega : es.length+1=859-6*N) many _ (fun _ _ w m n=>
    NearExtrema.extreme_mask N lo hi w m 0 n)

#print axioms route_coverage
end ResidualDensity.NearRootSets

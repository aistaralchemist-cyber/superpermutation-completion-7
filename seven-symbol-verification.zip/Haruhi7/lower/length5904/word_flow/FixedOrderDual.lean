import PlanarScoreExample
import Word5905
namespace ExactWordFlow.FixedOrderDual
open SevenWordWindows
open private digits from ExtremeWheelCut
open private cost from PlanarScoreExample

/-- W-0021's exceptional cycle in its observed order, cut at the free edge. -/
private def rows : List (Nat × String) := [(3,"6012345"),
  (5,"6501243"),
  (5,"6012453"),
  (5,"6124503"),
  (3,"6245013"),
  (3,"6324510"),
  (5,"6032415"),
  (5,"6324105"),
  (5,"6241035"),
  (5,"6410325"),
  (5,"6032145"),
  (5,"6321405"),
  (5,"6214035"),
  (5,"6140325"),
  (3,"6403215"),
  (5,"6540312"),
  (5,"6403152"),
  (5,"6031542"),
  (2,"6315402"),
  (5,"6023145"),
  (5,"6231405"),
  (5,"6314025"),
  (5,"6140235"),
  (5,"6023415"),
  (5,"6234105"),
  (5,"6341025"),
  (5,"6410235"),
  (3,"6102345"),
  (5,"6510243"),
  (5,"6102453"),
  (3,"6024513"),
  (5,"6302415"),
  (5,"6024135"),
  (5,"6241305"),
  (5,"6413025"),
  (5,"6302145"),
  (5,"6021435"),
  (5,"6214305"),
  (5,"6143025"),
  (3,"6430215"),
  (5,"6543012"),
  (5,"6430152"),
  (3,"6301542"),
  (5,"6230145"),
  (5,"6301425"),
  (5,"6014235"),
  (5,"6142305"),
  (5,"6230415"),
  (5,"6304125"),
  (5,"6041235"),
  (5,"6412305"),
  (2,"6123045"),
  (5,"6451203"),
  (5,"6512043"),
  (5,"6120453"),
  (3,"6204513"),
  (5,"6320415"),
  (5,"6204135"),
  (5,"6041325"),
  (5,"6413205"),
  (5,"6320145"),
  (5,"6201435"),
  (5,"6014325"),
  (5,"6143205"),
  (3,"6432015"),
  (3,"6543210"),
  (5,"6054312"),
  (5,"6543102"),
  (5,"6431052"),
  (3,"6310542")]
def states : Array Block := (rows.flatMap fun (r,s) =>
  (List.range (r+1)).map fun j => (digits s).take 1 ++ (digits s).tail.rotate j).toArray
abbrev I := Fin 391
/-- The dummy state 390 splits the single free cut into two zero-cost arcs. -/
def price (i j : I) : Nat :=
  if i.val=390 ∨ j.val=390 then 0
  else cost (states[i.val]?.getD []) (states[j.val]?.getD []) - 2

private def labels : Array Nat := #[56,56,56,56,0,0,0,0,0,0,1,1,1,1,1,1,25,25,25,25,25,25,56,56,56,56,56,56,56,56,30,30,30,30,30,30,52,52,52,52,52,52,35,35,35,35,35,35,32,32,32,32,32,32,29,29,29,29,29,29,51,51,51,51,51,51,34,34,34,34,34,34,31,31,31,31,31,31,56,56,56,56,26,26,26,26,26,26,27,27,27,27,27,27,28,28,28,28,28,28,56,56,56,12,12,12,12,12,12,47,47,47,47,47,47,21,21,21,21,21,21,14,14,14,14,14,14,13,13,13,13,13,13,48,48,48,48,48,48,22,22,22,22,22,22,15,15,15,15,15,15,56,56,56,56,18,18,18,18,18,18,19,19,19,19,19,19,56,56,56,56,17,17,17,17,17,17,16,16,16,16,16,16,49,49,49,49,49,49,23,23,23,23,23,23,11,11,11,11,11,11,10,10,10,10,10,10,46,46,46,46,46,46,20,20,20,20,20,20,56,56,56,56,2,2,2,2,2,2,9,9,9,9,9,9,56,56,56,56,7,7,7,7,7,7,4,4,4,4,4,4,3,3,3,3,3,3,44,44,44,44,44,44,40,40,40,40,40,40,37,37,37,37,37,37,36,36,36,36,36,36,53,53,53,53,53,53,56,56,56,33,33,33,33,33,33,42,42,42,42,42,42,43,43,43,43,43,43,56,56,56,56,41,41,41,41,41,41,39,39,39,39,39,39,38,38,38,38,38,38,54,54,54,54,54,54,8,8,8,8,8,8,6,6,6,6,6,6,5,5,5,5,5,5,45,45,45,45,45,45,56,56,56,56,56,56,56,56,55,55,55,55,55,55,24,24,24,24,24,24,50,50,50,50,50,50,56,56,56,56,56]
private def rowPot : Array Int := #[0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,2,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0]
private def colPot : Array Int := #[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-2]
private def label (i : I) := labels[i.val]?.getD 56
private def row (i : I) := rowPot[i.val]?.getD 0
private def col (i : I) := colPot[i.val]?.getD 0
private def exits (i j : I) : Prop := label i < 56 ∧ label j ≠ label i
private instance (i j : I) : Decidable (exits i j) := inferInstanceAs (Decidable (_ ∧ _))

private theorem certificate :
    (∀i j : I, i≠j → row i+col j+(if exits i j then (1:Int) else 0)≤price i j) ∧
    (∑i : I,row i)+(∑i : I,col i)=18 ∧ label 390=56 ∧
    (∀g∈Finset.range 56,∃i:I,label i=g) := by native_decide

/-- At least one edge must exit each cut in any spanning cycle. The
distinct cut labels ensure that their exit charges count different edges. -/
private theorem exit_bound (f : Equiv.Perm I)
    (reachable : ∀i:I,∃n:Nat,(f^[n]) i=390) :
    56≤(Finset.univ.filter (fun i=>exits i (f i))).card := by
  classical
  let A:=Finset.univ.filter fun i=>exits i (f i)
  have subset : Finset.range 56 ⊆ A.image label := by
    intro g hg
    by_contra absent
    obtain ⟨x,hx⟩:=certificate.2.2.2 g hg
    have step (i : I) (eq : label i=g) : label (f i)=g := by
      by_contra diff
      have mem : i∈A := Finset.mem_filter.mpr ⟨Finset.mem_univ _,by
        exact ⟨eq ▸ Finset.mem_range.mp hg,by simpa only [eq] using diff⟩⟩
      exact absent (Finset.mem_image.mpr ⟨i,mem,eq⟩)
    have stays (n : Nat) : label ((f^[n]) x)=g := by
      induction n with
      | zero => exact hx
      | succ n ih => rw [Function.iterate_succ_apply'];exact step _ ih
    obtain ⟨n,eq⟩:=reachable x
    have endTag:=stays n
    rw [eq,certificate.2.2.1] at endTag
    exact (Nat.ne_of_lt (Finset.mem_range.mp hg)) endTag.symm
  have lower:=(Finset.card_le_card subset).trans (Finset.card_image_le (s:=A) (f:=label))
  simpa [A] using lower

/-- Arbitrary reorderings of the 390 states and arbitrary free cuts cannot
improve W-0021's exceptional-cycle excess 74. Insert one dummy point into
the free edge to encode any such ordering as a spanning 391-cycle. -/
theorem optimal (f : Equiv.Perm I) (loopless : ∀i,f i≠i)
    (reachable : ∀i:I,∃n:Nat,(f^[n]) i=390) : 74≤ ∑ i : I,price i (f i) := by
  have sum := Finset.sum_le_sum (s:=Finset.univ) (fun i _ =>
    certificate.1 i (f i) (loopless i).symm)
  rw [Finset.sum_add_distrib, Finset.sum_add_distrib,Equiv.sum_comp f col,certificate.2.1] at sum
  have exitsEnough:=exit_bound f reachable
  have count : (∑i:I, if exits i (f i) then (1:Int) else 0)=
      ((Finset.univ.filter fun i=>exits i (f i)).card : Int) := by
    rw [←Finset.sum_filter]
    simp only [Finset.sum_const,nsmul_eq_mul,mul_one]
  rw [count] at sum
  exact_mod_cast (show (74:Int)≤∑i:I,(price i (f i):Int) by omega)

/-- With any number of ordinary six-wheels and any genus, every completion
whose sole exceptional cycle has these 390 actual states spells at least
5905 letters. The wheel supports and the exceptional order are free. -/
theorem sole_exception_floor (f : Equiv.Perm I) (loopless : ∀i,f i≠i)
    (reachable : ∀i:I,∃n:Nat,(f^[n]) i=390) {q g L s : Nat}
    (realCost : s=∑i:I,price i (f i))
    (genus : 390+6*q=(q+1)+719+2*g)
    (length : L=5764+(q+1)+s+2*g) : 5905≤L := by
  have bound:=optimal f loopless reachable
  omega

theorem realized : states.size=390 ∧ (states.toList.map classKey).Nodup ∧
    (∑ i : I,price i (i+1))=74 := by native_decide

/-- Read all literal seven-letter permutations at their first occurrence in
the stored W-0021 source, and compute the correction cycle containing the
cut from the last to the first. Equality verifies each of the 390 states. -/
private def inputOrder : Array Block := Id.run do
  let mut seen : Std.HashSet Block := {}
  let mut order : Array Block := #[]
  for x in windows SuperpermLowerBounds.LengthBudget.Word5905.word do
    if x.Nodup && !seen.contains x then
      seen := seen.insert x
      order := order.push x
  return order

private def inputCycle : Array Block := Id.run do
  let ord := inputOrder
  let mut next : Std.HashMap Block Block := {}
  for i in [:ord.size] do
    next := next.insert ord[i]! (ord[(i+1)%ord.size]!.rotate 6)
  let mut x := ord[0]!.rotate 6
  let mut orbit : Array Block := #[]
  for _ in [:391] do
    if orbit.contains x then break
    orbit := orbit.push x
    x := next[x]?.getD []
  return orbit

theorem from_reference : inputOrder.size=5040 ∧ inputCycle=states := by native_decide

#print axioms from_reference
#print axioms optimal
#print axioms sole_exception_floor
#print axioms realized
end ExactWordFlow.FixedOrderDual

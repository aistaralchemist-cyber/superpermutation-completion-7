import Cap95Catalog
import IndexedRootSearch
import Cap95Hard
import NinetyFive

namespace ExactWordFlow.Cap95Transport
open SevenWordWindows RotationCore ExtremeWheelCut NearWheelBinding ResidualDensity
open ExtremalRealizations
open private baseGood index checkLookup from NearBindingCheck
open private rows from Cap95Catalog

private theorem restrict {α : Type*} (p : α→Bool) (A B : List α) (inclusion : A⊆B) (base : Bool)
    (ok : (base && B.all p)=true) : (base && A.all p)=true := by
  obtain ⟨yes,each⟩:=Bool.and_eq_true_iff.mp ok
  apply Bool.and_eq_true_iff.mpr
  refine ⟨yes,List.all_eq_true.mpr ?_⟩
  intro x hx
  exact List.all_eq_true.mp each x (inclusion hx)

def fast (n : Nat) (v : Array (Block × Answer)) (table : Array (Finset Block)) (ps : List (List Nat)) :=
  v.toList.all (baseGood n table) &&
    let lut:=index v
    (IndexedRootSearch.results ps).all (checkLookup v lut)

private theorem verified_any (n : Nat) (v : Array (Block × Answer)) (table : Array (Finset Block))
    (ps : List (List Nat)) (ok : fast n v table ps=true) :
    (v.toList.all (baseGood n table) &&
        (realizations ps).all (checkLookup v (index v)))=true :=
  restrict (checkLookup v (index v)) (realizations ps) (IndexedRootSearch.results ps)
    (IndexedRootSearch.complete ps) (v.toList.all (baseGood n table)) ok

/-- A definition with the same data as the standalone ground computation.
The verification transfer is proved once with its table and profiles abstract. -/
def ground := fast 95 rows Cap95Data.hard.toArray (Cap95Profiles.profiles 95)

theorem certified (ok : ground=true) : Cap95Catalog.verified 95=true :=
  verified_any 95 rows Cap95Data.hard.toArray (Cap95Profiles.profiles 95) ok

theorem excluded (ok : ground=true) {R : Finset Block} (geo : R∈realizations (Cap95Profiles.profiles 95))
    {W : Finset (Finset Block)} (legal : W⊆allRows) (size : W.card≤95) :
    ¬SeedWheelCut.ClosedCover R allClasses W := by
  intro covers
  obtain ⟨r,hard,w,rows,small,actual,cover⟩:=Cap95Catalog.exhaust_verified (certified ok) geo legal size covers
  have tight : r.card+5*w.card≤allClasses.card := by rw [board,actual]; omega
  exact OrientedCNF.no_cover rows tight (Cap95Hard.unsat hard) cover

#print axioms certified
#print axioms excluded
end ExactWordFlow.Cap95Transport

import OverlapBudget
import SharedRotationCuts
import PartitionLoss
import ContactSquares

namespace ExactWordFlow
open ResidualIncidence ResidualRoutes ResidualDensity SevenWordWindows
open scoped Classical

private theorem reachable_classes (X : Multiset Block) (s : Block) {c : Block} (hc : c∈allClasses) :
    ∃ i∈liveGroups X s, c∈contacts (support X s) (label X) i := by
  classical
  have table : allClasses ⊆ (representatives.map (fun e => tag (dst e))).toFinset ∧
    (representatives.all (fun e => decide (full (dst e))))=true := by native_decide
  obtain ⟨e,he,eq⟩ := List.mem_map.mp (List.mem_toFinset.mp (table.1 hc))
  have used : dst e∈support X s := Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
    (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inl (show e∈required from he)),rfl⟩))
  exact ⟨_,Finset.mem_image_of_mem _ used,Finset.mem_image.mpr
    ⟨_,Finset.mem_filter.mpr ⟨used,rfl,of_decide_eq_true (List.all_eq_true.mp table.2 e he)⟩,eq⟩⟩

theorem classes_connected {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    ContactSquares.Connected (liveGroups X s) allClasses (contacts (support X s) (label X)) := by
  classical
  let C := contacts (support X s) (label X)
  have cuts := (feasible_iff_shared_cuts h.start_six h.edges_seven h.balance).mp h
  intro T uniform
  let L : Set (Component X) := {i | ∃ c∈C i, c∈T}
  have all (u) (hu : u∈liveGroups X s) (v) (hv : v∈liveGroups X s) (ul : u∈L) : v∈L := by
    by_contra nope
    obtain ⟨i,hi,j,hj,il,jl,c,hc⟩ := cuts L ⟨u,hu,ul⟩ ⟨v,hv,nope⟩
    obtain ⟨a,ha,yes⟩ := il
    have both := Finset.mem_inter.mp hc
    exact jl ⟨c,both.2,(uniform i hi a ha c both.1).mp yes⟩
  intro x hx y hy
  obtain ⟨i,hi,xi⟩ := reachable_classes X s hx
  obtain ⟨j,hj,yj⟩ := reachable_classes X s hy
  constructor
  · intro yes
    obtain ⟨a,ha,on⟩ := all i hi j hj ⟨x,xi,yes⟩
    exact (uniform j hj a ha y yj).mp on
  · intro yes
    obtain ⟨a,ha,on⟩ := all j hj i hi ⟨y,yj,yes⟩
    exact (uniform i hi a ha x xi).mp on

/-- Simultaneous losses certified in arbitrary disjoint groups total at most
ten. The individual groups may share rotation classes. -/
theorem partition_ten {κ : Type*} [DecidableEq κ] {X : Multiset Block} {s t : Block}
    (h : Feasible X s t) (small : X.card≤858) (p : Component X → κ) (loss : κ → Nat)
    (cert : let Q := liveGroups X s; let C := contacts (support X s) (label X)
      ∀ j∈Q.image p, (combined Q C p j).card-1+loss j ≤ separate Q C p j) :
    ∑ j∈(liveGroups X s).image p, loss j ≤ 10 := by
  have lo := partition_loss (label X) p h (fun _ he => on_edge he) loss cert
  change 719+(∑ j∈(liveGroups X s).image p, loss j) ≤ separateRank X s at lo
  have up := separate_rank_at_most_729 h.balance h.edges_seven small
  omega

/-- This applies to a long component meeting any chosen other components;
off-anchor collisions are charged as well as multiple on-anchor contacts. -/
theorem anchor_ten {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (a : Component X) (B : Finset (Component X)) (ha : a∈liveGroups X s) (other : a∉B)
    (live : B⊆liveGroups X s) (nonempty : (contacts (support X s) (label X) a).Nonempty)
    (meet : ∀i∈B, (contacts (support X s) (label X) i ∩ contacts (support X s) (label X) a).Nonempty) :
    let C := contacts (support X s) (label X); let A := C a
    ((∑ i∈B, ((C i∩A).card-1)) + ((∑ i∈B, (C i \ A).card) - ((B.biUnion C) \ A).card))≤10 := by
  have bound := anchor_loss (label X) h (fun _ he => on_edge he) a B ha other live nonempty meet
  have high := separate_rank_at_most_729 h.balance h.edges_seven budget
  dsimp only at bound ⊢
  unfold separateRank at high
  omega

/-- Any independently removable family of rectangle contacts costs one unit
per face. The component geometry is otherwise unrestricted. -/
theorem rectangle_ten {β : Type*} [DecidableEq β] {X : Multiset Block} {s t : Block}
    (h : Feasible X s t) (budget : X.card≤858) (F : Finset β)
    (E : β → Finset (Component X × Block)) (rect : ∀ f∈F, ContactSquares.Rectangle (E f))
    (boundary : ContactSquares.HasBoundary F E)
    (live : ∀f∈F, ∀ z∈E f, z.1∈liveGroups X s ∧ z.2∈contacts (support X s) (label X) z.1) :
    F.card≤10 := by
  have size : allClasses.card=720 := by native_decide
  have ne := Finset.card_pos.mp (show 0<allClasses.card by omega)
  have low := ContactSquares.independent_rectangles_cost (liveGroups X s) allClasses _
    ne (classes_connected h) F E rect boundary live
  rw [size] at low
  change 720-1+F.card ≤ separateRank X s at low
  have up := separate_rank_at_most_729 h.balance h.edges_seven budget
  omega

#print axioms anchor_ten
#print axioms rectangle_ten
end ExactWordFlow

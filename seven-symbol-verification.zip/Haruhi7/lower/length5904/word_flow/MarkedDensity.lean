import MarkedGeometry
import RouteDensity

namespace ResidualDensity.WeightedMarks
open MarkedGeometry DirectedEuler ExactWordFlow

/-- The last remembered suffix is a prefix of one of the forbidden masks.
Order the choices longest first to retain as much information as possible. -/
private def prefixes : Array (List Bool) :=
  ((forbidden.flatMap List.inits).eraseDups.mergeSort
    (fun a b => decide (b.length≤a.length))).toArray

private def memoryWord (s : Nat) := prefixes[s]?.getD []

private def nextState (s : List Bool) (b : Bool) : Nat :=
  let ext := s++[b]
  if forbidden.any (fun w => w.isSuffixOf ext) then prefixes.size
  else prefixes.findIdx (fun w => w.isSuffixOf ext)

private def steps := prefixes.map fun s => (nextState s false,nextState s true)
private def move (s : Nat) (b : Bool) :=
  let pair := steps[s]?.getD (prefixes.size,prefixes.size)
  if b then pair.2 else pair.1

/-- Credit sufficient for a continuation of at most n steps. A forbidden
transition contributes zero. A fixed point is checked below, edge by edge. -/
private def credits : Nat → Array Nat
  | 0 => Array.replicate prefixes.size 0
  | n+1 =>
    let prev := credits n
    steps.map fun (l,r) => max (prev[l]?.getD 0-38)
      (if r<prefixes.size then 45+prev[r]?.getD 0-38 else 0)

private def creditTable := credits 234
private def credit (s : Nat) := creditTable[s]?.getD 0
private def initial := prefixes.findIdx List.isEmpty

private theorem start : initial<prefixes.size ∧ memoryWord initial=[] ∧ credit initial=66 := by
  native_decide

/-- The numerical choices are untrusted. Each accepted edge must remember a
real suffix and pay for its bit. Each rejected edge must exhibit a forbidden
suffix. These checks, plus initial credit, suffice for the global bound. -/
private def valid (s : Nat) (b : Bool) : Bool :=
  let j:=move s b
  let ext:=memoryWord s++[b]
  if j<prefixes.size then (memoryWord j).isSuffixOf ext &&
    decide (45*b.toNat+credit j≤38+credit s)
  else forbidden.any fun q=>q.isSuffixOf ext

private theorem verified : ∀s : Fin prefixes.size, valid s.val false=true ∧ valid s.val true=true := by
  native_decide

private theorem accepted (s : Nat) (b : Bool) (pre bs : List Bool) (ok : s<prefixes.size)
    (suffix : memoryWord s <:+ pre) (safeWord : ∀x∈forbidden, ¬x <:+: pre++b::bs) :
    let j:=move s b
    j<prefixes.size ∧ memoryWord j <:+ pre++[b] ∧ 45*b.toNat+credit j≤38+credit s := by
  let j := move s b
  let ext := memoryWord s++[b]
  have checked : valid s b=true := by
    cases b
    · exact (verified ⟨s,ok⟩).1
    · exact (verified ⟨s,ok⟩).2
  have longer : ext <:+ pre++[b] := by
    obtain ⟨left,eq⟩:=suffix
    exact ⟨left,by simp [ext,←List.append_assoc,eq]⟩
  by_cases inside : j<prefixes.size
  · change (if j<prefixes.size then _ else _)=true at checked
    rw [ite_eq_left inside,Bool.and_eq_true] at checked
    exact ⟨inside, (List.isSuffixOf_iff_suffix.mp checked.1).trans longer,of_decide_eq_true checked.2⟩
  · change (if j<prefixes.size then _ else _)=true at checked
    rw [ite_eq_right inside] at checked
    obtain ⟨x,hx,bad⟩:=List.any_eq_true.mp checked
    have bad' := ((List.isSuffixOf_iff_suffix.mp bad).trans longer).isInfix
    exact False.elim (safeWord _ hx (by simpa using bad'.trans (List.prefix_append (pre++[b]) bs).isInfix))

private theorem price (pre rest : List Bool) (s : Nat) (ok : s<prefixes.size)
    (suffix : memoryWord s <:+ pre) (safeWord : ∀x∈forbidden, ¬x <:+: pre++rest) :
    45*rest.count true ≤ 38*rest.length+credit s := by
  induction rest generalizing s pre with
  | nil => simp
  | cons b bs ih =>
    obtain ⟨inside,suff,cost⟩:=accepted s b pre bs ok suffix safeWord
    have n:=ih (pre++[b]) _ inside suff (by simpa using safeWord)
    cases b <;> simp at cost ⊢ <;> omega

/-- Every interval, from any position and for any marks in distinct rotation
classes, obeys the same weighted bound. -/
theorem interval_price {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i n : ℕ) : 45*count p i n≤38*n+66 := by
  have h:=price [] (mask p i n) initial start.1 (by simp [start.2.1]) (by simpa using safe w m i n)
  rw [mark_count] at h
  simpa [mask,start.2.2] using h

theorem path_cap {s t : Six} {es : List Six} (r : Route src dst s es t)
    (width : ∀e∈es,e.length=7) : 45*classCount s es≤38*(es.length+1)+66 := by
  obtain ⟨u,I,w,m,h⟩:=open_observations r width
  rw [←h]
  exact interval_price w m 0 (es.length+1)

/-- Exact forward reward of the suffix automaton for all horizons through
283. This is only an upper bound on how many distinct real classes occur. -/
private def levels : Array (Array Nat) :=
  (List.range 283).foldl (fun a _ =>
    let prev := a.back!
    a.push (steps.map fun (l,r) =>
      max (prev[l]?.getD 0) (if r<prefixes.size then 1+prev[r]?.getD 0 else 0)))
    #[Array.replicate prefixes.size 0]

private def upper (n s : Nat) := ((levels[n]?.getD #[])[s]?).getD 0

private theorem upper_step :
    ∀n : Fin 283, ∀s : Fin prefixes.size, ∀b : Bool,
      move s.val b<prefixes.size →
        b.toNat+upper n.val (move s.val b)≤upper (n.val+1) s.val := by native_decide

private theorem upper_read (pre rest : List Bool) (s : Nat) (ok : s<prefixes.size)
    (small : rest.length≤283) (suffix : memoryWord s <:+ pre)
    (safeWord : ∀x∈forbidden, ¬x <:+: pre++rest) :
    rest.count true ≤ upper rest.length s := by
  induction rest generalizing s pre with
  | nil => simp
  | cons b bs ih =>
    have sz : bs.length<283 := by simpa using small
    obtain ⟨inside,suff,_⟩:=accepted s b pre bs ok suffix safeWord
    have child:=ih (pre++[b]) _ inside (by omega) suff (by simpa using safeWord)
    have cost:=upper_step ⟨bs.length,sz⟩ ⟨s,ok⟩ b inside
    change b.toNat + upper bs.length (move s b)≤ upper (bs.length+1) s at cost
    cases b <;> simp only [List.count_cons_self,List.count_cons_of_ne (by decide : false≠true),
      List.length_cons,Bool.toNat_false,Bool.toNat_true] at * <;> omega

private theorem interval_upper {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i n : ℕ) (sm : n≤283) : count p i n≤upper n initial := by
  have b:=upper_read [] (mask p i n) initial start.1 (by simpa [mask] using sm)
    (by simp [start.2.1]) (by simpa using safe w m i n)
  rw [mark_count] at b
  simpa [mask] using b

private theorem gainTable : ∀ k : Fin 258, 6*(upper (k.val+1) initial-1)≤5*k.val+23 := by native_decide

theorem short_gain {s t : Six} {es : List Six} (r : Route src dst s es t)
    (width : ∀e∈es,e.length=7) (small : es.length<258) :
    6*(classCount s es-1)≤5*es.length+23 := by
  obtain ⟨u,I,w,m,h⟩:=open_observations r width
  have lim:=gainTable ⟨es.length,small⟩
  have real:=interval_upper w m 0 (es.length+1) (by omega)
  rw [h] at real
  exact (Nat.mul_le_mul_left 6 (Nat.sub_le_sub_right real 1)).trans lim

theorem interval111 {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : ℕ) : count p i 111≤94 :=
  (interval_upper w m i 111 (by decide)).trans (by native_decide)

#print axioms path_cap
#print axioms short_gain
end ResidualDensity.WeightedMarks

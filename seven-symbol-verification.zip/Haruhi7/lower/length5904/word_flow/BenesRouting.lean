import Mathlib.Combinatorics.Hall.Finite
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Fin.Tuple.Sort
import Mathlib.Tactic

namespace ExactWordFlow.BenesRouting

/-- First coordinates of the two output wires reachable from an input pair. -/
private def neighbors {A : Type} [DecidableEq A] (p : Equiv.Perm (A × Bool)) (i : A) : Finset A :=
  Finset.univ.image fun b : Bool => (p (i,b)).1

private theorem hall {A : Type} [Fintype A] [DecidableEq A] (p : Equiv.Perm (A × Bool))
    (s : Finset A) : s.card ≤ (s.biUnion (neighbors p)).card := by
  classical
  let X := s ×ˢ (Finset.univ : Finset Bool)
  let Y := s.biUnion (neighbors p) ×ˢ (Finset.univ : Finset Bool)
  have sub : X.image p ⊆ Y := by
    intro z hz
    obtain ⟨⟨i,b⟩,hi,rfl⟩ := Finset.mem_image.mp hz
    refine Finset.mem_product.mpr ⟨Finset.mem_biUnion.mpr ⟨i,(Finset.mem_product.mp hi).1,?_⟩,Finset.mem_univ _⟩
    exact Finset.mem_image.mpr ⟨b,Finset.mem_univ _,rfl⟩
  have h := Finset.card_le_card sub
  simp only [Finset.card_image_of_injective _ p.injective, X, Y, Finset.card_product,
    Finset.card_univ, Fintype.card_bool] at h
  omega

/-- One configurable input layer, two independently routed half-sized networks
and one configurable output layer realize any prescribed wire permutation. -/
theorem split {A : Type} [Fintype A] [DecidableEq A] (p : Equiv.Perm (A × Bool)) :
    ∃ (a z : A → Bool) (top bottom : Equiv.Perm A), ∀ i,
      p (i,a i) = (top i, z (top i)) ∧
      p (i,!(a i)) = (bottom i, !(z (bottom i))) := by
  classical
  obtain ⟨f,inj,hf⟩ := (Finset.all_card_le_biUnion_card_iff_existsInjective' (neighbors p)).mp (hall p)
  let top := Equiv.ofBijective f ⟨inj,Finite.surjective_of_injective inj⟩
  have hchoose (i : A) : ∃ b : Bool, (p (i,b)).1=top i := by
    obtain ⟨b,_,hb⟩ := Finset.mem_image.mp (hf i)
    exact ⟨b,hb⟩
  choose a ha using hchoose
  let z := fun j => (p (top.symm j,a (top.symm j))).2
  have first (i : A) : p (i,a i) = (top i,z (top i)) := by
    exact Prod.ext (ha i) (by simp [z])
  let g := fun i => (p (i,!(a i))).1
  have second (i : A) : p (i,!(a i)) = (g i, !(z (g i))) := by
    refine Prod.ext rfl ?_
    have unused : (p (i,!(a i))).2 ≠ z (g i) := by
      intro eq
      have h : p (i,!(a i)) = p (top.symm (g i),a (top.symm (g i))) := by
        rw [first,Equiv.apply_symm_apply]
        exact Prod.ext rfl eq
      have e := p.injective h
      have fst := congrArg Prod.fst e
      have snd := congrArg Prod.snd e
      change i = top.symm (g i) at fst
      change (!(a i)) = a (top.symm (g i)) at snd
      rw [←fst] at snd
      cases h : a i <;> simp [h] at snd
    cases atval : z (g i) <;> cases val : (p (i,!(a i))).2 <;> simp_all
  have ginj : Function.Injective g := by
    intro i j eq
    have h : p (i,!(a i)) = p (j,!(a j)) := by rw [second,second,eq]
    exact congrArg Prod.fst (p.injective h)
  let bottom := Equiv.ofBijective g ⟨ginj,Finite.surjective_of_injective ginj⟩
  exact ⟨a,z,top,bottom,fun i=>⟨first i,second i⟩⟩

/-- The last bit selects the first or second wire of an adjacent pair. -/
abbrev Wire : Nat → Type
  | 0 => Unit
  | d+1 => Wire d × Bool

instance wireZeroSubsingleton : Subsingleton (Wire 0) := inferInstanceAs (Subsingleton Unit)

instance wireFintype (d : Nat) : Fintype (Wire d) := by
  induction d with
  | zero => exact inferInstanceAs (Fintype Unit)
  | succ d ih => exact inferInstanceAs (Fintype (Wire d × Bool))

instance wireDecidableEq (d : Nat) : DecidableEq (Wire d) := by
  induction d with
  | zero => exact inferInstanceAs (DecidableEq Unit)
  | succ d ih => exact inferInstanceAs (DecidableEq (Wire d × Bool))

/-- With two wires the code uses just a single switch. -/
abbrev Settings : Nat → Type
  | 0 => Unit
  | 1 => Bool
  | d+2 => (Wire (d+1) → Bool) × (Wire (d+1) → Bool) × Settings (d+1) × Settings (d+1)

/-- Destination of an input wire under the chosen switch settings. -/
def route : (d : Nat) → Settings d → Wire d → Wire d
  | 0, _, i => i
  | 1, flip, (_,b) => ((), if b then !flip else flip)
  | d+2, (first,last,high,low), (i,b) =>
    if b=first i then
      let j := route (d+1) high i
      (j,last j)
    else
      let j := route (d+1) low i
      (j,!(last j))

/-- All permutations of the wires have a setting of this exact topology. -/
theorem rearrangeable : ∀ (d : Nat) (p : Equiv.Perm (Wire d)),
    ∃ s : Settings d, ∀ i, route d s i = p i
  | 0,p => ⟨(),fun _ => @Subsingleton.elim Unit _ _ _⟩
  | 1,p => by
    let a : Bool := (p ((),false)).2
    have neq : (p ((),true)).2 ≠ a := by
      intro h
      have he : p ((),true) = p ((),false) := Prod.ext (Subsingleton.elim ..) h
      have hi := p.injective he
      have impossible : true = false := congrArg Prod.snd hi
      contradiction
    refine ⟨a,?_⟩
    rintro ⟨⟨⟩, b⟩
    apply Prod.ext (Subsingleton.elim ..)
    cases b with
    | false => rfl
    | true =>
      change (!a) = (p ((),true)).2
      cases h : (p ((),true)).2 <;> cases ha : a <;> simp_all
  | d+2,p => by
    obtain ⟨a,z,top,bottom,half⟩ := split p
    obtain ⟨high,hhigh⟩ := rearrangeable (d+1) top
    obtain ⟨low,hlow⟩ := rearrangeable (d+1) bottom
    refine ⟨(a,z,high,low),?_⟩
    rintro ⟨i,b⟩
    by_cases h : b=a i
    · subst b
      change (if a i = a i then _ else _) = _
      rw [ite_eq_left rfl, hhigh]
      exact (half i).1.symm
    · have hb : b=(!(a i)) := by cases b <;> cases ha : a i <;> simp_all
      change (if b = a i then _ else _) = _
      rw [ite_eq_right h, hlow, hb]
      exact (half i).2.symm

/-- Consecutive numbering. The product code sends (i,b) to 2*i+b. -/
def index : (d : Nat) → (Wire d ≃ Fin (2^d))
  | 0 => (Equiv.ofUnique Unit (Fin 1))
  | d+1 => (((index d).prodCongr finTwoEquiv.symm).trans finProdFinEquiv).trans
      (finCongr (pow_succ 2 d).symm)

theorem all_indices (d : Nat) (p : Equiv.Perm (Fin (2^d))) :
    ∃ s : Settings d, ∀ i, index d (route d s ((index d).symm i)) = p i := by
  obtain ⟨s,h⟩ := rearrangeable d (((index d).trans p).trans (index d).symm)
  exact ⟨s,fun i => by simp [h]⟩

theorem all_2048 (p : Equiv.Perm (Fin 2048)) :
    ∃ s : Settings 11, ∀ i, index 11 (route 11 s ((index 11).symm i)) = p i :=
  all_indices 11 p

/-- Input-to-output routing for the permutation that stably sorts the keys. -/
theorem can_sort {K : Type} [LinearOrder K] (key : Fin 2048 → K) :
    ∃ (s : Settings 11) (order : Equiv.Perm (Fin 2048)),
      Monotone (key ∘ order) ∧
      ∀ j, index 11 (route 11 s ((index 11).symm (order j))) = j := by
  let order := Tuple.sort key
  obtain ⟨s,h⟩ := all_2048 order.symm
  exact ⟨s,order,Tuple.monotone_sort key,fun j => (h (order j)).trans (order.symm_apply_apply j)⟩

/-- The array operation of a switch network. The same switch bit is used
for every field of a record, so its key and payload move together. -/
def run {V : Type} : (d : Nat) → Settings d → (Wire d → V) → Wire d → V
  | 0,_,xs,i => xs i
  | 1,flip,xs,(_,b) => xs ((), if b then !flip else flip)
  | d+2,(first,last,high,low),xs,(j,b) =>
    if b=last j then
      run (d+1) high (fun i => xs (i,first i)) j
    else
      run (d+1) low (fun i => xs (i,!(first i))) j

theorem run_at_route {V : Type} : ∀ (d : Nat) (s : Settings d) (xs : Wire d → V) (i : Wire d),
    run d s xs (route d s i) = xs i
  | 0,_,_,_ => rfl
  | 1,flip,xs,(⟨⟩,b) => by cases flip <;> cases b <;> rfl
  | d+2,(first,last,high,low),xs,(i,b) => by
    by_cases h : b=first i
    · subst b
      simp only [route,run,ite_true,eq_self,run_at_route (d+1)]
    · have hb : b=(!(first i)) := by cases b <;> cases hi : first i <;> simp_all
      simp only [route,h,ite_false,run]
      have no : (!(last (route (d+1) low i))) ≠ last (route (d+1) low i) := by
        cases last (route (d+1) low i) <;> decide
      rw [ite_eq_right no,run_at_route (d+1),hb]

/-- All 2048 input records can be placed in nondecreasing key order, and the
output records are exactly the inputs indexed by a single permutation. -/
theorem sorted_records {V K : Type} [LinearOrder K] (key : V → K) (xs : Fin 2048 → V) :
    ∃ (s : Settings 11) (order : Equiv.Perm (Fin 2048)),
      Monotone (fun i => key (xs (order i))) ∧
      ∀ j, run 11 s (fun w => xs (index 11 w)) ((index 11).symm j) = xs (order j) := by
  obtain ⟨s,order,mono,h⟩ := can_sort (key ∘ xs)
  refine ⟨s,order,mono,fun j => ?_⟩
  have dest := congrArg (index 11).symm (h j)
  simp only [Equiv.symm_apply_apply] at dest
  rw [←dest,run_at_route]
  simp

@[simp] theorem index_pair (d : Nat) (i : Wire d) (b : Bool) :
    (index (d+1) (i,b)).val = (if b then 1 else 0) + 2*(index d i).val := by
  cases b <;> rfl

#print axioms sorted_records

#print axioms all_2048
#print axioms can_sort
end ExactWordFlow.BenesRouting

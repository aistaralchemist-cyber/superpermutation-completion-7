import CompactGateSemantics
import SatGateTrace

namespace ExactWordFlow.CompactWordCircuit
open SatGateTrace (Lit Op Gate)

def wireLit (x : W) : Lit := (x.natAbs-1,decide (0<x))
def args : Event → List W
  | .fresh _ => []
  | .assertion xs | .gateOr xs => xs
  | .gateMux c a b => [c,a,b]

def operation : Event → Op
  | .fresh _ => .input
  | .assertion xs => .clause (xs.map wireLit)
  | .gateOr xs => .either (xs.map wireLit)
  | .gateMux c a b => .mux (wireLit c) (wireLit a) (wireLit b)

private theorem neg_lit {x : W} (hz : x≠0) : wireLit (-x) = SatGateTrace.neg (wireLit x) := by
  change Int at x
  by_cases h:0<x
  · simp [wireLit,SatGateTrace.neg,h,h.le]
  · have lt : x<0 := lt_of_le_of_ne (le_of_not_gt h) hz
    simp [wireLit,SatGateTrace.neg,h,lt]

theorem evaluated_lit {x : W} (nz : x≠0) (v : Nat → Bool) :
    SatGateTrace.val v (wireLit x) = wire v x := by
  change Int at x
  by_cases h : 0<x
  · simp [SatGateTrace.val,wireLit,wire,h,not_lt.mpr h.le]
  · have lt : x<0 := lt_of_le_of_ne (le_of_not_gt h) nz
    simp [SatGateTrace.val,wireLit,wire,h,lt]

@[simp] private theorem out_lit (n : Nat) : wireLit (Int.ofNat (n+1)) = (n,true) := by
  apply Prod.ext
  · rfl
  · change decide (0 < (Int.ofNat (n+1))) = true
    apply decide_eq_true
    change (0 : Int) < ((n+1 : Nat) : Int)
    exact_mod_cast Nat.zero_lt_succ n

private theorem emit_rows (e : Event) (n : Nat) (nz : ∀x∈args e,x≠0) :
    ((operation e).emit n).flatMap Gate.rows =
      (localClauses (Int.ofNat (n+1)) e).map (List.map wireLit) := by
  have nonzero : (Int.ofNat (n+1)) ≠ 0 := by exact Int.ofNat_ne_zero.mpr (Nat.succ_ne_zero n)
  cases e with
  | fresh s => rfl
  | assertion xs => rfl
  | gateOr xs =>
    simp only [operation,Op.emit,List.flatMap_cons,List.flatMap_nil,List.append_nil,
      Gate.rows,localClauses,List.map_cons,neg_lit nonzero,out_lit,List.map_map]
    congr 1
    apply List.map_congr_left
    intro x hx
    simp only [Function.comp_apply,List.map_cons,List.map_nil,neg_lit (nz x hx),out_lit]
  | gateMux c a b =>
    have hc:=nz c (by simp [args])
    have ha:=nz a (by simp [args])
    have hb:=nz b (by simp [args])
    simp only [operation,Op.emit,Gate.rows,localClauses,neg_lit nonzero,neg_lit hc,neg_lit ha,neg_lit hb,SatGateTrace.neg,
      List.flatMap_cons,List.flatMap_nil,List.append_nil,List.map_cons,List.map_nil,out_lit,Bool.not_true]

def signedRows (n : Nat) : List Event → List (List W)
  | [] => []
  | e::es => localClauses (Int.ofNat (n+1)) e ++ signedRows (advance n e) es

theorem rows_exact (es : List Event) (n : Nat) (nz : ∀e∈es,∀x∈args e,x≠0) :
    (SatGateTrace.compile n (es.map operation)).flatMap Gate.rows =
      (signedRows n es).map (List.map wireLit) := by
  induction es generalizing n with
  | nil => rfl
  | cons e es ih =>
    have next : (operation e).next n = advance n e := by cases e <;> rfl
    simp only [List.map_cons,SatGateTrace.compile,List.flatMap_append,signedRows,List.map_append,
      emit_rows e n (nz e List.mem_cons_self),next,ih _ (fun a ha=>nz a (List.mem_cons_of_mem _ ha))]

def certFormula (t : Tape) := SatGateTrace.formula (SatGateTrace.compile 0 (t.body.toList.map operation))

/-- The actual output rows, after DIMACS-to-Lean reindexing, are the very
clauses checked by the LRAT certificate API. -/
theorem formula_rows (t : Tape) (nz : ∀e∈t.body.toList,∀x∈args e,x≠0) :
    (certFormula t).clauses =
      ((signedRows 0 t.body.toList).map fun row => Std.Sat.CNF.Clause.ofLiterals (row.map wireLit)).toArray := by
  simp [certFormula,SatGateTrace.formula,rows_exact _ _ nz,List.map_map]

private theorem any_map (xs : List W) (nz : ∀x∈xs,x≠0) (v : Nat → Bool) :
    (xs.map wireLit).any (SatGateTrace.val v) = xs.any (wire v) := by
  induction xs with
  | nil => rfl
  | cons x xs ih => simp only [List.map_cons,List.any_cons,evaluated_lit (nz x List.mem_cons_self),
      ih (fun x hx=>nz x (List.mem_cons_of_mem _ hx))]

private theorem advance_meaning (e : Event) (n : Nat) (v : Nat → Bool) (nz : ∀x∈args e,x≠0) :
    (∀g∈(operation e).emit n,g.holds v) ↔ gateMeaning v (Int.ofNat (n+1)) e := by
  have out : wire v (Int.ofNat (n+1)) = v n := by rfl
  cases e with
  | fresh _ => simp [operation, Op.emit,gateMeaning]
  | assertion xs => simp only [operation,Op.emit,List.mem_singleton,forall_eq,Gate.holds,gateMeaning,any_map xs nz]
  | gateOr xs => simp only [operation,Op.emit,List.mem_singleton,forall_eq,Gate.holds,gateMeaning,any_map xs nz,out]
  | gateMux c a b =>
    simp only [operation,Op.emit,List.mem_singleton,forall_eq,Gate.holds,gateMeaning,out,evaluated_lit (x:=c) (nz c (by simp [args])),
      evaluated_lit (x:=a) (nz a (by simp [args])),evaluated_lit (x:=b) (nz b (by simp [args]))]

theorem semantic_trace (es : List Event) (n : Nat) (v : Nat → Bool) (nz : ∀e∈es,∀x∈args e,x≠0) :
    (∀g∈SatGateTrace.compile n (es.map operation), g.holds v) ↔ tailMeaning v n es := by
  induction es generalizing n with
  | nil => simp [SatGateTrace.compile,tailMeaning]
  | cons e es ih =>
    have next : (operation e).next n = advance n e := by cases e <;> rfl
    simp only [List.map_cons,SatGateTrace.compile,List.forall_mem_append,next,
      advance_meaning e n v (nz e List.mem_cons_self),ih _ (fun a ha=>nz a (List.mem_cons_of_mem _ ha)), tailMeaning]

theorem cert_formula_iff (t : Tape) (v : Nat → Bool) (nz : ∀e∈t.body.toList,∀x∈args e,x≠0) :
    (certFormula t).eval v = true ↔ tailMeaning v 0 t.body.toList :=
  (SatGateTrace.trace_iff ..).trans (semantic_trace _ _ _ nz)

/-- Executable, input-independent scoping check. Its recursive call is in tail
position. Every signed input literal names a previously allocated variable. -/
def checkScope (n : Nat) : List Event → Bool
  | [] => true
  | e::es => if (args e).all (fun x=>decide (x≠0 ∧ x.natAbs≤n)) then checkScope (advance n e) es else false

private theorem op_args (e : Event) : (operation e).args = (args e).map wireLit := by
  cases e <;> rfl

theorem scope_checked {es : List Event} {n : Nat} (ok : checkScope n es = true) :
    (∀e∈es,∀x∈args e,x≠0) ∧ SatGateTrace.wellScoped n (es.map operation) := by
  induction es generalizing n with
  | nil => exact ⟨by simp, trivial⟩
  | cons e es ih =>
    change (if (args e).all (fun x=>decide (x≠0 ∧ x.natAbs≤n)) then _ else false) = true at ok
    split at ok
    next h =>
      have harg (x : W) (hx : x∈args e) : x≠0 ∧ x.natAbs≤n :=
        of_decide_eq_true (List.all_eq_true.mp h x hx)
      obtain ⟨nz,scope⟩:=ih ok
      refine ⟨?_,?_,?_⟩
      · intro f hf
        rcases List.mem_cons.mp hf with rfl|hf
        · exact fun x hx=>(harg x hx).1
        · exact nz f hf
      · intro l hl
        rw [op_args] at hl
        obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hl
        obtain ⟨hne,lo⟩:=harg x hx
        have pn:=Int.natAbs_pos.mpr hne
        change x.natAbs-1<n
        omega
      · have ne : (operation e).next n = advance n e := by cases e <;> rfl
        simpa only [ne] using scope
    next => contradiction

theorem checked_satisfies {t : Tape} {inputs : Nat → Bool} (scope : checkScope 0 t.body.toList = true)
    (assertions : SatGateTrace.passes inputs 0 (fun _=>false) (t.body.toList.map operation)=true) :
    (certFormula t).eval
      (SatGateTrace.run inputs 0 (fun _=>false) (t.body.toList.map operation)) = true :=
  SatGateTrace.compile_satisfies (scope_checked scope).2 assertions

#print axioms checked_satisfies
#print axioms formula_rows
#print axioms cert_formula_iff
end ExactWordFlow.CompactWordCircuit

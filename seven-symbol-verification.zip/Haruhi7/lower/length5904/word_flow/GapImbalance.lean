import SquareGeometry

/-! Double contacts between wheels missing fixed symbols are matched one
for one by a five-letter gap signature. A fixed cyclic order of the five
letters admits five insertion positions. -/
namespace WheelContacts.GapImbalance
open ExactWordFlow SquareDual

def marks (W : Finset Block) (a b : Fin 7) :=
  (W.filter (fun s => missing s=a)).image (fun s => afterGap s b)
def positions (q : Block) : Finset Block := (Finset.range 5).image (fun i => q.rotate i)
def doubles (W : Finset Block) (a b : Fin 7) : Finset (Block × Block) :=
  (W.product W).filter (fun p => missing p.1=a ∧ missing p.2=b ∧
    (wheel p.1 ∩ wheel p.2).card=2)

private theorem decode_table : ∀s∈bases, ∀ b : Fin 7, b≠missing s →
    canonicalWheel (b :: afterGap s b)=s := by native_decide

private theorem gap_inj {s t : Block} (hs : s∈bases) (ht : t∈bases) (b : Fin 7)
    (sb : b≠missing s) (tb : b≠missing t) (eq : afterGap s b=afterGap t b) : s=t :=
  (decode_table s hs b sb).symm.trans ((congrArg (fun u => canonicalWheel (b::u)) eq).trans
    (decode_table t ht b tb))

/-- The pair of absent symbols fixes which two wheels can realize any
common marked gap. -/
theorem exact_gap_count (W : Finset Block) (legal : ∀s∈W, s∈bases)
    {a b : Fin 7} (ne : a≠b) :
    (doubles W a b).card=(marks W a b ∩ marks W b a).card := by
  let f : Block × Block → Block := fun p => afterGap p.1 b
  have info (p : Block × Block) (h : p∈doubles W a b) :
      p.1∈W ∧ p.2∈W ∧ missing p.1=a ∧ missing p.2=b ∧ afterGap p.1 b=afterGap p.2 a := by
    obtain ⟨ws,ma,mb,two⟩ := Finset.mem_filter.mp h
    obtain ⟨hs,ht⟩ := Finset.mem_product.mp ws
    have st : p.1≠p.2 := fun eq => ne (ma.symm.trans ((congrArg missing eq).trans mb))
    have gap := ((double_iff (legal _ hs) (legal _ ht) st).mp two).2
    rw [ma,mb] at gap
    exact ⟨hs,ht,ma,mb,gap⟩
  have bij : (doubles W a b).image f=marks W a b ∩ marks W b a := by
    ext u
    constructor
    · rintro hu
      obtain ⟨p,h,rfl⟩ := Finset.mem_image.mp hu
      obtain ⟨hs,ht,ma,mb,gap⟩ := info p h
      exact Finset.mem_inter.mpr ⟨Finset.mem_image.mpr ⟨_,Finset.mem_filter.mpr ⟨hs,ma⟩,rfl⟩,
        Finset.mem_image.mpr ⟨_,Finset.mem_filter.mpr ⟨ht,mb⟩,gap.symm⟩⟩
    · intro hu
      obtain ⟨l,r⟩ := Finset.mem_inter.mp hu
      obtain ⟨s,hs,se⟩ := Finset.mem_image.mp l
      obtain ⟨t,ht,te⟩ := Finset.mem_image.mp r
      obtain ⟨sw,ma⟩ := Finset.mem_filter.mp hs
      obtain ⟨tw,mb⟩ := Finset.mem_filter.mp ht
      have st : s≠t := fun eq => ne (ma.symm.trans ((congrArg missing eq).trans mb))
      have two : (wheel s ∩ wheel t).card=2 := by
        apply (double_iff (legal _ sw) (legal _ tw) st).mpr
        rw [ma,mb]
        exact ⟨ne,se.trans te.symm⟩
      exact Finset.mem_image.mpr ⟨(s,t),Finset.mem_filter.mpr
        ⟨Finset.mem_product.mpr ⟨sw,tw⟩,ma,mb,two⟩,se⟩
  rw [←bij]
  symm
  apply Finset.card_image_of_injOn
  intro p hp q hq same
  obtain ⟨ps,pt,pa,pb,pg⟩ := info p hp
  obtain ⟨qs,qt,qa,qb,qg⟩ := info q hq
  apply Prod.ext
  · exact gap_inj (legal _ ps) (legal _ qs) b (pa ▸ ne.symm) (qa ▸ ne.symm) same
  · exact gap_inj (legal _ pt) (legal _ qt) a (pb ▸ ne) (qb ▸ ne) (pg.symm.trans (same.trans qg))

/-- Charge all mutually disjoint marked-gap cells simultaneously. In each
five-position cell, complementary occupancy exceeding five forces that
many distinct double wheel pairs. -/
theorem charge_cells (W : Finset Block) (legal : ∀s∈W, s∈bases) {a b : Fin 7}
    (ne : a≠b) (cells : Finset (Finset Block))
    (dis : (cells : Set (Finset Block)).PairwiseDisjoint id) :
    ∑ G∈cells, ((marks W a b ∩ G).card + (marks W b a ∩ G).card - G.card)
      ≤ (doubles W a b).card := by
  let A := marks W a b
  let B := marks W b a
  have row (G : Finset Block) :
      (A∩G).card+(B∩G).card-G.card ≤ ((A∩B)∩G).card := by
    have e := Finset.card_union_add_card_inter (A∩G) (B∩G)
    have sub : (A∩G)∪(B∩G) ⊆ G := Finset.union_subset Finset.inter_subset_right Finset.inter_subset_right
    have n := Finset.card_le_card sub
    have eq : (A∩G)∩(B∩G)=(A∩B)∩G := by ext u; simp
    rw [eq] at e
    omega
  let keep (G : Finset Block) := (A∩B)∩G
  have dd : (cells : Set (Finset Block)).PairwiseDisjoint keep := by
    intro x hx y hy different
    exact (dis hx hy different).mono Finset.inter_subset_right Finset.inter_subset_right
  rw [exact_gap_count W legal ne]
  apply (Finset.sum_le_sum (fun G _ => row G)).trans
  rw [←Finset.card_biUnion dd]
  exact Finset.card_le_card (Finset.biUnion_subset.mpr (fun _ _ => Finset.inter_subset_left))

theorem five_positions (q : Block) : (positions q).card≤5 := by
  simpa [positions] using (Finset.card_image_le (s:=Finset.range 5) (f:=fun i => q.rotate i))

#print axioms exact_gap_count
#print axioms charge_cells
end WheelContacts.GapImbalance

import LargeRowParent

namespace ExactWordFlow.LargeRowParent
open SeedWheelCut

/-- Each exceptional row loses exactly one chosen member. A witness records
the rows in their given order and their resulting enlarged initial set. -/
inductive Seeds {α : Type*} [DecidableEq α] :
    Finset α → List (Finset α) → Finset α → Prop where
  | nil (A) : Seeds A [] A
  | cons {A F p Fs Z} : p∈F → Seeds (A∪F.erase p) Fs Z → Seeds A (F::Fs) Z

/-- Once a connected cover is given the exceptional rows may be processed
in any prescribed order. The residual family W is kept fixed throughout. -/
theorem all_rows {α : Type*} [DecidableEq α] {A V : Finset α} {W : Finset (Finset α)}
    (Fs : List (Finset α)) (seed : A⊆V) (ordinary : ∀R∈W,R⊆V)
    (large : ∀F∈Fs,F⊆V ∧ F.Nonempty) (cover : ClosedCover A V (Fs.toFinset∪W)) :
    ∃Z, Seeds A Fs Z ∧ Z⊆V ∧ ClosedCover Z V W := by
  induction Fs generalizing A with
  | nil=>exact ⟨A,.nil _,seed,by simpa using cover⟩
  | cons F Fs ih=>
    obtain ⟨fv,nf⟩:=large F List.mem_cons_self
    have rest (R) (hr:R∈Fs) :=large R (List.mem_cons_of_mem F hr)
    have restIn (R) (hr:R∈Fs.toFinset∪W) : R⊆V:=by
      rcases Finset.mem_union.mp hr with f|w
      · exact (rest R (List.mem_toFinset.mp f)).1
      · exact ordinary R w
    have cc : ClosedCover A V (insert F (Fs.toFinset∪W)):=by simpa using cover
    obtain ⟨p,hp,old⟩:=cut seed fv nf restIn cc
    have next : A∪F.erase p⊆V:=Finset.union_subset seed ((Finset.erase_subset ..).trans fv)
    obtain ⟨Z,parents,inside,closed⟩:=ih next rest old
    exact ⟨Z,.cons hp parents,inside,closed⟩

#print axioms all_rows
end ExactWordFlow.LargeRowParent

import DeletionShadow

namespace ExactWordFlow.LocalDeletion
open SevenWordWindows ResidualDensity DeletionShadow

/-- Consecutive windows of positive width k+1, in order, with multiplicity. -/
def factors {α : Type*} (k : Nat) : List α → List (List α)
  | []=>[]
  | a::as=>if k≤as.length then (a::as.take k)::factors k as else []

def lastPart {α : Type*} (k : Nat) (l : List α) := l.drop (l.length-k)
def localPart {α : Type*} (k : Nat) (l m r : List α) := lastPart k l++m++r.take k

private theorem short {α : Type*} (k : Nat) {x : List α} (small : x.length≤k) : factors k x=[] := by
  cases x with
  | nil=>rfl
  | cons a s=>simp only [List.length_cons] at small; simp [factors,show ¬ k ≤ s.length by omega]

private theorem separator {α : Type*} (k : Nat) (p u z : List α) (width : u.length=k) :
    factors k ((p++u)++z)=factors k (p++u)++factors k (u++z) := by
  induction p with
  | nil=>simp [short k width.le]
  | cons a p ih=>
    have enough : k≤(p++u).length:=by simp [width]
    have wide : k≤((p++u)++z).length:=by simp [width];omega
    have take : ((p++u)++z).take k=(p++u).take k := by
      simp only [List.take_append,Nat.sub_eq_zero_of_le enough,List.take_zero,List.append_nil]
    simp only [List.cons_append,factors,ite_eq_left enough,ite_eq_left wide,take,ih]

private theorem left_parts {α : Type*} (k : Nat) (l r : List α) :
    factors k (l++r)=factors k l++factors k (lastPart k l++r) := by
  by_cases enough : k≤l.length
  · let i:=l.length-k
    have cap : (l.drop i).length=k := by simp [i];omega
    simpa only [List.take_append_drop,lastPart,i] using separator k (l.take i) (l.drop i) r cap
  · have low : l.length≤k:=by omega
    simp [lastPart,Nat.sub_eq_zero_of_le low,short k low]

private theorem right_parts {α : Type*} (k : Nat) (l r : List α) :
    factors k (l++r)=factors k (l++r.take k)++factors k r := by
  by_cases enough : k≤r.length
  · have cap : (r.take k).length=k := by simp [enough]
    simpa only [List.append_assoc,List.take_append_drop] using separator k l (r.take k) (r.drop k) cap
  · have low : r.length≤k:=by omega
    simp [List.take_of_length_le low,short k low]

theorem factorization {α : Type*} (k : Nat) (l m r : List α) :
    factors k (l++m++r)=factors k l++factors k (localPart k l m r)++factors k r := by
  calc
    _ = factors k l++factors k (lastPart k l++(m++r)) := by rw [List.append_assoc,left_parts]
    _ = factors k l++(factors k (localPart k l m r)++factors k r) := by
      rw [←List.append_assoc,right_parts k (lastPart k l++m) r];rfl
    _ = _ := List.append_assoc .. |>.symm

/-- An equality of natural numbers, valid even when either flank is shorter
than k or the two replacement strings have unequal lengths. -/
theorem change {α : Type*} (k : Nat) (f : List (List α)→Nat)
    (add : ∀s t,f (s++t)=f s+f t) (l m n r : List α) :
    f (factors k (l++m++r)) + f (factors k (localPart k l n r)) =
      f (factors k (l++n++r)) + f (factors k (localPart k l m r)) := by
  rw [factorization k l m r,factorization k l n r]
  simp only [add]
  omega

theorem windows_eq (w : Block) : windows w=factors 6 w := by
  induction w with
  | nil=>rfl
  | cons a w ih=>simp [windows,factors,ih]

theorem six_eq (w : Block) : sixWindows w=factors 5 w := by
  induction w with
  | nil=>rfl
  | cons a w ih=>
    by_cases wide : 5≤w.length
    · simp [sixWindows,factors,wide,ih]
    · simp [sixWindows,factors,wide,ih,short 5 (show w.length≤5 by omega)]

def freq6 (w c : Block) :=
  ((sixWindows w).filterMap (fun u=>if full u then some (tag u) else none)).count c

theorem anchors_long {w : Block} (long : 6≤w.length) : RotationReinsert.anchors w=sixWindows w := by
  induction w with
  | nil=>simp at long
  | cons a xs ih=>
    have five : 5≤xs.length:=by simpa using long
    by_cases six : 6≤xs.length
    · have tail:=ih six
      unfold RotationReinsert.anchors at tail ⊢
      simp only [sixWindows,ite_eq_left five,windows,ite_eq_left six,List.map_cons,dst,
        List.drop_succ_cons,List.drop_zero,List.take_succ_cons] at ⊢
      rw [←tail]
    · have no : sixWindows xs=[]:=by rw [six_eq]; exact short 5 (by omega)
      simp [RotationReinsert.anchors,windows,six,sixWindows,five,no]

theorem freq6_anchors (w c : Block) : freq6 w c=
    (((RotationReinsert.anchors w).filter (fun u=>decide (full u))).map tag).count c := by
  have list_eq (ls : List Block) : ls.filterMap (fun u=>if full u then some (tag u) else none)=
      (ls.filter (fun u=>decide (full u))).map tag := by
    induction ls with
    | nil=>rfl
    | cons a xs ih=>by_cases yes : full a <;> simp [yes,ih]
  by_cases long : 6≤w.length
  · rw [anchors_long long,freq6,list_eq]
  · have no : sixWindows w=[]:=by rw [six_eq];exact short 5 (by omega)
    have win : windows w=[]:=by rw [windows_eq];exact short 6 (by omega)
    have nfull : ¬full w :=fun h=>long h.1.ge
    simp [freq6,RotationReinsert.anchors,no,win,List.take_of_length_le (by omega : w.length≤6),nfull]

/-- Multiplicity of each clean seven-letter permutation. -/
theorem clean7_count (l : Block) (x : Fin 7) (r p : Block) :
    (good (l++[x]++r)).count p + (good (localPart 6 l [] r)).count p =
      (good (l++r)).count p + (good (localPart 6 l [x] r)).count p := by
  simpa only [good,windows_eq,List.append_nil] using change 6
    (fun s : List Block=>(s.filter (fun q=>decide q.Nodup)).count p)
    (by simp [List.filter_append,List.count_append]) l [x] [] r

theorem clean7_length (l : Block) (x : Fin 7) (r : Block) :
    (good (l++[x]++r)).length + (good (localPart 6 l [] r)).length =
      (good (l++r)).length + (good (localPart 6 l [x] r)).length := by
  simpa only [good,windows_eq,List.append_nil] using change 6
    (fun s : List Block=>(s.filter (fun q=>decide q.Nodup)).length)
    (by simp [List.filter_append,List.length_append]) l [x] [] r

/-- Multiplicity of a visited rotation class among full six-letter contexts. -/
theorem visit6_count (l : Block) (x : Fin 7) (r c : Block) :
    freq6 (l++[x]++r) c + freq6 (localPart 5 l [] r) c =
      freq6 (l++r) c + freq6 (localPart 5 l [x] r) c := by
  simpa only [freq6,six_eq,List.append_nil] using change 5
    (fun s : List Block=>(s.filterMap (fun u=>if full u then some (tag u) else none)).count c)
    (by simp [List.filterMap_append,List.count_append]) l [x] [] r

#print axioms clean7_count
#print axioms visit6_count
end ExactWordFlow.LocalDeletion

import Cap35ActualShape

namespace ExactWordFlow.ShortWheelPeriod
open DirectedEuler ResidualDensity Cap35Rigidity
open private observations from Cap35ActualShape
open private phase from Cap35Rigidity
open private localMark localCount interval7 from DensityBudget
open private rigid rigid_hop from ResidualDensity

/-- A closed route with six distinct marks per seven positions must actually
contain the five full six-context runs forced by the seams. -/
theorem lower {s : Six} {es : List Six} {d : Nat} (r : Route src dst s es s)
    (wd : ∀e∈es,e.length=7) (len : es.length=7*(d+1)) (wide : 13≤es.length)
    (sat : classCount s es=6*(d+1)) : 30≤classCount s es := by
  classical
  obtain ⟨u,I,w,cy,cnt,mem⟩:=observations r wd (by omega)
  let p:=fun i : Nat => i%es.length∈I
  change CyclicMarked u p es.length at cy
  change count p 0 es.length=classCount s es at cnt
  have cap (i : Nat) : count p i 7≤6:=by
    rw [←localCount i 7]
    exact interval7 w (localMark cy (by omega : 7≤es.length)) i
  have per : ∀i,p (i+7*(d+1))↔p i:=len ▸ cy.periodic
  have total : count p 0 (7*(d+1))=6*(d+1):=len ▸ (cnt.trans sat)
  obtain ⟨each,rep⟩:=SaturatedCyclicWindow.saturation per cap total
  obtain ⟨b,good⟩:=phase (each 0) rep
  have seed:=cy.clean b (by simpa using good 0 0 (by decide))
  have hopStep (k : Nat) : u (b+7*(k+1))=hop (u (b+7*k)) := by
    let i:=b+7*k
    have marks (j : Nat) (hj:j≤5) : p (i+j) ∧ i ≤ i + j ∧ i+j < i + 13 :=
      ⟨good k j (by omega),by omega,by omega⟩
    have later (j : Nat) (hj:j≤5) : p ((i+7)+j) ∧ i ≤ i + 7+j ∧ i+7+j < i + 13 := by
      refine ⟨?_,by omega,by omega⟩
      simpa only [i,Nat.mul_succ,←Nat.add_assoc] using good (k+1) j (by omega)
    simpa only [i,Nat.mul_succ,←Nat.add_assoc] using
      rigid_hop w (localMark (i:=i) (b:=13) cy wide) i marks later
  have starts (k : Nat) : u (b+7*k)=hop^[k] (u b):=by
    induction k with
    | zero=>simp
    | succ k ih=>rw [hopStep,Function.iterate_succ_apply',ih]
  have sub : shape (u b) ⊆ touched (s::es.map dst):=by
    intro t ht
    obtain ⟨k,_,hw⟩:=Finset.mem_biUnion.mp ht
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hw)
    have jb:=List.mem_range.mp hj
    let i:=b+7*k
    have marks (z : Nat) (hz:z≤5) : p (i+z) ∧ i ≤ i + z ∧ i+z < i + 13 :=
      ⟨good k z (by omega),by omega,by omega⟩
    have rot:=rigid w (localMark (i:=i) (b:=13) cy wide) i j (fun z hz=>marks z (by omega))
    rw [show u i=hop^[k] (u b) from starts k] at rot
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨u (i+j),List.mem_filter.mpr
      ⟨mem _,decide_eq_true (cy.clean _ (marks j (by omega)).1)⟩,congrArg tag rot⟩)
  exact (ten (u b) seed).1 ▸ Finset.card_le_card sub

theorem impossible28 {s : Six} {es : List Six} (r : Route src dst s es s)
    (wd : ∀e∈es,e.length=7) (len : es.length=28) : classCount s es≠24 := by
  intro tight
  have h:=lower (d:=3) r wd (by omega) (by omega) (by omega)
  omega

#print axioms impossible28
end ExactWordFlow.ShortWheelPeriod

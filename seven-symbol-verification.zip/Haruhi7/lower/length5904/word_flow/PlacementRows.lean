import PlacementCertificate
import AlmostCover

namespace ExactWordFlow.PlacementCertificate
open SevenWordWindows SuperpermutationBounds Std.Sat

theorem table_size : table.length=5040 := by native_decide

theorem row_injective {r s : Nat} (hr : r<table.length) (hs : s<table.length)
    (eq : row r = row s) : r=s := by
  have nd : table.Nodup := Finset.sort_nodup _ _
  apply nd.eq_of_getElem_eq hr hs
  simpa only [row,List.getElem?_eq_getElem hr,List.getElem?_eq_getElem hs,Option.getD_some] using eq

/-- Relabeling the known 5905 word and deleting its first letter gives an
actual 5904-letter model for every legal clause except one chosen row. -/
theorem satisfiable_without_row {ss : List Schema} (valid : ss.all legal=true)
    {r : Nat} (hr : r<table.length) (omitted : Schema.required r ∉ ss) :
    ∃ v : Nat → Bool, (formula ss).eval v=true := by
  obtain ⟨width,clean⟩ := (mem_reps _).mp (row_mem hr)
  obtain ⟨w,len,hits⟩ := SevenAlmostCover.prescribed_omission (row r) width clean
  refine ⟨truth w,partial_word_satisfies valid len.le ?_⟩
  intro s mem
  cases s with
  | conflict => trivial
  | required t =>
    have ht : t<table.length := of_decide_eq_true (List.all_eq_true.mp valid _ mem)
    obtain ⟨tw,tc⟩ := (mem_reps _).mp (row_mem ht)
    have different : row t ≠ row r := by
      intro same
      exact omitted ((row_injective ht hr same) ▸ mem)
    obtain ⟨left,right,word⟩ := (hits _ tw tc).mpr different
    exact ⟨left,right,word.symm⟩

theorem every_row_required {ss : List Schema} (valid : ss.all legal=true)
    (unsat : (formula ss).Unsat) {r : Nat} (hr : r<5040) : Schema.required r∈ss := by
  by_contra omitted
  obtain ⟨v,sat⟩ := satisfiable_without_row valid (table_size ▸ hr) omitted
  simpa [sat] using unsat v

def requiredRows (ss : List Schema) : List Nat := ss.filterMap fun s => match s with
  | .required r => some r
  | .conflict .. => none

theorem required_clause_width (r : Nat) : (clause (.required r)).literals.length=5898 := by
  simp [clause,CNF.Clause.literals_ofLiterals]

/-- Each occurrence of a positive schema contributes exactly 5898 positive
literals. Duplicating rows can only increase both lower bounds. -/
theorem minimum_manifest {ss : List Schema} (valid : ss.all legal=true)
    (unsat : (formula ss).Unsat) :
    5040 ≤ (requiredRows ss).length ∧ 29725920 ≤ 5898*(requiredRows ss).length := by
  have sub : Finset.range 5040 ⊆ (requiredRows ss).toFinset := by
    intro r hr
    have yes := every_row_required valid unsat (Finset.mem_range.mp hr)
    exact List.mem_toFinset.mpr (List.mem_filterMap.mpr ⟨.required r,yes,rfl⟩)
  have size := Finset.card_le_card sub
  rw [Finset.card_range] at size
  have len := size.trans (List.toFinset_card_le _)
  exact ⟨len,by omega⟩

#print axioms minimum_manifest
end ExactWordFlow.PlacementCertificate

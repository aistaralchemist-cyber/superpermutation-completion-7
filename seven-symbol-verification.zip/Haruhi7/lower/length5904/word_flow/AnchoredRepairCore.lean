import CoreControls
import WheelContacts

namespace ExactWordFlow.AnchoredRepair
open SevenWordWindows ResidualDensity RotationCore RotationReinsert
abbrev Row := Finset Block

def missing (v : Block) : Row := allClasses \ visited v
def options (v : Block) : Finset Row :=
  let D:=missing v
  (((anchors v).filter (fun u=>decide (full u))).map fun u=>D∩WheelContacts.wheel u).toFinset

def level (A : Finset Row) : Nat→Finset Row
  | 0=>{∅}
  | n+1=>
    let S:=level A n
    S∪S.biUnion (fun U=>A.image (fun V=>U∪V))

def absent (v : Block) : Row := missing v \ (options v).biUnion id

structure Report where
  lost : Nat
  unavailable : Nat
  flags : List Bool
  deriving DecidableEq,BEq,Repr

def report (v : Block) : Report :=
  let D:=missing v
  let A:=options v
  ⟨D.card,(D \ A.biUnion id).card,(List.range 6).map (fun n=>decide (D∈level A n))⟩

def positions (w : Block) := (List.range (w.length-18)).filter fun i=>
  (w.drop i).take 6==(w.drop (i+13)).take 6
def excise (w : Block) (i : Nat) := w.take i++w.drop (i+13)
def record := RotationCoreControls.coreWord 628
def sourcePositions := positions record
def census := sourcePositions.map (fun i=>report (excise record i))
def flags (m : Nat) := (List.range 6).map (fun k=>decide (m≤k))

/-- m=6 is a sentinel for the recorded rows with an unreachable tag. -/
def types : List (Report×Nat) :=
  [(⟨5,0,flags 3⟩,12),(⟨5,0,flags 4⟩,15),(⟨5,0,flags 5⟩,5),
   (⟨5,1,flags 6⟩,3),(⟨5,2,flags 6⟩,1),(⟨5,3,flags 6⟩,1)]

def analysisCheck : Bool :=
  census.length==37 && types.all (fun (r,n)=>census.count r==n) &&
  census.all (fun r=>types.any (fun p=>p.1==r))

def witness : Block := [0,3,5,6,1,2,4]
def witnessCheck : Bool :=
  decide (41∈sourcePositions) && decide (witness∈absent (excise record 41))

end ExactWordFlow.AnchoredRepair

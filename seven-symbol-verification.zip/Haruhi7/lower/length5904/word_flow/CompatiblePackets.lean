import ComplementResidue

namespace ExactWordFlow.CompatiblePackets
open SevenWordWindows SeedWheelCut ExtremeWheelCut ComplementResidue
open private pop from ComplementResidue

/-- A single extra root tag pays for at most one unit in the residue
profile of a prescribed partial root. -/
private theorem extension {α β : Type*} [DecidableEq α] [DecidableEq β]
    (P A V : Finset α) (f : α→β) (colors : Finset β) (sub : P⊆A) :
    residue f colors (V\P) ≤ residue f colors (V\A)+(A\P).card := by
  classical
  let E:=(V\P)∩A
  have small : E⊆A\P := by
    intro x hx
    obtain ⟨out,hx⟩:=Finset.mem_inter.mp hx
    exact Finset.mem_sdiff.mpr ⟨hx,(Finset.mem_sdiff.mp out).2⟩
  have split : V\P=(V\A)∪E := by
    ext x
    simp only [E,Finset.mem_sdiff,Finset.mem_union,Finset.mem_inter]
    by_cases yes : x∈A <;> grind
  have apart : Disjoint (V\A) E := by
    apply Finset.disjoint_left.mpr
    exact fun _ hx he=>(Finset.mem_sdiff.mp hx).2 (Finset.mem_inter.mp he).2
  have fiber (c) : (pop f (V\P) c)%5 ≤ (pop f (V\A) c)%5+pop f E c := by
    have eq : pop f (V\P) c=pop f (V\A) c+pop f E c := by
      unfold pop;rw [split, Finset.filter_union, Finset.card_union_of_disjoint]
      exact apart.mono (Finset.filter_subset ..) (Finset.filter_subset ..)
    omega
  have sum:=Finset.sum_le_sum (s:=colors) (fun c _=>fiber c)
  rw [Finset.sum_add_distrib] at sum
  have cap : (∑c∈colors,pop f E c)≤(A\P).card := by
    unfold pop;rw [Finset.sum_card_fiberwise_eq_card_filter]
    exact Finset.card_le_card ((Finset.filter_subset ..).trans small)
  unfold residue;omega

/-- For a partial root P, colour tags outside P by compatible-wheel
components: vertices of every neutral wheel with at least five tags
outside P have one colour there. The conclusion applies to *all* root
supersets A, including those using nonzero total slack. -/
theorem partial_bound {β : Type*} [DecidableEq β] (P A : Finset Block)
    (f : Block→β) (colors : Finset β) {W : Finset (Finset Block)}
    (inside : P⊆A) (legal : W⊆allRows) (linked : ClosedCover A allClasses W)
    (mono : ∀w∈allRows,5≤(w\P).card → ∃z,∀x∈w\P,f x=z) :
    P.card+residue f colors (allClasses\P) ≤ A.card+4*(A.card+5*W.card-720) := by
  have sizes : ∀w∈allRows,w⊆allClasses ∧ w.card≤6 := by native_decide
  have bound:=palette_bound f colors P A allClasses W inside (fun w hw=>sizes w (legal hw))
    (fun w hw U sub full disj=>by
      have inD : U⊆w\P := fun x hx=>Finset.mem_sdiff.mpr ⟨sub hx,Finset.disjoint_left.mp disj hx⟩
      obtain ⟨z,proof⟩:=mono w (legal hw) (full ▸ Finset.card_le_card inD)
      exact ⟨z,fun x hx=>proof x (inD hx)⟩) linked
  have change:=extension P A allClasses f colors inside
  have total : allClasses.card=720 := by native_decide
  rw [total] at bound
  have diff:=Finset.card_sdiff_of_subset inside
  have lt:=Finset.card_le_card inside
  omega

#print axioms partial_bound
end ExactWordFlow.CompatiblePackets

import TourWheelPrice

namespace ExactWordFlow.OpenWheelPacking
open SeedWheelCut
variable {α : Type*} [DecidableEq α]

/-- Five previously unseen vertices from one legal six-wheel, after its
one previously reached parent is removed. -/
def Packet (legal : Finset (Finset α)) (U : Finset α) : Prop :=
  ∃ w∈legal, ∃ p∈w,U=w.erase p ∧ U.card=5

/-- From an arbitrary connected attachment order, keep the steps introducing
five new vertices. Every other step introduces at most four. -/
theorem extract {A V : Finset α} {legal : Finset (Finset α)} (W : Finset (Finset α))
    (board : A⊆V) (allowed : W⊆legal) (rows : ∀w∈W,w⊆V ∧ w.card≤6)
    (link : ClosedCover A V W) :
    ∃ T : Finset (Finset α),
      (∀u∈T,Packet legal u ∧ u⊆V \ A) ∧
      (∀u∈T,∀v∈T,u≠v → Disjoint u v) ∧
      V.card ≤ A.card+4*W.card+T.card := by
  classical
  by_cases move : ∃w∈W,(A∩w).Nonempty ∧ ¬w⊆A
  · obtain ⟨w,hw,⟨p,hp⟩,_⟩:=move
    have pp:=Finset.mem_inter.mp hp
    let B:=A∪w
    let U:=w \ A
    have rest : ClosedCover B V (W.erase w) := by
      intro C seed closed
      apply link C (Finset.subset_union_left.trans seed)
      intro r hr meets
      by_cases eq : r=w
      · exact eq ▸ Finset.subset_union_right.trans seed
      · exact closed _ (Finset.mem_erase.mpr ⟨eq,hr⟩) meets
    obtain ⟨T,ok,apart,count⟩:=extract (legal:=legal) (W.erase w)
      (Finset.union_subset board (rows _ hw).1) ((Finset.erase_subset ..).trans allowed)
      (fun r hr=>rows r (Finset.mem_of_mem_erase hr)) rest
    have wc:=Finset.card_erase_add_one hw
    have newSize : B.card = A.card+U.card := by
      have t:=Finset.card_union_add_card_inter A w
      have z:=Finset.card_sdiff_add_card_inter w A
      rw [Finset.inter_comm w A] at z
      dsimp [B,U]
      omega
    change V.card ≤ B.card+4*(W.erase w).card+T.card at count
    rw [newSize] at count
    have subset : U⊆w.erase p := by
      intro x hx
      have pair:=Finset.mem_sdiff.mp hx
      exact Finset.mem_erase.mpr ⟨fun eq=>pair.2 (eq ▸ pp.1),pair.1⟩
    have er:=(Finset.card_erase_add_one pp.2)
    have wide:=(rows w hw).2
    have bound:=Finset.card_le_card subset
    have shrink (t : Finset α) (ht : t∈T) : t⊆V \ A := by
      intro x hx
      obtain ⟨old,new⟩:=Finset.mem_sdiff.mp ((ok t ht).2 hx)
      exact Finset.mem_sdiff.mpr ⟨old,fun yes=>new (Finset.mem_union_left _ yes)⟩
    by_cases full : U.card=5
    · have eq : U=w.erase p := Finset.eq_of_subset_of_card_le subset (by omega)
      have sep (t : Finset α) (ht : t∈T) : Disjoint U t := by
        apply Finset.disjoint_left.mpr
        intro x hx hy
        exact (Finset.mem_sdiff.mp ((ok t ht).2 hy)).2
          (Finset.mem_union_right _ (Finset.mem_sdiff.mp hx).1)
      have fresh : U∉T := by
        intro yes
        obtain ⟨x,hx⟩:=Finset.card_pos.mp (show 0<U.card by omega)
        exact Finset.disjoint_left.mp (sep _ yes) hx hx
      refine ⟨insert U T,?_,?_,?_⟩
      · intro t ht
        rcases Finset.mem_insert.mp ht with rfl|mem
        · refine ⟨⟨w,allowed hw,p,pp.2,eq,full⟩,?_⟩
          intro x hx
          obtain ⟨mem,absent⟩:=Finset.mem_sdiff.mp hx
          exact Finset.mem_sdiff.mpr ⟨(rows _ hw).1 mem,absent⟩
        · exact ⟨(ok _ mem).1,shrink _ mem⟩
      · intro t ht v hv ne
        rcases Finset.mem_insert.mp ht with rfl|ht <;> rcases Finset.mem_insert.mp hv with rfl|hv
        · exact (ne rfl).elim
        · exact sep _ hv
        · exact (sep _ ht).symm
        · exact apart _ ht _ hv ne
      · rw [Finset.card_insert_of_notMem fresh]
        omega
    · exact ⟨T,fun t ht=>⟨(ok _ ht).1,shrink _ ht⟩,apart,by omega⟩
  · have done:=link A (Finset.Subset.refl _) (fun w hw touch=>by
      by_contra no
      exact move ⟨w,hw,touch,no⟩)
    exact ⟨∅,by simp,by simp,by have sz:=Finset.card_le_card done; simp; omega⟩
termination_by W.card
decreasing_by exact Finset.card_erase_lt_of_mem hw

/-- A lower price on legal disjoint packets caps their number even if
some other wheel attachments lose vertices through multiple contacts. -/
theorem capacity {P A V : Finset α} {legal W : Finset (Finset α)}
    (seed : P⊆A) (board : A⊆V) (allowed : W⊆legal) (rows : ∀w∈W,w⊆V ∧ w.card≤6)
    (link : ClosedCover A V W) (weight : α→Nat) (K r : Nat)
    (price : ∀w∈legal,∀p∈w,Disjoint (w.erase p) P → K≤∑v∈w.erase p,weight v)
    (budget : (∑v∈V \ P,weight v)<K*(r+1)) :
    V.card ≤ A.card+4*W.card+r := by
  classical
  obtain ⟨T,ok,apart,lim⟩:=extract W board allowed rows link
  have sub : T.biUnion (fun t=>t) ⊆ V \ P := by
    intro x hx
    obtain ⟨t,ht,mem⟩:=Finset.mem_biUnion.mp hx
    obtain ⟨yes,off⟩:=Finset.mem_sdiff.mp ((ok t ht).2 mem)
    exact Finset.mem_sdiff.mpr ⟨yes,fun hp=>off (seed hp)⟩
  have fees : (∑t∈T,K) ≤ ∑t∈T,∑v∈t,weight v := by
    apply Finset.sum_le_sum
    intro t ht
    obtain ⟨w,hw,p,hp,eq,_⟩:=(ok t ht).1
    have sep : Disjoint t P := Finset.disjoint_left.mpr (fun x hx inside=>
      (Finset.mem_sdiff.mp ((ok t ht).2 hx)).2 (seed inside))
    rw [eq] at sep ⊢
    exact price w hw p hp sep
  have cover := Finset.sum_le_sum_of_subset (f:=weight) sub
  rw [Finset.sum_biUnion (fun t ht u hu ne=>apart t ht u hu ne)] at cover
  have small := lt_of_le_of_lt (fees.trans cover) budget
  simp only [Finset.sum_const,smul_eq_mul] at small
  rw [Nat.mul_comm K] at small
  have n:=Nat.lt_of_mul_lt_mul_right small
  omega

/-- Substitute the actual word length into the extraction inequality.
Here M counts exceptional states, so M-|A| counts repeated root tags. -/
theorem word_cut {a w M q s L r : Nat} (size : a≤M) (wheels : w≤q)
    (packing : 720≤a+4*w+r) (length : L=5045+M+s+6*q) (short : L≤5904) :
    442+2*s+3*(M-a)+2*(5904-L) ≤ M+3*r := by omega

#print axioms extract
#print axioms capacity
#print axioms word_cut
end ExactWordFlow.OpenWheelPacking

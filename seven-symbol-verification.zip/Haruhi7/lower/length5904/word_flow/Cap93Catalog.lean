import Cap93Rows
import Cap93Data

namespace ExactWordFlow.Cap93Catalog
open SevenWordWindows RotationCore ExtremeWheelCut NearWheelBinding NearRootMoves
open private baseGood from NearBindingCheck
open private eliminates from ExtremeWheelCut

def checkedRows := rows.toList.all (baseGood 93 Cap93Data.hard.toArray)

set_option maxRecDepth 20000 in
theorem entry {p : Block × Answer} (tabRows : Array (Block × Answer)) (verified : tabRows.toList.all (baseGood 93 Cap93Data.hard.toArray)=true) (row : p∈tabRows.toList)
    {W : Finset (Finset Block)} (legal : W⊆allRows) (size : W.card≤93)
    (covered : SeedWheelCut.ClosedCover (visited p.1) allClasses W) :
    ∃r∈Cap93Data.hard, ∃w : Finset (Finset Block),
      w⊆allRows ∧ w.card≤93 ∧ r.card=255 ∧ SeedWheelCut.ClosedCover r allClasses w := by
  let tab:=Cap93Data.hard.toArray
  have ok:=List.all_eq_true.mp verified p row
  obtain ⟨word,ans⟩:=p
  cases ans with
  | easy c =>
    obtain ⟨budget,cert⟩:=Bool.and_eq_true_iff.mp ok
    have price:=of_decide_eq_true budget
    exact False.elim (eliminates _ _ legal (by rw [board];omega) cert covered)
  | hard i xs =>
    obtain ⟨ix,eq,sz⟩:=of_decide_eq_true ok
    change i<tab.size at ix
    change applyMoves xs (visited word)=tab[i]! at eq
    change (tab[i]!).card=255 at sz
    have mem : tab[i]!∈Cap93Data.hard := by
      change tab[i]!∈tab.toList
      rw [getElem!_pos tab i ix]
      exact Array.mem_toList_iff.mpr (Array.getElem_mem ix)
    obtain ⟨w,l,s,cc⟩:=transport legal covered xs
    rw [eq] at cc
    exact ⟨_,mem,w,l,s.trans size,sz,cc⟩

end ExactWordFlow.Cap93Catalog

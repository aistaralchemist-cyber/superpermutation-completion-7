import CoreMinimum
import LapBudget

namespace ExactWordFlow.CrossingRotations
open DirectedEuler RotationReinsert RotationCore ResidualDensity SevenWordWindows
abbrev Edges := List Block

/-- Between two occurrences of A and two occurrences of B, the word
travels on the five displayed routes. The pieces belonging to each of the
two alternating classes together spell exactly one lap, in order. -/
structure Switch (w : Block) where
  a : Block
  b : Block
  c : Block
  d : Block
  left : Edges
  middle₁ : Edges
  middle₂ : Edges
  middle₃ : Edges
  right : Edges
  a₁ : Edges
  b₁ : Edges
  a₂ : Edges
  b₂ : Edges
  atA : full a
  atB : full c
  lapA : a₁++a₂=lap a
  lapB : b₁++b₂=lap c
  word : windows w=left++a₁++middle₁++b₁++middle₂++a₂++middle₃++b₂++right
  lead : Route src dst (w.take 6) left a
  first : Route src dst b middle₁ c
  second : Route src dst d middle₂ b
  third : Route src dst a middle₃ d
  last : Route src dst c right (w.drop (w.length-6))

private theorem terminal {s t : Block} {es : Edges} (r : Route src dst s es t) :
    t∈s::es.map dst := by
  induction r with
  | nil => simp
  | cons e h tail ih => simpa [List.mem_cons,or_assoc] using Or.inr ih

private theorem lap_tags {a : Block} (ha : full a) :
    ∀e∈lap a, classKey e=tag a ∧ tag (dst e)=tag a := by
  have all : ∀ u∈states, ∀e∈lap u, classKey e=tag u ∧ tag (dst e)=tag u := by native_decide
  exact all a (mem_states ha)

/-- Erasing two interlaced rotations retains every visited class, can
lose at most the two completed classes, and saves exactly 14 letters. -/
theorem erase_pair {w : Block} (h : Switch w) (long : 6≤w.length) :
    ∃ v : Block, v.length+14=w.length ∧ 6≤v.length ∧
      visited w⊆visited v ∧ (complete w).card≤(complete v).card+2 := by
  let es := h.left++h.middle₃++h.middle₂++h.middle₁++h.right
  have path : Route src dst (w.take 6) es (w.drop (w.length-6)) :=
    OnePath66.join_routes (OnePath66.join_routes (OnePath66.join_routes
      (OnePath66.join_routes h.lead h.third) h.second) h.first) h.last
  have keep (e : Block) (he : e∈es) : e∈windows w := by
    rw [h.word]
    simp only [es,List.mem_append] at he ⊢
    tauto
  have split (e : Block) (he : e∈windows w) : e∈es ∨ e∈lap h.a ∨ e∈lap h.c := by
    rw [h.word] at he
    rw [←h.lapA,←h.lapB]
    simp only [es,List.mem_append] at he ⊢
    tauto
  obtain ⟨v,size,start,win⟩ := spell_route path (by simp; omega)
    (fun e he => window_width w (keep e he))
  have sizeA := congrArg List.length h.lapA
  have sizeB := congrArg List.length h.lapB
  rw [List.length_append,(lap_geometry _ h.atA).2.1] at sizeA
  rw [List.length_append,(lap_geometry _ h.atB).2.1] at sizeB
  have old := congrArg List.length h.word
  simp only [windows_length,List.length_append] at old
  simp only [es,List.length_append] at size
  have tA := terminal h.lead
  have tB := terminal (OnePath66.join_routes (OnePath66.join_routes
    (OnePath66.join_routes h.lead h.third) h.second) h.first)
  have two : tag h.a∈visited v ∧ tag h.c∈visited v := by
    constructor
    · apply (mem_visited _ _).mpr
      refine ⟨h.a,?_,h.atA,rfl⟩
      simp only [anchors,start,win,es,List.mem_cons,List.map_append,List.mem_append] at tA ⊢
      tauto
    · apply (mem_visited _ _).mpr
      refine ⟨h.c,?_,h.atB,rfl⟩
      simp only [anchors,start,win,es,List.mem_cons,List.map_append,List.mem_append] at tB ⊢
      tauto
  refine ⟨v,by omega,by omega,?_,?_⟩
  · intro k hk
    obtain ⟨u,here,clean,rfl⟩ := (mem_visited _ _).mp hk
    rcases List.mem_cons.mp here with front|later
    · exact (mem_visited _ _).mpr ⟨u,List.mem_cons.mpr (Or.inl (front.trans start.symm)),clean,rfl⟩
    · obtain ⟨e,he,rfl⟩ := List.mem_map.mp later
      rcases split e he with he|ha|hb
      · exact (mem_visited _ _).mpr ⟨dst e,List.mem_cons_of_mem _ (List.mem_map_of_mem (win ▸ he)),clean,rfl⟩
      · simpa only [(lap_tags h.atA _ ha).2] using two.1
      · simpa only [(lap_tags h.atB _ hb).2] using two.2
  · have sub : complete w ⊆ insert (tag h.a) (insert (tag h.c) (complete v)) := by
      intro k hk
      by_cases ha : k=tag h.a
      · simp [ha]
      by_cases hb : k=tag h.c
      · simp [hb]
      refine Finset.mem_insert_of_mem (Finset.mem_insert_of_mem ((mem_complete _ _).mpr ?_))
      obtain ⟨legal,covered⟩ := (mem_complete _ _).mp hk
      refine ⟨legal,fun p hp key => ?_⟩
      rcases split p (covered p hp key) with kept|lostA|lostB
      · rwa [win]
      · exact (ha (key.symm.trans (lap_tags h.atA _ lostA).1)).elim
      · exact (hb (key.symm.trans (lap_tags h.atB _ lostB).1)).elim
    have n := Finset.card_le_card sub
    have nA := Finset.card_insert_le (tag h.a) (insert (tag h.c) (complete v))
    have nB := Finset.card_insert_le (tag h.c) (complete v)
    omega

/-- In any nonempty score sublevel, choose a shortest word visiting all
720 classes. Such a witness has no alternating pair of complementary laps. -/
abbrev score := LapSkeleton.score

theorem avoid_crossings {n : Nat} {w : Block} (long : 6≤w.length)
    (all : (visited w).card=720) (low : score w≤n) :
    ∃ v : Block, 6≤v.length ∧ (visited v).card=720 ∧ score v≤n ∧
      v.length≤w.length ∧ LapSkeleton.LapFree v ∧ IsEmpty (Switch v) := by
  classical
  let P (k : Nat) := ∃ z : Block, 6≤z.length ∧ (visited z).card=720 ∧ score z≤n ∧ z.length=k
  have ok : ∃k,P k := ⟨_,w,long,all,low,rfl⟩
  obtain ⟨v,vl,va,vs,vm⟩ := Nat.find_spec ok
  have minimalCut (z : Block) (longer : z.length<v.length) (width : 6≤z.length)
      (seen : visited v ⊆ visited z) (cost : score z≤n) : False := by
    have hits := Finset.card_le_card seen
    have ceil := Finset.card_le_card (visited_subset z)
    rw [board] at ceil
    have best := Nat.find_min' ok (show P z.length from ⟨z,width,by omega,cost,rfl⟩)
    omega
  have used := Finset.card_le_card (complete_subset v)
  refine ⟨v,vl,va,vs,vm.trans_le (Nat.find_min' ok ⟨w,long,all,low,rfl⟩),?_,⟨?_⟩⟩
  · rintro ⟨l,r,p,hp,atLap⟩
    obtain ⟨z,zl,short,hit,num⟩ := LapSkeleton.cut_lap vl hp atLap
    apply minimalCut z (by omega) zl hit
    unfold score LapSkeleton.score at vs ⊢
    omega
  · intro cross
    obtain ⟨z,short,zl,hit,num⟩ := erase_pair cross vl
    apply minimalCut z (by omega) zl hit
    unfold score LapSkeleton.score at vs ⊢
    omega

/-- The original 1823/137 decision can quantify over lap-free,
non-interlaced words, with variable completion count and the same length cap. -/
theorem exact_1823 :
    (∃ w : Block, 6≤w.length ∧ w.length≤1823 ∧ (visited w).card=720 ∧ 137≤(complete w).card) ↔
    ∃v : Block, 6≤v.length ∧ v.length≤1823 ∧ (visited v).card=720 ∧
      score v≤5904 ∧ LapSkeleton.LapFree v ∧ IsEmpty (Switch v) := by
  constructor
  · rintro ⟨w,long,lim,vis,done⟩
    obtain ⟨v,vl,va,vs,len,free,nocross⟩ := avoid_crossings long vis
      (n:=5904) (by unfold score LapSkeleton.score; omega)
    exact ⟨v,vl,len.trans lim,va,vs,free,nocross⟩
  · rintro ⟨v,vl,_,va,scoreBound,_,_⟩
    obtain ⟨w,covered,sz⟩ := expand_remaining vl va
    exact RotationCore.exact_1823.mp ⟨w,covered,sz.trans_le scoreBound⟩

theorem exact_loss :
    (∃ w : Block, 6≤w.length ∧ w.length≤1823 ∧ (visited w).card=720 ∧ 137≤(complete w).card) ↔
    ∃v : Block, 6≤v.length ∧ v.length≤1823 ∧ (visited v).card=720 ∧ LapSkeleton.LapFree v ∧
      IsEmpty (Switch v) ∧
      LapSkeleton.dirty v+((LapSkeleton.starts v).length-720)+LapSkeleton.extraVisits v≤139 := by
  rw [exact_1823]
  constructor
  · rintro ⟨v,long,cap,all,low,free,absent⟩
    have eq := (LapSkeleton.score_budget long all free).1
    change LapSkeleton.score v≤5904 at low
    exact ⟨v,long,cap,all,free,absent,by omega⟩
  · rintro ⟨v,long,cap,all,free,absent,low⟩
    have eq := (LapSkeleton.score_budget long all free).1
    exact ⟨v,long,cap,all,by change LapSkeleton.score v≤5904; omega,free,absent⟩

#print axioms exact_loss
#print axioms exact_1823
#print axioms erase_pair
#print axioms avoid_crossings
end ExactWordFlow.CrossingRotations

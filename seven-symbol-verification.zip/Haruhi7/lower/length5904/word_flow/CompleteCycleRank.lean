import CoreCounts
import WheelContacts
import Packet64

namespace ExactWordFlow.CompleteCycleRank
open SevenWordWindows RotationCore RotationReinsert DirectedEuler
open private sum_union_le from Packet64

def d6 (w : Block) := (anchors w).toFinset.card
def d7 (w : Block) := (windows w).toFinset.card

/-- There are 840 geometrically distinct six-wheels. We count one only
when its six distinct, periodic seven-symbol factors all occur in the word. -/
def wheelFactors (q : Block) := (GlobalWheelRank.wheel q).toFinset

def completeWheels (w : Block) := WheelContacts.bases.toFinset.filter
  (fun q=>wheelFactors q ⊆ (windows w).toFinset)

/-- Pack any collection of edge-disjoint cycles into the actual factor graph.
The edges of each pack reach no target vertex outside their sources. Thus
treating one pack as a single set saves at least one unit of connection rank. -/
theorem packed_cycles_le {ι : Type*} [DecidableEq ι] {w : Block} (long : 6≤w.length)
    (J : Finset ι) (E : ι→Finset Block)
    (available : ∀i∈J,E i⊆(windows w).toFinset)
    (positive : ∀i∈J,(E i).Nonempty)
    (closed : ∀i∈J,(E i).image dst⊆(E i).image src)
    (disjoint : (↑J : Set ι).PairwiseDisjoint E) :
    d6 w+J.card≤d7 w+1 := by
  classical
  let F := (windows w).toFinset
  let used := J.biUnion E
  let unused := F \ used
  let points (i : ι) := (E i).image src
  let pair (e : Block) : Finset Block := {src e,dst e}
  let groups := J.image points
  let singles := unused.image pair
  obtain ⟨Z,home,price,joined⟩ := GlobalWheelRank.grow {w.take 6} (groups∪singles)
  have source : w.take 6∈Z := home (Finset.mem_singleton_self _)
  have step (e) (he : e∈windows w) (inside : src e∈Z) : dst e∈Z := by
    by_cases packed : e∈used
    · obtain ⟨i,hi,mem⟩:=Finset.mem_biUnion.mp packed
      have first : src e∈points i := Finset.mem_image_of_mem _ mem
      have last := closed i hi (Finset.mem_image_of_mem dst mem)
      exact joined _ (Finset.mem_union_left _ (Finset.mem_image_of_mem _ hi))
        ⟨_,Finset.mem_inter.mpr ⟨inside,first⟩⟩ last
    · have f : e∈unused := Finset.mem_sdiff.mpr ⟨List.mem_toFinset.mpr he,packed⟩
      exact joined _ (Finset.mem_union_right _ (Finset.mem_image_of_mem _ f))
        ⟨_,Finset.mem_inter.mpr ⟨inside,Finset.mem_insert_self ..⟩⟩
        (Finset.mem_insert_of_mem (Finset.mem_singleton_self _))
  have startAll := (read_route w long).closed (↑Z : Set Block) source step
  have cover : (anchors w).toFinset ⊆ Z := by
    intro x hx
    rcases List.mem_cons.mp (List.mem_toFinset.mp hx) with rfl|later
    · exact source
    · obtain ⟨e,he,rfl⟩ := List.mem_map.mp later
      exact step e he (startAll.2 e he)
  have un := sum_union_le groups singles
  have p1 : (∑q∈groups,(q.card-1)) ≤ ∑i∈J,((points i).card-1) :=
    Finset.sum_image_le_of_nonneg (fun _ _=>Nat.zero_le _)
  have p2 : (∑q∈singles,(q.card-1)) ≤ ∑e∈unused,((pair e).card-1) :=
    Finset.sum_image_le_of_nonneg (fun _ _=>Nat.zero_le _)
  have p3 : (∑e∈unused,((pair e).card-1))≤unused.card := by
    apply le_trans (Finset.sum_le_card_nsmul _ _ 1 ?_) (by simp)
    intro e he
    have h:=Finset.card_insert_le (src e) ({dst e} : Finset Block)
    simp only [Finset.card_singleton] at h
    change (insert (src e) ({dst e} : Finset Block)).card-1≤1
    omega
  have cost : (∑i∈J,((points i).card-1))+J.card ≤ used.card := by
    have bounds (i) (hi : i∈J) : (points i).card-1+1 ≤ (E i).card := by
      have pos:=Finset.card_pos.mpr (positive i hi)
      have limit : (points i).card≤(E i).card := Finset.card_image_le
      omega
    have sum:=Finset.sum_le_sum bounds
    simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] at sum
    simpa only [used,Finset.card_biUnion disjoint] using sum
  have usedSub : used⊆F := by
    intro e he
    obtain ⟨i,hi,h⟩:=Finset.mem_biUnion.mp he
    exact available i hi h
  have rest := Finset.card_sdiff_add_card_eq_card usedSub
  have lower := Finset.card_le_card cover
  simp only [Finset.card_singleton] at price
  have bound : Z.card ≤ 1+((∑i∈J,((points i).card-1))+unused.card) :=
    price.trans (Nat.add_le_add_left (un.trans (Nat.add_le_add p1 (p2.trans p3))) 1)
  change unused.card+used.card=F.card at rest
  change d6 w≤Z.card at lower
  change d6 w+J.card≤F.card+1
  omega

private def owner (e : Block) : Block ⊕ Block :=
  if e.Nodup then .inl (classKey e) else
    .inr ((((List.range 6).map (fun i=>(src e).rotate i)).min?).getD [])

private theorem permutation_geometry : ∀c∈allClasses, (fibre c).Nonempty ∧
    (fibre c).image dst⊆(fibre c).image src ∧ ∀e∈fibre c,owner e=Sum.inl c := by native_decide

private theorem wheel_geometry : ∀q∈WheelContacts.bases, (wheelFactors q).Nonempty ∧
    (wheelFactors q).image dst⊆(wheelFactors q).image src ∧
      ∀e∈wheelFactors q,owner e=Sum.inr q := by native_decide

/-- The two families of full circuits in the unprojected six-context Rauzy
graph. Their edge labels are respectively the seven genuine permutations
and the six repeated-letter wheel windows. No class-visit assumption. -/
theorem word_cycles_le (w : Block) (long : 6≤w.length) :
    d6 w+(complete w).card+(completeWheels w).card≤d7 w+1 := by
  let J := (complete w).disjSum (completeWheels w)
  let E : Block ⊕ Block → Finset Block := Sum.elim fibre wheelFactors
  have geom (i) (hi : i∈J) :
      E i ⊆ (windows w).toFinset ∧ (E i).Nonempty ∧ (E i).image dst⊆(E i).image src ∧
        ∀e∈E i,owner e=i := by
    cases i with
    | inl c =>
      have mem : c∈complete w := by simpa [J] using hi
      obtain ⟨a,all⟩:=(mem_complete w c).mp mem
      refine ⟨?_,permutation_geometry c a⟩
      intro e he
      obtain ⟨legal,key⟩:=Finset.mem_filter.mp (show e∈fibre c from he)
      exact List.mem_toFinset.mpr (all e (List.mem_toFinset.mp legal) key)
    | inr q =>
      have mem : q∈completeWheels w := by simpa [J] using hi
      obtain ⟨base,all⟩:=Finset.mem_filter.mp mem
      exact ⟨all,wheel_geometry q (List.mem_toFinset.mp base)⟩
  have dis : (↑J : Set (Block⊕Block)).PairwiseDisjoint E := by
    intro i hi j hj diff
    exact Finset.disjoint_left.mpr (fun {e} ei ej =>
      diff (((geom i hi).2.2.2 e ei).symm.trans ((geom j hj).2.2.2 e ej)))
  have h:=packed_cycles_le long J E (fun i hi=>(geom i hi).1)
    (fun i hi=>(geom i hi).2.1) (fun i hi=>(geom i hi).2.2.1) dis
  simpa [J,Nat.add_assoc] using h

#print axioms packed_cycles_le
#print axioms word_cycles_le
end ExactWordFlow.CompleteCycleRank

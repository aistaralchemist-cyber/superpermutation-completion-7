import LongComponent
import LongDensity

/-! Quantitative restriction on the total length in large residual components.
Each unit below 858 increases the required total by at least 50. -/
namespace ExactWordFlow
open ResidualIncidence ResidualRoutes ResidualDensity DirectedEuler
open scoped Classical

noncomputable def largeOther (X : Multiset Block) (s : Block) :=
  ((support X s).image (label X)).filter fun q => q≠label X s ∧ 73≤(part X q).card

noncomputable def largeMass (X : Multiset Block) (s : Block) :=
  (part X (label X s)).card + ∑ q∈largeOther X s, (part X q).card

noncomputable def separateRank (X : Multiset Block) (s : Block) :=
  ∑ q ∈ (support X s).image (label X), ((contacts (support X s) (label X) q).card-1)

/-- Upper bounds derived from balance and literal window widths, before any
connectivity assumption. The third inequality isolates the contribution of
all closed components when they each use at most 72 edges. -/
theorem component_prices {X : Multiset Block} {s t : Block}
    (bal : X.map src+{t}=X.map dst+{s}) (widthsX : ∀ e∈X, e.length=7) :
    240*separateRank X s+240*(largeOther X s).card ≤ 200*X.card+4*largeMass X s+228 ∧
    (largeOther X s=∅ → (part X (label X s)).card<186 → 6*separateRank X s≤5*X.card+23) ∧
    (largeOther X s=∅ →
      6*(separateRank X s) + 5*(part X (label X s)).card ≤ 5*X.card +
        6*((contacts (support X s) (label X) (label X s)).card-1)) := by
  classical
  let home := label X s
  let D := support X s
  let Q := D.image (label X)
  let C (q : Component X) := (contacts D (label X) q).card
  let K (q : Component X) := (part X q).card
  let Big (q) := q≠home ∧ 73≤K q
  let B := Q.filter Big
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have hs : ∀ e∈X, label X (src e)∈Q := by
    intro e he
    rw [on_edge he]
    apply Finset.mem_image_of_mem
    exact Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))
  have sumK : ∑ q∈Q, K q = X.card := sum_part_card X Q hs
  have estimates (q) (hq : q∈Q) :
      (q=home → 40*C q ≤ 34*K q+78 ∧ (K q<186 → 6*(C q-1)≤5*K q+23)) ∧
      (Big q → 40*C q ≤ 34*K q) ∧
      (q≠home → ¬Big q → 6*(C q-1) ≤ 5*K q) := by
    obtain ⟨v,_,lv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lab,ends⟩ := component_route bal v
    rw [lv] at eq lab ends
    have k : es.length=K q := congrArg Multiset.card eq
    have widths (e) (he : e∈es) : e.length=7 := by
      have inside : e∈part X q := eq ▸ (show e∈(↑es : Multiset Block) from he)
      exact widthsX e (in_part.mp inside).1
    have c : C q ≤ classCount a es := contacts_bound D lab r eq
    refine ⟨fun _ => ⟨?_,?_⟩,?_,?_⟩
    · have cap := open_linear40 r widths
      omega
    · intro small
      have cap : 6*classCount a es < 5*es.length+30 := by
        by_contra! gain
        have large := open_atleast186 r widths gain
        omega
      omega
    · rintro ⟨away,big⟩
      obtain ⟨aa,bb⟩ := ends.2 away
      subst a; subst b
      have cap := closed_linear40 r widths (by omega : 40≤es.length)
      omega
    · intro away none
      have small : es.length≤72 := by by_contra! too; exact none ⟨away,by omega⟩
      obtain ⟨aa,bb⟩ := ends.2 away
      subst a; subst b
      have cap := closed_small72 r widths small
      omega
  constructor
  · have cap (q) (hq : q∈Q) :
        240*(C q-1) + (if Big q then 240 else 0) ≤
          200*K q + (if Big q then 4*K q else 0) + (if q=home then 4*K q+228 else 0) := by
      obtain ⟨op,bg,cl⟩ := estimates q hq
      by_cases hh : q=home
      · have nn : ¬Big q := fun k => k.1 hh
        simp only [ite_eq_right nn,ite_eq_left hh]
        have bound := (op hh).1
        omega
      · rw [ite_eq_right hh]
        by_cases bb : Big q
        · simp only [ite_eq_left bb]
          have bound := bg bb
          have n := bb.2
          omega
        · simp only [ite_eq_right bb]
          have bound := cl hh bb
          omega
    have vsum := Finset.sum_le_sum cap
    have consts : (∑ q∈Q, (if Big q then 240 else 0)) = 240*B.card := by
      rw [← Finset.sum_filter]; simp [B,Nat.mul_comm]
    have weights : (∑ q∈Q, (if Big q then 4*K q else 0)) = 4*∑ q∈B, K q := by
      rw [← Finset.sum_filter,Finset.mul_sum]
    simp only [←Finset.mul_sum,Finset.sum_add_distrib,consts,weights,Finset.sum_ite_eq',root,ite_true,sumK] at vsum
    change 240*(∑ q∈Q, (C q-1))+240*B.card ≤ 200*X.card+4*(K home+∑ q∈B,K q)+228
    omega
  constructor
  · intro emp small
    change B=∅ at emp
    have cap (q) (hq : q∈Q) : 6*(C q-1) ≤ 5*K q + (if q=home then 23 else 0) := by
      obtain ⟨op,_,cl⟩ := estimates q hq
      by_cases hh : q=home
      · rw [ite_eq_left hh]; exact (op hh).2 (by simpa [hh,K,home] using small)
      · rw [ite_eq_right hh,Nat.add_zero]
        apply cl hh
        intro big
        have mem : q∈B := Finset.mem_filter.mpr ⟨hq,big⟩
        simp [emp] at mem
    have vsum := Finset.sum_le_sum cap
    simp only [←Finset.mul_sum,Finset.sum_add_distrib,Finset.sum_ite_eq',root,ite_true,sumK] at vsum
    exact vsum
  · intro emp
    change B=∅ at emp
    have cap (q) (hq : q∈Q.erase home) : 6*(C q-1) ≤ 5*K q := by
      obtain ⟨away,mem⟩ := Finset.mem_erase.mp hq
      apply (estimates q mem).2.2 away
      intro big
      have member : q∈B := Finset.mem_filter.mpr ⟨mem,big⟩
      simp [emp] at member
    have le := Finset.sum_le_sum cap
    simp only [←Finset.mul_sum] at le
    have cp := Finset.sum_erase_add (s:=Q) (fun q => C q-1) root
    have kp := Finset.sum_erase_add (s:=Q) K root
    rw [sumK] at kp
    change 6*(∑ q∈Q, (C q-1))+5*K home≤5*X.card+6*(C home-1)
    omega

/-- The longer components must supply the ordinary 719 rank units and any
additional units already known to be lost to overlapping contacts. -/
theorem mass_of_loss {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (size : X.card≤858) (loss : Nat) (lower : 719+loss≤ separateRank X s) :
    183 + 50*(858-X.card)+60*((largeOther X s).card+loss) ≤ largeMass X s := by
  have bound := (component_prices h.balance h.edges_seven).1
  omega

theorem long_mass_858 {X : Multiset Block} {s t : Block} (h : Feasible X s t) (size : X.card≤858) :
    732 + 200*(858-X.card) + 240*(largeOther X s).card ≤ 4*largeMass X s ∧
    (largeOther X s=∅ → 186≤(part X (label X s)).card) := by
  have rank : 719≤ separateRank X s := rank719 (label X) h (fun _ he => on_edge he)
  have bound := mass_of_loss h size 0 (by simpa using rank)
  refine ⟨by omega,?_⟩
  intro emp
  by_contra! small
  have cap := (component_prices h.balance h.edges_seven).2.1 emp small
  omega

end ExactWordFlow
#print axioms ExactWordFlow.long_mass_858

import EssentialPackets

namespace ExactWordFlow.ResidualRoutes
open DirectedEuler

def adjacent (X : Multiset Block) (a b : Block) : Prop :=
  ∃ e∈X, src e=a ∧ dst e=b

abbrev Component (X : Multiset Block) := Quotient (Relation.EqvGen.setoid (adjacent X))
def label (X : Multiset Block) (v : Block) : Component X := Quotient.mk _ v

theorem on_edge {X : Multiset Block} {e : Block} (he : e∈X) :
    label X (src e)=label X (dst e) :=
  Quotient.sound (.rel _ _ ⟨e,he,rfl,rfl⟩)

noncomputable def part (X : Multiset Block) (q : Component X) : Multiset Block := by
  classical exact X.filter fun e => label X (src e)=q

theorem in_part {X : Multiset Block} {q : Component X} {e : Block} :
    e∈part X q ↔ e∈X ∧ label X (src e)=q := by classical simp [part]

theorem invariant {X : Multiset Block} (T : Set Block)
    (step : ∀ e∈X, src e∈T ↔ dst e∈T) {v w : Block}
    (h : label X v=label X w) : v∈T ↔ w∈T := by
  have related : Relation.EqvGen (adjacent X) v w := Quotient.exact h
  clear h
  induction related with
  | rel x y h =>
    obtain ⟨e,hm,rfl,rfl⟩ := h
    exact step e hm
  | refl => rfl
  | symm _ _ _ ih => exact ih.symm
  | trans _ _ _ _ _ ih₁ ih₂ => exact ih₁.trans ih₂

theorem endpoints {X : Multiset Block} {s t : Block}
    (bal : X.map src+{t}=X.map dst+{s}) : label X s=label X t := by
  let S : Set Block := {v | label X s=label X v}
  have root : s∈S := rfl
  exact (Essential.restrictBalance root bal (fun e he hs => (show label X s=label X (src e) from hs).trans (on_edge he))).1

/-- Each weak residual component is a single Euler circuit, except that the
component of the initial state runs from the initial to the final state.
Filtering retains all multiplicities, including in components with no clean state. -/
theorem component_route {X : Multiset Block} {s t : Block}
    (bal : X.map src+{t}=X.map dst+{s}) (v : Block) :
    ∃ (a b : Block) (es : List Block), (↑es : Multiset Block)=part X (label X v) ∧
      Route src dst a es b ∧ label X a=label X v ∧
      ((label X v=label X s → a=s ∧ b=t) ∧ (label X v≠label X s → a=v ∧ b=v)) := by
  classical
  let q := label X v
  let Y := part X q
  let a := if q=label X s then s else v
  let b := if q=label X s then t else v
  have ends := endpoints bal
  have rootLabel : label X a=q := by
    dsimp only [a]; split
    next eq => exact eq.symm
    next => rfl
  have localBalance : Y.map src+{b}=Y.map dst+{a} := by
    have eq := congrArg (Multiset.filter fun x => label X x=q) bal
    simp only [Multiset.filter_add,Multiset.filter_map,Multiset.filter_singleton] at eq
    have same : (X.filter (fun e => label X (dst e)=q))=Y := by
      change _=X.filter (fun e => label X (src e)=q)
      apply Multiset.filter_congr
      intro e he
      rw [on_edge he]
    simp only [Function.comp_def] at eq
    rw [same] at eq
    change Y.map src + (if label X t=q then {t} else 0) =
      Y.map dst + (if label X s=q then {s} else 0) at eq
    by_cases atHome : q=label X s
    · simpa [a,b,atHome,← ends] using eq
    · have away := Ne.symm atHome
      have balanced : Y.map src=Y.map dst := by simpa [←ends,away] using eq
      simp [a,b,atHome,balanced]
  have reachable (S : Set Block) (root : a∈S)
      (step : ∀ e∈Y, src e∈S → dst e∈S) (e) (he : e∈Y) : src e∈S := by
    have both := (Essential.restrictBalance root localBalance step).2.1
    let T : Set Block := {x | label X x=q → x∈S}
    have sameSide (f) (hf : f∈X) : src f∈T ↔ dst f∈T := by
      change (label X (src f)=q → src f∈S) ↔ (label X (dst f)=q → dst f∈S)
      by_cases lab : label X (src f)=q
      · have live : f∈Y := in_part.mpr ⟨hf,lab⟩
        simpa [←on_edge hf,lab] using both f live
      · simp [←on_edge hf,lab]
    have localLabel := (in_part.mp he).2
    have same := invariant T sameSide (rootLabel.trans localLabel.symm)
    exact (same.mp (fun _ => root)) localLabel
  obtain ⟨es,eq,route⟩ := exists_route src dst Y a b localBalance reachable
  refine ⟨a,b,es,eq,route,rootLabel,?_⟩
  constructor <;> intro test
  · change q=label X s at test; simp [a,b,test]
  · change q≠label X s at test; simp [a,b,test]

private theorem mem_sources {a b : Block} {es : List Block} (r : Route src dst a es b)
    {e : Block} (he : e∈es) : src e∈a::es.map dst := by
  induction r with
  | nil => simp at he
  | cons f hs tail ih =>
    rcases List.mem_cons.mp he with rfl|rest
    · simp [hs]
    · have h := ih rest
      simpa using (List.mem_cons_of_mem _ h)

/-- The route through one weak component visits every vertex of that
component, including the isolated vertex when its edge multiset is empty. -/
theorem visits {X : Multiset Block} {q : Component X} {a b : Block} {es : List Block}
    (root : label X a=q) (r : Route src dst a es b) (eq : (↑es : Multiset Block)=part X q)
    {v : Block} (member : label X v=q) : v∈a::es.map dst := by
  let T : Set Block := {x | label X x=q → x∈a::es.map dst}
  have edges (f) (hf : f∈X) : src f∈T ↔ dst f∈T := by
    change (label X (src f)=q → _) ↔ (label X (dst f)=q → _)
    by_cases lab : label X (src f)=q
    · have live : f∈es := by
        change f∈(↑es : Multiset Block); rw [eq]; exact in_part.mpr ⟨hf,lab⟩
      exact ⟨fun _ _ => List.mem_cons_of_mem _ (List.mem_map.mpr ⟨f,live,rfl⟩),
        fun _ _ => mem_sources r live⟩
    · simp [←on_edge hf,lab]
  have same := invariant T edges (root.trans member.symm)
  exact (same.mp (fun _ => List.mem_cons_self ..)) member

private theorem count_by_label {ι : Type*} [DecidableEq ι] (f : Block → ι) (Q : Finset ι)
    (A : Multiset Block) (covers : ∀ e∈A, f e∈Q) :
    ∑ q ∈ Q, (A.filter fun e => f e=q).card = A.card := by
  induction A using Multiset.induction_on with
  | empty => simp
  | cons e A ih =>
    have rest := ih (fun a ha => covers a (Multiset.mem_cons_of_mem ha))
    have here := covers e (Multiset.mem_cons_self ..)
    have more (q : ι) : ((e ::ₘ A).filter fun x => f x=q).card =
        (A.filter fun x => f x=q).card + (if f e=q then 1 else 0) := by
      by_cases eq : f e=q <;> simp [eq]
    simp_rw [more]
    rw [Finset.sum_add_distrib,rest]
    simp [here]

theorem sum_part_card (X : Multiset Block) (Q : Finset (Component X))
    (hq : ∀ e∈X, label X (src e)∈Q) : ∑ q ∈ Q, (part X q).card=X.card := by
  classical exact count_by_label (fun e => label X (src e)) Q X hq

#print axioms component_route
end ExactWordFlow.ResidualRoutes

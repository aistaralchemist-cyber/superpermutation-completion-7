import HundredDecomposition
import ExtremeRootSets
import ExtremeWheelCut
import WheelRelabel
import ComponentCurve

namespace ExactWordFlow.NoHundred
open SevenWordWindows DirectedEuler ResidualDensity RotationComponentCount RotationCore
open WeightedMarks ExtremalRealizations ExtremeWheelCut SuperpermutationBounds

private theorem certificate_list :
    (realizations extremeProfiles).all (fun R=>provedRoots.contains R)=true := by native_decide

/-- No 858-edge feasible placement has one hundred occupied components
apart from the initial one. The contact computation uses the real Euler
path and the real wheel family on both sides of the alphabet change. -/
theorem component_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) : (occupied X s).card≤99 := by
  classical
  have cap:=MarkedComponentCap.component_limit h budget
  by_contra! many
  have hundred : (occupied X s).card=100 := by omega
  obtain ⟨es,ws,z,u,I,route,len,wd,colors,num,all,_,split,_⟩:=HundredDecomposition.decompose h budget hundred
  obtain ⟨f,bij,zero,norm⟩:=ExtremeRootSets.route_coverage route wd len colors.ge
  have known := List.all_eq_true.mp certificate_list _ norm
  have verified : (touched (s::es.map dst)).image (List.map f)∈provedRoots := List.contains_iff_mem.mp known
  have closed:=WheelRelabel.transport_closed all (HundredDecomposition.closed_cover h route all split) f bij.1 zero
  let vs:=ws.map (List.map f)
  have legal : vs.toFinset.image WheelContacts.wheel⊆allRows := by
    intro row hr
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hr
    obtain ⟨x,old,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hv)
    have fullX:=all x old
    have fullV : full (x.map f) := ⟨by simpa using fullX.1,fullX.2.map bij.1⟩
    obtain ⟨base,admissible,rows⟩:=WheelContacts.complete fullV
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨base,admissible,rows⟩)
  have rowCount : (vs.toFinset.image WheelContacts.wheel).card≤100 :=
    Finset.card_image_le.trans ((List.toFinset_card_le vs).trans (by simpa [vs] using num.le))
  exact no_cover verified legal rowCount closed

theorem exact_1557 :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
      ∃v : Block,6≤v.length ∧ v.length≤1557 ∧ (visited v).card=720 ∧ 99≤(complete v).card :=
  ComponentCurve.exact_threshold (k:=99) (m:=99) (@component_limit) (by decide) (by decide)

theorem completion_curve (k : Nat) (lo : 99≤k) (hi : k≤720) :
    IsLeast (lengthsFor k) (SuperpermBridge.HR.Ssuper 7-7*(720-k)) :=
  ComponentCurve.completion_curve (@component_limit) k (by omega) lo hi

theorem reference621 :
    RotationCoreControls.summary (RotationCoreControls.coreWord 621)=(1558,720,99) ∧
    RotationCoreControls.summary (RotationCoreControls.coreTruncated 621)=(1557,720,98) := by
  native_decide

#print axioms component_limit
#print axioms exact_1557
#print axioms completion_curve
#print axioms reference621
end ExactWordFlow.NoHundred

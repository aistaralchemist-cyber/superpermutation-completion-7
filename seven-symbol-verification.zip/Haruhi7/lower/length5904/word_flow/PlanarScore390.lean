import PlanarScoreExample
namespace ExactWordFlow.PlanarScore390
open SevenWordWindows SeedWheelCut ExtremeWheelCut
open private digits makeCert valid eliminates from ExtremeWheelCut
open private cost from PlanarScoreExample
private def rows : List (Nat × String) := [(5, "0123456"),
  (5, "0234516"),
  (5, "0345126"),
  (3, "0451236"),
  (5, "0645132"),
  (5, "0451362"),
  (5, "0513642"),
  (3, "0136452"),
  (5, "0213654"),
  (5, "0136524"),
  (3, "0365214"),
  (5, "0436512"),
  (5, "0365142"),
  (5, "0651432"),
  (3, "0514362"),
  (5, "0251463"),
  (5, "0514623"),
  (3, "0146253"),
  (5, "0314652"),
  (5, "0146532"),
  (5, "0465312"),
  (3, "0653142"),
  (5, "0265341"),
  (5, "0653421"),
  (3, "0534261"),
  (5, "0153462"),
  (5, "0534612"),
  (5, "0346152"),
  (3, "0461532"),
  (5, "0246135"),
  (5, "0461325"),
  (3, "0613245"),
  (5, "0561342"),
  (5, "0613452"),
  (2, "0134562"),
  (5, "0621354"),
  (5, "0213564"),
  (5, "0135624"),
  (3, "0356214"),
  (5, "0435612"),
  (5, "0356142"),
  (5, "0561432"),
  (3, "0614352"),
  (5, "0261453"),
  (5, "0614523"),
  (3, "0145263"),
  (5, "0314562"),
  (5, "0145632"),
  (5, "0456312"),
  (3, "0563142"),
  (5, "0256341"),
  (5, "0563421"),
  (3, "0634251"),
  (3, "0163452"),
  (5, "0216354"),
  (2, "0163524"),
  (5, "0241653"),
  (5, "0416523"),
  (3, "0165243"),
  (5, "2316540"),
  (2, "0165432"),
  (5, "0321645"),
  (5, "0216435"),
  (5, "0164325"),
  (3, "0643215"),
  (5, "0564312"),
  (5, "0643152"),
  (5, "0431562"),
  (3, "0315642"),
  (5, "0231546"),
  (4, "0154236"),
  (5, "0154263"),
  (3, "0542613")]

def walk : List Block := rows.flatMap fun (r,s) =>
  (List.range (r+1)).map fun j => (digits s).take 1 ++ (digits s).tail.rotate j
def rootClasses := (walk.map classKey).toFinset
private def paid := (walk.zip walk.tail).map fun (x,y) => cost x y

/-- The exceptional cycle has the same size as W-0021, but costs one unit
less. Each visited rotation class is distinct. The free edge has cost 7. -/
theorem profile : (∀ p∈walk,p.length=7 ∧ p.Nodup) ∧ walk.length=390 ∧
    rootClasses.card=390 ∧ paid.length=389 ∧ paid.count 2=317 ∧ paid.count 3=71 ∧ paid.count 4=1 ∧
    cost (walk.getLastD []) (walk.headD [])=7 ∧
    (paid.map fun d => d-2).sum=73 ∧
    walk.length-6-5*(paid.map fun d => d-2).sum=19 := by native_decide

/-- No saturated attachment of 66 ordinary six-wheels is possible.
The single outside class 0135426 forces a non-neutral attachment. -/
theorem no_neutral_extension {W : Finset (Finset Block)} (legal : W⊆allRows)
    (limit : W.card≤66) : ¬ ClosedCover rootClasses allClasses W := by
  let witness := makeCert [] "0135426"
  have check : valid rootClasses witness=true := by native_decide
  have card : allClasses.card=720 := by native_decide
  have rootSize := profile.2.2.1
  exact eliminates witness _ legal (by omega) check

/-- If this is the only exceptional correction cycle and it contains the
free edge, every other nontrivial cycle is an ordinary six-wheel. Substituting
the genus and length identities gives a twelve-letter gap to the failed 5904
target, even when a positive genus is allowed. The count q counts wheels
with multiplicity, so it is an upper bound on the number of distinct rows. -/
theorem sole_exception_cost {W : Finset (Finset Block)} {q g L : Nat}
    (legal : W⊆allRows) (covers : ClosedCover rootClasses allClasses W)
    (count : W.card≤q) (genus : 390+6*q=(q+1)+719+2*g)
    (length : L=5764+(q+1)+73+2*g) : 5916≤L := by
  have large : 67≤q := by
    by_contra! small
    exact no_neutral_extension legal (by omega) covers
  omega

#print axioms profile
#print axioms no_neutral_extension
#print axioms sole_exception_cost
end ExactWordFlow.PlanarScore390

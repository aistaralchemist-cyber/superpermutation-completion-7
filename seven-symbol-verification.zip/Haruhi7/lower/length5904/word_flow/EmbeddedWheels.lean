import LongMass
import GlobalWheelRank
import EssentialPackets

namespace ExactWordFlow.EmbeddedWheels
open SevenWordWindows ResidualDensity ResidualIncidence ResidualRoutes GlobalWheelRank
open scoped Classical

def turns (ws : List Block) : Multiset Block := ↑(ws.flatMap GlobalWheelRank.wheel)

private theorem wheel_data : ∀ u∈states,
    (GlobalWheelRank.wheel u).length=6 ∧
    ((GlobalWheelRank.wheel u).map src).Perm ((GlobalWheelRank.wheel u).map dst) ∧
    (orbit u).toFinset.card=6 ∧
    ∀ e∈GlobalWheelRank.wheel u,
      full (src e) ∧ full (dst e) ∧ tag (src e)∈orbit u ∧ tag (dst e)∈orbit u := by
  native_decide

private theorem sizes {ws : List Block} (legit : ∀ w∈ws, full w) :
    (turns ws).card=6*ws.length ∧ (turns ws).map src=(turns ws).map dst := by
  induction ws with
  | nil => simp [turns]
  | cons w ws ih =>
    obtain ⟨sz,bal⟩ := ih (fun q hq => legit q (List.mem_cons_of_mem _ hq))
    obtain ⟨n,p,_,_⟩ := wheel_data w (mem_states (legit w (by simp)))
    have single : (↑(GlobalWheelRank.wheel w) : Multiset Block).map src =
        (↑(GlobalWheelRank.wheel w) : Multiset Block).map dst := Quot.sound p
    have pieces : turns (w::ws) = (↑(GlobalWheelRank.wheel w) : Multiset Block) + turns ws := rfl
    rw [pieces,Multiset.card_add,Multiset.coe_card,Multiset.map_add,Multiset.map_add,n,sz,
      single,bal,List.length_cons]
    exact ⟨by omega,rfl⟩

private def enlarged (S : Finset Block) := if S.Nonempty then S else {[]}
private theorem nonempty (S : Finset Block) : (enlarged S).Nonempty := by
  rw [enlarged]; split <;> simp_all
private theorem rank_eq (S : Finset Block) : (enlarged S).card-1=S.card-1 := by
  rw [enlarged]; split
  · rfl
  · rename_i h
    simp [Finset.not_nonempty_iff_eq_empty.mp h]

private theorem image_sum {α β : Type*} [DecidableEq α] [DecidableEq β]
    (S : Finset α) (f : α → β) (g : β → Nat) :
    ∑ y ∈ S.image f, g y ≤ ∑ x∈S, g (f x) := by
  induction S using Finset.induction_on with
  | empty => simp
  | @insert a S fresh ih =>
    rw [Finset.image_insert,Finset.sum_insert fresh]
    by_cases known : f a∈S.image f
    · rw [Finset.insert_eq_of_mem known]; omega
    · rw [Finset.sum_insert known]; omega

private theorem board :
    ((representatives.map (fun e => tag (src e))).toFinset.card=720) ∧
    ∀ e∈representatives, full (src e) ∧ full (dst e) ∧ tag (src e)=tag (dst e) := by
  native_decide

/-- Any group of complete wheel turns can only join as many groups of
required rotation classes as its incidence sets have total rank. -/
theorem grouped_rank {Y : Multiset Block} {s t : Block} (ws : List Block)
    (legit : ∀ w∈ws, full w) (h : Feasible (Y+turns ws) s t)
    (W : Finset (Finset Block)) (contained : ∀ w∈ws, ∃u∈W, (orbit w).toFinset⊆u) :
    719 ≤ (∑u∈W,(u.card-1)) + separateRank Y s := by
  classical
  let D := support Y s
  let g := label Y
  let Q := D.image g
  let F := contacts D g
  let T (q : Component Y) := enlarged (F q)
  let φ (v : Block) := if full v then tag v else (nonempty (F (g v))).choose
  let B := Q.image T
  have bal := Essential.restBalance h (sizes legit).2
  have clean (v : Block) (fl : full v) : φ v=tag v := by simp [φ,fl]
  have memDdst (e : Block) (he : e∈Y) : dst e∈D := by
    exact Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))
  have memDsrc (e : Block) (he : e∈Y) : src e∈D := by
    have mem : src e∈Y.map src+{t} := Multiset.mem_add.mpr
      (Or.inl (Multiset.mem_map.mpr ⟨e,he,rfl⟩))
    rw [bal] at mem
    rcases Multiset.mem_add.mp mem with yes | rs
    · obtain ⟨a,ma,eq⟩ := Multiset.mem_map.mp yes
      exact eq ▸ memDdst a ma
    · have ss : src e=s := by simpa using rs
      exact ss ▸ Finset.mem_insert_self ..
  have owner (v : Block) (hv : v∈D) : φ v∈T (g v) := by
    by_cases fl : full v
    · have hit : tag v∈F (g v) := Finset.mem_image.mpr
        ⟨v,Finset.mem_filter.mpr ⟨hv,rfl,fl⟩,rfl⟩
      simpa [T,enlarged,clean v fl,show (F (g v)).Nonempty from ⟨_,hit⟩] using hit
    · simpa [φ,T,fl] using (nonempty (F (g v))).choose_spec
  have mandatory (e : Block) (he : e∈required) : φ (src e)=φ (dst e) := by
    have info := board.2 e he
    rw [clean _ info.1,clean _ info.2.1,info.2.2]
  have count : (representatives.map (fun e => φ (src e))).toFinset.card=720 := by
    have replace := List.map_congr_left (l:=representatives) (f:=fun e => φ (src e))
      (g:=fun e => tag (src e)) (fun e he => clean _ (board.2 e he).1)
    rw [replace,board.1]
  have need := projected_rank φ mandatory h (B∪W) (by
    intro e he
    right
    rcases Multiset.mem_add.mp he with hy | hw
    · have eq : g (src e)=g (dst e) := on_edge hy
      exact ⟨_,Finset.mem_union_left _ (Finset.mem_image_of_mem _ (Finset.mem_image_of_mem _ (memDsrc e hy))),
        owner _ (memDsrc e hy),eq ▸ owner _ (memDdst e hy)⟩
    · obtain ⟨w,hw,inside⟩ := List.mem_flatMap.mp (show e∈ws.flatMap GlobalWheelRank.wheel from hw)
      obtain ⟨u,hu,uw⟩ := contained w hw
      have geom := (wheel_data w (mem_states (legit w hw))).2.2.2 e inside
      exact ⟨u,Finset.mem_union_right _ hu,
        (clean _ geom.1) ▸ uw (List.mem_toFinset.mpr geom.2.2.1),
        (clean _ geom.2.1) ▸ uw (List.mem_toFinset.mpr geom.2.2.2)⟩)
  rw [count] at need
  let r (b : Finset Block) := b.card-1
  have comb := Finset.sum_union_inter (s₁:=B) (s₂:=W) (f:=r)
  have rem := image_sum Q T r
  have re (q) : r (T q)=(F q).card-1 := rank_eq (F q)
  simp_rw [re] at rem
  change 720≤1+∑ b∈B∪W,r b at need
  change 719≤(∑w∈W,r w)+∑ q∈Q,((F q).card-1)
  change (∑ v∈B,r v)≤_ at rem
  omega

theorem wheel_contacts_six (w : Block) (h : full w) : (orbit w).toFinset.card=6 :=
  (wheel_data w (mem_states h)).2.2.1

/-- Removing complete turns can lose at most five units of connectivity
per turn, even if the turn and the remaining path meet at literal vertices. -/
theorem residual_rank {Y : Multiset Block} {s t : Block} (ws : List Block)
    (legit : ∀ w∈ws, full w) (h : Feasible (Y+turns ws) s t) :
    719 ≤ 5*ws.length + ∑q∈(support Y s).image (label Y),
      ((contacts (support Y s) (label Y) q).card-1) := by
  classical
  let row (w : Block) := (orbit w).toFinset
  let W := ws.toFinset.image row
  have need := grouped_rank ws legit h W (fun w hw =>
    ⟨row w,Finset.mem_image_of_mem _ (List.mem_toFinset.mpr hw),fun _ hx => hx⟩)
  have five : (∑ x∈W,(x.card-1)) ≤ W.card*5 := by
    apply Finset.sum_le_card_nsmul
    intro x hx
    obtain ⟨w,hw,rfl⟩ := Finset.mem_image.mp hx
    have sz := wheel_contacts_six w (legit w (List.mem_toFinset.mp hw))
    change (orbit w).toFinset.card-1≤5
    omega
  have small : W.card≤ws.length := Finset.card_image_le.trans (List.toFinset_card_le _)
  change 719 ≤ 5*ws.length+separateRank Y s
  exact need.trans (Nat.add_le_add_right (five.trans (by omega)) _)

private theorem mass_le (Y : Multiset Block) (s : Block) : largeMass Y s ≤ Y.card := by
  classical
  let Q := (support Y s).image (label Y)
  let home := label Y s
  let K (q : Component Y) := (part Y q).card
  let B := largeOther Y s
  have home_mem : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have notBig : home∉B := by simp [B,home,largeOther]
  have subset : insert home B ⊆ Q := by
    intro q hq
    rcases Finset.mem_insert.mp hq with rfl|big
    · exact home_mem
    · exact (Finset.mem_filter.mp big).1
  have total := sum_part_card Y Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  change (∑q∈Q, K q)=Y.card at total
  have lower := Finset.sum_le_sum_of_subset (f:=K) subset
  rw [Finset.sum_insert notBig,total] at lower
  exact lower

/-- Even turns embedded in larger residual components can all be removed
for pricing. At least 186 edges must remain at this budget, so no more than
112 whole turns can be installed. Covers all endpoints and wheel repetitions. -/
theorem at_most_112 {Y : Multiset Block} {s t : Block} (ws : List Block)
    (legit : ∀ w∈ws, full w) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) : 186≤Y.card ∧ ws.length≤112 := by
  classical
  have sz := (sizes legit).1
  have bal := Essential.restBalance h (sizes legit).2
  have price := component_prices bal (fun e he =>
    h.edges_seven e (Multiset.mem_add.mpr (Or.inl he)))
  have rank : 719 ≤ 5*ws.length+separateRank Y s := residual_rank ws legit h
  rw [Multiset.card_add,sz] at budget
  have mass := mass_le Y s
  have enough : 186≤Y.card := by
    by_contra! tiny
    by_cases empty : largeOther Y s=∅
    · have rootSmall : (part Y (label Y s)).card < 186 := by
        have root_le : (part Y (label Y s)).card ≤ largeMass Y s :=
          Nat.le_add_right ..
        omega
      have cap := price.2.1 empty rootSmall
      omega
    · have pos : 0 < (largeOther Y s).card := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr empty)
      have cap := price.1
      omega
  exact ⟨enough,by omega⟩

/-- A certified overlap loss of one unit consumes the budget of ten
complete turns. Large closed components of the remainder incur the same charge. -/
theorem turns_with_loss {Y : Multiset Block} {s t : Block} (ws : List Block)
    (legit : ∀ w∈ws, full w) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (loss : Nat)
    (lower : 719+loss ≤ 5*ws.length+separateRank Y s) :
    183+50*(858-(Y+turns ws).card)+60*(loss+(largeOther Y s).card)≤largeMass Y s ∧
    ws.length+10*(loss+(largeOther Y s).card)≤112 := by
  have price := (component_prices (Essential.restBalance h (sizes legit).2) (fun e he =>
    h.edges_seven e (Multiset.mem_add.mpr (Or.inl he)))).1
  rw [Multiset.card_add,(sizes legit).1] at budget ⊢
  have total := mass_le Y s
  constructor <;> omega

end ExactWordFlow.EmbeddedWheels
#print axioms ExactWordFlow.EmbeddedWheels.at_most_112

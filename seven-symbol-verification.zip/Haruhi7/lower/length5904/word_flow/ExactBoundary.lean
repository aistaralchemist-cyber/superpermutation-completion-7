import NinetyFive
import TwelveBudget
import DirtyExitRank

namespace ExactWordFlow.ExactBoundary
open SevenWordWindows RotationCore RotationReinsert ResidualDensity RauzyBudget SuperpermutationBounds

/-- Duplicating the first letter introduces one dirty window and one dirty
six-context. It preserves both actual finite sets, including the phase data
used to decide whether a rotation class is complete. -/
theorem stutter (a : Fin 7) (xs : Block) (long : 6≤(a::xs).length) :
    visited (a::a::xs)=visited (a::xs) ∧ complete (a::a::xs)=complete (a::xs) := by
  have win : windows (a::a::xs)=(a::(a::xs).take 6)::windows (a::xs) := by
    rw [windows,ite_eq_left long]
  have states : anchors (a::a::xs)=(a::a::xs).take 6::anchors (a::xs) := by
    simp only [anchors,win,List.map_cons,dst,List.drop_succ_cons,List.drop_zero]
  have notClean : ¬full ((a::a::xs).take 6) := by simp [full]
  constructor
  · simp only [visited,states,List.filter_cons,decide_eq_true_eq,ite_eq_right notClean]
  · ext c
    rw [mem_complete,mem_complete]
    apply and_congr_right
    intro _
    have same (p : Block) (legal : p∈representatives) :
        p∈windows (a::a::xs) ↔ p∈windows (a::xs) := by
      rw [win,List.mem_cons]
      have ne : p≠a::(a::xs).take 6 := by
        intro eq
        have h:=(mem_reps p).mp legal
        simp [eq] at h
      exact or_iff_right ne
    constructor
    · intro yes p hp key
      exact (same p hp).mp (yes p hp key)
    · intro yes p hp key
      exact (same p hp).mpr (yes p hp key)

theorem pad {v : Block} {n : Nat} (long : 6≤v.length) (small : v.length≤n) :
    ∃ z : Block,z.length=n ∧ visited z=visited v ∧ complete z=complete v := by
  have extend (k : Nat) : ∃z : Block,z.length=v.length+k ∧ visited z=visited v ∧ complete z=complete v := by
    induction k with
    | zero => exact ⟨v,by simp,rfl,rfl⟩
    | succ k ih =>
      obtain ⟨z,sz,vis,fin⟩:=ih
      cases z with
      | nil => simp at sz; omega
      | cons a xs =>
        obtain ⟨left,right⟩:=stutter a xs (by omega)
        exact ⟨a::a::xs,by simp only [List.length_cons] at *; omega,left.trans vis,right.trans fin⟩
  obtain ⟨z,sz,hv,hc⟩:=extend (n-v.length)
  exact ⟨z,by omega,hv,hc⟩

/-- A counterexample can always be sought at just one exact core length. -/
theorem exact_length :
    (∃ w : Block,Covers w ∧ w.length≤5904) ↔
      ∃ v : Block,v.length=1529 ∧ (visited v).card=720 ∧ 95≤(complete v).card := by
  rw [NinetyFive.exact_1529]
  constructor
  · rintro ⟨v,long,small,hv,hc⟩
    obtain ⟨z,len,all,done⟩:=pad long small
    exact ⟨z,len,all ▸ hv,done ▸ hc⟩
  · rintro ⟨v,size,all,done⟩
    exact ⟨v,by omega,size.le,all,done⟩

/-- 5898 already suffices to fix the completed count after exact-length padding. -/
theorem exact_counts (floor : Transfer5901.WordFloor 5898) :
    (∃ w : Block,Covers w ∧ w.length≤5904) ↔
      ∃ v : Block,v.length=1529 ∧ (visited v).card=720 ∧ (complete v).card=95 := by
  rw [exact_length]
  constructor
  · rintro ⟨v,len,hit,many⟩
    obtain ⟨w,yes,sz⟩:=expand_remaining (v:=v) (by omega) hit
    have lo:=floor w yes
    exact ⟨v,len,hit,by omega⟩
  · rintro ⟨v,len,hit,count⟩
    exact ⟨v,len,hit,count.ge⟩

/-- The two certificates can explain the very same rank units. -/
def visible (v : Block) := extraContexts v+wheels v+repeats v+
  max (DirtyExitRank.forks v) (TwelveBudget.additional v)

theorem visible_le {v : Block} (long : 6≤v.length) : visible v≤defect v := by
  have a:=DirtyExitRank.word_forks_le v long
  have b:=TwelveBudget.within_rank v long
  unfold visible defect
  exact Nat.add_le_add_left (max_le a b) _

theorem boundary_cap {v : Block} (len : v.length=1529) (hit : (visited v).card=720)
    (many : 95≤(complete v).card) : visible v≤139 := by
  have h : 6≤v.length := by omega
  have hi:=visible_le (v:=v) h
  have cost:=length_eq v h
  omega

#print axioms stutter
#print axioms exact_length
#print axioms exact_counts
#print axioms boundary_cap
end ExactWordFlow.ExactBoundary

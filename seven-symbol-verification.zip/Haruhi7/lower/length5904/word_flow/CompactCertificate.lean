import CompactTraceBridge
import WheelLRAT

namespace ExactWordFlow.CompactWordCircuit
open Std.Sat Std.Tactic.BVDecide

private def appendRows (acc : Array (CNF.Clause Nat)) (rs : List (List W)) :=
  acc ++ (rs.map (fun row => CNF.Clause.ofLiterals (row.map wireLit))).toArray

/-- A tail-recursive materialization of the exact clause array, suitable for feeding a checker. -/
def buildRows : Nat → List Event → Array (CNF.Clause Nat) → Array (CNF.Clause Nat)
  | _, [], acc => acc
  | n, e::es, acc =>
    buildRows (advance n e) es (appendRows acc (localClauses (Int.ofNat (n+1)) e))

private theorem buildRows_eq (n : Nat) (es : List Event) (acc : Array (CNF.Clause Nat)) :
    buildRows n es acc = appendRows acc (signedRows n es) := by
  induction es generalizing n acc with
  | nil => simp [buildRows,signedRows,appendRows]
  | cons e es ih =>
    rw [buildRows,ih]
    simp [appendRows,signedRows,Array.append_assoc]

def checkerFormula (t : Tape) : CNF Nat := ⟨buildRows 0 t.body.toList #[]⟩

theorem checkerFormula_eq (t : Tape) (nz : ∀e∈t.body.toList,∀x∈args e,x≠0) :
    checkerFormula t = certFormula t := by
  cases eq : certFormula t with
  | mk c =>
    have h := formula_rows t nz
    rw [eq] at h
    simp only [CNF.clauses] at h
    rw [checkerFormula,buildRows_eq,h]
    simp [appendRows]

/-- Successful LRAT checks imply that this very list of output clauses is unsatisfiable. -/
theorem checked_unsat (t : Tape) (nz : ∀e∈t.body.toList,∀x∈args e,x≠0)
    {s : String} (ok : WheelLRAT.batch [checkerFormula t] [s]=true) :
    (certFormula t).Unsat := by
  rw [←checkerFormula_eq t nz]
  exact WheelLRAT.batch_sound ok _ (by simp)

end ExactWordFlow.CompactWordCircuit

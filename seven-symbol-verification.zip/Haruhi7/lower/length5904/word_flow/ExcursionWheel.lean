import Mathlib
import SevenReference

namespace ExcursionWheel

/-- Around any directed six-wheel with a minimum multiplicity m,
removing m complete turns leaves at most five times the positive divergence. -/
theorem min_turn (a b c d e f m : ℤ)
    (atMin : m=a ∨ m=b ∨ m=c ∨ m=d ∨ m=e ∨ m=f) :
    a+b+c+d+e+f-6*m ≤ 5*(max (a-f) 0 + max (b-a) 0 + max (c-b) 0 +
                           max (d-c) 0 + max (e-d) 0 + max (f-e) 0) := by
  have h (x : ℤ) : x ≤ max x 0 ∧ 0 ≤ max x 0 := ⟨le_max_left ..,le_max_right ..⟩
  obtain ⟨h₀,p₀⟩ := h (a-f)
  obtain ⟨h₁,p₁⟩ := h (b-a)
  obtain ⟨h₂,p₂⟩ := h (c-b)
  obtain ⟨h₃,p₃⟩ := h (d-c)
  obtain ⟨h₄,p₄⟩ := h (e-d)
  obtain ⟨h₅,p₅⟩ := h (f-e)
  rcases atMin with rfl|rfl|rfl|rfl|rfl|rfl <;> linarith

/-- These hypotheses are the contracted graph rank bound and the
six-wheel imbalance bound, with s compressed excursions visiting v
interior nonfull states in total. -/
theorem necessary (U B g s v z : ℤ) (area : U=B+g+v+s)
    (rank : 719≤B-z+s) (turns : B-6*z ≤ 5*(g+s+1)) :
    4309 ≤ 5*U+6*s-5*v := by omega

/-- Each compressed excursion has at least one interior nonfull state. -/
theorem length5904 (U s v : ℤ) (allowance : U≤858) (interior : s≤v)
    (cut : 4309≤5*U+6*s-5*v) :
    19+5*(v-s) ≤ s ∧ 19 ≤ s := by omega

/-- Given the abstract scalar constraints alone, the record's excursion
histogram can still fit the smaller allowance with B=715, g=0 and z=65. -/
theorem scalar_example :
    ∃ B g z : ℤ, 858=B+g+74+69 ∧ 719≤B-z+69 ∧ B-6*z≤5*(g+69+1) ∧
      0≤g ∧ 0≤z ∧ 6*z≤B := by
  exact ⟨715,0,65,by decide⟩

/-- Number of consecutive nonfull six-letter windows on each excursion.
Start and end states must be full; the finite check includes that condition. -/
def nonfullRuns : List Nat × Bool × Bool := Id.run do
  let ds := SevenReference.word.toList.toArray
  let mut a := #[]
  let mut streak := 0
  let mut startsFull := false
  for i in [0:ds.size-5] do
    if (ds.extract i (i+6)).toList.Nodup then
      if i==0 then startsFull := true
      if streak>0 then a := a.push streak
      streak := 0
    else streak := streak+1
  return (a.toList,startsFull,streak==0)

theorem record_histogram :
    nonfullRuns.2=(true,true) ∧
    nonfullRuns.1.length=69 ∧ nonfullRuns.1.sum=74 ∧
    nonfullRuns.1.count 1=64 ∧ nonfullRuns.1.count 2=5 := by native_decide

end ExcursionWheel
#print axioms ExcursionWheel.min_turn
#print axioms ExcursionWheel.necessary
#print axioms ExcursionWheel.record_histogram

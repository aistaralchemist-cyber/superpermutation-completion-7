import Reference64
import CleanFlow

namespace ExactWordFlow.DirtyWheelBudget
open GlobalWheelRank EmbeddedWheels ResidualDensity SevenWordWindows
abbrev Node := Sum Block Block

/-- Ordinary permutation cycles collapse to a vertex, but each repeated-letter
six-context is still a distinct vertex of the actual word graph. -/
def node (v : Block) : Node := if full v then .inl (cls v) else .inr v

def dirty (X : Multiset Block) : Finset Block :=
  ((X.toFinset.image src) ∪ (X.toFinset.image dst)).filter (fun v => ¬full v)

private def requiredNodes : Finset Node := (representatives.map (fun e => node (src e))).toFinset

def wheelNodes (q : Block) : Finset Node := (touches q).image Sum.inl

def wheelRows (ws : List Block) : Finset (Finset Node) := ws.toFinset.image wheelNodes

private def pair (e : Block) : Finset Node := {node (src e), node (dst e)}

/-- Different occurrences inducing the same unordered pair cost just once.
Ignore loops and steps already charged to one of the selected turns. -/
def otherPairs (ws : List Block) (F : Multiset Block) : Finset (Finset Node) :=
  (F.toFinset.filter (fun e => node (src e) ≠ node (dst e) ∧ e ∉ turns ws)).image pair

private theorem data : requiredNodes.card=720 ∧
    (∀e∈representatives, full (src e) ∧ node (src e)=node (dst e)) ∧
    ∀q∈states, (wheelNodes q).card=6 ∧
      ∀e∈wheel q, node (src e)∈wheelNodes q ∧ node (dst e)∈wheelNodes q := by
  native_decide

private theorem turn_step {ws : List Block} (ok : ∀q∈ws,full q)
    {e : Block} (he : e ∈ turns ws) : ∃ C∈wheelRows ws, node (src e)∈C ∧ node (dst e)∈C := by
  obtain ⟨q,hq,w⟩ := List.mem_flatMap.mp (show e∈ws.flatMap wheel from he)
  exact ⟨_,Finset.mem_image_of_mem _ (List.mem_toFinset.mpr hq),(data.2.2 _ (mem_states (ok _ hq))).2 _ w⟩

/-- Starting from any endpoint, count both the mandatory rotation classes
and every distinct dirty state in the used support. Each distinct selected
wheel contributes at most 5 and each other projected edge at most 1. -/
theorem rank {ws : List Block} {F : Multiset Block} {s t : Block}
    (ok : ∀q∈ws,full q) (h : Feasible (turns ws+F) s t) :
    719+(dirty (turns ws+F)).card ≤ 5*(wheelRows ws).card+(otherPairs ws F).card := by
  classical
  let X := turns ws+F
  let T := wheelRows ws
  let P := otherPairs ws F
  obtain ⟨C,st,size,rows⟩ := grow {node s} (T∪P)
  let region : Set Block := {v | node v∈C}
  have along (e) (he : e∈required+X) (enter : src e∈region) : dst e∈region := by
    change node (src e)∈C at enter
    change node (dst e)∈C
    rcases Multiset.mem_add.mp he with req|more
    · rwa [←(data.2.1 _ req).2]
    by_cases loop : node (src e)=node (dst e)
    · rwa [←loop]
    by_cases old : e ∈ turns ws
    · obtain ⟨D,mem,first,last⟩ := turn_step ok old
      exact rows D (Finset.mem_union_left P mem) ⟨_,Finset.mem_inter.mpr ⟨enter,first⟩⟩ last
    have newEdge := (Multiset.mem_add.mp more).resolve_left old
    have mem : pair e ∈ P := Finset.mem_image_of_mem _ (Finset.mem_filter.mpr
      ⟨Multiset.mem_toFinset.mpr newEdge,loop,old⟩)
    exact rows _ (Finset.mem_union_right T mem)
      ⟨_,Finset.mem_inter.mpr ⟨enter,by simp [pair]⟩⟩ (by simp [pair])
  have reach := h.reachable region (st (Finset.mem_singleton_self _)) along
  have mandatory : requiredNodes⊆C := by
    intro v hv
    obtain ⟨e,mem,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hv)
    exact reach e (Multiset.mem_add.mpr (Or.inl mem))
  let D : Finset Node := (dirty X).image Sum.inr
  have covered : D⊆C := by
    intro v hv
    obtain ⟨u,hu,rfl⟩ := Finset.mem_image.mp hv
    obtain ⟨edge,non⟩ := Finset.mem_filter.mp hu
    have nu : node u=Sum.inr u := by simp [node,non]
    rw [←nu]
    rcases Finset.mem_union.mp edge with source|dest
    · obtain ⟨e,mem,rfl⟩ := Finset.mem_image.mp source
      exact reach e (Multiset.mem_add.mpr (Or.inr (Multiset.mem_toFinset.mp mem)))
    · obtain ⟨e,mem,rfl⟩ := Finset.mem_image.mp dest
      have on : e∈required+X := Multiset.mem_add.mpr (Or.inr (Multiset.mem_toFinset.mp mem))
      exact along e on (reach e on)
  have separate : Disjoint requiredNodes D := by
    apply Finset.disjoint_left.mpr
    intro v hv hd
    obtain ⟨e,mem,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hv)
    obtain ⟨u,_,he⟩ := Finset.mem_image.mp hd
    simp [node,(data.2.1 _ mem).1] at he
  have low := Finset.card_le_card (Finset.union_subset mandatory covered)
  rw [Finset.card_union_of_disjoint separate,data.1] at low
  have dc : D.card=(dirty X).card := Finset.card_image_of_injective _ Sum.inr_injective
  rw [dc] at low
  have wheelPrice : ∑w∈T,(w.card-1) ≤ T.card*5 := by
    apply Finset.sum_le_card_nsmul
    intro w hw
    obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hw
    have nc := (data.2.2 q (mem_states (ok q (List.mem_toFinset.mp hq)))).1
    omega
  have edgePrice : ∑w∈P,(w.card-1) ≤ P.card*1 := by
    apply Finset.sum_le_card_nsmul
    intro w hw
    obtain ⟨e,_,rfl⟩ := Finset.mem_image.mp hw
    have small : (pair e).card≤2 := Finset.card_insert_le ..
    omega
  have un : (∑w∈T∪P,(w.card-1)) ≤ (∑w∈T,(w.card-1)) + (∑w∈P,(w.card-1)) :=
    (Nat.le_add_right _ _).trans (Finset.sum_union_inter ..).le
  change 719+(dirty X).card ≤ 5*T.card+P.card
  simp only [Finset.card_singleton] at size
  omega

private theorem count (ws : List Block) : (turns ws).card=6*ws.length := by
  induction ws with
  | nil => rfl
  | cons w ws ih =>
    change ((↑(wheel w) : Multiset Block)+turns ws).card=6*(ws.length+1)
    simp [ih,wheel,Nat.mul_add,Nat.add_comm]

/-- A global slack budget. It includes repetitions of ordinary wheels,
repeated mandatory arcs, repeated pairs, and excess occurrences. -/
theorem joint_loss {ws : List Block} {F : Multiset Block} {s t : Block}
    (ok : ∀q∈ws,full q) (h : Feasible (turns ws+F) s t) :
    719+(dirty (turns ws+F)).card+ws.length+5*(ws.length-(wheelRows ws).card)
      +(F.card-(otherPairs ws F).card) ≤ (turns ws+F).card := by
  have w : (wheelRows ws).card≤ws.length := Finset.card_image_le.trans (List.toFinset_card_le ws)
  have edges : (otherPairs ws F).card≤F.card := Finset.card_image_le.trans
    (Finset.card_filter_le _ _ |>.trans (Multiset.toFinset_card_le _))
  have lower := rank ok h
  rw [Multiset.card_add,count]
  omega

theorem at_5904 {ws : List Block} {F : Multiset Block} {s t : Block}
    (ok : ∀q∈ws,full q) (h : Feasible (turns ws+F) s t)
    (budget : (turns ws+F).card≤858) :
    (dirty (turns ws+F)).card+ws.length+5*(ws.length-(wheelRows ws).card)
      +(F.card-(otherPairs ws F).card) ≤ 139 := by
  have lower := joint_loss ok h
  omega

#print axioms at_5904
end ExactWordFlow.DirtyWheelBudget

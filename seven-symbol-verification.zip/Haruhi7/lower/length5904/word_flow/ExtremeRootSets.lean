import ExtremalRealizations
import MarkedExtrema

namespace ResidualDensity.ExtremeRootSets
open ExactWordFlow DirectedEuler WeightedMarks ExtremalRealizations

theorem route_coverage {a b : Six} {es : List Six}
    (r : Route src dst a es b) (width : ∀e∈es,e.length=7) (length : es.length=258)
    (many : 220≤classCount a es) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ((touched (a::es.map dst)).image (List.map f))∈realizations extremeProfiles := by
  apply route_coverage_of_masks r width length many
  intro v I walk marked count
  obtain ⟨ns,legit,spec⟩:=extreme_mask walk marked 0 count
  have ⟨⟨width,_⟩,positive⟩:=
    (Bool.and_eq_true_iff.mp (List.all_eq_true.mp profile_count.2.2 ns legit)).imp_left Bool.and_eq_true_iff.mp
  have rows : ns.length=40 := eq_of_beq width
  exact ⟨ns,legit,fun e=>by simp [e] at rows,fun j hj=>(of_decide_eq_true
    (List.all_eq_true.mp positive j hj)).1,spec⟩

private def censusCheck :=
  let results:=realizations extremeProfiles
  results.length==42 && results.toFinset.card==42 && results.all (fun s=>s.card==220) &&
    (extremeProfiles.filter (fun p=> !(realizations [p]).isEmpty)).length==6

/-- Seven normalized start phases of six surviving row profiles. Each
resulting marked set has 220 elements and is distinct from the other 41. -/
theorem census : censusCheck=true := by native_decide

#print axioms route_coverage
#print axioms census
end ResidualDensity.ExtremeRootSets

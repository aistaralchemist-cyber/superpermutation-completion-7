import WheelRepair

namespace ExactWordFlow.RepairedExcursions
open SevenWordWindows RotationCore RotationReinsert LapSkeleton DirectedEuler ResidualDensity ExcursionCore

private def ending (u : Block) := ((List.finRange 7).filter (fun x=>x∉u))++u

private theorem phases : ∀u∈states,
    ((ending u).length=7 ∧ (ending u).Nodup ∧ dst (ending u)=u ∧ classKey (ending u)=tag u) ∧
    ∀i∈List.range 6, full (u.rotate i) ∧ WheelContacts.wheel (u.rotate i)=WheelContacts.wheel u := by
  native_decide

/-- If a single wheel can restore every missing visit and at most one completed
class was lost on thirteen deleted edges, then every class of that wheel
is incomplete on the retained route. Its tags alone cannot secure a splice. -/
theorem wheel_has_no_intact_class {w : Block} {limit : Nat} (min : Minimal limit w)
    {s t : Block} {keep : List Block} (track : Route src dst s keep t)
    (start : s.length=6) (width : ∀e∈keep,e.length=7)
    (saved : keep.length+13≤(windows w).length) (few : (lost w keep).card≤1)
    {u : Block} (clean : full u) (restores : missingTags s keep⊆WheelContacts.wheel u)
    {c : Block} (onWheel : c∈WheelContacts.wheel u) :
    ∃p∈representatives,classKey p=c ∧ p∉keep := by
  obtain ⟨i,hi,hc⟩:=List.mem_map.mp (List.mem_toFinset.mp onWheel)
  let v:=u.rotate i
  obtain ⟨fl,wh⟩:=(phases u (mem_states clean)).2 i hi
  obtain ⟨len,unique,endp,tagEq⟩:=(phases v (mem_states fl)).1
  refine ⟨ending v,(mem_reps _).mpr ⟨len,unique⟩,tagEq.trans hc,?_⟩
  intro kept
  have att : v∈s::keep.map dst := by
    exact List.mem_cons_of_mem _ (endp ▸ (List.mem_map_of_mem kept))
  exact wheel_inaccessible min track start width saved few fl (wh.symm ▸ restores) att

#print axioms wheel_has_no_intact_class
end ExactWordFlow.RepairedExcursions

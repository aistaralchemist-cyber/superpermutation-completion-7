import LapShadowCapacity

namespace ExactWordFlow.LapDeletionShadow
open SevenWordWindows RotationCore DeletionShadow

/-- Adding a lap either raises the whole deletion bound by exactly one or
leaves it fixed, according to the occupancy of its unique projected row. -/
theorem upper_step (a : Fin 7) (l p r : Block) (hp : p∈representatives) :
    upper a (l++p++p.take 6++r)=upper a (l++p.take 6++r) +
      if capacity a (l++p.take 6++r) (proj a (classKey p))<6 then 1 else 0 := by
  let b:=proj a (classKey p)
  let big:=l++p++p.take 6++r
  let small:=l++p.take 6++r
  have member : classKey p∈allClasses := List.mem_toFinset.mpr (List.mem_map_of_mem hp)
  have present : b∈board6 a := Finset.mem_image_of_mem _ member
  have agree : ∑d∈(board6 a).erase b,capacity a big d=
      ∑d∈(board6 a).erase b,capacity a small d := by
    refine Finset.sum_congr rfl ?_
    intro d hd
    obtain ⟨diff,inside⟩:=Finset.mem_erase.mp hd
    exact (capacity_step a l p r hp inside).trans (if_neg diff)
  change ∑d∈board6 a,capacity a big d = (∑d∈board6 a,capacity a small d) + _
  rw [←Finset.sum_erase_add _ _ present,←Finset.sum_erase_add _ (capacity a small) present,agree]
  have changeRow := capacity_step a l p r hp present
  change capacity a big b = if b=b then min 6 (capacity a small b+1) else _ at changeRow
  rw [if_pos rfl] at changeRow
  rw [changeRow]
  have bound := at_most a small b
  have delta : min 6 (capacity a small b + 1) =
      capacity a small b + if capacity a small b<6 then 1 else 0 := by
    split <;> omega
  rw [delta]
  exact (Nat.add_assoc _ _ _).symm

theorem upper_many (a : Fin 7) {w z : Block} {ps : List Block} (cuts : Cuts w ps z) :
    upper a w≤upper a z+ps.length := by
  induction cuts with
  | stop => simp
  | remove hp _ ih =>
    rw [upper_step _ _ _ _ hp]
    simp only [List.length_cons]
    split <;> omega
end ExactWordFlow.LapDeletionShadow

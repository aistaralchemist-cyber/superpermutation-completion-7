import Mixed277Data
import LargeRowParent
import OrientedCNF

namespace ExactWordFlow.Mixed277
open SevenWordWindows RotationCore SeedWheelCut NearWheelBinding NearRootMoves ExtremeWheelCut ResidualDensity Cap35Fibers
open private valid eliminates from ExtremeWheelCut

private theorem width : ∀R∈allRows,R.card≤6 := by native_decide

private theorem from_answer {A : Finset Block} (ans : Answer) (pass : checkAnswer A ans=true)
    (bad : ∀T∈hard,(OrientedCNF.cnf T).Unsat) {W : Finset (Finset Block)}
    (leg : W⊆allRows) (bound : W.card≤91) (cover : ClosedCover A allClasses W) : False := by
  cases ans with
  | easy cert =>
    obtain ⟨size,ok⟩:=Bool.and_eq_true_iff.mp pass
    have cap:=of_decide_eq_true size
    exact eliminates cert A leg (by rw [board]; omega) ok cover
  | hard i ops =>
    obtain ⟨hi,eq,size⟩:=of_decide_eq_true pass
    have mem : hard.toArray[i]!∈hard := by rw [getElem!_pos hard.toArray i hi]; exact List.getElem_mem ..
    obtain ⟨Z,legal,count,yes⟩:=transport leg cover ops
    rw [eq] at yes
    exact OrientedCNF.no_cover legal (by rw [board,size];omega) (bad _ mem) yes

private theorem indexed {i j : Nat} (hi : i<roots.length) (hj : j<fibers.length)
    (checkedAll : checked=true) (shapes : (∀R∈roots,R.card=236) ∧ ∀F∈fibers,F.card=30)
    (bad : ∀T∈hard,(OrientedCNF.cnf T).Unsat) {p : Block} (hp : p∈fibers.toArray[j]!)
    {W : Finset (Finset Block)} (legal : W⊆allRows) (budget : W.card≤91)
    (yes : ClosedCover (makeSeed i j p) allClasses W) : False := by
  let R:=roots.toArray[i]!
  let F:=fibers.toArray[j]!
  have hbR : i<roots.toArray.size:=by simpa using hi
  have hbF : j<fibers.toArray.size:=by simpa using hj
  have memR : R∈roots:=by unfold R; rw [getElem!_pos roots.toArray i hbR]; exact List.getElem_mem ..
  have memF : F∈fibers:=by unfold F; rw [getElem!_pos fibers.toArray j hbF]; exact List.getElem_mem ..
  have cr:=shapes.1 R memR
  have cf:=shapes.2 F memF
  have small := LargeRowParent.cardinal yes (fun r hr=>width r (legal hr))
  change allClasses.card ≤ (R∪F.erase p).card+5*W.card at small
  rw [board] at small
  have testPair:=List.all_eq_true.mp (List.all_eq_true.mp checkedAll _ (List.mem_range.mpr hi)) _ (List.mem_range.mpr hj)
  change (decide (1 < (R∩F).card) || (F.sort (·≤·)).all
    (fun x=>decide ((R∪F.erase x).card<265) || checkAnswer (R∪F.erase x) (response i j x)))=true at testPair
  rcases Bool.or_eq_true_iff.mp testPair with overlap|checks
  · have big:=of_decide_eq_true overlap
    have cnt:=Finset.card_union_add_card_inter R F
    have sub : R∪F.erase p ⊆ R∪F :=Finset.union_subset_union_right (Finset.erase_subset ..)
    have le:=Finset.card_le_card sub
    omega
  · have hit:=List.all_eq_true.mp checks p ((Finset.mem_sort (·≤·)).mpr hp)
    rcases Bool.or_eq_true_iff.mp hit with lite|ok
    · have low:=of_decide_eq_true lite
      omega
    · exact from_answer _ ok bad legal budget yes

theorem reject {R F : Finset Block} (root:R∈roots) (family:F∈fibers)
    (all : checked=true) (data : (∀R∈roots,R.card=236) ∧ ∀F∈fibers,F.card=30)
    (bad : ∀T∈hard,(OrientedCNF.cnf T).Unsat)
    {p : Block} (hp : p∈F) {W : Finset (Finset Block)} (legal:W⊆allRows) (size:W.card≤91) :
    ¬ClosedCover (R∪F.erase p) allClasses W := by
  obtain ⟨i,hi,eq⟩:=List.mem_iff_getElem.mp root
  obtain ⟨j,hj,jq⟩:=List.mem_iff_getElem.mp family
  have er : roots.toArray[i]! = R:= by rw [getElem!_pos roots.toArray i (by simpa using hi)];exact eq
  have ef : fibers.toArray[j]! = F:= by rw [getElem!_pos fibers.toArray j (by simpa using hj)];exact jq
  intro cover
  apply indexed hi hj all data bad (p:=p) (ef ▸ hp) legal size
  simpa only [makeSeed,er,ef] using cover

#print axioms reject
end ExactWordFlow.Mixed277

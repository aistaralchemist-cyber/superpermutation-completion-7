import WordFlow

/-! An actual integer surplus at the target budget. Its degree data agree
with one open trail, and its support has a cut with no crossing edge. -/

namespace ExactWordFlow.Split
open SevenWordWindows
open SuperpermLowerBounds.LengthBudget.Word5905

def cycleEdges : List Block := (List.range 7).map fun i => (List.finRange 7).rotate i
def suffixWord := word.drop 8
def extraList := (windows suffixWord).filter (fun e => !decide e.Nodup)
def extra : Multiset Block := ↑extraList
def s := suffixWord.take 6
def t := suffixWord.drop (suffixWord.length-6)

def onCycle (v : Block) : Bool := (cycleEdges.map src).contains v

/-- The combined support consists of seven rotation edges and every window
of a genuine 5,897-letter suffix. Each prescribed edge is included once. -/
theorem partition : (↑cycleEdges : Multiset Block) + bag suffixWord = required + extra := by
  native_decide

theorem integer_data : s.length=6 ∧ suffixWord.length=5897 ∧ extra.card=858 ∧
    extra.map src + {t} = extra.map dst + {s} ∧
    (extraList.all fun e => e.length==7) = true := by native_decide

private theorem cut_table :
    ((cycleEdges ++ windows suffixWord).all fun e => onCycle (src e) == onCycle (dst e))=true ∧
    onCycle s = false ∧ onCycle (src (List.finRange 7))=true := by native_decide

/-- All 858 integral surplus windows balance correctly. Starting at s,
the seven required rotations in the separated cycle cannot be reached. -/
theorem failed_cut : ¬Feasible extra s t := by
  intro h
  let S : Set Block := {v | onCycle v = false}
  have closed (e) (mem : e∈required+extra) : src e ∈ S → dst e ∈ S := by
    rw [← partition] at mem
    have he : e∈cycleEdges ++ windows suffixWord := by
      change e∈((↑cycleEdges : Multiset Block) + ↑(windows suffixWord)) at mem
      rwa [Multiset.coe_add] at mem
    have sameSide :=  eq_of_beq (List.all_eq_true.mp cut_table.1 e he)
    change onCycle (src e)=false → onCycle (dst e)=false
    exact fun he => sameSide ▸ he
  have idmem : List.finRange 7 ∈ required+extra := by
    apply Multiset.mem_add.mpr
    exact Or.inl (show List.finRange 7 ∈ representatives from
      List.mem_permutations.mpr (List.Perm.refl _))
  have miss := h.reachable S cut_table.2.1 closed (List.finRange 7) idmem
  exact Bool.noConfusion (cut_table.2.2.symm.trans miss)

/-- Dropping reachability makes the target budget feasible. -/
theorem relaxation_feasible :
    ∃ (r : Multiset Block) (u v : Block), r.card=858 ∧ u.length=6 ∧
      (∀ b∈r, b.length=7) ∧ r.map src + {v} = r.map dst + {u} ∧ ¬Feasible r u v := by
  rcases integer_data with ⟨hs,_,sz,bal,widths⟩
  exact ⟨extra,s,t,sz,hs,fun b hb => eq_of_beq (List.all_eq_true.mp widths b hb),bal,failed_cut⟩

#print axioms relaxation_feasible
end ExactWordFlow.Split

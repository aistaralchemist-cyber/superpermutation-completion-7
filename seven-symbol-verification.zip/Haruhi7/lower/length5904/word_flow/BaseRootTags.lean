import WheelBaseResidual

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows DirectedEuler ResidualDensity ResidualRoutes ResidualIncidence
open RotationCore RotationReinsert LiteralWheelCover EmbeddedWheels
open private required_data from ResidualIncidence
open private mem_sources from ResidualRoutes

private theorem all_iff {a b : Block} {es : List Block} (r:Route src dst a es b) (p:Block→Prop)
    (stable : ∀e∈es,p (src e)↔p (dst e)) :
    ∀v∈a::es.map dst,p v↔p a := by
  induction r with
  | nil => simp
  | @cons x y es e eq path ih =>
    have first:=stable e List.mem_cons_self
    rw [eq] at first
    intro v hv
    rcases List.mem_cons.mp hv with rfl|later
    · rfl
    · exact (ih (fun f hf=>stable f (List.mem_cons_of_mem _ hf)) v later).trans first.symm

/-- Distinct rotation classes attested by the base must be touched by the single
remaining path. An unvisited class can only carry isolated mandatory edges. -/
theorem base_on_path {b s t : Block} {es : List Block} (long:6≤b.length)
    (enough:2≤(visited b).card) (r:Route src dst s es t)
    (incl:bag b≤required+(↑es : Multiset Block)) :
    visited b ⊆ touched (s::es.map dst) := by
  classical
  intro c hc
  by_contra outside
  let P (v : Block):=full v ∧ tag v=c
  have notRoot (u) (hu:u∈s::es.map dst) : ¬P u:=by
    rintro ⟨fu,key⟩
    exact outside (List.mem_toFinset.mpr (List.mem_map.mpr
      ⟨u,List.mem_filter.mpr ⟨hu,decide_eq_true fu⟩,key⟩))
  have stable (e) (he:e∈windows b): P (src e)↔P (dst e):=by
    rcases Multiset.mem_add.mp (Multiset.mem_of_le incl (show e∈bag b from he)) with mand|edge
    · obtain ⟨x,y,equal⟩:=required_data e mand
      simp [P,x,y,equal]
    · exact iff_of_false (notRoot _ (mem_sources r edge))
        (notRoot _ (List.mem_cons_of_mem _ (List.mem_map.mpr ⟨e,edge,rfl⟩)))
  have every:=all_iff (read_route b long) P stable
  obtain ⟨u,hu,fu,key⟩:=(mem_visited b c).mp hc
  have first:= (every u hu).mp ⟨fu,key⟩
  have sub : visited b⊆{c} := by
    intro d hd
    obtain ⟨v,hv,_,kd⟩:=(mem_visited b d).mp hd
    exact Finset.mem_singleton.mpr (kd.symm.trans ((every v hv).mpr first).2)
  have small:=Finset.card_le_card sub
  simp only [Finset.card_singleton] at small
  omega

theorem insertion_bound {b v : Block} {rs : List Row} (p : Inserts b rs v) :
    (visited v).card≤(visited b).card+5*rs.length := by
  induction p with
  | stop => simp
  | @add l u r rs z fl _ ih =>
    let w:=l++u++r
    let R:=WheelContacts.wheel u
    have size : R.card=6:=wheel_contacts_six u fl
    have hu : u∈anchors w:=(WheelAccess.anchor_iff w u fl).mpr ⟨l,r,rfl⟩
    have tagMem : tag u∈R:=by
      change tag u∈(orbit u).toFinset
      exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨0,by decide,by simp⟩)
    have x:=Finset.card_pos.mpr (show ((visited w)∩R).Nonempty from
      ⟨tag u,Finset.mem_inter.mpr ⟨(mem_visited ..).mpr ⟨u,hu,fl,rfl⟩,tagMem⟩⟩)
    have sum:=Finset.card_union_add_card_inter (visited w) R
    rw [WheelAccess.visited_step l u r fl] at ih
    change (visited z).card≤(visited w∪R).card+5*rs.length at ih
    change (visited z).card≤(visited w).card+5*(rs.length+1)
    omega

#print axioms base_on_path
#print axioms insertion_bound
end ExactWordFlow.WheelBaseResidual

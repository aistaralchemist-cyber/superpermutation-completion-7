import TwinAt859
import CoreCounts
namespace ExactWordFlow.SignGap858
open SevenWordWindows ResidualDensity RotationCore RotationReinsert MarkedGeometry WeightedMarks

/-- Inversion sign is well defined on seven-symbol rotation classes:
the key used here is their canonical representative. -/
def inversions : Block → Nat
  | [] => 0
  | a::as => (as.filter (fun b=>decide (b<a))).length + inversions as

def sample : Block := (List.replicate 72 ([0,1,2,3,4,5] : Block)).flatten ++
  (List.replicate 72 ([6,1,2,3,4,5] : Block)).flatten

def flags : List Bool := "1011111010110100111110000111011111101111110111111011111101101111110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111011111101111110111111011110111111011111101111110111011111101111110111111011111101110111111011111101111110111101111110111111011110111111011111101111110111101111110111111011111101111011111101111110111101111110111111011111101111011111101111110111111011110111111011111101111110111111".toList.map (· == '1')

def markedTags : List Block := ((anchors sample).zip flags).filterMap
  (fun (u,on)=>if on then some (tag u) else none)

set_option maxRecDepth 12000 in
theorem parity_obstruction_insufficient :
    sample.length=864 ∧ sample.toFinset.card=7 ∧ (anchors sample).length=859 ∧
    (∀u∈anchors sample, full u) ∧ flags.length=859 ∧ flags.count true=720 ∧
    (∀s∈forbidden, ¬s <:+: flags) ∧
    ((markedTags.filter (fun c=>decide (inversions c % 2=0))).length=360) ∧
    ((markedTags.filter (fun c=>decide (inversions c % 2=1))).length=360) ∧
    (visited sample).card=10 := by native_decide

theorem scalar_at_858 {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (w : Walk u) (h : Marked u p) (i : Nat) : count p i 859 ≤ 726 := by
  have price := interval_price w h i 859
  omega

#print axioms parity_obstruction_insufficient
#print axioms scalar_at_858
end ExactWordFlow.SignGap858

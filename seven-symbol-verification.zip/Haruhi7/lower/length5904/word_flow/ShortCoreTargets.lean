import BudgetCoreCurve
import ShortComponentCaps

namespace ExactWordFlow.ShortCoreTargets
open SevenWordWindows SuperpermutationBounds BudgetCoreCurve

theorem at5901 : (∃w : Block,Covers w ∧ w.length≤5901) ↔ atLength 1302 63 :=
  threshold 855 63 (by decide) fun h=> (ShortComponentCaps.component_limits h).1

theorem at5902 : (∃w : Block,Covers w ∧ w.length≤5902) ↔ atLength 1394 76 :=
  threshold 856 76 (by decide) fun h=> (ShortComponentCaps.component_limits h).2.1

theorem at5903 : (∃w : Block,Covers w ∧ w.length≤5903) ↔ atLength 1479 88 :=
  threshold 857 88 (by decide) fun h=> (ShortComponentCaps.component_limits h).2.2

#print axioms at5901
#print axioms at5902
#print axioms at5903
end ExactWordFlow.ShortCoreTargets

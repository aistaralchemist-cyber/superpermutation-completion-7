import FrontWordRows
import FrontWordPorts

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows CoreRecordBits SortedCoreRecords CoreCandidateBanks FrontRawBudget
open CompactFrontPlan FrontLocalMeaning

theorem records_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {w : Block} (len : w.length=1501) {cols : Rows}
    (hc : ArrayRel (RowRep v 7) cols ((Array.range 1501).map (hot w))) :
    Gives T (frontPhase cols) (fun out=>
      List.Forall₂ (fun r ws=>BitsRep v ws r) out.1.toList ((wordRows digits w).map rowWires) ∧
      BitsRep v (cleanSignals w).toArray out.2.1 ∧ BitsRep v (winSignals w).toArray out.2.2) := by
  exact records_from_ports law unit len hc (fun bs hb i hi=>ports_for_word len unit hc hb hi) (next_for_word len hc)

#print axioms records_gives
end ExactWordFlow.CompactWordCircuit

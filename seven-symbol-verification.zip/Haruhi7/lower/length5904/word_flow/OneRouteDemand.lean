import RunSpelling
import TwinAt859
import NearHundredShape
namespace ExactWordFlow.WheelDemand
open SevenWordWindows ResidualDensity ForcedRuns DirectedEuler ResidualIncidence ResidualRoutes RotationComponentCount
open private partition from HundredDecomposition
open private rank_partition hits from NearHundredShape
open private select from RouteDensity
open scoped Classical

theorem lone_component {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤858)
    (none : (occupied X s).card=0) : ∃es,Route src dst s es t ∧ (↑es : Multiset Block)=X ∧
      ∃T P, Realized s es T P ∧ 59≤T ∧ 20≤P := by
  have empty:=Finset.card_eq_zero.mp none
  have bag0:=partition X s
  rw [empty,Finset.sum_empty,add_zero] at bag0
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨as',bt'⟩:=ends.1 rfl
  subst a;subst b
  have eq : (↑es : Multiset Block)=X:=bag.trans bag0.symm
  have len : es.length=X.card:=congrArg Multiset.card eq
  have wd (e) (he:e∈es):=h.edges_seven e (eq ▸ (show e∈(↑es : Multiset Block) from he))
  have rank:=rank719 _ h (fun _ he=>on_edge he)
  change 719 ≤ separateRank X s at rank
  rw [rank_partition h,empty,Finset.sum_empty,add_zero] at rank
  have incl:hits X s (label X s)≤classCount s es:=contacts_bound _ lv r bag
  obtain ⟨u,w,hu,hk,edge⟩:=route_walk r wd
  obtain ⟨I,hI,cnt⟩:=select u (es.length+1)
  rw [edge] at cnt
  change count (·∈I) 0 (es.length+1)=classCount s es at cnt
  obtain ⟨single,pair⟩:=at_859 w hI 0 (es.length+1) (by omega) (by omega)
  exact ⟨es,r,eq,_,_,⟨u,I,0,es.length+1,w,edge,Or.inl (by omega),hI,cnt,rfl,rfl⟩,single,pair⟩

#print axioms lone_component
end ExactWordFlow.WheelDemand

import FusedPacked
import WheelAcceptBits
import WheelBitsFacts
import Cap92LookCore

namespace ExactWordFlow.Cap92Lookup
open SevenWordWindows Cap92Catalog
open Cap94Lookup (bits known)
def acceptBits (b : Nat) : Bool := wheelMaskCheck keys lookup rows.size b
theorem acceptBits_eq (R : Finset Block) :
    (acceptBits (bits 0 R) && decide (∀c∈R,known c=true))=accept R := by
  unfold acceptBits wheelMaskCheck accept
  simp [Bool.and_assoc]
end ExactWordFlow.Cap92Lookup


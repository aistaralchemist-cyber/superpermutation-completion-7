import RotationKeyMask
import Mathlib.Order.Sum.Order

namespace ExactWordFlow.SortedCoreRecords
open SevenWordWindows RotationCore RotationKeyMask ResidualDensity

/-- The valid part stores the canonical rotation (whose first symbol is zero).
The invalid part retains arbitrary key digits, including those of padding. -/
abbrev Key := Block ⊕ₗ List Nat

structure Row where
  key : Key
  mask : Finset (Fin 7)
  deriving DecidableEq

def contextKey (dirtyKey : Block → List Nat) (u : Block) : Key :=
  if full u then Sum.inlₗ (tag u) else Sum.inrₗ (dirtyKey u)

def windowRow (dirtyKey : Block → List Nat) (p : Block) : Row :=
  ⟨contextKey dirtyKey (src p), if p.Nodup then p.getLast?.toFinset else ∅⟩

def wordRows (dirtyKey : Block → List Nat) (w : Block) : List Row :=
  (windows w).map (windowRow dirtyKey) ++ [⟨contextKey dirtyKey (w.drop (w.length-6)), ∅⟩]

def visible (a : Option (Fin 7)) (bits : Finset (Fin 7)) : Prop :=
  match a with
  | none => True
  | some b => b ∈ bits

def occurs (rs : List Row) (k : Key) (a : Option (Fin 7)) : Prop :=
  ∃ r ∈ rs, r.key = k ∧ visible a r.mask

private theorem occurs_cons (r : Row) (rs : List Row) (k : Key) (a) :
    occurs (r::rs) k a ↔ (r.key=k ∧ visible a r.mask) ∨ occurs rs k a := by
  simp [occurs]

/-- Same-key records OR their masks. The previous group is emitted on a key
change, and the last group is emitted at the end. -/
def scan (r : Row) : List Row → List Row
  | [] => [r]
  | s::rs => if r.key=s.key then scan ⟨s.key,s.mask ∪ r.mask⟩ rs else r::scan s rs

def grouped : List Row → List Row
  | [] => []
  | r::rs => scan r rs

def ordered (rs : List Row) := rs.Pairwise fun a b => a.key ≤ b.key

private theorem scan_occurs (r : Row) (rs : List Row) (k : Key) (a) :
    occurs (scan r rs) k a ↔ occurs (r::rs) k a := by
  induction rs generalizing r with
  | nil => rfl
  | cons s rs ih =>
    rw [scan]
    by_cases eq : r.key = s.key
    · rw [ite_eq_left eq,ih,occurs_cons,occurs_cons r,occurs_cons s]
      cases a <;> simp only [visible,Finset.mem_union,eq] <;> tauto
    · rw [ite_eq_right eq,occurs_cons,ih,occurs_cons r]

theorem grouped_occurs (rs : List Row) (k : Key) (a) :
    occurs (grouped rs) k a ↔ occurs rs k a := by
  cases rs with
  | nil => rfl
  | cons r rs => exact scan_occurs r rs k a

private theorem scan_nodup (r : Row) (rs : List Row) (ord : ordered (r::rs)) :
    ((scan r rs).map Row.key).Nodup := by
  induction rs generalizing r with
  | nil => simp [scan]
  | cons s rs ih =>
    obtain ⟨first,tail⟩ := List.pairwise_cons.mp ord
    rw [scan]
    by_cases eq : r.key=s.key
    · rw [ite_eq_left eq]
      exact ih _ (List.pairwise_cons.mpr (List.pairwise_cons.mp tail))
    · rw [ite_eq_right eq,List.map_cons,List.nodup_cons]
      refine ⟨?_,ih s tail⟩
      intro mem
      obtain ⟨q,hq,eqKey⟩ := List.mem_map.mp mem
      have witness : occurs (scan s rs) r.key none := ⟨q,hq,eqKey,trivial⟩
      obtain ⟨q,hq,eqKey,_⟩ := (scan_occurs s rs r.key none).mp witness
      have bound : s.key ≤ q.key := by
        rcases List.mem_cons.mp hq with h | h
        · rw [h]
        · exact (List.pairwise_cons.mp tail).1 q h
      exact eq (le_antisymm (first s List.mem_cons_self) (eqKey ▸ bound))

theorem grouped_nodup {rs : List Row} (ord : ordered rs) :
    ((grouped rs).map Row.key).Nodup := by
  cases rs with
  | nil => simp [grouped]
  | cons r rs => exact scan_nodup r rs ord

private theorem context_clean_iff (d : Block → List Nat) (u c : Block) :
    contextKey d u=Sum.inlₗ c ↔ full u ∧ tag u=c := by
  by_cases h : full u <;> simp [contextKey,h,Sum.inlₗ,Sum.inrₗ]

theorem rows_visit (d : Block → List Nat) {w : Block} (long : 6≤w.length) (c : Block) :
    occurs (wordRows d w) (Sum.inlₗ c) none ↔ c∈visited w := by
  rw [visited_iff_record long]
  simp [occurs,wordRows,windowRow,visible,context_clean_iff]

theorem rows_bit (d : Block → List Nat) (w c : Block) (a : Fin 7) :
    occurs (wordRows d w) (Sum.inlₗ c) (some a) ↔ bitSeen w c a := by
  constructor
  · rintro ⟨r,hr,key,ha⟩
    rcases List.mem_append.mp hr with h | h
    · obtain ⟨p,hp,rfl⟩ := List.mem_map.mp h
      change a ∈ (if p.Nodup then p.getLast?.toFinset else ∅) at ha
      split at ha
      next clean =>
        have cp := permutation_record ((mem_reps _).mpr ⟨RotationReinsert.window_width w hp,clean⟩)
        refine ⟨p,hp,clean,cp.2.1.symm.trans ((context_clean_iff ..).mp key).2,?_⟩
        exact Option.mem_toFinset.mp ha
      next _ => simp at ha
    · obtain rfl := List.mem_singleton.mp h
      simp [visible] at ha
  · rintro ⟨p,hp,clean,key,last⟩
    have cp := permutation_record ((mem_reps _).mpr ⟨RotationReinsert.window_width w hp,clean⟩)
    refine ⟨windowRow d p,List.mem_append_left _ (List.mem_map.mpr ⟨p,hp,rfl⟩),
      (context_clean_iff ..).mpr ⟨cp.1,cp.2.1.trans key⟩,?_⟩
    simp [visible,windowRow,clean,last]


def classOf (k : Key) : Option Block := (ofLex k).getLeft?

private theorem classOf_eq {k : Key} {c : Block} :
    classOf k = some c ↔ k=Sum.inlₗ c := by
  change (ofLex k).getLeft?=some c ↔ ofLex k = Sum.inl c
  cases ofLex k <;> simp

def outputKeys (gs : List Row) (needFull : Bool) : List Block :=
  (gs.filter fun r => !needFull || decide (r.mask=Finset.univ)).filterMap fun r => classOf r.key

private theorem output_nodup {gs : List Row} (nd : (gs.map Row.key).Nodup) (need : Bool) :
    (outputKeys gs need).Nodup := by
  have pw : gs.Pairwise (fun r s => r.key ≠ s.key) :=
    List.pairwise_map.mp (List.nodup_iff_pairwise_ne.mp nd)
  let accept := fun r : Row => !need || decide (r.mask=Finset.univ)
  have fil : (gs.filter accept).Pairwise (fun r s => r.key ≠ s.key) :=
    List.pairwise_filter.mpr (pw.imp fun h _ _ => h)
  apply List.nodup_iff_pairwise_ne.mpr
  exact fil.filterMap (S:=fun x y : Block => x ≠ y) (fun r => classOf r.key) (fun _ _ diff x hx y hy same =>
    diff ((classOf_eq.mp hx).trans (same ▸ (classOf_eq.mp hy).symm)))

private theorem output_visit (gs : List Row) (c : Block) :
    c ∈ outputKeys gs false ↔ occurs gs (Sum.inlₗ c) none := by
  simp [outputKeys,occurs,visible,List.mem_filterMap,classOf_eq]

private theorem output_full {gs : List Row} (nd : (gs.map Row.key).Nodup) (c : Block) :
    c∈outputKeys gs true ↔ occurs gs (Sum.inlₗ c) none ∧
      ∀ a : Fin 7, occurs gs (Sum.inlₗ c) (some a) := by
  have mem : c∈outputKeys gs true ↔ ∃r∈gs,r.mask=Finset.univ ∧ r.key=Sum.inlₗ c := by
    simp [outputKeys,List.mem_filterMap,List.mem_filter,classOf_eq,and_assoc]
  rw [mem]
  constructor
  · rintro ⟨r,hr,all,key⟩
    exact ⟨⟨r,hr,key,trivial⟩,fun a => ⟨r,hr,key,by simp [visible,all]⟩⟩
  · rintro ⟨⟨r,hr,key,_⟩,bits⟩
    refine ⟨r,hr,Finset.eq_univ_of_forall fun a => ?_,key⟩
    obtain ⟨s,hs,eq,bit⟩ := bits a
    obtain rfl := List.inj_on_of_nodup_map nd hs hr (eq.trans key.symm)
    exact bit

/-- Padding may use any invalid key and any mask; no invalid group is counted. -/
def padding (extra : List Row) := ∀r∈extra, ∃junk, r.key=Sum.inrₗ junk

private theorem original {extra rs source : List Row} (pad : padding extra)
    (perm : rs.Perm (source++extra)) (c : Block) (a) :
    occurs rs (Sum.inlₗ c) a ↔ occurs source (Sum.inlₗ c) a := by
  constructor
  · rintro ⟨r,hr,key,bit⟩
    rcases List.mem_append.mp (perm.mem_iff.mp hr) with yes|bad
    · exact ⟨r,yes,key,bit⟩
    · obtain ⟨junk,eq⟩:=pad r bad
      simp [eq,Sum.inrₗ,Sum.inlₗ] at key
  · rintro ⟨r,hr,key,bit⟩
    exact ⟨r,perm.mem_iff.mpr (List.mem_append_left _ hr),key,bit⟩

/-- Counts of closed, valid equal-key runs; the second count additionally
requires that the accumulated mask contains all seven symbols. -/
def counts (rs : List Row) : Nat × Nat :=
  ((outputKeys (grouped rs) false).length,(outputKeys (grouped rs) true).length)

theorem sorted_counts {w : Block} (long : 6≤w.length) (d : Block → List Nat)
    {extra rs : List Row} (pad : padding extra)
    (perm : rs.Perm (wordRows d w ++ extra)) (order : ordered rs) :
    counts rs = ((visited w).card,(complete w).card) := by
  have collect (c : Block) (a : Option (Fin 7)) :=
    (grouped_occurs rs (Sum.inlₗ c) a).trans (original pad perm c a)
  have vis : (outputKeys (grouped rs) false).toFinset=visited w := by
    ext c
    rw [List.mem_toFinset,output_visit,collect,rows_visit d long]
  have done : (outputKeys (grouped rs) true).toFinset=complete w := by
    ext c
    rw [List.mem_toFinset,output_full (grouped_nodup order),collect,rows_visit d long]
    simp_rw [collect,rows_bit d]
    constructor
    · rintro ⟨hit,all⟩
      exact (complete_iff_all_bits (visited_subset w hit)).mpr all
    · intro hit
      exact ⟨complete_subset w hit,(complete_iff_all_bits ((mem_complete w _).mp hit).1).mp hit⟩
  have num (need : Bool) := List.toFinset_card_of_nodup (output_nodup (grouped_nodup order) need)
  exact Prod.ext ((num false).symm.trans (congrArg Finset.card vis))
    ((num true).symm.trans (congrArg Finset.card done))

/-- The canonical sorted witness can be constructed for any padded input. -/
def sortRows (rs : List Row) := rs.mergeSort fun a b => decide (a.key ≤ b.key)

theorem sorted_witness (rs : List Row) : (sortRows rs).Perm rs ∧ ordered (sortRows rs) := by
  refine ⟨List.mergeSort_perm ..,?_⟩
  have sorted := List.pairwise_mergeSort (le := fun a b : Row => decide (a.key ≤ b.key))
    (by intro a b c h k; exact decide_eq_true (le_trans (of_decide_eq_true h) (of_decide_eq_true k)))
    (by intro a b; simpa using le_total a.key b.key) rs
  exact sorted.imp fun h => of_decide_eq_true h

#print axioms sorted_counts
end ExactWordFlow.SortedCoreRecords

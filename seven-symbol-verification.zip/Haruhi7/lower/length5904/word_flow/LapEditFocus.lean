import LapEditContexts

namespace ExactWordFlow.LapEditContexts
open SevenWordWindows

/-- The kept tile carrying any specified output letter, with independent
choices before and after that tile. -/
theorem focus {ts w ps} (r : Render ts w ps) (i : Nat) (hi : i<w.length) :
    ∃ L t R u v ls rs k, ts=L++t::R ∧ Render L u ls ∧ Render R v rs ∧
      w=u++t.raw++v ∧ ps=ls++rs ∧ i=u.length+k ∧ k<t.raw.length := by
  induction r generalizing i with
  | nil => simp at hi
  | @keep ts w ps t rest ih =>
    by_cases here : i<t.raw.length
    · exact ⟨[],t,ts,[],w,[],ps,i,rfl,.nil,rest,rfl,rfl,by simp,here⟩
    · have small : i-t.raw.length<w.length := by simp at hi;omega
      obtain ⟨L,q,R,u,v,ls,rs,k,e,a,b,f,g,h,n⟩:=ih _ small
      exact ⟨t::L,q,R,t.raw++u,v,ls,rs,k,by simp [e],.keep _ a,b,
        by simp [f,List.append_assoc],g,by simp;omega,n⟩
  | @passLap t p ts w ps may rest ih =>
    obtain ⟨L,q,R,u,v,ls,rs,k,e,a,b,f,g,h,n⟩:=ih i hi
    exact ⟨t::L,q,R,u,v,p::ls,rs,k,by simp [e],.passLap may a,b,f,by simp [g],h,n⟩

abbrev Test := Block → Fin 7 → Block → List Block → Bool

/-- Flanks are passed nearest letter first on the left and in natural order
on the right. The saved permutation list witnesses necessary skips. -/
def localTest (f : Test) (back : List Tile) (t : Tile) (rs : List Tile) : Bool :=
  let left:=sides 6 back
  let right:=sides 6 rs
  (List.range t.raw.length).all fun k=>left.all fun (l,ls)=>right.all fun (r,qs)=>
    f (((t.raw.take k).reverse++l).take 6) (t.raw[k]?.getD 0)
      ((t.raw.drop (k+1)++r).take 6) (ls++qs)

def scan (f : Test) (back : List Tile) : List Tile → Bool
  | [] => true
  | t::rs => localTest f back t rs && scan f (t.flip::back) rs

private theorem at_split {f back t rs} (ls : List Tile)
    (yes : scan f back (ls++t::rs)=true) :
    localTest f (ls.reverse.map Tile.flip++back) t rs=true := by
  induction ls generalizing back with
  | nil => exact (Bool.and_eq_true_iff.mp yes).1
  | cons h hs ih =>
    have yes':=ih (Bool.and_eq_true_iff.mp yes).2
    simpa [List.append_assoc] using yes'

private theorem limited (l r : Block) : (l++r.take 6).take 6=(l++r).take 6 := by
  simp [List.take_append,List.take_take]

/-- A single finite scan entails the local test for every letter of every
word rendered by the optional tiles, with the witnesses actually omitted. -/
theorem at_letter {f ts w ps} (yes : scan f [] ts=true) (r : Render ts w ps) (i : Nat)
    (hi : i<w.length) : ∃ l x z seen, w=l++[x]++z ∧ i=l.length ∧
      f (l.reverse.take 6) x (z.take 6) seen=true ∧ ∀p∈seen,p∈ps := by
  obtain ⟨L,t,R,u,v,ls,rs,k,e,a,b,wEq,skipped,pos,lt⟩:=focus r i hi
  have ok:=at_split L (e ▸ yes)
  simp only [List.append_nil] at ok
  obtain ⟨left,seenL,subL⟩:=side_sound a.reverse 6
  obtain ⟨right,seenR,subR⟩:=side_sound b 6
  have chk:=List.all_eq_true.mp (List.all_eq_true.mp
    (List.all_eq_true.mp ok k (List.mem_range.mpr lt)) _ seenL) _ seenR
  let x := t.raw[k]
  let l := u++t.raw.take k
  let z := t.raw.drop (k+1)++v
  have middle : t.raw.take k++[x]++t.raw.drop (k+1)=t.raw := by
    rw [show t.raw.take k++[x]=t.raw.take (k+1) from List.take_append_getElem lt,List.take_append_drop]
  refine ⟨l,x,z, left++right, ?_, ?_, ?_, ?_⟩
  · rw [wEq]
    simpa only [l,z,List.append_assoc] using congrArg (fun q=>u++q++v) middle.symm
  · simp [l,pos,Nat.min_eq_left (Nat.le_of_lt lt)]
  · simpa only [l,z,List.reverse_append,limited,List.getElem?_eq_getElem lt,Option.getD_some,x] using chk
  · intro p hp
    rw [skipped]
    rcases List.mem_append.mp hp with h|h
    · exact List.mem_append_left _ (List.mem_reverse.mp (subL p h))
    · exact List.mem_append_right _ (subR p h)

#print axioms at_letter
end ExactWordFlow.LapEditContexts

import WheelBaseExits
import CoreAssembly

namespace ExactWordFlow.WheelBaseExits
open SevenWordWindows ResidualDensity RotationCore WheelFreeBoundary

-- Keep the multiplicities of all windows after subtracting one mandatory
-- seven-cycle per class completed by this particular word.
def spare (b : Block) := bag b - CoreAssembly.mandatory (complete b)

private theorem tags : ∀s∈states,
    (∀u∈phases s, full u ∧ tag u∈WheelContacts.wheel s) ∧
    ∀u∈phases s,∀v∈phases s,tag u=tag v → u=v := by native_decide

private theorem sourceTag : ∀p∈representatives,tag (src p)=classKey p := by native_decide

private theorem spent {b v : Block} (clean : full v) (departure : leaves b v)
    (endOff : ∀l : Block,b≠l++v)
    (alone : ∀a : Fin 7,v++[a]∈spare b → a=v.headD 0) :
    tag v∈complete b := by
  obtain ⟨l,r,form,off⟩:=departure
  cases r with
  | nil => exact False.elim (endOff l (by simpa using form))
  | cons a r =>
    let e := v++[a]
    have srcE : src e=v := by simp [src,e,clean.1]
    have occ : e∈windows b := by
      have hit:=window_mem l e r (by simp [e,clean.1])
      rw [form]
      simpa only [e,List.append_assoc,List.singleton_append] using hit
    have required : e∈CoreAssembly.mandatory (complete b) := by
      by_contra absent
      have ned : e∈spare b := by
        have plus : 0<(bag b).count e:=Multiset.count_pos.mpr occ
        have zero:=Multiset.count_eq_zero.mpr absent
        apply Multiset.count_pos.mp
        rw [spare,Multiset.count_sub,zero,Nat.sub_zero]
        exact plus
      exact off (by simpa using alone a ned)
    obtain ⟨rep,done⟩:=Multiset.mem_filter.mp required
    have key:=sourceTag e rep
    rw [srcE] at key
    exact key ▸ done

/-- Every complete residual wheel of a stripped base with no other residual
exit and not containing the endpoint needs two different completed classes.
This applies even when no further wheels are inserted (m=0). -/
theorem isolated_needs_two {b s : Block} (free : WheelFree b) (clean : full s)
    (each : ∀u∈phases s,occurs (prefixAt u 1) b)
    (endOff : ∀u∈phases s,∀l : Block,b≠l++u)
    (isolated : ∀u∈phases s,∀a : Fin 7,u++[a]∈spare b → a=u.headD 0) :
    2≤((WheelContacts.wheel s)∩complete b).card := by
  obtain ⟨v,vs,w,ws,ne,xv,xw⟩:=two_exits free clean each
  obtain ⟨data,inj⟩:=tags s (mem_states clean)
  obtain ⟨fv,iv⟩:=data v vs
  obtain ⟨fw,iw⟩:=data w ws
  have dv:=spent fv xv (endOff v vs) (isolated v vs)
  have dw:=spent fw xw (endOff w ws) (isolated w ws)
  have notEq : tag v≠tag w:=fun eq=>ne (inj v vs w ws eq)
  exact Finset.one_lt_card.mpr ⟨tag v,Finset.mem_inter.mpr ⟨iv,dv⟩,
    tag w,Finset.mem_inter.mpr ⟨iw,dw⟩,notEq⟩

#print axioms isolated_needs_two
end ExactWordFlow.WheelBaseExits

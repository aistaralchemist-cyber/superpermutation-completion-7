import RunCollision
import SpliceSides

set_option maxHeartbeats 2400000
namespace ExactWordFlow.RunCollision
open SevenWordWindows

def states (p : Block) := ((List.range 6).map (atPhase p)).toFinset

private def shape (p : Block) (i : Nat) (swap : Bool) :=
  let left:=p.take 1
  let right:=p.drop 6
  let mid:=(p.drop 1 |>.take 5).rotate i
  if swap then right++mid++left else left++mid++right

/-- All ten possible orderings keep the cyclic order of the middle
five letters and can only exchange the two end letters. -/
def possibleStarts (p : Block) :=
  (((List.range 5).map fun i=>shape p i false)++
    ((List.range 5).map fun i=>shape p i true)).toFinset

/-- All rotation classes encountered by blocks with the same five-letter
cyclic order. There are exactly thirty such classes. -/
def pool (p : Block) := (possibleStarts p).biUnion footprint

/-- The vertex skipped on a cost-three bac jump just before its destination. -/
def beforeBac (p : Block) :=
  let q:=atPhase p 5
  q.drop 2 ++ [q[1]?.getD 0,q[0]?.getD 0]

private theorem concrete : ∀p∈representatives,
    (atPhase p 5).rotate 1 ∈ states (next p .acb) ∧
    (beforeBac p).rotate 6 ∈ states p ∧
    states p=states (next p .bca) ∧ (states p).Nonempty ∧
    p∈possibleStarts p ∧ (possibleStarts p).card=10 ∧
    (pool p).card=30 ∧
    (∀j∈[Jump.cab,.cba],next p j∈representatives ∧
      possibleStarts (next p j)=possibleStarts p) := by native_decide

/-- The simple three-rotation skip was excluded by interpolation.
A skipped ordinary successor on acb requires that state to have an
ordinary outgoing edge at its selected position, hence be fixed by h.
The symmetric argument applies to the predecessor of the skipped
state on bac. Distinct full blocks contain only moved states. -/
theorem paid_options {p : Block} (hp : p∈representatives) (j : Jump)
    (interpolated : j ≠ .abc)
    (outbound : j=.acb → (atPhase p 5).rotate 1 ∉ states (next p j))
    (inbound : j=.bac → (beforeBac p).rotate 6 ∉ states p)
    (distinct : Disjoint (states p) (states (next p j))) : j=.cab ∨ j=.cba := by
  obtain ⟨acb,bac,bca,ne,_⟩:=concrete p hp
  cases j with
  | abc => exact False.elim (interpolated rfl)
  | acb => exact False.elim (outbound rfl acb)
  | bac => exact False.elim (inbound rfl bac)
  | bca =>
    obtain ⟨v,hv⟩:=ne
    exact False.elim (Finset.disjoint_left.mp distinct hv (bca ▸ hv))
  | cab => exact Or.inl rfl
  | cba => exact Or.inr rfl

private theorem union_mapped {A B C : Type*} [DecidableEq B] [DecidableEq C]
    (I : Finset A) (f : A→B) (F : B→Finset C) (S : Finset B) (good : I.image f ⊆ S) :
    (I.biUnion fun i=>F (f i)).card ≤ (S.biUnion F).card := by
  apply Finset.card_le_card
  exact Finset.biUnion_subset_iff_forall_subset.mpr (fun i hi=>
    Finset.subset_biUnion_of_mem F (good (Finset.mem_image_of_mem f hi)))

/-- Simultaneous bounds on literal starting permutations and rotation
tags of an arbitrarily long canonical homogeneous run. The states of
each block are accounted for even when different blocks share tags. -/
theorem run_pool {p : Block} (hp : p∈representatives) (v : Nat → Block)
    (n : Nat) (start : v 0=p)
    (advances : ∀i<n,∃j∈[Jump.cab,.cba],v (i+1)=next (v i) j) :
    ((Finset.range (n+1)).image v).card≤10 ∧
    ((Finset.range (n+1)).biUnion fun i=>footprint (v i)).card≤30 := by
  have same : ∀i≤n,v i∈representatives ∧ possibleStarts (v i)=possibleStarts p := by
    intro i
    induction i with
    | zero => intro _; simpa [start] using hp
    | succ i ih =>
      intro small
      obtain ⟨good,prev⟩:=ih (by omega)
      obtain ⟨j,hj,eq⟩:=advances i (by omega)
      obtain ⟨rep,step⟩:=(concrete _ good).2.2.2.2.2.2.2 j hj
      exact ⟨eq ▸ rep,eq ▸ step.trans prev⟩
  have boundStarts : (Finset.range (n+1)).image v ⊆ possibleStarts p := by
    intro x hx
    obtain ⟨i,hi,rfl⟩:=Finset.mem_image.mp hx
    obtain ⟨good,eq⟩:=same i (by have := Finset.mem_range.mp hi; omega)
    exact eq ▸ (concrete _ good).2.2.2.2.1
  have boundTags := union_mapped (Finset.range (n+1)) v footprint (possibleStarts p) boundStarts
  have cap : ((possibleStarts p).biUnion footprint).card=30 := (concrete p hp).2.2.2.2.2.2.1
  exact ⟨(Finset.card_le_card boundStarts).trans_eq (concrete p hp).2.2.2.2.2.1,boundTags.trans_eq cap⟩

/-- Aggregated, disjoint homogeneous runs incur at most the shared
incidence budget. At genus seven every candidate is at the upper
length boundary, has one exceptional cycle, and loses at most two
paid points over all breaks plus the deficit of the free block. -/
theorem genus_profile {k s g e p loss : Nat} (budget : k + s + 2*g ≤ 140) (nonempty : 1 ≤ e)
    (cycles : e ≤ k) (gain : 719 + 12*g + 6*(e-1) + loss ≤ p + 5*(k+s+2*g))
    (pools : 6*p ≤ 30*(s+e-p) + 2*g) (many : p ≤ s+e) :
    g ≤ 7 ∧ (g=7 → k+s+2*g=140 ∧ e=1 ∧ k ≤ 3 ∧ loss+k ≤ 3) := by
  omega

#print axioms paid_options
#print axioms run_pool
#print axioms genus_profile
end ExactWordFlow.RunCollision

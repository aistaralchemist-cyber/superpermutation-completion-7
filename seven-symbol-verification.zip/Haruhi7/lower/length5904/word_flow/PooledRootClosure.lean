import SharedRootForcing
import GenusFamily

namespace ExactWordFlow.MultipleRootContacts
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- Pool all the exceptional cycles into one set of anchors. A wheel with
two anchors may hit distinct disconnected exceptional cycles. The price
of forgetting all component distinctions is at most e−1. -/
theorem pooled_wheels {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (E W : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (nonempty : E.Nonempty)
    (wheels : W⊆h.cycleFactorsFinset) (apart : Disjoint E W)
    (six : ∀w∈W,w.support.card=6)
    (two : ∀w∈W,2≤(w.support.image tag ∩ E.biUnion (fun c=>c.support.image tag)).card) :
    let U:=E.biUnion fun c=>c.support.image tag
    let D:=W.biUnion fun w=>w.support.image tag \ U
    (∑c∈E,c.support.card)+W.card+1≤U.card+E.card+2*g ∧ D.card≤4*W.card := by
  classical
  let T (c : Perm X):=c.support.image tag
  let U:=E.biUnion T
  let D:=W.biUnion fun w=>T w \ U
  have cap:=PermutationGenus.family_budget start oneOrbit tag onto rot classes genus (E∪W)
    (Finset.union_subset known wheels) (nonempty.mono Finset.subset_union_left)
  have four (w) (hw : w∈W) : (T w \ U).card≤4:=by
    have same : T w \ U=T w \ (T w∩U) := by ext j; simp
    have lower:=two w hw
    have bound : (T w).card≤6:=(Finset.card_image_le (f:=tag)).trans (le_of_eq (six w hw))
    rw [same,Finset.card_sdiff_of_subset Finset.inter_subset_left]
    change 2≤(T w∩U).card at lower
    omega
  have countD:D.card≤4*W.card:=by
    have sum:=Finset.sum_le_card_nsmul W (fun w=>(T w \ U).card) 4 four
    simp only [smul_eq_mul] at sum
    exact Finset.card_biUnion_le.trans (by simpa only [Nat.mul_comm] using sum)
  have incl : (E∪W).biUnion T ⊆ U∪D:=by
    intro j hj
    obtain ⟨c,hc,hit⟩:=Finset.mem_biUnion.mp hj
    rcases Finset.mem_union.mp hc with he|hw
    · exact Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨c,he,hit⟩)
    · by_cases hu : j∈U
      · exact Finset.mem_union_left _ hu
      · exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨c,hw,Finset.mem_sdiff.mpr ⟨hit,hu⟩⟩)
  have unionSize:=(Finset.card_le_card incl).trans (Finset.card_union_le U D)
  have positive (c) (hc : c∈E) : 0<c.support.card:=by
    obtain ⟨x,hx,_⟩:=(Perm.mem_cycleFactorsFinset_iff.mp (known hc)).1
    exact Finset.card_pos.mpr ⟨x,Perm.mem_support.mpr hx⟩
  have mass : (∑c∈E,(c.support.card-1))+E.card=∑c∈E,c.support.card:=by
    have each : (∑c∈E,(c.support.card-1+1))=∑c∈E,c.support.card:=by
      apply Finset.sum_congr rfl
      intro c hc
      have pos:=positive c hc
      omega
    simpa only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] using each
  have gears : (∑c∈W,(c.support.card-1))=5*W.card:=by
    calc
      _ = ∑_∈W,5:=Finset.sum_congr rfl (fun w hw=>by rw [six w hw])
      _ = _:=by simp [Nat.mul_comm]
  have pos : 0<((E∪W).biUnion T).card:=by
    obtain ⟨c,hc⟩:=nonempty
    obtain ⟨x,hx⟩:=Finset.card_pos.mp (positive c hc)
    exact Finset.card_pos.mpr ⟨tag x,Finset.mem_biUnion.mpr ⟨c,Finset.mem_union_left _ hc,
      Finset.mem_image_of_mem _ hx⟩⟩
  rw [Finset.sum_union apart,gears] at cap
  change (∑c∈E,(c.support.card-1))+5*W.card≤((E∪W).biUnion T).card-1+2*g at cap
  change (∑c∈E,c.support.card)+W.card+1≤U.card+E.card+2*g ∧ D.card≤4*W.card
  exact ⟨by omega, countD⟩

#print axioms pooled_wheels
end ExactWordFlow.MultipleRootContacts

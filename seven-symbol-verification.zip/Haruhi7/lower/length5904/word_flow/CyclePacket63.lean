import Cycle17

namespace ExactWordFlow.CyclePacket63
open ResidualDensity EmbeddedWheels DirectedEuler OnePath66 OnePath66.Packet64

private theorem curve {u : Block} {p : List Block} (d : Block) (cycle : Route src dst u p u)
    (ne : p≠[]) : labels d u p=(p.map (project d ∘ src)).toFinset := by
  have first : u∈p.map src := by
    cases cycle with
    | nil => contradiction
    | cons e hh _ => simp [hh]
  have inList : project d u∈(p.map (project d ∘ src)).toFinset := by
    simpa [List.map_map] using List.mem_map_of_mem (f:=project d) first
  unfold labels
  rw [←source_list cycle,List.map_append,List.map_map]
  simp [inList]

theorem packet_bound {a b d u : Block} {es ws p : List Block} {F : Multiset Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (hd : d∈pathClasses a es)
    (cycle : Route src dst u p u) (nonempty : p≠[])
    (together : RequiredComponent.ClassesTogether (((↑es : Multiset Block)+turns ws)+(↑p+F))) :
    720≤classCount a es+5*ws.length+((p.map (project d ∘ src)).toFinset.card-1)+F.card := by
  let B := labels d u p
  have ends (e : Block) (he : e∈p) : project d (src e)∈B ∧ project d (dst e)∈B := by
    have sv : src e∈u::p.map dst := source_list cycle ▸ List.mem_append_left _ (List.mem_map_of_mem he)
    have dv : dst e∈u::p.map dst := List.mem_cons_of_mem _ (List.mem_map_of_mem he)
    exact ⟨List.mem_toFinset.mpr (List.mem_map_of_mem sv),List.mem_toFinset.mpr (List.mem_map_of_mem dv)⟩
  have rank := packet_rank r legit hd _ B (Finset.Subset.refl _) (↑p) F (fun e he => Or.inr (ends e he)) together
  simpa only [B,curve d cycle nonempty,classCount,pathClasses] using rank

theorem nonwheel_loss {u : Block} {p : List Block} (d : Block) (cycle : Route src dst u p u)
    (ww : ∀e∈p,e.length=7) (two : 2≤p.length) (twelve : p.length≤12)
    (noWheel : ¬(full u ∧ p=GlobalWheelRank.wheel u)) : (p.map (project d ∘ src)).toFinset.card<p.length := by
  by_contra! ge
  let m : Multiset Block := ↑(p.map (project d ∘ src))
  have eq : m.toFinset.card=m.card :=
    le_antisymm (Multiset.toFinset_card_le _) (by simpa [m] using ge)
  have nd := Multiset.coe_nodup.mp (Multiset.toFinset_card_eq_card_iff_nodup.mp eq)
  exact noWheel (ShortFreshCycle.tight_cycle_twelve d cycle ww two twelve nd)

theorem inefficient {u : Block} {p : List Block} (d : Block) (cycle : Route src dst u p u)
    (ww : ∀e∈p,e.length=7) (ne : p≠[]) (two : 2≤p.length) (small : p.length≤17)
    (near : p.length≤(p.map (project d ∘ src)).toFinset.card+1) (noWheel : ¬(full u ∧ p=GlobalWheelRank.wheel u)) :
    p.length≤12 ∧ (p.map (project d ∘ src)).toFinset.card<p.length := by
  have twelve := ShortFreshCycle.one_loss_short d cycle ww ne small near
  exact ⟨twelve,nonwheel_loss d cycle ww two twelve noWheel⟩

#print axioms packet_bound
#print axioms inefficient
end ExactWordFlow.CyclePacket63

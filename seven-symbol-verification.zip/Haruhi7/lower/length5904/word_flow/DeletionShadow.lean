import CoreCounts

namespace ExactWordFlow.DeletionShadow
open SevenWordWindows RotationCore

def erase (a : Fin 7) (w : Block) : Block := w.filter (· != a)
def sixWindows : Block → List Block
  | [] => []
  | x::xs => if 5≤xs.length then (x::xs.take 5)::sixWindows xs else sixWindows xs

private def kept (a : Fin 7) (w : Block) :=
  (windows w).filter fun e=>decide (e.Nodup ∧ e.head?≠some a)

private theorem six_tail (x : Fin 7) (xs : Block) : List.Sublist (sixWindows xs) (sixWindows (x::xs)) := by
  rw [sixWindows]; split
  · exact List.Sublist.cons _ (List.Sublist.refl _)
  · rfl

private theorem erase_six (a : Fin 7) (p : Block) (hp : p∈representatives) : (erase a p).length=6 := by
  have perm:=List.mem_permutations.mp hp
  have present:=perm.mem_iff.mpr (List.mem_finRange a)
  rw [erase,←((mem_reps _).mp hp).2.erase_eq_filter,List.length_erase_of_mem present,((mem_reps _).mp hp).1]

/-- The surviving first letter anchors each trace to its own projected position.
This avoids double counting at an erased letter on the boundary of a window. -/
private theorem trace (a : Fin 7) (w : Block) : List.Sublist ((kept a w).map (erase a)) (sixWindows (erase a w)) := by
  induction w with
  | nil => simp [kept,windows,erase,sixWindows]
  | cons x xs ih =>
    by_cases wide : 6≤xs.length
    · let e:=x::xs.take 6
      have left : kept a (x::xs)=(if e.Nodup ∧ x≠a then e::kept a xs else kept a xs) := by
        simp [kept,windows,wide,e,List.filter_cons]
      rw [left]
      by_cases ha : x=a
      · subst x
        simpa [erase] using ih
      · have er : erase a (x::xs)=x::erase a xs := by simp [erase,ha]
        rw [er]
        by_cases clean : e.Nodup
        · rw [ite_eq_left ⟨clean,ha⟩,List.map_cons]
          have hr : e∈representatives := (mem_reps e).mpr ⟨by simp [e,wide],clean⟩
          have len:=erase_six a e hr
          have split : erase a (x::xs)=erase a e++erase a (xs.drop 6) := by
            unfold erase
            rw [←List.filter_append]
            simp [e]
          have wide' : 5≤(erase a xs).length := by
            have le:=congrArg List.length (er.symm.trans split)
            simp [len] at le
            omega
          have eq : x::(erase a xs).take 5=erase a e := by
            have le:=congrArg (List.take 6) (er.symm.trans split)
            simpa only [List.take_succ_cons,List.take_left' len] using le
          rw [sixWindows,ite_eq_left wide',eq]
          exact List.Sublist.cons_cons _ ih
        · simpa only [clean,false_and,ite_false] using ih.trans (six_tail x (erase a xs))
    · have no : windows (x::xs)=[] := by simp [windows,wide]
      simp [kept,no]

def proj (a : Fin 7) (c : Block) :=
  let z:=erase a c
  z.rotate (z.idxOf (if a=0 then 1 else 0))
def board6 (a : Fin 7) := allClasses.image (proj a)
def turns (d : Block) := (List.range 6).map fun i=>d.rotate i
private def startAt (c p : Block) := c.rotate (c.idxOf (p.headD 0))

private def liftCheck : Bool := (List.finRange 7).all fun a=> (allClasses.sort (· ≤ ·)).all fun c=>
  (turns (proj a c)).all fun p=>
    let e:=startAt c p
    decide (e.length=7 ∧ e.Nodup ∧ classKey e=c ∧ e.head?≠some a ∧ erase a e=p)
private theorem liftData : liftCheck=true := by native_decide

private theorem lift_phase {a : Fin 7} {c p : Block} (hc : c∈allClasses) (hp : p∈turns (proj a c)) :
    startAt c p∈representatives ∧ classKey (startAt c p)=c ∧
    (startAt c p).head?≠some a ∧ erase a (startAt c p)=p := by
  have ⟨l,n,k,h,e⟩:=of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp
    (List.all_eq_true.mp liftData a (List.mem_finRange _)) c (by simpa using hc)) p hp)
  exact ⟨(mem_reps _).mpr ⟨l,n⟩,k,h,e⟩

def loads (a : Fin 7) (w d : Block) := (complete w).filter (fun c=>proj a c=d)

theorem multiplicity (a : Fin 7) (w d p : Block) (hp : p∈turns d) :
    (loads a w d).card≤(sixWindows (erase a w)).count p := by
  let T:=loads a w d
  let F (c : Block):=startAt c p
  have step (c) (h : c∈T) :
      F c∈representatives ∧ classKey (F c)=c ∧ (F c).head?≠some a ∧ erase a (F c)=p := by
    obtain ⟨hc,hd⟩:=Finset.mem_filter.mp h
    exact lift_phase ((mem_complete w c).mp hc).1 (hd.symm ▸ hp)
  have injective : Set.InjOn F T := fun c hc b hb eq=> (step c hc).2.1.symm.trans
    ((congrArg classKey eq).trans (step b hb).2.1)
  let R:=T.image F
  have sub : R.val ≤ (kept a w : Multiset Block) := by
    apply (Multiset.le_iff_subset R.nodup).mpr
    intro e he
    obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp (show e∈R from he)
    obtain ⟨legal,key,first,_⟩:=step c hc
    have hits:=((mem_complete w c).mp (Finset.mem_filter.mp hc).1).2 _ legal key
    exact List.mem_filter.mpr ⟨hits,decide_eq_true ⟨((mem_reps _).mp legal).2,first⟩⟩
  have same : R.val.map (erase a)=R.val.map (fun _=>p) := by
    apply Multiset.map_congr rfl
    intro e he
    obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp (show e∈R from he)
    exact (step c hc).2.2.2
  have amount:=Multiset.count_le_of_le p (Multiset.map_le_map (f:=erase a) sub)
  rw [same] at amount
  have card : R.card=T.card:=Finset.card_image_of_injOn injective
  have small : T.card≤((kept a w).map (erase a)).count p := by
    simpa [Multiset.map_const',card,List.count_eq_countP,Bool.beq_eq_decide_eq] using amount
  exact small.trans ((trace a w).count_le p)

private def capCheck : Bool := (List.finRange 7).all fun a=>
  ((board6 a).sort (· ≤ ·)).all fun d=> ((allClasses.filter (fun c=>proj a c=d)).card == 6)
private theorem capData : capCheck=true := by native_decide

private theorem six_lifts {a : Fin 7} {d : Block} (hd : d∈board6 a) :
    (allClasses.filter (fun c=>proj a c=d)).card=6 :=
  eq_of_beq (List.all_eq_true.mp (List.all_eq_true.mp capData a (List.mem_finRange _)) d (by simpa using hd))

private def capacityOn (words : List Block) (d : Block) : Nat :=
  (turns d).foldl (fun acc p=>min acc (words.count p)) 6

def capacity (a : Fin 7) (w d : Block) : Nat := capacityOn (sixWindows (erase a w)) d

def upper (a : Fin 7) (w : Block) : Nat :=
  let words:=sixWindows (erase a w)
  ∑d∈board6 a,capacityOn words d

theorem load_bound (a : Fin 7) (w d : Block) (hd : d∈board6 a) : (loads a w d).card≤capacity a w d := by
  have sub : loads a w d⊆allClasses.filter (fun c=>proj a c=d) := by
    intro c hc
    obtain ⟨h,e⟩:=Finset.mem_filter.mp hc
    exact Finset.mem_filter.mpr ⟨((mem_complete _ _).mp h).1,e⟩
  have lim:=Finset.card_le_card sub
  rw [six_lifts hd] at lim
  suffices aux : ∀(ps : List Block) (n : Nat),(loads a w d).card≤n →
      (∀p∈ps,(loads a w d).card≤(sixWindows (erase a w)).count p) →
      (loads a w d).card≤ps.foldl (fun t p=>min t ((sixWindows (erase a w)).count p)) n from
    aux _ _ lim (fun p hp=>multiplicity a w d p hp)
  intro ps
  induction ps with
  | nil => simp
  | cons p ps ih =>
    intro n hn all
    exact ih _ (le_min hn (all _ List.mem_cons_self)) (fun z hz=>all _ (List.mem_cons_of_mem _ hz))


theorem bound (a : Fin 7) (w : Block) : (complete w).card≤upper a w := by
  have member {c} (hc:c∈complete w) : proj a c∈board6 a:=
    Finset.mem_image_of_mem _ ((mem_complete _ _).mp hc).1
  rw [Finset.card_eq_sum_card_fiberwise (f:=proj a) (t:=board6 a) (fun _ h=>member h)]
  exact Finset.sum_le_sum (fun d hd=>load_bound a w d hd)

/-- A class whose projected rotations are absent for even one erased symbol
cannot occur in a simultaneous packing. -/
def eligible (w : Block) := allClasses.filter fun c=>∀a : Fin 7,0<capacity a w (proj a c)

theorem within_eligible (w : Block) : complete w⊆eligible w := by
  intro c hc
  have board:=((mem_complete _ _).mp hc).1
  refine Finset.mem_filter.mpr ⟨board,?_⟩
  intro a
  have positive:=Finset.card_pos.mpr (show (loads a w (proj a c)).Nonempty from
    ⟨c,Finset.mem_filter.mpr ⟨hc,rfl⟩⟩)
  exact positive.trans_le (load_bound a w _ (Finset.mem_image_of_mem _ board))

theorem simultaneous {w : Block} {k : Nat} (many : k≤(complete w).card) :
    ∃T : Finset Block,T⊆eligible w ∧ T.card=k ∧ ∀(a : Fin 7) (d : Block),d∈board6 a →
      (T.filter (fun c=>proj a c=d)).card≤capacity a w d := by
  obtain ⟨T,sub,sz⟩:=Finset.exists_subset_card_eq many
  exact ⟨T,sub.trans (within_eligible w),sz,fun a d hd=>
    (Finset.card_le_card (Finset.filter_subset_filter _ sub)).trans (load_bound a w d hd)⟩

#print axioms simultaneous
#print axioms bound
end ExactWordFlow.DeletionShadow

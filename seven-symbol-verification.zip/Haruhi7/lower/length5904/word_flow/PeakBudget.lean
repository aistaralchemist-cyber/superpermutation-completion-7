import SaturatedPool
import ZeroBlock

namespace ExactWordFlow.RunCollision
open SevenWordWindows

private theorem trailing_geometry : ∀p∈representatives,
    (next p .bca)∈states p ∧ ∀j∈[Jump.acb,.cab,.cba], footprint (next p j)⊆pool p := by
  native_decide

/-- Even if the next block is short, its first state is new. The bac
jump would make the required ordinary skipped-slot predecessor moved.
The bca jump would repeat a state of the whole preceding block. -/
theorem next_in_pool {p : Block} (legal : p∈representatives) (j : Jump)
    (interpolated : j ≠ .abc)
    (inbound : j=.bac → (beforeBac p).rotate 6 ∉ states p)
    (fresh : next p j ∉ states p) :
    footprint (next p j)⊆pool p := by
  have bac : (beforeBac p).rotate 6∈states p := by
    have table : ∀q∈representatives,(beforeBac q).rotate 6∈states q := by native_decide
    exact table p legal
  obtain ⟨bca,yes⟩:=trailing_geometry p legal
  cases j with
  | abc => exact False.elim (interpolated rfl)
  | bac => exact False.elim (inbound rfl bac)
  | bca => exact False.elim (fresh bca)
  | acb => exact yes _ (by simp)
  | cab => exact yes _ (by simp)
  | cba => exact yes _ (by simp)

/-- Two intervening zero blocks: all six choices of each jump are permitted. -/
theorem double_zero : ∀p∈representatives,∀q∈costThree (atPhase p 5),
    ∀t∈costThree (atPhase q 4),∀u∈costThree (atPhase t 4),
    (((phaseTags p 5 ∪ phaseTags q 4) ∪ phaseTags t 4) ∪ phaseTags u 5).card ≤ 18 := by
  native_decide

/-- Duplicate-tag defect is supermodular on position sets. In particular
overlapping at one injectively tagged block does not compromise additivity. -/
theorem defect_overlap {A B : Type*} [DecidableEq A] [DecidableEq B]
    (s t : Finset A) (tag : A→B)
    (overlap : (s∩t).card=((s∩t).image tag).card) :
    s.card-(s.image tag).card+(t.card-(t.image tag).card)
      ≤ (s∪t).card-((s∪t).image tag).card := by
  classical
  have pos₁ : (s.image tag).card ≤ s.card := Finset.card_image_le
  have pos₂ : (t.image tag).card ≤ t.card := Finset.card_image_le
  have card := Finset.card_union_add_card_inter s t
  have imgs := Finset.card_union_add_card_inter (s.image tag) (t.image tag)
  have sub : (s∩t).image tag ⊆ s.image tag ∩ t.image tag := by
    intro j hj
    obtain ⟨x,mem,rfl⟩:=Finset.mem_image.mp hj
    obtain ⟨left,right⟩:=Finset.mem_inter.mp mem
    exact Finset.mem_inter.mpr ⟨Finset.mem_image_of_mem _ left,Finset.mem_image_of_mem _ right⟩
  have lim := Finset.card_le_card sub
  rw [Finset.image_union]
  omega

/-- The genus arithmetic uses three separately necessary consequences
of the same incidence budget, without adding the budgets to each other.
The runs are maximal consecutive paid five-neutral cost-three blocks. -/
theorem canonical_profile {k s g e p loss runs closed : Nat}
    (budget : k + s + 2*g ≤ 140) (nonempty : 1 ≤ e) (cycles : e ≤ k)
    (gain : 719 + 12*g + 6*(e-1) + loss ≤ p + 5*(k+s+2*g))
    (regions : p + runs ≤ s+e) (noFree : closed+1 ≤ e) (inside : closed ≤ runs)
    (extended : 6*p+5*(runs-closed) ≤ 30*runs+loss+2*g)
    (gaps : runs ≤ loss+e+g) (poolBound : 6*p ≤ 30*runs+2*g) :
    g ≤ 5 ∧ 420*g+156*e+30*loss+25*k ≤ 3092 := by omega

#print axioms next_in_pool
#print axioms double_zero
#print axioms defect_overlap
#print axioms canonical_profile
end ExactWordFlow.RunCollision

import FixedSeed250

namespace ExactWordFlow.EndTrim94
open SevenWordWindows RotationCore ExtremeWheelCut

def path : Block := "012345012435012453012450312450132451032451302451320451230451203451204351204531205431205341205314205134205143205142305142035140235140325140352140532140523140521340521430524130542130541230541320541302541032541023541025341025431024531024351024315024135024153024150324150234152034152304152340152341052341".toList.map (fun c=>Fin.ofNat 7 (c.toNat-'0'.toNat))

/-- A genuine 294-edge root where removing the first or the last six edges
fails to give both 245 remaining labels and a one-wheel extension at once. -/
theorem profile : path.length=300 ∧ (visited path).card=250 ∧
    (visited (path.drop 6)).card=245 ∧ (visited (path.take 294)).card=244 ∧
    ¬∃u∈allRows,visited (path.drop 6)∪u=visited path := by native_decide

#print axioms profile
end ExactWordFlow.EndTrim94

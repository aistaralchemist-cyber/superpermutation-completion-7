import ResidualControls
import Dense462
import CompatibleWheelExample

/-! Five arbitrary letters at the two ends cannot buy five new classes
for any of three concrete backbones. One of the two ends has at least
three letters. Its nearest triple already loses at least one class. -/
namespace ExactWordFlow.FiveExtensionCaps
open ResidualDensity SevenWordWindows ResidualControls

def extension_classes (w : Block) := touched (vertices w)

private def heads : Block → Block → List Block
  | [], _ => []
  | a::p, v => ((a::p)++v).take 6 :: heads p v

private theorem heads_len (u v : Block) : (heads u v).length=u.length := by
  induction u with
  | nil => rfl
  | cons a u ih => simp [heads,ih]

private theorem truncate (u v : Block) : (u++v.take 6).take 6=(u++v).take 6 := by
  rw [List.take_append,List.take_append,List.take_take, Nat.min_eq_left (by omega)]

private theorem heads_take (u v : Block) : heads u (v.take 6)=heads u v := by
  induction u with
  | nil => rfl
  | cons a u ih => simp only [heads,truncate,ih]

private theorem vertex_cons (a : Fin 7) (w : Block) (long : 6≤w.length) :
    vertices (a::w) = (a::w).take 6 :: vertices w := by
  simp [vertices,windows,long,dst]

private theorem split (u v : Block) (long : 6≤v.length) :
    vertices (u++v) = heads u v ++ vertices v := by
  induction u with
  | nil => rfl
  | cons a u ih =>
    change vertices (a::(u++v)) = _
    rw [vertex_cons _ _ (by simp; omega),ih]
    rfl

private theorem boundaries (p w q : Block) (long : 6≤w.length) :
    vertices (p++w++q) =
    heads p (w.take 6) ++ vertices w ++ (windows (w.drop (w.length-6)++q)).map dst := by
  let m := w.take (w.length-6)
  let z := w.drop (w.length-6)
  have dec : m++z=w := List.take_append_drop .. 
  have six : z.length=6 := by simp [z]; omega
  have first : (w++q).take 6=w.take 6 := List.take_append_of_le_length long
  have eql : heads p (w++q)=heads p (w.take 6) := by rw [←heads_take p (w++q),first]
  have eqr : heads m (z++q)=heads m z := by
    rw [←heads_take m (z++q),List.take_left' six]
  have p1 := split m (z++q) (by simp [six])
  have p2 := split m z (by omega)
  have empty : windows z=[] := List.eq_nil_of_length_eq_zero (by rw [windows_length,six])
  have endOld : vertices z=[z] := by simp [vertices,empty,List.take_of_length_le six.le]
  have endNew : vertices (z++q) = z :: (windows (z++q)).map dst := by rw [vertices,List.take_left' six]
  rw [List.append_assoc,split p _ (by simp; omega),eql]
  rw [←List.append_assoc,dec] at p1
  rw [eqr,endNew] at p1
  rw [dec,endOld] at p2
  rw [p1,p2]
  simp [List.append_assoc,z]

private theorem touched_append (u v : List Block) : touched (u++v)=touched u∪touched v := by
  simp [touched,List.filter_append]

private theorem touched_size (u : List Block) : (touched u).card≤u.length := by
  exact (List.toFinset_card_le _).trans (by simp; exact List.length_filter_le ..)

/-- Each letter added outside an unchanged backbone can contribute at most
one new clean six-state observation. -/
theorem extension_cost (p w q : Block) (long : 6≤w.length) :
    (extension_classes (p++w++q)).card≤(extension_classes w).card+p.length+q.length := by
  unfold extension_classes
  rw [boundaries p w q long,touched_append,touched_append]
  let L := heads p (w.take 6)
  let R := (windows (w.drop (w.length-6)++q)).map dst
  have l := touched_size L
  have r := touched_size R
  have nl : L.length=p.length := heads_len .. 
  have nr : R.length=q.length := by simp [R,windows_length]; omega
  have a := Finset.card_union_le (touched L) (touched (vertices w))
  have b := Finset.card_union_le (touched L∪touched (vertices w)) (touched R)
  change ((touched L∪touched (vertices w))∪touched R).card≤_
  omega

private def triples : List Block := (List.finRange 7).flatMap fun a =>
  (List.finRange 7).flatMap fun b => (List.finRange 7).map fun c => [a,b,c]

private theorem mem_triples {p : Block} (size : p.length=3) : p∈triples := by
  rcases p with _|⟨a,_|⟨b,_|⟨c,_|⟨d,ds⟩⟩⟩⟩ <;> simp_all [triples,List.mem_finRange]

private def tripleCheck (w : Block) : Bool :=
  let A := extension_classes w
  let l := w.take 6
  let r := w.drop (w.length-6)
  triples.all fun x =>
    decide ((touched (heads x l) \ A).card≤2 ∧
      (touched ((windows (r++x)).map dst) \ A).card≤2)

private theorem local_bounds {w p : Block} (long : 6≤w.length) (tab : tripleCheck w=true)
    (size : p.length=3) :
    (extension_classes (p++w)).card≤(extension_classes w).card+2 ∧
      (extension_classes (w++p)).card≤(extension_classes w).card+2 := by
  let A := extension_classes w
  let L := touched (heads p (w.take 6))
  let R := touched ((windows (w.drop (w.length-6)++p)).map dst)
  have caps : (L\A).card≤2 ∧ (R\A).card≤2 :=
    of_decide_eq_true (List.all_eq_true.mp tab _ (mem_triples size))
  have lf : extension_classes (p++w)=L∪A := by
    change touched (vertices (p++w))=_
    rw [split p w long,←heads_take p w,touched_append]
    rfl
  have rt : extension_classes (w++p)=A∪R := by
    change touched (vertices (w++p))=_
    have h := boundaries [] w p long
    simp only [List.nil_append,heads] at h
    rw [h,touched_append]
    rfl
  rw [lf,rt,Finset.union_comm A R]
  have card (S : Finset Block) : (S∪A).card=A.card+(S\A).card := by
    have h := Finset.card_sdiff_add_card_eq_card (Finset.subset_union_right (s₁:=S) (s₂:=A))
    have eq : (S∪A)\A=S\A := by ext v; simp; tauto
    rw [eq] at h
    simpa [Nat.add_comm] using h.symm
  rw [card,card]
  change A.card+(L\A).card≤A.card+2 ∧ A.card+(R\A).card≤A.card+2
  omega

private theorem bound {w : Block} (long : 6≤w.length) (tab : tripleCheck w=true)
    (pre post : Block) (five : pre.length+post.length=5) :
    (extension_classes (pre++w++post)).card≤(extension_classes w).card+4 := by
  by_cases left : 3≤pre.length
  · let x := pre.take (pre.length-3)
    let u := pre.drop (pre.length-3)
    have dec : x++u=pre := List.take_append_drop ..
    have n : u.length=3 := by simp [u]; omega
    have nx := congrArg List.length dec
    simp only [List.length_append] at nx
    have old := (local_bounds (w:=w) long tab n).1
    have add := extension_cost x (u++w) post (by simp; omega)
    rw [←List.append_assoc x u,dec] at add
    omega
  · let u := post.take 3
    let x := post.drop 3
    have dec : u++x=post := List.take_append_drop .. 
    have n : u.length=3 := by simp [u]; omega
    have nx := congrArg List.length dec
    simp only [List.length_append] at nx
    have old := (local_bounds (w:=w) long tab n).2
    have add := extension_cost pre (w++u) x (by simp; omega)
    simp only [List.append_assoc,dec] at add ⊢
    omega

private theorem boards : ∀w∈[Dense462.word,CompatibleWheelExample.raw,ResidualControls.mainWord],
    6≤w.length ∧ (extension_classes w).card=390 ∧ tripleCheck w=true := by native_decide

theorem caps {w : Block} (which : w∈[Dense462.word,CompatibleWheelExample.raw,ResidualControls.mainWord])
    (pre post : Block) (five : pre.length+post.length=5) :
    (extension_classes (pre++w++post)).card≤394 := by
  obtain ⟨long,old,tab⟩ := boards w which
  have lim := bound long tab pre post five
  omega

theorem reference_cap (pre post : Block) (five : pre.length+post.length=5) :
    (extension_classes (pre++ResidualControls.mainWord++post)).card<395 := by
  have lim := caps (w:=ResidualControls.mainWord) (by simp) pre post five
  omega

/-- The window ceiling 394 is attained at each backbone, including extensions
with dirty intermediate states. -/
theorem attained :
    (extension_classes (Dense462.word++[3,4,2,5,1])).card=394 ∧
    (extension_classes (CompatibleWheelExample.raw++[5,3,0,1,2])).card=394 ∧
    (extension_classes (ResidualControls.mainWord++[4,5,2,3,1])).card=394 := by native_decide

#print axioms reference_cap
#print axioms caps
#print axioms attained
end ExactWordFlow.FiveExtensionCaps

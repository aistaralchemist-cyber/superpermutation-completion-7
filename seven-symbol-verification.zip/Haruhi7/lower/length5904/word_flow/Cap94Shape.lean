import Cap94Prices

namespace ExactWordFlow.Cap94Shape
open SevenWordWindows ResidualDensity DirectedEuler ResidualRoutes ResidualIncidence RotationComponentCount GlobalDensity66
open scoped Classical
open private hits Cost totals rank_partition from NearHundredShape
open private initial from MarkedDensity
open private cyclic_cap closed_price from GlobalDensity66

private def penalty (k c : Nat) :=
  if k=6 then 0 else if k=35 ∧ c=30 then 1 else 2

private theorem price {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (q : Component X) (hq : q∈occupied X s) (small : Cost X q≤42) :
    6*(hits X s q-1)+penalty (Cost X q) (hits X s q) ≤ 5*Cost X q := by
  obtain ⟨away,_⟩:=Finset.mem_erase.mp hq
  have active : q∈RotationComponentCount.active X s := occupied_active h ▸ hq
  have low : 6≤Cost X q := (Finset.mem_filter.mp active).2.2
  obtain ⟨v,_,key⟩:=residual_clean h away (by change 0<Cost X q; omega)
  obtain ⟨a,b,es,eq,r,lv,ep⟩:=component_route h.balance v
  rw [key] at eq lv ep
  obtain ⟨aa,bb⟩:=ep.2 away
  subst a; subst b
  have len : es.length=Cost X q:=congrArg Multiset.card eq
  have wd (u) (hu : u∈es):=h.edges_seven u (in_part.mp (eq ▸ (show u∈(↑es : Multiset Block) from hu))).1
  have inc : hits X s q≤classCount v es:=contacts_bound _ lv r eq
  have base:=closed_price r wd (by omega)
  by_cases six : Cost X q=6
  · simp [penalty,six] at *; omega
  obtain ⟨u,I,walk,cyclic,cnt⟩:=closed_observations r wd (by omega)
  have avg:=cyclic_7 walk cyclic (by omega : 7≤es.length)
  rw [cnt,len] at avg
  have second (large : 40≤Cost X q) : 40*hits X s q≤34*Cost X q := by
    have z:=window_cyclic_bound cyclic (by omega : 40≤es.length) (fun i pp _ hh=>interval40 walk hh i)
    rw [cnt,len] at z
    omega
  have table : ∀k c : Fin 43,6<k.val → 7*c.val≤6*k.val →
      (40≤k.val → 40*c.val≤34*k.val) → 6*(c.val-1)+penalty k.val c.val≤5*k.val := by native_decide
  exact table ⟨Cost X q,by omega⟩ ⟨hits X s q,by omega⟩ (by change 6<Cost X q; omega)
    (by change 7*hits X s q≤6*Cost X q;omega) second

private def simple (k : Nat) := if k=259 then 220 else if k=272 then 231 else (38*(k+1)+66)/45

private theorem choices : ∀k : Fin 295,∀f : Fin 37,258≤k.val → k.val+f.val≤294 →
    719 ≤ simple k.val-1+(3290+6*f.val-(if 0<f.val then 6 else 0))/7 →
    (k.val=258 ∧ f.val=36) ∨ (k.val=265 ∧ f.val=29) ∨ (k.val=294 ∧ f.val=0) := by native_decide

private theorem frontier {k f a w : Nat} (lo : 258≤k) (mass : k+f≤294) (linear : 45*a≤38*(k+1)+66)
    (first : k=259 → a≤220) (next : k=272 → a≤231)
    (rank : 719≤a-1+w) (weight : 7*w+(if 0<f then 6 else 0)≤3290+6*f) :
    (k=258 ∧ f=36 ∧ a=220 ∧ w=500) ∨ (k=265 ∧ f=29 ∧ a=226 ∧ w=494) ∨
      (k=294 ∧ f=0 ∧ a=250 ∧ w=470) := by
  have upper : a ≤ simple k := by unfold simple; split <;> (first | omega | split <;> omega)
  have bill : w≤(3290+6*f-(if 0<f then 6 else 0))/7 := by
    by_cases z : 0<f <;> simp only [z,ite_true,ite_false] at * <;> omega
  have opt : 719 ≤ simple k-1+(3290+6*f-(if 0<f then 6 else 0))/7 := by omega
  have cases:=choices ⟨k,by omega⟩ ⟨f,by omega⟩ lo mass opt
  change (k=258 ∧ f=36) ∨ (k=265 ∧ f=29) ∨ (k=294 ∧ f=0) at cases
  rcases cases with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> simp at * <;> omega

private theorem bound260 : Cap95Marked.upper 260 initial≤220 := by native_decide
private theorem bound273 : Cap95Marked.upper 273 initial≤231 := by native_decide

set_option maxHeartbeats 1600000 in
/-- With 94 active nonroot components there are only two possible mass
partitions. The 35-edge branch necessarily has exactly 30 distinct labels. -/
theorem shape {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (cnt : (occupied X s).card=94) :
    X.card=858 ∧
    (((part X (label X s)).card=294 ∧ hits X s (label X s)=250 ∧
        ∀q∈occupied X s,(part X q).card=6) ∨
     ((part X (label X s)).card=265 ∧ hits X s (label X s)=226 ∧
        ∃q∈occupied X s,(part X q).card=35 ∧ hits X s q=30 ∧
        ∀o∈occupied X s,o≠q → (part X o).card=6)) := by
  classical
  let Q:=occupied X s
  let E:=∑q∈Q,(Cost X q-6)
  let R:=∑q∈Q,(hits X s q-1)
  let S:=∑q∈Q,penalty (Cost X q) (hits X s q)
  change Q.card=94 at cnt
  have nobig : large X s=∅ := by
    by_contra! big
    have c:=Cap94Prices.large_count h budget (MarkedComponentCap.component_prices h budget).1 big
    change Q.card≤93 at c
    omega
  have base:=(MarkedComponentCap.component_prices h budget).2 nobig
  change 258≤Cost X (label X s) at base
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len : es.length=Cost X (label X s):=congrArg Multiset.card bag
  have width (z) (inZ : z∈es):=h.edges_seven z (in_part.mp (bag ▸ (show z∈(↑es : Multiset Block) from inZ))).1
  have root : hits X s (label X s)≤classCount s es:=contacts_bound _ lv r bag
  obtain ⟨mass,weight⟩:=totals h
  change Cost X (label X s)+6*Q.card+E=X.card at mass
  change 7*R+(if 0<E then 6 else 0)≤35*Q.card+6*E at weight
  rw [cnt] at mass weight
  have rank:=rank_partition h
  change separateRank X s=(hits X s (label X s)-1)+R at rank
  have floor : 719≤ separateRank X s :=rank719 _ h (fun _ he=>on_edge he)
  have linear:=WeightedMarks.path_cap r width
  have cap (k : Nat) (eq : es.length=k) (uk : k+1≤289) : classCount s es≤Cap95Marked.upper (k+1) initial := by
    subst k; exact Cap95Marked.route_upper r width uk
  have f (eq : es.length=259) : classCount s es≤220 :=
    (cap 259 eq (by decide)).trans bound260
  have n (eq : es.length=272) : classCount s es≤231 :=
    (cap 272 eq (by decide)).trans bound273
  have cases:=frontier (k:=es.length) (f:=E) (a:=classCount s es) (w:=R)
    (by omega) (by omega) linear f n (by omega) weight
  have total := mass
  have each (q) (hq : q∈Q) : 6≤Cost X q ∧ Cost X q-6≤E := by
    have pos : q∈RotationComponentCount.active X s:=occupied_active h ▸ hq
    exact ⟨(Finset.mem_filter.mp pos).2.2,Finset.single_le_sum (s:=Q) (f:=fun q=>Cost X q-6) (fun _ _=>Nat.zero_le _) hq⟩
  have eSmall : E≤36 := by omega
  have pointwise (q) (hq : q∈Q) : 6*(hits X s q-1)+penalty (Cost X q) (hits X s q)≤5*(6+(Cost X q-6)) := by
    obtain ⟨yes,le⟩:=each q hq
    rw [show 6+(Cost X q-6)=Cost X q by omega]
    exact price h q hq (by omega)
  have combined:=Finset.sum_le_sum pointwise
  simp only [Nat.mul_add,Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_const,smul_eq_mul,cnt] at combined
  change 6*R+S≤94*(5*6)+5*E at combined
  have per (q) (hq : q∈Q) : penalty (Cost X q) (hits X s q)≤S :=
    Finset.single_le_sum (s:=Q) (f:=fun q=>penalty (Cost X q) (hits X s q)) (fun _ _=>Nat.zero_le _) hq
  have exists_nonzero (yes : 0<E) : ∃q∈Q,Cost X q≠6 := by
    by_contra! none
    have z : E=0:=Finset.sum_eq_zero (fun q hq=>by rw [none q hq];decide)
    omega
  change X.card=858 ∧ ((Cost X (label X s)=294 ∧ hits X s (label X s)=250 ∧ ∀q∈Q,Cost X q=6) ∨
    (Cost X (label X s)=265 ∧ hits X s (label X s)=226 ∧ ∃q∈Q,Cost X q=35 ∧ hits X s q=30 ∧
      ∀o∈Q,o≠q → Cost X o=6))
  rcases cases with ⟨k,e0,c,w⟩|⟨k,e0,c,w⟩|⟨k,e0,c,w⟩
  · obtain ⟨q,hq,notSix⟩:=exists_nonzero (by omega)
    have pp:=per q hq
    unfold penalty at pp
    split at pp <;> (first | contradiction | split at pp <;> omega)
  · obtain ⟨q,hq,notSix⟩:=exists_nonzero (by omega)
    have pp:=per q hq
    have wanted : Cost X q=35 ∧ hits X s q=30 := by
      unfold penalty at pp
      by_contra fail
      simp [notSix,fail] at pp
      omega
    have erase:=Finset.sum_erase_add (s:=Q) (f:=fun z=>Cost X z-6) hq
    change (∑z∈Q.erase q,(Cost X z-6))+(Cost X q-6)=E at erase
    refine ⟨by omega,Or.inr ⟨by omega,by omega,q,hq,wanted.1,wanted.2,?_⟩⟩
    intro o ho ne
    have sm:=Finset.single_le_sum (s:=Q.erase q) (f:=fun z=>Cost X z-6) (fun _ _=>Nat.zero_le _) (Finset.mem_erase.mpr ⟨ne,ho⟩)
    have large:=(each o ho).1
    have own:=wanted.1
    change Cost X o=6
    omega
  · refine ⟨by omega,Or.inl ⟨by omega,by omega,?_⟩⟩
    intro q hq
    have all:=each q hq
    change Cost X q=6
    omega

#print axioms shape
end ExactWordFlow.Cap94Shape

import PlacementRows

namespace ExactWordFlow.PlacementCertificate
open SevenWordWindows SuperpermutationBounds Std.Sat

def negative : Schema → List Nat
  | .required _ => []
  | .conflict r i _ s j _ => [var r i,var s j]

def conflictCount : List Schema → Nat
  | [] => 0
  | .required _ :: ss => conflictCount ss
  | .conflict .. :: ss => conflictCount ss + 1

private def withTrue (v : Nat → Bool) (u x : Nat) : Bool := (x == u) || v x

private theorem required_more (v : Nat → Bool) (u r : Nat)
    (h : (clause (.required r)).eval v=true) :
    (clause (.required r)).eval (withTrue v u)=true := by
  unfold clause CNF.Clause.eval at h ⊢
  rw [CNF.Clause.literals_ofLiterals,List.any_eq_true] at h ⊢
  obtain ⟨_,mem,on⟩ := h
  obtain ⟨i,hi,rfl⟩ := List.mem_map.mp mem
  refine ⟨_,List.mem_map.mpr ⟨i,hi,rfl⟩,?_⟩
  simp [withTrue,show v (var r i)=true by simpa using on]

/-- With no negative literal for x[r,i], switch it on in the 5904-letter
near-cover omitting just r. Only positive rows can change, and all then hold. -/
theorem every_negative {ss : List Schema} (valid : ss.all legal=true) (unsat : (formula ss).Unsat)
    {r i : Nat} (hr : r<5040) (hi : i<5898) : var r i ∈ ss.flatMap negative := by
  by_contra missing
  have sr : r<table.length := by simpa [table_size] using hr
  obtain ⟨width,clean⟩ := (mem_reps _).mp (row_mem sr)
  obtain ⟨w,len,hits⟩ := SevenAlmostCover.prescribed_omission (row r) width clean
  let v := withTrue (truth w) (var r i)
  have sat : (formula ss).eval v=true := by
    rw [formula,CNF.eval,Array.all_eq_true_iff_forall_mem]
    intro c hc
    obtain ⟨s,hs,rfl⟩ := List.mem_map.mp (List.mem_toArray.mp hc)
    have ok := List.all_eq_true.mp valid s hs
    cases s with
    | required t =>
      by_cases eq : t=r
      · subst t
        rw [clause,CNF.Clause.eval,CNF.Clause.literals_ofLiterals,List.any_eq_true]
        exact ⟨_,List.mem_map.mpr ⟨i,List.mem_range.mpr hi,rfl⟩,by simp [v,withTrue]⟩
      · have ht : t<table.length := of_decide_eq_true ok
        obtain ⟨tw,tc⟩ := (mem_reps _).mp (row_mem ht)
        have diff : row t ≠ row r := fun e => eq (row_injective ht sr e)
        obtain ⟨l,z,hit⟩ := (hits _ tw tc).mpr diff
        exact required_more (truth w) (var r i) t
          (clause_sound_if_requested len.le (.required t) ok ⟨l,z,hit.symm⟩)
    | conflict t a k s b l =>
      have disagree := clause_sound_if_requested len.le (.conflict t a k s b l) ok trivial
      have na : var t a ≠ var r i := by
        intro eq
        exact missing (List.mem_flatMap.mpr
          ⟨_,hs,by simp only [negative,List.mem_cons]; exact Or.inl eq.symm⟩)
      have nb : var s b ≠ var r i := by
        intro eq
        exact missing (List.mem_flatMap.mpr
          ⟨_,hs,by simp only [negative,List.mem_cons]; exact Or.inr (Or.inl eq.symm)⟩)
      simpa [v,withTrue,na,nb,clause,CNF.Clause.eval,CNF.Clause.literals_ofLiterals] using disagree
  simpa [sat] using unsat v

private theorem negative_count (ss : List Schema) : (ss.flatMap negative).length=2*conflictCount ss := by
  induction ss with
  | nil => rfl
  | cons s ss ih => cases s <;> simp [negative,conflictCount,ih]; omega

theorem minimum_conflicts {ss : List Schema} (valid : ss.all legal=true) (unsat : (formula ss).Unsat) :
    14862960 ≤ conflictCount ss := by
  have sub : Finset.range 29725920 ⊆ (ss.flatMap negative).toFinset := by
    intro n hn
    have small := Finset.mem_range.mp hn
    have r : n/5898<5040 := by omega
    have i : n%5898<5898 := by omega
    have need := every_negative valid unsat r i
    have idx : var (n/5898) (n%5898)=n := by simp [var,Nat.div_add_mod]
    exact List.mem_toFinset.mpr (idx ▸ need)
  have sz := Finset.card_le_card sub
  rw [Finset.card_range] at sz
  have len := sz.trans (List.toFinset_card_le _)
  rw [negative_count] at len
  omega

def literalCount : List Schema → Nat
  | [] => 0
  | s::ss => (clause s).literals.length + literalCount ss

private theorem literal_count (ss : List Schema) :
    literalCount ss = 5898*(requiredRows ss).length + 2*conflictCount ss := by
  induction ss with
  | nil => rfl
  | cons s ss ih =>
    cases s with
    | required r =>
      have rows : requiredRows (.required r :: ss) = r :: requiredRows ss := rfl
      rw [literalCount,required_clause_width,ih,rows,conflictCount,List.length_cons]
      omega
    | conflict r i k s j l =>
      have rows : requiredRows (.conflict r i k s j l :: ss) = requiredRows ss := rfl
      have width : (clause (.conflict r i k s j l)).literals.length=2 := rfl
      rw [literalCount,width,ih,rows,conflictCount]
      omega

/-- Lower bound on the input formula's total number of literal occurrences,
counted with multiplicity; applies independently of the chosen LRAT proof. -/
theorem minimum_literals {ss : List Schema} (valid : ss.all legal=true) (unsat : (formula ss).Unsat) :
    59451840 ≤ literalCount ss := by
  rw [literal_count]
  have pos := (minimum_manifest valid unsat).2
  have neg := minimum_conflicts valid unsat
  omega

#print axioms minimum_literals
end ExactWordFlow.PlacementCertificate

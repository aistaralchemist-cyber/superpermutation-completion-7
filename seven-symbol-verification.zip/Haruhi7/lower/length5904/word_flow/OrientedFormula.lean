import SaturatedOrientation
import ExtremeWheelCut
import Std.Sat.CNF.Sat

namespace ExactWordFlow.OrientedCNF
open Std.Sat SevenWordWindows SaturatedOrientation ExtremeWheelCut
abbrev Choice := SaturatedOrientation.OptionRow Block

/-- One global variable per ordered pair consisting of a genuine wheel
and one of its six possible parent classes. -/
def options : List Choice :=
  WheelContacts.bases.flatMap fun w => (ResidualDensity.orbit w).map fun p => (WheelContacts.wheel w,p)

private def optionArray := options.toArray
private def atId (i : Nat) : Choice := optionArray[i]?.getD (∅,[])

/-- A column lists the orientation variables whose five children contain
the class. Precompute these 720 incidences independently of the root. -/
private def incidence : List (Block × List Nat) :=
  (allClasses.sort (·≤·)).map fun d =>
    (d, (List.range optionArray.size).filter (fun i => decide (d∈children (atId i))))

private def admits (A : Finset Block) : Array Bool :=
  optionArray.map fun p => decide (Disjoint (children p) A)

def columnIds (A : Finset Block) : List (List Nat) :=
  let allowed:=admits A
  (incidence.filter (fun item=>decide (item.1∉A))).map fun item =>
    item.2.filter (fun i => allowed[i]?.getD false)

private def exactlyOne (ids : List Nat) : List (CNF.Clause Nat) :=
  CNF.Clause.ofLiterals (ids.map (fun i=>(i,true))) ::
    ids.flatMap (fun i => (ids.filter (fun j=>decide (i<j))).map
      (fun j=> CNF.Clause.ofLiterals [(i,false),(j,false)]))

/-- Zero-based variable numbers. Each outside class contributes one
positive clause and one negative clause per unordered pair in its column. -/
def cnf (A : Finset Block) : CNF Nat :=
  ⟨((columnIds A).flatMap exactlyOne).toArray⟩

end ExactWordFlow.OrientedCNF

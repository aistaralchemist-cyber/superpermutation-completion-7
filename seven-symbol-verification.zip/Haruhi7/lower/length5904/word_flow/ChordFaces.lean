import PhaseReturn
import PhaseRank

namespace ExactWordFlow.ChordFaces
open Equiv PhaseReturn PhaseRank
open private marked mark_id skip from PhaseReturn
variable {X Y : Type*} [Fintype X] [DecidableEq X] [DecidableEq Y]

/-- Number the marked states of an exceptional cycle in its own cyclic order. -/
def nextIndex (m n : Nat) := if n+1 < m then n+1 else 0

/-- A chord joins two occurrences of the same original rotation tag.
The first return within that tag swaps its ends. Any additional return
that stays on its own side of the chord preserves this separation. -/
def Protected (m : Nat) (reorder : Nat→Nat) (l r : Nat) : Prop :=
  l < r ∧ r < m ∧ reorder l=r ∧ reorder r=l ∧
  ∀n < m,n≠l → n≠r → (l≤reorder n ∧ reorder n < r ↔ l≤n ∧ n < r)

theorem preserved {m l r n : Nat} {reorder : Nat→Nat}
    (chord : Protected m reorder l r) (small : n < m) :
    (l≤reorder (nextIndex m n) ∧ reorder (nextIndex m n) < r) ↔ (l≤n ∧ n < r) := by
  obtain ⟨lr,rm,atL,atR,separate⟩:=chord
  by_cases lt : n+1 < m
  · rw [nextIndex,ite_eq_left lt]
    by_cases left : n+1=l
    · rw [left,atL]; omega
    by_cases right : n+1=r
    · rw [right,atR]; omega
    rw [separate (n+1) lt left right]
    omega
  · rw [nextIndex,ite_eq_right lt]
    by_cases left : 0=l
    · rw [left,atL]; omega
    have right : 0≠r:=by omega
    rw [separate 0 (by omega) left right]
    omega

/-- For any list of protected chords, record the sides of all chords
containing the index. Intervals may be nested or disjoint. -/
def profile (D : Finset Nat) (right : Nat→Nat) (n : Nat) :=
  D.filter (fun l=>l≤n ∧ n < right l)

private theorem profile_step {D : Finset Nat} {right reorder : Nat→Nat} {m n : Nat}
    (protected_ : ∀l∈D,Protected m reorder l (right l)) (hn : n < m) :
    profile D right (reorder (nextIndex m n))=profile D right n := by
  ext l
  simp only [profile,Finset.mem_filter]
  by_cases h : l∈D
  · rw [preserved (protected_ l h) hn]
  · simp [h]

private theorem count_profiles {D : Finset Nat} {right reorder : Nat→Nat} {m : Nat}
    (protected_ : ∀l∈D,Protected m reorder l (right l)) :
    D.card+1=(insert (m-1) D).card ∧
    Set.InjOn (profile D right) (insert (m-1) D : Finset Nat) := by
  have last : m-1∉D := by
    intro h
    obtain ⟨a,b,_⟩:=protected_ _ h
    omega
  have distinguishes (l r : Nat) (hl : l∈insert (m-1) D) (hr : r∈insert (m-1) D)
      (small : l < r) : profile D right l≠profile D right r := by
    by_cases atEnd : r=m-1
    · have left : l∈D:=(Finset.mem_insert.mp hl).resolve_left (by omega)
      obtain ⟨a,b,_⟩:=protected_ l left
      have yes : l∈profile D right l:=Finset.mem_filter.mpr ⟨left,le_rfl,a⟩
      intro eq
      obtain ⟨_,_,lt⟩:=Finset.mem_filter.mp (eq ▸ yes)
      omega
    · have rightMem : r∈D:=(Finset.mem_insert.mp hr).resolve_left atEnd
      have a:=(protected_ r rightMem).1
      have yes : r∈profile D right r:=Finset.mem_filter.mpr ⟨rightMem,le_rfl,a⟩
      intro eq
      obtain ⟨_,le,_⟩:=Finset.mem_filter.mp (eq.symm ▸ yes)
      omega
  refine ⟨(Finset.card_insert_of_notMem last).symm,?_⟩
  intro x hx y hy eq
  rcases lt_trichotomy x y with lt|same|gt
  · exact (distinguishes _ _ hx hy lt eq).elim
  · exact same
  · exact (distinguishes _ _ hy hx gt eq.symm).elim

omit [Fintype X] in
/-- A coloring of the first-return states satisfying the return equations
lifts to a true invariant of the expanded physical successor R*J. -/
theorem lift_color {Z : Type*} {R J : Perm X} {S : Finset X} (visits : Hits R S)
    (off : ∀x∉S,J x=x) (label : X→Z) (stable : ∀x∈S,label (jump visits J x)=label x) :
    ∀x,label (mark visits ((R*J) x))=label (mark visits x) := by
  intro x
  by_cases hx : x∈S
  · rw [mark_id visits hx]
    exact stable x hx
  · rw [Perm.mul_apply,off x hx,skip visits hx]

/-- Protected chords force at least one more occupied base phase orbit
than their number. Untouched rotation tags supply additional isolated
colors. The marking S may contain dummy representatives on untouched tags;
these carry the index none. -/
theorem chord_budget {R J W : Perm X} (start : X) (one : ∀y,((R*J)*W).SameCycle start y)
    (width : ∀c∈W.cycleFactorsFinset,c.support.card≤6)
    (tag : X→Y) (V A : Finset Y) (realized : ∀t∈V,∃x,tag x=t) (board : A⊆V)
    (zone : ∀x,tag ((R*J) x)∈A ↔ tag x∈A)
    (stationary : ∀x,tag x∉A → tag ((R*J) x)=tag x)
    {S : Finset X} (visits : Hits R S) (off : ∀x∉S,J x=x)
    (m : Nat) (pos : 0 < m) (index : X→Option Nat) (reorder : Nat→Nat)
    (small : ∀x∈S,∀i,index x=some i→i < m)
    (all : ∀i < m,∃x∈S,tag x∈A ∧ index x=some i)
    (returns : ∀x∈S,index (jump visits J x)=(index x).map (fun n=>reorder (nextIndex m n)))
    (D : Finset Nat) (right : Nat→Nat)
    (protected_ : ∀l∈D,Protected m reorder l (right l)) :
    V.card+D.card ≤ A.card+5*W.cycleFactorsFinset.card := by
  classical
  let prof (x : X):=(index x).elim ∅ (profile D right)
  have invariant:=lift_color visits off prof (by
    intro x hx
    dsimp only [prof]
    rw [returns x hx]
    cases eq : index x with
    | none => rfl
    | some n => exact profile_step protected_ (small x hx n eq))
  let color (x : X) : Y ⊕ Finset Nat := if tag x∈A then Sum.inr (prof (mark visits x)) else Sum.inl (tag x)
  have held (x : X) : color ((R*J) x)=color x := by
    by_cases h : tag x∈A
    · simp only [color,ite_eq_left ((zone x).mpr h),ite_eq_left h,invariant]
    · simp only [color,stationary x h,ite_eq_right h]
  have rank:=color_budget start one color held width
  let labels:=(insert (m-1) D).image (profile D right)
  have sub : (V \ A).disjSum labels ⊆ Finset.univ.image color := by
    intro p hp
    cases p with
    | inl t =>
      obtain ⟨on,away⟩:=Finset.mem_sdiff.mp (Finset.inl_mem_disjSum.mp hp)
      obtain ⟨x,hx⟩:=realized t on
      exact Finset.mem_image.mpr ⟨x,Finset.mem_univ _,by simp [color,hx,away]⟩
    | inr t =>
      obtain ⟨n,hn,rfl⟩:=Finset.mem_image.mp (Finset.inr_mem_disjSum.mp hp)
      have sm : n < m := by
        rcases Finset.mem_insert.mp hn with rfl|h
        · omega
        · obtain ⟨a,b,_⟩:=protected_ _ h
          omega
      obtain ⟨x,hx,inside,idx⟩:=all n sm
      exact Finset.mem_image.mpr ⟨x,Finset.mem_univ _,by simp [color,inside,mark_id visits hx,prof,idx]⟩
  obtain ⟨count,inject⟩:=count_profiles protected_
  have sz : labels.card=(insert (m-1) D).card:=Finset.card_image_of_injOn inject
  have low:=Finset.card_le_card sub
  rw [Finset.card_disjSum,Finset.card_sdiff_of_subset board,sz,←count] at low
  have inc:=Finset.card_le_card board
  omega

/-- With s paid excess, each protected chord costs six additional states
above the ordinary mass bound, independently of the names of the tags. -/
theorem length_cut {M a k g q e s L : Nat} (mass : M+5*q=719+e+2*g)
    (short : L≤5904) (cost : L=5045+M+s+6*q)
    (occupied : a≤M) (chords : 720+k≤a+5*q) :
    (M-a)+k+1≤e+2*g ∧ 25+5*s+6*((M-a)+k)+5*(5904-L)≤M := by omega

/-- On one exceptional cycle each protected duplicate contributes both
one repeat and one extra face. In particular g=1 cannot pay for two. -/
theorem one_cycle {M a k g q : Nat} (mass : M+5*q=720+2*g)
    (distinct_duplicates : a+k≤M) (chords : 720+k≤a+5*q) : k≤g := by omega

#print axioms chord_budget
#print axioms one_cycle
end ExactWordFlow.ChordFaces

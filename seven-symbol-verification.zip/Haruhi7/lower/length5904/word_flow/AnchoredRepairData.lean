import AnchoredRepairCore

namespace ExactWordFlow.AnchoredRepair
set_option maxHeartbeats 0 in
theorem checked : analysisCheck=true := by native_decide
set_option maxHeartbeats 0 in
theorem witness_checked : witnessCheck=true := by native_decide
#print axioms checked
end ExactWordFlow.AnchoredRepair

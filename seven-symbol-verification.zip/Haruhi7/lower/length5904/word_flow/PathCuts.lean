import Mathlib.GroupTheory.Perm.Fin
import Mathlib.GroupTheory.Perm.Closure
import Mathlib.Tactic

set_option maxRecDepth 8192
namespace SevenPathCuts
open Equiv
abbrev Vertex := Equiv.Perm (Fin 7)
abbrev Color := Fin 7
abbrev Edge := Vertex × Color

def rot : Vertex := finRotate 7
def twist : Vertex := Equiv.swap 0 1 * rot^2
def generator (i : Color) : Vertex := if i=6 then twist else rot

def walk (x : Vertex) : List Color → Vertex
  | [] => x
  | i::is => walk (x*generator i) is

def edges (x : Vertex) : List Color → List Edge
  | [] => []
  | i::is => (x,i)::edges (x*generator i) is

def routes (i : Color) : List (List Color) :=
  if i=6 then
    [[6],
     [0, 0, 0, 6, 6, 6, 0, 6, 6, 0, 0],
     [1, 1, 6, 6, 0, 6, 6, 6, 0, 1, 1],
     [2, 2, 1, 0, 6, 0, 6, 6, 0, 0, 6, 0, 6, 6, 6, 2],
     [3, 6, 0, 0, 6, 0, 6, 6, 6, 6, 0, 6, 0, 1, 2, 3],
     [4, 3, 2, 1, 0, 6, 0, 0, 6, 0, 6, 6, 6, 0, 1, 2, 3, 4],
     [5, 4, 3, 2, 1, 0, 6, 0, 0, 0, 0, 6, 0, 6, 0, 6, 6, 6, 6, 0, 6, 0, 6, 0, 1, 2, 3, 4, 5]]
  else [[0], [1], [2], [3], [4], [5], [6, 0, 0, 0, 0, 0, 6, 6, 6, 6, 0, 6, 6, 6]]

theorem routing_data (i : Color) :
    (routes i).length = 7 ∧ (∀ p ∈ routes i, walk 1 p = generator i) ∧
      ((routes i).flatMap (edges 1)).Nodup := by
  have checked : ∀ j : Color, (routes j).length = 7 ∧
      (∀ p ∈ routes j, walk 1 p = generator j) ∧
      ((routes j).flatMap (edges 1)).Nodup := by native_decide
  exact checked i

def shift (a : Vertex) (e : Edge) : Edge := (a*e.1,e.2)
theorem shift_inj (a : Vertex) : Function.Injective (shift a) := by
  rintro ⟨x,i⟩ ⟨y,j⟩ h
  simpa [shift] using h

theorem translated (a x : Vertex) (p : List Color) :
    walk (a*x) p=a*walk x p ∧ edges (a*x) p=(edges x p).map (shift a) := by
  induction p generalizing x with
  | nil => simp [walk,edges]
  | cons i is ih =>
    simpa [walk,edges,shift,mul_assoc] using ih (x*generator i)

def cut (S : Finset Vertex) : Finset Edge :=
  Finset.univ.filter fun e : Edge => e.1∈S ∧ e.1*generator e.2∉S

attribute [irreducible] cut

private theorem leavePath (S : Finset Vertex) (x : Vertex) (p : List Color)
    (hx : x∈S) (hout : walk x p∉S) :
    ∃ e∈edges x p, e∈cut S := by
  induction p generalizing x with
  | nil => exact (hout hx).elim
  | cons i is ih =>
    by_cases h : x*generator i∈S
    · obtain ⟨e,he,hc⟩ := ih _ h hout
      exact ⟨e,List.mem_cons_of_mem _ he,hc⟩
    · exact ⟨(x,i),List.mem_cons_self, by simpa only [cut,Finset.mem_filter,Finset.mem_univ,true_and] using And.intro hx h⟩

private theorem countHit (S : Finset Vertex) (ps : List (List Edge))
    (H : ∀ p ∈ ps, ∃ e ∈ p, e∈cut S) :
    ps.length ≤ (ps.flatten.filter (· ∈ cut S)).length := by
  induction ps with
  | nil => simp
  | cons p ps ih =>
    obtain ⟨e,he,hc⟩ := H p (by simp)
    have hp : 0 < (p.filter (· ∈ cut S)).length :=
      List.length_pos_of_mem (List.mem_filter.mpr ⟨he, by simpa using hc⟩)
    have hh := ih (fun q hq => H q (by simp [hq]))
    simp only [List.flatten_cons,List.filter_append,List.length_append,List.length_cons]
    omega

theorem seven_on_exit (S : Finset Vertex) (x : Vertex) (i : Color)
    (hin : x∈S) (hout : x*generator i∉S) : 7 ≤ (cut S).card := by
  classical
  let paths := (routes i).map (edges x)
  have cert := routing_data i
  have hx (p : List Color) : edges x p=(edges 1 p).map (shift x) := by
    simpa using (translated x 1 p).2
  have allshift : paths.flatten = ((routes i).flatMap (edges 1)).map (shift x) := by
    rw [List.map_flatMap]
    change (routes i).flatMap (edges x) = _
    exact List.flatMap_congr (fun p _ => hx p)
  have nd : paths.flatten.Nodup := allshift ▸ cert.2.2.map (shift_inj x)
  have many := countHit S paths (by
    intro p hp
    obtain ⟨l,hl,rfl⟩ := List.mem_map.mp hp
    apply leavePath _ _ _ hin
    have rel : walk x l=x*walk 1 l := by simpa using (translated x 1 l).1
    rwa [rel,cert.2.1 l hl]
    )
  have contained : (paths.flatten.filter (·∈cut S)).toFinset ⊆ cut S := by
    intro e he
    simpa using (List.mem_filter.mp (List.mem_toFinset.mp he)).2
  have size := Finset.card_le_card contained
  rw [List.toFinset_card_of_nodup (nd.filter _)] at size
  simpa [paths,cert.1] using many.trans size

private def stable (S : Finset Vertex) : Subgroup Vertex where
  carrier := {g | ∀ x, x∈S ↔ x*g∈S}
  one_mem' := by simp
  mul_mem' := by
    intro a b ha hb x
    simpa [mul_assoc] using (ha x).trans (hb (x*a))
  inv_mem' := by
    intro a ha x
    simpa using (ha (x*a⁻¹)).symm

private theorem stable_of_forward (S : Finset Vertex) (g : Vertex)
    (h : ∀ x∈S, x*g∈S) : g ∈ stable S := by
  let f : S → S := fun x => ⟨x.val*g, h x.val x.property⟩
  have inj : Function.Injective f := by
    intro x y hxy
    exact Subtype.ext (mul_right_cancel (congrArg Subtype.val hxy : x.val*g=y.val*g))
  intro x
  refine ⟨h x, fun hx => ?_⟩
  obtain ⟨y,hy⟩ := Finite.surjective_of_injective inj (⟨x*g,hx⟩ : S)
  have hyx := mul_right_cancel (congrArg Subtype.val hy : y.val*g=x*g)
  exact hyx ▸ y.property

theorem all_cuts (S : Finset Vertex) (nonempty : S.Nonempty) (proper : S≠Finset.univ) :
    7 ≤ (cut S).card := by
  classical
  by_contra! hsmall
  have forward (i : Color) (x : Vertex) (hx : x∈S) : x*generator i∈S := by
    by_contra ho
    have := seven_on_exit S x i hx ho
    omega
  have r : rot∈stable S := stable_of_forward S rot (by simpa [generator] using forward 0)
  have t : twist∈stable S := stable_of_forward S twist (by simpa [generator] using forward 6)
  have sw : (Equiv.swap 0 1 : Vertex)∈stable S := by
    simpa [twist] using (stable S).mul_mem t ((stable S).inv_mem ((stable S).pow_mem r 2))
  have ht : stable S=⊤ := by
    apply top_unique
    rw [← Equiv.Perm.closure_cycle_adjacent_swap isCycle_finRotate
      support_finRotate (0 : Fin 7)]
    rw [Subgroup.closure_le]
    intro g hg
    rcases Set.mem_insert_iff.mp hg with h|h
    · simpa [h,rot] using r
    · have he := Set.mem_singleton_iff.mp h
      simpa [he,finRotate_apply_zero] using sw
  obtain ⟨x,hx⟩ := nonempty
  apply proper
  apply Finset.eq_univ_of_forall
  intro y
  have allow : x⁻¹*y∈stable S := by rw [ht]; trivial
  simpa using (allow x).1 hx

/-- Redirect every arc formerly entering the prescribed start to a new
dummy vertex, which has all seven arcs aimed at that start. -/
def next (r : Vertex) (i : Color) : Equiv.Perm (Option Vertex) :=
  Equiv.swap none (some r) * (Equiv.mulRight (generator i)).optionCongr

theorem next_dummy (r : Vertex) (i : Color) : next r i none = some r := by
  simp [next]

theorem next_real (r x : Vertex) (i : Color) :
    next r i (some x) = if x*generator i=r then none else some (x*generator i) := by
  by_cases h : x*generator i=r
  · simp [next,h]
  · simp [next,h, Equiv.swap_apply_of_ne_of_ne]

def pathCut (r : Vertex) (U : Finset (Option Vertex)) :
    Finset (Option Vertex × Color) :=
  Finset.univ.filter fun e : Option Vertex × Color => e.1∈U ∧ next r e.2 e.1∉U
attribute [irreducible] pathCut

theorem pathCut_mem (r : Vertex) (U : Finset (Option Vertex)) (x : Option Vertex) (i : Color) :
    (x,i) ∈ pathCut r U ↔ x∈U ∧ next r i x∉U := by
  simp only [pathCut,Finset.mem_filter,Finset.mem_univ,true_and]

private theorem tally (r : Vertex) (U : Finset (Option Vertex))
    (source : Color → Option Vertex) (h : ∀ i, (source i,i)∈pathCut r U) :
    7 ≤ (pathCut r U).card := by
  have le := Finset.card_le_card_of_injOn (s:=(Finset.univ : Finset Color))
    (t:=pathCut r U) (fun i => (source i,i)) (by intro i _; exact h i)
    (by intro i _ j _ eq; exact congrArg Prod.snd eq)
  simpa using le

theorem all_path_cuts (r : Vertex) (U : Finset (Option Vertex))
    (hne : U.Nonempty) (hpr : U≠Finset.univ) : 7 ≤ (pathCut r U).card := by
  classical
  let S : Finset Vertex := Finset.univ.filter (fun v => some v∈U)
  have memS (v : Vertex) : v∈S ↔ some v∈U := by simp [S]
  by_cases direct : none∈U ∧ some r∉U
  · apply tally r U (fun _ => none)
    intro i
    simpa only [pathCut_mem,next_dummy] using direct
  by_cases full : S=Finset.univ
  · have inside (v : Vertex) : some v∈U := (memS v).mp (by simp [full])
    have out : none∉U := by
      intro hn
      apply hpr
      apply Finset.eq_univ_of_forall
      rintro (_|v)
      · exact hn
      · exact inside v
    apply tally r U (fun i => some (r*(generator i)⁻¹))
    intro i
    simp only [pathCut_mem,next_real,inv_mul_cancel_right,ite_true]
    exact ⟨inside _,out⟩
  have nonempty : S.Nonempty := by
    obtain ⟨z,hz⟩ := hne
    cases z with
    | none => exact ⟨r,(memS r).mpr (by by_contra a; exact direct ⟨hz,a⟩)⟩
    | some v => exact ⟨v,(memS v).mpr hz⟩
  apply (all_cuts S nonempty full).trans
  apply Finset.card_le_card_of_injOn (fun (e : Edge) => (some e.1, e.2))
  · rintro ⟨x,i⟩ he
    change (x,i)∈cut S at he
    change (some x,i)∈pathCut r U
    have hp : x∈S ∧ x*generator i∉S := by
      simpa only [cut,Finset.mem_filter,Finset.mem_univ,true_and] using he
    rw [pathCut_mem,next_real]
    refine ⟨(memS x).mp hp.1,?_⟩
    by_cases hh : x*generator i=r
    · rw [ite_eq_left hh]
      intro hn
      exact direct ⟨hn,fun hr => hp.2 (hh ▸ (memS r).mpr hr)⟩
    · rw [ite_eq_right hh]
      exact fun h => hp.2 ((memS _).mpr h)
  · rintro ⟨x,i⟩ _ ⟨y,j⟩ _ h
    simpa using h

/-- A printed permutation lists its images in position order. -/
def word (x : Vertex) : List (Fin 7) := [x 0,x 1,x 2,x 3,x 4,x 5,x 6]

theorem overlap_one (x : Vertex) :
    (word x).drop 1 = (word (x*rot)).take 6 := by rfl

theorem overlap_two (x : Vertex) :
    (word x).drop 2 = (word (x*twist)).take 5 := by rfl

def price (i : Color) : ℕ := if i=6 then 2 else 1
def paid (r : Vertex) (i : Color) : Finset Vertex := Finset.univ.erase (r*(generator i)⁻¹)
attribute [irreducible] paid

theorem paid_iff (r x : Vertex) (i : Color) :
    x ∈ paid r i ↔ next r i (some x) ≠ none := by
  rw [next_real]
  simp [paid,eq_mul_inv_iff_mul_eq]

theorem paid_count (r : Vertex) (i : Color) : (paid r i).card=5039 := by
  simp [paid, Finset.card_erase_of_mem, Fintype.card_perm, Nat.factorial]

def fractionalLength (r : Vertex) : ℚ :=
  7 + (∑ i : Color, (paid r i).card * price i : ℕ)/ (7:ℚ)

theorem actual_cost (r : Vertex) : fractionalLength r = 40361/7 := by
  have total : (∑ i : Color, 5039 * price i : ℕ) = 40312 := by decide
  simp only [fractionalLength, paid_count, total]
  norm_num

theorem path_cost : (7:ℚ) + (5040-1)*(6*1+1*2)/7 = 40361/7 ∧ (40361:ℚ)/7<5904 := by norm_num
end SevenPathCuts

#print axioms SevenPathCuts.all_path_cuts
#print axioms SevenPathCuts.actual_cost

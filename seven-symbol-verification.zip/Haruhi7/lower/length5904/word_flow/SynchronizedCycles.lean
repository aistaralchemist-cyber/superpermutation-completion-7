import NoRoot265

namespace ExactWordFlow.SynchronizedCycles
open ResidualDensity MarkedGeometry DirectedEuler
open private localMark periodic_laps from DensityBudget
open private submask from MarkedGeometry
open private price initial start from MarkedDensity

/-- The repeated mark word of a closed walk avoids any forbidden profile
whose length fits within one lap, even across the cut between laps. -/
theorem safe_all_laps {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] {k : Nat}
    (w : Walk u) (h : CyclicMarked u p k) (i n : Nat) (v : List Bool)
    (bad : v∈forbidden) (fits : v.length≤k) : ¬v <:+:mask p i n := by
  rintro ⟨l,r,eq⟩
  let z:=i+l.length
  let t (j:Nat):=p j ∧ z≤j ∧ j<z+v.length
  have mark:Marked u t:=localMark (i:=z) h fits
  have block : mask p z v.length=v:=submask i n l v r eq
  have restrict : mask t z v.length=mask p z v.length:=by
    unfold mask
    apply List.map_congr_left
    intro j hj
    simp only [t]
    have lt:=List.mem_range.mp hj
    simp [show z≤z+j by omega,show z+j<z+v.length by omega]
  have reject:=safe w mark z v.length v bad
  rw [restrict,block] at reject
  exact reject ⟨[],[],by simp⟩

/-- Closed routes spanning the complete forbidden-profile memory pay no
endpoint credit. Applying the linear inequality to 67 laps removes a credit of 66. -/
theorem periodic_price {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] {k : Nat}
    (w : Walk u) (h : CyclicMarked u p k) (size:214≤k) : 45*count p 0 k≤38*k := by
  have maxLen : forbidden.all (fun v=>decide (v.length≤214))=true:=by native_decide
  have ok (v) (hv:v∈forbidden) : ¬v <:+:mask p 0 (k*67):=
    safe_all_laps w h 0 _ v hv ((of_decide_eq_true (List.all_eq_true.mp maxLen v hv)).trans size)
  have pay:=price [] (mask p 0 (k*67)) initial start.1 (by simp [start.2.1]) (by simpa using ok)
  rw [mark_count,periodic_laps h.periodic 67,start.2.2] at pay
  simp only [mask,List.length_map,List.length_range] at pay
  omega

theorem closed_route {s : Block} {es : List Block} (r:Route src dst s es s)
    (wd : ∀e∈es,e.length=7) (size:214≤es.length) : 45*classCount s es≤38*es.length := by
  obtain ⟨u,I,w,h,eq⟩:=closed_observations r wd (by omega)
  exact eq ▸ periodic_price w h size

#print axioms periodic_price
#print axioms closed_route
end ExactWordFlow.SynchronizedCycles

import SplitWheelPrice
import PrivateBoundaryWheels

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows ResidualDensity ResidualIncidence ResidualRoutes EmbeddedWheels
open LiteralWheelCover RotationCore
open WheelContacts (wheel)
open private sizes from EmbeddedWheels

/-- Price any grouping of the actual wheel rows. Each unit of rank lost
by grouping uses 45 units of the slack available after the residual walk. -/
theorem grouping_budget {Y : Multiset Block} {s t : Block} {ws : List Block}
    (clean : ∀u∈ws,full u) (flow : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (G : Finset Row)
    (covers : ∀u∈ws,∃R∈G,wheel u⊆R) :
    3*ws.length+45*(5*ws.length-∑R∈G,(R.card-1))≤308 := by
  have rank:=grouped_rank ws clean flow G covers
  have raw:=residual_rank ws clean flow
  have price:=(rest_price (Essential.restBalance flow (sizes clean).2)
    (fun e he=>flow.edges_seven e (Multiset.mem_add.mpr (Or.inl he)))).1
  have mass:=(sizes clean).1
  rw [Multiset.card_add,mass] at budget
  change 719≤(∑R∈G,(R.card-1))+separateRank Y s at rank
  change 719≤5*ws.length+separateRank Y s at raw
  omega

private theorem pack {ws : List Block} (clean : ∀u∈ws,full u)
    (T : Finset Row) (sub : T⊆(ws.map wheel).toFinset) :
    let S:=(ws.map wheel).toFinset
    let U:=T.biUnion id
    let G:=insert U (S\T)
    (∀u∈ws,∃R∈G,wheel u⊆R) ∧ ∑R∈G,(R.card-1) ≤ 5*(ws.length-T.card)+(U.card-1) := by
  classical
  let S:=(ws.map wheel).toFinset
  let U:=T.biUnion id
  let G:=insert U (S\T)
  have size (R : Row) (inside : R∈S) : R.card=6 := by
    obtain ⟨u,hu,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp inside)
    exact wheel_contacts_six u (clean u hu)
  change (∀u∈ws,∃R∈G,wheel u⊆R) ∧ ∑R∈G,(R.card-1) ≤ _
  constructor
  · intro u hu
    by_cases used : wheel u∈T
    · exact ⟨U,Finset.mem_insert_self ..,fun c hc=>Finset.mem_biUnion.mpr ⟨wheel u,used,hc⟩⟩
    · exact ⟨wheel u,Finset.mem_insert_of_mem (Finset.mem_sdiff.mpr
        ⟨List.mem_toFinset.mpr (List.mem_map_of_mem hu),used⟩),Finset.Subset.rfl⟩
  · have own : (∑R∈S\T,(R.card-1))=5*(S\T).card := by
      calc
        _ = ∑_R∈S\T,5 := Finset.sum_congr rfl (fun R hr=>by rw [size R (Finset.mem_sdiff.mp hr).1])
        _ = _ := by simp [Nat.mul_comm]
    have small : S.card≤ws.length := by
      simpa [S] using List.toFinset_card_le (ws.map wheel)
    have diff:=Finset.card_sdiff_of_subset sub
    change _≤5*(ws.length-T.card)+(U.card-1)
    by_cases dup : U∈S\T
    · simp only [G,Finset.insert_eq_of_mem dup,own]
      dsimp only [S] at *
      omega
    · simp only [G,Finset.sum_insert dup,own]
      dsimp only [S] at *
      omega

/-- This holds simultaneously for every subfamily of wheels, with no
assumption on the component count or the order of the splices. -/
theorem subfamily_budget {Y : Multiset Block} {s t : Block} {ws : List Block}
    (clean : ∀u∈ws,full u) (flow : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (T : Finset Row) (sub : T⊆(ws.map wheel).toFinset) :
    3*ws.length+45*(5*T.card-((T.biUnion id).card-1))≤308 := by
  obtain ⟨covered,cap⟩:=pack clean T sub
  have limit:=grouping_budget clean flow budget _ covered
  have st:=(Finset.card_le_card sub).trans (List.toFinset_card_le (ws.map wheel))
  simp only [List.length_map] at st
  let G := insert (T.biUnion id) ((ws.map wheel).toFinset \ T)
  change (∑R∈G,(R.card-1))≤5*(ws.length-T.card)+((T.biUnion id).card-1) at cap
  change 3*ws.length+45*(5*ws.length-∑R∈G,(R.card-1))≤308 at limit
  omega

theorem base_subfamily {b v : Block} {rs : List Row} (ins : Inserts b rs v)
    (visitedAll : (visited v).card=720) (done : (complete b).card=92)
    (size : v.length=1508) (T : Finset Row) (sub : T⊆rs.toFinset) :
    3*rs.length+45*(5*T.card-((T.biUnion id).card-1))≤308 := by
  obtain ⟨Y,ws,s,t,rows,len,cl,h,budget⟩:=sharp_residual_rows ins visitedAll done size
  have bound:=subfamily_budget cl h budget.le T (rows ▸ sub)
  rwa [len] at bound

theorem base_forest {b v : Block} {rs : List Row} (ins : Inserts b rs v)
    (visitedAll : (visited v).card=720) (done : (complete b).card=92)
    (size : v.length=1508) (many : 88≤rs.length) (T : Finset Row)
    (sub : T⊆rs.toFinset) (nonempty : T.Nonempty) : 5*T.card+1≤(T.biUnion id).card := by
  have bound:=base_subfamily ins visitedAll done size T sub
  have pos:=Finset.card_pos.mpr nonempty
  omega

#print axioms base_forest
#print axioms subfamily_budget
end ExactWordFlow.WheelBaseResidual

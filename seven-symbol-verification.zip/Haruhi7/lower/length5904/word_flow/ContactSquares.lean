import GlobalWheelRank

namespace ContactSquares

variable {ι α β : Type*} [DecidableEq ι] [DecidableEq α] [DecidableEq β]

def Connected (Q : Finset ι) (V : Finset α) (C : ι → Finset α) : Prop :=
  ∀ T : Set α, (∀i∈Q, ∀x∈C i, ∀y∈C i, x∈T ↔ y∈T) →
    ∀x∈V, ∀y∈V, x∈T ↔ y∈T

private theorem image_sum (Q : Finset ι) (f : ι → Finset α) :
    (∑ b∈Q.image f, (b.card-1)) ≤ ∑ i∈Q, ((f i).card-1) := by
  induction Q using Finset.induction_on with
  | empty => simp
  | @insert i Q hi ih =>
    rw [Finset.image_insert,Finset.sum_insert hi]
    by_cases mem : f i∈Q.image f
    · rw [Finset.insert_eq_of_mem mem]; omega
    · rw [Finset.sum_insert mem]; omega

theorem connected_rank (Q : Finset ι) (V : Finset α) (C : ι → Finset α)
    (ne : V.Nonempty) (cv : Connected Q V C) : V.card-1 ≤ ∑ i∈Q, ((C i).card-1) := by
  classical
  obtain ⟨a,ha⟩ := ne
  obtain ⟨R,sub,cap,closed⟩ := GlobalWheelRank.grow {a} (Q.image C)
  have anchor : a∈R := sub (Finset.mem_singleton_self _)
  have uniform (i) (hi : i∈Q) (x) (hx : x∈C i) (y) (hy : y∈C i) :
      x∈R ↔ y∈R := by
    have row := Finset.mem_image_of_mem C hi
    exact ⟨fun h => closed _ row ⟨_,Finset.mem_inter.mpr ⟨h,hx⟩⟩ hy,
      fun h => closed _ row ⟨_,Finset.mem_inter.mpr ⟨h,hy⟩⟩ hx⟩
  have cover : V⊆R := fun x hx => (cv (R : Set α) uniform a ha x hx).mp anchor
  have lim := Finset.card_le_card cover
  have max := image_sum Q C
  simp only [Finset.card_singleton] at cap
  omega

/-- Each selected face has four incidences forming a genuine rectangle. -/
def Rectangle (E : Finset (ι × α)) : Prop :=
  ∀ z∈E, ∃ j d, j≠z.1 ∧ d≠z.2 ∧ (z.1,d)∈E ∧ (j,z.2)∈E ∧ (j,d)∈E

/-- For every nonempty collection of faces, some incidence belongs to
exactly one of its faces. This gives an order for removing one edge per face. -/
def HasBoundary (F : Finset β) (edges : β → Finset (ι × α)) : Prop :=
  ∀ T ⊆ F, T.Nonempty → ∃ f∈T, ∃ z∈edges f, ∀ k∈T, z∈edges k → k=f

private def cut (C : ι → Finset α) (i : ι) (x : α) (j : ι) :=
  if j=i then (C j).erase x else C j

private theorem preserves {Q : Finset ι} {V : Finset α} {C : ι → Finset α} (cv : Connected Q V C)
    {i j : ι} {x d : α} (ji : j≠i) (dx : d≠x) (hj : j∈Q)
    (id₁ : d∈C i) (jx : x∈C j) (jd : d∈C j) :
    Connected Q V (cut C i x) := by
  intro T small
  apply cv T
  intro k hk a ha b hb
  by_cases eq : k=i
  · subst k
    have other := small j hj
    have xd : x∈T ↔ d∈T := other _ (by simpa [cut,ji] using jx) _ (by simpa [cut,ji] using jd)
    have dmem : d∈cut C i x i := by simp [cut,dx,id₁]
    have tie (c) (hc : c∈C i) : c∈T ↔ d∈T := by
      by_cases hit : c=x
      · simpa [hit] using xd
      · exact small i hk c (by simp [cut,hit,hc]) d dmem
    exact (tie a ha).trans (tie b hb).symm
  · exact small k hk a (by simpa [cut,eq] using ha) b (by simpa [cut,eq] using hb)

private theorem debit (Q : Finset ι) (C : ι → Finset α) {i : ι} {x d : α}
    (hi : i∈Q) (hx : x∈C i) (hd : d∈C i) (dx : d≠x) :
    (∑ j∈Q, ((cut C i x j).card-1))+1 = ∑j∈Q, ((C j).card-1) := by
  have two := Finset.one_lt_card.mpr ⟨d,hd,x,hx,dx⟩
  have same : ∑ j∈Q.erase i, ((cut C i x j).card-1) = ∑ j∈Q.erase i, ((C j).card-1) :=
    Finset.sum_congr rfl (fun j hj => by simp [cut,(Finset.mem_erase.mp hj).1])
  rw [←Finset.sum_erase_add _ _ hi,←Finset.sum_erase_add _ _ hi,same]
  simp [cut,Finset.card_erase_of_mem hx]
  omega

theorem independent_rectangles_cost (Q : Finset ι) (V : Finset α) (C : ι → Finset α)
    (ne : V.Nonempty) (cv : Connected Q V C) (F : Finset β)
    (edges : β → Finset (ι × α))
    (rect : ∀ f∈F, Rectangle (edges f)) (boundary : HasBoundary F edges)
    (used : ∀ f∈F, ∀ z∈edges f, z.1∈Q ∧ z.2∈C z.1) :
    V.card-1+F.card ≤ ∑i∈Q, ((C i).card-1) := by
  classical
  by_cases empty : F=∅
  · simpa [empty] using connected_rank Q V C ne cv
  have pos := Finset.nonempty_iff_ne_empty.mpr empty
  obtain ⟨f,hf,z,hz,unique⟩ := boundary F (Finset.Subset.refl _) pos
  obtain ⟨j,d,ji,dx,id₁,jx,jd⟩ := rect f hf z hz
  have new := preserves cv ji dx (used _ hf _ jx).1
    (used _ hf _ id₁).2 (used _ hf _ jx).2 (used _ hf _ jd).2
  have support (k) (hk : k∈F.erase f) (u) (hu : u∈edges k) :
      u.1∈Q ∧ u.2∈cut C z.1 z.2 u.1 := by
    have kn := Finset.mem_erase.mp hk
    have ok := used k kn.2 u hu
    refine ⟨ok.1,?_⟩
    by_cases eq : u.1=z.1
    · have other : u.2≠z.2 := by
        intro e
        have id : u=z := Prod.ext eq e
        exact kn.1 (unique k kn.2 (id ▸ hu))
      simp [cut,eq,other] at ok ⊢
      exact ok.2
    · simpa [cut,eq] using ok.2
  have ih := independent_rectangles_cost Q V (cut C z.1 z.2) ne new (F.erase f) edges
    (fun k hk => rect k (Finset.mem_of_mem_erase hk))
    (fun T sub => boundary T (sub.trans (Finset.erase_subset ..))) support
  have price := debit Q C (used f hf z hz).1 (used f hf z hz).2 (used f hf _ id₁).2 dx
  have sz := Finset.card_erase_add_one hf
  omega
termination_by F.card
decreasing_by exact Finset.card_erase_lt_of_mem hf

#print axioms independent_rectangles_cost
end ContactSquares

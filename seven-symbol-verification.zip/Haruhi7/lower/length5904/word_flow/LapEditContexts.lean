import LapDeletionShadow
import CoreControls

namespace ExactWordFlow.LapEditContexts
open SevenWordWindows

structure Tile where
  raw : Block
  skip : Option Block
  deriving Inhabited, DecidableEq

def Tile.flip (t : Tile) : Tile := ⟨t.raw.reverse,t.skip⟩
def uncut (ts : List Tile) : Block := ts.flatMap Tile.raw

/-- Choose which optional seven-letter laps to erase. The second list records
every skipped permutation in its original orientation and order. -/
inductive Render : List Tile → Block → List Block → Prop
  | nil : Render [] [] []
  | keep {ts w ps} (t : Tile) (rest : Render ts w ps) : Render (t::ts) (t.raw++w) ps
  | passLap {t : Tile} {p ts w ps} (may : t.skip=some p) (rest : Render ts w ps) :
      Render (t::ts) w (p::ps)

/-- Every chosen subset of the optional labels has an actual rendering. -/
theorem choose (ts : List Tile) (selected : Block → Bool) :
    ∃w,Render ts w ((ts.filterMap Tile.skip).filter selected) := by
  induction ts with
  | nil => exact ⟨[],.nil⟩
  | cons t ts ih =>
    obtain ⟨w,r⟩:=ih
    cases eq : t.skip with
    | none => exact ⟨_,by simpa [List.filterMap_cons,eq] using Render.keep t r⟩
    | some p =>
      by_cases take : selected p=true
      · exact ⟨_,by simpa [List.filterMap_cons,eq,List.filter_cons,take] using Render.passLap eq r⟩
      · exact ⟨_,by simpa [List.filterMap_cons,eq,List.filter_cons,take] using Render.keep t r⟩

theorem Render.append {l r v w ps qs} (a : Render l v ps) (b : Render r w qs) :
    Render (l++r) (v++w) (ps++qs) := by
  induction a with
  | nil => simpa using b
  | keep t _ ih => simpa [List.append_assoc] using Render.keep t ih
  | passLap eq _ ih => simpa using Render.passLap eq ih

theorem Render.reverse {ts w ps} (a : Render ts w ps) :
    Render (ts.reverse.map Tile.flip) w.reverse ps.reverse := by
  induction a with
  | nil => exact .nil
  | keep t _ ih => simpa [Tile.flip] using ih.append (Render.keep t.flip .nil)
  | @passLap t p ts w ps may _ ih =>
    have one : Render [t.flip] [] [p] := Render.passLap (by exact may) .nil
    simpa using ih.append one

/-- Only the first n emitted letters are needed. An option lists only skips
that have already been decided when those letters are known. -/
def sides (n : Nat) : List Tile → List (Block × List Block)
  | [] => [([],[])]
  | t::ts =>
    if n=0 then [([],[])] else
    let keep := if n≤t.raw.length then [(t.raw.take n,[])] else
      (sides (n-t.raw.length) ts).map fun (w,ps)=>(t.raw++w,ps)
    match t.skip with
    | none => keep
    | some p => keep++(sides n ts).map fun (w,ps)=>(w,p::ps)

theorem side_sound {ts w ps} (r : Render ts w ps) (n : Nat) :
    ∃ seen : List Block,(w.take n,seen)∈sides n ts ∧ ∀p∈seen,p∈ps := by
  induction r generalizing n with
  | nil => exact ⟨[],by simp [sides],by simp⟩
  | @keep ts w ps t rest ih =>
    by_cases nz : n=0
    · exact ⟨[],by simp [sides,nz],by simp⟩
    let K := if n≤t.raw.length then [(t.raw.take n,([] : List Block))] else
      (sides (n-t.raw.length) ts).map fun (w,ps)=>(t.raw++w,ps)
    have inside {entry : Block × List Block} (h : entry∈K) : entry∈sides n (t::ts) := by
      cases eq : t.skip <;> simp [sides,nz,eq,K] at h ⊢ <;> tauto
    by_cases enough : n≤t.raw.length
    · refine ⟨[],inside ?_,by simp⟩
      simp [K,enough,List.take_append,Nat.sub_eq_zero_of_le enough]
    · obtain ⟨seen,h,sub⟩:=ih (n-t.raw.length)
      refine ⟨seen,inside ?_,sub⟩
      simp only [K,enough,ite_false,List.mem_map]
      exact ⟨_,h,by simp [List.take_append,List.take_of_length_le (by omega : t.raw.length≤n)]⟩
  | @passLap t p ts w ps may rest ih =>
    by_cases nz : n=0
    · exact ⟨[],by simp [sides,nz],by simp⟩
    obtain ⟨seen,h,sub⟩:=ih n
    refine ⟨p::seen,?_,fun q hq=>?_⟩
    · simp only [sides,nz,ite_false,may,List.mem_append,List.mem_map]
      exact Or.inr ⟨_,h,rfl⟩
    · rcases List.mem_cons.mp hq with rfl|h
      · exact List.mem_cons_self
      · exact List.mem_cons_of_mem _ (sub _ h)

def Valid : List Tile → Prop
  | [] => True
  | t::ts => (∀p,t.skip=some p → t.raw=p ∧ p∈representatives ∧ (uncut ts).take 6=p.take 6) ∧ Valid ts

/-- Left-to-right cutting makes each optional block a legal literal lap,
including when another selected block starts in its surviving context. -/
theorem cuts {ts w ps} (r : Render ts w ps) (ok : Valid ts) (pre : Block) :
    LapDeletionShadow.Cuts (pre++uncut ts) ps (pre++w) := by
  induction r generalizing pre with
  | nil => exact LapDeletionShadow.Cuts.stop _
  | keep t rest ih =>
    simpa [uncut,List.append_assoc] using ih ok.2 (pre++t.raw)
  | @passLap t p ts w ps may rest ih =>
    obtain ⟨raw,rep,head⟩:=ok.1 _ may
    have e : p.take 6++(uncut ts).drop 6=uncut ts := head ▸ List.take_append_drop 6 (uncut ts)
    have prev:=ih ok.2 pre
    have next : LapDeletionShadow.Cuts (pre++p.take 6++(uncut ts).drop 6) ps (pre++w) := by
      simpa only [List.append_assoc,e] using prev
    have step:=LapDeletionShadow.Cuts.remove (l:=pre) (r:=(uncut ts).drop 6) rep next
    change LapDeletionShadow.Cuts (pre++(t.raw++uncut ts)) (p::ps) (pre++w)
    simpa only [raw,List.append_assoc,e] using step

end ExactWordFlow.LapEditContexts

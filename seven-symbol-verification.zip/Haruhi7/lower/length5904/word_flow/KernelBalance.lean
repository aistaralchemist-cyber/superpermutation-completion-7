import Windows5904

namespace SevenWordWindows

private theorem rotate_mem (e : Word) (n : Nat) (h : e∈representatives) :
    e.rotate n∈representatives := by
  have ⟨hl,hd⟩ := (mem_reps e).mp h
  exact (mem_reps _).mpr ⟨by simpa using hl,(e.rotate_perm n).nodup_iff.mpr hd⟩

private theorem rotation_permutes : (representatives.map (·.rotate 1)).Perm representatives := by
  have nd : representatives.Nodup := List.nodup_permutations _ (List.nodup_finRange _)
  apply (List.perm_ext_iff_of_nodup (nd.map (List.rotate_injective 1)) nd).mpr
  intro e
  constructor
  · rintro he
    obtain ⟨x,hx,rfl⟩ := List.mem_map.mp he
    exact rotate_mem _ _ hx
  · intro he
    have len := ((mem_reps _).mp he).1
    apply List.mem_map.mpr
    refine ⟨e.rotate 6,rotate_mem _ _ he,?_⟩
    rw [List.rotate_rotate]
    change e.rotate 7=e
    simpa only [len] using List.rotate_length e

theorem balanced_representatives :
    (↑representatives : Multiset Word).map (fun e => e.take 6) =
    (↑representatives : Multiset Word).map (fun e => e.drop 1) := by
  have hb := (rotation_permutes.map (fun e => e.take 6)).symm
  have h : (representatives.map (·.rotate 1)).map (·.take 6) = representatives.map (·.drop 1) := by
    rw [List.map_map]
    apply List.map_congr_left
    intro e he
    have len := ((mem_reps _).mp he).1
    change (e.rotate 1).take 6=e.drop 1
    rw [List.rotate_eq_drop_append_take (by omega : 1 ≤ e.length)]
    have ll : (e.drop 1).length=6 := by simp [len]
    rw [←ll, List.take_left]
  rw [h] at hb
  exact Quot.sound hb

end SevenWordWindows
#print axioms SevenWordWindows.balanced_representatives

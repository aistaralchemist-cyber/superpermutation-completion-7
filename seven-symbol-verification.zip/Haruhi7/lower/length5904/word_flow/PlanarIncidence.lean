import PhaseReturn

namespace ExactWordFlow.PlanarIncidence
open Equiv
variable {X A B : Type*} [Fintype X] [DecidableEq X] [DecidableEq A] [DecidableEq B]

/-- Connectivity of the incidence graph, expressed without any choice of cyclic order.
Equivalently the two permutations generate a transitive action. -/
def Connected (R h : Perm X) : Prop :=
  ∀ P : X→Prop, (∀x,P (R x) ↔ P x) → (∀x,P (h x) ↔ P x) → ∀x y,P x → P y

private def flips (F : Perm X) (u : X→Bool) := Finset.univ.filter (fun x=>u (F x)≠u x)

/-- A change of color along a finite cycle must be accompanied by another
change before that cycle returns to its original point. -/
private theorem another (F : Perm X) (a : X→A) (label : ∀x,a (F x)=a x)
    (u : X→Bool) (x : X) (diff : u (F x)≠u x) :
    ∃y,a y=a x ∧ y≠x ∧ u (F y)≠u y := by
  by_contra! only
  obtain ⟨n,_,endp⟩:=(show F.SameCycle (F x) x from Perm.sameCycle_apply_left.mpr (.refl _ _)).exists_pow_eq'
  have possible : ∃k : Nat,(F^k) (F x)=x:=⟨n,endp⟩
  let j:=Nat.find possible
  have col (m:Nat) : a ((F^m) (F x))=a x:=by
    induction m with
    | zero => simpa using label x
    | succ m ih => rw [pow_succ',Perm.mul_apply,label,ih]
  have keep (m:Nat) (le:m≤j) : u ((F^m) (F x))=u (F x):=by
    induction m with
    | zero => simp
    | succ m ih =>
      have ne : (F^m) (F x)≠x:=Nat.find_min possible (by omega : m<j)
      rw [pow_succ',Perm.mul_apply,only _ (col m) ne,ih (by omega)]
  have eq:=keep j le_rfl
  rw [show (F^j) (F x)=x from Nat.find_spec possible] at eq
  exact diff eq.symm

private theorem flip_mass (F : Perm X) (a : X→A) (label : ∀x,a (F x)=a x)
    (u : X→Bool) : 2*((flips F u).image a).card≤(flips F u).card := by
  let D:=flips F u
  have two (v) (hv:v∈D.image a) : 2≤(D.filter (fun x=>a x=v)).card := by
    obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hv
    obtain ⟨y,ey,neq,diff⟩:=another F a label u x (Finset.mem_filter.mp hx).2
    exact Finset.one_lt_card.mpr ⟨x,Finset.mem_filter.mpr ⟨hx,rfl⟩,y,
      Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _,diff⟩,ey⟩,neq.symm⟩
  have lower:=Finset.sum_le_sum two
  rw [←Finset.card_eq_sum_card_image] at lower
  simpa only [Finset.sum_const,smul_eq_mul,Nat.mul_comm] using lower

/-- For any nonempty set of edges D in a connected incidence graph, the
remaining edges must still pay for all vertices outside those touched by D. -/
private theorem incidence_growth (R h : Perm X) (a : X→A) (b : X→B)
    (ar : ∀x,a (R x)=a x) (bh : ∀x,b (h x)=b x) (connect : Connected R h)
    (D : Finset X) (ne : D.Nonempty) :
    (Finset.univ.image a).card+(Finset.univ.image b).card+D.card ≤
      (D.image a).card+(D.image b).card+Fintype.card X := by
  classical
  let pair (x:X) : Finset (A⊕B):={Sum.inl (a x),Sum.inr (b x)}
  let base:=(D.image a).disjSum (D.image b)
  let rest:=(Finset.univ\D).image pair
  obtain ⟨Z,sub,cap,closed⟩:=GlobalWheelRank.grow base rest
  have edge (x:X) : Sum.inl (a x)∈Z ↔ Sum.inr (b x)∈Z := by
    by_cases inside:x∈D
    · exact iff_of_true (sub (Finset.inl_mem_disjSum.mpr (Finset.mem_image_of_mem _ inside)))
        (sub (Finset.inr_mem_disjSum.mpr (Finset.mem_image_of_mem _ inside)))
    · have member:pair x∈rest:=Finset.mem_image_of_mem _ (Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,inside⟩)
      have l : Sum.inl (a x)∈pair x:=by simp [pair]
      have r : Sum.inr (b x)∈pair x:=by simp [pair]
      exact ⟨fun yes=>closed _ member ⟨_,Finset.mem_inter.mpr ⟨yes,l⟩⟩ r,
        fun yes=>closed _ member ⟨_,Finset.mem_inter.mpr ⟨yes,r⟩⟩ l⟩
  obtain ⟨s,hs⟩:=ne
  have left (x:X) : Sum.inl (a x)∈Z:=
    connect (fun v=>Sum.inl (a v)∈Z) (fun v=>by rw [ar])
      (fun v=>by rw [edge,bh,←edge]) s x
      (sub (Finset.inl_mem_disjSum.mpr (Finset.mem_image_of_mem _ hs)))
  have all : (Finset.univ.image a).disjSum (Finset.univ.image b)⊆Z:=by
    intro v hv
    cases v with
    | inl t => obtain ⟨x,_,rfl⟩:=Finset.mem_image.mp (Finset.inl_mem_disjSum.mp hv); exact left x
    | inr t => obtain ⟨x,_,rfl⟩:=Finset.mem_image.mp (Finset.inr_mem_disjSum.mp hv); exact (edge x).mp (left x)
  have count:=Finset.card_le_card all
  have fee : (∑w∈rest,(w.card-1))≤rest.card:=by
    have lim (w) (hw:w∈rest) : w.card-1≤1:=by
      obtain ⟨x,_,rfl⟩:=Finset.mem_image.mp hw
      simp [pair]
    simpa only [Finset.sum_const,smul_eq_mul,mul_one] using Finset.sum_le_sum lim
  have size:rest.card≤(Finset.univ\D).card:=Finset.card_image_le
  rw [Finset.card_disjSum] at count
  change Z.card≤((D.image a).disjSum (D.image b)).card+_ at cap
  rw [Finset.card_disjSum] at cap
  have tot:=Finset.card_sdiff_add_card_eq_card (Finset.subset_univ D)
  rw [Finset.card_univ] at tot
  omega

/-- A connected incidence tree has one face for every cyclic order at every
vertex: rotation order and correction-cycle order carry no further obstruction. -/
theorem tree_orbit (R h : Perm X) (a : X→A) (b : X→B)
    (ar : ∀x,a (R x)=a x) (bh : ∀x,b (h x)=b x)
    (tree : Fintype.card X+1≤(Finset.univ.image a).card+(Finset.univ.image b).card)
    (connect : Connected R h) (start : X) : ∀y,(R*h).SameCycle start y := by
  classical
  let P:=R*h
  let u (x:X):=decide (P.SameCycle start x)
  have steady (x:X) : u (P x)=u x:=by simp [u]
  have back (x:X) : u (h⁻¹ x)=u (R x):=by
    have eq:=(steady (h⁻¹ x)).symm
    simpa [P,Perm.mul_apply] using eq
  have rev (x:X) : b (h⁻¹ x)=b x:=by simpa using (bh (h⁻¹ x)).symm
  let D:=flips R u
  have same : flips h⁻¹ u=D:=by
    ext x
    simp only [flips,D,Finset.mem_filter,back]
  have empty : D=∅:=by
    by_contra non
    have sum:=incidence_growth R h a b ar bh connect D (Finset.nonempty_iff_ne_empty.mpr non)
    have left:=flip_mass R a ar u
    have right:=flip_mass h⁻¹ b rev u
    rw [same] at right
    change 2*(D.image a).card≤D.card at left
    omega
  have first (x:X):u (R x)=u x:=by
    by_contra neq
    have hx:x∈D:=Finset.mem_filter.mpr ⟨Finset.mem_univ _,neq⟩
    simp [empty] at hx
  have second (x:X):u (h x)=u x:=by
    have eq:=back (h x)
    rw [first] at eq
    simpa using eq.symm
  intro y
  have yes:=connect (fun x=>u x=true) (fun x=>by rw [first]) (fun x=>by rw [second])
    start y (decide_eq_true (.refl _ _))
  exact of_decide_eq_true yes

#print axioms tree_orbit
end ExactWordFlow.PlanarIncidence

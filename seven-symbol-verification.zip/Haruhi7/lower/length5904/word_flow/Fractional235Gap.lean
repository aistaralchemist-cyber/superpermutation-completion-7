import FixedSeed235Exact
import Fractional235Capacity
import FractionalPackingReal

namespace ExactWordFlow.Fractional235Capacity
open SevenWordWindows ExtremeWheelCut FixedSeed235Exact
/-- A certificate using classwise nonnegative real prices cannot exclude
this root, or any seed contained in it. -/
theorem every_real_price {P : Finset Block} (inside : P⊆rootClasses) (weight : Block→ℝ)
    (nonneg : ∀v∈allClasses \ P,0≤weight v) (K : ℝ)
    (pay : ∀w∈allRows,∀p∈w,Disjoint (w.erase p) P → K≤∑v∈w.erase p,weight v) :
    97*K≤∑v∈allClasses \ P,weight v := by
  apply FractionalPacking.lower_real (allClasses \ rootClasses) (allClasses \ P)
    kids mass 97 denominator (by decide) exact_load.1 exact_load.2 (fun i=>(geometry i).2.2)
    (Finset.sdiff_subset_sdiff (Finset.Subset.refl _) inside) weight nonneg K
  intro i
  apply pay (row i) (geometry i).1 (parent i) (geometry i).2.1
  exact Finset.disjoint_left.mpr (fun _ hv hp=>(Finset.mem_sdiff.mp ((geometry i).2.2 hv)).2 (inside hp))

/-- The same candidate has perfect fractional tag coverage with unit
wheel capacities and has no integral solution of the oriented cover CNF. -/
theorem integrality_gap :
    (∑i,mass i)=97*denominator ∧
    (∀v∈allClasses \ rootClasses,(∑i,if v∈kids i then mass i else 0)=denominator) ∧
    (∀w∈allRows,(∑i,if row i=w then mass i else 0)≤denominator) ∧
    (OrientedCNF.cnf rootClasses).Unsat :=
  ⟨exact_load.1,exact_load.2,wheel_caps,FixedSeed235Exact.impossible⟩
#print axioms every_real_price
#print axioms integrality_gap
end ExactWordFlow.Fractional235Capacity

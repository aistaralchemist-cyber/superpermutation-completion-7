import LapBudget
import CoreControls

namespace ExactWordFlow.ParityStretches
open DirectedEuler SevenWordWindows ResidualDensity RotationReinsert RotationCore LapSkeleton
open private entries token sum_counts_le from LapBudget

private def inversions : Block → Nat
  | [] => 0
  | a::xs => (xs.filter (·<a)).length + inversions xs

/-- Seven-cycle rotation preserves the parity of its labelled permutation. -/
def sign (c : Block) : Bool := inversions c % 2 == 1

private def side (b : Bool) (s : Block) : Nat :=
  if full s ∧ sign (tag s)=b then 1 else 0

private def ofSign (b : Bool) (lst : List Block) := (lst.filter (fun c=>sign c==b)).length

def departures (b : Bool) (es : List Block) :=
  (es.filter (fun e => side b (src e)==1 && decide (¬full (dst e)))).length

def returns (b : Bool) (es : List Block) :=
  (es.filter (fun e => decide (¬full (src e)) && side (!b) (dst e)==1)).length

def completions (b : Bool) (w : Block) := ((complete w).filter (fun c => sign c=b)).card

private theorem preserved : ∀p∈representatives, full (src p) ∧ full (dst p) ∧
    sign (tag (src p))=sign (tag (dst p)) := by native_decide

private theorem flip_table : ∀s∈states, ∀a : Fin 7, full (dst (s++[a])) →
    ¬(s++[a]).Nodup → sign (tag s) = !sign (tag (dst (s++[a]))) := by native_decide

private theorem flip {e : Block} (wide : e.length=7) (fs : full (src e)) (fd : full (dst e))
    (invalid : ¬e.Nodup) : sign (tag (src e)) = !sign (tag (dst e)) := by
  have nn : e ≠ [] := by intro he; simp [he] at wide
  have form : src e++[e.getLast nn]=e := by
    simpa [src,List.dropLast_eq_take,wide] using List.dropLast_append_getLast nn
  have h := flip_table (src e) (mem_states fs) (e.getLast nn)
  rw [form] at h
  exact h fd invalid

/-- Six adjacent clean moves that each change the parity of the class
restore the actual six-symbol context, including the original phase. -/
theorem six_switches_return {u : Nat → Block} (walk : Walk u) (i : Nat)
    (clean : ∀j≤6, full (u (i+j)))
    (switches : ∀j<6, sign (tag (u (i+j)))≠sign (tag (u (i+j+1)))) :
    u (i+6)=u i := by
  have phase (k : Nat) (small : k≤6) : u (i+k) = (u i).rotate k := by
    induction k with
    | zero => simp
    | succ k ih =>
      obtain ⟨a,mv⟩ := walk (i+k)
      have diff : tag (u (i+k))≠tag (u (i+k+1)) :=
        fun eq => switches k (by omega) (congrArg sign eq)
      have h := next_unique _ a (clean k (by omega)) (mv ▸ clean (k+1) small) (mv ▸ diff)
      rw [Nat.add_succ,mv,h,ih (by omega),List.rotate_rotate]
  have width := (clean 0 (by decide)).1
  simp only [Nat.add_zero] at width
  rw [phase 6 (by decide),←width,List.rotate_length]

private theorem exactTail (b : Bool) {s t : Block} {es : List Block}
    (r : Route src dst s es t) (wd : ∀e∈es,e.length=7) :
    2*ofSign b (entries es)+side b s+returns b es =
    (entries es).length+side b t+departures b es := by
  induction r with
  | nil => simp [entries,ofSign,departures,returns]
  | @cons s t es e first tail ih =>
    have next := ih (fun f hf => wd f (List.mem_cons_of_mem _ hf))
    subst s
    have w := wd e List.mem_cons_self
    by_cases nd : e.Nodup
    · obtain ⟨fs,fd,eq⟩ := preserved e ((mem_reps _).mpr ⟨w,nd⟩)
      simpa [entries,nd,side,eq,fs,fd,returns,departures] using next
    · by_cases fs : full (src e) <;> by_cases fd : full (dst e)
      · have eq := flip w fs fd nd
        cases b <;> cases v : sign (tag (dst e)) <;>
          simp [entries,nd,side,token,ofSign,eq,v,fs,fd,returns,departures] at * <;> omega
      all_goals
        cases b <;> cases ds : sign (tag (dst e)) <;> cases ss : sign (tag (src e)) <;>
          simp [entries,nd,side,token,ofSign,ds,ss,fs,fd,returns,departures] at * <;> omega

/-- Signed excess of stretch starts telescopes. Dirty excursions contribute
only through the signs at their two clean boundary states. -/
theorem exact_balance (w : Block) (long : 6≤w.length) (b : Bool) :
    2*ofSign b (starts w)+side (!b) (w.take 6)+returns b (windows w) =
    (starts w).length+side b (w.drop (w.length-6))+departures b (windows w) := by
  have h := exactTail b (read_route w long) (fun _ he=>window_width w he)
  cases b <;> by_cases f : full (w.take 6) <;> cases val : sign (tag (w.take 6)) <;>
    simp [starts,ofSign,side,token,f,val] at * <;> omega

private theorem halfBoard (b : Bool) : (allClasses.filter fun c=>sign c=b).card=360 := by
  cases b <;> native_decide

private theorem lowerCount {w : Block} (long : 6≤w.length) (all : (visited w).card=720)
    (free : LapFree w) (b : Bool) : 360+completions b w ≤ ofSign b (starts w) := by
  let S := (visited w).filter (fun c=>sign c=b)
  have whole := Finset.eq_of_subset_of_card_le (visited_subset w) (by rw [board,all])
  have sz : S.card=360 := by rw [show S=allClasses.filter (fun c=>sign c=b) by rw [←whole]]; exact halfBoard b
  have enough (c : Block) (hc : c∈S) :
      1+(if c∈complete w then 1 else 0) ≤ ((starts w).filter fun c=>sign c==b).count c := by
    obtain ⟨inBoard,sg⟩ := Finset.mem_filter.mp hc
    rw [List.count_filter]
    rotate_left
    · simpa using sg
    by_cases done : c∈complete w
    · have a := completed_hits done
      have v := visit_capacity long free c
      simp [done]; omega
    · simpa [done] using List.count_pos_iff.mpr (starts_hit long inBoard)
  have h := Finset.sum_le_sum enough
  have m := sum_counts_le S ((starts w).filter fun c=>sign c==b)
  have ident : (S.filter (fun c=>c∈complete w)) = (complete w).filter (fun c=>sign c=b) := by
    ext c; simp only [S,Finset.mem_filter]; constructor
    · rintro ⟨⟨_,a⟩,d⟩; exact ⟨d,a⟩
    · rintro ⟨d,a⟩; exact ⟨⟨complete_subset _ d,a⟩,d⟩
  simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one,Finset.sum_boole,ident,sz] at h
  exact h.trans m

private theorem exits_paid (b : Bool) (w : Block) : departures b (windows w)≤dirty w := by
  have step (es : List Block) : departures b es ≤ ((es.map dst).filter (fun s => decide (¬full s))).length := by
    induction es with
    | nil => simp [departures]
    | cons e es ih => by_cases hd : full (dst e) <;> by_cases hs : side b (src e)=1 <;>
        simp [departures,hd,hs] at * <;> omega
  have h := step (windows w)
  by_cases f : full (w.take 6) <;> simp [dirty,anchors,f] at h ⊢ <;> omega

/-- Additional starts of this parity beyond one per class and one further
start per completed class. The lap-free lower bound makes the subtraction exact. -/
def spareStarts (b : Bool) (w : Block) := ofSign b (starts w) - (360+completions b w)

def parityCost (b : Bool) (w : Block) :=
  2*completions b w + extraVisits w + (dirty w-departures b (windows w)) +
  returns b (windows w) + side (!b) (w.take 6) + (1-side b (w.drop (w.length-6)))

/-- The score computed from either parity alone, including the two boundary
states and every dirty excursion. Unused start capacity on a side costs two. -/
theorem exact_score {w : Block} (long : 6≤w.length) (all : (visited w).card=720)
    (free : LapFree w) (b : Bool) :
    score w = 5764+parityCost b w+2*spareStarts b w := by
  have balance := exact_balance w long b
  have count := lowerCount long all free b
  have paid := exits_paid b w
  have eq := (score_budget long all free).1
  have other := split_floor long all free
  have top : side b (w.drop (w.length-6))≤1 := by unfold side; split <;> decide
  unfold parityCost spareStarts
  omega

private theorem splitStarts (xs : List Block) : ofSign false xs + ofSign true xs=xs.length := by
  induction xs with
  | nil => simp [ofSign]
  | cons c xs ih =>
    cases s : sign c <;> simp [ofSign,s] at * <;> omega

private theorem splitComplete (w : Block) :
    completions false w + completions true w=(complete w).card := by
  let C := complete w
  have halves (S : Finset Block) :
      (S.filter (fun c=>sign c=false)).card+(S.filter (fun c=>sign c=true)).card=S.card := by
    induction S using Finset.induction with
    | empty => simp
    | insert a S fresh ih =>
      cases s : sign a <;> simp [Finset.filter_insert,s,fresh] at * <;> omega
  exact halves C

/-- If each completed class uses precisely its required extra stretch and
all others use one, both one-sided lower bounds equal the full score. -/
theorem tight_starts {w : Block} (long : 6≤w.length) (all : (visited w).card=720)
    (free : LapFree w) (tight : (starts w).length=720+(complete w).card) (b : Bool) :
    spareStarts b w=0 ∧ score w=5764+parityCost b w := by
  have i := lowerCount long all free false
  have j := lowerCount long all free true
  have k := splitComplete w
  have m := splitStarts (starts w)
  have eq := exact_score long all free b
  unfold spareStarts at eq ⊢
  cases b <;> omega

/-- For either parity, at most seventy completed classes can survive removal
of contiguous laps in a candidate with a 139-unit budget. Extra valid visits,
dirty contexts not entered from this side, returns to the other parity and
the two endpoint terms all spend the same budget. -/
theorem parity_budget {w : Block} (long : 6≤w.length) (all : (visited w).card=720)
    (free : LapFree w) (limit : score w≤5904) (b : Bool) :
    2*completions b w + extraVisits w + (dirty w-departures b (windows w)) +
      returns b (windows w) + side (!b) (w.take 6) + (1-side b (w.drop (w.length-6))) ≤ 140 := by
  have balance := exact_balance w long b
  have count := lowerCount long all free b
  have paid := exits_paid b w
  have score := (score_budget long all free).1
  have other := split_floor long all free
  have top : side b (w.drop (w.length-6))≤1 := by unfold side; split <;> decide
  omega

theorem at_most_seventy {w : Block} (long : 6≤w.length) (all : (visited w).card=720)
    (free : LapFree w) (limit : score w≤5904) (b : Bool) : completions b w≤70 := by
  have h := parity_budget long all free limit b
  omega

/-- In the extremal 70-case every term other than the completions vanishes.
In particular all dirty contexts are entered directly from this side and
there can be no dirty-to-opposite return anywhere in the word. -/
theorem seventy_rigidity {w : Block} (long : 6≤w.length) (all : (visited w).card=720)
    (free : LapFree w) (limit : score w≤5904) (b : Bool) (seventy : completions b w=70) :
    score w=5904 ∧ spareStarts b w=0 ∧ extraVisits w=0 ∧
    dirty w=departures b (windows w) ∧ returns b (windows w)=0 ∧
    side (!b) (w.take 6)=0 ∧ side b (w.drop (w.length-6))=1 := by
  have eq := exact_score long all free b
  have paid := exits_paid b w
  have endCap : side b (w.drop (w.length-6))≤1 := by unfold side; split <;> decide
  unfold parityCost at eq
  omega

/-- A concrete cone of forbidden profiles, without fixing an endpoint, a
path order, a wheel count or the identities of the completed classes. -/
theorem exclude_reference_cone {w : Block} (long : 6≤w.length) (all : (visited w).card=720)
    (free : LapFree w) (b : Bool) (done : 32≤completions b w)
    (unpaid : 41≤dirty w-departures b (windows w)) (back : 36≤returns b (windows w)) :
    5905 ≤ score w := by
  by_contra! small
  have eq := parity_budget long all free (by omega : score w≤5904) b
  omega

/-- The recorded 5,905-letter word, after all 654 complete literal laps
have been removed. The counts pin the concrete cone to the reference word. -/
def reference := (RotationCoreControls.coreWord 653).drop 7

theorem reference_counts : reference.length=1327 ∧ (visited reference).card=720 ∧
    (completions false reference, dirty reference, departures false (windows reference),
        returns false (windows reference), parityCost false reference, score reference)=
    (32,74,33,36,141,5905) := by native_decide

/-- Every shift retains the suffix not yet shifted out. This tests a whole
dirty excursion without specifying any of its intervening states. -/
theorem suffix_after {u : Nat → Block} (walk : Walk u) (i k : Nat) (width : (u i).length=6)
    (within : k≤6) : (u i).drop k <+: u (i+k) := by
  induction k with
  | zero => simp
  | succ k ih =>
    obtain ⟨rest,old⟩ := ih (by omega)
    obtain ⟨a,mv⟩ := walk (i+k)
    have ne : (u i).drop k≠[] := fun h => by have := List.drop_eq_nil_iff.mp h; omega
    rw [show i+(k+1)=i+k+1 by omega,mv,step,←old,List.tail_append_of_ne_nil ne,List.tail_drop,List.append_assoc]
    exact List.prefix_append ..

def bridgeStart : Block := [5,4,1,0,3,2]
def bridgeEnd : Block := [0,3,2,1,4,5]

theorem reference_bridge : ((reference.drop 114).take 9 : Block)=[5,4,1,0,3,2,1,4,5] ∧
    (complete reference).card=66 ∧ parityCost true reference=141 := by native_decide

/-- The two interior dirty contexts in this actual three-shift bridge cannot
be compressed into a single interior context, even with a new middle symbol. -/
theorem bridge_needs_three {u : Nat → Block} (walk : Walk u) (i k : Nat)
    (left : u i=bridgeStart) (right : u (i+k)=bridgeEnd) : 3≤k := by
  by_contra! small
  have check : ∀j∈List.range 3, ¬(bridgeStart.drop j <+: bridgeEnd) := by native_decide
  have h := suffix_after walk i k (by rw [left]; decide) (by omega)
  rw [left,right] at h
  exact check k (List.mem_range.mpr small) h

#print axioms six_switches_return
#print axioms exact_score
#print axioms parity_budget
#print axioms at_most_seventy
#print axioms tight_starts
#print axioms seventy_rigidity
#print axioms exclude_reference_cone
#print axioms reference_counts
#print axioms reference_bridge
#print axioms bridge_needs_three
end ExactWordFlow.ParityStretches

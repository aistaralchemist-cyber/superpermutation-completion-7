import EmbeddedWheels
import SharedRotationCuts
import ContactSquares
import WheelContacts

/-! Contact rows for any decomposition of the surplus into full wheel turns
and arbitrary other edges. The removed turns may meet the remaining edges
at actual six-letter vertices. Repeated turns have only one contact row. -/
namespace ExactWordFlow.EmbeddedWheels
open SevenWordWindows ResidualDensity ResidualRoutes ResidualIncidence
open scoped Classical

noncomputable def boardIds (Y : Multiset Block) (s : Block) (ws : List Block) :
    Finset (Sum (Component Y) Block) := (liveGroups Y s).disjSum ws.toFinset

noncomputable def boardRow (Y : Multiset Block) (s : Block) :
    Sum (Component Y) Block → Finset Block :=
  Sum.elim (contacts (support Y s) (label Y)) WheelContacts.wheel

private theorem wheel_table :
    (WheelContacts.bases.all fun w => decide ((WheelContacts.wheel w).card=6 ∧
      ∀e∈GlobalWheelRank.wheel w, full (src e) ∧ full (dst e) ∧
      tag (src e)∈WheelContacts.wheel w ∧ tag (dst e)∈WheelContacts.wheel w))=true := by
  native_decide

private theorem required_table : (representatives.map (fun e => tag (src e))).toFinset=allClasses ∧
    (representatives.all fun e => decide (full (src e) ∧ full (dst e) ∧ tag (src e)=tag (dst e)))=true := by
  native_decide

theorem inr_mem_board {Y : Multiset Block} {s w : Block} {ws : List Block} (hw : w∈ws) :
    Sum.inr w ∈ boardIds Y s ws := by simpa [boardIds] using hw

theorem board_weight_distinct {Y : Multiset Block} {s : Block} (ws : List Block)
    (legit : ∀w∈ws, w∈WheelContacts.bases) :
    ∑ i∈boardIds Y s ws, ((boardRow Y s i).card-1) = separateRank Y s+5*ws.toFinset.card := by
  classical
  rw [boardIds,Finset.sum_disjSum]
  change separateRank Y s + (∑w∈ws.toFinset, ((WheelContacts.wheel w).card-1)) = _
  have eq : ∀w∈ws.toFinset, (WheelContacts.wheel w).card-1=5 := by
    intro w hw
    rw [(of_decide_eq_true (List.all_eq_true.mp wheel_table _ (legit _ (List.mem_toFinset.mp hw)))).1]
  rw [Finset.sum_congr rfl eq]
  simp [Nat.mul_comm]

theorem board_weight {Y : Multiset Block} {s : Block} (ws : List Block)
    (legit : ∀w∈ws,w∈WheelContacts.bases) (nd : ws.Nodup) :
    ∑ i∈boardIds Y s ws, ((boardRow Y s i).card-1) = separateRank Y s+5*ws.length := by
  rw [board_weight_distinct ws legit,List.toFinset_card_of_nodup nd]

theorem board_connected {Y : Multiset Block} {s t : Block} (ws : List Block)
    (legit : ∀w∈ws,w∈WheelContacts.bases) (h : Feasible (Y+turns ws) s t) :
    ContactSquares.Connected (boardIds Y s ws) allClasses (boardRow Y s) := by
  classical
  intro T uniform
  let K := contacts (support Y s) (label Y)
  let U : Set Block := {v | ∃c∈K (label Y v), c∈T}
  have reflect (v : Block) (hv : full v) : v∈U ↔ tag v∈T := by
    have srcMem : v∈required.map src := mem_states hv
    have reqBal : required.map src=required.map dst := balanced_representatives
    rw [reqBal] at srcMem
    have sup : v∈support Y s := by
      apply Finset.mem_insert_of_mem
      apply Multiset.mem_toFinset.mpr
      rw [Multiset.map_add]
      exact Multiset.mem_add.mpr (Or.inl srcMem)
    have row : Sum.inl (label Y v) ∈ boardIds Y s ws :=
      Finset.inl_mem_disjSum.mpr (Finset.mem_image_of_mem _ sup)
    have hit : tag v∈K (label Y v) := Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨sup,rfl,hv⟩,rfl⟩
    constructor
    · rintro ⟨c,hc,on⟩
      exact (uniform _ row c hc _ hit).mp on
    · exact fun vc => ⟨_,hit,vc⟩
  have invariant (e : Block) (he : e∈required+(Y+turns ws)) :
      src e∈U ↔ dst e∈U := by
    rcases Multiset.mem_add.mp he with req|extra
    · obtain ⟨f,g,eq⟩ := of_decide_eq_true (List.all_eq_true.mp required_table.2 e req)
      rw [reflect _ f,reflect _ g,eq]
    · rcases Multiset.mem_add.mp extra with keep|wheel
      · change (∃c∈K (label Y (src e)), c∈T) ↔ ∃c∈K (label Y (dst e)), c∈T
        rw [on_edge keep]
      · obtain ⟨q,hq,edge⟩ := List.mem_flatMap.mp (show e∈ws.flatMap GlobalWheelRank.wheel from wheel)
        have row := (of_decide_eq_true (List.all_eq_true.mp wheel_table _ (legit _ hq))).2 e edge
        rw [reflect _ row.1,reflect _ row.2.1]
        exact uniform _ (inr_mem_board hq) _ row.2.2.1 _ row.2.2.2
  let S : Set Block := {v | v∈U ↔ s∈U}
  have root : s∈S := Iff.rfl
  have step : ∀e∈required+(Y+turns ws), src e∈S → dst e∈S :=
    fun e he hs => (invariant e he).symm.trans hs
  have agree (c : Block) (hc : c∈allClasses) : c∈T ↔ s∈U := by
    rw [←required_table.1] at hc
    obtain ⟨e,he,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hc)
    have live : e∈required+(Y+turns ws) := Multiset.mem_add.mpr (Or.inl he)
    have fullv := (of_decide_eq_true (List.all_eq_true.mp required_table.2 _ he)).1
    exact (reflect _ fullv).symm.trans (h.reachable S root step _ live)
  intro a ha b hb
  exact (agree _ ha).trans (agree _ hb).symm

#print axioms board_connected
#print axioms board_weight_distinct
end ExactWordFlow.EmbeddedWheels

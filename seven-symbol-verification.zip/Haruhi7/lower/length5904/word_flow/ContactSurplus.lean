import ConnectorSavings
import GlobalDensity66

namespace ExactWordFlow.ConnectorSavings
open SevenWordWindows ResidualRoutes ResidualIncidence ResidualDensity RotationSpan RotationComponentCount
open private base_groups from ConnectorSavings
open scoped Classical

private theorem terminal_support {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    terminals X s ⊆ support X s := by
  intro v hv
  rcases Finset.mem_insert.mp hv with rfl|others
  · exact Finset.mem_insert_self ..
  have enter (v) (hit : v∈X.map dst) : v∈support X s :=
    Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr (by
      rw [Multiset.map_add]; exact Multiset.mem_add.mpr (Or.inr hit)))
  rcases Finset.mem_union.mp others with outgoing|incoming
  · have pos : v∈X.map src+{t} := Multiset.mem_add.mpr (Or.inl (Multiset.mem_toFinset.mp outgoing))
    rw [h.balance] at pos
    rcases Multiset.mem_add.mp pos with other|home
    · exact enter v other
    · have eq : v=s := by simpa using home
      exact eq ▸ Finset.mem_insert_self ..
  · exact enter v (Multiset.mem_toFinset.mp incoming)

/-- Dual incidence count. Extra class attachments above a spanning rank
fit within the old incidence slack, independently of the endpoints. -/
theorem dual_rank {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    (∑c∈allClasses, ((attachments X s c).card-1))+719≤(occupied X s).card+separateRank X s := by
  classical
  let Q := (terminals X s).image (label X)
  let I := attachments X s
  let C := fun q=> (contacts (support X s) (label X) q).card
  have sub (c) : I c⊆Q := Finset.image_subset_image (Finset.filter_subset ..)
  have row (c) : (I c).card=∑q∈Q,if q∈I c then 1 else 0 := by
    rw [Finset.sum_boole]
    congr 1
    ext x; simp +contextual [sub c]
  have col (q) : (∑c∈allClasses,if q∈I c then 1 else 0)≤C q := by
    rw [Finset.sum_boole]
    apply Finset.card_le_card
    intro c hc
    obtain ⟨v,hv,eq⟩:=Finset.mem_image.mp (Finset.mem_filter.mp hc).2
    obtain ⟨there,clean,key⟩:=Finset.mem_filter.mp hv
    exact Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨terminal_support h there,eq,clean⟩,key⟩
  have inc : (∑c∈allClasses,(I c).card) ≤∑q∈Q,C q := by
    simp_rw [row]
    rw [Finset.sum_comm]
    exact Finset.sum_le_sum (fun q _=>col q)
  have positive (c) (hc : c∈allClasses) : 0<(I c).card := by
    obtain ⟨v,hv,clean,tagEq⟩:=every_tag h hc
    exact Finset.card_pos.mpr ⟨_,Finset.mem_image_of_mem _ (Finset.mem_filter.mpr ⟨hv,clean,tagEq⟩)⟩
  have adjust := Finset.sum_congr (s₁:=allClasses) (s₂:=allClasses) rfl
    (fun c hc => show (I c).card=(I c).card-1+1 by have := positive c hc; omega)
  simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one,RotationCore.board] at adjust
  have pieces := Finset.sum_le_sum (s:=Q) (fun q _=>show C q≤(C q-1)+1 by omega)
  simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] at pieces
  have lim : (∑q∈Q,(C q-1))≤ separateRank X s :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.image_subset_image (terminal_support h)) (by intros; omega)
  have qn : Q.card=(occupied X s).card+1:=base_groups X s
  change (∑c∈allClasses, ((I c).card-1))+719≤_
  omega

/-- At incidence rank 719, every class touching two different components
is indispensable. In general the sum of the lost joining capacities,
not just the number of omitted classes, is at most the rank surplus. -/
theorem omitted_rank {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {S : Finset Block} (sub : S⊆allClasses)
    (span : ∀v∈terminals X s,label (selected X S) v=label (selected X S) s) :
    (∑c∈allClasses \ S,((attachments X s c).card-1))+719≤ separateRank X s := by
  have cap:=dual_rank h
  have must:=necessary span
  have split:=Finset.sum_sdiff (f:=fun c=> (attachments X s c).card-1) sub
  rw [←split] at cap
  apply Nat.le_of_add_le_add_right (b:=(occupied X s).card)
  calc
    _ ≤ ((∑c∈allClasses \ S, ((attachments X s c).card-1))+719) + (∑c∈S, ((attachments X s c).card-1)) :=
      Nat.add_le_add_left must _
    _ ≤ separateRank X s+(occupied X s).card := by
      simpa only [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using cap

/-- A tight component incidence count forces every class with two or more
original attachments into every connected selection. -/
theorem forced_at_equality {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (tight : separateRank X s=719) {S : Finset Block} (sub : S⊆allClasses)
    (span : ∀v∈terminals X s,label (selected X S) v=label (selected X S) s)
    {c : Block} (hc : c∈allClasses) (many : 2≤(attachments X s c).card) : c∈S := by
  by_contra no
  have pos:=Finset.single_le_sum (f:=fun a=> (attachments X s a).card-1)
    (fun _ _=>Nat.zero_le _) (Finset.mem_sdiff.mpr ⟨hc,no⟩)
  have all:=omitted_rank h sub span
  have le : (attachments X s c).card-1+719≤719 :=
    (Nat.add_le_add_right pos 719).trans (all.trans_eq tight)
  omega

/-- Quantified for every feasible placement of at most 858 extra edges. -/
theorem omitted_nine {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (short : X.card≤858) {S : Finset Block} (sub : S⊆allClasses)
    (span : ∀v∈terminals X s,label (selected X S) v=label (selected X S) s) :
    (∑c∈allClasses \ S,((attachments X s c).card-1))≤9 := by
  have lo:=omitted_rank h sub span
  have hi:=GlobalDensity66.rank_728 h.balance h.edges_seven short
  omega

#print axioms forced_at_equality
#print axioms omitted_rank
#print axioms omitted_nine
end ExactWordFlow.ConnectorSavings

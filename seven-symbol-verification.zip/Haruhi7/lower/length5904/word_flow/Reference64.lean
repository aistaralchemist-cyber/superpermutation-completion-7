import MacroAlternatives
import ElevenExtensionCaps
import Packet64
import Return64
import Cycle64
import SpineWheelTrimming
import TwelveWitness

set_option maxRecDepth 4096
set_option maxHeartbeats 800000

namespace ExactWordFlow.Reference64
open DirectedEuler ResidualDensity SevenWordWindows OnePath66 EmbeddedWheels
open SuperpermutationBounds ReferenceSpineOptimum
open SuperpermLowerBounds.LengthBudget

private abbrev W := ResidualControls.mainWord
private abbrev a := W.take 6
private abbrev b := W.drop (W.length-6)

private theorem data : 6≤W.length ∧ classCount a (windows W)=390 ∧ (bag W).card=463 := by
  native_decide

private theorem turn_count (ws : List Block) : (turns ws).card=6*ws.length := by
  induction ws with
  | nil => rfl
  | cons w ws ih =>
    change ((↑(GlobalWheelRank.wheel w) : Multiset Block)+turns ws).card=6*(ws.length+1)
    simp [ih,GlobalWheelRank.wheel,Nat.mul_add,Nat.add_comm]

private theorem join_bag (p es q : List Block) (T : Multiset Block) :
    (↑(p++es++q) : Multiset Block)+T=(↑es+T)+↑(p++q) := by
  simp only [←Multiset.coe_add]
  ac_rfl

private theorem move_turn (A B C D : Multiset Block) : A+B+(C+D)=A+(C+B)+D := by ac_rfl

private theorem move_loop (A R : Multiset Block) (e : Block) : A+({e}+R)=A+R+{e} := by ac_rfl

/-- The Euler alternative in which all fresh windows extend the two ends. -/
private theorem no_ends {ws p q : List Block} {s t : Block}
    (legit : ∀u∈ws,full u) (n : ws.length=64)
    (pre : Route src dst s p a) (post : Route src dst b q t) (budget : p.length+q.length≤11)
    (h : Feasible ((bag W+turns ws)+↑(p++q)) s t) : False := by
  have spine := read_route W data.1
  have together := (RequiredComponent.together_iff_classes _).mp (RequiredComponent.feasible_together h)
  have base := data.2.1
  have cd : 0<classCount a (windows W) := by omega
  have floor := exchange_rank spine legit (Finset.card_pos.mp cd) (↑(p++q)) (↑(p++q))
    (fun _ h => h) together
  simp only [Multiset.coe_card,List.length_append,n,base] at floor
  have width (e : Block) (he : e∈p++q) : e.length=7 := h.edges_seven e
    (Multiset.mem_add.mpr (Or.inr (show e∈(↑(p++q) : Multiset Block) from he)))
  have cap := ElevenExtensionCaps.route_extension_cap pre post
    (fun e he => width e (List.mem_append_left _ he)) (fun e he => width e (List.mem_append_right _ he))
    (by omega)
  change classCount s (p++windows W++q)≤399 at cap
  have eq : (↑(p++windows W++q) : Multiset Block)+turns ws =
      (bag W+turns ws)+↑(p++q) := join_bag p (windows W) q (turns ws)
  have joined := join_routes (join_routes pre spine) post
  have good : Feasible ((↑(p++windows W++q) : Multiset Block)+turns ws) s t := eq.symm ▸ h
  have lower := residual_rank ws legit good
  change 719≤5*ws.length+separateRank (↑(p++windows W++q)) s at lower
  rw [path_rank_eq joined s,n] at lower
  omega

/-- For any two endpoints and any 64 complete turns, the prescribed
463-window multiset needs at least twelve more literal windows. -/
theorem no_eleven {ws : List Block} {s t : Block} (n : ws.length=64)
    (legit : ∀u∈ws,full u) (F : Multiset Block) (small : F.card≤11) :
    ¬Feasible (bag W+turns ws+F) s t := by
  intro yes
  have spine := read_route W data.1
  have c := data.2.1
  obtain ⟨d,hd⟩ := Finset.card_pos.mp (show 0<(pathClasses a (windows W)).card from
    (show 0<classCount a (windows W) by omega))
  have together := (RequiredComponent.together_iff_classes _).mp (RequiredComponent.feasible_together yes)
  have rb := spine.balance
  have wb := EndpointSaving.turns_balance ws legit
  have old : (bag W+turns ws).map src+{b}=(bag W+turns ws).map dst+{a} := by
    simp only [bag,Multiset.map_add,wb,add_right_comm _ ((turns ws).map dst) _,rb]
  have degree := fresh_endpoints old yes.balance
  rcases MacroAlternatives.alternatives src dst F degree with ends|cycle|back
  · obtain ⟨p,q,eq,pr,po⟩ := ends
    subst F
    exact no_ends legit n pr po (by simpa using small) yes
  · obtain ⟨u,p,ne,sub,rr⟩ := cycle
    obtain ⟨R,split⟩ := exists_add_of_le sub
    have sz : p.length+R.card≤11 := by simpa only [split,Multiset.card_add,Multiset.coe_card] using small
    have width (e : Block) (he : e∈p) : e.length=7 :=
      yes.edges_seven e (Multiset.mem_add.mpr (Or.inr
        (Multiset.mem_of_le sub (show e∈(↑p : Multiset Block) from he))))
    rw [split] at together
    have tight := Packet64.cycle_nodup (F:=R) spine legit hd c n.le rr ne sz together
    by_cases two : 2≤p.length
    · obtain ⟨fullu,wheel⟩ := ShortFreshCycle.tight_cycle d rr width two (by omega) tight
      have rewrite : bag W+turns ws+F=bag W+turns (u::ws)+R := by
        rw [split,wheel]
        change _=bag W+(↑(GlobalWheelRank.wheel u)+turns ws)+R
        exact move_turn ..
      apply ReferenceSpineOptimum.excludes_5904 (ws:=u::ws) (other:=R)
        (by simp [n]) (by intro v hv; rcases List.mem_cons.mp hv with rfl|hw; exact fullu; exact legit _ hw)
        _ (rewrite ▸ yes)
      rw [←rewrite,Multiset.card_add,Multiset.card_add,data.2.2,turn_count,n]
      omega
    · have one : p.length=1 := by have := List.length_pos_iff.mpr ne; omega
      obtain ⟨e,rfl⟩ := List.length_eq_one_iff.mp one
      have loop : src e=dst e := by
        cases rr with
        | cons _ he tail => cases tail; exact he
      have reform : bag W+turns ws+F = (bag W+turns ws+R)+{e} := by
        rw [split]; exact move_loop _ _ _
      have smaller := SpineWheelTrimming.drop_loop loop (reform ▸ yes)
      exact no_eleven n legit R (by omega) smaller
  · obtain ⟨p,sub,rr⟩ := back
    obtain ⟨R,split⟩ := exists_add_of_le sub
    have sz : p.length+R.card≤11 := by simpa only [split,Multiset.card_add,Multiset.coe_card] using small
    have width (e : Block) (he : e∈p) : e.length=7 :=
      yes.edges_seven e (Multiset.mem_add.mpr (Or.inr
        (Multiset.mem_of_le sub (show e∈(↑p : Multiset Block) from he))))
    rw [split] at together
    exact Packet64.no_reference_return (F:=R) rr width legit n.le sz together
termination_by F.card
decreasing_by rw [split,Multiset.card_add,Multiset.coe_card]; simp

/-- All 720 mandatory rotation classes cannot lie in the same weak component.
Balanced components containing only surplus windows may be disconnected. -/
theorem classes_disconnected {ws : List Block} {F : Multiset Block} {s t : Block}
    (n : ws.length=64) (legit : ∀u∈ws,full u) (small : F.card≤11)
    (width : ∀e∈bag W+turns ws+F,e.length=7)
    (bal : (bag W+turns ws+F).map src+{t}=(bag W+turns ws+F).map dst+{s}) :
    ¬RequiredComponent.ClassesTogether (bag W+turns ws+F) := by
  intro together
  obtain ⟨R,sub,s',t',yes⟩ := SpineWheelTrimming.trim_reference legit width bal together
  exact no_eleven n legit R ((Multiset.card_le_card sub).trans small) yes

/-- Exactly twelve is the minimum number of spare windows when 64 full
turns have been selected in addition to the spine. Other turns may be
present among the spare windows. -/
theorem least_extra : IsLeast {k : Nat | ∃ (ws : List Block) (F : Multiset Block) (s t : Block),
    ws.length=64 ∧ (∀u∈ws,full u) ∧ F.card=k ∧
    (∀e∈bag W+turns ws+F,e.length=7) ∧
    (bag W+turns ws+F).map src+{t}=(bag W+turns ws+F).map dst+{s} ∧
    RequiredComponent.ClassesTogether (bag W+turns ws+F)} 12 := by
  constructor
  · obtain ⟨ws,F,s,t,n,leg,sz,yes,together⟩ := SpineWheelTrimming.twelve_attainable
    exact ⟨ws,F,s,t,n,leg,sz,yes.edges_seven,yes.balance,together⟩
  · rintro k ⟨ws,F,s,t,n,leg,sz,width,bal,together⟩
    by_contra! small
    exact classes_disconnected n leg (by omega) width bal together

/-- All words retaining the W-0021 spine and at least 64 complete turns,
with multiplicity after reserving the mandatory copies. -/
def Keeps64 (w : Block) : Prop :=
  ∃ (ws : List Block) (F : Multiset Block), 64≤ws.length ∧
    (∀u∈ws,full u) ∧ bag w=required+(bag W+turns ws+F)

theorem restricted_minimum :
    (∃ w : Block, Covers w ∧ Keeps64 w ∧ w.length=5905) ∧
    (∀w : Block, Covers w → Keeps64 w → 5905≤w.length) := by
  constructor
  · obtain ⟨w,hw,⟨ws,F,n,leg,eq⟩,sz⟩ := ReferenceSpineOptimum.restricted_minimum.1
    exact ⟨w,hw,⟨ws,F,by omega,leg,eq⟩,sz⟩
  · rintro w hw ⟨ws,F,n,leg,eq⟩
    obtain ⟨l,r,hw'⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
    have long := congrArg List.length hw'
    simp only [List.length_append,List.length_finRange] at long
    obtain ⟨X,ex,cost,yes⟩ := extract_windows_at_ends w hw (by omega)
    have same := add_left_cancel (ex.trans eq)
    subst X
    by_contra! small
    by_cases more : 65≤ws.length
    · exact ReferenceSpineOptimum.excludes_5904 more leg (show (bag W+turns ws+F).card≤858 by omega) yes
    · rw [Multiset.card_add,Multiset.card_add,data.2.2,turn_count] at cost
      exact no_eleven (by omega) leg F (by omega) yes

#print axioms no_eleven
#print axioms classes_disconnected
#print axioms least_extra
#print axioms restricted_minimum
end ExactWordFlow.Reference64

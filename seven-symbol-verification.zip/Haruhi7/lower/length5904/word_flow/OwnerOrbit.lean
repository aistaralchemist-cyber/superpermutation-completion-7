import SevenMoves

namespace ExactWordFlow.SevenMoves
theorem owner_pow (p : X) (n : Nat) : owner (p*t^n)=owner p := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ,←mul_assoc]
    exact (owner_turn _).trans ih

theorem owner_mem (p y : X) (hy : y∈owner p) : owner y=owner p := by
  obtain ⟨a,ha,rfl⟩:=Finset.mem_image.mp hy
  obtain ⟨n,_,rfl⟩:=Finset.mem_image.mp ha
  exact owner_pow p n

#print axioms owner_mem
end ExactWordFlow.SevenMoves

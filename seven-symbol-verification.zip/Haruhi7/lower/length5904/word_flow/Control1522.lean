import CoreControls

namespace ExactWordFlow.Boundary1522
open RotationCoreControls

theorem reference626 :
    summary (coreWord 626)=(1523,720,94) ∧
    summary (coreTruncated 626)=(1522,720,93) := by native_decide

#print axioms reference626
end ExactWordFlow.Boundary1522

import Mathlib.Data.Finset.Basic

namespace ExactWordFlow.CompactFrontPlan

/-- Port 1 is true, ports 2..50 are seven one-hot lanes, and 51..68
are the three bits of each of the six symbols in the context. -/
abbrev Ref := Int
abbrev Ops := Array (List Ref)
abbrev B := StateM Ops

def port (i a : Nat) : Ref := .ofNat (2+7*i+a)
def bitPort (i j : Nat) : Ref := .ofNat (51+3*i+j)

def addOr (args : List Ref) : B Ref := fun ops =>
  (.ofNat (69+ops.size), ops.push args)

def addAnd (args : List Ref) : B Ref := return -(←addOr (args.map (-·)))

structure Indices where
  row : Array Ref
  clean : Ref
  deriving Inhabited

/-- The paid disjunctions are emitted in the same order as the original
word circuit. The possible seventh symbol affects only the last seven gates. -/
def keyPart : B Indices := do
  let miss ← (Array.range 7).mapM fun a => do
    return -(← addOr ((List.range 6).map fun i => port i a))
  let mut pairs := #[]
  for a in [:7] do
    for b in [a+1:7] do pairs := pairs.push (← addAnd [miss[a]!,miss[b]!])
  let clean := -(← addOr pairs.toList)
  let last ← [2,1,0].mapM (fun bit : Nat =>
    addOr (((List.range 7).filter (·.testBit bit)).map fun a => miss[a]!))
  let bs := ((Array.range 6).map fun i => (Array.range 3).map fun bit => bitPort i bit).push last.toArray
  let zeros := ((Array.range 6).map fun i=>port i 0).push miss[0]!
  let mut row := #[-clean]
  for off in [1:7] do
    for bit in [:3] do
      let terms ← (List.range 7).mapM fun j => addAnd [zeros[j]!,bs[(j+off)%7]![bit]!]
      row := row.push (← addOr terms)
  return ⟨row,clean⟩

def template := keyPart.run #[]

def missRef (a : Nat) : Ref := -(.ofNat (69+a))

/-- A missing or out-of-range reference defaults false, as in the circuit
template evaluator. The declared plan only uses previously available ports. -/
def lookup (neg : α → α) (fallback : α) (env : Array α) (ref : Ref) : α :=
  let a := (env[ref.natAbs-1]?).getD fallback
  if ref<0 then neg a else a

def runPure (neg : α → α) (fallback : α) (gate : List α → α) (ports : Array α) (ops : Ops) : Array α :=
  ops.toList.foldl (fun env args => env.push (gate (args.map (lookup neg fallback env)))) ports

def ports (one : α) (letter : Nat→Nat→α) (bin : Nat→Nat→α) : Array α :=
  #[one] ++ (Array.range 7).flatMap (fun i => (Array.range 7).map (letter i)) ++
    (Array.range 6).flatMap (fun i => (Array.range 3).map (bin i))

end ExactWordFlow.CompactFrontPlan

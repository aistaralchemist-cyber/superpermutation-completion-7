import EmbeddedWheels

/-! The path and wheel turns may share vertices and edges. The endpoints
of the total word are independent of the endpoints of the named path. -/
namespace ExactWordFlow.OnePath66
open SevenWordWindows ResidualRoutes ResidualIncidence ResidualDensity DirectedEuler EmbeddedWheels
open scoped Classical

/-- The sole residual component which can contribute positive rank is the
one containing the named path. The global start may even be off this path. -/
theorem path_rank {a b : Block} {es : List Block} (r : Route src dst a es b) (s : Block) :
    separateRank (↑es) s ≤ classCount a es-1 := by
  classical
  let Y : Multiset Block := ↑es
  let D := support Y s
  let g := label Y
  let root := g a
  let row (q : Component Y) := (contacts D g q).card-1
  have same : ∀ e∈es, g (src e)=root := (r.closed {v | g v=root} rfl
      (fun e he hsrc => (on_edge (X:=Y) (e:=e) (show e∈Y from he)).symm.trans hsrc)).2
  have all : (↑es : Multiset Block)=part Y root := by
    change Y=Y.filter (fun e => g (src e)=root)
    symm
    exact Multiset.filter_eq_self.mpr same
  have home : row root ≤ classCount a es-1 := Nat.sub_le_sub_right (contacts_bound D rfl r all) 1
  have away (q) (hq : q∈D.image g) (off : q≠root) : row q=0 := by
    obtain ⟨v,_,hv⟩ := Finset.mem_image.mp hq
    have empty : part Y q=0 := by
      apply Multiset.eq_zero_iff_forall_notMem.mpr
      intro e he
      obtain ⟨member,eq⟩ := in_part.mp he
      exact off (eq.symm.trans (same _ member))
    have count := contacts_bound D hv (Route.nil (src:=src) (dst:=dst) v)
      (show (↑([] : List Block) : Multiset Block)=part Y q from empty.symm)
    have tight : classCount v []≤1 := by
      by_cases fullV : full v <;> simp [classCount,touched,fullV]
    exact Nat.sub_eq_zero_of_le (count.trans tight)
  change ∑ q ∈ D.image g, row q ≤ classCount a es-1
  apply (Finset.sum_le_sum (g:=fun q => if q=root then classCount a es-1 else 0) ?_).trans
  · simp only [Finset.sum_ite_eq',Finset.mem_image]
    split <;> omega
  · intro q hq
    split
    next h => exact h ▸ home
    next h => exact (away q hq h).le

/-- The required permutation edges put every clean state in the support
used for the rank. Consequently no clean class of the path is lost. -/
theorem path_rank_eq {a b : Block} {es : List Block} (r : Route src dst a es b) (s : Block) :
    separateRank (↑es) s = classCount a es-1 := by
  classical
  apply le_antisymm (path_rank r s)
  let Y : Multiset Block := ↑es
  let D := support Y s
  let g := label Y
  let root := g a
  let Q := D.image g
  let F := contacts D g root
  have startSet := (r.closed {v | g v=root} rfl
      (fun e he hsrc => (on_edge (X:=Y) (e:=e) (show e∈Y from he)).symm.trans hsrc)).2
  have allClean (v) (fl : full v) : v∈D := by
    have hs : v∈required.map src := mem_states fl
    have perm : required.map src=required.map dst := balanced_representatives
    rw [perm] at hs
    exact Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr (by
      rw [Multiset.map_add]; exact Multiset.mem_add.mpr (Or.inl hs)))
  have incl : touched (a::es.map dst) ⊆ F := by
    intro c hc
    obtain ⟨v,inList,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hc)
    obtain ⟨atV,y⟩ := List.mem_filter.mp inList
    have fl := of_decide_eq_true y
    have rootV : g v=root := by
      rcases List.mem_cons.mp atV with rfl|rest
      · rfl
      · obtain ⟨e,he,rfl⟩ := List.mem_map.mp rest
        exact (on_edge (X:=Y) (e:=e) he).symm.trans (startSet e he)
    exact Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨allClean v fl,rootV,fl⟩,rfl⟩
  have size : classCount a es≤F.card := Finset.card_le_card incl
  by_cases ok : root∈Q
  · have one := Finset.single_le_sum (s:=Q) (f:=fun q => (contacts D g q).card-1)
        (fun _ _ => Nat.zero_le _) ok
    exact (Nat.sub_le_sub_right size 1).trans one
  · have emp : F=∅ := Finset.eq_empty_iff_forall_notMem.mpr (by
      intro c hc
      obtain ⟨v,hv,_⟩ := Finset.mem_image.mp hc
      obtain ⟨hd,e,_⟩ := Finset.mem_filter.mp hv
      exact ok (Finset.mem_image.mpr ⟨v,hd,e⟩))
    rw [emp,Finset.card_empty] at size
    omega

/-- The literal path has 463 six-letter states. Partition them into eleven
40-state intervals and a final 23-state interval. -/
theorem class_cap {a b : Block} {es : List Block} (r : Route src dst a es b)
    (width : ∀e∈es,e.length=7) (n : es.length=462) : classCount a es≤394 := by
  classical
  obtain ⟨u,I,w,hm,hc⟩ := open_observations r width
  have cap := window_open_bound w hm (interval40 w hm) 0 (es.length+1)
  rw [hc,n] at cap
  exact cap

/-- Any feasible placement of one path of length 462 and 66 complete
wheel turns has one of just five possible path contact counts. -/
theorem contact_range {a b s t : Block} {es ws : List Block}
    (r : Route src dst a es b) (n : es.length=462) (k : ws.length=66)
    (legit : ∀w∈ws, full w) (h : Feasible ((↑es : Multiset Block)+turns ws) s t) :
    390 ≤ classCount a es ∧ classCount a es ≤ 394 ∧
    5*ws.length+separateRank (↑es) s-719 = classCount a es-390 := by
  have lo := residual_rank ws legit h
  change 719≤5*ws.length+separateRank (↑es) s at lo
  have one := path_rank_eq r s
  have hi := class_cap r (fun e he => h.edges_seven e (Multiset.mem_add.mpr (Or.inl he))) n
  omega

#print axioms path_rank
#print axioms contact_range
end ExactWordFlow.OnePath66

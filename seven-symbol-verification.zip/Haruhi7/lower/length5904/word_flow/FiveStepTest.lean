import FiveStepForm
import ExtendedSpineRank
import SpineExtensions

namespace ExactWordFlow.OnePath66
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels

/-- A purely local test on a fixed open word rules out *every* choice of
at most 65 complete wheels and any five additional windows. -/
theorem no_five_of_extension_cap (w : Block) (long : 6≤w.length)
    (ends : w.take 6 ≠ w.drop (w.length-6))
    (classes : classCount (w.take 6) (windows w)=390)
    (bounded : ∀ pre post : Block, pre.length+post.length=5 →
      classCount ((pre++w++post).take 6) (windows (pre++w++post))<395)
    {ws : List Block} (legit : ∀u∈ws,full u) (k : ws.length≤65)
    {fresh : Multiset Block} (size : fresh.card≤5) (s t : Block) :
    ¬Feasible (((↑(windows w) : Multiset Block)+turns ws)+fresh) s t := by
  intro h
  have r := read_route w long
  have together := (RequiredComponent.together_iff_classes _).mp (RequiredComponent.feasible_together h)
  have low := replacement_floor r legit classes k fresh together
  have five : fresh.card=5 := by omega
  obtain ⟨p,q,bag,pre,post⟩ := five_step_form r ends legit classes k fresh five h
  have len := congrArg Multiset.card bag
  simp only [Multiset.coe_card,List.length_append,five] at len
  have need := (extended_spine_exact pre r post classes k legit len (bag ▸ h)).1
  have width (e : Block) (he : e∈p++q) : e.length=7 := by
    apply h.edges_seven
    exact Multiset.mem_add.mpr (Or.inr (bag ▸ (show e∈(↑(p++q) : Multiset Block) from he)))
  obtain ⟨l,rgt,ls,rs,win,first⟩ := spell_extensions w long pre post
    (fun e he => width e (List.mem_append_left _ he)) (fun e he => width e (List.mem_append_right _ he))
  have cap := bounded l rgt (by omega)
  rw [win,first] at cap
  omega

#print axioms no_five_of_extension_cap
end ExactWordFlow.OnePath66

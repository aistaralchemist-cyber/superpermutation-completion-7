import FusedOne294

namespace ExactWordFlow.FusedAny
open SevenWordWindows ResidualDensity ResidualIncidence RotationComponentCount DirectedEuler
open WeightedMarks MarkedGeometry ExtremalRealizations NearRootMoves ShortMarked
open private canonical encode map_tag from Interval66
open private initial start from MarkedDensity
open private win Accepted max_accept dfs dfs_sound footprint mem_foot from FusedRoots294
open private mask_cons from StrongerDensity
open private choose_shift shift_trace from FusedOne294

def check (edges : Nat) (accept : Finset Six→Bool) : Bool :=
  dfs accept edges initial true FusedOne294.base {}

def profileOK (edges goal : Nat) : Bool :=
  (upper (edges+1) initial == goal) && !(win edges initial false)
theorem profile294 : profileOK 294 250=true := by native_decide
theorem profile300 : profileOK 300 255=true := by native_decide

private theorem accepted_start {edges goal : Nat} (short : edges+1≤478) (profile : profileOK edges goal=true)
    {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i : Nat) (many : goal≤count p i (edges+1)) :
    p i ∧ Accepted initial (mask p i (edges+1)) := by
  obtain ⟨size,bad⟩:=Bool.and_eq_true_iff.mp profile
  have cap : upper (edges+1) initial=goal := eq_of_beq size
  let bs := mask p i (edges+1)
  have width : bs.length=(edges+1) := by simp [bs,mask]
  have maximal : upper bs.length initial≤bs.count true := by rw [width,cap,mark_count]; exact many
  have read:=max_accept [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i (edges+1)) maximal
  refine ⟨?_,read⟩
  by_contra fail
  change Accepted initial (mask p i (edges+1)) at read
  rw [mask_cons] at read
  cases read with
  | cons edge _ =>
    have yes : win edges initial false=true := by simpa [mask,fail] using edge
    simp only [yes,Bool.not_true,Bool.false_eq_true] at bad

private theorem selected_accept {edges goal : Nat} (short : edges+1≤478) (profile : profileOK edges goal=true)
    (accept : Finset Six→Bool) (checks : check edges accept=true)
    {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : Nat) (many : goal≤count p i (edges+1)) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ∃k : Nat,accept (applyMoves (List.replicate k 7) ((selectedTags u i (mask p i (edges+1))).toFinset.image (List.map f)))=true := by
  obtain ⟨first,read⟩:=accepted_start short profile w m i many
  let f:=encode (u i)
  have ck : states.all (fun s=>decide (Function.Injective (encode s) ∧ encode s 0=0 ∧
    s.map (encode s)∈canonical))=true := by native_decide
  obtain ⟨inj,z,can⟩:=of_decide_eq_true (List.all_eq_true.mp ck _ (mem_states (m.1 i first)))
  let v (k : Nat):=(u k).map f
  have walk : Walk v := by
    intro j
    obtain ⟨a,eq⟩:=w j
    exact ⟨f a,by simp [v,eq,step,List.map_tail]⟩
  have markv : Marked v p := by
    refine ⟨fun j hj=>⟨by simp [v,(m.1 j hj).1],(m.1 j hj).2.map inj⟩,?_⟩
    intro j k hj hk eq
    apply m.2 j k hj hk
    change tag ((u j).map f)=tag ((u k).map f) at eq
    rw [map_tag f inj z _ (m.1 j hj),map_tag f inj z _ (m.1 k hk)] at eq
    exact List.map_injective_iff.mpr inj eq
  have imageEq : (selectedTags u i (mask p i (edges+1))).toFinset.image (List.map f)=
      (selectedTags v i (mask p i (edges+1))).toFinset := by
    ext c
    simp only [Finset.mem_image,List.mem_toFinset,mem_marked]
    constructor
    · rintro ⟨a,⟨j,hj,hp,rfl⟩,rfl⟩
      exact ⟨j,hj,hp,map_tag f inj z _ (m.1 _ hp)⟩
    · rintro ⟨j,hj,hp,rfl⟩
      exact ⟨tag (u (i+j)),⟨j,hj,hp,rfl⟩,(map_tag f inj z _ (m.1 _ hp)).symm⟩

  obtain ⟨k,hk⟩:=choose_shift _ can
  obtain ⟨t,tw,tm,hbase,tags⟩:=shift_trace k v p walk markv i (edges+1)
  have exactly : t i=FusedOne294.base := hbase.trans hk
  have passed : dfs accept edges initial (decide (p i)) (t i) {}=true := by
    simpa only [check,decide_eq_true first,exactly] using checks
  have cert:=dfs_sound accept tw tm edges initial i {} (by simp) read passed
  have emptyFoot : footprint {}=∅ := by ext x; simp [mem_foot]
  rw [emptyFoot,Finset.union_empty,tags] at cert
  exact ⟨f,inj.bijective_of_finite,z,k,by rwa [imageEq]⟩

open private select from RouteDensity

/-- Literal reachability of a root footprint; the normalization is a single
alphabet bijection fixing zero, as required for transport of the wheel cover. -/
theorem route_coverage {edges goal : Nat} (short : edges+1≤478) (profile : profileOK edges goal=true)
    (accept : Finset Six→Bool) (checks : check edges accept=true)
    {a b : Six} {es : List Six} (r : Route src dst a es b) (width : ∀e∈es,e.length=7)
    (length : es.length+1=(edges+1)) (many : goal≤classCount a es) :
    ∃f : Fin 7→Fin 7, Function.Bijective f ∧ f 0=0 ∧
      ∃k : Nat,accept (applyMoves (List.replicate k 7) ((touched (a::es.map dst)).image (List.map f)))=true := by
  classical
  obtain ⟨u,walk,_,_,eq⟩:=route_walk r width
  rw [length] at eq
  obtain ⟨I,marks,card⟩:=select u (edges+1)
  rw [eq] at card
  have sufficient : goal≤count (·∈I) 0 (edges+1) := by rw [card]; exact many
  obtain ⟨f,bij,z,contains⟩:=selected_accept short profile accept checks walk marks 0 sufficient
  let J := (Finset.range (edges+1)).filter fun j=>j∈I
  have matchSet : (selectedTags u 0 (mask (·∈I) 0 (edges+1))).toFinset=J.image (tag ∘ u) := by
    ext c
    simp only [List.mem_toFinset,mem_marked,Nat.zero_add,Finset.mem_image,J,
      Finset.mem_filter,Finset.mem_range,Function.comp_apply]
    grind
  have subset : J.image (tag ∘ u)⊆touched (a::es.map dst) := by
    intro c hc
    obtain ⟨j,hj,rfl⟩:=Finset.mem_image.mp hc
    obtain ⟨hj,marked⟩:=Finset.mem_filter.mp hj
    change tag (u j)∈touched _
    rw [←eq]
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨u j,List.mem_filter.mpr
      ⟨List.mem_map.mpr ⟨j,Finset.mem_range.mp hj |> List.mem_range.mpr,rfl⟩,decide_eq_true (marks.1 _ marked)⟩,rfl⟩)
  have injective : Set.InjOn (tag ∘ u) J := by
    intro j hj k hk same
    exact marks.2 j k (Finset.mem_filter.mp hj).2 (Finset.mem_filter.mp hk).2 same
  have equal : J.image (tag ∘ u)=touched (a::es.map dst) := by
    apply Finset.eq_of_subset_of_card_le subset
    rw [Finset.card_image_of_injOn injective,←card]
    simp [J,count]
  exact ⟨f,bij,z,by rwa [matchSet,equal] at contains⟩


open RotationCore ExtremeWheelCut SuperpermutationBounds
open private partition wheel_list from HundredDecomposition
open private hits from NearHundredShape
open ResidualRoutes

theorem cover_certificate {edges goal : Nat} (short : edges+1≤478) (profile : profileOK edges goal=true)
    (accept : Finset Six→Bool) (checks : check edges accept=true)
    {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (root : (part X (label X s)).card=edges)
    (colors : goal≤hits X s (label X s))
    (every : ∀q∈occupied X s,(part X q).card=6) :
    ∃R, accept R=true ∧ ∃W⊆allRows, W.card≤(occupied X s).card ∧ SeedWheelCut.ClosedCover R allClasses W := by
  classical
  change goal≤hits X s (label X s) at colors
  obtain ⟨a,b,es,bag,r,eq,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len : es.length=(part X (label X s)).card:=congrArg Multiset.card bag
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have cover : hits X s (label X s)≤classCount s es:=contacts_bound _ eq r bag
  obtain ⟨ws,num,legal,_,packet⟩:=wheel_list (occupied X s) (fun q hq=>MarkedLargeCap.six_component h (Finset.mem_erase.mp hq).1 (every q hq))
  have split:=partition X s
  rw [←bag,←packet] at split
  have fullW (v) (hv : v∈ws) := (legal v hv).1
  have length : es.length+1=(edges+1) := by omega
  have count : goal≤classCount s es := by omega
  obtain ⟨f,bij,zero,k,norm⟩:=route_coverage short profile accept checks r wd length count
  have closed:=WheelRelabel.transport_closed fullW (HundredDecomposition.closed_cover h r fullW split) f bij.1 zero
  let vs:=ws.map (List.map f)
  have legal : vs.toFinset.image WheelContacts.wheel⊆allRows := by
    intro row hr
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hr
    obtain ⟨x,old,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hv)
    have fullX:=fullW x old
    have fullV : full (x.map f) := ⟨by simpa using fullX.1,fullX.2.map bij.1⟩
    obtain ⟨base,admissible,rows⟩:=WheelContacts.complete fullV
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨base,admissible,rows⟩)
  obtain ⟨Z,good,ct,sealed⟩:=transport legal closed (List.replicate k 7)
  exact ⟨_,norm,_,good,ct.trans (Finset.card_image_le.trans ((List.toFinset_card_le vs).trans
    (by simpa [vs] using num.le))),sealed⟩

#print axioms cover_certificate
end ExactWordFlow.FusedAny

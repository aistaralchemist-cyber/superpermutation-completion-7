import WheelContacts
import CoreCounts

namespace ExactWordFlow.LiteralWheelCover
open SevenWordWindows RotationCore RotationReinsert ResidualDensity

abbrev Row := Finset Block

/-- The distinct wheel rows indexed by actual clean six-letter contexts
of this word. Multiple phases or occurrences of one wheel contribute one row. -/
def ready (w : Block) : Finset Row :=
  (((anchors w).filter (fun u=>decide (full u))).map WheelContacts.wheel).toFinset

def condition (w : Block) (k : Nat) : Prop :=
  ∃S : Finset Row,S⊆ready w ∧ S.card≤k ∧ allClasses \ visited w ⊆ S.biUnion id

theorem mem_ready {w : Block} {R : Row} : R∈ready w ↔
    ∃u∈anchors w,full u ∧ WheelContacts.wheel u=R := by
  simp [ready,List.mem_map,List.mem_filter,and_assoc]

/-- The only permitted operation duplicates six consecutive distinct letters.
The list records the rows of the wheels in chronological insertion order. -/
inductive Inserts : Block → List Row → Block → Prop
  | stop (w : Block) : Inserts w [] w
  | add {l u r : Block} {rs : List Row} {z : Block} (clean : full u)
      (rest : Inserts (l++u++u++r) rs z) : Inserts (l++u++r) (WheelContacts.wheel u::rs) z

theorem Inserts.trans {w v z : Block} {rs ts : List Row} (p : Inserts w rs v)
    (q : Inserts v ts z) : Inserts w (rs++ts) z := by
  induction p with
  | stop => exact q
  | add clean _ ih => exact .add clean (ih q)

theorem Inserts.length_eq {w z : Block} {rs : List Row} (p : Inserts w rs z) :
    z.length=w.length+6*rs.length := by
  induction p with
  | stop => simp
  | add clean _ ih =>
    have width:=clean.1
    simp only [List.length_append,List.length_cons] at ih ⊢
    omega

end ExactWordFlow.LiteralWheelCover

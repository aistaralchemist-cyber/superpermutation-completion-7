import ContractedContacts
namespace ExactWordFlow.MultipleRootContacts
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- Two partial seeds that meet share a component. This equivalence is
generated only by the specified contacts, before the unknown suffixes and
all remaining cycles are added. -/
def componentSetoid (E : Finset (Perm X)) (seed : Perm X → Finset Y) : Setoid Y :=
  Relation.EqvGen.setoid (fun a b => ∃c∈E, a∈seed c ∧ b∈seed c)

def component (E : Finset (Perm X)) (seed : Perm X → Finset Y) (y : Y) :
    Quotient (componentSetoid E seed) := Quotient.mk _ y

noncomputable def componentCount (E : Finset (Perm X)) (seed : Perm X→Finset Y) (V : Finset Y) : Nat := by
  classical exact (V.image (component E seed)).card

/-- For every nonexceptional wheel, distinct required seed components
are the only free contacts. All repeated contacts summed over all wheels
and all internal repetitions in E together are bounded by 2g. -/
theorem seed_components {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (seed : Perm X→Finset Y)
    (observed : ∀e∈E,seed e⊆e.support.image tag) :
    (∑c∈h.cycleFactorsFinset,(c.support.card-
      (if c∈E then (c.support.image tag).card else componentCount E seed (c.support.image tag))))≤2*g := by
  classical
  apply contracted_rank start oneOrbit tag onto rot classes genus E known (component E seed)
  intro S closed a b equal yes
  have chain : Relation.EqvGen (fun a b=> ∃c∈E, a∈seed c ∧ b∈seed c) a b := Quotient.exact equal
  have same : a∈S ↔ b∈S := by
    clear yes equal
    induction chain with
    | rel a b joined =>
      obtain ⟨c,hc,ac,bc⟩:=joined
      have aa:=observed c hc ac
      have bb:=observed c hc bc
      exact ⟨fun x=>closed c hc ⟨a,Finset.mem_inter.mpr ⟨x,aa⟩⟩ bb,
        fun x=>closed c hc ⟨b,Finset.mem_inter.mpr ⟨x,bb⟩⟩ aa⟩
    | refl => exact Iff.rfl
    | symm _ _ _ ih => exact ih.symm
    | trans _ _ _ _ _ ab bc => exact ab.trans bc
  exact same.mp yes

#print axioms seed_components
end ExactWordFlow.MultipleRootContacts

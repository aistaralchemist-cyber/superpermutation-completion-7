import CompactWitness

namespace ExactWordFlow.CompactWordCircuit

private def cost : Event → Nat
  | .fresh _ => 0
  | .assertion _ => 1
  | .gateMux .. => 4
  | .gateOr xs => xs.length+1

private theorem rows_cost (x : W) (e : Event) : (localClauses x e).length = cost e := by
  cases e <;> simp [localClauses,cost]

private theorem count_from (es : List Event) (n acc : Nat) :
    es.foldl (fun a e=>a+cost e) acc = acc+(signedRows n es).length := by
  induction es generalizing n acc with
  | nil => simp [signedRows]
  | cons e es ih => simp [signedRows,ih (advance n e),rows_cost,Nat.add_assoc]

theorem header_clause_count (t : Tape) :
    clauseCount t=(signedRows 0 t.body.toList).length := by
  have h := count_from t.body.toList 0 0
  rw [Array.foldl_toList,Nat.zero_add] at h
  exact h

set_option maxRecDepth 100000 in
theorem fixed_header : (goalTape true).vars=1462260 ∧ clauseCount (goalTape true)=5679593 ∧
    (goalTape true).body.size=1497335 := by native_decide

/-- The DIMACS header and the actual signed row list agree on the entire fixed instance. -/
theorem fixed_rows_length : (signedRows 0 (goalTape true).body.toList).length=5679593 :=
  (header_clause_count _).symm.trans fixed_header.2.1

end ExactWordFlow.CompactWordCircuit

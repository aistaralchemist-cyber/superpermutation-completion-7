import DeepBridgeCost
import CanonicalBridgeBoundary

namespace ExactWordFlow.CanonicalCorrectionCap
open SevenWordWindows ResidualDensity RotationComponentCount DeepBridgeComponents

/-- Count F blocks by maximal cyclic runs. In genus zero a mixed run
cannot use the thirty pool tags and then touch the trailing block.
A cycle with no trailing block can use five F blocks. -/
theorem planar_count (lengths : List (Nat × Bool)) {e : Nat}
    (caps : ∀l∈lengths,l.1≤4+l.2.toNat)
    (free : (lengths.map (fun l=>l.2.toNat)).sum+1≤e) :
    (lengths.map Prod.fst).sum≤4*lengths.length+e-1 := by
  have sum_cap (xs : List (Nat × Bool)) (h : ∀l∈xs,l.1≤4+l.2.toNat) :
      (xs.map Prod.fst).sum ≤ 4*xs.length+(xs.map (fun l=>l.2.toNat)).sum := by
    induction xs with
    | nil => simp
    | cons l xs ih =>
      have small:=h l (by simp)
      have rest:=ih (fun k hk=>h k (by simp [hk]))
      simp only [List.map_cons,List.sum_cons,List.length_cons]
      omega
  have :=sum_cap lengths caps
  omega

/-- The projection inequalities keep the actual number of paid endpoints
and the actual number of negative endpoints; replacing either by the cost
upper bound too early loses the effect of a deep bridge. -/
structure BlockProfile (q : Nat) where
  e : Nat
  g : Nat
  p : Nat
  loss : Nat
  runs : Nat
  blocks : List (Nat × Nat)
  paid : ∀b∈blocks,3≤b.2 ∧ b.1≤5
  nonempty : 1≤e
  budget : q+e+(blocks.map (fun b=>b.2-2)).sum+2*g≤140
  score : 719+12*g+6*(e-1)+loss ≤p+5*(q+e+(blocks.map (fun b=>b.2-2)).sum+2*g)
  pool : 6*p≤30*runs+2*g
  planar : g=0 → p≤4*runs+e-1
  regions : p+runs≤blocks.length+e
  separators : runs≤(blocks.filter (fun b=>decide (b.1+1<5*(b.2-2)))).length+e+g
  losses : (blocks.map (fun b=>5*(b.2-2)-(b.1+1))).sum≤loss

theorem expensive_cut {q : Nat} (b : BlockProfile q) (exp : ∃c∈b.blocks,5≤c.2) : q≤94 := by
  obtain ⟨a,d⟩:=DeepBridgeCost.dear_sums b.blocks b.paid exp
  have n:=b.nonempty
  have s:=b.score
  have ct:=b.regions
  have gap:=b.separators
  have lost:=b.losses
  have bound:=b.budget
  have pool:=b.pool
  by_cases flat : b.g=0
  · have := b.planar flat
    omega
  · omega

private theorem zero_interior (vs : List (List Block)) (noDeep : ∀v∈vs,v.length≤4) :
    (vs.map (fun v=>v.length-4)).sum=0 := by
  induction vs with
  | nil => simp
  | cons v vs ih =>
    have first:=noDeep v (by simp)
    have rest:=ih (fun t ht=>noDeep t (by simp [ht]))
    simp [Nat.sub_eq_zero_of_le first,rest]

/-- The trace hypotheses record precisely the start and end of an actual
paid exceptional transition, together with the skipped ordinary positions
obtained by `DeepBridgeComponents.skipped_gates`.  Normal transitions that
belong to an exceptional cycle are permitted; their traces have length two. -/
structure Guarded (W : Finset Block) (v : List Block) where
  x : Block
  y : Block
  a : Fin 7
  b : Fin 7
  px : x∈representatives
  py : y∈representatives
  start : wheelKey x.tail∉W
  finish : wheelKey (y.take 6)∉W
  skipLeft : a=x[0]?.getD 0 → wheelKey (x.rotate 1).tail∉W
  skipRight : b=y[6]?.getD 0 → wheelKey (y.rotate 5).tail∉W
  first : ∀u∈v.take 2,u=x.tail ∨ u=x.tail.tail++[a]
  last : ∀u∈v.drop (v.length-2),u=y.take 6 ∨ u=b::y.take 5

/-- For every residual word graph and every compatible canonical block
profile, all physical ordinary wheels satisfy the bound. No catalogue of
exceptional supports, normalized seeds or endpoint search is required here. -/
theorem wheel_cap {X : Multiset Block} {s t : Block} (flow : Feasible X s t)
    (budget : X.card≤858) (W : Finset Block) (legal : ∀w∈W,w∈WheelContacts.bases)
    (present : ∀w∈W,∀e∈GlobalWheelRank.wheel w,e∈X) (away : wheelKey s∉W)
    (bridges : List (List Block))
    (decompose : ∀e∈X,(∃w∈W,e∈GlobalWheelRank.wheel w) ∨
      ∃v∈bridges,src e∈v ∧ dst e∈v)
    (guard : ∀v∈bridges,Guarded W v) (b : BlockProfile W.card)
    (cost : ∀v∈bridges,5≤v.length → ∃c∈b.blocks,5≤c.2) :
    W.card≤95 ∧ (95≤W.card → ∀c∈b.blocks,c.2≤4) := by
  have short (many : 95≤W.card) : ∀c∈b.blocks,c.2≤4 := by
    intro c hc
    by_contra! long
    have := expensive_cut b ⟨c,hc,long⟩
    omega
  refine ⟨?_,short⟩
  by_contra! many
  have noDeep (v) (hv : v∈bridges) : v.length≤4 := by
    by_contra! long
    obtain ⟨c,hc,dear⟩:=cost v hv long
    have :=short (by omega) c hc
    omega
  have empty : []∉W := by
    intro h
    have illegal : ([] : Block)∉WheelContacts.bases := by native_decide
    exact illegal (legal _ h)
  have bd:=bridge_limit flow budget W legal present away bridges decompose (by
    intro v hv u hu w
    let V:=guard v hv
    exact guarded_bridge empty V.px V.py V.a V.b V.start V.finish V.skipLeft V.skipRight
      V.first V.last hu w)
  rw [zero_interior bridges noDeep] at bd
  omega

#print axioms planar_count
#print axioms expensive_cut
#print axioms wheel_cap
end ExactWordFlow.CanonicalCorrectionCap

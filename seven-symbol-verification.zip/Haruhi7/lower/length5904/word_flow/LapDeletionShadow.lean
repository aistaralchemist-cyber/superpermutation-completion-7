import DeletionShadow

namespace ExactWordFlow.LapDeletionShadow
open SevenWordWindows DeletionShadow

/-- Exactly those six-letter windows whose first symbol comes from the prefix.
A suffix of five letters suffices to determine all of them. -/
private def front : Block → Block → List Block
  | [], _ => []
  | x::xs, t => (x::(xs++t).take 5)::front xs t

private theorem five (xs t : Block) : (xs++t.take 5).take 5=(xs++t).take 5 := by
  simp [List.take_append,List.take_take]

private theorem split (l t : Block) (wide : 5≤t.length) :
    sixWindows (l++t)=front l (t.take 5)++sixWindows t := by
  induction l with
  | nil => rfl
  | cons x xs ih =>
    have size : 5≤xs.length+t.length:=by omega
    simp [sixWindows,front,size,ih,five]

private theorem erase_append (a : Fin 7) (u v : Block) :
    erase a (u++v)=erase a u++erase a v := by simp [erase]

private theorem center : ∀a∈List.finRange 7,∀p∈representatives,
    let q:=erase a p
    let h:=erase a (p.take 6)
    q.length=6 ∧ 5≤h.length ∧ h.take 5=q.take 5 ∧ front q (q.take 5)=turns q := by
  native_decide

/-- Ordered window sequences before and after cutting a literal seven-lap.
The middle six windows are the six rotations in order. All cross-boundary
windows are included in the same 'before' and 'after' lists. -/
theorem ordered (a : Fin 7) (l p r : Block) (hp : p∈representatives) :
    ∃ before after : List Block,
      sixWindows (erase a (l++p++p.take 6++r))=
        before++turns (erase a p)++after ∧
      sixWindows (erase a (l++p.take 6++r))=before++after := by
  let q:=erase a p
  let h:=erase a (p.take 6)
  let left:=erase a l
  let right:=erase a r
  obtain ⟨ql,hl,equal,core⟩:=center a (List.mem_finRange _) p hp
  change q.length=6 at ql
  change 5≤h.length at hl
  change h.take 5=q.take 5 at equal
  change front q (q.take 5)=turns q at core
  have wide : 5≤(h++right).length:=by simp;omega
  have wide' : 5≤(q++(h++right)).length:=by simp;omega
  have head : (h++right).take 5=q.take 5 := by
    simpa [List.take_append, Nat.sub_eq_zero_of_le hl] using equal
  have head' : (q++(h++right)).take 5=q.take 5 := by
    simp [List.take_append,ql]
  refine ⟨front left (q.take 5),sixWindows (h++right),?_,?_⟩
  · simp only [erase_append,List.append_assoc]
    change sixWindows (left++(q++(h++right)))=_
    rw [split left _ wide',split q _ wide,head,head',core]
  · simp only [erase_append,List.append_assoc]
    change sixWindows (left++(h++right))=_
    rw [split left _ wide,head]

def bag (a : Fin 7) (w : Block) : Multiset Block := ↑(sixWindows (erase a w))
def orbit (a : Fin 7) (p : Block) : Multiset Block := ↑(turns (erase a p))

theorem one_lap (a : Fin 7) (l p r : Block) (hp : p∈representatives) :
    bag a (l++p++p.take 6++r) = bag a (l++p.take 6++r) + orbit a p := by
  obtain ⟨b,e,old,cut⟩:=ordered a l p r hp
  unfold bag orbit
  rw [old,cut]
  simp only [←Multiset.coe_add]
  ac_rfl

/-- Actual spelling of a sequence of lap excisions, in the order performed. -/
inductive Cuts : Block → List Block → Block → Prop
  | stop (w : Block) : Cuts w [] w
  | remove {l p r : Block} {ps : List Block} {z : Block} (hp : p∈representatives)
      (rest : Cuts (l++p.take 6++r) ps z) : Cuts (l++p++p.take 6++r) (p::ps) z

theorem many_laps (a : Fin 7) {w z : Block} {ps : List Block} (cuts : Cuts w ps z) :
    bag a w=bag a z+(ps.map (orbit a)).sum := by
  induction cuts with
  | stop => simp
  | remove hp rest ih =>
    rw [one_lap _ _ _ _ hp,ih]
    simp only [List.map_cons,List.sum_cons]
    ac_rfl

#print axioms one_lap
#print axioms many_laps
end ExactWordFlow.LapDeletionShadow

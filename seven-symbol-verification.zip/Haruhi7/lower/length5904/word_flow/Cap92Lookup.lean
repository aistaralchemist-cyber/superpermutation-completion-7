import WheelTable
import Cap92LookCore
import Cap92RowsChecked
import Cap92Hard
import OrientedCNF

namespace ExactWordFlow.Cap92Lookup
open private baseGood from NearBindingCheck
open SevenWordWindows RotationCore NearRootMoves ExtremeWheelCut NearWheelBinding Cap92Catalog
open Cap94Lookup (bits known board_of_known eq_shift unshift)

theorem no_cover {R : Finset Block} (accepted : accept R=true)
    {W : Finset (Finset Block)} (leg : W⊆allRows) (size : W.card≤92) :
    ¬SeedWheelCut.ClosedCover R allClasses W := by
  intro cover
  unfold accept at accepted
  generalize lookup.getD (bits 0 R) (rows.size,7)=ij at accepted
  rcases ij with ⟨i,j⟩
  obtain ⟨hi,hj,eq,knownR⟩:=of_decide_eq_true accepted
  exact WheelTable.reject 92 Cap92Data.hard (by decide) (fun _ m=>Cap92Hard.unsat m)
    rows rows_ok hi hj eq knownR leg size cover

#print axioms no_cover
end ExactWordFlow.Cap92Lookup

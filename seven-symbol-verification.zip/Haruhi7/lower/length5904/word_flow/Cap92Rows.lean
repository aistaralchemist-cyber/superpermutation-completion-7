import NearBindingCheck
import Cap92Data

namespace ExactWordFlow.Cap92Catalog
open SevenWordWindows RotationCore ExtremeWheelCut NearWheelBinding NearRootMoves
open private parse from NearBindingCheck

def rows : Array (Block × Answer) :=
  (((include_str "wheel-roots-92.txt").trimAscii.toString.splitOn "\n").map parse).toArray

end ExactWordFlow.Cap92Catalog

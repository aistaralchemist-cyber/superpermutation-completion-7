import LiteralWheelRows
import WheelAccess

namespace ExactWordFlow.LiteralWheelCover
open SevenWordWindows RotationCore RotationReinsert ResidualDensity WheelAccess

theorem ready_step (l u r : Block) (clean : full u) :
    ready (l++u++u++r)=ready (l++u++r) := by
  ext R
  constructor
  · intro found
    obtain ⟨v,hv,fl,eq⟩:=mem_ready.mp found
    have accessibleBefore := (accessible_step l u r v clean).mp ⟨v,hv,fl,rfl⟩
    obtain ⟨z,hz,fz,ez⟩:=accessibleBefore
    exact mem_ready.mpr ⟨z,hz,fz,ez.trans eq⟩
  · intro found
    obtain ⟨v,hv,fl,eq⟩:=mem_ready.mp found
    have accessibleAfter := (accessible_step l u r v clean).mpr ⟨v,hv,fl,rfl⟩
    obtain ⟨z,hz,fz,ez⟩:=accessibleAfter
    exact mem_ready.mpr ⟨z,hz,fz,ez.trans eq⟩

theorem Inserts.ready_eq {w z : Block} {rs : List Row} (p : Inserts w rs z) :
    ready z=ready w := by
  induction p with
  | stop => rfl
  | add clean _ ih => exact ih.trans (ready_step _ _ _ clean)

theorem Inserts.complete_eq {w z : Block} {rs : List Row} (p : Inserts w rs z) :
    complete z=complete w := by
  induction p with
  | stop => rfl
  | add clean _ ih => exact ih.trans (complete_step _ _ _ clean)

theorem Inserts.visited_eq {w z : Block} {rs : List Row} (p : Inserts w rs z) :
    visited z=visited w ∪ rs.toFinset.biUnion id := by
  induction p with
  | stop => simp
  | add clean _ ih =>
    rw [ih,visited_step _ _ _ clean]
    simp [Finset.union_assoc]

theorem Inserts.rows_ready {w z : Block} {rs : List Row} (p : Inserts w rs z) :
    rs.toFinset⊆ready w := by
  induction p with
  | stop => simp
  | @add l u r rs z clean _ ih =>
    rw [ready_step _ _ _ clean] at ih
    have pos : u∈anchors (l++u++r) := (anchor_iff _ _ clean).mpr ⟨l,r,rfl⟩
    simpa only [List.toFinset_cons,Finset.insert_subset_iff] using
      (And.intro (mem_ready.mpr ⟨u,pos,clean,rfl⟩) ih)

/-- Every prescribed order, including repetitions, can be spelled using
actual consecutive contexts. Each wheel remains available after earlier ones. -/
theorem realizes (w : Block) (rs : List Row) (legal : rs.toFinset⊆ready w) :
    ∃z : Block, Inserts w rs z := by
  induction rs generalizing w with
  | nil => exact ⟨w,.stop w⟩
  | cons R rs ih =>
    obtain ⟨head,tail⟩:=Finset.insert_subset_iff.mp
      (show insert R rs.toFinset⊆ready w by simpa only [List.toFinset_cons] using legal)
    obtain ⟨u,hu,clean,row⟩:=mem_ready.mp head
    obtain ⟨l,r,eq⟩:=(anchor_iff w u clean).mp hu
    subst w
    have legal' : rs.toFinset⊆ready (l++u++u++r) := by rw [ready_step l u r clean]; exact tail
    obtain ⟨z,path⟩:=ih _ legal'
    exact ⟨z,row ▸ Inserts.add clean path⟩

theorem budget_iff (w : Block) (k : Nat) :
    (∃rs z, Inserts w rs z ∧ rs.length≤k ∧ (visited z).card=720) ↔ condition w k := by
  classical
  constructor
  · rintro ⟨rs,z,path,lim,all⟩
    refine ⟨rs.toFinset,path.rows_ready,(List.toFinset_card_le rs).trans lim,?_⟩
    have same := Finset.eq_of_subset_of_card_le (visited_subset z) (by rw [all,board])
    intro c hc
    obtain ⟨inside,missing⟩:=Finset.mem_sdiff.mp hc
    have found : c∈visited z:=same ▸ inside
    rw [path.visited_eq] at found
    exact (Finset.mem_union.mp found).resolve_left missing
  · rintro ⟨S,legal,lim,covered⟩
    obtain ⟨z,path⟩:=realizes w S.toList (by simpa using legal)
    refine ⟨S.toList,z,path,by simpa using lim,?_⟩
    have all : allClasses⊆visited z := by
      intro c hc
      rw [path.visited_eq]
      by_cases seen : c∈visited w
      · exact Finset.mem_union_left _ seen
      · exact Finset.mem_union_right _ (by simpa using covered (Finset.mem_sdiff.mpr ⟨hc,seen⟩))
    rw [Finset.Subset.antisymm (visited_subset z) all,board]

#print axioms realizes
#print axioms budget_iff
end ExactWordFlow.LiteralWheelCover

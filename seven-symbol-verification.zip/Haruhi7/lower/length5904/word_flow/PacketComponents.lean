import CompatiblePackets

namespace ExactWordFlow.PacketComponents
open SevenWordWindows SeedWheelCut ExtremeWheelCut ComplementResidue CompatiblePackets

/-- Two tags share a compatible row if they both survive deletion of a
partial root and the same row has at least five surviving tags. -/
def related (P : Finset Block) (x y : Block) : Prop :=
  ∃w∈allRows,5≤(w\P).card ∧ x∈w\P ∧ y∈w\P

/-- Sum of the residues modulo five of *all* compatible-row component sizes. -/
noncomputable def componentResidue (P : Finset Block) : Nat := by
  classical
  let f:=Quot.mk (related P)
  exact residue f ((allClasses\P).image f) (allClasses\P)

/-- Applies to every prescribed partial root P and its arbitrary extension
A. At zero slack each component has to be topped up by enough new root
tags to leave a multiple of five surviving in that component. -/
theorem all_partial_roots (P A : Finset Block) {W : Finset (Finset Block)}
    (inside : P⊆A) (legal : W⊆allRows) (linked : ClosedCover A allClasses W) :
    P.card+componentResidue P ≤ A.card+4*(A.card+5*W.card-720) := by
  classical
  let f:=Quot.mk (related P)
  apply partial_bound P A f ((allClasses\P).image f) inside legal linked
  intro w hw cap
  have pos : 0<(w\P).card := by omega
  choose p hp using Finset.card_pos.mp pos
  exact ⟨f p,fun x hx=>Quot.sound ⟨w,hw,cap,hx,hp⟩⟩

#print axioms all_partial_roots
end ExactWordFlow.PacketComponents

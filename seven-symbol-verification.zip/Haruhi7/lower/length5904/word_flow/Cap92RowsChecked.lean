import Cap92Rows
namespace ExactWordFlow.Cap92Catalog
open private baseGood from NearBindingCheck
set_option maxHeartbeats 0 in
theorem rows_ok : rows.toList.all (baseGood 92 Cap92Data.hard.toArray)=true := by native_decide
#print axioms rows_ok
end ExactWordFlow.Cap92Catalog

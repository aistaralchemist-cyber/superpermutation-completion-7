import FractionalPacking
namespace ExactWordFlow.FractionalPacking
/-- The same rational packing obstructs arbitrary nonnegative real prices. -/
theorem lower_real {α ι : Type*} [DecidableEq α] [Fintype ι]
    (V P : Finset α) (child : ι→Finset α) (mass : ι→Nat) (N D : Nat)
    (pos : 0<D) (size : ∑i,mass i=N*D)
    (exact : ∀v∈V, (∑i,if v∈child i then mass i else 0)=D)
    (inside : ∀i,child i⊆V) (outer : V⊆P)
    (weight : α→ℝ) (nonneg : ∀v∈P,0≤weight v) (K : ℝ)
    (pay : ∀i,K≤∑v∈child i,weight v) : (N:ℝ)*K≤∑v∈P,weight v := by
  classical
  have expand (i : ι) : (∑v∈V,if v∈child i then (mass i:ℝ)*weight v else 0) =
      (mass i:ℝ)*(∑v∈child i,weight v) := by
    rw [← Finset.sum_filter,Finset.filter_mem_eq_inter,Finset.inter_eq_right.mpr (inside i),
      Finset.mul_sum]
  have bound : (∑i,(mass i:ℝ)*K) ≤ ∑i,(mass i:ℝ)*(∑v∈child i,weight v) :=
    Finset.sum_le_sum (fun i _=>mul_le_mul_of_nonneg_left (pay i) (by positivity))
  have cb : (∑i,(mass i:ℝ)*(∑v∈child i,weight v))=(D:ℝ)*(∑v∈V,weight v) := by
    simp_rw [←expand]
    rw [Finset.sum_comm,Finset.mul_sum]
    refine Finset.sum_congr rfl (fun v hv=>?_ )
    rw [←exact v hv,Nat.cast_sum,Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro i _
    by_cases h : v∈child i <;> simp [h]
  rw [←Finset.sum_mul,←Nat.cast_sum,size,Nat.cast_mul,cb] at bound
  have dpos : 0<(D:ℝ) := by exact_mod_cast pos
  have ls : (D:ℝ)*((N:ℝ)*K)≤(D:ℝ)*(∑v∈V,weight v) := by linarith only [bound, mul_assoc (N:ℝ) (D:ℝ) K, mul_comm (N:ℝ) (D:ℝ), mul_assoc (D:ℝ) (N:ℝ) K]
  exact (le_of_mul_le_mul_left ls dpos).trans (Finset.sum_le_sum_of_subset_of_nonneg outer fun i hi _=>nonneg i hi)
end ExactWordFlow.FractionalPacking

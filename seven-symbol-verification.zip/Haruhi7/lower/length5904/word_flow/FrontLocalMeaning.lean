import CompactFrontPlan
import CoreRecordBits

namespace ExactWordFlow.FrontLocalMeaning
open SevenWordWindows ResidualDensity SortedCoreRecords CoreRecordBits CompactFrontPlan

def inputPorts (u : Block) : Array Bool := ports true
  (fun i a => decide ((u[i]?).map Fin.val = some a))
  (fun i j => ((u[i]?).map (fun s => s.val.testBit (2-j))).getD false)

def environment (u : Block) := runPure (!·) false (fun bs => bs.any id) (inputPorts u) template.2

def read (u : Block) := lookup (!·) false (environment u)

/-- All key gates, the intermediate clean flag and the seven referenced
missing indicators are checked together for each concrete six-symbol input. -/
def correct (u : Block) : Bool := Id.run do
  let env := environment u
  let v := lookup (!·) false env
  return (template.1.row.map v).toList == keyWires u &&
    v template.1.clean == clean u &&
    (List.finRange 7).all fun a => v (missRef a) == missing u a

open private blocks enumerated from CoreRecordBits
private theorem table : (blocks 6).all correct = true := by native_decide

theorem local_meaning {u : Block} (len : u.length=6) :
    (template.1.row.map (read u)).toList = keyWires u ∧
    read u template.1.clean = clean u ∧ ∀a : Fin 7,read u (missRef a)=missing u a := by
  have ok := List.all_eq_true.mp table u (len ▸ enumerated u)
  change ((_ && _) && _)=true at ok
  obtain ⟨⟨eq,cl⟩,all⟩ := (and_congr Bool.and_eq_true_iff Iff.rfl).mp (Bool.and_eq_true_iff.mp ok)
  exact ⟨beq_iff_eq.mp eq,beq_iff_eq.mp cl,fun a=>beq_iff_eq.mp (List.all_eq_true.mp all a (List.mem_finRange _))⟩

#print axioms local_meaning
end ExactWordFlow.FrontLocalMeaning

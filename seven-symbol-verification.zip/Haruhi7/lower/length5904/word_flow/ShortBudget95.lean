import NearHundredShape
import Transfer5901

namespace ExactWordFlow.ShortBudget95
open SevenWordWindows SuperpermutationBounds ResidualDensity RotationSpan RotationComponentCount
open RotationCore CoreAssembly
open private required_data from ResidualIncidence

/-- Even without any orientation search, fewer than 858 supplementary edges
cannot support 96 occupied nonroot components, since the near-extreme
equalities would force all 858 edges to be spent. -/
theorem component_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤857) : (occupied X s).card≤95 := by
  by_contra! many
  have exactSize:=(NearHundredShape.near_shape h (by omega) (by omega)).1
  omega

/-- For every actual full-word length ceiling at most 5,903 the exact
core decision already requires only 95 completed classes. -/
theorem exact_below_5904 {n : Nat} (upper : n≤5903) :
    (∃w : Block,Covers w ∧ w.length≤n) ↔
    ∃v : Block,6≤v.length ∧ v.length+4375≤n ∧ (visited v).card=720 ∧ 95≤(complete v).card := by
  constructor
  · rintro ⟨w,cover,limit⟩
    obtain ⟨l,r,word⟩:=cover (List.finRange 7) List.length_finRange (List.nodup_finRange _)
    obtain ⟨X,size,h⟩:=extract_at_ends w cover (by simp [word];omega)
    obtain ⟨S,sub,length,span⟩:=spanning h
    have amount:=component_limit h (by omega)
    have hit (c) (hc : c∈allClasses) : ∃u,full u ∧ tag u=c ∧
        ResidualRoutes.label (selected X S) u=ResidualRoutes.label (selected X S) (w.take 6) := by
      obtain ⟨u,hu,clean,key⟩:=every_tag h hc
      exact ⟨u,clean,key,span u hu⟩
    have must (p) (hp : p∈representatives) (want : classKey p∈S) :
        ResidualRoutes.label (selected X S) (src p)=ResidualRoutes.label (selected X S) (w.take 6) := by
      obtain ⟨u,hu,clean,key⟩:=every_tag h (sub want)
      have tab : ∀p∈representatives,tag (src p)=classKey p := by native_decide
      have here:=tab p hp
      exact (join_same (required_data p hp).1 clean (here.trans key.symm) (here ▸ want)).trans (span u hu)
    obtain ⟨v,long,len,all,done⟩:=CoreAssembly.target h sub (length.trans amount) (by decide) hit must
    exact ⟨v,long,by omega,all,done⟩
  · rintro ⟨v,long,len,all,done⟩
    obtain ⟨w,cover,size⟩:=expand_remaining long all
    exact ⟨w,cover,by omega⟩

/-- Explicit point of entry for the published 5,901 lower bound. If a
95-completion decision word uses at most 1,529 letters, its length is at
least 1,526 and it completes exactly 95 classes. -/
theorem floor_transfer (lower : Transfer5901.WordFloor 5901) {v : Block}
    (long : 6≤v.length) (small : v.length≤1529) (all : (visited v).card=720)
    (done : 95≤(complete v).card) : 1526≤v.length ∧ (complete v).card=95 := by
  obtain ⟨w,cover,sz⟩:=expand_remaining long all
  have floor:=lower w cover
  omega

theorem reference625 :
    RotationCoreControls.summary (RotationCoreControls.coreWord 625)=(1530,720,95) ∧
    RotationCoreControls.summary (RotationCoreControls.coreTruncated 625)=(1529,720,94) := by native_decide

#print axioms exact_below_5904
#print axioms floor_transfer
#print axioms reference625
end ExactWordFlow.ShortBudget95

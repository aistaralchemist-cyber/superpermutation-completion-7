import PooledRootClosure

namespace ExactWordFlow.MultipleRootContacts
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- The same operation as the concrete wheel closure, on any named board. -/
noncomputable def forceRows (rows : Finset (Finset Y)) (P : Finset Y) : Finset Y := by
  classical
  exact P∪Finset.univ.filter fun j=>∀w∈rows,j∈w → 2≤(w∩P).card

/-- One fixed defect D works for every choice of pooled seed and every
iteration, even when the exceptional cycles are disconnected. -/
theorem pooled_force_iterate {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (nonempty : E.Nonempty)
    (six : ∀w∈h.cycleFactorsFinset,w∉E → w.support.card=6)
    (rows : Finset (Finset Y)) (legal : ∀w∈h.cycleFactorsFinset,w∉E → w.support.image tag∈rows) :
    let U:=E.biUnion fun c=>c.support.image tag
    ∃D : Finset Y, Disjoint D U ∧
      4*(∑c∈E,c.support.card)+D.card+4≤4*U.card+4*E.card+8*g ∧
      ∀P⊆U, ∀n : Nat, ((fun A=>forceRows rows A \ D)^[n]) P⊆U := by
  classical
  let T (w : Perm X):=w.support.image tag
  let U:=E.biUnion T
  let H:=h.cycleFactorsFinset
  let W:=(H \ E).filter fun w=>2≤(T w∩U).card
  let D:=W.biUnion fun w=>T w \ U
  have inc (w) (hw : w∈W) : w∈H ∧ w∉E:=Finset.mem_sdiff.mp (Finset.mem_filter.mp hw).1
  have cap:=pooled_wheels start oneOrbit tag onto rot classes genus E W known nonempty
    (fun w hw=>(inc w hw).1) (Finset.disjoint_left.mpr (fun {_} he hw=>(inc _ hw).2 he))
    (fun w hw=>six w (inc w hw).1 (inc w hw).2) (fun _ hw=>(Finset.mem_filter.mp hw).2)
  change (∑c∈E,c.support.card)+W.card+1≤U.card+E.card+2*g ∧ D.card≤4*W.card at cap
  refine ⟨D,Finset.disjoint_left.mpr ?_,by change 4*(∑c∈E,c.support.card)+D.card+4≤4*U.card+4*E.card+8*g; omega,?_⟩
  · intro j hd hu
    obtain ⟨w,_,hj⟩:=Finset.mem_biUnion.mp hd
    exact (Finset.mem_sdiff.mp hj).2 hu
  have step {P : Finset Y} (inside : P⊆U) : forceRows rows P \ D⊆U:=by
    intro j hj
    obtain ⟨hj,nod⟩:=Finset.mem_sdiff.mp hj
    by_contra off
    rcases Finset.mem_union.mp hj with old|blocked
    · exact off (inside old)
    obtain ⟨w,hw,hit⟩:=tag_covered start oneOrbit tag onto rot classes j
    have ordinary : w∉E:=fun he=>off (Finset.mem_biUnion.mpr ⟨w,he,hit⟩)
    have low:=(Finset.mem_filter.mp blocked).2 _ (legal w hw ordinary) hit
    have member : w∈W:=Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨hw,ordinary⟩,
      low.trans (Finset.card_le_card (Finset.inter_subset_inter_left inside))⟩
    exact nod (Finset.mem_biUnion.mpr ⟨w,member,Finset.mem_sdiff.mpr ⟨hit,off⟩⟩)
  intro P inside n
  induction n with
  | zero => exact inside
  | succ n ih =>
    rw [Function.iterate_succ_apply']
    exact step ih

#print axioms pooled_force_iterate
end ExactWordFlow.MultipleRootContacts

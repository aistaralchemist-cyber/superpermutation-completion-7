import MarkedLargeCap

namespace ExactWordFlow.ComponentCurve
open SevenWordWindows ResidualDensity ResidualRoutes ResidualIncidence RotationSpan
open RotationComponentCount RotationCore SuperpermutationBounds CoreAssembly
open private required_data from ResidualIncidence
open private add_to control_counts from CompletionCurve

private theorem rooted_bound (m : Nat) (limit : ∀{X : Multiset Block} {s t : Block}, Feasible X s t → X.card≤858 → (occupied X s).card ≤ m) {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) : ∃S⊆allClasses, S.card ≤ m ∧
      (∀c∈allClasses, ∃u, full u ∧ tag u=c ∧ label (selected X S) u=label (selected X S) s) ∧
      (∀p∈representatives, classKey p∈S → label (selected X S) (src p)=label (selected X S) s) := by
  obtain ⟨S,sub,size,span⟩:=spanning h
  have count := limit h budget
  refine ⟨S,sub,size.trans count,?_,?_⟩
  · intro c hc
    obtain ⟨u,hu,clean,key⟩:=every_tag h hc
    exact ⟨u,clean,key,span u hu⟩
  · intro p hp inS
    have inBoard:=sub inS
    obtain ⟨u,hu,clean,key⟩:=every_tag h inBoard
    have tab : ∀p∈representatives,tag (src p)=classKey p := by native_decide
    have here:=tab p hp
    exact (join_same (required_data p hp).1 clean (here.trans key.symm) (here ▸ inS)).trans (span u hu)


/-- The last noninitial disjoint lap of W-0021 leaves 67 completed classes. -/
theorem reference653 :
    RotationCoreControls.summary (RotationCoreControls.coreWord 653)=(1334,720,67) := by
  native_decide

theorem completion_curve {m : Nat} (cap : ∀{X : Multiset Block} {s t : Block}, Feasible X s t → X.card≤858 → (occupied X s).card ≤ m)
    (k : Nat) (base : 67≤k) (lo : m≤k) (hi : k≤720) :
    IsLeast (lengthsFor k) (SuperpermBridge.HR.Ssuper 7-7*(720-k)) := by
  have bound {v : Block} (long : 6≤v.length) (all : (visited v).card=720)
      (done : k≤(complete v).card) : SuperpermBridge.HR.Ssuper 7 ≤ v.length+7*(720-k) := by
    obtain ⟨w,hw,sz⟩ := expand_remaining long all
    have best := SuperpermBridge.ssuper_le_length hw
    omega
  constructor
  · obtain ⟨w,hw,sz⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
    by_cases small : w.length≤5904
    · obtain ⟨p,q,occ⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
      obtain ⟨X,cost,h⟩ := extract_at_ends w hw (by simp [occ]; omega)
      obtain ⟨S,legal,limit,hit,root⟩ := rooted_bound m cap h (by omega)
      obtain ⟨z,long,len,all,done⟩ := CoreAssembly.target h legal (limit.trans lo) hi hit root
      have min := bound long all done
      exact ⟨z,long,all,done,by omega⟩
    · have up := SuperpermBridge.ssuper_le_length SuperpermLowerBounds.LengthBudget.Word5905.covers
      rw [SuperpermLowerBounds.LengthBudget.Word5905.length_5905] at up
      obtain ⟨len,va,dc⟩ := control_counts reference653
      obtain ⟨z,long,seen,done,size⟩ := add_to base hi (w:=RotationCoreControls.coreWord 653)
        (by omega) va dc.ge
      have min := bound long seen done
      exact ⟨z,long,seen,done,by omega⟩
  · rintro n ⟨v,long,all,done,rfl⟩
    have min := bound long all done
    omega

/-- The feasible-length decision at any certified component threshold. -/
theorem exact_threshold {m k : Nat} (cap : ∀{X : Multiset Block} {s t : Block},
    Feasible X s t → X.card≤858 → (occupied X s).card ≤ m) (lo : m≤k) (hi : k≤720) :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
      ∃v : Block,6≤v.length ∧ v.length≤864+7*k ∧ (visited v).card=720 ∧ k≤(complete v).card := by
  constructor
  · rintro ⟨w,hw,small⟩
    obtain ⟨a,b,hword⟩:=hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
    obtain ⟨X,cost,h⟩:=extract_at_ends w hw (by simp [hword]; omega)
    obtain ⟨S,sub,num,hit,must⟩:=rooted_bound m cap h (by omega)
    obtain ⟨v,long,room,all,done⟩:=CoreAssembly.target h sub (num.trans lo) hi hit must
    exact ⟨v,long,by omega,all,done⟩
  · rintro ⟨v,long,room,all,done⟩
    obtain ⟨w,hw,sz⟩:=expand_remaining long all
    exact ⟨w,hw,by omega⟩

end ExactWordFlow.ComponentCurve

import BypassPackets
import EmbeddedWheels

/-! Removing a single edge of a closed packet incident with an endpoint
preserves every prescribed window, allowing that endpoint to move. -/
namespace ExactWordFlow.EndpointSaving
open Essential ResidualRoutes SevenWordWindows SuperpermutationBounds

private theorem step_bypass {A B : Multiset Block} {e : Block}
    (bal : Balanced (B+{e})) :
    label (required+(A+B)) (src e)=label (required+(A+B)) (dst e) := by
  have eq : B.map src+{src e}=B.map dst+{dst e} := by
    simpa [Essential.Balanced] using bal
  have link := (endpoints eq).symm
  let S : Set Block := {v | label (required+(A+B)) v=label (required+(A+B)) (src e)}
  have bi (f) (hf : f∈B) : src f∈S ↔ dst f∈S := by
    change _=_ ↔ _=_
    rw [on_edge (X:=required+(A+B)) (Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inr hf))))]
  exact ((invariant S bi link).mp rfl).symm

private theorem lift_balance {Y : Multiset Block} {s t : Block}
    (bal : Y.map src+{t}=Y.map dst+{s}) :
    (required+Y).map src+{t}=(required+Y).map dst+{s} := by
  rw [Multiset.map_add,Multiset.map_add,show required.map src=required.map dst from balanced_representatives,add_assoc,add_assoc,bal]

private theorem move {Y : Multiset Block} {e s t s' t' : Block}
    (h : Feasible (Y+{e}) s t) (six : s'.length=6)
    (bal : Y.map src+{t'}=Y.map dst+{s'})
    (initial : label (required+Y) s'=label (required+Y) s)
    (bypass : label (required+Y) (src e)=label (required+Y) (dst e)) : Feasible Y s' t' := by
  refine ⟨six,fun f hf => h.edges_seven f (Multiset.mem_add.mpr (Or.inl hf)),bal,?_⟩
  intro S hs closed f hf
  have bi := (restrictBalance hs (lift_balance bal) closed).2.1
  refine h.reachable S ((invariant S bi initial).mp hs) ?_ f ?_
  · intro q hq hsrc
    rw [←add_assoc] at hq
    rcases Multiset.mem_add.mp hq with keep|del
    · exact closed q keep hsrc
    · have qe : q=e := by simpa using del
      subst q
      exact (invariant S bi bypass).mp hsrc
  · rw [←add_assoc]
    exact Multiset.mem_add.mpr (Or.inl hf)

/-- A closed subpacket with a step out of the starting state permits a
one-letter saving, even if every other step of the packet remains necessary. -/
theorem peel_start {A B : Multiset Block} {e t : Block} (circulation : Balanced (B+{e}))
    (h : Feasible ((A+B)+{e}) (src e) t) : Feasible (A+B) (dst e) t := by
  have em : e∈(A+B)+{e} := Multiset.mem_add.mpr (Or.inr (by simp))
  have wide := h.edges_seven e em
  have eq := h.balance
  simp only [Multiset.map_add,Multiset.map_singleton] at eq
  have bal : (A+B).map src+{t} = (A+B).map dst+{dst e} :=
    add_right_cancel (b:=({src e} : Multiset Block)) (by simpa only [Multiset.map_add,add_assoc,add_comm,add_left_comm] using eq)
  have link := step_bypass (A:=A) circulation
  exact move h (by simp [dst,wide]) bal link.symm link

/-- The corresponding one-letter saving at the terminal state. -/
theorem peel_end {A B : Multiset Block} {e s : Block} (circulation : Balanced (B+{e}))
    (h : Feasible ((A+B)+{e}) s (dst e)) : Feasible (A+B) s (src e) := by
  have eq := h.balance
  simp only [Multiset.map_add,Multiset.map_singleton] at eq
  have bal : (A+B).map src+{src e} = (A+B).map dst+{s} :=
    add_right_cancel (b:=({dst e} : Multiset Block)) (by simpa only [Multiset.map_add,add_assoc,add_comm,add_left_comm] using eq)
  exact move h h.start_six bal rfl (step_bypass circulation)

/-- Any positive circulation in the extra multiset having a step out of
the start or into the end gives an actual one-letter shorter word. -/
theorem packet_saves_one {A W : Multiset Block} {s t : Block}
    (cycle : Essential.Balanced W) (h : Feasible (A+W) s t)
    (hit : s∈W.map src ∨ t∈W.map dst) :
    ∃ v : Word, Covers v ∧ v.length+1=(A+W).card+5046 := by
  classical
  have split (e) (he : e∈W) : W.erase e+{e}=W := by
    rw [add_comm,Multiset.singleton_add,Multiset.cons_erase he]
  have smaller (e) (he : e∈W) (u z) (good : Feasible (A+W.erase e) u z) :
      ∃ v : Word, Covers v ∧ v.length+1=(A+W).card+5046 := by
    obtain ⟨v,cv,len⟩ := (word_iff_flow ((A+W.erase e).card+5046) (by omega)).mpr
      ⟨A+W.erase e,u,z,by omega,good⟩
    have count := Multiset.card_erase_add_one he
    simp only [Multiset.card_add] at len ⊢
    exact ⟨v,cv,by omega⟩
  rcases hit with start | finish
  · obtain ⟨e,he,rfl⟩ := Multiset.mem_map.mp start
    apply smaller e he (dst e) t
    apply peel_start (A:=A) (B:=W.erase e) (by rwa [split e he])
    rwa [add_assoc,split e he]
  · obtain ⟨e,he,rfl⟩ := Multiset.mem_map.mp finish
    apply smaller e he s (src e)
    apply peel_end (A:=A) (B:=W.erase e) (by rwa [split e he])
    rwa [add_assoc,split e he]

private theorem split_state {u : Block} {n : Nat} (h : u.length=n+1) :
    ∃ a v, u=a::v ∧ v.length=n := by
  obtain ⟨a,v,rfl⟩ := List.exists_cons_of_length_eq_add_one h
  exact ⟨a,v,rfl,by simpa using h⟩

theorem single_balance {u : Block} (legal : ResidualDensity.full u) :
    Balanced (↑(GlobalWheelRank.wheel u) : Multiset Block) := by
  have len := legal.1
  obtain ⟨a,u0,rfl,ha⟩ := split_state (n:=5) len
  obtain ⟨b,u1,rfl,hb⟩ := split_state (n:=4) ha
  obtain ⟨c,u2,rfl,hc⟩ := split_state (n:=3) hb
  obtain ⟨d,u3,rfl,hd⟩ := split_state (n:=2) hc
  obtain ⟨e,u4,rfl,he⟩ := split_state (n:=1) hd
  obtain ⟨f,u5,rfl,hf⟩ := split_state (n:=0) he
  have eu : u5=[] := List.length_eq_zero_iff.mp hf
  subst u5
  exact turn6_balance a b c d e f

theorem turns_balance (ws : List Block) (legit : ∀w∈ws,ResidualDensity.full w) :
    Balanced (EmbeddedWheels.turns ws) := by
  induction ws with
  | nil => rfl
  | cons w ws ih =>
    have one := single_balance (legit w List.mem_cons_self)
    have tail := ih (fun z hz => legit z (List.mem_cons_of_mem _ hz))
    change ((↑(GlobalWheelRank.wheel w) : Multiset Block)+EmbeddedWheels.turns ws).map src =
      ((↑(GlobalWheelRank.wheel w) : Multiset Block)+EmbeddedWheels.turns ws).map dst
    rw [Multiset.map_add,Multiset.map_add,one,tail]

/-- Each ordinary six-wheel through either actual six-letter endpoint
allows a shortening. The wheel need not be a separate component. -/
theorem wheel_saves_one {A : Multiset Block} {u s t : Block} (legal : ResidualDensity.full u)
    (h : Feasible (A+(↑(GlobalWheelRank.wheel u) : Multiset Block)) s t)
    (touches : s∈(GlobalWheelRank.wheel u).map src ∨ t∈(GlobalWheelRank.wheel u).map dst) :
    ∃ v : Word, Covers v ∧ v.length+1=(A+(↑(GlobalWheelRank.wheel u) : Multiset Block)).card+5046 := by
  apply packet_saves_one (A:=A) (W:=↑(GlobalWheelRank.wheel u)) _ h
  · simpa using touches
  · exact single_balance legal

#print axioms packet_saves_one
#print axioms wheel_saves_one
#print axioms peel_start
#print axioms peel_end
end ExactWordFlow.EndpointSaving

import WheelBaseResidual
import SixProjection

namespace ExactWordFlow.BaseSixOverlap
open DirectedEuler SevenWordWindows SuperpermutationBounds ResidualDensity RotationCore RotationReinsert
open WheelBaseResidual SixProjection LiteralWheelCover
open private width perms6 perm_mem recode from SixProjection

/-- Minimal number of added letters for a suffix-prefix overlap of two six-words. -/
def gap (x y : SixWord) : Nat :=
  ((List.range 7).find? fun k=>decide (x.drop k=y.take (6-k))).getD 6

def stepCost (g:Fin 7) (e:Block) := gap (project g (src e)) (project g (dst e))
def cost (g:Fin 7) (w:Block) := ((windows w).map (stepCost g)).sum

private theorem join_gap (x y:SixWord) (sy:y.length=6) : Join x y (gap x y) := by
  unfold gap
  generalize eq : (List.range 7).find? (fun k =>decide (x.drop k=y.take (6-k)))=found
  cases found with
  | none => exact ⟨y,x,sy,rfl⟩
  | some k =>
    have h : x.drop k=y.take (6-k):=of_decide_eq_true (List.find?_some (p:=fun i=>decide (x.drop i=y.take (6-i))) eq)
    have bound:=List.mem_range.mp (List.mem_of_find?_eq_some eq)
    refine ⟨y.drop (6-k), x.take k, by simp [sy];omega,?_⟩
    calc
      x++y.drop (6-k) = (x.take k++x.drop k)++y.drop (6-k) := by rw [List.take_append_drop]
      _ = x.take k++y := by rw [h,List.append_assoc,List.take_append_drop]

private def tagImage (g : Fin 7) (c : Block) :=
  ((c.rotate (c.idxOf g+1)).take 6).map (recode g)

private theorem labels : ∀g : Fin 7, (∀u∈states,tagImage g (tag u)=project g u) ∧
    perms6.toFinset⊆allClasses.image (tagImage g) := by native_decide

private theorem spell_all {s t : Block} {es : List Block} (r:Route src dst s es t)
    (g:Fin 7) (wd:∀e∈es,e.length=7):
    ∃tail:SixWord, tail.length=(es.map (stepCost g)).sum ∧
      ∀u∈s::es.map dst,project g u <:+: project g s++tail := by
  induction r with
  | nil => exact ⟨[],rfl,by simp⟩
  | @cons x y es e hs path ih =>
    obtain ⟨z,lz,all⟩:=ih (fun k hk=>wd k (List.mem_cons_of_mem _ hk))
    have le:=wd _ List.mem_cons_self
    obtain ⟨a,b,la,eq⟩:=join_gap (project g (src e)) (project g (dst e)) (width g (by simp [dst,le]))
    change a.length=stepCost g e at la
    rw [hs] at eq
    refine ⟨a++z,by simp [la,lz],?_⟩
    intro u hu
    rcases List.mem_cons.mp hu with rfl|rest
    · exact (List.prefix_append ..).isInfix
    · obtain ⟨l,v,h⟩:=all u rest
      refine ⟨b++l,v,?_⟩
      rw [←List.append_assoc,eq]
      simpa only [List.append_assoc] using congrArg (b++·) h

/-- This lower bound applies already to the reduced word before any seven-laps
are reinserted. It only needs all 720 visits, and allows free endpoints. -/
theorem floor (g:Fin 7) {v:Block} (long:6≤v.length) (covered:(visited v).card=720) :
    864≤cost g v := by
  have all:=Finset.eq_of_subset_of_card_le (visited_subset v) (by rw [board,covered])
  obtain ⟨tail,len,occ⟩:=spell_all (read_route v long) g (fun _ he=>window_width v he)
  have cov : Covers (project g (v.take 6)++tail) := by
    intro p lp nd
    obtain ⟨c,hc,key⟩:=Finset.mem_image.mp ((labels g).2 (List.mem_toFinset.mpr (perm_mem lp nd)))
    obtain ⟨u,hu,fu,kt⟩:=(mem_visited _ _).mp (all ▸ hc)
    have cur:=occ u hu
    rw [←(labels g).1 u (mem_states fu),kt,key] at cur
    obtain ⟨l,r,eq⟩:=cur
    exact ⟨l,r,eq.symm⟩
  have z:=SuperpermLowerBounds.superperm_kisic_numerical_bounds.2.1.trans
    (SuperpermBridge.ssuper_le_length cov)
  have init : (project g (v.take 6)).length=6:=width g (by simp;omega)
  rw [List.length_append,init,len] at z
  unfold cost
  omega

private theorem wheel_cost : ∀u∈states, ∀g:Fin 7,
    ((GlobalWheelRank.wheel u).map (stepCost g)).sum=if g∈u then 35 else 6 := by native_decide

theorem sharp {b v : Block} {rs : List Row} (ins:Inserts b rs v)
    (boardV:(visited v).card=720) (long:6≤v.length):
    ∃ws : List Block,ws.map WheelContacts.wheel=rs ∧ (∀u∈ws,full u) ∧
      ∀g:Fin 7, 864≤cost g b+6*ws.length+29*(ws.filter (fun u=>decide (g∈u))).length := by
  obtain ⟨ws,rows,nRows,clean,bags⟩:=inserted_turns_rows ins
  refine ⟨ws,rows,clean,fun g=>?_⟩
  have turn : ((EmbeddedWheels.turns ws).map (stepCost g)).sum=
      6*ws.length+29*(ws.filter fun u=>decide (g∈u)).length := by
    clear rows bags nRows
    induction ws with
    | nil => simp [EmbeddedWheels.turns]
    | cons u ws ih =>
      have cu:=clean u List.mem_cons_self
      have tail:=ih (fun a ha=>clean a (List.mem_cons_of_mem _ ha))
      have eq : EmbeddedWheels.turns (u::ws)=↑(GlobalWheelRank.wheel u)+EmbeddedWheels.turns ws := rfl
      rw [eq,Multiset.map_add,Multiset.sum_add,Multiset.map_coe,Multiset.sum_coe,wheel_cost u (mem_states cu),tail]
      by_cases mem : g∈u <;> simp [mem] <;> omega
  have h:=floor g long boardV
  have sum := congrArg (fun Q:Multiset Block=>(Q.map (stepCost g)).sum) bags
  simp only [bag,Multiset.map_coe,Multiset.sum_coe,Multiset.map_add,Multiset.sum_add,turn] at sum
  unfold cost at h ⊢
  omega

/-- A zero-wheel candidate has to pay the six-superpermutation floor for each
of the seven distinguished symbols even before expansion. -/
theorem zero (g:Fin 7) {b:Block} (fit:condition b 0) (long:6≤b.length) :
    864≤cost g b := by
  obtain ⟨rs,v,ins,sz,boardV⟩:=(budget_iff b 0).mpr fit
  have nil : rs=[]:=List.length_eq_zero_iff.mp (by omega)
  have eq:=ins.visited_eq
  rw [nil] at eq
  simp only [List.toFinset_nil,Finset.biUnion_empty,Finset.union_empty] at eq
  exact floor g long (eq ▸ boardV)

def prices (w : Block) := (List.finRange 7).map (fun g=>cost g w)
def referencePrices := [4265,4513,4443,4443,4725,4839,2309]

/-- The six-word projection tests do not see the lost completion when the
old 1509-letter record control is truncated to 1508 letters. -/
theorem controls :
    prices (RotationCoreControls.coreWord 628)=referencePrices ∧
    prices (RotationCoreControls.coreTruncated 628)=referencePrices := by native_decide

#print axioms controls
#print axioms sharp
#print axioms zero
end ExactWordFlow.BaseSixOverlap

import ActualPackingCost
import Mathlib.GroupTheory.Perm.Fin
import Mathlib.GroupTheory.Perm.Cycle.Concrete
import Mathlib.Data.Fintype.Perm
import Mathlib.Logic.Equiv.Fin.Rotate

namespace ExactWordFlow.SevenMoves
open Equiv

abbrev X := Perm (Fin 7)
abbrev Y := Perm (Fin 6)
def r : X := finRotate 7
def t : X := List.formPerm ([1,2,3,4,5,6] : List (Fin 7))
def R : Perm X := Equiv.mulRight r
def turn (p : X) := p*t

theorem sizeX : Fintype.card X=5040 := by rw [Fintype.card_perm,Fintype.card_fin]; decide
theorem sizeY : Fintype.card Y=720 := by rw [Fintype.card_perm,Fintype.card_fin]; decide

private def pool : Finset X := (Finset.range 6).image (fun j => t^j)
def owner (p : X) : Finset X := pool.image (fun a => p*a)

private theorem pool_size : pool.card=6 := by decide +native
private theorem pool_one : 1∈pool := by decide +native
private theorem pool_turn : pool.image (fun a=>t*a)=pool := by decide +native

theorem owner_size (p : X) : (owner p).card=6 := by
  rw [owner,Finset.card_image_of_injective _ (mul_right_injective p),pool_size]

theorem owner_has (p : X) : p∈owner p := by
  exact Finset.mem_image.mpr ⟨1,pool_one,mul_one p⟩

theorem owner_turn (p : X) : owner (turn p)=owner p := by
  unfold turn owner
  conv_rhs => rw [←pool_turn]
  rw [Finset.image_image]
  simp only [mul_assoc,Function.comp_def]

theorem fibre_bound (Q : Finset X) (i : Finset X) :
    (Q.filter (fun p=>owner p=i)).card≤6 := by
  let A:=Q.filter (fun p=>owner p=i)
  change A.card≤6
  by_cases ne : A.Nonempty
  · obtain ⟨x,hx⟩:=ne
    have key:owner x=i:=(Finset.mem_filter.mp hx).2
    have sub:A⊆i:=by
      intro y hy
      rw [←(Finset.mem_filter.mp hy).2]
      exact owner_has y
    exact (Finset.card_le_card sub).trans (by rw [←key,owner_size])
  · simp [Finset.not_nonempty_iff_eq_empty.mp ne]

theorem pure_row (h c : Perm X) (hc : c∈h.cycleFactorsFinset)
    (pure : ∀x∈c.support,h x=turn x) (x : X) (hx:x∈c.support) :
    c.support=owner x := by
  classical
  have spec:=Perm.mem_cycleFactorsFinset_iff.mp hc
  have walk (n : Nat) : (c^n) x∈c.support ∧ (c^n) x=x*t^n ∧ owner ((c^n) x)=owner x := by
    induction n with
    | zero => simpa using hx
    | succ n ih =>
      rw [pow_succ',Perm.mul_apply]
      refine ⟨Perm.apply_mem_support.mpr ih.1,?_,?_⟩
      · rw [spec.2 _ ih.1,pure _ ih.1,turn,ih.2.1,pow_succ,mul_assoc]
      · rw [spec.2 _ ih.1,pure _ ih.1,owner_turn,ih.2.2]
  apply Finset.Subset.antisymm
  · intro y hy
    obtain ⟨n,_,_,eq⟩:=(spec.1.sameCycle (Perm.mem_support.mp hx) (Perm.mem_support.mp hy)).exists_pow_eq _
    rw [←eq,←(walk n).2.2]
    exact owner_has _
  · intro y hy
    obtain ⟨a,ha,rfl⟩:=Finset.mem_image.mp hy
    obtain ⟨n,_,rfl⟩:=Finset.mem_image.mp ha
    rw [←(walk n).2.1]
    exact (walk n).1

theorem pure_card_six (h c : Perm X) (hc : c∈h.cycleFactorsFinset)
    (pure : ∀x∈c.support,h x=turn x) : c.support.card=6 := by
  classical
  obtain ⟨x,hx⟩:=(Perm.mem_cycleFactorsFinset_iff.mp hc).1.nonempty_support
  rw [pure_row h c hc pure x hx,owner_size]

def normal (p:X) : X := p*r^(p.symm 0).val
def tag (p:X) : Y := (Perm.decomposeFin (normal p)).2

private theorem adj : ∀i:Fin 7,r*r^(r.symm i).val=r^i.val := by decide +native

theorem tag_rot (p:X) : tag (R p)=tag p := by
  have h : normal (R p)=normal p := by
    change p*r*r^(r.symm (p.symm 0)).val=p*r^(p.symm 0).val
    rw [mul_assoc,adj]
  simp [tag,h]

theorem tag_surj : Function.Surjective tag := by
  intro y
  let p:X:=Perm.decomposeFin.symm (0,y)
  have h0 : p 0=0 := by simp [p]
  have hp : p.symm 0=0 := p.injective (by simpa using h0.symm)
  refine ⟨p,?_⟩
  simp [tag,normal,hp,p]

end ExactWordFlow.SevenMoves

import WordFlow

namespace ExactWordFlow
open SevenWordWindows DirectedEuler

private theorem prepend_steps {s t : Block} {es : List Block}
    (r : Route src dst s es t) (widths : ∀e∈es, e.length=7)
    (w : Block) (long : 6≤w.length) (same : w.take 6=t) :
    ∃ pre : Block, pre.length=es.length ∧ (pre++w).take 6=s ∧
      windows (pre++w)=es++windows w := by
  induction r with
  | nil => exact ⟨[],rfl,by simpa using same,by simp⟩
  | @cons u v es e hs tail ih =>
    obtain ⟨p,len,head,all⟩ := ih (fun f hf => widths f (List.mem_cons_of_mem _ hf)) same
    have sz := widths e List.mem_cons_self
    have pl : 6≤(p++w).length := by simp; omega
    cases e with
    | nil => simp at sz
    | cons a xs =>
      have firstPart : (p++w).take 6=xs := by simpa [dst] using head
      have seven : (a::(p++w)).take 7=a::xs := by simpa using congrArg (a::·) firstPart
      have six := congrArg (List.take 6) seven
      refine ⟨a::p,by simp [len],?_,?_⟩
      · simpa [List.take_take,src] using six.trans (show (a::xs).take 6=u from hs)
      · change windows (a::(p++w)) = (a::xs)::(es++windows w)
        rw [windows,ite_eq_left pl,firstPart,all]

private theorem final_width {s t : Block} {es : List Block} (r : Route src dst s es t)
    (start : s.length=6) (ww : ∀e∈es,e.length=7) : t.length=6 := by
  induction r with
  | nil => exact start
  | cons e hs tail ih =>
    have ew := ww e List.mem_cons_self
    exact ih (by simp [dst,ew]) (fun f hf => ww f (List.mem_cons_of_mem _ hf))

private theorem append_windows (w post : Block) (long : 6≤w.length) :
    windows (w++post)=windows w++windows (w.drop (w.length-6)++post) := by
  induction w with
  | nil => simp at long
  | cons a xs ih =>
    by_cases six : 6≤xs.length
    · have enough : 6≤(xs++post).length := by simp; omega
      have last : (a::xs).drop ((a::xs).length-6)=xs.drop (xs.length-6) := by
        rw [show (a::xs).length-6=(xs.length-6)+1 by simp; omega]
        rfl
      rw [last]
      simp only [List.cons_append,windows,ite_eq_left six,ite_eq_left enough,
        List.cons_append,List.cons.injEq]
      exact ⟨by simp [List.take_append_of_le_length six],ih six⟩
    · have len : (a::xs).length=6 := by simp_all; omega
      have none := List.length_eq_zero_iff.mp (show (windows (a::xs)).length=0 by
        rw [windows_length,len])
      rw [len,none]
      simp

/-- Spell arbitrary literal extensions on both sides of a fixed word,
preserving the full ordered list of windows and the starting state. -/
theorem spell_extensions {s t : Block} {p q : List Block} (w : Block) (long : 6≤w.length)
    (pRoute : Route src dst s p (w.take 6)) (qRoute : Route src dst (w.drop (w.length-6)) q t)
    (pWidth : ∀e∈p,e.length=7) (qWidth : ∀e∈q,e.length=7) :
    ∃ pre post : Block, pre.length=p.length ∧ post.length=q.length ∧
      windows (pre++w++post)=p++windows w++q ∧ (pre++w++post).take 6=s := by
  have terminal := final_width qRoute (by simp; omega) qWidth
  obtain ⟨z,zlen,zhead,zwin⟩ := prepend_steps qRoute qWidth t (by omega)
    (List.take_of_length_le (by omega))
  let post := (z++t).drop 6
  have join : w.drop (w.length-6)++post=z++t := by
    rw [←zhead]
    exact List.take_append_drop 6 (z++t)
  have no : windows t=[] := List.length_eq_zero_iff.mp (by rw [windows_length,terminal])
  have Q : windows (w++post)=windows w++q := by
    rw [append_windows w post long,join,zwin,no,List.append_nil]
  have initial : (w++post).take 6=w.take 6 := List.take_append_of_le_length long
  obtain ⟨pre,plen,ph,pw⟩ := prepend_steps pRoute pWidth (w++post) (by simp; omega) initial
  refine ⟨pre,post,plen,?_,?_,by simpa [List.append_assoc] using ph⟩
  · simp [post,zlen,terminal]
  · simpa [List.append_assoc,Q] using pw

#print axioms spell_extensions
end ExactWordFlow

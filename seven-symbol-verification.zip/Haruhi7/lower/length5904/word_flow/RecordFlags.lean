import SortedCoreRecords

namespace ExactWordFlow.SortedCoreRecords
open SevenWordWindows RotationCore

def finish (r : Row) : Bool × Bool :=
  let visit := (classOf r.key).isSome
  (visit,visit && decide (r.mask = Finset.univ))

/-- One flag pair per physical row. A row followed by the same key emits
two false flags and passes its accumulated bits forward. -/
def runFlags (r : Row) : List Row → List (Bool × Bool)
  | [] => [finish r]
  | s::rs =>
    if r.key=s.key then (false,false)::runFlags ⟨s.key,s.mask∪r.mask⟩ rs
    else finish r::runFlags s rs

def flags : List Row → List (Bool × Bool)
  | [] => []
  | r::rs => runFlags r rs

private def pick (need : Bool) (p : Bool × Bool) := if need then p.2 else p.1

private theorem cons_output (r : Row) (gs : List Row) (need : Bool) :
    (outputKeys (r::gs) need).length =
      (outputKeys gs need).length + (pick need (finish r)).toNat := by
  cases h : classOf r.key with
  | none => cases need <;> by_cases full : r.mask=Finset.univ <;>
      simp [outputKeys,pick,finish,h,full]
  | some c => cases need <;> by_cases full : r.mask=Finset.univ <;>
      simp [outputKeys,pick,finish,h,full]

private theorem runFlags_count (r : Row) (rs : List Row) (need : Bool) :
    (runFlags r rs).countP (pick need) = (outputKeys (scan r rs) need).length := by
  induction rs generalizing r with
  | nil =>
    simp only [runFlags,scan,cons_output]
    cases eq : pick need (finish r) <;> simp [outputKeys,eq]
  | cons s rs ih =>
    by_cases eq : r.key=s.key
    · simp only [runFlags,scan,ite_eq_left eq,List.countP_cons,ih]
      cases need <;> simp [pick]
    · simp only [runFlags,scan,ite_eq_right eq,List.countP_cons,ih,cons_output]
      cases pick need (finish r) <;> simp

theorem flags_count (rs : List Row) :
    ((flags rs).countP Prod.fst,(flags rs).countP Prod.snd) = counts rs := by
  cases rs with
  | nil => simp [flags,counts,outputKeys,grouped]
  | cons r rs =>
    exact Prod.ext (runFlags_count r rs false) (runFlags_count r rs true)

theorem sorted_flags {w : Block} (long : 6 ≤ w.length) (d : Block → List Nat)
    {extra rs : List Row} (pad : padding extra)
    (perm : rs.Perm (wordRows d w ++ extra)) (order : ordered rs) :
    ((flags rs).countP Prod.fst,(flags rs).countP Prod.snd) =
      ((visited w).card,(complete w).card) :=
  (flags_count rs).trans (sorted_counts long d pad perm order)

#print axioms sorted_flags
end ExactWordFlow.SortedCoreRecords

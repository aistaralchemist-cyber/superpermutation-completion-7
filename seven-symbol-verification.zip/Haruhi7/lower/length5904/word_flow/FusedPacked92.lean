import Cap92AcceptBits

namespace ExactWordFlow.FusedPacked92
open SevenWordWindows RotationCore
private def raw : Bool := FusedPacked.check 306 Cap92Lookup.acceptBits
set_option maxHeartbeats 0 in
private theorem raw_ok : raw=true := by native_decide

theorem checked : FusedAny.check 306 Cap92Lookup.accept=true := by
  apply FusedPacked.certified 306 Cap92Lookup.acceptBits _ _ raw_ok
  intro R board accepted
  rw [←Cap92Lookup.acceptBits_eq,accepted]
  simpa using fun c hc=>Cap94Lookup.known_of_board (board hc)

#print axioms checked
end ExactWordFlow.FusedPacked92

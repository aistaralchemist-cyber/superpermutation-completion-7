import Mathlib.Data.List.Forall2
import CompactGateLaws
import FrontLocalMeaning

namespace ExactWordFlow.CompactWordCircuit
open CompactFrontPlan FrontLocalMeaning
abbrev BitsRep (v : Nat→Bool) (ys : Array Bool) (xs : Bits) := List.Forall₂ (Rep v) ys.toList xs.toList

private theorem nz_all {v : Nat→Bool} {bs : List Bool} {xs : List W}
    (h : List.Forall₂ (Rep v) bs xs) : ∀x∈xs,x≠0 := by
  induction h with
  | nil => simp
  | cons hp _ ih => simpa using And.intro hp.1 ih

theorem bool_or_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {bs : List Bool} {xs : List W} (h : List.Forall₂ (Rep v) bs xs) :
    Gives T (anyGate xs) (Rep v (bs.any id)) := by
  have same : xs.any (wire v)=bs.any id := by
    induction h with
    | nil => rfl
    | cons hx _ ih => simp [hx.2,ih]
  rw [←same]
  exact lift_primitive law (any_quiet xs) (fun st=>anyGate_realizes xs st v unit (nz_all h))

theorem bool_and_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {bs : List Bool} {xs : List W} (h : List.Forall₂ (Rep v) bs xs) :
    Gives T (allGate xs) (Rep v (bs.all id)) := by
  have same : xs.all (wire v)=bs.all id := by
    induction h with
    | nil => rfl
    | cons hx _ ih => simp [hx.2,ih]
  rw [←same]
  exact lift_primitive law (all_quiet xs) (fun st=>allGate_realizes xs st v unit (nz_all h))

theorem default_rep {v : Nat→Bool} {bs : List Bool} {xs : List W} (unit : v 0=true)
    (h : List.Forall₂ (Rep v) bs xs) (i : Nat) :
    Rep v ((bs[i]?).getD false) ((xs[i]?).getD (-1)) := by
  induction h generalizing i with
  | nil => simp; exact zero_rep unit
  | cons hp _ ih => cases i with
    | zero => exact hp
    | succ i => exact ih i

theorem plan_lookup {v : Nat→Bool} {bs : Array Bool} {xs : Bits} (unit : v 0=true)
    (h : BitsRep v bs xs) (i : Int) :
    Rep v (lookup (!·) false bs i) (lookup (-·) (-1) xs i) := by
  have here:= default_rep unit h (i.natAbs-1)
  simp only [Array.getElem?_toList] at here
  unfold lookup
  split
  · exact ⟨neg_ne_zero.mpr here.1,by rw [wire_neg here.1,here.2]⟩
  · exact here

private theorem push_rep {v : Nat→Bool} {b : Bool} {x : W} {bs : Array Bool} {xs : Bits}
    (h : BitsRep v bs xs) (on : Rep v b x) : BitsRep v (bs.push b) (xs.push x) := by
  simpa only [BitsRep,Array.toList_push] using List.rel_append h (.cons on .nil)

private theorem map_refs {v : Nat→Bool} {bs : Array Bool} {xs : Bits} (unit : v 0=true)
    (h : BitsRep v bs xs) (args : List Ref) :
    List.Forall₂ (Rep v) (args.map (lookup (!·) false bs)) (args.map (lookup (-·) (-1) xs)) := by
  induction args with
  | nil => exact .nil
  | cons a _ ih => exact .cons (plan_lookup unit h a) ih

theorem front_grows (p : Array W) (ops : Ops) : Grows (realizeFront p ops) :=
  foldList_grows (fun _ _=>bind_grows (anyGate_grows _) (fun _=>pure_grows _)) _ p

/-- Each local gate is compiled with the actual signed-literal simplification,
and its wire represents the same Boolean value as the pure template evaluator. -/
theorem front_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {bs : Array Bool} {p : Array W} (hp : BitsRep v bs p) (ops : Ops) :
    Gives T (realizeFront p ops) (BitsRep v (runPure (!·) false (fun as=>as.any id) bs ops)) := by
  apply foldList_gives (R:=fun u b=>BitsRep v b u) (fun _ _=>bind_grows (anyGate_grows _) (fun _=>pure_grows _)) _ _ _ hp
  intro args _ env values h
  exact bind_gives (anyGate_grows _) (fun _=>pure_grows _) (bool_or_gives law unit (map_refs unit h args))
    (fun _ bit=>pure_gives (push_rep h bit))

end ExactWordFlow.CompactWordCircuit

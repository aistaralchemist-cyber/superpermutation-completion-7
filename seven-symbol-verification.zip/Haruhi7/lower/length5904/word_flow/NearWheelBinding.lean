import NearBinding96
import NearBinding97
import NearBinding98

namespace ExactWordFlow.NearWheelBinding
open SevenWordWindows SeedWheelCut RotationCore ExtremeWheelCut NearRootMoves NearHardRoots
open ResidualDensity.ExtremalRealizations ResidualDensity.NearExtrema

/-- Every connected cover in one of the three complete finite geometries
can be relabelled to a remaining representative. All other rooted cases are
excluded by explicit connected-wheel forcing chains. -/
theorem exhaust {n : Nat} (lo : 96≤n) (hi : n≤98) {R : Finset Block}
    (geo : R∈realizations (profiles n)) {W : Finset (Finset Block)}
    (legal : W⊆allRows) (size : W.card≤n) (covered : ClosedCover R allClasses W) :
    ∃r∈NearHardRoots.hard n, ∃w : Finset (Finset Block),
      w⊆allRows ∧ w.card≤n ∧ r.card=720-5*n ∧ ClosedCover r allClasses w := by
  have ver : verified n=true := by
    rcases (show n=96 ∨ n=97 ∨ n=98 by omega) with rfl|rfl|rfl
    · exact checked96
    · exact checked97
    · exact checked98
  exact exhaust_verified ver geo legal size covered

#print axioms exhaust
end ExactWordFlow.NearWheelBinding

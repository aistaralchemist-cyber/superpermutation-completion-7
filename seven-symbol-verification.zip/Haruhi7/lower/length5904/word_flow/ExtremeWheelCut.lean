import CoreCounts
import SeedWheelCut
import WheelContacts

namespace ExactWordFlow.ExtremeWheelCut
open SevenWordWindows RotationCore SeedWheelCut

def allRows := (WheelContacts.bases.map WheelContacts.wheel).toFinset

private theorem widths : ∀w∈allRows,w.card≤6 := by native_decide

/-- The intermediate witness class forces its designated wheel. The last
class has no wheel entering the connected seed with a single contact. -/
inductive Certificate where
  | stop (c : Block)
  | force (c q : Block) (rest : Certificate)
deriving Inhabited

private def valid (R : Finset Block) : Certificate → Bool
  | .stop d => decide (d∈allClasses ∧ d∉R ∧ ∀w∈allRows,d∈w → 2≤(R∩w).card)
  | .force d q cert =>
    let v := WheelContacts.wheel q
    decide (d∈allClasses ∧ d∉R ∧ (R∪v).card≤R.card+5 ∧
      ∀w∈allRows, d∈w → w≠v → 2≤(R∩w).card) && valid (R∪v) cert

private theorem eliminates (c : Certificate) (R : Finset Block) {W : Finset (Finset Block)}
    (legal : W⊆allRows) (budget : R.card+5*W.card≤allClasses.card) (verified : valid R c=true) :
    ¬ClosedCover R allClasses W := by
  intro linked
  have wide (w) (hw : w∈W) := widths w (legal hw)
  induction c generalizing R W with
  | stop d =>
    obtain ⟨req,missing,forced⟩ := of_decide_eq_true verified
    exact missing (forced_by_seed R R allClasses W d (Finset.Subset.refl _) req wide budget
      (fun w hw => forced w (legal hw)) linked)
  | force d q cert ih =>
    let v := WheelContacts.wheel q
    obtain ⟨test,later⟩ := Bool.and_eq_true_iff.mp verified
    obtain ⟨req,missing,sz,only⟩ := of_decide_eq_true test
    have must : v∈W := by
      by_contra no
      exact missing (forced_by_seed R R allClasses W d (Finset.Subset.refl _) req wide budget
        (fun w hw hc => only w (legal hw) hc (fun eq => no (by change WheelContacts.wheel q∈W; rwa [←eq]))) linked)
    have count := Finset.card_erase_add_one must
    have connected : ClosedCover (R∪v) allClasses (W.erase v) := by
      intro C sub closed
      apply linked C (Finset.subset_union_left.trans sub)
      intro w hw meet
      by_cases eq : w=v
      · exact eq ▸ Finset.subset_union_right.trans sub
      · exact closed w (Finset.mem_erase.mpr ⟨eq,hw⟩) meet
    change (R∪v).card≤R.card+5 at sz
    exact ih (R∪v) ((Finset.erase_subset ..).trans legal) (by omega) later connected
      (fun w hw=>wide w (Finset.mem_erase.mp hw).2)

private def digits (s : String) : Block := s.toList.map (fun ch => Fin.ofNat 7 (ch.toNat-'0'.toNat))

private def makeCert (pairs : List (String × String)) (endClass : String) : Certificate :=
  pairs.foldr (fun (d,w) rest => .force (digits d) (digits w) rest) (.stop (digits endClass))

/-- Six first-row-normalized spellings and their finite forcing chains. -/
private def data : List (Block × Certificate) := [
  (digits "012345012340512340152340125340123540132540135240135420135402135042130542130452130425130421530412530415230415320413520413250413205413204513240513245013245103245130245310245301245302145320145321045321405321450321540321504321503421503241502341502431502413502415302415",makeCert [("0245136","025136"), ("0245163","025163"), ("0326415","032641"), ("0362415","036241"), ("0415362","015362"), ("0153246","015324")] "0415632"),
  (digits "012345012340512340152340125340123540132540135240135420135402135042135024135021435012435014235014325014352014532014523014520314520134521034512034510234510324510342510432510423510425310452310453210453120453102453012453021453024153024513025413025143025134025130425130",makeCert [("0246513","132465"), ("0261435","026145"), ("0132645","013245"), ("0245613","045613"), ("0613452","061342"), ("0134256","013425"), ("0163452","163452")] "0213645"),
  (digits "012345012340512340152340125340123540132540135240135420135402135042135024135021435012435014235014325014352014532014523014520314520134521034521304521340521430521403521405321405231402531420531425031425301425310425130425103425104325104235102435102345102354102351402351",makeCert [] "0426351"),
  (digits "012345012340512340152340125340123540132540135240135420135402135042135024135021435021345023145023415023451023541023514023510423510243512043512403512430512435012453012450312450132451032451302451320451324051342051432051423051420351420531425031425301425310425314025314",makeCert [("0123654","123654"), ("0124356","014356"), ("0124365","014365")] "0142635"),
  (digits "012345012340512340152340125340123540132540135240135420135402135042135024135021435021345023145023415023451023541023514023510423510243512043521043520143520413520431520341520314520315420315240312540312450312405312045312054312053412053142051342051432051423051420351420",makeCert [("0123654","123654"), ("0315264","035264"), ("0356412","035412"), ("0126354","012635"), ("0435126","045126"), ("0634512","034512"), ("0234651","034651"), ("0435162","162435")] "0356124"),
  (digits "012345012340512340152340125340123540132540135240135420135402135042135024135021435021345023145032145031245031425031452031542031524031520431502431504231504321504312504132504123504125304125034120534120354120345120435120453120451320451230452130452310452301452304152304",makeCert [] "0126354")
]

private def rename (shift : Fin 7) (w : Block) := w.map (·+shift)

private def transport (shift : Fin 7) : Certificate → Certificate
  | .stop d => .stop (classKey (rename shift d))
  | .force d w c => .force (classKey (rename shift d)) (rename shift w) (transport shift c)

/-- The seven cyclic initial phases used in the normalized geometric search. -/
private def cases258 := data.flatMap fun (word,c) =>
  (List.finRange 7).map fun shift => (visited (rename shift word),transport shift c)

def provedRoots := cases258.map Prod.fst

private theorem checked :
    ∀entry∈cases258, entry.1.card=220 ∧ valid entry.1 entry.2=true := by native_decide

theorem no_cover {R : Finset Block} (known : R∈provedRoots) {W : Finset (Finset Block)}
    (legal : W⊆allRows) (small : W.card≤100) : ¬ClosedCover R allClasses W := by
  obtain ⟨entry,he,rfl⟩ := List.mem_map.mp known
  obtain ⟨cost,ok⟩ := checked entry he
  exact eliminates _ _ legal (by rw [board,cost]; omega) ok

#print axioms no_cover
end ExactWordFlow.ExtremeWheelCut

import NonNeutralGenus

namespace ExactWordFlow.RowCredits
open Equiv
variable {X ι : Type*} [Fintype X] [DecidableEq X] [DecidableEq ι]

def fee (h R : Perm X) (last : X) (d : X→Nat) (x : X) : Nat :=
  (if x=last then 1 else d x-2)+(if x∈h.support ∧ h x=R x then 1 else 0)

theorem budget (h R : Perm X) (last : X) (d : X→Nat) (S : Finset X) :
    (∑x∈S,fee h R last d x) ≤ 1+(∑x∈Finset.univ.erase last,(d x-2))+
      (h.support.filter fun x=>h x=R x).card := by
  classical
  have cap:=Finset.sum_le_sum_of_subset (f:=fee h R last d) (Finset.subset_univ S)
  have first : (∑x : X,if x=last then 1 else d x-2)=
      (∑x∈Finset.univ.erase last,(d x-2))+1 := by
    rw [←Finset.sum_erase_add _ _ (Finset.mem_univ last)]
    have part : (∑x∈Finset.univ.erase last,if x=last then 1 else d x-2) =
        ∑x∈Finset.univ.erase last,(d x-2) := Finset.sum_congr (s₂:=Finset.univ.erase last) (f:=fun i:X=>if i=last then (1:Nat) else d i-2) (g:=fun i=>d i-2) rfl (fun i hi=>ite_eq_right (Finset.mem_erase.mp hi).1)
    rw [part]; simp
  have second : (∑x : X,if x∈h.support ∧ h x=R x then 1 else 0)=
      (h.support.filter fun x=>h x=R x).card := by
    simp only [←Finset.sum_filter, Finset.sum_const, smul_eq_mul, mul_one]
    congr 1
    ext x
    simp
  simp only [fee,Finset.sum_add_distrib,first,second] at cap
  simpa only [fee,Finset.sum_add_distrib,Nat.add_comm 1] using cap

/-- Every physical neutral wheel touched by an exception contains a paid
departure, the open cut, or a nonordinary cost-two switch. Otherwise the
cycle stays on that same neutral wheel and agrees with it throughout. -/
theorem row_positive (h R : Perm X) (turn : X→X) (owner : X→ι) (fixedRow : ∀x,owner (turn x)=owner x)
    (last : X) (d : X→Nat) (positive : ∀x,x≠last → 1≤d x)
    (one : ∀x,x≠last → (d x=1 ↔ h x=x))
    (two : ∀x,x≠last → d x=2 → h x=turn x ∨ h x=R x)
    (E : Finset (Perm X)) (sub : E⊆h.cycleFactorsFinset)
    (exceptional : ∀c∈E,last∈c.support ∨ ∃y∈c.support,h y≠turn y) :
    let S:=E.biUnion Perm.support
    ∀i∈S.image owner,0<∑x∈S.filter (fun x=>owner x=i),fee h R last d x := by
  classical
  let S:=E.biUnion Perm.support
  change ∀i∈S.image owner,_
  intro i hi
  by_contra no
  have zero : (∑x∈S.filter (fun t=>owner t=i),fee h R last d x)=0:=Nat.eq_zero_of_not_pos no
  obtain ⟨x,hx,xi⟩:=Finset.mem_image.mp hi
  obtain ⟨c,hc,xc⟩:=Finset.mem_biUnion.mp hx
  have spec:=Perm.mem_cycleFactorsFinset_iff.mp (sub hc)
  have localZero (z : X) (hz : z∈c.support) (inrow : owner z=i) :
      z≠last ∧ h z=turn z := by
    have zS : z∈S:=Finset.mem_biUnion.mpr ⟨c,hc,hz⟩
    have zrow : z∈S.filter (fun t=>owner t=i):=Finset.mem_filter.mpr ⟨zS,inrow⟩
    have le:=Finset.single_le_sum (f:=fee h R last d) (fun _ _=>Nat.zero_le _)
      zrow
    have z0 : fee h R last d z=0:=by omega
    have moved : h z≠z:=by rw [←spec.2 z hz]; exact Perm.mem_support.mp hz
    by_cases lastZ : z=last
    · simp [fee,lastZ] at z0
    · have nz : d z≠1:=(one z lastZ).not.mpr moved
      have raw:=positive z lastZ
      simp only [fee,ite_eq_right lastZ] at z0
      have cost : d z=2:=by omega
      rcases two z lastZ cost with yes|bad
      · exact ⟨lastZ,yes⟩
      · simp [Perm.mem_support.mpr moved,bad] at z0
  have walk (n : Nat) : (c^n) x∈c.support ∧ owner ((c^n) x)=i := by
    induction n with
    | zero => simpa using And.intro xc xi
    | succ n ih =>
      rw [pow_succ',Perm.mul_apply]
      refine ⟨Perm.apply_mem_support.mpr ih.1,?_⟩
      rw [spec.2 _ ih.1,(localZero _ ih.1 ih.2).2,fixedRow,ih.2]
  have entire (y : X) (hy : y∈c.support) : owner y=i := by
    obtain ⟨n,_,_,eq⟩:=(spec.1.sameCycle (Perm.mem_support.mp xc) (Perm.mem_support.mp hy)).exists_pow_eq _
    exact eq ▸ (walk n).2
  rcases exceptional c hc with cut|⟨y,hy,bad⟩
  · exact (localZero last cut (entire last cut)).1 rfl
  · exact bad (localZero y hy (entire y hy)).2

#print axioms row_positive
#print axioms budget
end ExactWordFlow.RowCredits

import CompactReports
import KeyWireOrder

namespace ExactWordFlow.CompactWordCircuit
open CoreRecordBits (wireLE)

private def keyEq (p : W×W) : M W := do return -(← bitXor p.1 p.2)
private def agreeBit (v : Nat→Bool) (p : W×W) (out : W) :=
  Rep v (decide (wire v p.1=wire v p.2)) out

private theorem keyEq_grows (p : W×W) : Grows (keyEq p) :=
  bind_grows (xor_grows _ _) (fun _=>pure_grows _)

private theorem keyEq_reports (p : W×W) : Reports (keyEq p) (fun _=>[]) :=
  no_report_bind (xor_grows _ _) (fun _=>pure_grows _) (report_quiet (xor_quiet _ _))
    (fun _=>report_pure _)

private theorem keyEq_gives {v : Nat→Bool} {T : Test} (law : ModelsGates T v) (unit : v 0=true)
    (p : W×W) (nz : p.1≠0 ∧ p.2≠0) : Gives T (keyEq p) (agreeBit v p) := by
  refine bind_gives (m:=bitXor p.1 p.2) (P:=Rep v (wire v p.1 ^^ wire v p.2))
    (xor_grows _ _) (fun _=>pure_grows _) (xor_gives law unit ⟨nz.1,rfl⟩ ⟨nz.2,rfl⟩) ?_
  intro out h
  apply pure_gives
  refine ⟨neg_ne_zero.mpr h.1,?_⟩
  rw [wire_neg h.1,h.2]
  cases wire v p.1 <;> cases wire v p.2 <;> decide

theorem leFrom_grows (ps : List (W×W)) : Grows (leFrom ps) := by
  induction ps with
  | nil => exact pure_grows _
  | cons p ps ih =>
    rw [leFrom]
    exact bind_grows ih (fun y=>mux_grows _ _ _)

private theorem leFrom_reports (ps : List (W×W)) : Reports (leFrom ps) (fun _=>[]) := by
  induction ps with
  | nil => exact report_pure _
  | cons p ps ih =>
    rw [leFrom]
    exact no_report_bind (leFrom_grows ps) (fun y=>mux_grows _ _ _) ih (fun y=>report_quiet (mux_quiet _ _ _))

private theorem pairs_ok {xs ys : List W} (nx : ∀x∈xs,x≠0) (ny : ∀y∈ys,y≠0)
    (p : W×W) (hp : p∈xs.zip ys) : p.1≠0 ∧ p.2≠0 :=
  ⟨nx _ (List.of_mem_zip hp).1,ny _ (List.of_mem_zip hp).2⟩

private theorem matched {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {xs ys es : List W} (sz : xs.length=ys.length) (nz : ∀x∈xs,x≠0)
    (h : List.Forall₂ (agreeBit v) (xs.zip ys) es) :
    Gives T (leFrom (es.zip xs)) (Rep v (wireLE (xs.map (wire v)) (ys.map (wire v)))) ∧
    (∀e∈es,e≠0) ∧ es.all (wire v) = decide (xs.map (wire v)=ys.map (wire v)) := by
  induction xs generalizing ys es with
  | nil =>
    obtain rfl : ys=[] := List.length_eq_zero_iff.mp sz.symm
    cases h
    exact ⟨pure_gives (one_rep unit),by simp,by simp⟩
  | cons x xs ih =>
    cases ys with
    | nil => simp at sz
    | cons y ys =>
      cases h with
      | cons hb ht =>
        rename_i e es
        have nx:=nz x List.mem_cons_self
        obtain ⟨tail,clean,allEq⟩:=ih (by simpa using sz) (fun z hz=>nz z (List.mem_cons_of_mem _ hz)) ht
        refine ⟨?_,?_,?_⟩
        · simp only [List.zip_cons_cons,leFrom]
          refine bind_gives (m:=leFrom (es.zip xs)) (P:=Rep v (wireLE (xs.map (wire v)) (ys.map (wire v))))
            (leFrom_grows _) (fun out=>mux_grows _ _ _) tail ?_
          intro next hn
          have neg : Rep v (!(wire v x)) (-x) := ⟨neg_ne_zero.mpr nx,wire_neg nx⟩
          simpa [wireLE] using mux_gives law unit hb hn neg
        · intro z hz
          rcases List.mem_cons.mp hz with rfl|hz
          · exact hb.1
          · exact clean z hz
        · simp only [List.all_cons,hb.2,allEq,List.map_cons,List.cons.injEq]
          by_cases h:wire v x=wire v y <;> simp [h]

private theorem compareBits_grows (as bs : List W) :
    Grows (do let same ← (as.zip bs).mapM keyEq; let le ← leFrom (same.zip as)
              insist [le]; let equal ← allGate same; return (le,equal)) := by
  exact bind_grows (mapList_grows keyEq_grows _) fun same=>
    bind_grows (leFrom_grows _) fun le=>bind_grows (insist_grows _) fun _=>
    bind_grows (allGate_grows _) fun eq=>pure_grows (le,eq)

theorem compareRows_grows (n : Nat) (a b : Bits) : Grows (compareRows n a b) :=
  compareBits_grows _ _

theorem compareRows_reports (n : Nat) (a b : Bits) : Reports (compareRows n a b) (fun p=>[[p.1]]) := by
  unfold compareRows
  dsimp only
  change Reports (do let same ← ((a.toList.take n).zip (b.toList.take n)).mapM keyEq
                     let le ← leFrom (same.zip (a.toList.take n))
                     insist [le]; let equal ← allGate same; return (le,equal)) _
  refine no_report_bind (mapList_grows keyEq_grows _) (fun same=>bind_grows (leFrom_grows _)
    (fun _=>bind_grows (insist_grows _) (fun _=>bind_grows (allGate_grows _) (fun _=>pure_grows _))))
    (no_reports_map keyEq_grows keyEq_reports _) ?_
  intro same
  refine no_report_bind (leFrom_grows _) (fun _=>bind_grows (insist_grows _)
    (fun _=>bind_grows (allGate_grows _) (fun _=>pure_grows _))) (leFrom_reports _) ?_
  intro le
  refine report_bind (insist_grows _) (fun _=>bind_grows (allGate_grows _) (fun _=>pure_grows _))
    (insist_reports _) ?_
  intro _ st
  have q : Reports (allGate same >>= fun e=>pure (le,e)) (fun _=>[]) :=
    no_report_bind (allGate_grows _) (fun _=>pure_grows _) (report_quiet (all_quiet _)) (fun _=>report_pure _)
  have empty:=q st
  change [[le]] ++ assertRows _ = [[le]]
  rw [empty,List.append_nil]

def keyBits (v : Nat→Bool) (n : Nat) (r : Bits) := (r.toList.take n).map (wire v)
def edgeRep (v : Nat→Bool) (n : Nat) (ab : Bits×Bits) (out : W×W) :=
  Rep v (wireLE (keyBits v n ab.1) (keyBits v n ab.2)) out.1 ∧
    Rep v (decide (keyBits v n ab.1 = keyBits v n ab.2)) out.2

theorem compareRows_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    (n : Nat) (a b : Bits) (ha : n≤a.size) (hb : n≤b.size)
    (na : ∀x∈a.toList,x≠0) (nb : ∀x∈b.toList,x≠0) :
    Gives T (compareRows n a b) (edgeRep v n (a,b)) := by
  let xs:=a.toList.take n
  let ys:=b.toList.take n
  have nx : ∀x∈xs,x≠0 := fun x hx=>na x (List.mem_of_mem_take hx)
  have ny : ∀x∈ys,x≠0 := fun x hx=>nb x (List.mem_of_mem_take hx)
  have size : xs.length=ys.length := by simp [xs,ys,List.length_take,ha,hb]
  unfold compareRows
  change Gives T (do let same ← (xs.zip ys).mapM keyEq
                     let le ← leFrom (same.zip xs)
                     insist [le]; let equal ← allGate same; return (le,equal)) _
  refine bind_gives (P:=List.Forall₂ (agreeBit v) (xs.zip ys)) (mapList_grows keyEq_grows _)
    (fun same=>bind_grows (leFrom_grows _) (fun _=>bind_grows (insist_grows _)
    (fun _=>bind_grows (allGate_grows _) (fun _=>pure_grows _))))
    (mapList_gives keyEq_grows _ (fun p hp=>keyEq_gives law unit p (pairs_ok nx ny p hp))) ?_
  intro same he
  obtain ⟨ord,clean,eq⟩:=matched law unit size nx he
  refine bind_gives (P:=Rep v (wireLE (xs.map (wire v)) (ys.map (wire v))))
    (leFrom_grows _) (fun _=>bind_grows (insist_grows _) (fun _=>bind_grows (allGate_grows _)
    (fun _=>pure_grows _))) ord ?_
  intro le hl
  refine bind_gives (P:=fun _=>True) (insist_grows _) (fun _=>bind_grows (allGate_grows _) (fun _=>pure_grows _))
    (insist_gives _) ?_
  intro _ _
  refine bind_gives (P:=Rep v (same.all (wire v))) (allGate_grows _) (fun _=>pure_grows _)
    (lift_primitive law (all_quiet _) (fun st=>allGate_realizes same st v unit clean)) ?_
  intro e h
  exact pure_gives ⟨hl,eq ▸ h⟩


def rowEdges (xs : List α) := xs.zip xs.tail
def rowReady (n : Nat) (ws : Bits) := n≤ws.size ∧ ∀x∈ws.toList,x≠0

theorem adjacentRows_grows (n : Nat) (rs : List Bits) : Grows (adjacentRows n rs) := by
  induction rs using adjacentRows.induct with
  | case1 => exact pure_grows _
  | case2 a => exact pure_grows _
  | case3 a b r ih =>
    rw [adjacentRows]
    exact bind_grows (compareRows_grows _ _ _) (fun pair=>bind_grows ih (fun tail=>pure_grows (pair::tail)))

theorem adjacentRows_gives {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    (n : Nat) (rs : List Bits) (ready : ∀r∈rs,rowReady n r) :
    Gives T (adjacentRows n rs) (List.Forall₂ (edgeRep v n) (rowEdges rs)) := by
  induction rs using adjacentRows.induct with
  | case1 => exact pure_gives .nil
  | case2 a => exact pure_gives .nil
  | case3 a b r ih =>
    rw [adjacentRows]
    have ha:=ready a List.mem_cons_self
    have hb:=ready b (List.mem_cons_of_mem _ List.mem_cons_self)
    have tail := ih (fun x hx=>ready x (List.mem_cons_of_mem _ hx))
    refine bind_gives (m:=compareRows n a b) (P:=edgeRep v n (a,b)) (compareRows_grows _ _ _)
      (fun pair=>bind_grows (adjacentRows_grows n (b::r)) (fun rest=>pure_grows (pair::rest)))
      (compareRows_gives law unit n a b ha.1 hb.1 ha.2 hb.2) ?_
    intro pair hp
    exact bind_gives (m:=adjacentRows n (b::r)) (P:=List.Forall₂ (edgeRep v n) (rowEdges (b::r)))
      (adjacentRows_grows _ _) (fun rest=>pure_grows (pair::rest)) tail
      (fun rest hr=>pure_gives (.cons hp hr))

theorem adjacentRows_reports (n : Nat) (rs : List Bits) :
    Reports (adjacentRows n rs) (fun out=>out.map fun p=>[p.1]) := by
  induction rs using adjacentRows.induct with
  | case1 => exact report_pure _
  | case2 a => exact report_pure _
  | case3 a b r ih =>
    rw [adjacentRows]
    refine report_bind (compareRows_grows n a b)
      (fun p=>bind_grows (adjacentRows_grows _ _) (fun tail=>pure_grows (p::tail)))
      (compareRows_reports n a b) ?_
    intro p st
    have past:=ih st
    change [[p.1]] ++ assertRows (((adjacentRows n (b::r) st).2.body.toList).drop st.body.size)
      = (p::(adjacentRows n (b::r) st).1).map _
    rw [past]
    rfl

#print axioms adjacentRows_gives
#print axioms adjacentRows_reports
end ExactWordFlow.CompactWordCircuit

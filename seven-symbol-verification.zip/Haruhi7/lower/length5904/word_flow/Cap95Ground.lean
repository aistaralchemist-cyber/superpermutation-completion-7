import IndexedRootSearch
import Cap95Catalog

namespace ExactWordFlow.Cap95Catalog
open ResidualDensity
open private baseGood index checkLookup from NearBindingCheck
open private rows from Cap95Catalog

def indexed : Bool :=
  let v:=rows
  v.toList.all (baseGood 95 Cap95Data.hard.toArray) &&
    let lut:=index v
    (IndexedRootSearch.results (Cap95Profiles.profiles 95)).all (checkLookup v lut)

set_option maxHeartbeats 0 in
theorem checkedGround : indexed=true := by native_decide

#print axioms checkedGround
end ExactWordFlow.Cap95Catalog

import GlobalDensity66

namespace ExactWordFlow.RotationComponentCount
open SevenWordWindows ResidualDensity ResidualDensity.Density66 DirectedEuler ResidualRoutes ResidualIncidence GlobalDensity66
open scoped Classical
open private open_cap cyclic_cap closed_price chunksCap from GlobalDensity66
open private all_contacts from OverlapBudget
open private required_data from ResidualIncidence

/-- Nonroot components with room for a closed six-symbol context. -/
noncomputable def active (X : Multiset Block) (s : Block) :=
  ((support X s).image (label X)).filter fun q => q≠label X s ∧ 6≤(part X q).card

/-- Each nonroot active component incurs at least six units in the
66-position budget. A long closed component incurs sixty additional units. -/
theorem paid {X : Multiset Block} {s t : Block}
    (bal : X.map src+{t}=X.map dst+{s}) (width : ∀e∈X,e.length=7) (budget : X.card≤858) :
    66*separateRank X s+6*(active X s).card+60*(large X s).card≤56*X.card+82 := by
  classical
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  let C (q : Component X) := (contacts (support X s) (label X) q).card
  let Big (q) := q≠home ∧ 79≤K q
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q = X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have range (q : Component X) : K q≤858 := (Multiset.card_le_card (Multiset.filter_le ..)).trans budget
  have localPrice (q) (hq : q∈Q) :
      (q=home → C q≤cap (K q)) ∧ (Big q → 66*C q≤56*K q) ∧
      (q≠home → ¬Big q → 6*(C q-1)≤5*K q) := by
    obtain ⟨v,_,vv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩ := component_route bal v
    rw [vv] at eq lv ep
    have len : es.length=K q := congrArg Multiset.card eq
    have wd (e : Block) (he : e∈es) := width e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have incl : C q≤classCount a es := contacts_bound _ lv r eq
    refine ⟨fun _ => ?_,?_,?_⟩
    · obtain ⟨x,y,z⟩:=open_cap r wd
      rw [len] at x y z
      exact le_min (all_contacts ..) (le_min (incl.trans x) (le_min (incl.trans y) (incl.trans z)))
    · rintro ⟨away,big⟩
      obtain ⟨aa,bb⟩ := ep.2 away
      subst a; subst b
      have zz := cyclic_cap r wd (by omega)
      omega
    · intro away no
      obtain ⟨aa,bb⟩ := ep.2 away
      subst a; subst b
      have small : es.length<79 := by by_contra! no'; exact no ⟨away,by omega⟩
      have zz := closed_price r wd small
      omega
  let Act (q : Component X) := q≠home ∧ 6≤K q
  have scalar : ∀k : Fin 859, 66*(cap k.val-1)≤56*k.val+82 := by native_decide
  have unit (q) (hq : q∈Q) :
      66*(C q-1)+(if Act q then 6 else 0)+(if Big q then 60 else 0) ≤
      56*K q+(if q=home then 82 else 0) := by
    obtain ⟨op,bg,cl⟩:=localPrice q hq
    by_cases hr : q=home
    · have na : ¬Act q := fun e => e.1 hr
      have nb : ¬Big q := fun e => e.1 hr
      simp only [ite_eq_right na,ite_eq_right nb,ite_eq_left hr,Nat.add_zero]
      exact (Nat.mul_le_mul_left 66 (Nat.sub_le_sub_right (op hr) 1)).trans (scalar ⟨K q,by have:=range q; omega⟩)
    · rw [ite_eq_right hr,Nat.add_zero]
      by_cases big : Big q
      · have a : Act q := ⟨hr,by have:=big.2; omega⟩
        have n:=bg big
        have l:=big.2
        rw [ite_eq_left a,ite_eq_left big]
        omega
      · have v:=cl hr big
        rw [ite_eq_right big,Nat.add_zero]
        by_cases a : Act q
        · rw [ite_eq_left a]
          have l:=a.2
          omega
        · rw [ite_eq_right a,Nat.add_zero]
          omega
  have cost:=Finset.sum_le_sum unit
  have actCard : (∑q∈Q,if Act q then 6 else 0)=6*(active X s).card := by
    rw [←Finset.sum_filter]; simp [Q,active,Act,K,home,Nat.mul_comm]
  have bigCard : (∑q∈Q,if Big q then 60 else 0)=60*(large X s).card := by
    rw [←Finset.sum_filter]; simp [Q,large,Big,K,home,Nat.mul_comm]
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_ite_eq',root,ite_true,actCard,bigCard,total] at cost
  exact cost

theorem active_le {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858) :
    (active X s).card≤108 ∧ (large X s ≠ ∅ → (active X s).card≤102) := by
  classical
  have rank : 719 ≤ separateRank X s:=rank719 (label X) h fun _ he => on_edge he
  have price:=paid h.balance h.edges_seven budget
  have withBig (nonempty : large X s≠∅) : (active X s).card≤102 := by
    have p := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr nonempty)
    omega
  refine ⟨?_,withBig⟩
  by_cases big : large X s≠∅
  · have z:=withBig big; omega
  let Q := (support X s).image (label X)
  let K (q : Component X) := (part X q).card
  let home := label X s
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q = X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have rootSize : 210≤K home := by
    rcases root_210_or_closed_79 h budget with rootSize|⟨q,ne,hi⟩
    · exact rootSize
    · have nepart : part X q≠0 := fun zero => by simp [zero] at hi
      obtain ⟨e,he⟩:=Multiset.exists_mem_of_ne_zero nepart
      have ⟨orig,eq⟩:=in_part.mp he
      have member : q∈Q := by
        rw [←eq,on_edge orig]
        exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
          (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr orig),rfl⟩)))
      exact (big (Finset.nonempty_iff_ne_empty.mp ⟨q,Finset.mem_filter.mpr ⟨member,ne,hi⟩⟩)).elim
  have each (q) (hq : q∈Q.erase home) : (if q∈active X s then 6 else 0)≤K q := by
    split
    next yes => exact (Finset.mem_filter.mp yes).2.2
    next => omega
  have size:=Finset.sum_le_sum each
  have sub : active X s ⊆ Q.erase home := by
    intro q hq
    obtain ⟨m,a,_⟩:=Finset.mem_filter.mp hq
    exact Finset.mem_erase.mpr ⟨a,m⟩
  have eq : ((Q.erase home).filter fun q => q∈active X s)=active X s := by ext x; simp +contextual [Finset.mem_erase]; grind
  rw [←Finset.sum_filter,eq] at size
  simp at size
  have split := Finset.sum_erase_add (s:=Q) K root
  rw [total] at split
  omega

private theorem short_return_table :
    ∀v∈states, ∀k∈List.range 6, 0<k → ¬(v.drop k <+: v) := by native_decide

/-- A nonempty closed walk through six different symbols has at least six edges. -/
theorem closed_clean {v : Block} {es : List Block} (fl : full v) (r : Route src dst v es v)
    (wd : ∀e∈es,e.length=7) (pos : 0<es.length) : 6≤es.length := by
  by_contra! short
  obtain ⟨u,walk,start,finish,_⟩ := route_walk r wd
  have pref (i : Nat) (small : i≤es.length) : v.drop i <+: u i := by
    induction i with
    | zero => simp [start]
    | succ i ih =>
      obtain ⟨rest,eq⟩:=ih (by omega)
      obtain ⟨a,mv⟩:=walk i
      have neq : v.drop i≠[] := fun e => by have:=List.drop_eq_nil_iff.mp e; have:=fl.1; omega
      rw [mv,step,←eq,List.tail_append_of_ne_nil neq,List.tail_drop,List.append_assoc]
      exact List.prefix_append ..
  have endp:=pref es.length le_rfl
  rw [finish] at endp
  exact short_return_table v (mem_states fl) es.length (List.mem_range.mpr short) pos endp

/-- Every edge-bearing nonroot residual component must contain a clean vertex:
otherwise its boundary is crossed by neither residual nor mandatory edges. -/
theorem residual_clean {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {q : Component X} (away : q≠label X s) (pos : 0<(part X q).card) :
    ∃v, full v ∧ label X v=q := by
  classical
  by_contra! no
  let S : Set Block := {v | label X v≠q}
  have stable (e) (he : e∈required+X) (hs : src e∈S) : dst e∈S := by
    change label X (dst e)≠q
    rcases Multiset.mem_add.mp he with req | more
    · exact no _ (required_data e req).2.1
    · rw [←on_edge more]
      exact hs
  obtain ⟨e,he⟩:=Multiset.exists_mem_of_ne_zero (show part X q≠0 by intro eq; simp [eq] at pos)
  exact (h.reachable S (Ne.symm away) stable e (Multiset.mem_add.mpr (Or.inr (in_part.mp he).1))) (in_part.mp he).2

noncomputable def occupied (X : Multiset Block) (s : Block) :=
  (((X.map src).toFinset).image (label X)).erase (label X s)

theorem occupied_active {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    occupied X s=active X s := by
  classical
  ext q
  constructor
  · intro mem
    obtain ⟨away,inQ⟩:=Finset.mem_erase.mp mem
    obtain ⟨v,vm,eq⟩:=Finset.mem_image.mp inQ
    obtain ⟨e,orig,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp vm)
    have ep := in_part.mpr ⟨orig,eq⟩
    have pos : 0<(part X q).card := Multiset.card_pos.mpr (fun eq => by simp [eq] at ep)
    obtain ⟨v,fl,vq⟩:=residual_clean h away pos
    obtain ⟨a,b,es,bag,r,_,ep⟩:= component_route h.balance v
    rw [vq] at bag ep
    obtain ⟨rfl,rfl⟩:=ep.2 away
    have len : es.length=(part X q).card := congrArg Multiset.card bag
    have wd (x) (hx : x∈es) := h.edges_seven x (in_part.mp (bag ▸ (show x∈(↑es : Multiset Block) from hx))).1
    refine Finset.mem_filter.mpr ⟨?_,away,len ▸ closed_clean fl r wd (by omega)⟩
    rw [←eq,on_edge orig]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr orig),rfl⟩)))
  · intro mem
    obtain ⟨_,away,sz⟩:=Finset.mem_filter.mp mem
    obtain ⟨e,he⟩:=Multiset.exists_mem_of_ne_zero (show part X q≠0 by intro eq; simp [eq] at sz)
    obtain ⟨orig,eq⟩:=in_part.mp he
    exact Finset.mem_erase.mpr ⟨away,Finset.mem_image.mpr ⟨src e,
      Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,orig,rfl⟩),eq⟩⟩

theorem component_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858) :
    (occupied X s).card≤108 ∧ (large X s≠∅ → (occupied X s).card≤102) :=
  occupied_active h ▸ active_le h budget

#print axioms component_limit

end ExactWordFlow.RotationComponentCount

import HundredDecomposition

namespace ExactWordFlow.NearHundredShape
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence ResidualRoutes
open RotationComponentCount GlobalDensity66 MarkedLargeCap
open scoped Classical
open private partition wheel_list from HundredDecomposition
open private count_cap from DensityBudget
open private select from RouteDensity

private noncomputable abbrev Cost (X : Multiset Block) (q : Component X) := (part X q).card
private noncomputable def hits (X : Multiset Block) (s : Block) (q : Component X) :=
  (contacts (support X s) (label X) q).card

private theorem local_rank {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (q : Component X) (hq : q∈occupied X s) :
    7*(hits X s q-1)+(if 6<Cost X q then 6 else 0) ≤ 35+6*(Cost X q-6) := by
  classical
  obtain ⟨away,inLabels⟩:=Finset.mem_erase.mp hq
  have act : q∈active X s := occupied_active h ▸ hq
  have minSz : 6≤Cost X q := (Finset.mem_filter.mp act).2.2
  obtain ⟨v,clean,key⟩:=residual_clean h away (show 0<Cost X q by omega)
  obtain ⟨a,b,es,eq,r,lv,ep⟩:=component_route h.balance v
  rw [key] at eq lv ep
  obtain ⟨aa,bb⟩:=ep.2 away
  subst a; subst b
  have len : es.length=Cost X q:=congrArg Multiset.card eq
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
  have incl : hits X s q≤classCount v es:=contacts_bound _ lv r eq
  obtain ⟨u,I,walk,cyclic,cnt⟩:=closed_observations r wd (by omega)
  by_cases long : 6<Cost X q
  · have avg:=cyclic_7 walk cyclic (by omega : 7≤es.length)
    rw [cnt,len] at avg
    simp only [ite_eq_left long]
    omega
  · have cap:=count_cap (fun i=>i%es.length∈I) 0 es.length
    rw [cnt,len] at cap
    simp only [ite_eq_right long]
    omega

private theorem rank_partition {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    separateRank X s=(hits X s (label X s)-1)+ ∑q∈occupied X s,(hits X s q-1) := by
  classical
  let Q:=(support X s).image (label X)
  let home:=label X s
  let activeQ:=insert home (occupied X s)
  have incl : activeQ⊆Q := by
    intro q hq
    rcases Finset.mem_insert.mp hq with rfl|away
    · exact Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
    obtain ⟨seen,_,_⟩:=Finset.mem_filter.mp (show q∈active X s from occupied_active h ▸ away)
    exact seen
  have inactive (q) (inQ : q∈Q) (inactiveQ : q∉activeQ) : hits X s q-1=0 := by
    have homeDiff : q≠home := fun e=>inactiveQ (Finset.mem_insert.mpr (Or.inl e))
    have no : q∉occupied X s := fun v=>inactiveQ (Finset.mem_insert_of_mem v)
    have empty : part X q=0 := by
      by_contra nonempty
      obtain ⟨e,he⟩:=Multiset.exists_mem_of_ne_zero nonempty
      obtain ⟨orig,atQ⟩:=in_part.mp he
      exact no (Finset.mem_erase.mpr ⟨homeDiff,Finset.mem_image.mpr ⟨src e,
        Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,orig,rfl⟩),atQ⟩⟩)
    obtain ⟨v,_,key⟩:=Finset.mem_image.mp inQ
    obtain ⟨a,b,es,eq,r,lv,_⟩:=component_route h.balance v
    rw [key] at eq lv
    have bound : hits X s q≤classCount a es := contacts_bound _ lv r eq
    rw [empty] at eq
    have nil : es=[] := by simpa using eq
    rw [nil] at bound
    have tiny : classCount a []≤1 := by by_cases good : full a <;> simp [classCount,touched,good]
    omega
  have setup:=Finset.sum_subset incl inactive
  have n : home∉occupied X s := Finset.notMem_erase _ _
  change ∑q∈activeQ,(hits X s q-1)= separateRank X s at setup
  rw [Finset.sum_insert n] at setup
  exact setup.symm

private theorem totals {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    let Q:=occupied X s
    let E:=∑q∈Q,(Cost X q-6)
    let R:=∑q∈Q,(hits X s q-1)
    Cost X (label X s)+6*Q.card+E=X.card ∧
      7*R+(if 0<E then 6 else 0)≤35*Q.card+6*E := by
  classical
  let Q:=occupied X s
  let E:=∑q∈Q,(Cost X q-6)
  change Cost X (label X s)+6*Q.card+E=X.card ∧ _
  have mass:=congrArg Multiset.card (partition X s)
  rw [Multiset.card_add,Multiset.card_sum] at mass
  have each (q) (hq : q∈Q) : Cost X q=6+(Cost X q-6) := by
    have minSz : 6≤Cost X q := (Finset.mem_filter.mp (show q∈active X s from occupied_active h ▸ hq)).2.2
    omega
  have eq:=Finset.sum_congr rfl each
  simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul] at eq
  have upper:=Finset.sum_le_sum (s:=Q) (fun q hq=>local_rank h q hq)
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_const,smul_eq_mul] at upper
  refine ⟨?_,?_⟩
  · change X.card=Cost X (label X s)+∑ q∈Q,Cost X q at mass
    change (∑q∈Q,Cost X q)=_*_+E at eq
    omega
  · change 7*(∑q∈Q,(hits X s q-1))+(if 0<E then 6 else 0)≤35*Q.card+6*E
    by_cases positive : 0<E
    · have someQ : ∃q∈Q,6<Cost X q := by
        by_contra! small
        have z : E=0 := Finset.sum_eq_zero (fun q hq => Nat.sub_eq_zero_of_le (small q hq))
        omega
      obtain ⟨q,hq,size⟩:=someQ
      have take:=Finset.single_le_sum (s:=Q) (f:=fun q=>if 6<Cost X q then 6 else 0)
        (fun _ _=>Nat.zero_le _) hq
      simp only [ite_eq_left size] at take
      simp only [ite_eq_left positive]
      dsimp [E] at *
      omega
    · simp only [ite_eq_right positive]
      dsimp [E] at *
      omega


private theorem shape_of_frontier
    (frontier : ∀{a b : Block} {es : List Block} {N E R : Nat}, Route src dst a es b →
      (∀e∈es,e.length=7) → 96≤N → N≤100 → 258≤es.length → es.length+6*N+E≤858 →
      719≤(classCount a es-1)+R → 7*R+(if 0<E then 6 else 0)≤35*N+6*E →
      E=0 ∧ es.length+6*N=858 ∧ classCount a es+5*N=720 ∧ R=5*N)
    {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (near : 96≤(occupied X s).card) :
    let N:=(occupied X s).card
    X.card=858 ∧ (part X (label X s)).card+6*N=858 ∧
      separateRank X s=719 ∧ hits X s (label X s)+5*N=720 ∧
      ∀q∈occupied X s,(part X q).card=6 ∧ ∃v,full v ∧ label X v=q ∧ part X q=↑(GlobalWheelRank.wheel v) := by
  classical
  let Q:=occupied X s
  let N:=Q.card
  let E:=∑q∈Q,(Cost X q-6)
  let R:=∑q∈Q,(hits X s q-1)
  change 96≤N at near
  have high : N≤100 := MarkedComponentCap.component_limit h budget
  have noBig : large X s=∅ := by
    by_contra! someBig
    have bound : N≤95 :=large_le h budget someBig
    omega
  have home:= (MarkedComponentCap.component_prices h budget).2 noBig
  obtain ⟨a,b,es,eq,route,lab,ep⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ep.1 rfl
  subst a; subst b
  have len : es.length=Cost X (label X s) := congrArg Multiset.card eq
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
  have hit : hits X s (label X s)≤classCount s es := contacts_bound _ lab route eq
  obtain ⟨mass,weight⟩:=totals h
  change Cost X (label X s)+6*N+E=X.card at mass
  change 7*R+(if 0<E then 6 else 0)≤35*N+6*E at weight
  have rank:=rank_partition h
  change separateRank X s=(hits X s (label X s)-1)+R at rank
  have floor : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  change 258≤Cost X (label X s) at home
  obtain ⟨zero,tight,full,contrib⟩:=frontier route wd near high (by omega) (by omega) (by omega) weight
  have each (q) (hq : q∈Q) : Cost X q=6 := by
    have sub := Finset.single_le_sum (s:=Q) (f:=fun q=>Cost X q-6) (fun _ _=>Nat.zero_le _) hq
    change Cost X q-6≤E at sub
    have minSz : 6≤Cost X q := (Finset.mem_filter.mp (show q∈active X s from occupied_active h ▸ hq)).2.2
    omega
  change X.card=858 ∧ Cost X (label X s)+6*N=858 ∧ separateRank X s=719 ∧
    hits X s (label X s)+5*N=720 ∧ _
  refine ⟨by omega,by omega,by omega,by omega,fun q hq=>⟨each q hq,?_⟩⟩
  exact six_component h (Finset.mem_erase.mp hq).1 (each q hq)

/-- Reconstruct the exact root and list of six-wheel components, not just
their aggregate sizes. Their original literal edge multiplicities are preserved. -/
private theorem decompose_of_shape {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {N : Nat} (card : (occupied X s).card=N) (near : 96≤N) (high : N≤100)
    (rootSize : (part X (label X s)).card+6*N=858)
    (rootTags : hits X s (label X s)+5*N=720)
    (closed : ∀q∈occupied X s,∃v,full v ∧ label X v=q ∧ part X q=↑(GlobalWheelRank.wheel v)) :
    ∃es ws : List Block,∃z : Block,∃u : ℕ→Block,∃I : Finset ℕ,
      Route src dst s es t ∧ es.length+6*N=858 ∧ (∀e∈es,e.length=7) ∧ classCount s es+5*N=720 ∧
      ws.length=N ∧ (∀v∈ws,full v) ∧ (ws.map (label X)).Nodup ∧
      X=↑es+EmbeddedWheels.turns ws ∧ z.length=es.length+6 ∧ z.take 6=s ∧ windows z=es ∧
      Walk u ∧ u 0=s ∧ u es.length=t ∧ positions u (es.length+1)=s::es.map dst ∧
      Marked u (·∈I) ∧ count (·∈I) 0 (es.length+1)+5*N=720 := by
  classical
  obtain ⟨a,b,es,bag,r,eq,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len : es.length=(part X (label X s)).card:=congrArg Multiset.card bag
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have cover : hits X s (label X s)≤classCount s es:=contacts_bound _ eq r bag
  have lim:=WeightedMarks.path_cap r wd
  have rank : classCount s es+5*N=720 := by omega
  obtain ⟨ws,num,legal,unique,packet⟩:=wheel_list (occupied X s) closed
  have split:=partition X s
  rw [←bag,←packet] at split
  obtain ⟨z,length,start,word⟩:=RotationReinsert.spell_route r h.start_six wd
  obtain ⟨u,walk,first,last,points⟩:=route_walk r wd
  obtain ⟨I,mark,cnt⟩:=select u (es.length+1)
  rw [points] at cnt
  exact ⟨es,ws,z,u,I,r,by omega,wd,rank,num.trans card,fun x hx=>(legal x hx).1,
    unique,split,length,start,word,walk,first,last,points,mark,by rw [cnt];exact rank⟩

/-- At these five values the marked-walk price is sufficient to rule out
any surplus over six per closed component. Only integer inequalities enter. -/
private theorem integer_frontier {a b : Block} {es : List Block} {N E R : Nat}
    (route : Route src dst a es b) (width : ∀e∈es,e.length=7)
    (lo : 96≤N) (hi : N≤100) (length : 258≤es.length) (mass : es.length+6*N+E≤858)
    (rank : 719≤(classCount a es-1)+R)
    (closedPrice : 7*R+(if 0<E then 6 else 0)≤35*N+6*E) :
    E=0 ∧ es.length+6*N=858 ∧ classCount a es+5*N=720 ∧ R=5*N := by
  have openPrice:=WeightedMarks.path_cap route width
  have small : E≤24 := by omega
  by_cases nonzero : 0<E
  · rw [ite_eq_left nonzero] at closedPrice
    omega
  · rw [ite_eq_right nonzero] at closedPrice
    omega

/-- For all five counts the entire budget is saturated. Every nonroot
component is literally one six-wheel, and the root and rank are exact. -/
theorem near_shape {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (near : 96≤(occupied X s).card) :
    let N:=(occupied X s).card
    X.card=858 ∧ (part X (label X s)).card+6*N=858 ∧ separateRank X s=719 ∧
      (contacts (support X s) (label X) (label X s)).card+5*N=720 ∧
      ∀q∈occupied X s,(part X q).card=6 ∧ ∃v,full v ∧ label X v=q ∧ part X q=↑(GlobalWheelRank.wheel v) :=
  shape_of_frontier (@integer_frontier) h budget near

/-- Gives one actual residual path, its spelling and marks, and all N actual
wheels. Applicable also at 96, 97, 98, and 99 components. -/
theorem decompose {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    {N : Nat} (card : (occupied X s).card=N) (near : 96≤N) :
    ∃es ws : List Block,∃z : Block,∃u : ℕ→Block,∃I : Finset ℕ,
      Route src dst s es t ∧ es.length+6*N=858 ∧ (∀e∈es,e.length=7) ∧ classCount s es+5*N=720 ∧
      ws.length=N ∧ (∀v∈ws,full v) ∧ (ws.map (label X)).Nodup ∧
      X=↑es+EmbeddedWheels.turns ws ∧ z.length=es.length+6 ∧ z.take 6=s ∧ windows z=es ∧
      Walk u ∧ u 0=s ∧ u es.length=t ∧ positions u (es.length+1)=s::es.map dst ∧
      Marked u (·∈I) ∧ count (·∈I) 0 (es.length+1)+5*N=720 := by
  have high:=(MarkedComponentCap.component_limit h budget)
  obtain ⟨_,root,_,colors,every⟩:=near_shape h budget (card ▸ near)
  rw [card] at root colors
  exact decompose_of_shape h card near (card ▸ high) root colors (fun q hq=>(every q hq).2)

#print axioms near_shape
#print axioms decompose
end ExactWordFlow.NearHundredShape

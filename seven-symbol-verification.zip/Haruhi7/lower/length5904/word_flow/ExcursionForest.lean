import ReturnRoutes

namespace ExactWordFlow.ExcursionForest
open SevenWordWindows RotationCore RotationReinsert LapSkeleton DirectedEuler ResidualDensity ExcursionCore ReturnFootprints

abbrev Packet := List Block

def ShortReturn (p : Packet) : Prop :=
  (∃s,Route src dst s p s) ∧ (∀e∈p,e.length=7) ∧ 8≤p.length ∧ p.length≤10

inductive Linked : List Packet → Prop
  | one (p : Packet) : Linked [p]
  | attach {p : Packet} {ps : List Packet} (tail : Linked ps)
      (touch : (labels p ∩ labels ps.flatten).Nonempty) : Linked (p::ps)

private theorem labels_append (a b : Packet) : labels (a++b)=labels a∪labels b := by simp [ReturnFootprints.labels]

private theorem summed {ps : List Packet} (good : ∀p∈ps,ShortReturn p) :
    8*ps.length≤ps.flatten.length := by
  induction ps with
  | nil => simp
  | cons p ps ih =>
    have len := (good p List.mem_cons_self).2.2.1
    have tail := ih (fun q h=>good q (List.mem_cons_of_mem _ h))
    simp only [List.length_cons,List.flatten_cons,List.length_append]
    omega

private theorem union_bound {ps : List Packet} (good : ∀p∈ps,ShortReturn p)
    (linked : Linked ps) : (labels ps.flatten).card ≤ ps.length + 1 := by
  have card (p : Packet) (ok : ShortReturn p) : (labels p).card≤2 := by
    obtain ⟨⟨s,r⟩,wide,small,large⟩:=ok
    exact short_return r wide (by omega) large
  induction linked with
  | one p => simpa using card p (good p (by simp))
  | @attach p ps link touch ih =>
    have less:=ih (fun q h=>good q (List.mem_cons_of_mem _ h))
    have here:=card p (good p List.mem_cons_self)
    have both:=Finset.card_union_add_card_inter (labels p) (labels ps.flatten)
    have pos:=Finset.card_pos.mpr touch
    simp only [List.length_cons,List.flatten_cons,labels_append]
    omega

/-- For any excisable collection of short returns, its distinct endangered
completions outnumber the returns. Applied to all subcollections this rules
out a cycle in their graph, including two coincident edges. -/
theorem private_classes {w : Block} {limit : Nat} (min : Minimal limit w)
    {s t : Block} {keep : Packet} (r : Route src dst s keep t)
    (start : s.length=6) (width : ∀e∈keep,e.length=7) (tags : HoldsAll s keep)
    {ps : List Packet} (good : ∀p∈ps,ShortReturn p) (nonempty : ps≠[])
    (split : keep.length+ps.flatten.length=(windows w).length) :
    ps.length < (lost w keep).card := by
  have m:=summed good
  have pos : 0<ps.length:=List.length_pos_iff.mpr nonempty
  have pay:=retained_route min r start width tags (by omega)
  omega

/-- A connected collection of excisable 8--10 step returns can spend at
most six total letters above seven per return, including the slack of the
original score. In particular there are at most six returns in a component. -/
theorem component_bound {w : Block} {limit : Nat} (min : Minimal limit w)
    {s t : Block} {keep : Packet} (r : Route src dst s keep t)
    (start : s.length=6) (width : ∀e∈keep,e.length=7) (tags : HoldsAll s keep)
    {ps : List Packet} (good : ∀p∈ps,ShortReturn p) (linked : Linked ps)
    (account : ∀e∈windows w,e∈keep ∨ e∈ps.flatten)
    (split : keep.length+ps.flatten.length=(windows w).length) :
    limit-score w+(ps.flatten.length-7*ps.length)≤6 ∧ ps.length≤6 := by
  have nonempty : ps≠[]:=by cases linked <;> simp
  have card:=Finset.card_le_card (lost_subset account)
  have upper:=union_bound good linked
  have debt:=summed good
  have pos : 0<ps.length:=List.length_pos_iff.mpr nonempty
  have limit':=retained_route min r start width tags (by omega)
  omega

#print axioms private_classes
#print axioms component_bound
end ExactWordFlow.ExcursionForest

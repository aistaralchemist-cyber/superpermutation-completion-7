import CycleCutDual
import ExtensionResidue

namespace ExactWordFlow.SupportExclusion

/-- A dual bound for a cut-open exceptional circuit may lose one unit per
extra circuit. Each such circuit already costs a unit in the genus identity.
This criterion needs no specific support cardinality or endpoint. -/
theorem support_bound {M e q g s L boundD : Nat}
    (present : 1 ≤ e) (mass : M + 6 * q = e + q + 719 + 2 * g)
    (length : L = 5764 + e + q + s + 2 * g) (price : boundD + 1 ≤ s + e) :
    5765 + boundD + ((720 - M + 4) / 5) + 2 * g ≤ L := by omega

/-- On any possible counterexample the sum of these two independently
certified quantities falls at least one short of 140. -/
theorem required_gap {M e q g s L boundD : Nat}
    (present : 1 ≤ e) (mass : M + 6 * q = e + q + 719 + 2 * g)
    (length : L = 5764 + e + q + s + 2 * g) (price : boundD + 1 ≤ s + e) (short : L ≤ 5904) :
    boundD + ((720 - M + 4) / 5) + 2 * g ≤ 139 := by
  have bound:= support_bound present mass length price
  omega

#print axioms support_bound
#print axioms required_gap
end ExactWordFlow.SupportExclusion

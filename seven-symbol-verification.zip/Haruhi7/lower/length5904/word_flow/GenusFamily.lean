import PermutationGenus

namespace ExactWordFlow.PermutationGenus
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- In any nonempty family of nontrivial correction cycles, the surplus
incidence rank fits in the same global genus budget. Intersections of
different correction cycles and duplicate tags within a single cycle
both count. -/
theorem family_budget {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (sevenClasses : Fintype.card Y=720) {g : Nat}
    (genus : h.support.card=h.cycleType.card+719+2*g)
    (S : Finset (Perm X)) (legit : S ⊆ h.cycleFactorsFinset) (nonempty : S.Nonempty) :
    (∑c∈S,(c.support.card-1)) ≤ (S.biUnion fun c => c.support.image tag).card-1+2*g := by
  classical
  let H := h.cycleFactorsFinset
  let t (c : Perm X) := c.support.image tag
  let U := S.biUnion t
  obtain ⟨Z,base,bound,closed⟩:=GlobalWheelRank.grow U ((H \ S).image t)
  obtain ⟨c,hc⟩:=nonempty
  obtain ⟨seed,movedSeed,_⟩:=(Perm.mem_cycleFactorsFinset_iff.mp (legit hc)).1
  have memSeed : tag seed∈U:=Finset.mem_biUnion.mpr ⟨_,hc,
    Finset.mem_image_of_mem _ (Perm.mem_support.mpr movedSeed)⟩
  have step (x) (mem : tag x∈Z) : tag ((R*h) x)∈Z := by
    rw [Perm.mul_apply,rot]
    by_cases fix : h x=x
    · simpa [fix] using mem
    · have moved:=Perm.mem_support.mpr fix
      have group : h.cycleOf x∈H:=Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr moved
      have contains (y) (hxy : h.SameCycle x y) : tag y∈t (h.cycleOf x) :=
        Finset.mem_image_of_mem _ (Perm.mem_support_cycleOf_iff.mpr ⟨hxy,moved⟩)
      have dest:=contains _ (Perm.sameCycle_apply_right.mpr (.refl _ _))
      by_cases chosen : h.cycleOf x∈S
      · exact base (Finset.mem_biUnion.mpr ⟨_,chosen,dest⟩)
      · exact closed _ (Finset.mem_image_of_mem _ (Finset.mem_sdiff.mpr ⟨group,chosen⟩))
          ⟨_,Finset.mem_inter.mpr ⟨mem,contains x (.refl _ _)⟩⟩ dest
  have walk : ∀n : Nat,tag (((R*h)^n) seed)∈Z := by
    intro n
    induction n with
    | zero => simpa using base memSeed
    | succ n ih => simpa [pow_succ',Perm.mul_apply] using step _ ih
  have eq : Z=Finset.univ := by
    apply Finset.eq_univ_of_forall
    intro j
    obtain ⟨y,rfl⟩:=onto j
    obtain ⟨n,_,_,eq⟩:=((oneOrbit seed).symm.trans (oneOrbit y)).exists_pow_eq _
    exact eq ▸ walk n
  have charge : (∑u∈(H \ S).image t,(u.card-1)) ≤ ∑c∈H \ S,(c.support.card-1) := by
    calc _ ≤ ∑c∈H \ S,((t c).card-1) := Finset.sum_image_le_of_nonneg (fun _ _=>Nat.zero_le _)
         _ ≤ _ := Finset.sum_le_sum (fun c _ => Nat.sub_le_sub_right Finset.card_image_le _)
  have total : (∑c∈H,(c.support.card-1))+H.card=h.support.card := by
    have e : (∑c∈H,(c.support.card-1+1))= ∑c∈H,c.support.card := by
      apply Finset.sum_congr rfl
      intro c hc
      obtain ⟨x,hx,_⟩:=(Perm.mem_cycleFactorsFinset_iff.mp hc).1
      have pos:=Finset.card_pos.mpr (show c.support.Nonempty from ⟨x,Perm.mem_support.mpr hx⟩)
      omega
    simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] at e
    exact e.trans h.sum_cycleType
  have pieces : h.cycleType.card=H.card := by simp [H,Perm.cycleType_def]
  have split := Finset.sum_sdiff (f:=fun c : Perm X=>c.support.card-1) legit
  change (∑c∈H \ S,(c.support.card-1))+(∑c∈S,(c.support.card-1))=
    ∑c∈H,(c.support.card-1) at split
  simp only [eq,Finset.card_univ,sevenClasses] at bound
  have posU:= Finset.card_pos.mpr (show U.Nonempty from ⟨_,memSeed⟩)
  change (∑c∈S,(c.support.card-1))≤U.card-1+2*g
  omega

#print axioms family_budget
end ExactWordFlow.PermutationGenus

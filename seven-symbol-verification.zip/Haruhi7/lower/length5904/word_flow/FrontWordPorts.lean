import FrontBinary
import FrontWindowIndex

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows CoreRecordBits SortedCoreRecords CoreCandidateBanks FrontRawBudget
open CompactFrontPlan FrontLocalMeaning

private theorem row_default {R : α→β→Prop} [Inhabited α] [Inhabited β] {rows : Array α}
    {bs : Nat→β} {n : Nat} (h : ArrayRel R rows ((Array.range n).map bs)) (i : Nat) (hi : i<n) (missing : α) :
    R ((rows[i]?).getD missing) (bs i) := by
  have hr : rows.size=n := by simpa using h.size
  have hb : i<rows.size := hr ▸ hi
  have val := h.get i hb
  simpa [hb,hi,getElem!_pos,Array.getElem?_eq_getElem] using val

private theorem flatRep {v : Nat→Bool} (iList : List Nat) (jList : List Nat)
    (f : Nat→Nat→Bool) (g : Nat→Nat→W) (h : ∀i∈iList,∀j∈jList,Rep v (f i j) (g i j)) :
    List.Forall₂ (Rep v) (iList.flatMap (fun i=>jList.map (f i))) (iList.flatMap (fun i=>jList.map (g i))) := by
  induction iList with
  | nil => exact .nil
  | cons i is ih =>
    exact List.rel_append (rep_map jList (h _ List.mem_cons_self))
      (ih fun x hx=>h _ (List.mem_cons_of_mem _ hx))

private theorem array_default {v : Nat→Bool} (unit : v 0=true) {bs : Array Bool} {r : Bits}
    (h : BitsRep v bs r) (a : Nat) : Rep v ((bs[a]?).getD false) ((r[a]?).getD (-1)) := by
  simpa only [Array.getElem?_toList] using default_rep unit h a

theorem ports_for_word {w : Block} (len : w.length=1501) {v : Nat→Bool} (unit : v 0=true)
    {cols bits : Rows} (hc : ArrayRel (RowRep v 7) cols ((Array.range 1501).map (hot w)))
    (hb : ArrayRel (fun r bs=>BitsRep v (rawBinary bs) r) bits ((Array.range 1501).map (hot w)))
    {i : Nat} (hi : i<1496) :
    BitsRep v (inputPorts (sliceAt w i 6)) (recordPorts cols bits i) := by
  unfold inputPorts recordPorts ports BitsRep
  simp only [Array.toList_append,Array.toList_flatMap,Array.toList_map,Array.toList_range]
  apply List.rel_append
  · apply List.rel_append
    · exact .cons (one_rep unit) .nil
    · apply flatRep
      intro lane hm a ha
      have al := List.mem_range.mp ha
      by_cases lim : lane<6
      · have hrow := (row_default hc (i+lane) (by omega) #[]).2
        have bit := array_default unit (List.Forall₂.flip hrow) a
        simpa [hot,sliceAt,List.getElem?_take,List.getElem?_drop,lim,al] using bit
      · simpa [sliceAt,List.getElem?_take,lim] using zero_rep unit
  · apply flatRep
    intro lane hm b hb'
    have ll := List.mem_range.mp hm
    have bl := List.mem_range.mp hb'
    have lt : i+lane<1501 := by omega
    have r := row_default hb (i+lane) lt #[]
    have bit := array_default unit r b
    rw [binary_symbol (i:=i+lane) (j:=⟨b,bl⟩) (w:=w) (by omega)] at bit
    simpa [sliceAt,List.getElem?_take,List.getElem?_drop,ll] using bit

theorem next_for_word {w : Block} (len : w.length=1501) {v : Nat→Bool}
    {cols : Rows} (hc : ArrayRel (RowRep v 7) cols ((Array.range 1501).map (hot w)))
    (i : Nat) :
    BitsRep v (optionalHot (w[i+6]?)) ((cols[i+6]?).getD #[]) := by
  by_cases h : i+6<1501
  · have raw := row_default hc (i+6) h #[]
    have inWord : i+6<w.length := len ▸ h
    have eq := List.getElem?_eq_getElem inWord
    have same : hot w (i+6) = optionalHot (w[i+6]?) := by simp [eq,hot,optionalHot]
    rw [←same]
    exact List.Forall₂.flip raw.2
  · have clen : cols.size=1501 := by simpa using hc.size
    have hn : w.length ≤ i+6 := by omega
    have bn : cols.size ≤ i+6 := by omega
    simp only [List.getElem?_eq_none hn,Array.getElem?_eq_none bn,Option.getD_none,optionalHot]
    exact .nil


end ExactWordFlow.CompactWordCircuit

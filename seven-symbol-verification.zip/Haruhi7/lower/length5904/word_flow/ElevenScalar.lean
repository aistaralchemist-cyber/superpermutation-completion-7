import GlobalClosedPrice
import ShortMarked

namespace ExactWordFlow.ElevenLong
open ResidualDensity DirectedEuler
open private initial from MarkedDensity
open private closeCap from Cap93Mass
open private price from GlobalClosedPrice

def Oracle : Prop :=
  ∀{s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀e∈es,e.length=7) {k c : Nat}
    (bounds : (k,c)∈[(265,225),(413,350),(426,361),(432,366),(438,371),(445,377)])
    (len : es.length=k), classCount s es≤c

private def openCap (r : Nat) : Nat :=
  if r=265 then 225 else if r=413 then 350 else if r=426 then 361
  else if r=432 then 366 else if r=438 then 371 else if r=445 then 377
  else ShortMarked.upper (r+1) initial

theorem open_price (o : Oracle) {s t : Block} {es : List Block}
    (r : Route src dst s es t) (wd : ∀e∈es,e.length=7) (small : es.length≤466) :
    classCount s es≤openCap es.length := by
  unfold openCap
  split
  next e => exact o r wd (k:=265) (by decide) e
  next =>
    split
    next e => exact o r wd (k:=413) (by decide) e
    next =>
      split
      next e => exact o r wd (k:=426) (by decide) e
      next =>
        split
        next e => exact o r wd (k:=432) (by decide) e
        next =>
          split
          next e => exact o r wd (k:=438) (by decide) e
          next =>
            split
            next e => exact o r wd (k:=445) (by decide) e
            next => exact ShortMarked.route_upper r wd (by omega)

private def choices : List Nat := [21,28,34,35,60,156,169,182,195,201,208]

private theorem choices_cover : ∀k : Fin 859, 6<k.val →
    38*k.val≤45*(closeCap k.val-1)+33 → k.val∈choices := by native_decide

private theorem choices_low : ∀k∈choices,21≤k := by decide

private theorem finite_bound :
    choices.all (fun k=>choices.all (fun l=>(List.range 3).all (fun d=>(List.range 467).all (fun r=>
      decide (r+350+k+l+6*d≤858 →
        openCap r-1+290+(closeCap k-1)+(closeCap l-1)+5*d<719)))))=true := by native_decide

theorem scalar (k l r d a : Nat) (hk : 6<k) (hl : 6<l) (hd : d≤2)
    (mass : r+350+k+l+6*d≤858)
    (rank : 719≤a-1+290+(closeCap k-1)+(closeCap l-1)+5*d)
    (root : 45*(a-1)≤38*r+59) (cap : r≤466 → a≤openCap r) : False := by
  have charge (n : Nat) (large : 6<n) : 45*(closeCap n-1)+25≤38*n := by
    have pr:=price n (closeCap n) (by omega) (Nat.le_refl _)
    simp only [GlobalClosedPrice.fee,if_pos large] at pr
    omega
  have ck:=charge k hk
  have cl:=charge l hl
  have mk:=choices_cover ⟨k,by omega⟩ hk (by change 38*k≤45*(closeCap k-1)+33; omega)
  have ml:=choices_cover ⟨l,by omega⟩ hl (by change 38*l≤45*(closeCap l-1)+33; omega)
  change k∈choices at mk
  change l∈choices at ml
  have lo:=choices_low k mk
  have lo':=choices_low l ml
  have rr : r≤466:=by omega
  have v:=cap rr
  have f:=finite_bound
  simp only [List.all_eq_true,List.mem_range,decide_eq_true_eq] at f
  have neg:=f k mk l ml d (by omega) r (by omega) mass
  omega

#print axioms scalar
end ExactWordFlow.ElevenLong

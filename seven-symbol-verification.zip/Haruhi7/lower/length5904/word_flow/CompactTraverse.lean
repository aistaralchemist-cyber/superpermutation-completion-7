import CompactGateSemantics

namespace ExactWordFlow.CompactWordCircuit

abbrev Test := Nat → Event → Prop

def sourceTest (input : Source → Bool) (v : Nat → Bool) : Test := fun n e =>
  match e with
  | .fresh s => v n = input s
  | .assertion _ => True
  | .gateOr xs => gateMeaning v (Int.ofNat (n+1)) (.gateOr xs)
  | .gateMux c a b => gateMeaning v (Int.ofNat (n+1)) (.gateMux c a b)

def admits (T : Test) (n : Nat) : List Event → Prop
  | [] => True
  | e::es => T n e ∧ admits T (advance n e) es

theorem admits_append (T : Test) (n : Nat) (a b : List Event) :
    admits T n (a++b) ↔ admits T n a ∧ admits T (a.foldl advance n) b := by
  induction a generalizing n with
  | nil => simp [admits]
  | cons x xs ih => simp [admits,ih,and_assoc]

def Grows (m : M α) := ∀ st, ∃ es : List Event,
  (m st).2.body.toList = st.body.toList ++ es ∧ (m st).2.vars = es.foldl advance st.vars

def Gives (T : Test) (m : M α) (P : α → Prop) :=
  ∀ st, admits T st.vars ((m st).2.body.toList.drop st.body.size) → P (m st).1

theorem pure_grows (a : α) : Grows (pure a) := fun _st=>⟨[],(List.append_nil _).symm, rfl⟩

theorem bind_grows {m : M α} {k : α → M β}
    (hm : Grows m) (hk : ∀a,Grows (k a)) : Grows (m >>= k) := by
  intro st
  obtain ⟨a,ra,na⟩ := hm st
  obtain ⟨b,rb,nb⟩ := hk (m st).1 (m st).2
  exact ⟨a++b,by change ((k (m st).1 (m st).2).2.body.toList)=_; rw [rb,ra,List.append_assoc],
    by change ((k (m st).1 (m st).2).2.vars)=_; rw [nb,na,List.foldl_append]⟩

theorem pure_gives {T : Test} {a : α} {P : α → Prop} (h : P a) :
    Gives T (pure a) P := fun _ _=>h

theorem bind_gives {T : Test} {m : M α} {k : α → M β} {P : α → Prop} {Q : β → Prop}
    (gm : Grows m) (gk : ∀a,Grows (k a)) (hm : Gives T m P)
    (hk : ∀a,P a → Gives T (k a) Q) : Gives T (m >>= k) Q := by
  intro st ok
  obtain ⟨a,ra,na⟩ := gm st
  obtain ⟨b,rb,nb⟩ := gk (m st).1 (m st).2
  change admits T st.vars (((k (m st).1 (m st).2).2.body.toList).drop st.body.size) at ok
  rw [rb,ra,List.append_assoc] at ok
  have raw : admits T st.vars (a++b) := by
    simpa only [← Array.length_toList (xs:=st.body),List.drop_left] using ok
  obtain ⟨oa,ob⟩ := (admits_append ..).mp raw
  apply hk (m st).1 (hm st (by simpa [ra] using oa)) (m st).2
  simpa [rb,na] using ob

theorem alloc_grows (e : Event) (h : ∀xs,e ≠ .assertion xs) : Grows (alloc e) := by
  intro st
  refine ⟨[e],by simp [alloc],?_⟩
  cases e <;> simp_all [alloc,advance]

theorem mapList_grows {f : α → M β} (step : ∀ x,Grows (f x)) :
    ∀ a : List α, Grows (a.mapM f)
  | [] => pure_grows _
  | x::xs => by
    rw [List.mapM_cons]
    exact bind_grows (step x) (fun _=>bind_grows (mapList_grows step xs) (fun _=>pure_grows _))

theorem mapList_gives {T : Test} {f : α → M β} {R : α → β → Prop}
    (grow : ∀ x,Grows (f x)) : ∀ a : List α,
    (∀x∈a,Gives T (f x) (R x)) → Gives T (a.mapM f) (List.Forall₂ R a)
  | [],_ => pure_gives .nil
  | x::xs,h => by
    rw [List.mapM_cons]
    refine bind_gives (m:=f x) (k:=fun v=>do let vs ← xs.mapM f; pure (v::vs)) (P:=R x) (Q:=List.Forall₂ R (x::xs)) (grow x) (fun _=>bind_grows (mapList_grows grow xs) (fun _=>pure_grows _)) (h x List.mem_cons_self) ?_
    intro v hv
    exact bind_gives (m:=xs.mapM f) (k:=fun vs=>pure (v::vs)) (P:=List.Forall₂ R xs) (Q:=List.Forall₂ R (x::xs)) (mapList_grows grow xs) (fun _=>pure_grows _)
      (mapList_gives grow xs (fun y hy=>h y (List.mem_cons_of_mem _ hy)))
      (fun vs hvs=>pure_gives (.cons hv hvs))

theorem mapArray_grows {f : α → M β} (g : ∀x,Grows (f x)) (a : Array α) :
    Grows (a.mapM f) := by
  rw [Array.mapM_eq_mapM_toList]
  exact bind_grows (mapList_grows g _) (fun _=>pure_grows _)

theorem mapArray_gives {T : Test} {f : α → M β} {R : α → β → Prop}
    (a : Array α) (g : ∀x,Grows (f x)) (h : ∀x∈a,Gives T (f x) (R x)) :
    Gives T (a.mapM f) (fun out => List.Forall₂ R a.toList out.toList) := by
  rw [Array.mapM_eq_mapM_toList]
  exact bind_gives (mapList_grows g _) (fun _=>pure_grows _)
    (mapList_gives g _ (fun x hx=>h x (by simpa using hx)))
    (fun vs hv=>pure_gives (by simpa using hv))


theorem foldList_grows {f : β → α → M β} (step : ∀ b x,Grows (f b x)) :
    ∀ (xs : List α) (b : β), Grows (xs.foldlM f b)
  | [],b => pure_grows b
  | x::xs,b => bind_grows (step b x) (foldList_grows step xs)

theorem foldList_gives {T : Test} {f : β → α → M β} {g : γ → α → γ} {R : β → γ → Prop}
    (grow : ∀b x,Grows (f b x)) : ∀(xs : List α) (b : β) (c : γ), R b c →
    (∀ x∈xs, ∀u v, R u v → Gives T (f u x) (fun y => R y (g v x))) →
    Gives T (xs.foldlM f b) (fun y => R y (xs.foldl g c))
  | [],_,_,h,_ => pure_gives h
  | x::xs,b,c,h,step => by
    exact bind_gives (m:=f b x) (k:=xs.foldlM f) (P:=fun y => R y (g c x))
      (Q:=fun y=>R y (xs.foldl g (g c x))) (grow b x) (foldList_grows grow xs)
      (step x List.mem_cons_self b c h)
      (fun y hy=>foldList_gives grow xs y (g c x) hy (fun z hz=>step z (List.mem_cons_of_mem _ hz)))

/-- Convert an actual `for i in [:n]` body which yields each accumulator to an
ordinary monadic fold, preserving the execution order and tape. -/
theorem range_fold (n : Nat) (init : β) (f : β → Nat → M β) :
    forIn [:n] init (fun i b => ForInStep.yield <$> f b i) = (List.range n).foldlM f init := by
  simp only [Std.Legacy.Range.forIn_eq_forIn_range']
  simp [List.range_eq_range']

theorem map_gives {T : Test} {m : M α} {f : α → β} {P : α → Prop} {Q : β → Prop}
    (grow : Grows m) (h : Gives T m P) (post : ∀x, P x → Q (f x)) : Gives T (f <$> m) Q :=
  bind_gives (m:=m) (k:=fun x=>pure (f x)) grow (fun _=>pure_grows _) h
    (fun x hx=>pure_gives (post x hx))

theorem map_grows {m : M α} (f : α → β) (g : Grows m) : Grows (f <$> m) :=
  bind_grows (m:=m) (k:=fun x=>pure (f x)) g (fun _=>pure_grows _)

end ExactWordFlow.CompactWordCircuit

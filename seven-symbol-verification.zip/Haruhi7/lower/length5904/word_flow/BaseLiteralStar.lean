import BaseWheelFrontier92
import BaseRootTags

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows SuperpermutationBounds DirectedEuler ResidualDensity ResidualRoutes
open RotationCore LiteralWheelCover EmbeddedWheels
open scoped Classical

/-- The 260 labels of the remaining path are exactly the labels accessible
to the original base word before any of its 92 wheels are restored. -/
theorem actual_footprint_widths {b v : Block} {rs : List Row} (ins : Inserts b rs v)
    (count : rs.length=92) (done : (complete b).card=92)
    (boardV : (visited v).card=720) (len : v.length=1508) :
    ∃s t es, Route src dst s es t ∧ es.length=306 ∧
      visited b=touched (s::es.map dst) ∧ (visited b).card=260 ∧ (∀e∈es,e.length=7) := by
  obtain ⟨Y,ws,s,t,_,num,clean,flow,total,base⟩:=sharp_residual_rows_bag ins boardV done len
  obtain ⟨es,r,split,edges,cols,_⟩:=pure_92 clean flow total.le (num.trans count)
  have small:=(ins.length_eq)
  have floor:=insertion_bound ins
  have sub:=base_on_path (b:=b) (by omega) (by omega) r (split ▸ base)
  have cap:=Finset.card_le_card sub
  change (touched (s::es.map dst)).card=260 at cols
  refine ⟨s,t,es,r,edges,Finset.eq_of_subset_of_card_le sub (by omega),by omega,?_⟩
  intro e he
  exact flow.edges_seven e (Multiset.mem_add.mpr (Or.inl (split ▸ (show e∈(↑es:Multiset Block) from he))))

theorem actual_footprint {b v : Block} {rs : List Row} (ins : Inserts b rs v)
    (count : rs.length=92) (done : (complete b).card=92)
    (boardV : (visited v).card=720) (len : v.length=1508) :
    ∃s t es, Route src dst s es t ∧ es.length=306 ∧
      visited b=touched (s::es.map dst) ∧ (visited b).card=260 := by
  obtain ⟨s,t,es,r,n,P,c,_⟩:=actual_footprint_widths ins count done boardV len
  exact ⟨s,t,es,r,n,P,c⟩

/-- Each actual wheel has exactly one tag in the base and five private
outside tags. The 92 outside sets are pairwise disjoint, cover the full
complement, and their common base has size 260. -/
theorem direct_partition {b v : Block} {rs : List Row} (ins : Inserts b rs v)
    (count : rs.length=92) (done : (complete b).card=92)
    (boardV : (visited v).card=720) (len : v.length=1508) :
    let P:=visited b
    let f:=fun R : Row=>R \ P
    rs.toFinset.biUnion f=allClasses \ P ∧
    ∀R∈rs.toFinset,(R∩P).card=1 ∧ (f R).card=5 ∧
      Disjoint (f R) ((rs.toFinset.erase R).biUnion f) := by
  classical
  let T:=rs.toFinset
  let P:=visited b
  let f (R : Row):=R \ P
  obtain ⟨_,_,_,_,_,_,size⟩:=actual_footprint ins count done boardV len
  have need : (allClasses \ P).card=460:=by
    rw [Finset.card_sdiff_of_subset (visited_subset b),board,size]
  have entire:=Finset.eq_of_subset_of_card_le (visited_subset v) (by rw [board,boardV])
  have cover : T.biUnion f=allClasses \ P := by
    ext x
    have eq := congrArg (fun A:Row=>x∈A) (ins.visited_eq.symm.trans entire)
    change (x∈P∪T.biUnion id)=(x∈allClasses) at eq
    simp only [Finset.mem_sdiff,←eq,Finset.mem_union,Finset.mem_biUnion,f,id_eq]
    grind
  have caps (R) (hR:R∈T) : R.card=6 ∧ (f R).card≤5 := by
    obtain ⟨u,anchor,clean,eq⟩:=mem_ready.mp (ins.rows_ready hR)
    have sz:R.card=6:=eq ▸ wheel_contacts_six u clean
    have contains : tag u∈WheelContacts.wheel u := by
      exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨0,by decide,by simp⟩)
    have pos:=Finset.card_pos.mpr (show (R∩P).Nonempty from ⟨_,Finset.mem_inter.mpr
      ⟨eq ▸ contains,(mem_visited ..).mpr ⟨u,anchor,clean,rfl⟩⟩⟩)
    have part:=Finset.card_sdiff_add_card_inter R P
    exact ⟨sz,by unfold f;omega⟩
  refine ⟨cover,?_⟩
  intro R hR
  change R∈T at hR
  let U:=(T.erase R).biUnion f
  have lim : (T.erase R).card≤91 := by
    have n:=List.toFinset_card_le rs
    have e:=Finset.card_erase_add_one hR
    change T.card≤rs.length at n
    omega
  have other : U.card≤455:=by
    calc
      U.card≤∑r∈T.erase R,(f r).card:=Finset.card_biUnion_le
      _ ≤ ∑_r∈T.erase R,5 :=Finset.sum_le_sum (fun r hr=>(caps r (Finset.mem_erase.mp hr).2).2)
      _ ≤ 455 :=by simp; omega
  have whole : f R∪U=T.biUnion f:=by
    rw [show T.biUnion f=(insert R (T.erase R)).biUnion f by rw [Finset.insert_erase hR]]
    exact (Finset.biUnion_insert ..).symm
  have num:=Finset.card_union_add_card_inter (f R) U
  rw [whole,cover,need] at num
  have rr:=caps R hR
  have split:=Finset.card_sdiff_add_card_inter R P
  change (f R).card+(R∩P).card=R.card at split
  change (R∩P).card=1 ∧ (f R).card=5 ∧ Disjoint (f R) U
  refine ⟨by omega,by omega,?_⟩
  apply Finset.disjoint_iff_inter_eq_empty.mpr
  exact Finset.card_eq_zero.mp (by omega)

#print axioms actual_footprint
#print axioms direct_partition
end ExactWordFlow.WheelBaseResidual

import ShortMarked
import NoRoot271

namespace ExactWordFlow.LongOpenWindows
open SevenWordWindows ResidualDensity DirectedEuler WeightedMarks MarkedGeometry ShortMarked
open private initial start accepted move memoryWord prefixes from MarkedDensity
open private upper_read upper_step from ShortMarked
open private unmask mask_cons from StrongerDensity
open private canonical normalize from Interval66
open private search_complete from Geometry40
open private runs from MarkedExtrema

private def optimal : Nat → Nat → List (List Bool)
  | 0,_ => [[]]
  | n+1,s =>
    [false,true].flatMap fun b =>
      let j:=move s b
      if j<prefixes.size ∧ b.toNat+upper n j=upper (n+1) s then
        (optimal n j).map (b::·)
      else []

private theorem maximizer (pre bs : List Bool) (s : Nat) (valid : s<prefixes.size)
    (small : bs.length≤478) (suff : memoryWord s <:+ pre)
    (safeWord : ∀x∈forbidden, ¬x <:+: pre++bs) (maximal : upper bs.length s≤bs.count true) :
    bs∈optimal bs.length s := by
  induction bs generalizing s pre with
  | nil => simp [optimal]
  | cons b bs ih =>
    obtain ⟨next,suffix,_⟩:=accepted s b pre bs valid suff safeWord
    have hsz : bs.length<478 := by simpa using small
    have sm : bs.length≤478 := by omega
    have good : ∀x∈forbidden, ¬x <:+: (pre++[b])++bs := by simpa using safeWord
    have tail := upper_read _ _ _ next sm suffix good
    have pay:=upper_step ⟨bs.length,hsz⟩ ⟨s,valid⟩ b next
    change b.toNat+upper bs.length (move s b)≤upper (bs.length+1) s at pay
    have cnt : (b::bs).count true=b.toNat+bs.count true := by cases b <;> simp [Nat.add_comm]
    simp only [List.length_cons,cnt] at maximal
    have win : b.toNat+upper bs.length (move s b)=upper (bs.length+1) s := by omega
    have child:=ih _ _ next sm suffix good (by omega)
    apply List.mem_flatMap.mpr
    refine ⟨b,by cases b <;> simp,?_⟩
    dsimp only
    rw [ite_eq_left ⟨next,win⟩]
    exact List.mem_map.mpr ⟨bs,child,rfl⟩

private def failed (bs : List Bool) : Bool :=
  let ns := runs bs 0
  bs==rowsMask ns && bs.head?==some true && ns.all (fun k=>decide (0<k)) &&
    canonical.all (fun s=> !rowSearch ns s [])

def table : List (Nat × Nat) := [(265,225),(413,350),(426,361),(432,366),(438,371),(445,377)]

private def checked (x : Nat × Nat) : Bool :=
  x.1+1≤478 && upper (x.1+1) initial==x.2+1 && (optimal (x.1+1) initial).all failed

set_option maxHeartbeats 0 in
private theorem data : table.all checked=true := by native_decide

theorem marks (u : Nat→Six) (p : Nat→Prop) [DecidablePred p]
    (w : Walk u) (m : Marked u p) (i : Nat) {k c : Nat} (mem : (k,c)∈table) :
    count p i (k+1)≤c := by
  by_contra! many
  have checkedRow:=List.all_eq_true.mp data _ mem
  unfold checked at checkedRow
  simp only [Bool.and_eq_true,beq_iff_eq,decide_eq_true_eq] at checkedRow
  obtain ⟨⟨size,cap⟩,rest⟩:=checkedRow
  let bs:=mask p i (k+1)
  have len : bs.length=k+1:=by simp [bs,mask]
  have hi : upper bs.length initial≤bs.count true := by rw [len,cap,mark_count]; omega
  have hit:=maximizer [] bs initial start.1 (by omega) (by simp [start.2.1])
    (by simpa [bs] using safe w m i (k+1)) hi
  rw [len] at hit
  have test:=List.all_eq_true.mp rest _ hit
  unfold failed at test
  simp only [Bool.and_eq_true,beq_iff_eq] at test
  obtain ⟨⟨⟨pattern,head⟩,positive⟩,dead⟩:=test
  have first : p i := by
    change (mask p i (k+1)).head?=some true at head
    rw [mask_cons] at head
    exact of_decide_eq_true (Option.some.inj head)
  have marked:=unmask i (k+1) (runs bs 0) pattern
  obtain ⟨v,vw,vm,iv⟩:=normalize w m _ first
  have nz (n) (member : n∈runs bs 0) : 0<n := of_decide_eq_true (List.all_eq_true.mp positive n member)
  have feasible:=search_complete vw vm _ nz _ marked [] (by simp)
  have no:=List.all_eq_true.mp dead _ iv
  simp [feasible] at no

theorem route {s t : Block} {es : List Block} (r : Route src dst s es t)
    (wd : ∀e∈es,e.length=7) {k c : Nat} (bounds : (k,c)∈table) (len : es.length=k) :
    classCount s es≤c := by
  obtain ⟨u,I,walk,mark,eq⟩:=open_observations r wd
  rw [len] at eq
  exact eq ▸ marks u (·∈I) walk mark 0 bounds

#print axioms route
end ExactWordFlow.LongOpenWindows

import PlanarScore390
namespace ExactWordFlow.ForcedRootClosure
open SevenWordWindows SeedWheelCut ExtremeWheelCut
open private widths from ExtremeWheelCut

/-- The tags that any saturated connected root containing P must already
contain, since every neutral wheel touching them also touches P twice. -/
def force (P : Finset Block) : Finset Block := P ∪ allClasses.filter fun d =>
    ∀w∈allRows,d∈w → 2≤(P∩w).card

theorem forced_subset {P A : Finset Block} {W : Finset (Finset Block)}
    (inside : P⊆A) (legal : W⊆allRows)
    (tight : A.card+5*W.card≤allClasses.card) (linked : ClosedCover A allClasses W) :
    force P⊆A := by
  intro d hd
  rcases Finset.mem_union.mp hd with old|new
  · exact inside old
  · obtain ⟨required,blocked⟩ := Finset.mem_filter.mp new
    exact forced_by_seed P A allClasses W d inside required
      (fun w hw=>widths w (legal hw)) tight (fun w hw=>blocked w (legal hw)) linked

theorem iterate_subset {P A : Finset Block} {W : Finset (Finset Block)}
    (inside : P⊆A) (legal : W⊆allRows)
    (tight : A.card+5*W.card≤allClasses.card) (linked : ClosedCover A allClasses W)
    (n : Nat) : (force^[n]) P⊆A := by
  induction n with
  | zero => exact inside
  | succ n ih =>
    rw [Function.iterate_succ_apply']
    exact forced_subset ih legal tight linked

/-- These 378 distinct tags of the score-19 construction force at least
thirteen other ones into any root which only has saturated six-wheels left.
Consequently every possible continuation to a root on at most 390 tags
fails, independently of its final twelve states, costs, and endpoints. -/
def earlyTags := ((PlanarScore390.walk.take 378).map classKey).toFinset

theorem prefix_bound : earlyTags.card=378 ∧ (force earlyTags).card=391 := by native_decide

theorem forbid_all_suffixes {A : Finset Block} {W : Finset (Finset Block)}
    (inside : earlyTags⊆A) (legal : W⊆allRows)
    (size : A.card≤390) (wheels : W.card≤66) : ¬ ClosedCover A allClasses W := by
  intro linked
  have board : allClasses.card=720 := by native_decide
  have bound := Finset.card_le_card
    (forced_subset inside legal (by omega) linked)
  have need := prefix_bound.2
  omega

#print axioms forced_subset
#print axioms iterate_subset
#print axioms prefix_bound
#print axioms forbid_all_suffixes
end ExactWordFlow.ForcedRootClosure

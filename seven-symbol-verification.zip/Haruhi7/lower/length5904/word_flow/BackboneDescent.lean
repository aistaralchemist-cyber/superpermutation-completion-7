import ShortestDescent
import ContactBypass
import RequiredComponent

namespace ExactWordFlow.BackboneDescent
open SevenWordWindows SuperpermutationBounds ResidualRoutes DirectedEuler RequiredComponent

/-- Every mandatory source belongs to a component of the fixed edges met
by the route. Isolated components containing no mandatory source need not be met. -/
def MeetsMandatory (Z : Multiset Block) (a : Block) (es : List Block) : Prop :=
  ∀ p∈required, ∃ v∈a::es.map dst, label (required+Z) (src p)=label (required+Z) v

private theorem kept_label {B G : Multiset Block} (kept : ∀e∈B,e∈G) {u v : Block}
    (eq : label B u=label B v) : label G u=label G v := by
  let S := {x : Block | label G u=label G x}
  have along (e) (he : e∈B) : src e∈S ↔ dst e∈S := by
    change (label G u=label G (src e)) ↔ (label G u=label G (dst e))
    rw [on_edge (kept e he)]
  exact (invariant S along eq).mp rfl

theorem necessary {Z : Multiset Block} {a b s t : Block} {es : List Block}
    (r : Route src dst a es b) (used : es≠[]) (h : Feasible ((↑es : Multiset Block)+Z) s t) :
    MeetsMandatory Z a es := by
  classical
  let B := required+Z
  let V := a::es.map dst
  let S : Set Block := {u | ∃v∈V, label B u=label B v}
  have seen (v) (hv : v∈V) : v∈S := ⟨v,hv,rfl⟩
  have dest (e) (he : e∈es) : dst e∈V := List.mem_cons_of_mem _ (List.mem_map.mpr ⟨e,he,rfl⟩)
  have froms := (r.closed {v : Block | v∈V} List.mem_cons_self (fun e he _ => dest e he)).2
  have fixed (e) (he : e∈B) : src e∈S ↔ dst e∈S := by
    change (∃v∈V, label B (src e)=label B v) ↔ ∃v∈V, label B (dst e)=label B v
    rw [on_edge he]
  have step (e) (he : e∈required+((↑es : Multiset Block)+Z)) : src e∈S ↔ dst e∈S := by
    rcases Multiset.mem_add.mp he with req|more
    · exact fixed _ (Multiset.mem_add.mpr (Or.inl req))
    rcases Multiset.mem_add.mp more with track|remain
    · exact iff_of_true (seen _ (froms e track)) (seen _ (dest e track))
    · exact fixed _ (Multiset.mem_add.mpr (Or.inr remain))
  have root : s∈S := by
    by_contra no
    obtain ⟨e,he⟩ := List.exists_mem_of_ne_nil _ used
    have reach := h.reachable Sᶜ no (fun f hf n y => n ((step f hf).mpr y)) e
      (Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inl he))))
    exact reach (seen _ (froms e he))
  exact fun p hp => h.reachable S root (fun e he => (step e he).mp) p (Multiset.mem_add.mpr (Or.inl hp))

theorem together {Z : Multiset Block} {a b : Block} {es : List Block}
    (r : Route src dst a es b) (hit : MeetsMandatory Z a es) :
    RequiredTogether ((↑es : Multiset Block)+Z) := by
  let G := required+((↑es : Multiset Block)+Z)
  have keep (e) (he : e∈required+Z) : e∈G := by
    rcases Multiset.mem_add.mp he with req|other
    · exact Multiset.mem_add.mpr (Or.inl req)
    · exact Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inr other)))
  have onTrack (p) (hp : p∈required) : label G (src p)=label G a := by
    obtain ⟨v,hv,eq⟩ := hit p hp
    exact (kept_label keep eq).trans (Essential.walk_label r (fun e he =>
      Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inl he)))) hv)
  exact fun p hp q hq => (onTrack p hp).trans (onTrack q hq).symm

/-- A shorter replacement may use different endpoints and different classes
inside each fixed component. It yields a shorter genuine superpermutation. -/
theorem shorten_by_replacement {Z : Multiset Block} {a b : Block} {es qs : List Block}
    (r : Route src dst a qs b) (hit : MeetsMandatory Z a qs)
    (balanced : Z.map src=Z.map dst) (width : ∀e∈((↑qs : Multiset Block)+Z), e.length=7)
    (lt : qs.length<es.length) : Shortenable ((↑es : Multiset Block)+Z) := by
  have bal := r.balance
  have fullbal : ((↑qs : Multiset Block)+Z).map src+{b}=((↑qs : Multiset Block)+Z).map dst+{a} := by
    simp only [Multiset.map_add,add_right_comm _ (Z.map dst) _,
      balanced,bal]
  obtain ⟨Y,sub,u,v,yes⟩ := feasible_submultiset width fullbal (together r hit)
  have small := Multiset.card_le_card sub
  refine ⟨Y,u,v,?_,yes⟩
  simp only [Multiset.card_add,Multiset.coe_card] at small ⊢
  omega

/-- The endpoint can be dropped if each mandatory source in its fixed
component is already represented in the rest of the route. In particular
this holds if the endpoint is visited again up to fixed-component equality,
or if its fixed component contains no mandatory source at all. -/
def EndpointCovered (Z : Multiset Block) (a : Block) (rest : List Block) : Prop :=
  ∀p∈required, label (required+Z) (src p)=label (required+Z) a →
    ∃v∈rest, label (required+Z) (src p)=label (required+Z) v

theorem rehit {Z : Multiset Block} {a : Block} {rest : List Block}
    (seen : ∃v∈rest, label (required+Z) a=label (required+Z) v) : EndpointCovered Z a rest := by
  obtain ⟨v,hv,eq⟩ := seen
  exact fun p _ hp => ⟨v,hv,hp.trans eq⟩

theorem trim_first {Z : Multiset Block} {a b s t e : Block} {es : List Block}
    (r : Route src dst a (e::es) b) (orig : Feasible ((↑(e::es) : Multiset Block)+Z) s t)
    (balanced : Z.map src=Z.map dst) (covered : EndpointCovered Z a (dst e::es.map dst)) :
    Shortenable ((↑(e::es) : Multiset Block)+Z) := by
  have old := necessary r (by simp) orig
  cases r with
  | cons _ _ tail =>
    apply shorten_by_replacement tail _ balanced _ (by simp)
    · intro p hp
      obtain ⟨v,hv,eq⟩ := old p hp
      rcases List.mem_cons.mp hv with rfl|inside
      · exact covered p hp eq
      · exact ⟨v,inside,eq⟩
    · intro z hz
      apply orig.edges_seven
      rcases Multiset.mem_add.mp hz with path|fixed
      · exact Multiset.mem_add.mpr (Or.inl (List.mem_cons_of_mem _ (show z∈es from path)))
      · exact Multiset.mem_add.mpr (Or.inr fixed)

theorem trim_last {Z : Multiset Block} {a b s t e : Block} {es : List Block}
    (pre : Route src dst a es (src e)) (r : Route src dst a (es++[e]) b)
    (orig : Feasible ((↑(es++[e]) : Multiset Block)+Z) s t) (balanced : Z.map src=Z.map dst)
    (covered : EndpointCovered Z (dst e) (a::es.map dst)) :
    Shortenable ((↑(es++[e]) : Multiset Block)+Z) := by
  have old := necessary r (by simp) orig
  apply shorten_by_replacement pre _ balanced _ (by simp)
  · intro p hp
    obtain ⟨v,hv,eq⟩ := old p hp
    have occ : v∈(a::es.map dst)++[dst e] := by simpa using hv
    rcases List.mem_append.mp occ with inside|last
    · exact ⟨v,inside,eq⟩
    · exact covered p hp (List.mem_singleton.mp last ▸ eq)
  · intro z hz
    apply orig.edges_seven
    rcases Multiset.mem_add.mp hz with path|fixed
    · exact Multiset.mem_add.mpr (Or.inl (List.mem_append_left _ (show z∈es from path)))
    · exact Multiset.mem_add.mpr (Or.inr fixed)

#print axioms trim_first
#print axioms trim_last
#print axioms necessary
#print axioms shorten_by_replacement
end ExactWordFlow.BackboneDescent

import WordFlow
import RouteDensity
import SplitFlow

namespace ResidualControls
open ExactWordFlow SevenWordWindows ResidualDensity

private def decode (s : String) : Block := s.toList.map (fun c => Fin.ofNat 7 (c.toNat-48))
def mainWord := decode "0123450124350124530124503124501324510324150324105324103524103254103214503214053214035214032514032154031254031524031542031540231450231405231402531402351402341502341052341025341023541023451024351024531024513024153024135024130524130254130214530214350214305214302514302154301254301524301542301452301425301423501423051423041523041253041235041230541230451203451204351204531204513204153204135204132504132054132014532014352014325014320514320154321054312054310254310524310542310"
def wheelWords : List Block :=
  ["012354", "013254", "013425", "013524", "015346", "015364", "015634", "016534",
   "021634", "025134", "031425", "031452", "034125", "034152", "034215", "034256",
   "034621", "035142", "035412", "035426", "036421", "042153", "042516", "042561",
   "042613", "042651", "043156", "043165", "043521", "043615", "045216", "045231",
   "045321", "046251", "046315", "051246", "051264", "051624", "053426", "053462",
   "053642", "056124", "056342", "061354", "061534", "063452", "064251", "064315",
   "065124", "065342", "123465", "123645", "132456", "134526", "134562", "134652",
   "135462", "135642", "136452", "136542", "154326", "154623", "156423", "163245",
   "163542", "165432"].map (fun s => let u:=decode s; u++u)

def vertices (w : Block) := w.take 6::(windows w).map dst
private def routes (w : Block) := w::wheelWords
def edgeBag (w : Block) : Multiset Block := ↑((routes w).flatMap windows)
private def capacity (w : Block) := ((routes w).map (fun u => (touched (vertices u)).card-1)).sum
private def disjoint (w : Block) : Bool := decide (((routes w).map (fun u => (vertices u).toFinset)).Pairwise Disjoint)

/-- The known connected 5,905-letter example and the disconnected
858-edge example differ by one edge on their main residual trail. -/
theorem reference_counts :
    bag SuperpermLowerBounds.LengthBudget.Word5905.word = required + edgeBag mainWord ∧
    ExactWordFlow.Split.extra = edgeBag mainWord.tail ∧
    wheelWords.length=66 ∧
    (wheelWords.all fun u => decide (u.take 6 = u.drop 6 ∧ (windows u).length=6 ∧
      (touched (vertices u)).card=6))=true ∧
    disjoint mainWord=true ∧ disjoint mainWord.tail=true ∧
    (windows mainWord).length=463 ∧ (touched (vertices mainWord)).card=390 ∧
    (windows mainWord.tail).length=462 ∧ (touched (vertices mainWord.tail)).card=389 ∧
    capacity mainWord=719 ∧ capacity mainWord.tail=718 := by native_decide

#print axioms reference_counts
end ResidualControls

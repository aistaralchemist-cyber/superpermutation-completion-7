import WindowAlphabet
import Word5905

namespace SevenWindowAlphabet
open ExactWordFlow SevenWordWindows

/-- Enumerate length-seven blocks directly, keeping only the running total. -/
private def countWords (p : Block → Bool) : Nat → Block → Nat
  | 0, w => if p w then 1 else 0
  | n+1, w => ((List.finRange 7).map fun a => countWords p n (a::w)).sum

/-- Restricted growth strings give the equality patterns of blocks.
At each step a previously unused letter receives the next integer. -/
private def countPatterns (p : Block → Bool) : Nat → Nat → Block → Nat
  | 0, _, w => if p w.reverse then 1 else 0
  | n+1, used, w => (((List.finRange 7).filter fun a => a.val≤used).map
      fun a => countPatterns p n (max used (a.val+1)) (a::w)).sum

theorem census : countWords admissible 7 [] = 216720 ∧
    countPatterns (fun _ => true) 7 0 [] = 877 ∧
    countPatterns admissible 7 0 [] = 86 := by native_decide

theorem reference_control :
    (windows SuperpermLowerBounds.LengthBudget.Word5905.word).all admissible = true := by
  native_decide

#print axioms census
#print axioms reference_control
end SevenWindowAlphabet

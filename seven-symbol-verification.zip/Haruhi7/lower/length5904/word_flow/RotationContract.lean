import WordFlow
import ResidualDensity

/-! Delete any chosen collection of disjoint seven-edge rotation excursions,
retaining one visited six-letter anchor for every deleted class. -/
namespace ExactWordFlow.RotationContract
open DirectedEuler SevenWordWindows ResidualDensity

def Passage (c : Block) (xs : List Block) : Prop :=
  ∃ (a b d : List Block) (u : Block), xs=a++b++d ∧ b.length=7 ∧
    (∀e∈b, mark e=some c) ∧ (∀e∈a++d, mark e≠some c) ∧
    Route src dst u b u ∧ full u ∧ tag u=c

private abbrev chain := Route src dst

private theorem join {s u t : Block} {a b : List Block} (p : chain s a u)
    (q : chain u b t) : chain s (a++b) t := by
  induction p with
  | nil => exact q
  | cons e h _ ih => exact .cons _ h (ih q)

private theorem split_at {s t : Block} (a b : List Block)
    (r : chain s (a++b) t) : ∃u, chain s a u ∧ chain u b t := by
  induction a generalizing s with
  | nil => exact ⟨s,.nil _,r⟩
  | cons e a ih =>
    cases r with
    | cons _ h rest =>
      obtain ⟨u,left,right⟩ := ih rest
      exact ⟨u,.cons _ h left,right⟩

private theorem end_eq {s t z : Block} {a : List Block} (p : chain s a t)
    (q : chain s a z) : t=z := by
  induction p with
  | nil => cases q; rfl
  | cons e h _ ih => cases q with | cons _ _ rest => exact ih rest

private theorem start_eq {s u t z : Block} {a : List Block} (ne : a≠[])
    (p : chain s a t) (q : chain u a z) : s=u := by
  cases p with
  | nil => contradiction
  | cons e h _ => cases q with | cons _ k _ => exact h.symm.trans k

private theorem end_seen {s t : Block} {a : List Block} (p : chain s a t) :
    t∈s::a.map dst := by
  induction p with
  | nil => simp
  | cons e h rest ih => simpa [List.mem_cons,or_assoc] using Or.inr ih

private def cut (c : Block) (xs : List Block) := xs.filter (fun e => decide (mark e≠some c))

private theorem filter_same {xs : List Block} {c : Block} (h : ∀e∈xs, mark e≠some c) :
    cut c xs=xs := List.filter_eq_self.mpr (fun e he => decide_eq_true (h e he))

private theorem cut_spec {xs : List Block} {c s t : Block} (r : chain s xs t)
    (p : Passage c xs) : chain s (cut c xs) t ∧ (cut c xs).length+7=xs.length ∧
    ∃u∈s::(cut c xs).map dst, full u ∧ tag u=c := by
  obtain ⟨a,b,d,u,rfl,seven,inside,outside,loop,clean,cls⟩ := p
  obtain ⟨middle,left,right⟩ := split_at a (b++d) (by simpa [List.append_assoc] using r)
  obtain ⟨exit,through,rest⟩ := split_at b d right
  have neq : b≠[] := by intro h; simp [h] at seven
  have eq := start_eq neq through loop
  subst middle
  have eq := end_eq through loop
  subst exit
  have leftEq := filter_same (c:=c) (xs:=a) (fun e he => outside e (List.mem_append_left _ he))
  have rightEq := filter_same (c:=c) (xs:=d) (fun e he => outside e (List.mem_append_right _ he))
  have zero : cut c b=[] := List.filter_eq_nil_iff.mpr (by intro e he; simp [inside e he])
  have drop : cut c (a++b++d)=a++d := by
    simp only [cut,List.filter_append] at leftEq rightEq zero ⊢
    rw [leftEq,rightEq,zero,List.append_nil]
  rw [drop]
  refine ⟨join left rest,by simp [seven]; omega,u,?_,clean,cls⟩
  have seen := end_seen left
  simp only [List.mem_cons,List.map_append,List.mem_append] at seen ⊢
  tauto

private theorem pass_survives {xs : List Block} {c k : Block} (diff : k≠c)
    (p : Passage k xs) : Passage k (cut c xs) := by
  obtain ⟨a,b,d,u,rfl,seven,inside,outside,loop,clean,cls⟩ := p
  have keep := filter_same (c:=c) (xs:=b) (by intro e he; simp [inside e he,diff])
  refine ⟨cut c a,b,cut c d,u,?_,seven,inside,?_,loop,clean,cls⟩
  · simpa only [cut,List.filter_append] using congrArg (fun z => cut c a++z++cut c d) keep
  · intro e he
    apply outside
    rcases List.mem_append.mp he with first|last
    · exact List.mem_append_left _ (List.mem_of_mem_filter first)
    · exact List.mem_append_right _ (List.mem_of_mem_filter last)

private theorem destination_tag {e c : Block} (width : e.length=7) (mc : mark e=some c) :
    tag (dst e)=c := by
  have cert : ∀p∈representatives, tag (dst p)=classKey p := by native_decide
  unfold mark at mc
  split at mc
  next nd => exact (cert _ ((mem_reps _).mpr ⟨width,nd⟩)).trans (Option.some.inj mc)
  next => contradiction

/-- The remaining route keeps all and only edges outside the selected classes.
The initial state is counted as a possible anchor, including for a leading run. -/
theorem many (S : Finset Block) {xs : List Block} {s t : Block}
    (r : chain s xs t) (widths : ∀ e∈xs, e.length=7)
    (runs : ∀c∈S, Passage c xs) :
    ∃ys, chain s ys t ∧ ys.length+7*S.card=xs.length ∧
      (∀e, e∈ys ↔ e∈xs ∧ ∀c∈S, mark e≠some c) ∧
      ∀c∈S, ∃u∈s::ys.map dst, full u ∧ tag u=c := by
  classical
  induction S using Finset.induction_on generalizing xs with
  | empty => exact ⟨xs,r,by simp,by simp,by simp⟩
  | @insert c S fresh ih =>
    obtain ⟨route,len,u,seen,clean,cls⟩ := cut_spec r (runs _ (Finset.mem_insert_self _ _))
    have remain : ∀ e∈cut c xs, e.length=7 := fun e he => widths e (List.mem_of_mem_filter he)
    obtain ⟨ys,valid,size,mem,hits⟩ := ih route remain (by
      intro k hk
      exact pass_survives (by rintro rfl; exact fresh hk) (runs k (Finset.mem_insert_of_mem hk)))
    refine ⟨ys,valid,by rw [Finset.card_insert_of_notMem fresh]; omega,?_,?_⟩
    · intro e
      simp [mem e,cut,and_assoc]
    · intro k hk
      rcases Finset.mem_insert.mp hk with rfl|other
      · refine ⟨u,?_,clean,cls⟩
        rcases List.mem_cons.mp seen with first|later
        · exact List.mem_cons.mpr (Or.inl first)
        · obtain ⟨e,he,rfl⟩ := List.mem_map.mp later
          apply List.mem_cons_of_mem
          apply List.mem_map.mpr
          refine ⟨e,(mem e).mpr ⟨he,?_⟩,rfl⟩
          intro x hx eq
          have same := (destination_tag (remain e he) eq).symm.trans cls
          exact fresh (same ▸ hx)
      · exact hits _ other

end ExactWordFlow.RotationContract

import CompactLayout
import CompactBenes
import CompactThresholdProof

namespace ExactWordFlow.CompactWordCircuit

abbrev SignalList (v : Nat → Bool) := List.Forall₂ (fun (x : W) (b : Bool)=>Rep v b x)

theorem insist_grow (xs : List W) : Grows (insist xs) := by
  intro st
  refine ⟨[.assertion xs],?_,rfl⟩
  exact Array.toList_push

private theorem signal_data {v : Nat → Bool} {xs : List W} {bs : List Bool} (h : SignalList v xs bs) :
    nonzero xs ∧ xs.map (wire v)=bs := by
  induction h with
  | nil => exact ⟨by simp [nonzero],rfl⟩
  | cons h _ ih => exact ⟨by simpa [nonzero] using And.intro h.1 ih.1,by simp [h.2,ih.2]⟩

theorem cap_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (unit : v 0=true)
    {ws : Bits} {bs : List Bool} (bits : SignalList v ws.toList bs) {k : Nat} (count : k ≤ bs.count true) :
    Gives T (capped ws k) (Rep v true) := by
  obtain ⟨nz,values⟩:=signal_data bits
  have q := threshold_gives law unit ws k nz
  rw [values,decide_eq_true count] at q
  unfold capped
  refine bind_gives (m:=threshold ws k) (P:=Rep v true) (Q:=Rep v true) (threshold_grows _ _)
    (fun x=>bind_grows (insist_grow _) (fun _=>pure_grows x)) q ?_
  intro x hx
  exact bind_gives (m:=insist [x]) (P:=fun _=>True) (Q:=Rep v true) (insist_grow _)
    (fun _=>pure_grows x) (fun _ _=>trivial) (fun _ _=>pure_gives hx)

private theorem indexed_flags {v : Nat → Bool} {as : Array Bool} {ws : Bits}
    (h : ArrayRel (fun x b=>Rep v b x) ws as) : ∀i<as.size, Rep v as[i]! ws[i]! :=
  fun i hi => h.get i (h.size ▸ hi)

def startVals (c h : List Bool) := c.take 1 ++ List.zipWith (fun a b=>a && !b) c.tail h

theorem starts_gives {T : Test} {v : Nat → Bool} (law : ModelsGates T v) (one : v 0=true)
    {clean hits : Bits} {cs hs : List Bool}
    (cleanBits : SignalList v clean.toList cs) (hitBits : SignalList v hits.toList hs)
    (size : cs.length=hs.length+1) :
    Gives T (startPhase clean hits) (fun out=>SignalList v out.toList (startVals cs hs)) := by
  have cl := cleanBits.length_eq
  have hl := hitBits.length_eq
  simp only [Array.length_toList] at cl hl
  let val := fun i : Nat=>cs[i+1]! && !hs[i]!
  have ci (i:Nat) (hi:i<cs.length) : Rep v cs[i]! clean[i]! := by
    have h := cleanBits.get (i:=i) (by simpa [cl] using hi) hi
    simpa [getElem!_pos,hi,cl] using h
  have wi (i:Nat) (hi:i<hs.length) : Rep v hs[i]! hits[i]! := by
    have h := hitBits.get (i:=i) (by simpa [hl] using hi) hi
    simpa [getElem!_pos,hi,hl] using h
  have first := ci 0 (by omega)
  unfold startPhase
  refine bind_gives (P:=fun out=>List.Forall₂ (fun i x=>Rep v (val i) x) (List.range hits.size) out.toList)
    (mapArray_grows (fun _=>allGate_grows _) _) (fun _=>pure_grows _) ?_ ?_
  · have h := mapArray_gives (T:=T) (R:=fun i x=>Rep v (val i) x) (Array.range hits.size)
        (fun i=>allGate_grows [clean[i+1]!, -hits[i]!]) (fun i hi=>by
          have b : i<hits.size := by simpa using hi
          have hit := wi i (by omega)
          exact and2_gives law one (ci (i+1) (by omega)) ⟨neg_ne_zero.mpr hit.1,by rw [wire_neg hit.1,hit.2]⟩)
    exact h.imp (fun _ hz=>by simpa using hz)
  · intro a ha
    apply pure_gives
    have nn : cs ≠ [] := by intro z; simp [z] at size
    obtain ⟨d,ds,cd⟩:=List.exists_cons_of_ne_nil nn
    subst cs
    simp only [startVals,List.take_succ_cons,List.take_zero,List.tail_cons,List.cons_append,
      List.nil_append,Array.toList_append]
    apply List.Forall₂.cons (by simpa using first)
    apply List.forall₂_of_length_eq_of_get
    · simpa [List.length_zipWith,hl,show ds.length=hs.length by simpa using size] using ha.length_eq.symm
    · intro i hi hj
      have z := ha.length_eq
      simp only [List.length_range,Array.length_toList] at z
      have b : i<hits.size := by simpa only [z,Array.length_toList] using hi
      have b2 : i<hs.length := by omega
      have b3 : i<ds.length := by simp at size; omega
      have h := ha.get (i:=i) (by simpa using b) hi
      simpa [List.get_eq_getElem,val,List.getElem_zipWith, getElem!_pos,b2,b3] using h

end ExactWordFlow.CompactWordCircuit

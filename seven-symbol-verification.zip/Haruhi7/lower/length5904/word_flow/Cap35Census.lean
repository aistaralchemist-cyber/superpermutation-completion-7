import Cap35Rigidity
import ExtremeWheelCut
import Interval66

namespace ExactWordFlow.Cap35Rigidity
open ResidualDensity WheelContacts ExtremeWheelCut
open private map_tag encode canonical from Interval66

private theorem hop_full (s : Six) (hs : full s) : full (hop s) := by
  have checked : states.all (fun z=>decide (full (hop z)))=true:=by native_decide
  exact of_decide_eq_true (List.all_eq_true.mp checked s (mem_states hs))

private theorem hop_map (f : Fin 7→Fin 7) (s : Six) : hop (s.map f)=(hop s).map f := by
  simp only [hop,List.map_append,List.map_rotate,List.map_take,List.map_drop]

private theorem wheel_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (zero : f 0=0) (s : Six)
    (hs : full s) : (wheel s).image (List.map f)=wheel (s.map f) := by
  have form (j:Nat) : tag ((s.map f).rotate j)=(tag (s.rotate j)).map f:=by
    rw [←List.map_rotate,map_tag f inj zero]
    exact ⟨by simp [hs.1],List.nodup_rotate.mpr hs.2⟩
  ext w
  simp only [wheel,orbit,Finset.mem_image,List.mem_toFinset,List.mem_map,List.mem_range]
  constructor
  · rintro ⟨x,⟨j,hj,rfl⟩,rfl⟩
    exact ⟨j,hj,form j⟩
  · rintro ⟨j,hj,rfl⟩
    exact ⟨_,⟨j,hj,rfl⟩,(form j).symm⟩

private theorem shape_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (zero : f 0=0)
    (s : Six) (hs : full s) : (shape s).image (List.map f)=shape (s.map f) := by
  have transport (j:Nat) : (hop^[j] (s.map f))=(hop^[j] s).map f ∧ full (hop^[j] s):=by
    induction j with
    | zero => exact ⟨rfl,hs⟩
    | succ j ih =>
      rw [Function.iterate_succ_apply',Function.iterate_succ_apply',ih.1,hop_map]
      exact ⟨rfl,hop_full _ ih.2⟩
  ext w
  simp only [shape,Finset.mem_image,Finset.mem_biUnion]
  constructor
  · rintro ⟨y,⟨k,hk,hy⟩,rfl⟩
    refine ⟨k,hk,?_⟩
    rw [(transport k).1,←wheel_map f inj zero _ (transport k).2]
    exact Finset.mem_image_of_mem _ hy
  · rintro ⟨k,hk,hw⟩
    rw [(transport k).1,←wheel_map f inj zero _ (transport k).2] at hw
    obtain ⟨y,hy,rfl⟩:=Finset.mem_image.mp hw
    exact ⟨y,⟨k,hk,hy⟩,rfl⟩

private theorem board_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (zero : f 0=0) :
    allRows.image (Finset.image (List.map f))=allRows := by
  have sub:allRows.image (Finset.image (List.map f))⊆allRows:=by
    intro W hW
    obtain ⟨z,hz,rfl⟩:=Finset.mem_image.mp hW
    obtain ⟨s,hs,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hz)
    have hs':full s := by
      have right : states.all (fun q => decide (full q))=true:=by native_decide
      exact of_decide_eq_true (List.all_eq_true.mp right s (List.mem_filter.mp hs).1)
    rw [wheel_map f inj zero s hs']
    obtain ⟨t,legal,eq⟩:=complete (s:=s.map f) ⟨by simp [hs'.1],hs'.2.map inj⟩
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨t,legal,eq⟩)
  exact Finset.eq_of_subset_of_card_le sub (by rw [Finset.card_image_of_injective _
    (Finset.image_injective (List.map_injective_iff.mpr inj))])

def contained (T : Finset Six) := allRows.filter (fun w=>w⊆T)

private theorem count_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (zero : f 0=0)
    (T : Finset Six) : (contained (T.image (List.map f))).card=(contained T).card:=by
  let g:=List.map f
  have gi:Function.Injective g:=List.map_injective_iff.mpr inj
  have map_eq : contained (T.image g)=(contained T).image (Finset.image g) := by
    ext w
    constructor
    · intro hw
      obtain ⟨board,inside⟩:=Finset.mem_filter.mp hw
      rw [←board_map f inj zero] at board
      obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp board
      exact Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨hv,(Finset.image_subset_image_iff gi).mp inside⟩,rfl⟩
    · intro hw
      obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hw
      obtain ⟨board,inside⟩:=Finset.mem_filter.mp hv
      refine Finset.mem_filter.mpr ⟨?_,Finset.image_subset_image inside⟩
      rw [←board_map f inj zero]
      exact Finset.mem_image_of_mem _ board
  rw [show List.map f=g from rfl,map_eq,Finset.card_image_of_injective _ (Finset.image_injective gi)]

/-- Every saturated five-run shape has exactly thirty rotation classes and
contains ten entire six-wheels. Only seven normalized starts are needed. -/
theorem ten (s : Six) (hs : full s) : (shape s).card=30 ∧ (contained (shape s)).card=10 := by
  have encodeCheck : states.all (fun v=>decide (Function.Injective (encode v) ∧ encode v 0=0 ∧
      v.map (encode v)∈canonical))=true:=by native_decide
  obtain ⟨inj,z,can⟩:=of_decide_eq_true (List.all_eq_true.mp encodeCheck s (mem_states hs))
  have table : canonical.all (fun v=>decide ((shape v).card=30 ∧ (contained (shape v)).card=10))=true := by native_decide
  have eq:=of_decide_eq_true (List.all_eq_true.mp table _ can)
  rw [←shape_map _ inj z s hs,Finset.card_image_of_injective _ (List.map_injective_iff.mpr inj),
    count_map _ inj z] at eq
  exact eq

#print axioms ten
end ExactWordFlow.Cap35Rigidity

import DynamicWheelCover

namespace ExactWordFlow.DynamicWheelCover
open SevenWordWindows RotationCore ResidualDensity LiteralWheelCover
open WheelContacts (wheel)

-- The endpoint is a target set of classes, rather than the whole board.
inductive Restores (D : Finset Block) : Finset Block → List Row → Prop
  | done {V} (all : D⊆V) : Restores D V []
  | step {V rs u} (clean : full u) (hit : ∃c∈V,c∈wheel u)
      (rest : Restores D (V∪wheel u) rs) : Restores D V (wheel u::rs)

private theorem enlarge {U V : Finset Block} {rs : List Row} (p : Reaches U rs) (more : U⊆V) :
    Reaches V rs := by
  induction p generalizing V with
  | done all => exact .done (all.trans more)
  | step clean hit _ ih =>
    obtain ⟨c,cv,cr⟩:=hit
    exact .step clean ⟨c,more cv,cr⟩ (ih (Finset.union_subset_union more Finset.Subset.rfl))

theorem join {V D : Finset Block} {rs ts : List Row} (repair : Restores D V rs)
    (finish : Reaches D ts) : Reaches V (rs++ts) := by
  induction repair with
  | done all => exact enlarge finish all
  | step clean hit _ ih => exact .step clean hit ih

/-- Cut any number of pieces and reach the old visits by any class-connected
wheel sequence. Handles zero original wheels and multiple excisions at once. -/
theorem saving_bound {b q : Block} {k h : Nat} (done : (complete b).card=92)
    (size : b.length+6*k=1508) (base : condition b k) (long : 6≤q.length)
    (lost : (complete b).card≤(complete q).card+h) {rs : List Row}
    (repair : Restores (visited b) (visited q) rs) :
    b.length≤q.length+7*h+6*rs.length+5 := by
  obtain ⟨ts,n,finish⟩:=of_condition base
  obtain ⟨z,all,len⟩:=spell (join repair finish) (w:=q) long Finset.Subset.rfl
  have lower:=SuperpermLowerBounds.covers_lower_bound_7_k16_native z all
  have cap : (complete q).card≤720 := by
    rw [←board]
    exact Finset.card_le_card ((complete_subset q).trans (visited_subset q))
  simp only [List.length_append,price] at len
  omega

/-- If r thirteen-edge returns together endanger at most r completions,
their lost visits cannot be reacquired with fewer than r wheels. -/
theorem joint_thirteen {b q : Block} {k r : Nat} (done : (complete b).card=92)
    (size : b.length+6*k=1508) (base : condition b k) (long : 6≤q.length)
    (saved : q.length+13*r≤b.length) (lost : (complete b).card≤(complete q).card+r)
    {rs : List Row} (repair : Restores (visited b) (visited q) rs) : r≤rs.length := by
  have bound:=saving_bound done size base long lost repair
  omega

#print axioms joint_thirteen
end ExactWordFlow.DynamicWheelCover

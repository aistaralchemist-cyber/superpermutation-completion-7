import DirtyWheelBudget
import Disjoint858

set_option maxRecDepth 4096
set_option maxHeartbeats 600000

namespace ExactWordFlow.DirtyWheelBudget
open GlobalWheelRank EmbeddedWheels ResidualDensity SevenWordWindows

private def endpoints (e : Block) : Finset Node := {node (src e),node (dst e)}
private def fixedEdges := bag Dense462.word
private def fixedPairs := fixedEdges.toFinset.image endpoints
private def ids := Dense462.DisjointWheels.wheels
private def X := Dense462.DisjointWheels.X
private def reserve (w : Block) := ((wheel w).toFinset.image endpoints) \ fixedPairs

/-- Direct census of the record and the all-class, 858-edge control. -/
theorem controls :
    let record := ResidualControls.wheelWords.map (·.take 6)
    let F := bag ResidualControls.mainWord
    (dirty (turns record+F)).card=74 ∧ (wheelRows record).card=66 ∧ (otherPairs record F).card=463 ∧
    X=turns ids+fixedEdges ∧ X.card=858 ∧ X.Nodup ∧
    (dirty X).card=73 ∧ (wheelRows ids).card=66 ∧ (otherPairs ids fixedEdges).card=462 ∧
    ((states.filter (fun q => (wheel q).all (fun e => decide (e∈X)))).map wheelNodes).toFinset.card=66 := by
  native_decide

/-- A wheel which can actually be removed is disjoint from the raw
path windows; its projected class set determines its original wheel. -/
private theorem geometry :
    fixedPairs.card=462 ∧ ids.toFinset.card=66 ∧
    (∀e∈windows Dense462.word, e∈X ∧ node (src e)≠node (dst e)) ∧
    (∀ w∈ids, 5≤(reserve w).card ∧ ∀e∈wheel w, e∈X ∧ node (src e)≠node (dst e)) ∧
    (∀ w∈ids, ∀z∈ids, w≠z → Disjoint (reserve w) (reserve z)) ∧
    (∀ w∈ids, ∀z∈ids, wheelNodes w=wheelNodes z → w=z) ∧
    ∀q∈states, (∀e∈wheel q,e∈X) → ∀ e∈wheel q,
      e∉fixedEdges ∧ ∀w∈ids, e∈wheel w → wheelNodes w=wheelNodes q := by
  refine ⟨?_,?_,?_,?_,?_,?_,?_⟩ <;> native_decide

private theorem sdiff_disj {α β : Type*} [DecidableEq β] (A : Finset β) (S : Finset α)
    (f : α→Finset β) : Disjoint A (S.biUnion (fun w => f w \ A)) := by
  apply Finset.disjoint_left.mpr
  intro z hz h
  obtain ⟨w,_,hm⟩ := Finset.mem_biUnion.mp h
  exact (Finset.mem_sdiff.mp hm).2 hz

/-- Even the strongest choice of complete turns in the support cannot
exclude this placement by the joint global rank test. -/
theorem all_selections_pass {ws : List Block} {F : Multiset Block}
    (ok : ∀q∈ws,full q) (decomp : X=turns ws+F) :
    719+(dirty X).card ≤ 5*(wheelRows ws).card+(otherPairs ws F).card := by
  classical
  let A := wheelRows ws
  let K := ids.toFinset.filter (fun w => wheelNodes w∈A)
  let R := ids.toFinset \ K
  let extra := otherPairs ws F
  have db : (dirty X).card=73 := controls.2.2.2.2.2.2.1
  obtain ⟨pnum,allnum,main,given,sep,inj,loc⟩ := geometry
  have inTurn {q} (hq : q∈ws) {e} (he : e∈wheel q) : e∈turns ws :=
    (show e∈ws.flatMap wheel from List.mem_flatMap.mpr ⟨q,hq,he⟩)
  have info (e) (he : e∈turns ws) :
      e∉fixedEdges ∧ ∀w∈ids, e∈wheel w → wheelNodes w∈A := by
    obtain ⟨q,hq,h⟩ := List.mem_flatMap.mp (show e∈ws.flatMap wheel from he)
    have member (v) (hv : v∈wheel q) : v∈X := decomp ▸ Multiset.mem_add.mpr (Or.inl (inTurn hq hv))
    obtain ⟨no,same⟩ := loc q (mem_states (ok q hq)) member e h
    refine ⟨no,fun w hw ew => ?_⟩
    rw [same w hw ew]
    exact Finset.mem_image_of_mem _ (List.mem_toFinset.mpr hq)
  have pick (e) (edge : e∈X) (fresh : e∉turns ws) (non : node (src e)≠node (dst e)) :
      endpoints e∈extra := by
    have inside := (Multiset.mem_add.mp (decomp ▸ edge)).resolve_left fresh
    exact Finset.mem_image_of_mem _ (Finset.mem_filter.mpr ⟨Multiset.mem_toFinset.mpr inside,non,fresh⟩)
  have keep : fixedPairs⊆extra := by
    intro v hv
    obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp hv
    have mem := Multiset.mem_toFinset.mp he
    exact pick e (main e mem).1 (fun h => (info e h).1 mem) (main e mem).2
  have rest (w) (hw : w∈R) : reserve w⊆extra := by
    obtain ⟨hs,out⟩ := Finset.mem_sdiff.mp hw
    have orig := List.mem_toFinset.mp hs
    intro z hz
    obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp (Finset.mem_sdiff.mp hz).1
    have ew := List.mem_toFinset.mp he
    have live := (given w orig).2 e ew
    exact pick e live.1 (fun h => out (Finset.mem_filter.mpr ⟨hs,(info e h).2 w orig ew⟩)) live.2
  have disj : (R : Set Block).PairwiseDisjoint reserve := by
    intro w hw v hv ne
    exact sep w (List.mem_toFinset.mp (Finset.mem_sdiff.mp hw).1)
      v (List.mem_toFinset.mp (Finset.mem_sdiff.mp hv).1) ne
  have away : Disjoint fixedPairs (R.biUnion reserve) :=
    sdiff_disj fixedPairs R (fun w => (wheel w).toFinset.image endpoints)
  have inAll : fixedPairs ∪ R.biUnion reserve ⊆ extra :=
    Finset.union_subset keep (Finset.biUnion_subset.mpr rest)
  have n := Finset.card_le_card inAll
  rw [Finset.card_union_of_disjoint away,Finset.card_biUnion disj,pnum] at n
  have low : R.card*5≤∑w∈R,(reserve w).card := by
    calc
      _ = ∑ _∈R,5 := by simp
      _ ≤ _ := Finset.sum_le_sum fun w hw => (given w (List.mem_toFinset.mp (Finset.mem_sdiff.mp hw).1)).1
  have ik : Set.InjOn wheelNodes K := by
    intro w hw v hv equal
    exact inj w (List.mem_toFinset.mp (Finset.mem_filter.mp hw).1) v
      (List.mem_toFinset.mp (Finset.mem_filter.mp hv).1) equal
  have ksub : K.image wheelNodes ⊆ A := by
    intro z hz
    obtain ⟨w,hw,rfl⟩ := Finset.mem_image.mp hz
    exact (Finset.mem_filter.mp hw).2
  have ksize := Finset.card_le_card ksub
  rw [Finset.card_image_of_injOn ik] at ksize
  have knum : R.card+K.card=66 := (Finset.card_sdiff_add_card_eq_card
    (Finset.filter_subset (fun w => wheelNodes w∈A) ids.toFinset)).trans allnum
  change 719+(dirty X).card≤5*A.card+extra.card
  omega

#print axioms controls
#print axioms all_selections_pass
end ExactWordFlow.DirtyWheelBudget

import Geometry40

namespace ResidualDensity

def mask (p : ℕ → Prop) [DecidablePred p] (i n : ℕ) : List Bool :=
  (List.range n).map fun j => decide (p (i+j))

private theorem mask_cons (p : ℕ → Prop) [DecidablePred p] (i n : ℕ) :
    mask p i (n+1)=decide (p i)::mask p (i+1) n := by
  simp only [mask,List.range_succ_eq_map,List.map_cons,List.map_map,Nat.add_zero]
  congr 1
  apply List.map_congr_left
  intro j _
  simp only [Function.comp_apply,Nat.succ_eq_add_one]
  congr 2; omega

def goodMask : Nat → List Bool → Prop
  | _, [] => True
  | r, true::xs => r<6 ∧ goodMask (r+1) xs
  | _, false::xs => goodMask 0 xs

private theorem admiss {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p] (w : Walk u)
    (h : Marked u p) (a r n : ℕ) (hr : r≤6) (prev : ∀j<r,p (a+j)) :
    goodMask r (mask p (a+r) n) := by
  induction n generalizing a r with
  | zero => trivial
  | succ n ih =>
    rw [mask_cons]
    by_cases cur : p (a+r)
    · simp only [decide_eq_true cur,goodMask]
      have rr : r<6 := by
        by_contra! large
        apply no_seven w h a
        intro j hj
        by_cases lt : j<r
        · exact prev j lt
        · have : j=r := by omega
          simpa [this] using cur
      exact ⟨rr,by rw [Nat.add_assoc]; apply ih a (r+1) (by omega)
                   intro j hj
                   by_cases lt : j<r
                   · exact prev j lt
                   · have : j=r := by omega
                     simpa [this] using cur⟩
    · simp only [decide_eq_false cur,goodMask]
      simpa using ih (a+r+1) 0 (by decide) (by simp)

def candidates : Nat → Nat → Nat → List (List Bool)
  | 0,_,_ => [[]]
  | n+1,g,r =>
    if n+1>6-r+7*g then [] else
      (if r<6 then (candidates n g (r+1)).map (true::·) else []) ++
      (if 0<g then (candidates n (g-1) 0).map (false::·) else [])

private theorem room (xs : List Bool) (r g : Nat) (hr : r≤6) (hg : xs.count false≤g)
    (ok : goodMask r xs) : xs.length≤6-r+7*g := by
  induction xs generalizing r g with
  | nil => simp
  | cons b xs ih =>
    cases b
    · simp at hg ⊢
      have := ih 0 (g-1) (by decide) (by omega) ok
      omega
    · simp at hg ⊢
      have := ih (r+1) g (by have := ok.1; omega) hg ok.2
      have := ok.1; omega

private theorem admitted (xs : List Bool) (r g : Nat) (hr : r≤6) (hg : xs.count false≤g)
    (ok : goodMask r xs) : xs∈candidates xs.length g r := by
  induction xs generalizing r g with
  | nil => simp [candidates]
  | cons b xs ih =>
    have fit := room (b::xs) r g hr hg ok
    rw [List.length_cons,candidates,ite_eq_right (by simpa using not_lt.mpr fit)]
    apply List.mem_append.mpr
    cases b
    · right
      simp at hg
      rw [ite_eq_left (by omega)]
      exact List.mem_map.mpr ⟨xs,ih 0 (g-1) (by decide) (by omega) ok,rfl⟩
    · left
      rw [ite_eq_left ok.1]
      exact List.mem_map.mpr ⟨xs,ih (r+1) g (by have := ok.1; omega) (by simpa using hg) ok.2,rfl⟩

def rowsMask : List Nat → List Bool
  | [] => []
  | n::ns => List.replicate n true ++ (if ns.isEmpty then [] else false::rowsMask ns)

private theorem unmask {p : ℕ → Prop} [DecidablePred p] (i n : ℕ) (ns : List Nat)
    (eq : mask p i n = rowsMask ns) : rowsMarked p i ns := by
  induction ns generalizing i n with
  | nil => trivial
  | cons l ls ih =>
    constructor
    · intro j hj
      have lsize : l≤n := by
        have := congrArg List.length eq
        simp [mask,rowsMask] at this
        omega
      have mem : (mask p i n)[j]'(by simp [mask]; omega)=true := by
        have eq' := congrArg (fun xs : List Bool => xs[j]?) eq
        simpa [mask,rowsMask,show j<n by omega,List.getElem?_append_left (by simpa using hj : j<(List.replicate l true).length),List.getElem?_replicate_of_lt hj] using eq'
      simpa [mask] using mem
    · cases ls with
      | nil => trivial
      | cons z zs =>
        have size : l+1≤n := by
          have := congrArg List.length eq
          simp [mask,rowsMask] at this
          omega
        apply ih (i+l+1) (n-(l+1))
        have dd := congrArg (List.drop (l+1)) eq
        simp only [rowsMask,List.isEmpty_cons,Bool.false_eq_true,ite_false] at dd
        have trim : (mask p i n).drop (l+1)=mask p (i+l+1) (n-(l+1)) := by
          apply List.ext_getElem
          · simp [mask]
          · intro j hj hk
            simp [mask,Nat.add_assoc,Nat.add_left_comm]
        rw [trim] at dd
        simpa [List.drop_append_of_le_length,List.drop_append,List.drop_replicate,rowsMask] using dd

theorem interval40 {u : ℕ → Six} {p : ℕ → Prop} [DecidablePred p] (w : Walk u)
    (h : Marked u p) (i : ℕ) : count p i 40≤34 := by
  by_contra! many
  have nfalse (i n : ℕ) : (mask p i n).count false + count p i n=n := by
    induction n generalizing i with
    | zero => simp [mask,count]
    | succ n ih =>
      have e : count p i (n+1)= (if p i then 1 else 0) + count p (i+1) n := by
        unfold count
        conv_lhs => rw [show n+1=1+n by omega]
        simp only [Finset.card_filter,Finset.sum_range_add,Finset.range_one,Finset.sum_singleton,Nat.add_zero,Nat.add_assoc]
      rw [mask_cons,e]
      have rr := ih (i+1)
      by_cases pp : p i <;> simp [pp] <;> omega
  have hh := nfalse i 40
  have good40 : goodMask 0 (mask p i 40) := by simpa using admiss w h i 0 40 (by decide) (by simp)
  have member := admitted (mask p i 40) 0 5 (by decide) (by omega) good40
  simp only [mask,List.length_map,List.length_range] at member
  have cert : (candidates 40 5 0).all (fun xs => widths40.any (fun a => xs==rowsMask a))=true := by
    native_decide
  obtain ⟨ns,hn,eq⟩ := List.any_eq_true.mp (List.all_eq_true.mp cert _ member)
  exact no40profile w h i ns hn (unmask i 40 ns (eq_of_beq eq))
end ResidualDensity
#print axioms ResidualDensity.interval40

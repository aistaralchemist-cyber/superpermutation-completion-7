import Bound
import Control1508
import LapSkeleton
namespace ExactWordFlow.StrippedControl
open RotationCore RotationCoreControls SevenWordWindows ResidualDensity LiteralWheelCover

def offsets : List Nat :=
  [45,72,166,173,194,212,237,285,292,312,565,585,592,638,645,652,677,692,699,
   720,727,734,754,786,817,824,831,853,860,868,889,908,919,940,947,1041,1068]
def excise (w : Block) (i n : Nat) : Block := w.take i ++ w.drop (i+n)
def shrink (w : Block) (i : Nat) : Block := excise w i 6
def base : Block := offsets.foldl shrink (coreWord 628)
def change (i : Nat) : Block := excise base i 1

def legal : Block → List Nat → Bool
  | _,[] => true
  | w,i::rest =>
    let u := (w.drop i).take 6
    decide (full u) && (u == (w.drop (i+6)).take 6) && legal (shrink w i) rest

def tests : List (Nat × Nat) :=
  (List.range base.length).map fun i =>
    let z := change i
    let g := (good z).length
    (g, if g < 644 then 0 else (visited z).card)

def counts : List Nat := [529,530,531].map (fun v=>tests.count (644,v))

def insertAt (a : Nat) : Block := base.take a ++ (base.drop a).take 6 ++ base.drop a
def touched (a j : Nat) : Block := excise (insertAt a) (a+j) 1
def inner : Bool := offsets.all (fun a=>(List.range 12).all (fun j=>decide ((good (touched a j)).length<644)))
def checked : Bool := let w:=base
  w.length==1287 && decide ((complete w).card=92) && decide ((visited w).card=535) &&
  legal (coreWord 628) offsets &&
  counts == [51,312,33] &&
  inner &&
  tests.all (fun (g,h)=>decide (g<644 ∨ h≤532))

set_option maxRecDepth 30000
theorem certificate : checked=true := by native_decide

end ExactWordFlow.StrippedControl

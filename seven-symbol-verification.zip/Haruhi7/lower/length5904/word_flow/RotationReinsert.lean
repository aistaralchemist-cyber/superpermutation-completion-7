import ExtendedSpineRank
import ResidualControls

namespace ExactWordFlow.RotationReinsert
open DirectedEuler ResidualDensity SevenWordWindows SuperpermutationBounds

def anchors (w : Block) : List Block := w.take 6::(windows w).map dst

def HasAnchor (w c : Block) : Prop := ∃u∈anchors w, full u ∧ tag u=c

theorem window_width (w : Word) {e : Block} (he : e ∈ windows w) : e.length=7 := by
  induction w with
  | nil => simp [windows] at he
  | cons a xs ih =>
    rw [windows] at he
    split at he
    · rcases List.mem_cons.mp he with eq | tail
      · subst e; simp; omega
      · exact ih tail
    · simp at he

theorem window_occurs (w : Word) {e : Block} (he : e ∈ windows w) :
    ∃ u v, w=u++e++v := by
  induction w with
  | nil => simp [windows] at he
  | cons a xs ih =>
    rw [windows] at he
    split at he
    · rcases List.mem_cons.mp he with eq | tail
      · subst e
        exact ⟨[],xs.drop 6,by simp⟩
      · obtain ⟨u,v,hu⟩ := ih tail
        exact ⟨a::u,v,by simp [hu]⟩
    · simp at he

/-- Reconstruct a word from a route of overlapping seven-letter blocks. -/
theorem spell_route {s t : Block} {es : List Block} (r : Route src dst s es t)
    (hlen : s.length=6) (widths : ∀ e∈es, e.length=7) :
    ∃ w : Word, w.length=es.length+6 ∧ w.take 6=s ∧ windows w=es := by
  induction r with
  | nil s => exact ⟨s,by simp [hlen],List.take_of_length_le (by omega),
        List.length_eq_zero_iff.mp (by rw [windows_length,hlen])⟩
  | @cons u v es e hs tail ih =>
    have ew := widths e List.mem_cons_self
    have dw : (dst e).length=6 := by simp [dst,ew]
    obtain ⟨w,wl,wp,ww⟩ := ih dw (fun a ha => widths a (List.mem_cons_of_mem _ ha))
    have wlong : 6≤w.length := by omega
    cases e with
    | nil => simp at ew
    | cons a xs =>
      have tailEq : w.take 6=xs := by simpa [dst] using wp
      have both : (a::w).take 7 = a::xs := by simpa using congrArg (a :: ·) tailEq
      have firstSix := congrArg (List.take 6) both
      refine ⟨a::w,by simp [wl],?_,?_⟩
      · simpa [List.take_take,src] using firstSix.trans (show (a::xs).take 6=u from hs)
      · simp [windows,wlong,ww,tailEq]



/-- A linear spelling of one complete seven-edge mandatory rotation. -/
def lapWord (u : Block) := u ++ (List.finRange 7).filter (fun a => a∉u) ++ u

def lap (u : Block) := windows (lapWord u)

private def rotations (p : Block) := (List.range 7).map (fun i => p.rotate i)

private theorem laps : ∀u∈states, 6≤(lapWord u).length ∧ (lapWord u).take 6=u ∧
    (lapWord u).drop ((lapWord u).length-6)=u ∧ (lap u).length=7 ∧
    (lap u).toFinset=(rotations (tag u)).toFinset := by native_decide

private theorem numbers : ∀p∈representatives, p∈rotations (classKey p) := by native_decide

theorem lap_geometry (u : Block) (hu : full u) :
    Route src dst u (lap u) u ∧ (lap u).length=7 ∧
      ∀p∈representatives, classKey p=tag u → p∈lap u := by
  obtain ⟨big,left,right,len,keys⟩ := laps u (mem_states hu)
  have route := read_route (lapWord u) big
  rw [left,right] at route
  refine ⟨route,len,fun p hp eq => List.mem_toFinset.mp ?_⟩
  rw [keys,←eq]
  exact List.mem_toFinset.mpr (numbers p hp)

private theorem splice {a b u : Block} {xs ys : List Block} (base : Route src dst a xs b)
    (atAnchor : u∈a::xs.map dst) (loop : Route src dst u ys u) :
    ∃zs : List Block, Route src dst a zs b ∧ (↑zs : Multiset Block)=↑xs+↑ys := by
  induction base with
  | nil v =>
    have eq : u=v := by simpa using atAnchor
    subst u
    exact ⟨ys,loop,by simp⟩
  | @cons v b xs e first tail ih =>
    by_cases here : u=v
    · subst u
      exact ⟨ys++e::xs,OnePath66.join_routes loop (.cons _ first tail),by simp [add_comm]⟩
    · have hit := (List.mem_cons.mp atAnchor).resolve_left here
      obtain ⟨zs,rr,eq⟩ := ih hit
      refine ⟨e::zs,.cons e first rr,?_⟩
      change e ::ₘ (↑zs : Multiset Block)=(e ::ₘ (↑xs : Multiset Block))+↑ys
      rw [eq,Multiset.cons_add]

/-- Insert a mandatory lap at any occurrence of its six-symbol anchor. Every
previous edge and every previous anchor remains available for other insertions. -/
theorem insert_class {w c : Block} (long : 6≤w.length) (hit : HasAnchor w c) :
    ∃z : Block, z.length=w.length+7 ∧ (∀v∈anchors w, v∈anchors z) ∧
      (∀p∈windows w, p∈windows z) ∧
      (∀p∈representatives, classKey p=c → p∈windows z) := by
  obtain ⟨u,whereAt,fullu,rfl⟩ := hit
  obtain ⟨lp,seven,all⟩ := lap_geometry u fullu
  obtain ⟨zs,r,eq⟩ := splice (read_route w long) whereAt lp
  have mem (p : Block) : p∈zs ↔ p∈windows w ∨ p∈lap u := by
    change p∈(↑zs : Multiset Block) ↔ _
    rw [eq,Multiset.mem_add]
    rfl
  obtain ⟨z,len,head,win⟩ := spell_route r (by simp; omega)
    (fun e he => ((mem e).mp he).elim (window_width w) (window_width (lapWord u)))
  have size := congrArg Multiset.card eq
  simp only [Multiset.coe_card,Multiset.card_add,windows_length,seven] at size
  refine ⟨z,by omega,?_,?_,?_⟩
  · intro v hv
    rcases List.mem_cons.mp hv with h|h
    · exact List.mem_cons.mpr (Or.inl (h.trans head.symm))
    · obtain ⟨e,he,rfl⟩ := List.mem_map.mp h
      apply List.mem_cons_of_mem
      rw [win]
      exact List.mem_map.mpr ⟨e,(mem e).mpr (Or.inl he),rfl⟩
  · intro p hp
    rw [win]
    exact (mem p).mpr (Or.inl hp)
  · intro p hp key
    rw [win]
    exact (mem p).mpr (Or.inr (all p hp key))

/-- Forward spelling from any core. The selected classes are arbitrary,
their six-letter anchors may overlap in the core, and endpoints are free. -/
theorem expand {w : Block} (S : Finset Block) (long : 6≤w.length)
    (hit : ∀c∈S, HasAnchor w c)
    (keep : ∀p∈representatives, classKey p∉S → p∈windows w) :
    ∃z : Block, Covers z ∧ z.length=w.length+7*S.card := by
  classical
  induction S using Finset.induction_on generalizing w with
  | empty =>
    refine ⟨w,?_,by simp⟩
    intro p size nd
    exact window_occurs w (keep p ((mem_reps p).mpr ⟨size,nd⟩) (by simp))
  | @insert c S no ih =>
    obtain ⟨v,n,remain,old,lapAll⟩ := insert_class long (hit c (Finset.mem_insert_self ..))
    have tags (d) (hd : d∈S) : HasAnchor v d := by
      obtain ⟨u,here,fullu,e⟩ := hit d (Finset.mem_insert_of_mem hd)
      exact ⟨u,remain u here,fullu,e⟩
    have rest (p) (hp : p∈representatives) (hs : classKey p ∉ S) : p∈windows v := by
      by_cases eq : classKey p=c
      · exact lapAll p hp eq
      · exact old p (keep p hp (by simpa using And.intro eq hs))
    obtain ⟨z,hz,l⟩ := ih (by omega : 6≤v.length) tags rest
    exact ⟨z,hz,by rw [Finset.card_insert_of_notMem no]; omega⟩

#print axioms spell_route
#print axioms insert_class
#print axioms expand
end ExactWordFlow.RotationReinsert

import GlobalWheelRank
import Dense462

namespace Path462Cut
open ExactWordFlow SevenWordWindows GlobalWheelRank

private def decode (s : String) : Block :=
  s.toList.map fun c => ⟨(c.toNat-48)%7, Nat.mod_lt _ (by decide)⟩

/-- A concrete 462-step residual path on six of the seven symbols. -/
def center := Dense462.word
def centerEdges := windows center
def old := ((((center.take 6)::(centerEdges.map dst)).filter (fun v => decide v.Nodup)).map cls).toFinset

/-- Contract every visited clean class and the dirty contexts to one vertex. -/
def φ (v : Block) := if v.Nodup ∧ cls v∉old then cls v else []
def dead := decode "0154623"
def touches (q : Block) := ((wheel q).map (fun e => φ (src e))).toFinset

theorem path_size : centerEdges.length=462 ∧ old.card=390 ∧ dead∉old := by native_decide

private theorem tables :
    (representatives.all (fun e => φ (src e) == φ (dst e)))=true ∧
    (centerEdges.all (fun e => φ (src e) == φ (dst e)))=true ∧
    (representatives.map (fun e => φ (src e))).toFinset.card=331 ∧
    (representatives.map (fun e => decide (φ (src e)=dead))).toFinset.card=2 ∧
    ((representatives.map src).all (fun q => decide (
       (touches q).card ≤ 6 ∧ (dead∈touches q → (touches q).card≤5) ∧
       ∀ e∈wheel q, φ (dst e)∈touches q)))=true := by native_decide

/-- No choice of at most 66 ordinary wheels completes this path, even with
arbitrary repetitions of their individual steps or of mandatory edges. -/
theorem no_66_wheel_completion {X : Multiset Block} {s t : Block}
    (W : Finset Block) (legit : W⊆roots) (few : W.card≤66)
    (cover : ∀ e∈X, e∈required ∨ e∈centerEdges ∨ ∃ q∈W, e∈wheel q) :
    ¬Feasible X s t := by
  classical
  intro h
  let T := W.image touches
  have req (e) (he : e∈required) :=
    eq_of_beq (List.all_eq_true.mp tables.1 e he)
  have core (e) (he : e∈centerEdges) :=
    eq_of_beq (List.all_eq_true.mp tables.2.1 e he)
  have localData (q) (hq : q∈W) :=
    of_decide_eq_true (List.all_eq_true.mp tables.2.2.2.2 q (List.mem_toFinset.mp (legit hq)))
  have account (e) (he : e∈X) :
      φ (src e)=φ (dst e) ∨ ∃ b∈T, φ (src e)∈b ∧ φ (dst e)∈b := by
    rcases cover e he with good | cent | ⟨q,hq,hw⟩
    · exact Or.inl (req e good)
    · exact Or.inl (core e cent)
    · exact Or.inr ⟨touches q,Finset.mem_image_of_mem _ hq,
        List.mem_toFinset.mpr (List.mem_map.mpr ⟨e,hw,rfl⟩),
        (localData q hq).2.2 e hw⟩
  have necessary := projected_rank φ req h T account
  rw [tables.2.2.1] at necessary
  have demand : ∃ b∈T, dead∈b := by
    by_contra! no
    let ψ (v : Block) := decide (φ v=dead)
    have hf (a b : Block) (eq : φ a=φ b) : ψ a=ψ b := by simp [ψ,eq]
    have low := projected_rank ψ (fun e he => hf _ _ (req e he)) h ∅ (by
      intro e he
      rcases account e he with same | ⟨b,hb,hs,hd⟩
      · exact Or.inl (hf _ _ same)
      · have ns : φ (src e)≠dead := fun eq => no b hb (eq ▸ hs)
        have nd : φ (dst e)≠dead := fun eq => no b hb (eq ▸ hd)
        exact Or.inl (by simp [ψ,ns,nd]))
    change (representatives.map (fun e => decide (φ (src e)=dead))).toFinset.card ≤ _ at low
    rw [tables.2.2.2.1] at low
    simp at low
  obtain ⟨b,hb,db⟩ := demand
  have bsize : b.card≤5 := by
    obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hb
    exact (localData q hq).2.1 db
  have cap : ∑ t∈T.erase b, (t.card-1) ≤ (T.erase b).card*5 := by
    apply Finset.sum_le_card_nsmul
    intro a ha
    obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp (Finset.mem_erase.mp ha).2
    have six := (localData q hq).1
    omega
  have weight := Finset.sum_erase_add (f:=fun z : Finset Block => z.card-1) T hb
  have count := Finset.card_erase_add_one hb
  have rows : T.card ≤ W.card := Finset.card_image_le
  omega

end Path462Cut
#print axioms Path462Cut.no_66_wheel_completion

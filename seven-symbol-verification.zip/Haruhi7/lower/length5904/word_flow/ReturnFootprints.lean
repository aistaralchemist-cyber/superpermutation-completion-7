import ExcursionCore

namespace ExactWordFlow.ReturnFootprints
open SevenWordWindows RotationCore RotationReinsert LapSkeleton DirectedEuler ResidualDensity ExcursionCore

def labels (edges : List Block) : Finset Block :=
  ((edges.filter (fun e=>e.Nodup)).map classKey).toFinset

theorem lost_subset {w : Block} {keep removed : List Block}
    (account : ∀e∈windows w,e∈keep ∨ e∈removed) : lost w keep⊆labels removed := by
  intro c hc
  obtain ⟨old,p,rep,key,absent⟩:=Finset.mem_filter.mp hc
  have seen:=((mem_complete _ _).mp old).2 p rep key
  have gone: p∈removed:=(account p seen).resolve_left absent
  exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨p,List.mem_filter.mpr
    ⟨gone,decide_eq_true ((mem_reps _).mp rep).2⟩,key⟩)

private def tails : Nat → List Block
  | 0 => [[]]
  | n+1 => []::(List.finRange 7).flatMap fun a=>(tails n).map (a::·)

private theorem member (p : Block) (n : Nat) (small : p.length≤n) : p∈tails n := by
  induction n generalizing p with
  | zero => cases p <;> simp_all [tails]
  | succ n ih =>
    cases p with
    | nil => simp [tails]
    | cons a p =>
      exact List.mem_cons_of_mem _ (List.mem_flatMap.mpr ⟨a,List.mem_finRange _,
        List.mem_map.mpr ⟨p,ih p (by simpa using small),rfl⟩⟩)

private def canon := (List.range 7).map (fun i=>(List.finRange 7).rotate i)
private def ren (p : Block) (x : Fin 7) : Fin 7 := Fin.ofNat 7 ((classKey p).idxOf x)

private theorem normalize : ∀p∈representatives,Function.Injective (ren p) ∧ ren p 0=0 ∧ p.map (ren p)∈canon := by native_decide

private theorem check : ∀p∈canon,∀a∈tails 3,(labels (windows (p++a++p.take 6))).card≤2 := by native_decide

private theorem windows_map (f : Fin 7→Fin 7) (w : Block) :
    windows (w.map f)=(windows w).map (List.map f) := by
  induction w with
  | nil => rfl
  | cons a xs ih =>
    by_cases h : 6≤xs.length <;> simp [windows,h,ih,List.map_take]

private theorem key_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (zero : f 0=0) (p : Block) :
    classKey (p.map f)=(classKey p).map f := by
  have pred : (fun x : Fin 7 => x != 0) ∘ f = (fun x => x != 0) := by
    funext x
    by_cases z : x=0
    · simp [z,zero]
    · have nz : f x≠0 := fun e => z (inj (e.trans zero.symm))
      simp only [Function.comp_apply,bne_iff_ne.mpr nz,bne_iff_ne.mpr z]
  unfold classKey
  rw [List.dropWhile_map,List.takeWhile_map,pred,List.map_append]

private theorem labels_map (f : Fin 7→Fin 7) (inj : Function.Injective f) (zero : f 0=0) (es : List Block) :
    labels (es.map (List.map f))=(labels es).image (List.map f) := by
  ext c
  simp only [labels,List.mem_toFinset,List.mem_map,List.mem_filter,decide_eq_true_eq,Finset.mem_image]
  constructor
  · rintro ⟨e,⟨⟨p,hp,rfl⟩,unique⟩,rfl⟩
    exact ⟨_,⟨p,⟨hp,unique.of_map _⟩,rfl⟩,(key_map f inj zero p).symm⟩
  · rintro ⟨_,⟨p,⟨hp,unique⟩,rfl⟩,rfl⟩
    exact ⟨_,⟨⟨p,hp,rfl⟩,unique.map inj⟩,key_map f inj zero p⟩

/-- In a cyclic word of length seven through ten with an initial permutation,
every permutation edge has one of at most two rotation classes. -/
theorem word_cap {p a : Block} (rep : p∈representatives) (short : a.length≤3) :
    (labels (windows (p++a++p.take 6))).card≤2 := by
  obtain ⟨inj,z,norm⟩:=normalize p rep
  let f:=ren p
  have sm : (a.map f).length≤3:=by simpa using short
  have h:=check (p.map f) norm (a.map f) (member _ 3 sm)
  have eq : (p.map f++a.map f++(p.map f).take 6)=(p++a++p.take 6).map f := by
    simp [List.map_take]
  rw [eq,windows_map,labels_map f inj z,Finset.card_image_of_injective _ (List.map_injective_iff.mpr inj)] at h
  exact h

#print axioms word_cap
end ExactWordFlow.ReturnFootprints

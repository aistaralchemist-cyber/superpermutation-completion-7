import PhaseCount
import CompleteCycleRank
import Core1620
import Transfer5901

namespace ExactWordFlow.RauzyBudget
open RotationCore RotationReinsert SevenWordWindows SuperpermutationBounds

def d₆ (v : Block) := (anchors v).toFinset.card
def d₇ (v : Block) := (windows v).toFinset.card
def wheels (v : Block) := (CompleteCycleRank.completeWheels v).card

/-- Distinct six-letter contexts above one per visited rotation class and
six further contexts per completed rotation class. -/
def extraContexts (v : Block) := d₆ v - ((visited v).card + 6*(complete v).card)

/-- Repeated occurrences of a seven-letter factor, beyond its first. -/
def repeats (v : Block) := (windows v).length - d₇ v

/-- Cycle-space dimension outside the independent complete seven-cycles
and complete six-wheels, measured in the undirected factor multigraph. -/
def otherRank (v : Block) := (d₇ v+1) - (d₆ v+(complete v).card+wheels v)

def defect (v : Block) := extraContexts v + wheels v + repeats v + otherRank v

/-- Separate the four nonnegative contributions without using a division,
an approximation, or a prescribed traversal through the classes. -/
theorem length_eq (v : Block) (h : 6≤v.length) :
    v.length=5+(visited v).card+7*(complete v).card+defect v := by
  have vertices : (visited v).card+6*(complete v).card≤d₆ v := PhaseCount.phases v
  have cycles : d₆ v+(complete v).card+wheels v≤d₇ v+1 := CompleteCycleRank.word_cycles_le v h
  have unique : d₇ v≤(windows v).length := List.toFinset_card_le _
  have len := windows_length v
  unfold defect extraContexts repeats otherRank
  omega

/-- This objective can be read from a single short word, then lifted by
completing its as-yet unfinished mandatory rotations. -/
theorem full_score {v : Block} (h : 6≤v.length) (hit : (visited v).card=720) :
    v.length+7*(720-(complete v).card)=5765+defect v := by
  have cap := Finset.card_le_card (complete_subset v)
  have eq := length_eq v h
  omega

theorem from_floor {k : Nat} (floor : Transfer5901.WordFloor k) {v : Block}
    (h : 6≤v.length) (hit : (visited v).card=720) : k≤5765+defect v := by
  obtain ⟨w,all,sz⟩:=expand_remaining h hit
  rw [←full_score h hit,←sz]
  exact floor w all

/-- A word lower bound of 5901 translates to 136 in this integer objective. -/
theorem known_136 (floor : Transfer5901.WordFloor 5901) {v : Block}
    (h : 6≤v.length) (hit : (visited v).card=720) : 136≤defect v := by
  have lower:=from_floor floor h hit
  omega

/-- The desired global bound is exactly the missing four units, including
the cycle-space dimension of circuits other than the complete wheels and laps. -/
theorem criterion : (∀v : Block, 6≤v.length → (visited v).card=720 → 140≤defect v) ↔
    ¬∃w : Block,Covers w ∧ w.length≤5904 := by
  constructor
  · intro lower counter
    obtain ⟨v,long,cap,hit,many⟩:=exact_1620.mp counter
    have lo:=lower v long hit
    have eq:=full_score long hit
    omega
  · intro excluded v long hit
    obtain ⟨w,all,sz⟩:=expand_remaining long hit
    have lo : 5904<w.length := by
      by_contra! small
      exact excluded ⟨w,all,small⟩
    have eq:=full_score long hit
    omega

#print axioms length_eq
#print axioms criterion
end ExactWordFlow.RauzyBudget

import ExtremeWheelCut

namespace ExactWordFlow.PlanarScoreExample
open SevenWordWindows SeedWheelCut ExtremeWheelCut
open private digits makeCert valid eliminates from ExtremeWheelCut

/-- Each row gives the start of a consecutive run of ordinary tail rotations
and the number of tail rotations used before the exceptional transition. -/
private def rows : List (Nat × String) := [(5, "0123456"),
  (5, "0234516"),
  (5, "0345126"),
  (5, "0451236"),
  (3, "0512346"),
  (5, "0651243"),
  (5, "0512463"),
  (5, "0124653"),
  (3, "0246513"),
  (5, "0324615"),
  (5, "0246135"),
  (5, "0461325"),
  (3, "0613245"),
  (5, "0561342"),
  (5, "0613452"),
  (3, "0134562"),
  (5, "0213465"),
  (5, "0134625"),
  (5, "0346215"),
  (3, "0462135"),
  (5, "0546231"),
  (5, "0462351"),
  (5, "0623541"),
  (3, "0235461"),
  (5, "0123564"),
  (5, "0235614"),
  (3, "0356124"),
  (5, "0435621"),
  (5, "0356241"),
  (5, "0562431"),
  (3, "0624351"),
  (3, "0162453"),
  (5, "0316254"),
  (5, "0162534"),
  (5, "0625314"),
  (3, "0253164"),
  (5, "0425361"),
  (5, "0253641"),
  (5, "0536421"),
  (5, "0364251")]

def walk : List Block := rows.flatMap fun (r,s) =>
  (List.range (r+1)).map fun j => (digits s).take 1 ++ (digits s).tail.rotate j

def rootClasses : Finset Block := (walk.map classKey).toFinset

/-- The cost of the edge x → R(y) for h-successor y. -/
private def cost (x y : Block) : Nat :=
    let z:= y.rotate 1
    ((List.range 7).map (·+1) |>.find? (fun d => x.drop d == z.take (7-d))).getD 8

private def paid := (walk.zip walk.tail).map fun (x,y) => cost x y

/-- All 220 entries are genuine seven-symbol permutations, their rotation
tags are distinct, and all paid costs are fully accounted for. The missing
closing edge has cost seven, hence it is a maximizing cut. -/
theorem profile : (∀ p∈walk,p.length=7 ∧ p.Nodup) ∧ walk.length=220 ∧
    rootClasses.card=220 ∧ paid.length=219 ∧ paid.count 2=180 ∧ paid.count 3=39 ∧
    cost (walk.getLastD []) (walk.headD [])=7 ∧
    (paid.map fun d => d-2).sum=39 ∧
    walk.length-6-5*(paid.map fun d => d-2).sum=19 := by native_decide

private def obstruction := makeCert [
  ("0123546","012546"), ("0213456","021456"),
  ("0243561","024361"), ("0124536","124536")] "0435612"

private theorem check_chain : valid rootClasses obstruction=true := by native_decide

/-- A 220-class root at the putative 5904 score fails all 100-wheel
extensions, even allowing supports to overlap. Four forced wheels are
sufficient, independently of the order of all the remaining wheels. -/
theorem no_neutral_extension {W : Finset (Finset Block)} (legal : W⊆allRows)
    (limit : W.card≤100) : ¬ ClosedCover rootClasses allClasses W := by
  have card : allClasses.card=720 := by native_decide
  have rootSize := profile.2.2.1
  exact eliminates obstruction _ legal (by omega) check_chain

#print axioms profile
#print axioms no_neutral_extension
end ExactWordFlow.PlanarScoreExample

import PathTurnsGap
import NinetyTwo

namespace ExactWordFlow.PathTurnsGap
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence RotationCore
open WeightedMarks ExtremalRealizations ExtremeWheelCut SuperpermutationBounds
set_option maxHeartbeats 800000
open private normalized_rows from PathTurnsGap

theorem no_single_path_93_94 {s t : Block} {es ws : List Block}
    (h : Feasible ((↑es : Multiset Block)+EmbeddedWheels.turns ws) s t)
    (r : Route src dst s es t) (fullW : ∀w∈ws,full w)
    (budget : es.length+6*ws.length≤858) (lo : 93≤ws.length) (hi : ws.length≤94) : False := by
  classical
  have wd (e) (he : e∈es) : e.length=7:=h.edges_seven e (Multiset.mem_add.mpr (Or.inl he))
  have rk:=EmbeddedWheels.residual_rank ws fullW h
  change 719≤5*ws.length+separateRank (↑es) s at rk
  rw [OnePath66.path_rank_eq r s] at rk
  have val:=WeightedMarks.path_cap r wd
  by_cases n94 : ws.length=94
  · have col : 250≤classCount s es:=by omega
    have len : es.length+1=295:=by omega
    obtain ⟨f,bij,zero,j,norm⟩:=FusedOne294.route_coverage Cap94Lookup.accept FusedOneGround.checked r wd len col
    obtain ⟨W,legal,size,closed⟩:=normalized_rows h r fullW bij zero
    obtain ⟨Z,leg,ct,covered⟩:=NearRootMoves.transport legal closed (List.replicate j 7)
    exact Cap94Lookup.no_cover norm leg (by omega) covered
  have col : 255≤classCount s es:=by omega
  have len : es.length+1=301:=by omega
  obtain ⟨f,bij,zero,j,norm⟩:=FusedAny.route_coverage (by decide) FusedAny.profile300
    Cap93Lookup.accept FusedPacked93.checked r wd len col
  obtain ⟨W,legal,size,closed⟩:=normalized_rows h r fullW bij zero
  obtain ⟨Z,leg,ct,covered⟩:=NearRootMoves.transport legal closed (List.replicate j 7)
  exact Cap93Lookup.no_cover norm leg (by omega) covered

#print axioms no_single_path_93_94
end ExactWordFlow.PathTurnsGap

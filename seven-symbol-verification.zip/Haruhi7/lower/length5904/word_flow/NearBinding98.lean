import NearBindingCheck

namespace ExactWordFlow.NearWheelBinding
theorem checked98 : verified 98=true := by native_decide
#print axioms checked98
end ExactWordFlow.NearWheelBinding

import NearBindingCheck
import Cap35Fibers

namespace ExactWordFlow.Mixed277
open SevenWordWindows ResidualDensity RotationCore NearHardRoots NearWheelBinding Cap35Fibers
open private parse from NearBindingCheck
open private valid from ExtremeWheelCut

def roots := ((include_str "mixed-roots.txt").trimAscii.toString.splitOn "\n").map (fun w=>visited (digits w))
def fiberReps := ((include_str "mixed-fibers.txt").trimAscii.toString.splitOn "\n").map digits
def fibers := fiberReps.map fiber

def makeSeed (i j : Nat) (p : Block) := (roots.toArray[i]!) ∪ ((fibers.toArray[j]!).erase p)

def hard := ((include_str "mixed277-hard.txt").trimAscii.toString.splitOn "\n").map fun line=>
  match line.splitOn " " with
  | [i,j,k] => makeSeed i.toNat! j.toNat! (digits k)
  | _ => ∅

private def answers : Std.HashMap (Nat×Nat×Block) Answer := Id.run do
  let mut a := {}
  for line in (include_str "mixed277-certs.txt").trimAscii.toString.splitOn "\n" do
    if let i::j::rest := line.splitOn " " then
      let (p,ans) := parse (String.intercalate " " rest)
      a := a.insert (i.toNat!,j.toNat!,p) ans
  return a

def response (i j : Nat) (p:Block) := answers.getD (i,j,p) (.easy (.stop []))
def checkAnswer (A : Finset Block) (ans : Answer) : Bool :=
  match ans with
  | .easy cert => decide (A.card≤265) && valid A cert
  | .hard i xs => decide (i<hard.toArray.size ∧ NearRootMoves.applyMoves xs A=hard.toArray[i]! ∧
      (hard.toArray[i]!).card=265)

def checkedPair (i j : Nat) : Bool :=
  let R:=roots.toArray[i]!
  let F:=fibers.toArray[j]!
  decide (1<(R∩F).card) || (F.sort (·≤·)).all (fun p=>
    let A:=R∪F.erase p
    decide (A.card<265) || checkAnswer A (response i j p))

def checked := (List.range roots.length).all fun i=> (List.range fibers.length).all (checkedPair i)

end ExactWordFlow.Mixed277

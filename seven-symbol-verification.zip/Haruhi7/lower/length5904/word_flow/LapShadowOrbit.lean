import LapDeletionShadow

namespace ExactWordFlow.LapDeletionShadow
open SevenWordWindows DeletionShadow

/-- Rotating the seven-letter source affects the starting phase of the
projected lap, but preserves its entire multiset of six-letter windows. -/
private theorem phases : ∀a∈List.finRange 7,∀p∈representatives,
    orbit a p=(↑(turns (proj a (classKey p))) : Multiset Block) ∧
    (turns (proj a (classKey p))).Nodup := by native_decide

theorem orbit_class (a : Fin 7) {p : Block} (hp : p∈representatives) :
    orbit a p=↑(turns (proj a (classKey p))) := (phases a (List.mem_finRange _) p hp).1

theorem phase_independent (a : Fin 7) {p q : Block} (hp : p∈representatives)
    (hq : q∈representatives) (eq : classKey p=classKey q) : orbit a p=orbit a q := by
  rw [orbit_class a hp,orbit_class a hq,eq]

/-- The multiplicity of each individual six-letter phase changes by zero or one. -/
theorem one_count (a : Fin 7) (l p r q : Block) (hp : p∈representatives) :
    (sixWindows (erase a (l++p++p.take 6++r))).count q =
      (sixWindows (erase a (l++p.take 6++r))).count q +
        (if q∈turns (proj a (classKey p)) then 1 else 0) := by
  obtain ⟨b,e,big,small⟩:=ordered a l p r hp
  have unique : (turns (erase a p)).Nodup := by
    change (orbit a p).Nodup
    rw [orbit_class _ hp]
    exact (phases a (List.mem_finRange _) p hp).2
  have same : q∈turns (erase a p) ↔ q∈turns (proj a (classKey p)) := by
    change q∈orbit a p ↔ q∈(↑(turns (proj a (classKey p))) : Multiset Block)
    rw [orbit_class a hp]
  rw [big,small]
  simp only [List.count_append]
  by_cases yes : q∈turns (proj a (classKey p))
  · rw [ite_eq_left yes,List.count_eq_one_of_mem unique (same.mpr yes)]
    omega
  · rw [ite_eq_right yes,List.count_eq_zero_of_not_mem (fun h=>yes (same.mp h))]
    omega

theorem class_laps (a : Fin 7) {w z : Block} {ps : List Block} (cuts : Cuts w ps z) :
    bag a w=bag a z+(ps.map (fun p=>(↑(turns (proj a (classKey p))) : Multiset Block))).sum := by
  induction cuts with
  | stop => simp
  | remove hp _ ih =>
    rw [one_lap _ _ _ _ hp,ih,orbit_class _ hp]
    simp only [List.map_cons,List.sum_cons]
    ac_rfl

#print axioms class_laps
end ExactWordFlow.LapDeletionShadow

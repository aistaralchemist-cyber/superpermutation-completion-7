import OnePath66

namespace ExactWordFlow.OnePath66
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels
open scoped Classical

theorem join_routes {u v t : Block} {p q : List Block}
    (hp : Route src dst u p v) (hq : Route src dst v q t) :
    Route src dst u (p++q) t := by
  induction hp with
  | nil => exact hq
  | cons e h _ ih => exact .cons e h (ih hq)

private theorem one_head (x : Block) (xs : List Block) :
    (touched (x::xs)).card ≤ (touched xs).card+1 := by
  by_cases f : full x
  · simpa [touched,f] using Finset.card_insert_le (tag x) (touched xs)
  · simp [touched,f]

private theorem before {s a : Block} {p : List Block} (rp : Route src dst s p a) (xs : List Block) :
    classCount s (p++xs)≤classCount a xs+p.length := by
  induction rp with
  | nil => simp
  | @cons u v tail e st rt ih =>
    have head := one_head u (dst e::(tail++xs).map dst)
    change classCount u ((e::tail)++xs) ≤ classCount v xs+(e::tail).length
    change classCount u ((e::tail)++xs) ≤ classCount (dst e) (tail++xs)+1 at head
    rw [List.length_cons]
    omega

private theorem after (a : Block) (es q : List Block) :
    classCount a (es++q)≤classCount a es+q.length := by
  have add (L M : List Block) : touched (L++M)=touched L ∪ touched M := by
    simp [touched]
  have small : (touched (q.map dst)).card≤q.length := by
    apply (List.toFinset_card_le _).trans
    simpa using List.length_filter_le (fun x => decide (full x)) (q.map dst)
  have form : classCount a (es++q)=((touched (a::es.map dst))∪touched (q.map dst)).card := by
    simp only [classCount,List.map_append]
    rw [←add]
    rfl
  rw [form]
  exact (Finset.card_union_le ..).trans (Nat.add_le_add_left small _)

/-- Five additional edges placed only at the two ends of a 390-class spine
must gain five distinct classes. The remaining 65 wheels leave no slack. -/
theorem extended_spine_exact {a b s t : Block} {p es q ws : List Block}
    (pre : Route src dst s p a) (spine : Route src dst a es b) (post : Route src dst b q t)
    (classes : classCount a es=390) (k : ws.length≤65) (legit : ∀w∈ws, full w)
    (five : p.length+q.length=5)
    (h : Feasible (((↑es : Multiset Block)+turns ws)+↑(p++q)) s t) :
    classCount s (p++es++q)=395 ∧ ws.length=65 := by
  have eq : (↑(p++es++q) : Multiset Block)+turns ws =
      ((↑es : Multiset Block)+turns ws)+↑(p++q) := by
    simp only [←Multiset.coe_add]
    ac_rfl
  have joined := join_routes (join_routes pre spine) post
  have good : Feasible ((↑(p++es++q) : Multiset Block)+turns ws) s t := eq.symm ▸ h
  have lo := residual_rank ws legit good
  change 719≤5*ws.length+separateRank (↑(p++es++q)) s at lo
  rw [path_rank_eq joined s] at lo
  have hi := before pre (es++q)
  rw [←List.append_assoc] at hi
  have last := after a es q
  omega

#print axioms extended_spine_exact
end ExactWordFlow.OnePath66

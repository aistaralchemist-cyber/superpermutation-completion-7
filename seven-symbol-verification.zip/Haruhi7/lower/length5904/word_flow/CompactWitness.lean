import CompactTraverse
import CompactTraceBridge
import CoreDecision1501

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows RotationCore

/-- The inputs remain free. Every gate equation has a constructive extension,
regardless of whether the output assertions hold. -/
theorem extend_tape (src : Source → Bool) (es : List Event) (start : Nat)
    (old : Nat → Bool) (sc : checkScope start es = true) :
    ∃ v : Nat → Bool, (∀j<start, v j=old j) ∧ admits (sourceTest src v) start es := by
  induction es generalizing start old with
  | nil => exact ⟨old,fun _ _=>rfl,trivial⟩
  | cons e rest ih =>
    change (if (args e).all (fun x=>decide (x≠0 ∧ x.natAbs ≤ start))
      then checkScope (advance start e) rest else false)=true at sc
    split at sc
    next h =>
      have prior {x : W} (mem : x ∈ args e) : x.natAbs-1 < start := by
        obtain ⟨nz,hi⟩ := of_decide_eq_true (List.all_eq_true.mp h x mem)
        have pos := Int.natAbs_pos.mpr nz
        omega
      let set : Bool := match e with
        | .fresh s => src s | .assertion _ => false
        | .gateOr xs => xs.any (wire old)
        | .gateMux c a b => if wire old c then wire old a else wire old b
      let next := match e with
        | .assertion _ => old | _ => Function.update old start set
      obtain ⟨v,keep,tail⟩ := ih (advance start e) next sc
      have agree (j : Nat) (lt : j<start) : v j=old j := by
        have hn : j<advance start e := by cases e <;> simp [advance] <;> omega
        rw [keep _ hn]
        cases e <;> simp [next,Function.update_of_ne (Nat.ne_of_lt lt)]
      have eval {x : W} (mem : x∈args e) : wire v x=wire old x := by
        simp only [wire,agree _ (prior mem)]
      refine ⟨v,agree,?_,tail⟩
      cases e with
      | assertion => trivial
      | fresh s => simpa [sourceTest,next,set,advance] using keep start (by simp [advance])
      | gateOr xs =>
        have same : xs.any (wire v) = xs.any (wire old) := by
          apply Bool.eq_iff_iff.mpr
          simp only [List.any_eq_true]
          exact exists_congr fun x=>and_congr_right fun hx=>by rw [eval hx]
        change v start = xs.any (wire v)
        rw [same]
        simpa [next,set] using keep start (by simp [advance])
      | gateMux c a b =>
        have c' := eval (x:=c) (by simp [args])
        have a' := eval (x:=a) (by simp [args])
        have b' := eval (x:=b) (by simp [args])
        change v start = (if wire v c then wire v a else wire v b)
        rw [c',a',b']
        simpa [next,set] using keep start (by simp [advance])
    next => contradiction

def claims (es : List Event) : List (List W) := es.filterMap fun e=>
  match e with | .assertion xs => some xs | _ => none

theorem with_claims {src : Source → Bool} {v : Nat → Bool} {es : List Event} {n : Nat}
    (eqs : admits (sourceTest src v) n es) :
    tailMeaning v n es ↔ ∀r∈claims es, r.any (wire v)=true := by
  induction es generalizing n with
  | nil => simp [tailMeaning,claims]
  | cons e es ih =>
    obtain ⟨head,tail⟩:=eqs
    rw [tailMeaning,ih tail]
    cases e <;> simp_all [claims,gateMeaning,sourceTest]

def goalTape (cuts : Bool) := compact 7 1501 91 cuts

set_option maxRecDepth 100000 in
/-- Both emitted instances are scoped, including the budget tests. -/
theorem goal_scope : ∀cuts, checkScope 0 (goalTape cuts).body.toList = true := by
  intro cuts
  cases cuts <;> native_decide

theorem candidate_assignment {src : Source → Bool} (cuts : Bool) :
    ∃v, admits (sourceTest src v) 0 (goalTape cuts).body.toList ∧
      ((certFormula (goalTape cuts)).eval v = true ↔
        ∀r∈claims (goalTape cuts).body.toList, r.any (wire v)=true) := by
  have sc := goal_scope cuts
  obtain ⟨v,_,holds⟩:=extend_tape src _ 0 (fun _=>false) sc
  exact ⟨v,holds,(cert_formula_iff _ _ (scope_checked sc).1).trans (with_claims holds)⟩

end ExactWordFlow.CompactWordCircuit

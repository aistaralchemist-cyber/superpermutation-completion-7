import Cap94Shape
import SaturatedContacts
import OverlapLoss

namespace ExactWordFlow.Forest94
open SevenWordWindows ResidualRoutes ResidualIncidence RotationComponentCount ResidualDensity
open scoped Classical
open private hits Cost local_rank rank_partition from NearHundredShape

/-- In either 94-component shape the connected incidence family uses all
719 available merges, leaving no room for any incidence cycle. -/
theorem saturated {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (cnt : (occupied X s).card=94) : separateRank X s=719 := by
  classical
  have low : 719≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  have rank:=rank_partition h
  have wheel (q) (hq : q∈occupied X s) (size : Cost X q=6) : hits X s q-1≤5 := by
    have price:=local_rank h q hq
    rw [size] at price
    omega
  obtain ⟨_,shape⟩:=Cap94Shape.shape h budget cnt
  rcases shape with ⟨_,root,others⟩|⟨_,root,q,mem,_,tags,others⟩
  · have sum:=Finset.sum_le_sum (s:=occupied X s) (f:=fun u=>hits X s u-1) (g:=fun _=>5)
        (fun u hu=>wheel u hu (others u hu))
    simp only [Finset.sum_const,smul_eq_mul,cnt] at sum
    omega
  · have sum:=Finset.sum_le_sum (s:=(occupied X s).erase q) (f:=fun u=>hits X s u-1) (g:=fun _=>5)
        (fun u hu=>wheel u (Finset.mem_erase.mp hu).2 (others u (Finset.mem_erase.mp hu).2 (Finset.mem_erase.mp hu).1))
    have n:=Finset.card_erase_add_one mem
    simp only [Finset.sum_const,smul_eq_mul] at sum
    have split:=Finset.sum_erase_add (occupied X s) (fun u=>hits X s u-1) mem
    omega

theorem forest {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (cnt : (occupied X s).card=94) :
    let D:=support X s
    ∀ U⊆D.image (label X), ∑q∈U,((contacts D (label X) q).card-1) ≤
      (U.biUnion (contacts D (label X))).card-1 :=
  feasible_saturated_subfamilies (label X) h (fun _ he=>on_edge he) (saturated h budget cnt)

theorem pair {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (cnt : (occupied X s).card=94)
    {a b : Component X} (ne : a≠b) (ha : a∈(support X s).image (label X))
    (hb : b∈(support X s).image (label X)) :
    (contacts (support X s) (label X) a ∩ contacts (support X s) (label X) b).card≤1 := by
  classical
  by_contra! many
  have nonempty:=Finset.card_pos.mp (Nat.zero_lt_of_lt many)
  have loss:=overlap_loss (label X) h (fun _ he=>on_edge he) ne ha hb nonempty
  change 719+(_-1)≤ separateRank X s at loss
  rw [saturated h budget cnt] at loss
  omega

#print axioms saturated
#print axioms forest
#print axioms pair
end ExactWordFlow.Forest94

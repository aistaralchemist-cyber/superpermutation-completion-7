import RotationSplice

namespace ExactWordFlow.RotationSplice
variable {X : Type*} [Fintype X] [DecidableEq X] {n : Nat}

/-- Changing one representative can only destroy an ordinary arc at that
state or at its predecessor. If neither exists, no new ordinary arc is possible. -/
private theorem single_change (R : Equiv.Perm X) (occ : X → Fin n → Prop)
    (p : X → Fin n) (valid : ∀x,occ x (p x))
    (best : ∀f,(∀x,occ x (f x)) → (ordinary R f).card≤(ordinary R p).card)
    (z : X) (slot : Fin n) (ok : occ z slot) (outgoing : z∉ordinary R p)
    (incoming : R.symm z∉ordinary R p) :
    ordinary R (Function.update p z slot) = ordinary R p := by
  classical
  let f := Function.update p z slot
  have keeps : ordinary R p ⊆ ordinary R f := by
    intro x hx
    have off : x≠z := fun eq=>outgoing (eq ▸ hx)
    have offR : R x≠z := by
      intro eq
      have seq : x=R.symm z := by rw [←eq,Equiv.symm_apply_apply]
      exact incoming (seq ▸ hx)
    simpa [ordinary,f,Function.update_of_ne off,Function.update_of_ne offR] using hx
  have admissible (x) : occ x (f x) := by
    by_cases eq : x=z
    · subst x; simpa [f] using ok
    · simpa [f,Function.update_of_ne eq] using valid x
  exact (Finset.eq_of_subset_of_card_le keeps (best f admissible)).symm

theorem forced_outgoing (R : Equiv.Perm X) (occ : X → Fin n → Prop)
    (p : X → Fin n) (valid : ∀x,occ x (p x))
    (best : ∀f,(∀x,occ x (f x)) → (ordinary R f).card≤(ordinary R p).card)
    (x : X) (slot : Fin n) (ne : x≠R x)
    (ok : occ (R x) slot) (next : slot.val=(p x).val+1) (missed : p (R x)≠slot) :
    R x∈ordinary R p := by
  classical
  have off : x∉ordinary R p := by
    intro hx
    exact missed (Fin.ext (((Finset.mem_filter.mp hx).2).trans next.symm))
  by_contra no
  have eq:=single_change R occ p valid best (R x) slot ok no (by simpa using off)
  have added : x∈ordinary R (Function.update p (R x) slot) := by
    simp [ordinary,Function.update_of_ne ne,next]
  exact off (eq ▸ added)

theorem forced_incoming (R : Equiv.Perm X) (occ : X → Fin n → Prop)
    (p : X → Fin n) (valid : ∀x,occ x (p x))
    (best : ∀f,(∀x,occ x (f x)) → (ordinary R f).card≤(ordinary R p).card)
    (z : X) (slot : Fin n) (ne : R z≠z)
    (ok : occ z slot) (next : (p (R z)).val=slot.val+1) (missed : p z≠slot) :
    R.symm z∈ordinary R p := by
  classical
  have off : z∉ordinary R p := by
    intro hz
    have equal := (Finset.mem_filter.mp hz).2
    exact missed (Fin.ext (by omega))
  by_contra no
  have eq:=single_change R occ p valid best z slot ok off no
  have added : z∈ordinary R (Function.update p z slot) := by
    simp [ordinary,Function.update_of_ne ne,next]
  exact off (eq ▸ added)

#print axioms forced_outgoing
#print axioms forced_incoming
end ExactWordFlow.RotationSplice

import Mixed277Data

namespace ExactWordFlow.Mixed277
open SevenWordWindows ResidualDensity Cap35Fibers
private def index : Std.HashMap Block Nat := Id.run do
  let mut table := {}
  for (r,i) in fiberReps.zipIdx do
    for j in [:5] do table := table.insert ((r.take 5).rotate j) i
  return table

private def idOf (u : Block) := index.getD (u.take 5) fibers.length
private def rots (u : Block) := ((List.range 5).map (fun i=>(u.take 5).rotate i)).toFinset
private theorem fiberKeys : ∀u∈states,let i:=idOf u
    i<fiberReps.length ∧ (u.take 5).toFinset=(fiberReps.toArray[i]!.take 5).toFinset ∧
      rots u=rots (fiberReps.toArray[i]!) := by native_decide

private theorem test (u c : Block) : c∈fiber u ↔ c∈allClasses ∧ restrict (u.take 5) c∈rots u := by
  simp only [fiber,rots,Finset.mem_filter,List.any_eq_true,beq_iff_eq,List.mem_toFinset,List.mem_map]
  constructor <;> rintro ⟨a,i,hi,eq⟩ <;> exact ⟨a,i,hi,eq.symm⟩

theorem fiber_in {z : Block} (hz : full z) : fiber z∈fibers := by
  let i:=idOf z
  obtain ⟨lt,chars,rot⟩:=fiberKeys z (mem_states hz)
  let rep:=fiberReps.toArray[i]!
  have inside : rep∈fiberReps:=by
    change fiberReps.toArray[i]!∈fiberReps
    rw [getElem!_pos _ _ (by simpa [i] using lt)]
    exact List.getElem_mem ..
  have eq : fiber z=fiber rep := by
    ext c
    rw [test,test]
    have same : restrict (z.take 5) c=restrict (rep.take 5) c := by
      apply List.filter_congr
      intro x _; simp only [decide_eq_decide]
      have := Finset.ext_iff.mp chars x
      simpa [rep,i] using this
    rw [same,rot]
  rw [eq]; exact List.mem_map_of_mem inside

set_option maxHeartbeats 0 in
theorem geometry : (∀R∈roots,R.card=236) ∧ (∀F∈fibers,F.card=30) := by native_decide
set_option maxHeartbeats 0 in
theorem checks : checked=true := by native_decide
#print axioms checks
end ExactWordFlow.Mixed277

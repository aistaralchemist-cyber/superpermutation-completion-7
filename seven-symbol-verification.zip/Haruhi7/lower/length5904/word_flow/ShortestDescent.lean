import WordFlow

namespace ExactWordFlow
open SevenWordWindows SuperpermutationBounds

/-- A competing superpermutation may change both endpoints and all its
additional edges. Every mandatory permutation still has to occur. -/
def Shortenable (X : Multiset Block) : Prop :=
  ∃ (Y : Multiset Block) (u v : Block), Y.card<X.card ∧ Feasible Y u v

theorem actual_shorter {X : Multiset Block} (drop : Shortenable X) :
    ∃ w : Word, Covers w ∧ w.length<5046+X.card := by
  obtain ⟨Y,u,v,lt,h⟩ := drop
  obtain ⟨w,hw,n⟩ := (word_iff_flow (5046+Y.card) (by omega)).mpr ⟨Y,u,v,by omega,h⟩
  exact ⟨w,hw,by omega⟩

/-- Any feasible placement admits a globally shortest competitor among all
placements. The competitor does not have to be a submultiset. -/
theorem exists_irreducible {X : Multiset Block} {s t : Block} (good : Feasible X s t) :
    ∃ (Y : Multiset Block) (u v : Block), Y.card≤X.card ∧ Feasible Y u v ∧ ¬Shortenable Y := by
  classical
  let P (n : Nat) := ∃ (Z : Multiset Block) (a b : Block), Z.card=n ∧ Feasible Z a b
  have yes : ∃ n, P n := ⟨X.card,X,s,t,rfl,good⟩
  obtain ⟨Y,u,v,n,h⟩ := Nat.find_spec yes
  refine ⟨Y,u,v,n ▸ Nat.find_min' yes ⟨X,s,t,rfl,good⟩,h,?_⟩
  rintro ⟨Z,a,b,lt,hz⟩
  exact (Nat.find_min yes (n ▸ lt)) ⟨Z,a,b,rfl,hz⟩

/-- It suffices to shorten every surviving exception at every budget up to
858. This is equivalent to the numerical optimum and does not assume it. -/
theorem optimal_iff_shortening : SuperpermBridge.HR.Ssuper 7=5905 ↔
    ∀ (X : Multiset Block) (s t : Block), X.card≤858 → Feasible X s t → Shortenable X := by
  constructor
  · intro opt X s t size good
    obtain ⟨w,hw,hl⟩ := (word_iff_flow (5046+X.card) (by omega)).mpr ⟨X,s,t,by omega,good⟩
    have lb := SuperpermBridge.ssuper_le_length hw
    omega
  · intro drop
    apply optimal_iff_no_858.mpr
    rintro ⟨X,s,t,size,h⟩
    obtain ⟨Y,u,v,small,good,minimum⟩ := exists_irreducible h
    exact minimum (drop Y u v (by omega) good)

/-- Excluded normal cases and strictly improvable exceptional cases may be
proved separately. -/
theorem optimal_of_exceptions (exception : Multiset Block → Block → Block → Prop)
    (remaining : ∀ X s t, X.card≤858 → Feasible X s t → exception X s t)
    (improve : ∀ X s t, X.card≤858 → Feasible X s t → exception X s t → Shortenable X) :
    SuperpermBridge.HR.Ssuper 7=5905 :=
  optimal_iff_shortening.mpr (fun X s t budget h => improve X s t budget h (remaining X s t budget h))

#print axioms optimal_iff_shortening
end ExactWordFlow

import SeventeenCaps
import Packet64
import MacroAlternatives
import EndExchange
import EndpointSaving

set_option maxRecDepth 4096
set_option maxHeartbeats 600000

namespace ExactWordFlow.SeventeenBranches
open DirectedEuler ResidualDensity SevenWordWindows OnePath66 EmbeddedWheels ResidualControls

private abbrev W := mainWord
private abbrev a := W.take 6
private abbrev b := W.drop (W.length-6)
private theorem long : 6≤W.length := by native_decide

private theorem pack_ends (P E Q : List Block) (T : Multiset Block) :
    (↑(P++E++Q) : Multiset Block)+T+0 = ((↑E+T)+↑(P++Q)) := by
  simp only [←Multiset.coe_add,add_zero]
  ac_rfl

private theorem pack_back (E P : List Block) (T R : Multiset Block) :
    (↑(E++P) : Multiset Block)+T+R = ((↑E+T)+(↑P+R)) := by
  simp only [←Multiset.coe_add]
  ac_rfl

def anchor : Block := tag (dst [0,1,2,3,4,5,0])

theorem anchor_mem (s : Block) (p q : List Block) :
    anchor∈pathClasses s (p++windows W++q) := by
  let e : Block := [0,1,2,3,4,5,0]
  have old : e∈windows W := by native_decide
  have fl : full (dst e) := by native_decide
  have seen : e∈p++windows W++q := List.mem_append_left _ (List.mem_append_right _ old)
  exact List.mem_toFinset.mpr (List.mem_map.mpr
    ⟨dst e, List.mem_filter.mpr ⟨List.mem_cons_of_mem _ (List.mem_map.mpr ⟨e,seen,rfl⟩),
     decide_eq_true fl⟩,rfl⟩)

theorem extended_seed (s : Block) (p q : List Block) :
    (pathClasses s (p++windows W++q)).Nonempty := ⟨anchor,anchor_mem s p q⟩

/-- The ordinary literal two-sided extension would need at least 405
classes for 63 arbitrary wheels, whereas seventeen letters reach only 404. -/
theorem no_ends {ws p q : List Block} {s t : Block}
    (pre : Route src dst s p a) (post : Route src dst b q t)
    (wp : ∀e∈p,e.length=7) (wq : ∀e∈q,e.length=7)
    (legit : ∀v∈ws,full v) (n : ws.length≤63) (hi : p.length+q.length≤17)
    (together : RequiredComponent.ClassesTogether (bag W+turns ws+↑(p++q))) : False := by
  have cap := SeventeenCaps.extension_cap pre post wp wq hi
  change classCount s (p++windows W++q)≤404 at cap
  have r := join_routes (join_routes pre (read_route W long)) post
  have link : RequiredComponent.ClassesTogether ((↑(p++windows W++q) : Multiset Block)+turns ws+0) := by
    rw [pack_ends]; exact together
  have rank := exchange_rank r legit (extended_seed s p q) 0 0 (fun _ h => h) link
  simp only [Multiset.card_zero,Nat.add_zero] at rank
  omega

/-- Literal return paths lose at least three rank units, exceeding the
two units of slack at 63 wheels and 17 spare windows. -/
theorem no_return {ws p : List Block} {F : Multiset Block}
    (rp : Route src dst b p a) (widths : ∀e∈p,e.length=7)
    (legit : ∀v∈ws,full v) (n : ws.length≤63) (hi : p.length+F.card≤17)
    (together : RequiredComponent.ClassesTogether (bag W+turns ws+(↑p+F))) : False := by
  have cap := SeventeenCaps.return_cap rp widths (by omega)
  change classCount a (windows W++p)+3≤390+p.length at cap
  have r := join_routes (read_route W long) rp
  have sd := extended_seed a [] p
  simp only [List.nil_append] at sd
  have link : RequiredComponent.ClassesTogether ((↑(windows W++p) : Multiset Block)+turns ws+F) := by
    rw [pack_back]; exact together
  have rank := exchange_rank r legit sd F F (fun _ h => h) link
  change 720≤classCount a (windows W++p)+5*ws.length+F.card at rank
  omega

/-- Any balanced fully connected candidate at this budget must contain a
nonempty pure closed circuit entirely within the unprescribed windows. -/
theorem must_cycle {ws : List Block} {F : Multiset Block} {s t : Block}
    (legit : ∀v∈ws,full v) (n : ws.length≤63) (small : F.card≤17)
    (width : ∀e∈F,e.length=7)
    (bal : (bag W+turns ws+F).map src+{t}=(bag W+turns ws+F).map dst+{s})
    (together : RequiredComponent.ClassesTogether (bag W+turns ws+F)) :
    ∃ (v : Block) (p : List Block), p≠[] ∧ (↑p : Multiset Block)≤F ∧ Route src dst v p v := by
  have spine := read_route W long
  have rb := spine.balance
  have wb := EndpointSaving.turns_balance ws legit
  have old : (bag W+turns ws).map src+{b}=(bag W+turns ws).map dst+{a} := by
    simp only [bag,Multiset.map_add,wb,add_right_comm _ ((turns ws).map dst) _,rb]
  have degree := fresh_endpoints old bal
  rcases MacroAlternatives.alternatives src dst F degree with ends|cyc|back
  · obtain ⟨p,q,eq,pr,po⟩ := ends
    subst F
    exact False.elim (no_ends pr po (fun e he => width e (List.mem_append_left _ he))
      (fun e he => width e (List.mem_append_right _ he)) legit n (by simpa using small) together)
  · exact cyc
  · obtain ⟨p,sub,rp⟩ := back
    obtain ⟨R,split⟩ := exists_add_of_le sub
    have sz : p.length+R.card≤17 := by simpa only [split,Multiset.card_add,Multiset.coe_card] using small
    rw [split] at together
    exact False.elim (no_return rp (fun e he => width e (Multiset.mem_of_le sub he))
      legit n sz together)

#print axioms no_ends
#print axioms no_return
#print axioms must_cycle
end ExactWordFlow.SeventeenBranches

import Open306
import OpenWheelPacking
import ExtremeWheelCut
import EmbeddedWheels

namespace ExactWordFlow.PacketSeed306
open SevenWordWindows RotationCore OpenWheelPacking ExtremeWheelCut ResidualDensity
open SeedWheelCut (ClosedCover)
abbrev Row := Finset Block

private def encoded (s : String) : Block := s.toList.map (fun c=>Fin.ofNat 7 (c.toNat-'0'.toNat))
def pins : Row := (["0134625", "0136425", "0314652", "0316452", "0324165", "0324615", "0326415", "0341625", "0361425", "0416523", "0416532", "0436125", "0461253", "0534162", "0534612", "0536412", "0634125", "0641253", "0652341"].map encoded).toFinset
def x := encoded "0364125"
def y := encoded "0346125"
def z := encoded "0341652"
private def packetOptions (seed : Row) (c : Block) :=
  (allRows.filter (fun r=>c∈r)).biUnion (fun r=>r.image (fun p=>r.erase p)) |>.filter
    fun p=>c∈p ∧ Disjoint p seed

private def compatible (p q : Row) := p=q ∨ Disjoint p q
private instance (p q : Row) : Decidable (compatible p q) := inferInstanceAs (Decidable (_ ∨ _))

private theorem checks :
    pins.card=19 ∧ pins⊆visited Open306.path ∧
    (x∈allClasses ∧ y∈allClasses ∧ z∈allClasses) ∧
    (x∉visited Open306.path ∧ y∉visited Open306.path ∧ z∉visited Open306.path) ∧
    ∀p∈packetOptions pins x,∀q∈packetOptions pins y,∀r∈packetOptions pins z,
      ¬(compatible p q ∧ compatible q r ∧ compatible r p) := by native_decide

private theorem rowData : ∀R∈allRows,R⊆allClasses ∧ R.card≤6 := by native_decide

private theorem option {P u : Row} {c : Block} (pu : Packet allRows u) (absent : Disjoint u P)
    (tag : c∈u) : u∈packetOptions P c := by
  obtain ⟨R,leg,d,dr,rfl,_⟩:=pu
  exact Finset.mem_filter.mpr ⟨Finset.mem_biUnion.mpr ⟨R,Finset.mem_filter.mpr
    ⟨leg,Finset.mem_of_mem_erase tag⟩,Finset.mem_image.mpr ⟨d,dr,rfl⟩⟩,tag,absent⟩

/-- Saturation forces every missing class into one piece of a disjoint
partition by five-element packets. -/
theorem saturated {A : Row} (boardA : A⊆allClasses) (W : Finset Row)
    (legal : W⊆allRows) (tight : A.card+5*W.card≤720) (link : ClosedCover A allClasses W) :
    ∃T : Finset Row,(∀u∈T,Packet allRows u ∧ u⊆allClasses\A) ∧
      (∀u∈T,∀v∈T,u≠v → Disjoint u v) ∧ T.biUnion id=allClasses\A := by
  obtain ⟨T,ok,apart,bound⟩:=extract W boardA legal (fun R h=>rowData R (legal h)) link
  refine ⟨T,ok,apart,Finset.eq_of_subset_of_card_le (Finset.biUnion_subset.mpr fun u hu=>(ok u hu).2) ?_⟩
  have size (u : Row) (hu:u∈T) : u.card=5 := by
    obtain ⟨_,_,_,_,_,n⟩:=(ok u hu).1
    exact n
  have unionSize : (T.biUnion id).card=5*T.card := by
    change (T.biUnion (fun u=>u)).card=5*T.card
    rw [Finset.card_biUnion (fun u hu v hv ne=>apart u hu v hv ne)]
    calc
      _=∑_u∈T,5:=Finset.sum_congr rfl size
      _=_:=by simp [Nat.mul_comm]
  rw [Finset.card_sdiff_of_subset boardA,board]
  rw [board] at bound
  omega

/-- The other 698 rotation classes are unrestricted. Only 19 required
presences and three absences are used to refute a saturated wheel cover. -/
theorem obstruction {A : Row} (inBoard : A⊆allClasses) (positive : pins⊆A)
    (nx : x∉A) (ny : y∉A) (nz : z∉A) {W : Finset Row}
    (legal : W⊆allRows) (budget : A.card+5*W.card≤720) : ¬ClosedCover A allClasses W := by
  intro link
  obtain ⟨T,ok,apart,union⟩:=saturated inBoard W legal budget link
  have get (c : Block) (bc : c∈allClasses) (off : c∉A) :
      ∃u∈T,u∈packetOptions pins c := by
    have h:=Finset.mem_sdiff.mpr ⟨bc,off⟩
    rw [←union] at h
    obtain ⟨u,ut,cu⟩:=Finset.mem_biUnion.mp h
    exact ⟨u,ut,option (ok u ut).1 (Finset.disjoint_left.mpr fun {d} du dp=>
      (Finset.mem_sdiff.mp ((ok u ut).2 du)).2 (positive dp)) cu⟩
  have triple:=checks.2.2.1
  obtain ⟨p,pt,px⟩:=get x triple.1 nx
  obtain ⟨q,qt,qy⟩:=get y triple.2.1 ny
  obtain ⟨r,rt,rz⟩:=get z triple.2.2 nz
  have pair (a b : Row) (ha:a∈T) (hb:b∈T) : compatible a b :=
    (eq_or_ne a b).imp_right (fun ne=>apart a ha b hb ne)
  exact checks.2.2.2.2 p px q qy r rz ⟨pair p q pt qt,pair q r qt rt,pair r p rt pt⟩

theorem open306_fails {W : Finset Row} (legal : W⊆allRows) (count : W.card≤92) :
    ¬ClosedCover (visited Open306.path) allClasses W := by
  obtain ⟨a,b,c⟩:=checks.2.2.2.1
  exact obstruction (visited_subset _) checks.2.1 a b c legal (by rw [Open306.control.2]; omega)

#print axioms obstruction
#print axioms open306_fails
end ExactWordFlow.PacketSeed306

import ControlData
namespace ExactWordFlow.StrippedControl
open RotationCore RotationCoreControls SevenWordWindows ResidualDensity LiteralWheelCover
set_option maxRecDepth 30000
attribute [local irreducible] counts tests base offsets inner change touched insertAt RotationCore.visited RotationCore.complete RotationCoreControls.coreWord

theorem verified_control : base.length=1287 ∧ (complete base).card=92 ∧
    (visited base).card=535 ∧ legal (coreWord 628) offsets=true ∧ counts=[51,312,33] := by
  have h := certificate
  simp only [checked,Bool.and_eq_true_iff,beq_iff_eq,decide_eq_true_eq] at h
  tauto

theorem one_deletion (i : Nat) (hi : i<base.length) (done : 92≤(complete (change i)).card) :
    (visited (change i)).card ≤ 532 := by
  have h := certificate
  have prop : tests.all (fun (g,h) => decide (g<644 ∨ h≤532)) = true := (Bool.and_eq_true_iff.mp h).2
  have pos : ((good (change i)).length,
      if (good (change i)).length < 644 then 0 else (visited (change i)).card) ∈ tests := by
    rw [tests]
    exact List.mem_map_of_mem (f:=fun i=>((good (change i)).length,
      if (good (change i)).length < 644 then 0 else (visited (change i)).card)) (List.mem_range.mpr hi)
  have result : (good (change i)).length<644 ∨ (if (good (change i)).length<644 then 0 else (visited (change i)).card)≤532 := of_decide_eq_true (List.all_eq_true.mp prop _ pos)
  have price := LapSkeleton.completed_floor (change i)
  have hi' : ¬(good (change i)).length<644 := by omega
  simpa only [hi',ite_false,false_or] using result

/-- Remove any letter of the fully stripped control and permit every possible
reattachment. At most 37 wheels cannot recover all classes if 92 completions survive. -/
theorem no_budget (i : Nat) (hi : i<base.length) (done : 92≤(complete (change i)).card) :
    ¬condition (change i) 37 := by
  intro cover
  have a := one_deletion i hi done
  have c := WheelCoverCapacity.cover_bound cover
  omega

theorem touched_fails {a j : Nat} (ha : a∈offsets) (hj : j<12) :
    (complete (touched a j)).card ≤ 91 := by
  have outer : inner = true := (Bool.and_eq_true_iff.mp (Bool.and_eq_true_iff.mp certificate).1).2
  rw [inner] at outer
  have h : (good (touched a j)).length<644 := of_decide_eq_true
    (List.all_eq_true.mp (List.all_eq_true.mp outer _ ha) _ (List.mem_range.mpr hj))
  have price := LapSkeleton.completed_floor (touched a j)
  omega

#print axioms touched_fails
#print axioms no_budget
end ExactWordFlow.StrippedControl

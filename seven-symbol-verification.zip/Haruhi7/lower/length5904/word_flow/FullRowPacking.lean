import WheelContraction

namespace ExactWordFlow.FullRowPacking
variable {ι α : Type*} [DecidableEq ι] [DecidableEq α]

/-- Every row not sending six new names can pay for at most five of them
per unit of credit. A row spending two credits can pay for all six. -/
theorem extract (I : Finset ι) (row : ι→Finset α) (credit : ι→Nat)
    (width : ∀i∈I,(row i).card≤6) (pos : ∀i∈I,0<credit i) :
    ∃K⊆I,(∀i∈K,(row i).card=6 ∧ credit i=1) ∧
      (∀i∈K,∀j∈K,i≠j → Disjoint (row i) (row j)) ∧
      (I.biUnion row).card ≤ 5*(∑i∈I,credit i)+K.card := by
  classical
  induction I using Finset.induction_on with
  | empty => exact ⟨∅,by simp,by simp,by simp,by simp⟩
  | @insert i I fresh ih =>
    obtain ⟨K,sub,full,apart,count⟩:=ih (fun j hj=>width _ (Finset.mem_insert_of_mem hj))
      (fun j hj=>pos _ (Finset.mem_insert_of_mem hj))
    have wide:=width i (Finset.mem_insert_self ..)
    have paid:=pos i (Finset.mem_insert_self ..)
    let U:=I.biUnion row
    have grow : ((insert i I).biUnion row).card=U.card+((row i)\U).card := by
      rw [Finset.biUnion_insert]
      change (row i∪U).card=U.card+((row i)\U).card
      have h:=Finset.card_sdiff_add_card (row i) U
      omega
    have take:=Finset.card_le_card (Finset.sdiff_subset (s:=row i) (t:=U))
    change U.card≤5*(∑j∈I,credit j)+K.card at count
    by_cases add : ((row i)\U).card=6 ∧ credit i=1
    · have eq : (row i)\U=row i := Finset.eq_of_subset_of_card_le Finset.sdiff_subset (by omega)
      have d (j) (hj : j∈K) : Disjoint (row i) (row j) := by
        apply Finset.disjoint_left.mpr
        intro x hi me
        have sep : x∈(row i)\U:=by rw [eq]; exact hi
        exact (Finset.mem_sdiff.mp sep).2 (Finset.mem_biUnion.mpr ⟨j,sub hj,me⟩)
      refine ⟨insert i K,Finset.insert_subset_insert _ sub,?_,?_,?_⟩
      · intro j hj
        rcases Finset.mem_insert.mp hj with rfl|old
        · exact ⟨by omega,add.2⟩
        · exact full _ old
      · intro x hx y hy ne
        by_cases xi : x=i
        · subst x
          exact d y ((Finset.mem_insert.mp hy).resolve_left ne.symm)
        · have xK:=(Finset.mem_insert.mp hx).resolve_left xi
          by_cases yi : y=i
          · subst y; exact (d x xK).symm
          · exact apart x xK y ((Finset.mem_insert.mp hy).resolve_left yi) ne
      · have unseen : i∉K:=fun h=>fresh (sub h)
        rw [grow,Finset.card_insert_of_notMem unseen,Finset.sum_insert fresh]
        omega
    · refine ⟨K,sub.trans (Finset.subset_insert ..),full,apart,?_⟩
      rw [grow,Finset.sum_insert fresh]
      omega

#print axioms extract
end ExactWordFlow.FullRowPacking

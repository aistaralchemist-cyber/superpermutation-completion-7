import NormalizedWord
import Windows5904
import Mathlib.Data.List.Lex

namespace SevenEndpointPairs
open SuperpermutationBounds SevenWordWindows
abbrev identityWord := List.finRange 7

/-- If g lists the labels of a permutation, its partner is J ∘ g⁻¹ ∘ J,
where J reverses the order of the seven indices. The executable formula
uses the positions of J's labels in the reversed list g. -/
def partner (g : Word) : Word := identityWord.reverse.map
  (fun a => Fin.ofNat 7 (g.reverse.idxOf a))

def endpointReps : List Word := representatives.filter (fun g => decide (g ≤ partner g))

theorem endpoint_census : representatives.length=5040 ∧
    (representatives.filter (fun g => g==partner g)).length=232 ∧
    endpointReps.length=2636 ∧ endpointReps.Nodup := by native_decide

theorem partner_involution {g : Word} (mem : g∈representatives) :
    partner (partner g)=g ∧ partner g∈representatives := by
  have check : representatives.all (fun x =>
    decide (partner (partner x)=x ∧ (partner x).length=7 ∧ (partner x).Nodup))=true := by
    native_decide
  obtain ⟨e,lg,ng⟩ := of_decide_eq_true (List.all_eq_true.mp check g mem)
  exact ⟨e,(mem_reps _).mpr ⟨lg,ng⟩⟩

private theorem inverse_index (g : Word) (lg : g.length=7) (nd : g.Nodup) (a : Fin 7) :
    (SevenAlmostCover.relabel g lg nd).symm a = Fin.ofNat 7 (g.idxOf a) := by
  let f := SevenAlmostCover.relabel g lg nd
  let i := f.symm a
  have j : i.val < g.length := by have := i.isLt; omega
  have v : g[i.val] = a := f.apply_symm_apply a
  have ix : g.idxOf a=i.val := by simpa [v] using nd.idxOf_getElem i.val j
  change i=_
  exact Fin.ext (by simp [ix,Fin.ofNat,i.isLt,Nat.mod_eq_of_lt])

private theorem reverse_normalized {s g : Word} (c : Covers s) (lg : g.length=7) (nd : g.Nodup)
    (start : identityWord <+: s) (last : g <:+ s) :
    ∃ t : Word, t.length=s.length ∧ Covers t ∧ identityWord <+: t ∧ partner g <:+ t := by
  have lgr : g.reverse.length=7 := by simpa using lg
  have ngr : g.reverse.Nodup := by simpa using nd
  let f := (SevenAlmostCover.relabel g.reverse lgr ngr).symm
  have mapped : g.reverse.map f=identityWord := by
    have fwd := SevenAlmostCover.relabel_map g.reverse lgr ngr
    simpa [f] using congrArg (List.map f) fwd.symm
  have mappedLast : identityWord.reverse.map f=partner g := by
    have ef : (⇑f) = fun a => Fin.ofNat 7 (g.reverse.idxOf a) :=
      funext fun a => inverse_index g.reverse lgr ngr a
    exact congrArg (fun t : Fin 7 → Fin 7 => identityWord.reverse.map t) ef
  refine ⟨s.reverse.map f,by simp,?_,?_,?_⟩
  · intro p lp np
    obtain ⟨u,v,h⟩ := c (p.map f.symm).reverse (by simpa using lp) (by simpa using np.map f.symm.injective)
    exact ⟨v.reverse.map f,u.reverse.map f,by simp [h,List.append_assoc]⟩
  · obtain ⟨u,hu⟩ := last
    exact ⟨u.reverse.map f,by rw [←hu,List.reverse_append,List.map_append,mapped]⟩
  · obtain ⟨v,hv⟩ := start
    exact ⟨v.reverse.map f,by rw [←hv,List.reverse_append,List.map_append,mappedLast]⟩

/-- All endpoint-sensitive length-5,904 tests need only the 2,636
representatives; the involution comes from an actual word transformation. -/
theorem normalized_endpoint_representative {w : Word} (c : Covers w) (len : w.length≤5904) :
    ∃ s : Word, s.length=5904 ∧ Covers s ∧ identityWord <+: s ∧
      ∃ g∈endpointReps, g <:+ s := by
  obtain ⟨s,ls,cover,start,g,lg,nd,last⟩ := SevenNormalizedWord.normalize_5904 c len
  have mem : g∈representatives := (mem_reps g).mpr ⟨lg,nd⟩
  by_cases le : g ≤ partner g
  · exact ⟨s,ls,cover,start,g,List.mem_filter.mpr ⟨mem,decide_eq_true le⟩,last⟩
  · obtain ⟨t,lt,cv,st,en⟩ := reverse_normalized cover lg nd start last
    obtain ⟨round,member⟩ := partner_involution mem
    have ord : partner g ≤ partner (partner g) := by rw [round]; exact le_of_not_ge le
    exact ⟨t,lt.trans ls,cv,st,partner g,List.mem_filter.mpr ⟨member,decide_eq_true ord⟩,en⟩

end SevenEndpointPairs
#print axioms SevenEndpointPairs.normalized_endpoint_representative
#print axioms SevenEndpointPairs.endpoint_census

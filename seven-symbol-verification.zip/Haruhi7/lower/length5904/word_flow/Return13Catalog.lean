import AnchoredRepairLogic
import AnchoredRepairData
import LiteralWheelCover
import Control1508

namespace ExactWordFlow.AnchoredRepair
open SevenWordWindows RotationCore RotationCoreControls
open LiteralWheelCover (Inserts ready condition)

deriving instance ReflBEq, LawfulBEq for Report

abbrev restored (w : Block) (n : Nat) : Prop :=
  ∃rs z,Inserts w rs z ∧ rs.length≤n ∧ (visited z).card=720

theorem positions_iff (w : Block) (i : Nat) : i∈positions w ↔
    i+19≤w.length ∧ (w.drop i).take 6=(w.drop (i+13)).take 6 := by
  simp only [positions,List.mem_filter,List.mem_range,beq_iff_eq]
  constructor <;> rintro ⟨pos,eq⟩ <;> exact ⟨by omega,eq⟩

theorem counts : sourcePositions.length=37 ∧ ∀row∈types,census.count row.1=row.2 := by
  obtain ⟨both,_⟩:=Bool.and_eq_true_iff.mp checked
  obtain ⟨cnt,entries⟩:=Bool.and_eq_true_iff.mp both
  refine ⟨?_,fun row mem=>eq_of_beq (List.all_eq_true.mp entries row mem)⟩
  simpa [census] using eq_of_beq cnt

theorem realized_profile (i : Nat) (hi : i∈sourcePositions) :
    let q:=report (excise record i)
    q=⟨5,0,flags 3⟩ ∨ q=⟨5,0,flags 4⟩ ∨ q=⟨5,0,flags 5⟩ ∨
    q=⟨5,1,flags 6⟩ ∨ q=⟨5,2,flags 6⟩ ∨ q=⟨5,3,flags 6⟩ := by
  have h:=List.all_eq_true.mp (Bool.and_eq_true_iff.mp checked).2 _ (List.mem_map_of_mem (f:=fun i=>report (excise record i)) hi)
  obtain ⟨p,hp,e⟩:=List.any_eq_true.mp h
  have mem:=List.mem_map_of_mem (f:=Prod.fst) hp
  rw [eq_of_beq e] at mem
  simpa only [types,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] using mem

/-- The counts in the catalog distinguish exact minima of three, four, and
five wheels and certificates of impossibility for every wheel budget. -/
theorem restored_exact {v : Block} {m} (small:m<6) (profile:(report v).flags=flags m) (n : Nat) :
    restored v n ↔ m≤n :=
  (LiteralWheelCover.budget_iff v n).trans (exact_min v m small profile n)

theorem unavailable {v : Block} (miss : 0<(report v).unavailable) (n : Nat) : ¬restored v n :=
  fun yes=>impossible v miss n ((LiteralWheelCover.budget_iff v n).mp yes)

theorem two_never (i : Nat) (hi:i∈sourcePositions) : ¬restored (excise record i) 2 := by
  intro yes
  rcases realized_profile i hi with h|h|h|h|h|h
  · exact (by decide : ¬3≤2) ((restored_exact (m:=3) (by decide) (congrArg Report.flags h) 2).mp yes)
  · exact (by decide : ¬4≤2) ((restored_exact (m:=4) (by decide) (congrArg Report.flags h) 2).mp yes)
  · exact (by decide : ¬5≤2) ((restored_exact (m:=5) (by decide) (congrArg Report.flags h) 2).mp yes)
  all_goals exact unavailable (by rw [h];decide) 2 yes

private theorem summary_len {w : Block} {n a b : Nat} (h : summary w=(n,a,b)) : w.length=n :=
  congrArg (fun p : Nat×Nat×Nat => p.1) h

theorem length_lower (i : Nat) (hi:i∈sourcePositions) {rs z}
    (ins:Inserts (excise record i) rs z) (all:(visited z).card=720) : 1514≤z.length := by
  have inRange : i < record.length-18 :=List.mem_range.mp (List.mem_filter.mp hi).1
  have size:record.length=1509:=summary_len (w:=coreWord 628) (n:=1509) (a:=720) (b:=92) Boundary1508.reference628.1
  rw [size] at inRange
  have removed : (excise record i).length=1496:=by
    simp only [excise,List.length_append,List.length_take,List.length_drop,size]
    rw [Nat.min_eq_left (show i≤1509 by omega)]
    omega
  have need : 3≤rs.length:=by
    by_contra! few
    exact two_never i hi ⟨rs,z,ins,by omega,all⟩
  have len:=ins.length_eq
  omega

/-- A tag outside the union of the initial available wheels remains absent
under every finite sequence of literal wheel insertions. -/
theorem permanent {v c : Block} {rs z} (never : c∈absent v) (ins:Inserts v rs z) : c∉visited z := by
  obtain ⟨missingTag,nowheel⟩:=Finset.mem_sdiff.mp never
  intro occurs
  rw [ins.visited_eq] at occurs
  rcases Finset.mem_union.mp occurs with old|added
  · exact (Finset.mem_sdiff.mp missingTag).2 old
  · obtain ⟨W,hW,has⟩:=Finset.mem_biUnion.mp added
    apply nowheel
    apply Finset.mem_biUnion.mpr
    refine ⟨missing v∩W,?_,Finset.mem_inter.mpr ⟨missingTag,has⟩⟩
    rw [options_eq]
    exact Finset.mem_image_of_mem _ (ins.rows_ready hW)

private theorem decode_witness (b : Bool) (v c : Block)
    (h : (b && decide (c∈absent v))=true) : c∈absent v :=
  of_decide_eq_true (Bool.and_eq_true_iff.mp h).2

attribute [local irreducible] record witness excise absent sourcePositions visited

set_option maxRecDepth 16000 in
/-- A particular class is absent forever after the cut at zero-based offset 41. -/
theorem witness_permanent {rs : List Row} {z : Block} (ins:Inserts (excise record 41) rs z) : witness∉visited z :=
  @permanent (excise record 41) witness rs z
    (decode_witness (decide (41∈sourcePositions)) (excise record 41) witness witness_checked) ins

#print axioms two_never
#print axioms length_lower
#print axioms witness_permanent
end ExactWordFlow.AnchoredRepair

import ExtremeWheelCut
namespace ExactWordFlow.PriceAction
open SevenWordWindows ExtremeWheelCut

/-- A tag starting at 0 lists, at positions 0 through 6, the new names of
the symbols. Thus each of the 720 tags is one relabelling fixing 0. -/
def rename (g x : Block) := x.map (fun i=>g[i.val]?.getD 0)

private def reps : List Block := (List.finRange 6).permutations.map fun s=>0::s.map Fin.succ
private def key (x y : Block) : Bool := decide (x≤y)

private theorem sorted : reps.toFinset=allClasses ∧
    (∀x∈reps, ((reps.map (fun g=>rename g x)).mergeSort key)=reps.mergeSort key) ∧
    (∀g∈reps, ((reps.map (rename g)).mergeSort key)=reps.mergeSort key) := by native_decide

private theorem restore (f : Block→Block) (eq : (reps.map f).mergeSort key=reps.mergeSort key) :
    allClasses.image f=allClasses := by
  have p := (List.mergeSort_perm (reps.map f) key).symm
  rw [eq] at p
  have perm := p.trans (List.mergeSort_perm reps key)
  ext x
  rw [←sorted.1]
  simpa only [Finset.mem_image,List.mem_toFinset,List.mem_map] using (perm.mem_iff (a:=x))

theorem latin : (∀x∈allClasses,allClasses.image (fun g=>rename g x)=allClasses) ∧
    (∀g∈allClasses,allClasses.image (rename g)=allClasses) := by
  have valid {x} (hx : x∈allClasses) : x∈reps := List.mem_toFinset.mp (sorted.1.symm ▸ hx)
  exact ⟨fun x hx=>restore _ (sorted.2.1 x (valid hx)),fun g hg=>restore _ (sorted.2.2 g (valid hg))⟩

open private digits from ExtremeWheelCut
def attach := WheelContacts.wheel (digits "123456")
def five := attach.erase (digits "0123456")
private def row (g : Block) := attach.image (rename g)
private def rootTag (g : Block) := rename g (digits "0123456")
theorem geometry :
    allClasses.card=720 ∧ five⊆allClasses ∧ five.card=5 ∧
    ∀g∈allClasses,row g∈allRows ∧ rootTag g∈row g ∧
      five.image (rename g)=(row g).erase (rootTag g) := by native_decide

#print axioms latin
#print axioms geometry
end ExactWordFlow.PriceAction

import PrivateCompletionEdges
import Overlap

namespace ExactWordFlow.PrivateCompletionEdges
open SevenWordWindows ResidualDensity RotationCore CoreAssembly WheelBaseResidual

/-- The count includes only the seven rotations of classes completed in b. -/
def privatePerms (b : Block) : Finset Block :=
  (mandatory (complete b)).toFinset.filter fun e=>(bag b).count e=1

theorem private_count {b : Block} {m : Nat} (hyp : BaseEqualityDecision.candidate b m) :
    505+m+RauzyBudget.extraContexts b+RauzyBudget.wheels b+RauzyBudget.otherRank b+
      (5*m-(allClasses\visited b).card)≤(privatePerms b).card := by
  classical
  obtain ⟨_,done,len,least⟩:=hyp
  let B:=bag b
  let S:=mandatory (complete b)
  let bad:=S.toFinset.filter fun e=>¬B.count e=1
  have sub : S≤B:=mandatory_in_bag b
  have dup : required.Nodup:=Multiset.coe_nodup.mpr (List.nodup_permutations _ (List.nodup_finRange _))
  have sn : S.Nodup:=dup.filter _
  have bound : bad.val≤B-B.dedup:=by
    apply (Multiset.le_iff_subset bad.nodup).mpr
    intro e he
    obtain ⟨inS,more⟩:=Finset.mem_filter.mp (show e∈bad from he)
    have existsB:=Multiset.mem_of_le sub (Multiset.mem_toFinset.mp inS)
    apply Multiset.count_pos.mp
    rw [Multiset.count_sub,Multiset.count_dedup,ite_eq_left existsB]
    have positive:=Multiset.count_pos.mpr existsB
    omega
  have loss:=Multiset.card_le_card bound
  rw [Multiset.card_sub (Multiset.dedup_le _)] at loss
  change bad.card≤RauzyBudget.repeats b at loss
  have sizes:=Finset.card_filter_add_card_filter_not (s:=S.toFinset) (p:=fun e=>B.count e=1)
  change (privatePerms b).card+bad.card=S.toFinset.card at sizes
  have init:=(mandatory_data (complete b) (fun c hc=>((mem_complete b c).mp hc).1)).1
  change S.card=7*(complete b).card at init
  rw [done] at init
  have actual : S.toFinset.card=S.card:=by
    change S.dedup.card=S.card
    rw [Multiset.dedup_eq_self.mpr sn]
  have score:=WheelCoverCapacity.defect_split done len least.1
  unfold RauzyBudget.defect at score
  omega

#print axioms private_count
end ExactWordFlow.PrivateCompletionEdges

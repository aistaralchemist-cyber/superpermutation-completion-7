import FiveStepTest
import FiveExtensionCaps

namespace ExactWordFlow.ReferenceSpineOptimum
open SevenWordWindows SuperpermutationBounds ResidualDensity EmbeddedWheels FiveExtensionCaps OnePath66
open SuperpermLowerBounds.LengthBudget

/-- A word keeps the 463 occurrence spine and at least 65 full six-turns,
counting windows with multiplicity. Wheel choices, remaining windows,
the order of spelling, and the two endpoints are all free. -/
def KeepsSpine (w : Block) : Prop :=
  ∃ (ws : List Block) (other : Multiset Block), 65≤ws.length ∧
    (∀u∈ws,full u) ∧ bag w=required+((bag ResidualControls.mainWord+turns ws)+other)

private def wheelIds := ResidualControls.wheelWords.map (fun w => w.take 6)

private theorem data :
    ResidualControls.mainWord.length=469 ∧
    ResidualControls.mainWord.take 6 ≠ ResidualControls.mainWord.drop (ResidualControls.mainWord.length-6) ∧
    classCount (ResidualControls.mainWord.take 6) (windows ResidualControls.mainWord)=390 ∧
    (bag ResidualControls.mainWord).card=463 ∧ wheelIds.length=66 ∧ (∀u∈wheelIds, full u) ∧
    ResidualControls.edgeBag ResidualControls.mainWord=bag ResidualControls.mainWord+turns wheelIds := by
  native_decide

private theorem turn_count (ws : List Block) : (turns ws).card=6*ws.length := by
  induction ws with
  | nil => rfl
  | cons w ws ih =>
    change ((↑(GlobalWheelRank.wheel w) : Multiset Block)+turns ws).card=6*(ws.length+1)
    simp [ih,GlobalWheelRank.wheel,Nat.mul_add,Nat.add_comm]

theorem excludes_5904 {ws : List Block} {other : Multiset Block} {s t : Block}
    (many : 65≤ws.length) (legit : ∀u∈ws,full u)
    (budget : ((bag ResidualControls.mainWord+turns ws)+other).card≤858) :
    ¬ Feasible ((bag ResidualControls.mainWord+turns ws)+other) s t := by
  obtain ⟨len,ends,c,sz,_⟩ := data
  rw [Multiset.card_add,Multiset.card_add,sz,turn_count] at budget
  exact no_five_of_extension_cap _ (by omega) ends c reference_cap legit (by omega) (by omega) s t

/-- The actual optimum inside the entire stated class is 5905. -/
theorem restricted_minimum :
    (∃ w : Block, Covers w ∧ KeepsSpine w ∧ w.length=5905) ∧
    (∀ w : Block, Covers w → KeepsSpine w → 5905≤w.length) := by
  constructor
  · refine ⟨Word5905.word,Word5905.covers,?_,Word5905.length_5905⟩
    obtain ⟨_,_,_,_,n,leg,bagEq⟩ := data
    refine ⟨wheelIds,0,by omega,leg,?_⟩
    simpa only [add_zero,←bagEq] using ResidualControls.reference_counts.1
  · rintro w hw ⟨ws,other,n,leg,bagEq⟩
    obtain ⟨l,r,hlist⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
    have long := congrArg List.length hlist
    simp only [List.length_append,List.length_finRange] at long
    obtain ⟨X,eq,cost,yes⟩ := extract_windows_at_ends w hw (by omega)
    have same := add_left_cancel (eq.trans bagEq)
    subst X
    by_contra! small
    exact excludes_5904 n leg (by omega) yes

#print axioms excludes_5904
#print axioms restricted_minimum
end ExactWordFlow.ReferenceSpineOptimum

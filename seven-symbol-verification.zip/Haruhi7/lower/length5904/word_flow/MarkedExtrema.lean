import MarkedDensity

namespace ResidualDensity.WeightedMarks
open MarkedGeometry
open private prefixes initial start move memoryWord upper upper_step accepted upper_read from MarkedDensity
open private unmask from StrongerDensity

/-- Enumerate the maximizers of the finite upper bound, following only
transitions that spend precisely the optimal remaining budget. -/
private def optimal : Nat → Nat → List (List Bool)
  | 0,_ => [[]]
  | n+1,s =>
    [false,true].flatMap fun b =>
      let j:=move s b
      if j<prefixes.size ∧ b.toNat+upper n j=upper (n+1) s then
        (optimal n j).map (b::·)
      else []

private theorem maximizer (pre bs : List Bool) (s : Nat) (valid : s<prefixes.size)
    (small : bs.length≤283) (suff : memoryWord s <:+ pre)
    (safeWord : ∀x∈forbidden, ¬x <:+: pre++bs) (maximal : upper bs.length s≤bs.count true) :
    bs∈optimal bs.length s := by
  induction bs generalizing s pre with
  | nil => simp [optimal]
  | cons b bs ih =>
    obtain ⟨next,suffix,_⟩:=accepted s b pre bs valid suff safeWord
    have hsz : bs.length<283 := by simpa using small
    have sm : bs.length≤283 := by omega
    have good : ∀x∈forbidden, ¬x <:+: (pre++[b])++bs := by simpa using safeWord
    have tail := upper_read _ _ _ next sm suffix good
    have pay:=upper_step ⟨bs.length,hsz⟩ ⟨s,valid⟩ b next
    change b.toNat+upper bs.length (move s b)≤upper (bs.length+1) s at pay
    have cnt : (b::bs).count true=b.toNat+bs.count true := by cases b <;> simp [Nat.add_comm]
    simp only [List.length_cons,cnt] at maximal
    have win : b.toNat+upper bs.length (move s b)=upper (bs.length+1) s := by omega
    have child:=ih _ _ next sm suffix good (by omega)
    apply List.mem_flatMap.mpr
    refine ⟨b,by cases b <;> simp,?_⟩
    dsimp only
    rw [ite_eq_left ⟨next,win⟩]
    exact List.mem_map.mpr ⟨bs,child,rfl⟩

private def runs : List Bool → Nat → List Nat
  | [],k => [k]
  | true::bs,k => runs bs (k+1)
  | false::bs,k => k::runs bs 0

def extremeProfiles := (optimal 259 initial).map (fun w=>runs w 0)

private theorem maximum : upper 259 initial=220 := by native_decide

theorem profile_count : extremeProfiles.length=42 ∧ extremeProfiles.Nodup ∧
    extremeProfiles.all (fun ns=> ns.length==40 && ns.sum==220 &&
      ns.all (fun k=>decide (0<k ∧ k≤6)))=true := by native_decide

private theorem decode_ok : (optimal 259 initial).all (fun bs=>bs==rowsMask (runs bs 0))=true := by
  native_decide

/-- Every actual 259-position interval with 220 distinct marked classes has
one of exactly 42 positive, single-gap profiles. -/
theorem extreme_mask {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : ℕ) (many : 220≤count p i 259) : ∃ns∈extremeProfiles, mask p i 259=rowsMask ns := by
  let bs := mask p i 259
  have len : bs.length=259 := by simp [bs,mask]
  have maxed : upper bs.length initial ≤ bs.count true := by rw [len,maximum,mark_count]; exact many
  have hit:=maximizer [] bs initial start.1 (by omega) (by simp [start.2.1]) (by simpa [bs] using safe w m i 259) maxed
  rw [len] at hit
  exact ⟨runs bs 0,List.mem_map_of_mem hit,eq_of_beq (List.all_eq_true.mp decode_ok _ hit)⟩

theorem extreme_rows {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : ℕ) (many : 220≤count p i 259) : ∃ns∈extremeProfiles, rowsMarked p i ns := by
  obtain ⟨ns,member,eq⟩:=extreme_mask w m i many
  exact ⟨ns,member,unmask i 259 ns eq⟩

#print axioms extreme_rows
end ResidualDensity.WeightedMarks

import MarkedDensity
namespace ResidualDensity.ForcedRuns
open SevenWordWindows MarkedGeometry WeightedMarks DirectedEuler ExactWordFlow
open private prefixes memoryWord steps move initial start accepted from MarkedDensity

def six : List Bool := List.replicate 6 true
def twin : List Bool := six++[false]++six

/-- Substring occurrences, counted by their distinct ending positions. -/
def endings (pattern pre : List Bool) : List Bool → Nat
  | [] => 0
  | b::bs => (pattern.isSuffixOf (pre++[b])).toNat+endings pattern (pre++[b]) bs

private def memHit (pat : List Bool) (j : Nat) := (pat.isSuffixOf (memoryWord j)).toNat
private def charges (pat : List Bool) := prefixes.map fun w=>(pat.isSuffixOf w).toNat
private def potential (pat : List Bool) (q stepCost charge : Nat) (laps : Nat) :=
  let cs:=charges pat
  (List.range laps).foldl (fun v _ => steps.map fun (l,r) =>
    max ((v[l]?.getD 0)-(stepCost+charge*(cs[l]?.getD 0)))
      (if r<prefixes.size then q+v[r]?.getD 0-(stepCost+charge*(cs[r]?.getD 0)) else 0))
    (Array.replicate prefixes.size 0)

private def singleTable := potential six 1995 1644 380 110
private def pairTable := potential twin 6 5 1 16
private def singleCost (s : Nat):=singleTable[s]?.getD 0
private def pairCost (s : Nat):=pairTable[s]?.getD 0

private def Good (pat : List Bool) (q t c : Nat) (C : Nat→Nat) (s : Nat) (b : Bool) : Prop :=
   move s b<prefixes.size → q*b.toNat+C (move s b)≤t+c*memHit pat (move s b)+C s

private theorem singleSteps : singleCost initial=2124 ∧
    ∀s : Fin prefixes.size, ∀b : Bool, Good six 1995 1644 380 singleCost s.val b := by
  unfold Good
  native_decide

private theorem pairSteps : pairCost initial=6 ∧
    ∀s : Fin prefixes.size, ∀b : Bool, Good twin 6 5 1 pairCost s.val b := by
  unfold Good
  native_decide

private theorem trueHit (pat pre : List Bool) (b : Bool) (j : Nat)
    (suffix : memoryWord j <:+ pre++[b]) :
    memHit pat j≤(pat.isSuffixOf (pre++[b])).toNat := by
  unfold memHit
  cases e : pat.isSuffixOf (memoryWord j)
  · simp
  · have yes:=List.isSuffixOf_iff_suffix.mpr ((List.isSuffixOf_iff_suffix.mp e).trans suffix)
    simp [yes]

private theorem price (pat : List Bool) (q t c : Nat) (C : Nat→Nat)
    (data:∀s : Fin prefixes.size,∀b : Bool, Good pat q t c C s.val b)
    (pre bs : List Bool) (s : Nat) (ok : s<prefixes.size) (suffix : memoryWord s <:+ pre)
    (safeWord : ∀x∈forbidden, ¬x <:+: pre++bs) :
    q*bs.count true≤t*bs.length+c*endings pat pre bs+C s := by
  induction bs generalizing s pre with
  | nil => simp
  | cons b bs ih =>
    obtain ⟨inside,suff,_⟩:=accepted s b pre bs ok suffix safeWord
    have edge:=data ⟨s,ok⟩ b inside
    change q*b.toNat+C (move s b)≤t+c*memHit pat (move s b)+C s at edge
    have tHit:=Nat.mul_le_mul_left c (trueHit pat pre b (move s b) suff)
    have tail:=ih (pre++[b]) _ inside suff (by simpa using safeWord)
    have cnt : (b::bs).count true=b.toNat+bs.count true := by cases b <;> simp [Nat.add_comm]
    rw [cnt,List.length_cons,endings,Nat.mul_add,Nat.mul_add,Nat.mul_add,Nat.mul_one]
    omega

/-- Two simultaneous bounds on actual marked walks. The first counts a full
six-row, the second counts two full rows separated by exactly one hole. -/
theorem marks {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] (w : Walk u) (h : Marked u p)
    (i n : Nat) :
    1995*count p i n ≤1644*n+380*endings six [] (mask p i n)+2124 ∧
    6*count p i n ≤5*n+endings twin [] (mask p i n)+6 := by
  have s:=price six 1995 1644 380 singleCost singleSteps.2 [] (mask p i n) initial start.1
    (by simp [start.2.1]) (by simpa using safe w h i n)
  have d:=price twin 6 5 1 pairCost pairSteps.2 [] (mask p i n) initial start.1
    (by simp [start.2.1]) (by simpa using safe w h i n)
  rw [mark_count,singleSteps.1] at s
  rw [mark_count,pairSteps.1] at d
  simpa [mask] using And.intro s d

#print axioms marks
end ResidualDensity.ForcedRuns

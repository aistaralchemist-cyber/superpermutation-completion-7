import Cap35ActualShape

namespace ExactWordFlow.Cap35Rigidity
open ResidualDensity WheelContacts ExtremeWheelCut
open private shape_map board_map from Cap35Census
open private encode canonical from Interval66

private def Arow (s : Six) (i : Fin 5) := wheel (hop^[i.val] s)
private def Brow (s : Six) (i : Fin 5) := Arow (s.take 5++[missing s]) i

/-- The ten full supports are arranged into two sets of five. Two rows on
one side are disjoint. Across the two sides, corresponding rows intersect
twice and all other pairs intersect once. -/
def WheelPairs (T : Finset Six) (L U : Fin 5→Finset Six) : Prop :=
  (∀i,L i∈contained T ∧ U i∈contained T) ∧
  (∀i j,((L i)∩(L j)).card=if i=j then 6 else 0) ∧
  (∀i j,((U i)∩(U j)).card=if i=j then 6 else 0) ∧
  ∀i j,((L i)∩(U j)).card=if i=j then 2 else 1

private instance (T : Finset Six) (L U : Fin 5→Finset Six) : Decidable (WheelPairs T L U) := by
  unfold WheelPairs
  infer_instance

theorem two_sides (s : Six) (hs : full s) : ∃L U,WheelPairs (shape s) L U := by
  have norm : states.all (fun v=>decide (Function.Injective (encode v) ∧ encode v 0=0 ∧
      v.map (encode v)∈canonical))=true:=by native_decide
  obtain ⟨single,zero,can⟩:=of_decide_eq_true (List.all_eq_true.mp norm s (mem_states hs))
  have table : canonical.all (fun v=>decide (WheelPairs (shape v) (Arow v) (Brow v)))=true:=by native_decide
  let f:=encode s
  let g:=List.map f
  let v:=s.map f
  have gi:Function.Injective g:=List.map_injective_iff.mpr single
  obtain ⟨both,ll,uu,lu⟩:=of_decide_eq_true (List.all_eq_true.mp table v can)
  have pre (W : Finset Six) (hm : W∈contained (shape v)) : ∃Z∈contained (shape s),Z.image g=W:=by
    obtain ⟨board,inside⟩:=Finset.mem_filter.mp hm
    rw [←board_map f single zero] at board
    obtain ⟨Z,hZ,rfl⟩:=Finset.mem_image.mp board
    rw [show shape v=(shape s).image g from (shape_map f single zero s hs).symm] at inside
    exact ⟨Z,Finset.mem_filter.mpr ⟨hZ,(Finset.image_subset_image_iff gi).mp inside⟩,rfl⟩
  choose L lmem el using (fun i=>pre _ (both i).1)
  choose U umem eu using (fun i=>pre _ (both i).2)
  have inter (H K:Finset Six) : (H∩K).card=(H.image g∩K.image g).card := by
    rw [←Finset.image_inter _ _ gi,Finset.card_image_of_injective _ gi]
  exact ⟨L,U,fun i=>⟨lmem i,umem i⟩,
    fun i j=>by rw [inter,el,el,ll],
    fun i j=>by rw [inter,eu,eu,uu],
    fun i j=>by rw [inter,el,eu,lu]⟩

open ResidualIncidence ResidualRoutes
open scoped Classical in
theorem component_pairs {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {q : Component X} (away:q≠label X s) (size:(part X q).card=35)
    (num:(contacts (support X s) (label X) q).card=30) :
    ∃L U,WheelPairs (contacts (support X s) (label X) q) L U := by
  obtain ⟨z,hz,eq,_⟩:=actual_ten h away size num
  rw [eq]
  exact two_sides z hz

#print axioms component_pairs
end ExactWordFlow.Cap35Rigidity

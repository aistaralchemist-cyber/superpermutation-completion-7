import RouteDensity

/-! A simple open route realizing 390 distinct clean rotation classes in 462
supplementary edges. It is a partial route over the six symbols 0 through 5. -/
namespace Dense462
open ExactWordFlow SevenWordWindows ResidualDensity DirectedEuler

def word : Block := "032145032140532140352140325140321540312540315240315420315402314502314052314025314023514023415023410523410253410235410234510243510245310245130241530241350241305241302541302145302143502143052143025143021543012543015243015423014523014253014235014230514230415230412530412350412305412304512034512043512045312045132041532041352041325041320541320145320143520143250143205143201543210543120543102543105243105423104523104253104235104231504213504215304215034210534210354210345210".toList.map fun c => Fin.ofNat 7 (c.toNat-48)
def es := windows word
def first := word.take 6
def last := word.drop (word.length-6)
def vertices := first :: es.map dst

theorem realized : es.length=462 ∧ (vertices.Nodup) ∧ classCount first es=390 ∧
    (vertices.filter (fun v => decide (full v))).length=390 ∧ (6 : Fin 7) ∉ word ∧
    (∀ e∈es, e.length=7 ∧ ¬e.Nodup) ∧ Route src dst first es last := by
  have numbers : es.length=462 ∧ (vertices.Nodup) ∧ classCount first es=390 ∧
      (vertices.filter (fun v => decide (full v))).length=390 ∧ (6 : Fin 7) ∉ word ∧
      (es.all fun e => decide (e.length=7 ∧ ¬e.Nodup)) ∧ word.length=468 := by native_decide
  rcases numbers with ⟨n,nd,cc,clean,missing,width,len⟩
  exact ⟨n,nd,cc,clean,missing,fun e he => of_decide_eq_true (List.all_eq_true.mp width e he),
    read_route word (by omega)⟩

end Dense462
#print axioms Dense462.realized

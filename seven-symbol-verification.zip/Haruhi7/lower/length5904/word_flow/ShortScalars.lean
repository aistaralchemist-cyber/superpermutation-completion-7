import ShortMarked
set_option maxHeartbeats 550000
namespace ExactWordFlow.ShortScalars
open ResidualDensity
open private initial from MarkedDensity
@[irreducible] def openCap (a : Nat) := ShortMarked.upper (a+1) initial
def closedRank (b : Nat) :=
  if b=0 then 0 else
  min (min (56*b/66) (if b≥111 then 94*b/111 else 720))
    (if b≥137 then 116*b/137 else 720) - 1

private def good (a b : Nat) : Bool :=
  if b=0 ∨ 79≤b then
    let extra := if b=0 then 0 else 6
    let rank := 6*(openCap a-1)+6*closedRank b
    decide ((a+b≤471+extra → rank<5*(a+b)+39) ∧
      (a+b≤394+extra → rank<5*(a+b)+34) ∧
      (a+b≤323+extra → rank<5*(a+b)+29))
  else true

private theorem table : ((List.range 478).all (fun a=>(List.range 478).all (good a)))=true := by
  native_decide

/-- The two arguments are aggregate lengths, with the second zero exactly
when there is no long closed component. -/
theorem scalar : ∀ a b : Fin 478, b.val=0 ∨ 79≤b.val →
    let extra := if b.val=0 then 0 else 6
    let rank := 6*(openCap a.val-1)+6*closedRank b.val
    (a.val+b.val≤471+extra → rank<5*(a.val+b.val)+39) ∧
    (a.val+b.val≤394+extra → rank<5*(a.val+b.val)+34) ∧
    (a.val+b.val≤323+extra → rank<5*(a.val+b.val)+29) := by
  intro a b ok
  have checked:=List.all_eq_true.mp (List.all_eq_true.mp table a.val (List.mem_range.mpr a.isLt)) b.val
    (List.mem_range.mpr b.isLt)
  unfold good at checked
  rw [ite_eq_left ok] at checked
  exact of_decide_eq_true checked

#print axioms scalar
end ExactWordFlow.ShortScalars

import WordFlow
import LowerBounds.TheoremA

namespace ExactWordFlow.SixProjection
open SevenWordWindows DirectedEuler SuperpermutationBounds

abbrev SixWord := List (Fin 6)

/-- Two words can be joined by appending exactly c letters to the first. -/
def Join (u v : SixWord) (c : Nat) : Prop :=
  ∃ a b : SixWord, a.length=c ∧ u++a=b++v

private theorem spell {f : Block → SixWord} {price : Block → Nat} {s t : Block} {es : List Block}
    (r : Route src dst s es t)
    (links : ∀e∈es, Join (f (src e)) (f (dst e)) (price e)) :
    ∃ tail : SixWord, tail.length=(es.map price).sum ∧
      ∀e∈es, f (src e) <:+: f s++tail := by
  induction r with
  | nil => exact ⟨[],rfl,by simp⟩
  | cons e hs trail ih =>
    obtain ⟨z,lz,all⟩ := ih (fun x hx => links x (List.mem_cons_of_mem _ hx))
    obtain ⟨a,b,la,eq⟩ := links e List.mem_cons_self
    rw [hs] at eq
    refine ⟨a++z,by simp [la,lz],?_⟩
    intro k hk
    rcases List.mem_cons.mp hk with rfl|rest
    · rw [hs]; exact (List.prefix_append ..).isInfix
    · obtain ⟨u,v,h⟩ := all k rest
      refine ⟨b++u,v,?_⟩
      rw [←List.append_assoc,eq]
      simpa only [List.append_assoc] using congrArg (b++·) h

private def perms6 := (List.finRange 6).permutations

private theorem perm_mem {p : SixWord} (len : p.length=6) (nd : p.Nodup) : p∈perms6 := by
  have hu : p.toFinset=Finset.univ := Finset.eq_univ_of_card p.toFinset
    (by rw [List.toFinset_card_of_nodup nd,len,Fintype.card_fin])
  apply List.mem_permutations.mpr
  apply (List.perm_ext_iff_of_nodup nd (List.nodup_finRange _)).mpr
  intro z
  exact ⟨fun _ => List.mem_finRange _,fun _ => List.mem_toFinset.mp (hu ▸ Finset.mem_univ z)⟩

/-- Any labelling of the rotation classes onto six-permutations yields a lower
bound for the total cost of joining the images of the residual edges. -/
theorem price_floor {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (f : Block → SixWord) (price : Block → Nat) (width : (f s).length=6)
    (onto : ∀p∈perms6, ∃e∈required, f (src e)=p)
    (free : ∀e∈required, price e=0)
    (join : ∀e∈required+X, Join (f (src e)) (f (dst e)) (price e)) :
    864 ≤ (X.map price).sum := by
  have rb : required.map src=required.map dst := balanced_representatives
  have bal : (required+X).map src+{t}=(required+X).map dst+{s} := by
    rw [Multiset.map_add,Multiset.map_add,rb,add_assoc,add_assoc,h.balance]
  obtain ⟨es,eq,r⟩ := exists_route src dst (required+X) s t bal h.reachable
  have mem (e) : e∈es ↔ e∈required+X := by
    change e∈(↑es : Multiset Block) ↔ _; rw [eq]
  obtain ⟨u,lu,cu⟩ := spell r (fun e he => join e ((mem e).mp he))
  have cv : Covers (f s++u) := by
    intro p lp nd
    obtain ⟨e,he,fe⟩ := onto p (perm_mem lp nd)
    obtain ⟨a,b,eq⟩ := cu e ((mem e).mpr (Multiset.mem_add.mpr (Or.inl he)))
    exact ⟨a,b,by rw [←fe]; exact eq.symm⟩
  have low := SuperpermLowerBounds.superperm_kisic_numerical_bounds.2.1.trans
    (SuperpermBridge.ssuper_le_length cv)
  have z : (required.map price).sum=0 := by
    have eq : required.map price = required.map (fun _ => (0 : Nat)) :=
      Multiset.map_congr rfl free
    rw [eq]; simp
  have cost := congrArg (fun Y : Multiset Block => (Y.map price).sum) eq
  simp only [Multiset.map_coe,Multiset.sum_coe,Multiset.map_add,Multiset.sum_add,z,zero_add] at cost
  simp only [List.length_append,width,lu,cost] at low
  omega

/-- The deleted symbol is exchanged with 6 before reading labels in Fin 6. -/
private def recode (g a : Fin 7) : Fin 6 :=
  Fin.ofNat 6 (if a=6 then g.val else a.val)

def project (g : Fin 7) (v : Block) : SixWord :=
  if g∈v ∧ v.Nodup then
    let p := v ++ (List.finRange 7).filter (fun a => a∉v)
    ((p.rotate (p.idxOf g+1)).take 6).map (recode g)
  else v.map (recode g)

private theorem table (g : Fin 7) :
    (∀e∈representatives, project g (src e)=project g (dst e)) ∧
    perms6.toFinset ⊆ (representatives.map (fun e => project g (src e))).toFinset := by
  have tab : ∀g : Fin 7,
      (∀e∈representatives, project g (src e)=project g (dst e)) ∧
      perms6.toFinset ⊆ (representatives.map (fun e => project g (src e))).toFinset := by native_decide
  exact tab g

private theorem width (g) {v : Block} (hv : v.length=6) : (project g v).length=6 := by
  unfold project
  split <;> simp [hv]

def price (g : Fin 7) (e : Block) := if e.Nodup then 0 else if g∈e then 6 else 1

private theorem join_edge (g : Fin 7) {e : Block} (le : e.length=7) :
    Join (project g (src e)) (project g (dst e)) (price g e) := by
  by_cases nd : e.Nodup
  · have same := (table g).1 e ((mem_reps _).mpr ⟨le,nd⟩)
    exact ⟨[],[],by simp [price,nd],by simp [same]⟩
  by_cases hm : g∈e
  · exact ⟨project g (dst e),project g (src e),by
        rw [width g (by simp [dst,le])]; simp [price,nd,hm],rfl⟩
  · cases e with
    | nil => simp at le
    | cons a v =>
      have len : v.length=6 := by simp at le; omega
      have last : v ≠ [] := by intro n; simp [n] at len
      have h₁ : g∉src (a::v) := fun h => hm (List.mem_of_mem_take h)
      have h₂ : g∉dst (a::v) := fun h => hm (List.mem_cons_of_mem _ h)
      refine ⟨[recode g (v.getLast last)],[recode g a],by simp [price,nd,hm],?_⟩
      simp only [project,h₁,h₂,false_and,ite_false]
      have five : v.take 5 = v.dropLast := by simp [List.dropLast_eq_take,len]
      change (a::v.take 5).map (recode g) ++ _ = _ ++ v.map (recode g)
      rw [five]
      have eq := congrArg (List.map (recode g)) (List.dropLast_append_getLast last)
      simpa using congrArg (recode g a :: ·) eq

def bad (X : Multiset Block) := X.filter (fun e => ¬e.Nodup)
def carrying (X : Multiset Block) (g : Fin 7) := (bad X).filter (fun e => g∈e)

private theorem sum_price (X : Multiset Block) (g : Fin 7) :
    (X.map (price g)).sum = (bad X).card+5*(carrying X g).card := by
  induction X using Multiset.induction_on with
  | empty => simp [bad,carrying]
  | cons e X ih =>
    by_cases nd : e.Nodup <;> by_cases hm : g∈e <;>
      simp [price,nd,hm,bad,carrying,Multiset.sum_cons] at ih ⊢ <;> omega

/-- Each symbol needs enough nonpermutation supplementary windows containing it;
duplicates of prescribed permutations are harmless under the projection. -/
theorem all_symbols_floor {X : Multiset Block} {s t : Block} (h : Feasible X s t) (g : Fin 7) :
    864 ≤ (bad X).card + 5*(carrying X g).card := by
  rw [←sum_price]
  apply price_floor h (project g) (price g) (width g h.start_six)
  · intro p hp
    have m := (table g).2 (List.mem_toFinset.mpr hp)
    exact List.mem_map.mp (List.mem_toFinset.mp m)
  · intro e he
    have nd := ((mem_reps e).mp (show e∈representatives from he)).2
    simp [price,nd]
  · intro e he
    rcases Multiset.mem_add.mp he with req|ext
    · exact join_edge _ ((mem_reps e).mp (show e∈representatives from req)).1
    · exact join_edge _ (h.edges_seven _ ext)

theorem twice_for_every_symbol {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (g : Fin 7) : 2≤(carrying X g).card := by
  have bound := all_symbols_floor h g
  have sub : (bad X).card≤X.card := Multiset.card_le_card (Multiset.filter_le ..)
  omega

#print axioms price_floor
#print axioms twice_for_every_symbol
end ExactWordFlow.SixProjection

import PrivateWindowCount
import TightControl

namespace ExactWordFlow.PrivateCompletionEdges
/-- The 1509 control uses a single occurrence of each of its 644 completed
permutations. This global uniqueness condition holds at the known boundary. -/
theorem near_control : (privatePerms StrippedControl.base).card=644 := by native_decide

#print axioms near_control
end ExactWordFlow.PrivateCompletionEdges

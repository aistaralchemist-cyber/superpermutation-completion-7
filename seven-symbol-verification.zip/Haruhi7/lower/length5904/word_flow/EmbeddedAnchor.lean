import EmbeddedContactRows
import PartitionLoss

namespace ContactSquares
open ExactWordFlow.ResidualIncidence
variable {ι α : Type*} [DecidableEq ι] [DecidableEq α]

/-- Rank lost when rows meeting A are contracted onto A. -/
def anchorCost (A : Finset α) (B : Finset ι) (C : ι → Finset α) : Nat :=
  (∑i∈B,((C i ∩ A).card-1)) +
  ((∑i∈B,(C i \ A).card)-((B.biUnion C) \ A).card)

/-- Contracting any subfamily of rows preserves every cut required by
connectivity. Its full cardinality loss can be charged to the original board. -/
theorem indexed_subfamily_cost (Q : Finset ι) (V : Finset α) (C : ι → Finset α)
    (ne : V.Nonempty) (connected : Connected Q V C) (T : Finset ι)
    (sub : T⊆Q) {a : ι} (hit : a∈T) (loss : Nat)
    (price : (T.biUnion C).card-1+loss ≤ ∑i∈T, ((C i).card-1)) :
    V.card-1+loss ≤ ∑i∈Q,((C i).card-1) := by
  classical
  let D (i : ι) := if i=a then T.biUnion C else C i
  let P := Q \ T
  have out : a∉P := fun h => (Finset.mem_sdiff.mp h).2 hit
  have cv : Connected (insert a P) V D := by
    intro S rows
    apply connected S
    intro i hi x hx y hy
    by_cases within : i∈T
    · have both (v) (hv : v∈C i) : v∈D a := by
        simpa [D] using (Finset.mem_biUnion.mpr ⟨i,within,hv⟩ : v∈T.biUnion C)
      exact rows a (Finset.mem_insert_self ..) x (both x hx) y (both y hy)
    · have neq : i≠a := fun eq => within (eq ▸ hit)
      have old := rows i (Finset.mem_insert_of_mem (Finset.mem_sdiff.mpr ⟨hi,within⟩))
      exact old x (by simpa [D,neq] using hx) y (by simpa [D,neq] using hy)
  have base := connected_rank _ _ _ ne cv
  rw [Finset.sum_insert out] at base
  have same : (∑i∈P,((D i).card-1)) = ∑i∈P,((C i).card-1) := by
    apply Finset.sum_congr rfl
    intro i hi
    have ni : i≠a := fun eq => out (eq ▸ hi)
    simp [D,ni]
  simp only [same,D,ite_true] at base
  have split := Finset.sum_sdiff sub (f:=fun i => (C i).card-1)
  change (∑i∈P,((C i).card-1)) + _ = _ at split
  omega

theorem indexed_anchor_cost (Q : Finset ι) (V : Finset α) (C : ι → Finset α)
    (ne : V.Nonempty) (connected : Connected Q V C) (a : ι) (B : Finset ι)
    (ha : a∈Q) (other : a∉B) (sub : B⊆Q) (nonempty : (C a).Nonempty)
    (meet : ∀i∈B, (C i ∩ C a).Nonempty) :
    V.card-1+anchorCost (C a) B C ≤ ∑i∈Q,((C i).card-1) := by
  apply indexed_subfamily_cost Q V C ne connected (insert a B) (Finset.insert_subset ha sub)
    (Finset.mem_insert_self ..)
  rw [Finset.biUnion_insert,Finset.sum_insert other]
  simpa only [anchorCost,Nat.add_assoc] using (anchor_account (C a) B C nonempty meet).le

end ContactSquares

namespace ExactWordFlow.EmbeddedWheels
open SevenWordWindows ResidualDensity ResidualIncidence ResidualRoutes ContactSquares
open scoped Classical

/-- A chosen subfamily of distinct extracted wheels meeting any one residual
component is charged fully for extra contacts there and for their repeated
classes elsewhere. Repeated copies of turns carry their separate charge. -/
theorem embedded_anchor_budget {Y : Multiset Block} {s t : Block} (ws : List Block)
    (canonical : ∀w∈ws, w∈WheelContacts.bases) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (i : Component Y) (owner : i∈liveGroups Y s)
    (B : Finset Block) (sub : B⊆ws.toFinset)
    (nonempty : (contacts (support Y s) (label Y) i).Nonempty)
    (meet : ∀w∈B, (WheelContacts.wheel w ∩ contacts (support Y s) (label Y) i).Nonempty) :
    ws.length + 10*(anchorCost (contacts (support Y s) (label Y) i) B WheelContacts.wheel +
      5*(ws.length-ws.toFinset.card)+(largeOther Y s).card) ≤ 112 := by
  classical
  let ins : Block ↪ (Component Y ⊕ Block) := Function.Embedding.inr
  let a : (Component Y ⊕ Block) := Sum.inl i
  let M := B.map ins
  let R := boardRow Y s
  have member : a∈boardIds Y s ws := Finset.inl_mem_disjSum.mpr owner
  have other : a∉M := by simp [a,M,ins]
  have incl : M⊆boardIds Y s ws := by
    intro u hu
    obtain ⟨w,hw,rfl⟩ := Finset.mem_map.mp hu
    exact inr_mem_board (List.mem_toFinset.mp (sub hw))
  have allMeet : ∀u∈M,(R u ∩ R a).Nonempty := by
    intro u hu
    obtain ⟨w,hw,rfl⟩ := Finset.mem_map.mp hu
    exact meet _ hw
  have population : allClasses.card=720 := by native_decide
  have ne := Finset.card_pos.mp (show 0<allClasses.card by omega)
  have cap := indexed_anchor_cost _ _ R ne (board_connected ws canonical h) a M member other incl nonempty allMeet
  have same : anchorCost (R a) M R = anchorCost (contacts (support Y s) (label Y) i) B WheelContacts.wheel := by
    have joined : M.biUnion R=B.biUnion WheelContacts.wheel := by
      ext x
      simp [M,Finset.mem_biUnion,ins,R,boardRow]
    simp [anchorCost,M,Finset.sum_map, a,R,boardRow,ins] at joined ⊢
    rw [joined]
  rw [same,population] at cap
  change _ ≤ ∑u∈boardIds Y s ws, ((boardRow Y s u).card-1) at cap
  rw [board_weight_distinct ws canonical] at cap
  have fulls (w) (hw : w∈ws) : full w := by
    have table : ∀z∈WheelContacts.bases, full z := by native_decide
    exact table w (canonical w hw)
  have count := List.toFinset_card_le ws
  exact (turns_with_loss ws fulls h budget _ (by omega)).2

/-- Applied to 66 extracted turns, a selected subfamily meeting the chosen
residual row may spend at most four units on both kinds of collision together. -/
theorem anchor_cost_at_most_four {Y : Multiset Block} {s t : Block} (ws : List Block)
    (canonical : ∀w∈ws, w∈WheelContacts.bases) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (many : 66≤ws.length)
    (i : Component Y) (owner : i∈liveGroups Y s) (B : Finset Block) (sub : B⊆ws.toFinset)
    (nonempty : (contacts (support Y s) (label Y) i).Nonempty)
    (meet : ∀w∈B, (WheelContacts.wheel w ∩ contacts (support Y s) (label Y) i).Nonempty) :
    anchorCost (contacts (support Y s) (label Y) i) B WheelContacts.wheel ≤ 4 := by
  have := embedded_anchor_budget ws canonical h budget i owner B sub nonempty meet
  omega

end ExactWordFlow.EmbeddedWheels
#print axioms ExactWordFlow.EmbeddedWheels.embedded_anchor_budget

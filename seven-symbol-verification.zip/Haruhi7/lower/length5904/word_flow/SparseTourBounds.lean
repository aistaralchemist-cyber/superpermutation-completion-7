import OpenWheelPacking
import NamedClosedCover
import SparseSeedPacking

namespace ExactWordFlow.SparseTourBounds
open Equiv SeedWheelCut ExtremeWheelCut SevenWordWindows OpenWheelPacking
open SparseSeedPacking
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

private theorem geometry : allClasses.card=720 ∧ ∀w∈allRows,w⊆allClasses ∧ w.card≤6 :=
  by native_decide

/-- Obtain the cost/packing obstruction directly on a single actual successor
orbit. P is an arbitrary subset of the exceptional tags. No limit is placed
on the number of exceptional cycles or the genus. -/
theorem from_successor {R h : Perm X} (start : X) (orbit : ∀y,(R*h).SameCycle start y)
    (tag : X → Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (name : Y ↪ Block) (board : Finset.univ.map name=allClasses)
    (E : Finset (Perm X)) (sub : E⊆h.cycleFactorsFinset) (present : E.Nonempty)
    (legal : ∀c∈h.cycleFactorsFinset \ E,(c.support.image tag).map name∈allRows)
    {P : Finset Block} (seed : P⊆(E.biUnion (fun c=>c.support.image tag)).map name)
    {s L : Nat} (short : L≤5904) (length :
      L=5045+(∑c∈E,c.support.card)+s+6*(h.cycleFactorsFinset \ E).card) :
    let A:=(E.biUnion (fun c=>c.support.image tag)).map name
    let M:=∑c∈E,c.support.card
    ∃ T : Finset (Finset Block),
      (∀t∈T,Packet allRows t ∧ t⊆allClasses \ P) ∧
      (∀t∈T,∀u∈T,t≠u → Disjoint t u) ∧
      442+2*s+3*(M-A.card)+2*(5904-L) ≤ M+3*T.card := by
  classical
  let tags (c : Perm X):=c.support.image tag
  let A:=(E.biUnion tags).map name
  let W:=((h.cycleFactorsFinset \ E).image tags).image (fun w=>w.map name)
  have closed : ClosedCover A allClasses W := by
    rw [← board]
    exact MultipleRootContacts.named_closed_cover name
      (TourWheelPrice.from_order start orbit tag onto rot E sub present)
  have inside : A⊆allClasses := by
    rw [←board]
    exact Finset.map_subset_map.mpr (Finset.subset_univ _)
  have rows : W⊆allRows := by
    intro w hw
    obtain ⟨b,hb,rfl⟩:=Finset.mem_image.mp hw
    obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp hb
    exact legal c hc
  obtain ⟨T,pack,apart,cap⟩:=extract W inside rows (fun w hw=>geometry.2 _ (rows hw)) closed
  have m : A.card≤∑c∈E,c.support.card := by
    rw [show A.card=(E.biUnion tags).card from Finset.card_map ..]
    exact Finset.card_biUnion_le.trans (Finset.sum_le_sum (fun _ _=> Finset.card_image_le))
  have n : W.card≤(h.cycleFactorsFinset \ E).card:= Finset.card_image_le.trans Finset.card_image_le
  refine ⟨T,?_,apart,word_cut m n (geometry.1 ▸ cap) length short⟩
  intro t ht
  refine ⟨(pack _ ht).1,?_⟩
  intro v hv
  obtain ⟨on,off⟩:=Finset.mem_sdiff.mp ((pack _ ht).2 hv)
  exact Finset.mem_sdiff.mpr ⟨on,fun old=>off (seed old)⟩

/-- Both integer certificates also bound arbitrary nonsaturated covers.
The second term counts all selected wheels, including wasteful ones. -/
theorem sparse_cuts {A : Finset Block} {W : Finset (Finset Block)} (board : A⊆allClasses)
    (legal : W⊆allRows) (link : ClosedCover A allClasses W) :
    (FixedSeed390Price.seed⊆A → 655 ≤ A.card+4*W.card) ∧
    (FixedSeed250Price.seed⊆A → 627 ≤ A.card+4*W.card) := by
  have rows:=fun w (hw : w∈W)=>geometry.2 w (legal hw)
  constructor
  · intro seed
    have cut:=capacity seed board legal rows link FixedSeed390Price.weight 624 65
      FixedSeed390Price.certificate.2.2 (by rw [FixedSeed390Price.certificate.2.1]; decide)
    rw [geometry.1] at cut
    omega
  · intro seed
    have cut:=capacity seed board legal rows link FixedSeed250Price.weight 2535 93
      FixedSeed250Price.certificate.2.2 (by rw [FixedSeed250Price.certificate.2.1]; decide)
    rw [geometry.1] at cut
    omega

/-- There is no prior bound on M, s, q, the root size, or the genus.
A short realization containing one of the seeds must obey its mass floor. -/
theorem mass_floors {A : Finset Block} {W : Finset (Finset Block)} (board : A⊆allClasses)
    (legal : W⊆allRows) (link : ClosedCover A allClasses W) {M s q L : Nat}
    (mass : A.card≤M) (count : W.card≤q) (length : L=5045+M+s+6*q) (short : L≤5904) :
    (FixedSeed390Price.seed⊆A → 247+2*s+3*(M-A.card)+2*(5904-L) ≤ M) ∧
    (FixedSeed250Price.seed⊆A → 163+2*s+3*(M-A.card)+2*(5904-L) ≤ M) := by
  have cuts:=sparse_cuts board legal link
  constructor
  · intro seed
    have w:=word_cut (r:=65) mass count (by have h:=cuts.1 seed; omega) length short
    omega
  · intro seed
    have w:=word_cut (r:=93) mass count (by have h:=cuts.2 seed; omega) length short
    omega

#print axioms from_successor
#print axioms sparse_cuts
#print axioms mass_floors
end ExactWordFlow.SparseTourBounds

import RotationReinsert
import RotationClassesRequired

namespace ExactWordFlow.PacketSpelling
open SevenWordWindows SuperpermutationBounds ResidualRoutes
open private rotate_label from RotationClassesRequired
open private required_balanced from WordFlow

/-- Each component carrying a mandatory permutation spells exactly one copy
of each of its remaining windows, including multiplicities. A component
away from the endpoints may begin with any of the seven letters. -/
theorem piece {A : Multiset Block} {s t p : Block} (start : s.length=6)
    (width : ∀e∈A,e.length=7) (balance : A.map src+{t}=A.map dst+{s})
    (mandatory : p∈required) (letter : Fin 7) :
    ∃w : Block, w.length=(part (required+A) (label (required+A) (src p))).card+6 ∧
      (↑(windows w) : Multiset Block)=part (required+A) (label (required+A) (src p)) ∧
      (label (required+A) (src p)≠label (required+A) s → w.head?=some letter) := by
  have perm : p.Perm (List.finRange 7) := List.mem_permutations.mp mandatory
  have inside : letter∈p := perm.mem_iff.mpr (List.mem_finRange _)
  obtain ⟨left,right,split⟩:=List.append_of_mem inside
  let v:=src (p.rotate left.length)
  have rotated : p.rotate left.length=(letter::right)++left := by
    rw [split,List.rotate_append_length_eq]
  have letterAt : v.head?=some letter := by simp [v,src,rotated]
  have six : v.length=6 := by simp [v,src,((mem_reps p).mp mandatory).1]
  have whereV : label (required+A) v=label (required+A) (src p) :=
    (rotate_label A mandatory left.length).symm
  have bal : (required+A).map src+{t}=(required+A).map dst+{s} := by
    simp only [Multiset.map_add,add_assoc,required_balanced,balance]
  obtain ⟨a,b,es,edges,path,_,same,other⟩:=component_route bal v
  have aSix : a.length=6 := by
    by_cases eq : label (required+A) v=label (required+A) s
    · rw [(same eq).1,start]
    · rw [(other eq).1,six]
  obtain ⟨w,length,first,win⟩:=RotationReinsert.spell_route path aSix (by
    intro e he
    have hit : e∈part (required+A) (label (required+A) v) := edges ▸ (show e∈(↑es : Multiset Block) from he)
    rcases Multiset.mem_add.mp (in_part.mp hit).1 with full|extra
    · exact ((mem_reps e).mp full).1
    · exact width e extra)
  rw [whereV] at edges
  refine ⟨w,?_,win ▸ edges,?_⟩
  · rw [←edges,Multiset.coe_card,length]
  · intro away
    have actual:=first.trans (other (whereV ▸ away)).1
    have firstLetter := (congrArg List.head? actual).trans letterAt
    cases w <;> exact firstLetter

#print axioms piece
end ExactWordFlow.PacketSpelling

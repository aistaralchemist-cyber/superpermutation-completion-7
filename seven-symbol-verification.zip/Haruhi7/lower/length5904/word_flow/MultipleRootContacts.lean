import GenusContacts

namespace ExactWordFlow.MultipleRootContacts
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- Any incidence family whose closures still propagate all original
correction cycles must pay the global connectivity rank. -/
theorem closure_rank {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat}
    (genus : h.support.card=h.cycleType.card+719+2*g)
    (keep : Perm X → Finset Y)
    (inside : ∀c∈h.cycleFactorsFinset,keep c ⊆ c.support.image tag)
    (present : ∀c∈h.cycleFactorsFinset,(keep c).Nonempty)
    (repair : ∀Z : Finset Y,
      (∀c∈h.cycleFactorsFinset, (Z∩keep c).Nonempty → keep c⊆Z) →
      ∀c∈h.cycleFactorsFinset,∀j∈c.support.image tag,j∈Z → c.support.image tag⊆Z) :
    (∑c∈h.cycleFactorsFinset,(c.support.card-(keep c).card))≤2*g := by
  classical
  let H:=h.cycleFactorsFinset
  obtain ⟨Z,base,bound,closed⟩:=GlobalWheelRank.grow {tag start} (H.image keep)
  have spread:=repair Z (fun c hc=>closed _ (Finset.mem_image_of_mem _ hc))
  have step (x : X) (seen : tag x∈Z) : tag ((R*h) x)∈Z := by
    rw [Perm.mul_apply,rot]
    by_cases fix : h x=x
    · simpa [fix] using seen
    · have moved:=Perm.mem_support.mpr fix
      have group : h.cycleOf x∈H:=Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr moved
      have contains (y) (hxy : h.SameCycle x y) : tag y∈(h.cycleOf x).support.image tag :=
        Finset.mem_image_of_mem _ (Perm.mem_support_cycleOf_iff.mpr ⟨hxy,moved⟩)
      exact spread _ group _ (contains x (.refl _ _)) seen
        (contains _ (Perm.sameCycle_apply_right.mpr (.refl _ _)))
  have walk : ∀n : Nat,tag (((R*h)^n) start)∈Z := by
    intro n
    induction n with
    | zero => simpa using base (Finset.mem_singleton_self _)
    | succ n ih => simpa [pow_succ',Perm.mul_apply] using step _ ih
  have eq : Z=Finset.univ := by
    apply Finset.eq_univ_of_forall
    intro j
    obtain ⟨y,rfl⟩:=onto j
    obtain ⟨n,_,_,eq⟩:=(oneOrbit y).exists_pow_eq _
    exact eq ▸ walk n
  have charge : (∑u∈H.image keep,(u.card-1)) ≤ ∑c∈H,((keep c).card-1) :=
    Finset.sum_image_le_of_nonneg (fun _ _=>Nat.zero_le _)
  have cost : (∑c∈H, (c.support.card-(keep c).card))+(∑c∈H,((keep c).card-1))+H.card=
      h.support.card := by
    have e : (∑c∈H, (c.support.card-(keep c).card+((keep c).card-1)+1))=∑c∈H,c.support.card := by
      apply Finset.sum_congr rfl
      intro c hc
      have leq:=(Finset.card_le_card (inside c hc)).trans Finset.card_image_le
      have pos:=Finset.card_pos.mpr (present c hc)
      omega
    simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] at e
    exact e.trans h.sum_cycleType
  have pieces : h.cycleType.card=H.card := by simp [H,Perm.cycleType_def]
  simp only [eq,Finset.card_univ,Finset.card_singleton,classes] at bound
  change (∑c∈H,(c.support.card-(keep c).card))≤2*g
  omega

/-- Remove contacts from the actual correction cycles. A removed tag can
be reached through any retained donor cycle sharing another retained tag
with the original cycle. Donors need not agree between removals. -/
theorem rerouted_contacts {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat}
    (genus : h.support.card=h.cycleType.card+719+2*g)
    (keep : Perm X → Finset Y)
    (inside : ∀c∈h.cycleFactorsFinset,keep c ⊆ c.support.image tag)
    (present : ∀c∈h.cycleFactorsFinset,(keep c).Nonempty)
    (detour : ∀c∈h.cycleFactorsFinset,∀j∈c.support.image tag,j∉keep c →
      ∃d∈h.cycleFactorsFinset,j∈keep d ∧ (keep c ∩ keep d).Nonempty) :
    (∑c∈h.cycleFactorsFinset,(c.support.card-(keep c).card))≤2*g := by
  classical
  apply closure_rank start oneOrbit tag onto rot classes genus keep inside present
  intro Z closed
  let H:=h.cycleFactorsFinset
  have take (c : Perm X) (hc : c∈H) {j : Y} (hj : j∈keep c) (seen : j∈Z) : keep c⊆Z :=
    closed c hc ⟨j,Finset.mem_inter.mpr ⟨seen,hj⟩⟩
  have spread (c : Perm X) (hc : c∈H) (j : Y) (hj : j∈c.support.image tag) (seen : j∈Z) :
      c.support.image tag ⊆ Z := by
    have mid : keep c⊆Z := by
      by_cases retained : j∈keep c
      · exact take c hc retained seen
      obtain ⟨d,hd,jd,k,hk⟩:=detour c hc j hj retained
      have both:=Finset.mem_inter.mp hk
      exact take c hc both.1 (take d hd jd seen both.2)
    intro k hk
    by_cases retained : k∈keep c
    · exact mid retained
    obtain ⟨d,hd,kd,v,hv⟩:=detour c hc k hk retained
    have both:=Finset.mem_inter.mp hv
    exact take d hd both.2 (mid both.1) kd
  exact spread

#print axioms closure_rank
#print axioms rerouted_contacts
end ExactWordFlow.MultipleRootContacts

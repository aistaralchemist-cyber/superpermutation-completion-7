import SevenTourGenus
import SevenOverlap
import HitColor

set_option maxRecDepth 12000

namespace ExactWordFlow.AnonymousSeven
open Equiv SevenMoves AnonymousRows

/-- Count every correction cycle with some departure from its six-cycle.
The closing transition is measured separately, so there is no exception
forced merely because a pure wheel contains the cut. -/
noncomputable def exceptions (h : Perm X) : Finset (Perm X) := by
  classical
  exact h.cycleFactorsFinset.filter (fun c=>∃x∈c.support,h x≠turn x)
noncomputable def length (h : Perm X) (last : X) := 7+∑x∈Finset.univ.erase last,d x (h x)

theorem ordinary {h c : Perm X} (hc : c∈h.cycleFactorsFinset \ exceptions h) :
    ∀x∈c.support,h x=turn x := by
  classical
  intro x hx
  by_contra bad
  exact (Finset.mem_sdiff.mp hc).2 (Finset.mem_filter.mpr ⟨(Finset.mem_sdiff.mp hc).1,x,hx,bad⟩)

theorem ordinary_six {h c : Perm X} (hc : c∈h.cycleFactorsFinset \ exceptions h) :
    c.support.card=6 := pure_card_six h c (Finset.mem_sdiff.mp hc).1 (ordinary hc)

theorem pure_floor (h : Perm X) (start last : X) (tour : ∀y,(R*h).SameCycle start y)
    (empty : exceptions h=∅) : 5915≤length h last := by
  classical
  obtain ⟨g,eqg⟩:=SevenTourGenus.exists_genus h start tour
  have six (c) (hc : c∈h.cycleFactorsFinset) : c.support.card=6 := by
    apply ordinary_six (h:=h)
    simpa [empty] using hc
  have total : (∑c∈h.cycleFactorsFinset,c.support.card)=h.support.card := h.sum_cycleType
  rw [Finset.sum_congr rfl six] at total
  simp only [Finset.sum_const,smul_eq_mul] at total
  have cnt : h.cycleType.card=h.cycleFactorsFinset.card:=by simp [Perm.cycleType_def]
  have cost:=ActualPackingCost.open_packing_cost h last (fun x=>d x (h x)) sizeX
    (fun x _=>d_positive ..) (fun x _=>d_one ..) ∅ (Finset.empty_subset _)
    (fun c hc=>six c (Finset.mem_sdiff.mp hc).1)
  simp only [Finset.sum_empty,Finset.sdiff_empty,Nat.add_zero] at cost
  have wheels : 145≤h.cycleFactorsFinset.card := by omega
  unfold length
  split at cost <;> omega

/-- No cycle, endpoint or family of rotation classes is specified in this theorem.
Input is a single actual seven-symbol tour with the true overlap budget. -/
theorem every_short_order (h : Perm X) (start last : X) (tour : ∀y,(R*h).SameCycle start y)
    (short : length h last≤5907) :
    ∃ (f : Y→Y) (K : Finset (Finset X)),
      (∀c∈h.cycleFactorsFinset \ exceptions h,∀x∈c.support,∀y∈c.support,f (tag x)=f (tag y)) ∧
      Separated ((exceptions h).biUnion Perm.support) owner (f ∘ tag)
        (RowCredits.fee h R last (fun x=>d x (h x))) K ∧
      29540≤5*length h last+K.card := by
  classical
  have present : (exceptions h).Nonempty := by
    by_contra no
    have high:=pure_floor h start last tour (Finset.not_nonempty_iff_eq_empty.mp no)
    omega
  obtain ⟨g,eqg⟩:=SevenTourGenus.exists_genus h start tour
  obtain ⟨f,K,mono,apart,bill⟩:=packed start last tour tag tag_surj tag_rot sizeX sizeY
    turn owner owner_turn (fibre_bound Finset.univ) (fun x=>d x (h x))
    (fun x _=>d_positive ..) (fun x _=>d_one ..) (fun x _=>d_two x (h x))
    (exceptions h) (Finset.filter_subset ..) present (fun _ hc=>ordinary_six hc)
    (fun _ hc=>Or.inr (Finset.mem_filter.mp hc).2) eqg
  have ne:=Finset.card_pos.mpr present
  refine ⟨f,K,mono,apart,?_⟩
  change 29535+5*(exceptions h).card≤5*length h last+K.card at bill
  omega

/-- A wheel is required to occur as an actual ordinary cycle of the order. -/
def Required (h : Perm X) (w : Finset Y) : Prop :=
  ∃c∈h.cycleFactorsFinset \ exceptions h,c.support.image tag=w

theorem blocker (h : Perm X) (start last : X) (tour : ∀y,(R*h).SameCycle start y)
    (ws : List (Finset Y)) (root : Y) (B : Finset Y)
    (required : ∀w∈ws,Required h w)
    (joins : HitColor.chain {root} ws=true)
    (hit : ∀i : Finset X,(states owner i).Nonempty →
      ∃x∈states owner i,tag x∈ws.foldl (·∪·) {root} ∪ B)
    (short : length h last≤5907) : 29539≤5*length h last+B.card := by
  classical
  let C := ws.foldl (·∪·) {root}
  obtain ⟨f,K,mono,sep,lim⟩:=every_short_order h start last tour short
  have same (w) (hw:w∈ws) (x) (hx:x∈w) (y) (hy:y∈w) : f x=f y := by
    obtain ⟨c,hc,eq⟩:=required w hw
    rw [←eq] at hx hy
    obtain ⟨u,hu,rfl⟩:=Finset.mem_image.mp hx
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hy
    exact mono c hc _ hu _ hv
  have cap:=HitColor.one_component C B f (f root)
    (HitColor.connected f (f root) {root} ws (by simp) joins same)
  have ct:=HitColor.bound sep (C∪B) (by
    intro i hi
    apply hit
    obtain ⟨x,hx⟩:=Finset.card_pos.mp (show 0<((states owner i).image (f ∘ tag)).card by rw [(sep.1 i hi).2.1]; decide)
    obtain ⟨y,hy,_⟩:=Finset.mem_image.mp hx
    exact ⟨y,hy⟩)
  omega

#print axioms every_short_order
#print axioms blocker
end ExactWordFlow.AnonymousSeven

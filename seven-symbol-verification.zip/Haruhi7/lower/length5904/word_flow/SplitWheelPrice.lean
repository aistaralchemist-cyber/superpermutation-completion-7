import WheelBaseResidual
import GlobalClosedPrice
import ShortComponentCaps
import Cap93Mass

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows SuperpermutationBounds RotationCore RotationReinsert ResidualDensity
open LiteralWheelCover EmbeddedWheels ResidualIncidence ResidualRoutes
open scoped Classical
open private closeCap cyclic_price rootCap root_price from Cap93Mass
open private price from GlobalClosedPrice
open private sizes from EmbeddedWheels

/-- The weighted cyclic route price applies to arbitrary balanced leftovers
after marked wheels are removed, including components carrying no clean state. -/
theorem rest_price {Y : Multiset Block} {s t : Block}
    (bal : Y.map src+{t}=Y.map dst+{s})
    (width : ∀ e∈Y,e.length=7) :
    let a:=(part Y (label Y s)).card
    let nonroot:=((support Y s).image (label Y)).erase (label Y s)
    let longer:=nonroot.filter fun q=>7≤(part Y q).card
    45*separateRank Y s+25*longer.card≤38*Y.card+59 ∧
      (longer=∅ → 6*separateRank Y s+5*a≤5*Y.card+6*(rootCap a-1)) := by
  classical
  let Q:=(support Y s).image (label Y)
  let home:=label Y s
  let K (q : Component Y):=(part Y q).card
  let C (q : Component Y):=(contacts (support Y s) (label Y) q).card
  have root : home∈Q:=Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q=Y.card := sum_part_card Y Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have localBound (q) (hq:q∈Q) :
      (q=home → C q≤rootCap (K q) ∧ 45*(C q-1)≤38*K q+59) ∧
      (q≠home → 45*(C q-1)+(if 7≤K q then 25 else 0)≤38*K q ∧
        (K q≤6 → 6*(C q-1)≤5*K q)) := by
    obtain ⟨v,_,vv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩:=component_route bal v
    rw [vv] at eq lv ep
    have len:es.length=K q:=congrArg Multiset.card eq
    have wd (e) (he:e∈es):=width e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have inc : C q≤classCount a es:=contacts_bound _ lv r eq
    constructor
    · intro _
      rw [←len]
      exact ⟨inc.trans (root_price r wd),by have := WeightedMarks.path_cap r wd; omega⟩
    · intro away
      obtain ⟨x,y⟩:=ep.2 away
      subst a; subst b
      constructor
      · by_cases low : es.length<6
        · simp only [ite_eq_right (by omega : ¬7≤K q),Nat.add_zero]
          have z:=closed_small72 r wd (by omega)
          omega
        · have z:=price (K q) (C q) (by omega) (len ▸ inc.trans (cyclic_price r wd (by omega)))
          unfold GlobalClosedPrice.fee at z
          split at z <;> split <;> omega
      · intro small
        have z:=closed_small72 r wd (by omega)
        omega
  have closed (q) (hq:q∈Q.erase home) : 45*(C q-1)+(if 7≤K q then 25 else 0)≤38*K q :=
    ((localBound q (Finset.mem_erase.mp hq).2).2 (Finset.mem_erase.mp hq).1).1
  have closedSum:=Finset.sum_le_sum closed
  simp only [Finset.sum_add_distrib,←Finset.mul_sum] at closedSum
  have lump : (∑q∈Q.erase home, if 7≤K q then 25 else 0)=25*((Q.erase home).filter fun q=>7≤K q).card := by
    rw [←Finset.sum_filter]
    simp [Nat.mul_comm]
  rw [lump] at closedSum
  have rt:=(localBound home root).1 rfl
  have csum:=Finset.sum_erase_add (s:=Q) (fun q=>C q-1) root
  have ksum:=Finset.sum_erase_add (s:=Q) K root
  change 45*(∑q∈Q,(C q-1))+25*((Q.erase home).filter fun q=>7≤K q).card≤38*Y.card+59 ∧
    (((Q.erase home).filter fun q=>7≤K q)=∅ →
      6*(∑q∈Q,(C q-1))+5*K home≤5*Y.card+6*(rootCap (K home)-1))
  refine ⟨by omega,?_⟩
  intro empty
  have small (q) (hq:q∈Q.erase home) : K q≤6 := by
    by_contra! big
    have mem : q∈((Q.erase home).filter fun i=>7≤K i):=Finset.mem_filter.mpr ⟨hq,big⟩
    simp [empty] at mem
  have six (q) (hq:q∈Q.erase home) : 6*(C q-1)≤5*K q :=
    ((localBound q (Finset.mem_erase.mp hq).2).2 (Finset.mem_erase.mp hq).1).2 (small q hq)
  have tot:=Finset.sum_le_sum six
  simp only [←Finset.mul_sum] at tot
  omega

private theorem roots_small : ∀a:Fin 258,6*(rootCap a.val-1)<5*a.val+24 := by native_decide

theorem high_small_components {Y : Multiset Block} {s t : Block} {ws : List Block}
    (clean : ∀u∈ws, full u) (flow : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (many : 95≤ws.length) :
    ∀q∈((support Y s).image (label Y)).erase (label Y s), (part Y q).card≤6 := by
  classical
  have sz:=(sizes clean).1
  rw [Multiset.card_add,sz] at budget
  have rank : 719 ≤ 5*ws.length+separateRank Y s:=residual_rank ws clean flow
  have pr:=rest_price (Essential.restBalance flow (sizes clean).2)
    (fun e he=>flow.edges_seven e (Multiset.mem_add.mpr (Or.inl he)))
  dsimp only at pr
  have empty : (((support Y s).image (label Y)).erase (label Y s)).filter
      (fun q=>7≤(part Y q).card)=∅ := by
    by_contra ne
    have pos:=Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr ne)
    omega
  intro q hq
  by_contra! large
  have mem : q∈(((support Y s).image (label Y)).erase (label Y s)).filter
      (fun q=>7≤(part Y q).card):=Finset.mem_filter.mpr ⟨hq,large⟩
  simp [empty] at mem

open private wheel_data from EmbeddedWheels
open private required_data from ResidualIncidence
open private six_cycle from MarkedLargeCap

/-- Both marked wheels and required cycles can touch a remaining component
only at a clean state. Consequently it cannot be a short all-dirty circuit. -/
theorem high_six_component {Y : Multiset Block} {s t : Block} {ws : List Block}
    (clean : ∀u∈ws, full u) (flow : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (many : 95≤ws.length)
    {q : Component Y} (hq:q∈RotationComponentCount.occupied Y s) :
    ∃v,full v ∧ label Y v=q ∧ part Y q=↑(GlobalWheelRank.wheel v) := by
  classical
  obtain ⟨away,inQ⟩:=Finset.mem_erase.mp hq
  obtain ⟨v,hv,eq⟩:=Finset.mem_image.mp inQ
  obtain ⟨e,original,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp hv)
  have he:=in_part.mpr ⟨original,eq⟩
  have pos : 0<(part Y q).card:=Multiset.card_pos.mpr (fun zero=>by simp [zero] at he)
  have supported : q∈((support Y s).image (label Y)).erase (label Y s) := by
    refine Finset.mem_erase.mpr ⟨away,?_⟩
    rw [←eq,on_edge original]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr original),rfl⟩)))
  have size:=high_small_components clean flow budget many q supported
  have fresh : ∃v,full v ∧ label Y v=q := by
    by_contra! no
    let S : Set Block:={v | label Y v≠q}
    have stable (x) (hx:x∈required+(Y+turns ws)) (hs:src x∈S) : dst x∈S := by
      change label Y (dst x)≠q
      rcases Multiset.mem_add.mp hx with req|extra
      · exact no _ (required_data x req).2.1
      rcases Multiset.mem_add.mp extra with more|marked
      · rw [←on_edge more]
        exact hs
      · obtain ⟨u,hu,inWheel⟩:=List.mem_flatMap.mp (show x∈ws.flatMap GlobalWheelRank.wheel from marked)
        exact no _ ((wheel_data u (mem_states (clean u hu))).2.2.2 _ inWheel).2.1
    exact (flow.reachable S (Ne.symm away) stable e (Multiset.mem_add.mpr
      (Or.inr (Multiset.mem_add.mpr (Or.inl original))))) eq
  obtain ⟨u,fu,key⟩:=fresh
  obtain ⟨a,b,es,bag,route,_,ep⟩:=component_route (Essential.restBalance flow (sizes clean).2) u
  rw [key] at bag ep
  obtain ⟨aa,bb⟩:=ep.2 away
  subst a; subst b
  have len:es.length=(part Y q).card:=congrArg Multiset.card bag
  have wd (x) (hx:x∈es):=flow.edges_seven x (Multiset.mem_add.mpr (Or.inl
    (in_part.mp (bag ▸ (show x∈(↑es : Multiset Block) from hx))).1))
  have low:=RotationComponentCount.closed_clean fu route wd (by omega)
  have same:=six_cycle fu route wd (by omega)
  exact ⟨u,fu,key,bag.symm.trans (congrArg (fun p:List Block=>(↑p:Multiset Block)) same)⟩

theorem high_spine {Y : Multiset Block} {s t : Block} {ws : List Block}
    (clean : ∀u∈ws, full u) (flow : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (many : 95≤ws.length) :
    let a:=(part Y (label Y s)).card
    258≤a ∧ 5*a+24≤6*(rootCap a-1) := by
  classical
  have sz:=(sizes clean).1
  rw [Multiset.card_add,sz] at budget
  have rank : 719 ≤ 5*ws.length+separateRank Y s:=residual_rank ws clean flow
  have pr:=rest_price (Essential.restBalance flow (sizes clean).2)
    (fun e he=>flow.edges_seven e (Multiset.mem_add.mpr (Or.inl he)))
  dsimp only at pr ⊢
  have empty : (((support Y s).image (label Y)).erase (label Y s)).filter
      (fun q=>7≤(part Y q).card)=∅ := by
    by_contra ne
    have pos:=Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr ne)
    omega
  have six:=pr.2 empty
  have hit : 5*(part Y (label Y s)).card+24≤6*(rootCap (part Y (label Y s)).card-1):=by omega
  refine ⟨?_,hit⟩
  by_contra! small
  exact (Nat.not_lt_of_ge hit) (roots_small ⟨_,small⟩)

theorem at_most_100 {Y : Multiset Block} {s t : Block} {ws : List Block}
    (clean : ∀u∈ws, full u) (flow : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) : ws.length≤100 := by
  by_contra! many
  have low:=(high_spine clean flow budget (by omega)).1
  have sz:=(sizes clean).1
  rw [Multiset.card_add,sz] at budget
  have small:=(Multiset.card_le_card (Multiset.filter_le (fun e=>label Y (src e)=label Y s) Y))
  change (part Y (label Y s)).card≤Y.card at small
  omega

theorem hundred_root {Y : Multiset Block} {s t : Block} {ws : List Block}
    (clean : ∀u∈ws, full u) (flow : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (hundred:ws.length=100) :
    (part Y (label Y s)).card=258 ∧ (part Y (label Y s))=Y := by
  have low:=(high_spine clean flow budget (by omega)).1
  have sz:=(sizes clean).1
  rw [Multiset.card_add,sz] at budget
  have sub : part Y (label Y s)≤Y:=Multiset.filter_le ..
  have lim:=Multiset.card_le_card sub
  exact ⟨by omega,Multiset.eq_of_le_of_card_le sub (by omega)⟩

theorem sharp_bounds {b : Block} {k : Nat} (done : (complete b).card=92)
    (budget : b.length+6*k=1508) (fit : condition b k) :
    k≤100 ∧ 908≤b.length := by
  obtain ⟨rs,v,ins,small,vis⟩:=(budget_iff b k).mpr fit
  have sum:=ins.length_eq
  have c : (complete v).card=92:=ins.complete_eq ▸ done
  have sharp:=(Boundary1508Floor.only_boundary (w:=v) (by omega) vis c.ge).2
  obtain ⟨Y,ws,s,t,count,clean,h,total⟩:=sharp_residual ins vis done (by omega)
  have limit:=at_most_100 clean h total.le
  omega

#print axioms at_most_100
#print axioms sharp_bounds
end ExactWordFlow.WheelBaseResidual

import SeedWheelCut

namespace SaturatedOrientation
open SeedWheelCut

abbrev OptionRow (α : Type*) [DecidableEq α] := Finset α × α
def children {α : Type*} [DecidableEq α] (p : OptionRow α) := p.1.erase p.2

/-- A finite orientation satisfying only consequences of a saturated
connected cover. These are the constraints used in the exact-cover CNF. -/
structure Choices {α : Type*} [DecidableEq α] (A V : Finset α)
    (W : Finset (Finset α)) (T : Finset (OptionRow α)) : Prop where
  valid : ∀p∈T,p.1∈W ∧ p.2∈p.1 ∧ Disjoint (children p) A ∧ p.1.card=6
  cover : ∀d∈V \ A,∃p∈T,d∈children p
  disjoint : ∀p∈T,∀q∈T,p≠q → Disjoint (children p) (children q)
  no_pair : ∀p∈T,∀q∈T,p.2∈children q → q.2∉children p

/-- Each joining wheel in a saturated cover supplies exactly five new
labels, and its one previously seen label is its parent. The direction
of the resulting order also rules out reciprocal parent-child pairs. -/
theorem exists_choices {α : Type*} [DecidableEq α] (A V : Finset α) (W : Finset (Finset α))
    (width : ∀w∈W,w.card≤6) (tight : A.card+5*W.card≤V.card) (linked : ClosedCover A V W) :
    ∃ T : Finset (OptionRow α), Choices A V W T := by
  classical
  by_cases grow : ∃w∈W,(A∩w).Nonempty ∧ ¬w⊆A
  · obtain ⟨w,hw,meet,unused⟩:=grow
    let B:=A∪w
    let U:=W.erase w
    have linkB : ClosedCover B V U := by
      intro C seed close
      apply linked C ((show A⊆B from Finset.subset_union_left).trans seed)
      intro r hr touch
      by_cases same : r=w
      · exact same ▸ (show w⊆B from Finset.subset_union_right).trans seed
      · exact close r (Finset.mem_erase.mpr ⟨same,hr⟩) touch
    have widths (r) (hr : r∈U) : r.card≤6 := width r (Finset.mem_of_mem_erase hr)
    obtain ⟨reach,start,lim,stable⟩:=GlobalWheelRank.grow B U
    have all:=Finset.card_le_card (linkB reach start stable)
    have budget : (∑r∈U,(r.card-1))≤5*U.card := by
      have cap:=Finset.sum_le_sum (s:=U) (g:=fun _=>5) (fun r hr=>
        show r.card-1≤5 by have:=widths r hr; omega)
      simpa [Nat.mul_comm] using cap
    have edge:=Finset.card_erase_add_one hw
    change U.card+1=W.card at edge
    have union:=Finset.card_union_add_card_inter A w
    change B.card+(A∩w).card=A.card+w.card at union
    have positive:=Finset.card_pos.mpr meet
    have six:=width w hw
    have one : (A∩w).card=1 := by omega
    have full : w.card=6 := by omega
    have nextTight : B.card+5*U.card≤V.card := by omega
    obtain ⟨T,sel⟩:=exists_choices B V U widths nextTight linkB
    obtain ⟨a,am⟩:=meet
    obtain ⟨aA,aw⟩:=Finset.mem_inter.mp am
    let x : OptionRow α := (w,a)
    have clean : Disjoint (children x) A := by
      apply Finset.disjoint_left.mpr
      intro d hd da
      obtain ⟨other,dw⟩:=Finset.mem_erase.mp hd
      exact other (Finset.card_le_one.mp one.le _ (Finset.mem_inter.mpr ⟨da,dw⟩) _ am)
    have subset : children x⊆B := (Finset.erase_subset ..).trans Finset.subset_union_right
    have parent : x.2∈B := Finset.mem_union_left _ aA
    have old (q) (hq : q∈T) : Disjoint (children q) B := (sel.valid q hq).2.2.1
    have apart (q) (hq : q∈T) : Disjoint (children x) (children q) :=
      (old q hq).symm.mono_left subset
    refine ⟨insert x T,?_⟩
    constructor
    · intro p hp
      rcases Finset.mem_insert.mp hp with rfl|prev
      · exact ⟨hw,aw,clean,full⟩
      · obtain ⟨r,pa,di,n⟩:=sel.valid p prev
        exact ⟨Finset.mem_of_mem_erase r,pa,di.mono_right Finset.subset_union_left,n⟩
    · intro d hd
      obtain ⟨board,out⟩:=Finset.mem_sdiff.mp hd
      by_cases next : d∈B
      · have dw := (Finset.mem_union.mp next).resolve_left out
        have neq : d≠a := fun eq=>out (eq ▸ aA)
        exact ⟨x,Finset.mem_insert_self ..,Finset.mem_erase.mpr ⟨neq,dw⟩⟩
      · obtain ⟨p,hp,member⟩:=sel.cover d (Finset.mem_sdiff.mpr ⟨board,next⟩)
        exact ⟨p,Finset.mem_insert_of_mem hp,member⟩
    · intro p hp q hq different
      rcases Finset.mem_insert.mp hp with rfl|pOld <;> rcases Finset.mem_insert.mp hq with rfl|qOld
      · exact (different rfl).elim
      · exact apart _ qOld
      · exact (apart _ pOld).symm
      · exact sel.disjoint _ pOld _ qOld different
    · intro p hp q hq observed opposite
      rcases Finset.mem_insert.mp hp with rfl|pOld <;> rcases Finset.mem_insert.mp hq with rfl|qOld
      · exact (Finset.mem_erase.mp observed).1 rfl
      · exact Finset.disjoint_left.mp (old _ qOld) observed parent
      · exact Finset.disjoint_left.mp (old _ pOld) opposite parent
      · exact sel.no_pair _ pOld _ qOld observed opposite
  · have done:=linked A (Finset.Subset.refl _) (fun w hw meet=>
        Classical.byContradiction (fun notAll=>grow ⟨w,hw,meet,notAll⟩))
    refine ⟨∅,?_⟩
    constructor
    · simp
    · intro d hd
      obtain ⟨mem,out⟩:=Finset.mem_sdiff.mp hd
      exact (out (done mem)).elim
    · simp
    · simp
termination_by W.card
decreasing_by exact Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (Finset.card_erase_add_one hw).le

#print axioms exists_choices
end SaturatedOrientation

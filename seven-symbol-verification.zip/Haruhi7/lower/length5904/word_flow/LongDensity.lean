import StrongerDensity

namespace ResidualDensity
open ExactWordFlow DirectedEuler

private theorem numeric40 (k : ℕ) :
    let n := k+1; let r := n%40
    40*(34*(n/40)+6*(r/7)+r%7) ≤ 34*k+78 := by
  dsimp
  have dec := Nat.div_add_mod (k+1) 40
  have check : ∀r : Fin 40, 40*(6*(r.val/7)+r.val%7) ≤ 34*r.val+44 := by decide +kernel
  have a := check ⟨_,Nat.mod_lt (k+1) (by decide : 0<40)⟩
  dsimp at a
  omega

private theorem numeric41 (k : ℕ) :
    let n := k+1; let r := n%41
    41*(35*(n/41)+6*(r/7)+r%7) ≤ 35*k+75 := by
  dsimp
  have dec := Nat.div_add_mod (k+1) 41
  have check : ∀r : Fin 41, 41*(6*(r.val/7)+r.val%7) ≤ 35*r.val+40 := by decide +kernel
  have a := check ⟨_,Nat.mod_lt (k+1) (by decide : 0<41)⟩
  dsimp at a
  omega

theorem open_linear40 {s t : Six} {es : List Six} (route : Route src dst s es t)
    (widths : ∀ e∈es, e.length=7) : 40*classCount s es ≤ 34*es.length+78 := by
  obtain ⟨u,I,w,hm,hc⟩ := open_observations route widths
  have a := window_open_bound w hm (interval40 w hm) 0 (es.length+1)
  rw [hc] at a
  exact (Nat.mul_le_mul_left 40 a).trans (numeric40 es.length)

theorem open_linear41 {s t : Six} {es : List Six} (route : Route src dst s es t)
    (widths : ∀ e∈es, e.length=7) : 41*classCount s es ≤ 35*es.length+75 := by
  obtain ⟨u,I,w,hm,hc⟩ := open_observations route widths
  have a := open_count w hm 0 (es.length+1)
  rw [hc] at a
  exact (Nat.mul_le_mul_left 41 a).trans (numeric41 es.length)

theorem closed_linear40 {s : Six} {es : List Six} (route : Route src dst s es s)
    (widths : ∀ e∈es, e.length=7) (long : 40≤es.length) :
    40*classCount s es ≤ 34*es.length := by
  obtain ⟨u,I,w,hm,hc⟩ := closed_observations route widths (by omega)
  have a := window_cyclic_bound hm long (fun i p _ hi => interval40 w hi i)
  simpa only [hc] using a

theorem closed_linear41 {s : Six} {es : List Six} (route : Route src dst s es s)
    (widths : ∀ e∈es, e.length=7) (long : 41≤es.length) :
    41*classCount s es ≤ 35*es.length := by
  obtain ⟨u,I,w,hm,hc⟩ := closed_observations route widths (by omega)
  exact hc ▸ cyclic_41 w hm long

/-- No component of at most seventy-two edges can exceed the rank-per-six-wheel baseline. -/
theorem closed_small72 {s : Six} {es : List Six} (route : Route src dst s es s)
    (widths : ∀ e∈es, e.length=7) (small : es.length≤72) :
    6*classCount s es ≤ 5*es.length+6 := by
  by_cases le : es.length≤60
  · exact closed_route_gain route widths le
  · have b := closed_linear40 route widths (by omega)
    have check : ∀ m n : Fin 73, 40*n.val≤34*m.val → 6*n.val≤5*m.val+6 := by decide +kernel
    have kk : es.length < 73 := by omega
    have cc : classCount s es < 73 := by omega
    exact check ⟨es.length,kk⟩ ⟨classCount s es,cc⟩ b

/-- An open component carrying the whole rank gain of 24 requires at least 186 extra edges. -/
theorem open_atleast186 {s t : Six} {es : List Six} (route : Route src dst s es t)
    (widths : ∀ e∈es, e.length=7) (gain : 5*es.length+30≤6*classCount s es) :
    186 ≤ es.length := by
  obtain ⟨u,I,w,hm,hc⟩ := open_observations route widths
  have a := window_open_bound w hm (interval40 w hm) 0 (es.length+1)
  rw [hc] at a
  by_contra! lt
  have ck : ∀ k : Fin 186, let n := k.val+1; let r := n%40
      6*(34*(n/40)+6*(r/7)+r%7) < 5*k.val+30 := by decide +kernel
  have bad := ck ⟨_,lt⟩
  dsimp at bad
  omega

/-- Fixed length used in the near-record cut example, independent of both endpoint contexts. -/
theorem open_route_462 {s t : Six} {es : List Six} (route : Route src dst s es t)
    (widths : ∀ e∈es, e.length=7) (size : es.length=462) : classCount s es ≤ 394 := by
  obtain ⟨u,I,w,hm,hc⟩ := open_observations route widths
  have a := window_open_bound w hm (interval40 w hm) 0 (es.length+1)
  rw [hc,size] at a
  exact a

end ResidualDensity
#print axioms ResidualDensity.open_atleast186
#print axioms ResidualDensity.closed_small72

import ExtremalRealizations

namespace ResidualDensity.BatchedRealizations
open ExtremalRealizations
open private rowSets from ExtremalRealizations
open private canonical from Interval66

/-- Share a geometric prefix among every mask with that prefix. In
particular a failed seam discards all the suffixes below it at once. -/
private def endpoints (ps : List (List Nat)) (seen : List Six) : List (Finset Six) :=
  if []∈ps then [seen.toFinset] else []

private def tailsFor (n : Nat) (ps : List (List Nat)) :=
  ps.filterMap fun xs => match xs with
    | [] => none
    | a::tail => if a=n then some tail else none

private def firsts (ps : List (List Nat)) := (ps.filterMap List.head?).eraseDups

private def search : Nat → List (List Nat) → Six → List Six → List (Finset Six)
  | 0,ps,_,seen => endpoints ps seen
  | fuel+1,ps,s,seen =>
    endpoints ps seen ++ (firsts ps).flatMap fun n =>
      let tails:=tailsFor n ps
      let more:=tails.filter (fun xs=> !xs.isEmpty)
      if n=0 then endpoints tails seen ++
        (if more.isEmpty then [] else (List.finRange 7).flatMap fun a=> search fuel more (step s a) seen)
      else
        let hits:=rowTags s n
        if full s && hits.all (fun z => decide (z∉seen)) then
          let updated:=hits++seen
          endpoints tails updated ++ (if more.isEmpty then [] else
            (List.finRange 7).flatMap fun a=>(List.finRange 7).flatMap fun b=>
              search fuel more (step (step (s.rotate (n-1)) a) b) updated)
        else []

def results (ps : List (List Nat)) : List (Finset Six) :=
  let depth := (ps.map List.length).sum
  canonical.flatMap fun s=>search depth ps s []

private theorem tails_spec (n : Nat) (ps : List (List Nat)) (xs : List Nat) :
    xs∈tailsFor n ps ↔ n::xs∈ps := by
  constructor
  · rintro h
    obtain ⟨l,hl,eq⟩:=List.mem_filterMap.mp h
    cases l with
    | nil => simp at eq
    | cons a rest =>
      by_cases same : a=n
      · simp_all
      · simp [same] at eq
  · intro yes
    exact List.mem_filterMap.mpr ⟨n::xs,yes,by simp⟩

private theorem sound (s : Six) (seen : List Six) (ps : List (List Nat))
    (ns : List Nat) (has : ns∈ps) (fuel : Nat) (long : ns.length≤fuel) :
    rowSets ns s seen ⊆ search fuel ps s seen := by
  induction fuel generalizing s seen ps ns with
  | zero =>
    have eq:=List.eq_nil_of_length_eq_zero (by omega : ns.length=0)
    subst ns
    simp [rowSets,search,endpoints,has]
  | succ fuel ih =>
    cases ns with
    | nil =>
      intro x hx
      rw [search]
      exact List.mem_append_left _ (by simpa [endpoints,has,rowSets] using hx)
    | cons n ns =>
      have nmem : n∈firsts ps := List.mem_eraseDups.mpr (List.mem_filterMap.mpr ⟨n::ns,has,rfl⟩)
      have nTail:= (tails_spec n ps ns).mpr has
      intro ans found
      rw [search]
      apply List.mem_append_right
      apply List.mem_flatMap.mpr
      refine ⟨n,nmem,?_⟩
      dsimp only
      by_cases zero : n=0
      · subst n
        rw [rowSets,ite_eq_left rfl] at found
        rw [ite_eq_left rfl]
        cases ns with
        | nil =>
          exact List.mem_append_left _ (by simpa [endpoints,nTail] using found)
        | cons n ns =>
          have sub : n::ns∈(tailsFor 0 ps).filter (fun xs=> !xs.isEmpty) := List.mem_filter.mpr ⟨nTail,rfl⟩
          have pos : !((tailsFor 0 ps).filter (fun xs=> !xs.isEmpty)).isEmpty := by
            simp only [Bool.not_eq_true',List.isEmpty_eq_false_iff]; exact List.ne_nil_of_mem sub
          simp only [List.isEmpty_cons,Bool.false_eq_true,ite_false,List.mem_flatMap] at found
          obtain ⟨a,ha,tail⟩:=found
          apply List.mem_append_right
          rw [ite_eq_right (by simpa using pos)]
          exact List.mem_flatMap.mpr ⟨a,ha,ih _ _ _ _ sub (by simpa using long) tail⟩
      · rw [rowSets,ite_eq_right zero] at found
        rw [ite_eq_right zero]
        by_cases ok : (decide (full s) && (rowTags s n).all (fun z=>decide (z∉seen)))=true
        · rw [ite_eq_left ok] at found ⊢
          cases ns with
          | nil => exact List.mem_append_left _ (by simpa [endpoints,nTail] using found)
          | cons a as =>
            have sub : a::as∈(tailsFor n ps).filter (fun xs=> !xs.isEmpty) := List.mem_filter.mpr ⟨nTail,rfl⟩
            have pos : !((tailsFor n ps).filter (fun xs=> !xs.isEmpty)).isEmpty := by
              simp only [Bool.not_eq_true',List.isEmpty_eq_false_iff]; exact List.ne_nil_of_mem sub
            simp only [List.isEmpty_cons,Bool.false_eq_true,ite_false,List.mem_flatMap] at found
            obtain ⟨a,ha,b,hb,tail⟩:=found
            apply List.mem_append_right
            rw [ite_eq_right (by simpa using pos)]
            exact List.mem_flatMap.mpr ⟨a,ha,List.mem_flatMap.mpr ⟨b,hb,ih _ _ _ _ sub (by simpa using long) tail⟩⟩
        · rw [ite_eq_right ok] at found; exact (List.not_mem_nil found).elim

theorem covers (ps : List (List Nat)) : realizations ps ⊆ results ps := by
  intro r h
  obtain ⟨ns,member,more⟩:=List.mem_flatMap.mp h
  obtain ⟨s,basic,ans⟩:=List.mem_flatMap.mp more
  have len : ns.length≤(ps.map List.length).sum :=
    List.single_le_sum (fun _ _=>Nat.zero_le _) _ (List.mem_map_of_mem member)
  exact List.mem_flatMap.mpr ⟨s,basic,sound _ _ _ _ member _ len ans⟩

#print axioms covers
end ResidualDensity.BatchedRealizations

import PooledForceIterate
import ForcedRootClosure

namespace ExactWordFlow.MultipleRootContacts
open Equiv SevenWordWindows ForcedRootClosure SeedWheelCut ExtremeWheelCut
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- Any physical seed forcing at least 391 classes suffices, regardless of
its distribution among exceptional h-cycles. -/
theorem pooled_exclude {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (name : Y ↪ Block) (board : Finset.univ.map name=allClasses)
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (nonempty : E.Nonempty)
    (six : ∀w∈h.cycleFactorsFinset,w∉E → w.support.card=6)
    (legal : ∀w∈h.cycleFactorsFinset,w∉E → (w.support.image tag).map name∈allRows)
    (P : Finset Block) (forceBound : 391≤(force P).card)
    (inside : P⊆(E.biUnion (fun c=>c.support.image tag)).map name)
    (limited : (∑c∈E,c.support.card)≤390) {s L : Nat} (paid : 71 ≤ s)
    (cost : L=5764+h.cycleType.card+s+2*g) (short : L≤5904) : False := by
  classical
  let H:=h.cycleFactorsFinset
  let T (w : Perm X):=w.support.image tag
  let U:=E.biUnion T
  let rows:=(H \ E).image T
  have maps (w) (hw : w∈H) (off : w∉E) : T w∈rows:=
    Finset.mem_image_of_mem _ (Finset.mem_sdiff.mpr ⟨hw,off⟩)
  obtain ⟨D,_,cap,step⟩:=pooled_force_iterate start oneOrbit tag onto rot classes genus E known nonempty six rows maps
  have stable : forceRows rows U \ D⊆U:=by simpa using step U (Finset.Subset.refl _) 1
  have incl : force P ⊆ (U∪D).map name := by
    intro j hj
    rcases Finset.mem_union.mp hj with old|new
    · obtain ⟨y,hy,rfl⟩:=Finset.mem_map.mp (inside old)
      exact Finset.mem_map_of_mem _ (Finset.mem_union_left _ hy)
    · obtain ⟨required,blocked⟩:=Finset.mem_filter.mp new
      obtain ⟨y,_,rfl⟩:=Finset.mem_map.mp (board ▸ required)
      apply Finset.mem_map_of_mem
      by_cases escape : y∈D
      · exact Finset.mem_union_right _ escape
      apply Finset.mem_union_left
      apply stable
      apply Finset.mem_sdiff.mpr
      refine ⟨Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _,?_⟩),escape⟩
      intro r hr hit
      obtain ⟨w,hw,rfl⟩:=Finset.mem_image.mp hr
      obtain ⟨yes,off⟩:=Finset.mem_sdiff.mp hw
      have low:=blocked _ (legal w yes off) (Finset.mem_map_of_mem name hit)
      have sub : P∩(T w).map name ⊆ ((T w)∩U).map name := by
        rw [Finset.map_inter]
        intro x hx
        obtain ⟨px,wx⟩:=Finset.mem_inter.mp hx
        exact Finset.mem_inter.mpr ⟨wx,inside px⟩
      simpa only [Finset.card_map] using low.trans (Finset.card_le_card sub)
  have arrive:=Finset.card_le_card incl
  rw [Finset.card_map] at arrive
  have touch:=forceBound.trans (arrive.trans (Finset.card_union_le U D))
  have dominated : U.card≤∑c∈E,c.support.card:=Finset.card_biUnion_le.trans
    (Finset.sum_le_sum (fun c _=>Finset.card_image_le))
  have nE:=Finset.card_pos.mpr nonempty
  have split : (∑c∈H \ E,c.support.card)+(∑c∈E,c.support.card)=h.support.card :=
    (Finset.sum_sdiff known).trans h.sum_cycleType
  have neutral : (∑c∈H \ E,c.support.card)=(H \ E).card*6 := by
    rw [Finset.sum_congr rfl (fun c hc=>six c (Finset.mem_sdiff.mp hc).1 (Finset.mem_sdiff.mp hc).2)]
    simp [H]
  have k : H.card=h.cycleType.card:=by simp [H,Perm.cycleType_def]
  have count:=Finset.card_sdiff_add_card_eq_card known
  change (H \ E).card+E.card=H.card at count
  change 4*(∑c∈E,c.support.card)+D.card+4≤4*U.card+4*E.card+8*g at cap
  have residue : (∑c∈E,c.support.card)+5*(H \ E).card=719+E.card+2*g:=by omega
  have length : 19+6*E.card+5*s+12*g≤∑c∈E,c.support.card:=by omega
  omega

/-- The concrete 378-tag prefix is a certified instance. -/
theorem pooled_378 {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (name : Y ↪ Block) (board : Finset.univ.map name=allClasses)
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (nonempty : E.Nonempty)
    (six : ∀w∈h.cycleFactorsFinset,w∉E → w.support.card=6)
    (legal : ∀w∈h.cycleFactorsFinset,w∉E → (w.support.image tag).map name∈allRows)
    (inside : earlyTags⊆(E.biUnion (fun c=>c.support.image tag)).map name)
    (limited : (∑c∈E,c.support.card)≤390) {s L : Nat} (paid : 71 ≤ s)
    (cost : L=5764+h.cycleType.card+s+2*g) (short : L≤5904) : False :=
  pooled_exclude start oneOrbit tag onto rot classes genus name board E known nonempty six legal
    earlyTags (le_of_eq prefix_bound.2.symm) inside limited paid cost short

#print axioms pooled_exclude
#print axioms pooled_378
end ExactWordFlow.MultipleRootContacts

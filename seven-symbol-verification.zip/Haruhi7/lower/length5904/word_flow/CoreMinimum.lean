import RotationCore

namespace ExactWordFlow.RotationCore
open SevenWordWindows SuperpermutationBounds
open SuperpermLowerBounds.LengthBudget

/-- The objective does not prescribe the starting letters, the final letters,
the identity of any completed class, or the path between classes. -/
def admissibleCore (v : Block) : Prop :=
  6≤v.length ∧ (visited v).card=720 ∧ 137≤(complete v).card

private theorem cut_583 {w : Block} (hw : Covers w) (many : 583≤(completeClasses w).card) :
    ∃v : Block, admissibleCore v ∧ v.length+4081=w.length := by
  classical
  obtain ⟨S,pick,n⟩ := Finset.exists_subset_card_eq many
  have legal : S⊆allClasses := fun c hc => (Finset.mem_filter.mp (pick hc)).1
  obtain ⟨v,long,size,hit,covered⟩ := contract S hw pick
  have all : allClasses⊆visited v := by
    intro c hc
    by_cases sel : c∈S
    · exact hit sel
    · exact complete_subset v (covered (Finset.mem_sdiff.mpr ⟨hc,sel⟩))
  have eq := Finset.Subset.antisymm (visited_subset v) all
  have number := Finset.card_le_card covered
  rw [Finset.card_sdiff_of_subset legal,board,n] at number
  exact ⟨v,⟨long,by rw [eq,board],by omega⟩,by omega⟩

private theorem record_runs : 583≤(completeClasses Word5905.word).card := by native_decide

theorem exists_1824_core : ∃v : Block, admissibleCore v ∧ v.length=1824 := by
  obtain ⟨v,ok,size⟩ := cut_583 Word5905.covers record_runs
  rw [Word5905.length_5905] at size
  exact ⟨v,ok,by omega⟩

private theorem any_core_length : ∃n : Nat, ∃v : Block, admissibleCore v ∧ v.length=n := by
  obtain ⟨v,ok,size⟩ := exists_1824_core
  exact ⟨1824,v,ok,size⟩

noncomputable def minimumCoreLength : Nat := by
  classical
  exact Nat.find any_core_length

theorem minimumCore_spec :
    IsLeast {n : Nat | ∃v : Block, admissibleCore v ∧ v.length=n} minimumCoreLength := by
  classical
  exact ⟨Nat.find_spec any_core_length,fun _ h => Nat.find_min' any_core_length h⟩

/-- A truly shortest covering word of length at most 5904 has clean endpoints
at its original length, so the two compulsory loss units count without padding. -/
theorem shortest_intact {w : Block} (hw : Covers w) (small : w.length≤5904)
    (minimal : ∀v : Block, Covers v → w.length≤v.length) :
    583≤(completeClasses w).card := by
  obtain ⟨u,v,form⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange 7)
  have long := congrArg List.length form
  simp only [List.length_append,List.length_finRange] at long
  obtain ⟨p,l,r,size,nd,left,first,_⟩ := SevenCriticalLetters.shortest_unique hw minimal 0 (by omega)
  have emptyL : l=[] := List.length_eq_zero_iff.mp (by omega)
  subst l
  simp only [List.nil_append] at left
  have lft : (w.take 6).Nodup := by
    rw [left,List.take_append_of_le_length (by omega)]
    exact nd.take
  obtain ⟨q,l,r,sq,ndq,right,_,last,_⟩ := SevenCriticalLetters.shortest_unique hw minimal (w.length-1) (by omega)
  have total := congrArg List.length right
  simp only [List.length_append] at total
  have emptyR : r=[] := List.length_eq_zero_iff.mp (by omega)
  subst r
  simp only [List.append_nil] at right
  have rgt : (w.drop (w.length-6)).Nodup := by
    rw [right,List.length_append,sq,show l.length+7-6=l.length+1 by omega,
      List.drop_append,List.drop_of_length_le (show l.length≤l.length+1 by omega)]
    simp only [List.nil_append,Nat.add_sub_cancel_left]
    exact ndq.drop
  have lost := AdjacentInvalid.at_least_two hw small lft rgt
  have base := AdjacentInvalid.complete_with_gaps w hw small
  omega

/-- The seven-symbol shortest-superpermutation objective equals a fixed
constant plus the shortest admissible core, with no assumed lower bound. -/
theorem exact_minimum : SuperpermBridge.HR.Ssuper 7=4081+minimumCoreLength := by
  apply le_antisymm
  · obtain ⟨v,⟨long,all,many⟩,size⟩ := minimumCore_spec.1
    obtain ⟨w,hw,sz⟩ := expand_remaining long all
    have lo := SuperpermBridge.ssuper_le_length hw
    omega
  · obtain ⟨w,hw,size⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
    have minimal (v : Block) (hv : Covers v) : w.length≤v.length :=
      size.trans_le (SuperpermBridge.ssuper_le_length hv)
    by_cases small : w.length≤5904
    · obtain ⟨v,hv,sz⟩ := cut_583 hw (shortest_intact hw small minimal)
      have min := minimumCore_spec.2 (show v.length∈{n : Nat | ∃z : Block, admissibleCore z ∧ z.length=n}
        from ⟨v,hv,rfl⟩)
      omega
    · have cap := minimumCore_spec.2 (show 1824∈{n : Nat | ∃z : Block, admissibleCore z ∧ z.length=n}
        from exists_1824_core)
      omega

/-- Every completed class beyond the 137 required by this objective
costs at least seven letters relative to an optimal admissible core. -/
theorem extra_class_price {v : Block} (hv : admissibleCore v) :
    minimumCoreLength+7*((complete v).card-137)≤v.length := by
  obtain ⟨long,all,many⟩ := hv
  have upper := (Finset.card_le_card (complete_subset v)).trans all.le
  obtain ⟨w,hw,size⟩ := expand_remaining long all
  have low := SuperpermBridge.ssuper_le_length hw
  rw [exact_minimum,size] at low
  omega

theorem shortest_core_completes_exactly {v : Block} (hv : admissibleCore v)
    (shortest : v.length=minimumCoreLength) : (complete v).card=137 := by
  have lo := hv.2.2
  have bound := extra_class_price hv
  omega

#print axioms extra_class_price
#print axioms shortest_intact
#print axioms exact_minimum
end ExactWordFlow.RotationCore

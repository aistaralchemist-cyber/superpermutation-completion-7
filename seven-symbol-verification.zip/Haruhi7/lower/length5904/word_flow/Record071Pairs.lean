import Record071

namespace ExactWordFlow.Record071
open GlobalWheelRank EmbeddedWheels ResidualDensity SevenWordWindows DirtyWheelBudget

private def edgePair (e : Block) : Finset Node := {node (src e),node (dst e)}
private def live := states.filter fun q => (wheel q).all (fun e => decide (e∈extra))

private theorem census : extra.Nodup ∧ (extra.map edgePair).Nodup ∧
    (∀e∈((windows word).filter (fun b => !decide b.Nodup)), node (src e) ≠ node (dst e)) ∧
    ∀u∈live, ∀v∈live, wheelNodes u=wheelNodes v → ∃ e∈wheel u, e∈wheel v := by
  refine ⟨?_,?_,?_,?_⟩ <;> native_decide

private theorem no_dup_below {α : Type*} {A X : Multiset α} (sub : A≤X) (nd : X.Nodup) :
    A.Nodup := by
  obtain ⟨B,rfl⟩ := exists_add_of_le sub
  exact (Multiset.nodup_add.mp nd).1

private theorem row_simple {ws : List Block} (ok : ∀w∈ws,full w) (sub : turns ws≤extra) :
    (ws.map wheelNodes).Nodup := by
  induction ws with
  | nil => simp
  | cons w ws ih =>
    have form : turns (w::ws)=(↑(wheel w) : Multiset Block)+turns ws := rfl
    have ltTail : turns ws≤turns (w::ws) := by rw [form]; exact Multiset.le_add_left ..
    have p (u) (hu : u∈w::ws) : u∈live := List.mem_filter.mpr ⟨mem_states (ok u hu),
      List.all_eq_true.mpr (fun e he => decide_eq_true (Multiset.mem_of_le sub
        (show e∈(w::ws).flatMap wheel from List.mem_flatMap.mpr ⟨u,hu,he⟩)))⟩
    have nd := no_dup_below sub census.1
    rw [form] at nd
    have disj : ∀{v}, v∈(↑(wheel w) : Multiset Block) → v∉turns ws := Multiset.disjoint_left.mp (Multiset.nodup_add.mp nd).2.2
    refine List.nodup_cons.mpr ⟨?_,ih (fun u hu => ok _ (List.mem_cons_of_mem _ hu)) (ltTail.trans sub)⟩
    intro seen
    obtain ⟨u,hu,eq⟩ := List.mem_map.mp seen
    obtain ⟨e,ew,eu⟩ := census.2.2.2 _ (p _ List.mem_cons_self) _ (p _ (List.mem_cons_of_mem _ hu)) eq.symm
    exact disj (show e∈(↑(wheel w) : Multiset Block) from ew)
      (show e∈ws.flatMap wheel from List.mem_flatMap.mpr ⟨u,hu,eu⟩)

/-- For every actual choice on this connected 5,905 word, even the joint
rank loss is at most 138. The value is attained by its maximum turn packing. -/
theorem every_price_at_most_138 {ws : List Block} {F : Multiset Block}
    (ok : ∀w∈ws,full w) (split : extra=turns ws+F) :
    (dirty extra).card+ws.length+5*(ws.length-(wheelRows ws).card)
      +(F.card-(otherPairs ws F).card) ≤138 := by
  have sub : turns ws≤extra := split ▸ (Multiset.le_add_right ..)
  have remain : F≤extra := split ▸ (Multiset.le_add_left ..)
  have lim := maximum_turns.2 (show ws.length∈{m : Nat | ∃ws : List Block, ws.length=m ∧
    (∀q∈ws,full q) ∧ turns ws≤extra} from ⟨ws,rfl,ok,sub⟩)
  have rowsEq : wheelRows ws=(ws.map wheelNodes).toFinset := by ext v; simp [wheelRows]
  have rows := List.toFinset_card_of_nodup (row_simple ok sub)
  rw [List.length_map] at rows
  have raw := split ▸ census.1
  have noOverlap : ∀{e}, e∈F → e∉turns ws := Multiset.disjoint_right.mp (Multiset.nodup_add.mp raw).2.2
  have use : ∀e∈F.toFinset, node (src e)≠node (dst e) ∧ e∉turns ws := by
    intro e he
    have hf := Multiset.mem_toFinset.mp he
    have ex := Multiset.mem_of_le remain hf
    exact ⟨census.2.2.1 _ ex,noOverlap hf⟩
  have rawPairs : (otherPairs ws F).card=(F.map edgePair).toFinset.card := by
    unfold otherPairs
    rw [Finset.filter_eq_self.mpr use,Multiset.toFinset_map]
    rfl
  have nd := no_dup_below (Multiset.map_le_map (f:=edgePair) remain) census.2.1
  rw [Multiset.toFinset_card_of_nodup nd, Multiset.card_map] at rawPairs
  have d := placement.2.2.2.2.1
  rw [rowsEq,rows,rawPairs,d]
  omega

#print axioms every_price_at_most_138
end ExactWordFlow.Record071

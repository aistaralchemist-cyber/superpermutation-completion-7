import ResidualRoutes
import ResidualIncidence

/-! The overlap graph with one vertex per residual weak component and a link
whenever two components touch the same rotation class. Its connectivity is
an exact test for an integral placement which already satisfies degree balance. -/
namespace ExactWordFlow.ResidualIncidence
open SevenWordWindows ResidualDensity ResidualRoutes DirectedEuler
open scoped Classical

noncomputable def liveGroups (X : Multiset Block) (s : Block) :=
  (support X s).image (label X)

noncomputable def shares (X : Multiset Block) (s : Block) (i j : Component X) :=
  ((contacts (support X s) (label X) i) ∩ (contacts (support X s) (label X) j)).Nonempty

/-- Every proper nonempty two-color split of the used residual components
has a rotation class in both colors. A dirty-only component remains a
vertex of this test and can itself witness a failed cut. -/
def SharedCuts (X : Multiset Block) (s : Block) : Prop :=
  ∀ L : Set (Component X), (∃ i∈liveGroups X s, i∈L) →
    (∃ j∈liveGroups X s, j∉L) →
    ∃ i∈liveGroups X s, ∃ j∈liveGroups X s, i∈L ∧ j∉L ∧ shares X s i j

private theorem agrees_of_cuts {X : Multiset Block} {s : Block} (cuts : SharedCuts X s)
    (L : Set (Component X)) (invar : ∀ i∈liveGroups X s, ∀ j∈liveGroups X s,
      shares X s i j → i∈L → j∈L) :
    ∀ i∈liveGroups X s, ∀ j∈liveGroups X s, i∈L → j∈L := by
  intro i hi j hj on
  by_contra off
  obtain ⟨u,hu,v,hv,ul,vl,edge⟩ := cuts L ⟨_,hi,on⟩ ⟨_,hj,off⟩
  exact vl (invar u hu v hv edge ul)

private theorem member_pair {X : Multiset Block} {s : Block} {u v : Block}
    (hu : u∈support X s) (hv : v∈support X s) (fu : full u) (fv : full v) (eq : tag u=tag v) :
    shares X s (label X u) (label X v) := by
  refine ⟨tag u,Finset.mem_inter.mpr ⟨?_,?_⟩⟩
  · exact Finset.mem_image.mpr ⟨u,Finset.mem_filter.mpr ⟨hu,rfl,fu⟩,rfl⟩
  · exact Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨hv,rfl,fv⟩,eq.symm⟩

private theorem required_step {X : Multiset Block} {s : Block} {e : Block} (he : e∈required) :
    src e∈support X s ∧ dst e∈support X s ∧ shares X s (label X (src e)) (label X (dst e)) := by
  have table : representatives.all (fun p => decide
      (full (src p) ∧ full (dst p) ∧ tag (src p)=tag (dst p)))=true := by native_decide
  obtain ⟨a,b,eq⟩ := of_decide_eq_true (List.all_eq_true.mp table _ he)
  have st : src e ∈ required.map dst := by
    rw [←(show required.map src=required.map dst from balanced_representatives)]
    exact Multiset.mem_map.mpr ⟨e,he,rfl⟩
  have mem (v : Block) (hit : v∈required.map dst) : v∈support X s := by
    apply Finset.mem_insert_of_mem
    apply Multiset.mem_toFinset.mpr
    rw [Multiset.map_add]
    exact Multiset.mem_add.mpr (Or.inl hit)
  have u := mem _ st
  have v := mem _ (Multiset.mem_map.mpr ⟨e,he,rfl⟩)
  exact ⟨u,v,member_pair u v a b eq⟩

private theorem along {a b : Block} {es : List Block} (walk : Route src dst a es b)
    (S : Set Block) (eq : ∀ e∈es, src e∈S ↔ dst e∈S) :
    ∀ e∈es, src e∈S ↔ a∈S := by
  induction walk with
  | nil => simp
  | @cons u v tail f st r ih =>
    intro e he
    rcases List.mem_cons.mp he with rfl|mem
    · rw [st]
    · exact (ih (fun z hz => eq z (List.mem_cons_of_mem _ hz)) e mem).trans
        ((eq f List.mem_cons_self).symm.trans (by rw [st]))

private def orbitWord (v : Block) := tag v ++ tag v

private theorem same_class (S : Set Block)
    (hold : ∀e∈required, src e∈S ↔ dst e∈S) {u v : Block}
    (fu : full u) (fv : full v) (eq : tag u=tag v) : u∈S ↔ v∈S := by
  have table : states.all (fun a =>
      decide (6≤(orbitWord a).length) &&
      ((windows (orbitWord a)).map src).contains a &&
      (windows (orbitWord a)).all (fun e => decide (e.length=7 ∧ e.Nodup)))=true := by native_decide
  have row (a : Block) (fl : full a) : a∈S ↔ (orbitWord a).take 6∈S := by
    have hh := List.all_eq_true.mp table a (mem_states fl)
    simp only [Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem,List.all_eq_true] at hh
    obtain ⟨⟨sz,loc⟩,edges⟩ := hh
    obtain ⟨e,he,ee⟩ := List.mem_map.mp loc
    have route := read_route (orbitWord a) sz
    exact (show a∈S ↔ src e∈S by rw [ee]).trans
      (along route S (fun e h => hold e ((mem_reps _).mpr (edges e h))) e he)
  have same : orbitWord u=orbitWord v := by simp [orbitWord,eq]
  exact (row u fu).trans ((same ▸ (row v fv)).symm)

theorem feasible_iff_shared_cuts {X : Multiset Block} {s t : Block} (size : s.length=6)
    (width : ∀e∈X, e.length=7) (balance : X.map src+{t}=X.map dst+{s}) :
    Feasible X s t ↔ SharedCuts X s := by
  classical
  let D := support X s
  let Q := liveGroups X s
  have home : label X s∈Q := Finset.mem_image_of_mem _ (Finset.mem_insert_self ..)
  have mapin (v) (hv : v∈D) : label X v∈Q := Finset.mem_image_of_mem _ hv
  have dest (e) (he : e∈required+X) : dst e∈D := Finset.mem_insert_of_mem
    (Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨_,he,rfl⟩))
  constructor
  · intro h L pos neg
    by_contra! no
    have sep (e) (he : e∈required+X) : label X (src e)∈L ↔ label X (dst e)∈L := by
      rcases Multiset.mem_add.mp he with req | ex
      · obtain ⟨u,v,sh⟩ := required_step (X:=X) (s:=s) req
        have rev : shares X s (label X (dst e)) (label X (src e)) := by
          simpa only [shares,Finset.inter_comm] using sh
        constructor
        · intro on
          by_contra off
          exact no _ (mapin _ u) _ (mapin _ v) on off sh
        · intro on
          by_contra off
          exact no _ (mapin _ v) _ (mapin _ u) on off rev
      · rw [on_edge ex]
    let S : Set Block := {v | label X v∈L ↔ label X s∈L}
    have root : s∈S := Iff.rfl
    have step (e) (he : e∈required+X) : src e∈S → dst e∈S := fun old => (sep e he).symm.trans old
    have all (q) (hq : q∈Q) : q∈L ↔ label X s∈L := by
      obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hq
      rcases Finset.mem_insert.mp hv with sv|out
      · rw [sv]
      · obtain ⟨e,he,rfl⟩ := Multiset.mem_map.mp (Multiset.mem_toFinset.mp out)
        exact step e he (h.reachable S root step e he)
    obtain ⟨i,hi,on⟩ := pos
    obtain ⟨j,hj,off⟩ := neg
    exact off ((all _ hj).mpr ((all _ hi).mp on))
  · intro cuts
    refine ⟨size,width,balance,?_⟩
    intro S start step e he
    have bal : (required+X).map src+{t}=(required+X).map dst+{s} := by
      have rb : required.map src=required.map dst := balanced_representatives
      rw [Multiset.map_add,Multiset.map_add,rb,add_assoc,add_assoc,balance]
    have bi := (Essential.restrictBalance start bal step).2.1
    let L : Set (Component X) := {q | ∃v∈S, label X v=q}
    have reflect (v) : label X v∈L ↔ v∈S := by
      constructor
      · rintro ⟨z,hz,eq⟩
        exact (invariant S (fun f hf => bi f (Multiset.mem_add.mpr (Or.inr hf))) eq).mp hz
      · exact fun hv => ⟨v,hv,rfl⟩
    have preserves (i) (_ : i∈Q) (j) (_ : j∈Q) (shared : shares X s i j)
        (inL : i∈L) : j∈L := by
      obtain ⟨c,hc⟩ := shared
      obtain ⟨ha,hb⟩ := Finset.mem_inter.mp hc
      obtain ⟨u,um,uc⟩ := Finset.mem_image.mp ha
      obtain ⟨v,vm,vc⟩ := Finset.mem_image.mp hb
      obtain ⟨_,ui,uf⟩ := Finset.mem_filter.mp um
      obtain ⟨_,vj,vf⟩ := Finset.mem_filter.mp vm
      have link := same_class S (fun e he => bi e (Multiset.mem_add.mpr (Or.inl he))) uf vf (uc.trans vc.symm)
      rw [←vj,reflect,←link,←reflect,ui]
      exact inL
    have there := agrees_of_cuts cuts L preserves (label X s) home _ (mapin _ (dest _ he))
      ((reflect _).mpr start)
    exact (bi _ he).mpr ((reflect _).mp there)

#print axioms feasible_iff_shared_cuts
end ExactWordFlow.ResidualIncidence

import FusedOneGround
import Cap94Lookup
import NinetyFour
import BudgetCoreCurve
import Control1515

namespace ExactWordFlow.NinetyThree
open SevenWordWindows SuperpermutationBounds ResidualDensity RotationComponentCount RotationCore

theorem component_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (bd : X.card≤858) : (occupied X s).card≤93 := by
  have older:=NinetyFour.component_limit h bd
  by_contra! many
  obtain ⟨R,hit,W,legal,sz,closed⟩:=FusedOne294.cover_certificate Cap94Lookup.accept FusedOneGround.checked h bd (by omega)
  exact Cap94Lookup.no_cover hit legal sz closed

theorem exact_length : (∃w : Block,Covers w ∧ w.length≤5904) ↔ BudgetCoreCurve.atLength 1515 93 :=
  BudgetCoreCurve.threshold 858 93 (by decide) (@component_limit)

open private neg_witness from Target107

theorem ceiling_iff : Target107.ceiling 1620 107 ↔ Target107.ceiling 1515 92 := by
  rw [neg_witness 1620 107,neg_witness 1515 92]
  exact not_congr (RotationCore.exact_1620.symm.trans
    (ComponentCurve.exact_threshold (k:=93) (@component_limit) (by decide) (by decide)))

#print axioms component_limit
#print axioms exact_length
#print axioms ceiling_iff
end ExactWordFlow.NinetyThree

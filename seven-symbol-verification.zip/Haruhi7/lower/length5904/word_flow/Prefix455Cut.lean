import Prefix455Data

namespace Prefix455
open ExactWordFlow SevenWordWindows ResidualDensity GlobalWheelRank DirectedEuler SeedWheelCut

private def anchor := tag (baseWord.take 6)
private def proj (v : Block) := if full v then tag v else anchor

private theorem tables :
    anchor ∈ seen ∧ proj last ∈ seen ∧
    allClasses ⊆ (representatives.map (fun e => proj (src e))).toFinset ∧
    (∃ e∈representatives, proj (src e)=anchor) ∧
    (∀e∈representatives, proj (src e)=proj (dst e)) ∧
    (∀e∈windows baseWord, proj (src e)∈seen ∧ proj (dst e)∈seen) ∧
    (∀q∈roots, ∀e∈wheel q, proj (src e)∈GlobalWheelRank.touches q ∧
      proj (dst e)∈GlobalWheelRank.touches q) := by native_decide

private theorem collected {v : Block} {vs : List Block} (hv : v∈vs) :
    proj v∈seen ∪ touched vs := by
  by_cases fl : full v
  · apply Finset.mem_union_right
    exact List.mem_toFinset.mpr (List.mem_map.mpr
      ⟨v,List.mem_filter.mpr ⟨hv,decide_eq_true fl⟩,by simp [proj,fl]⟩)
  · simp [proj,fl,tables.1]

private theorem sources {a b : Block} {es : List Block} (r : Route src dst a es b)
    {e : Block} (he : e∈es) : src e∈a::es.map dst := by
  induction r with
  | nil => simp at he
  | cons f hs tail ih =>
    rcases List.mem_cons.mp he with rfl|rest
    · simp [hs]
    · simpa using (List.mem_cons_of_mem _ (ih rest))

/-- The 455-edge prefix fails for every seven-edge continuation, every
choice of at most 66 wheels, all multiplicities, and both global endpoints. -/
theorem every_seven_edge_tail_fails {X : Multiset Block} {s t b : Block} {es : List Block}
    (r : Route src dst last es b) (ww : ∀e∈es, e.length=7) (k : es.length=7)
    (W : Finset Block) (legit : W⊆roots) (few : W.card≤66)
    (account : ∀e∈X, e∈required ∨ e∈windows baseWord ∨ e∈es ∨ ∃ q∈W, e∈wheel q) :
    ¬Feasible X s t := by
  classical
  intro h
  let U := touched (es.map dst)
  let A := seen∪U
  let B := W.image GlobalWheelRank.touches
  have data := prefix_geometry
  have lin := tables
  obtain ⟨e,he,eq⟩ := lin.2.2.2.1
  have cover : ClosedCover A allClasses B := by
    apply of_feasible proj A allClasses B h lin.2.2.1
      ⟨e,he,Finset.mem_union_left _ (eq ▸ lin.1)⟩
      (fun e he => lin.2.2.2.2.1 e he)
    intro f hf
    rcases account f hf with hr | core | tail | ⟨q,hq,step⟩
    · exact Or.inl (lin.2.2.2.2.1 f hr)
    · obtain ⟨a,b⟩ := lin.2.2.2.2.2.1 f core
      exact Or.inr (Or.inl ⟨Finset.mem_union_left _ a,Finset.mem_union_left _ b⟩)
    · have dst_mem : dst f∈es.map dst := List.mem_map.mpr ⟨_,tail,rfl⟩
      have out := collected dst_mem
      have st := sources r tail
      have ins : proj (src f)∈A := by
        rcases List.mem_cons.mp st with sv | st
        · exact Finset.mem_union_left _ (sv ▸ lin.2.1)
        · exact collected st
      exact Or.inr (Or.inl ⟨ins,out⟩)
    · have pair := lin.2.2.2.2.2.2 q (legit hq) f step
      exact Or.inr (Or.inr ⟨_,Finset.mem_image_of_mem _ hq,pair⟩)
  have uu : U.card≤6 := seven_destinations r ww k
  have aa : A.card≤390 := (Finset.card_union_le ..).trans (by rw [data.2.1]; omega)
  have bb : B.card≤66 := Finset.card_image_le.trans few
  have small : A.card+5*B.card≤allClasses.card := by rw [data.2.2.2.1]; omega
  have inW : B ⊆ allWheels := Finset.image_mono _ legit
  have block := data.2.2.2.2.2.2
  have sub : forbidden⊆U := by
    intro d hd
    have inside := forced_by_seed seen A allClasses B d Finset.subset_union_left
      (data.2.2.2.2.1 hd) (fun w hw => (block w (inW hw)).1.le) small
      (fun w hw dw => (block w (inW hw)).2 d hd dw) cover
    exact (Finset.mem_union.mp inside).resolve_left (fun mem =>
      Finset.disjoint_left.mp data.2.2.2.2.2.1 mem hd)
  have bound := Finset.card_le_card sub
  rw [data.2.2.1] at bound
  omega

#print axioms every_seven_edge_tail_fails
end Prefix455

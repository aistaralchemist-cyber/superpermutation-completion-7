import FrontWindowIndex
import FrontBinary

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows CoreRecordBits SortedCoreRecords CoreCandidateBanks FrontRawBudget
open CompactFrontPlan FrontLocalMeaning

private theorem projectRows (f : α→γ) (g : β→δ) {R : α→β→Prop} {S : γ→δ→Prop}
    (post : ∀a b,R a b → S (f a) (g b)) {xs : List α} {ys : List β}
    (h : List.Forall₂ R xs ys) : List.Forall₂ S (xs.map f) (ys.map g) := by
  induction h with
  | nil => exact .nil
  | cons h _ ih => exact .cons (post _ _ h) ih

def recordsSpec (v : Nat→Bool) (w : Block) (out : Rows × Bits × Bits) :=
    List.Forall₂ (fun r ws=>BitsRep v ws r) out.1.toList ((wordRows digits w).map rowWires) ∧
    BitsRep v (cleanSignals w).toArray out.2.1 ∧ BitsRep v (winSignals w).toArray out.2.2

theorem after_triples {w : Block} (len : w.length=1501) {v : Nat→Bool}
    {ts : List (Bits × W × W)} (h : List.Forall₂ (rowRep v) ((List.range 1496).map (tripleAt w)) ts) :
    recordsSpec v w ((ts.map Prod.fst).toArray,(ts.map (fun r=>r.2.1)).toArray,
      ((ts.take 1495).map (fun r=>r.2.2)).toArray) := by
  rw [triple_table len] at h
  have rs := projectRows Prod.fst Prod.fst (S:=BitsRep v) (fun _ _ val=>val.1) h
  have cls := projectRows (fun r=>r.2.1) (fun r=>r.2.1) (S:=Rep v) (fun _ _ val=>val.2.1) h
  have short := List.forall₂_take 1495 h
  have cutH : (windows w).length=1495 := by simp [windows_length,len]
  have bound : ((windows w).map (fun p=>(rowWires (windowRow digits p),clean (src p),decide p.Nodup))).length=1495 := by simpa only [List.length_map] using cutH
  rw [←bound,List.take_left,bound] at short
  have wins := projectRows (fun r=>r.2.2) (fun r=>r.2.2) (S:=Rep v) (fun _ _ val=>val.2.2) short
  refine ⟨?_,?_,?_⟩
  · apply List.Forall₂.flip
    simpa [flip,wordRows,List.map_map,Function.comp_def] using rs
  · simpa [BitsRep,cleanSignals,List.map_map,Function.comp_def] using cls
  · simpa [BitsRep,winSignals,List.map_map,Function.comp_def,bound] using wins


set_option maxHeartbeats 1800000 in
set_option maxRecDepth 8192 in
theorem records_from_ports {T : Test} {v : Nat→Bool} (law : ModelsGates T v) (unit : v 0=true)
    {w : Block} (len : w.length=1501) {cols : Rows}
    (hc : ArrayRel (RowRep v 7) cols ((Array.range 1501).map (hot w)))
    (ports : ∀ bs, ArrayRel (fun r b=>BitsRep v (rawBinary b) r) bs ((Array.range 1501).map (hot w)) →
      ∀i,i<1496 → BitsRep v (inputPorts (sliceAt w i 6)) (recordPorts cols bs i))
    (nextPort : ∀i, BitsRep v (optionalHot (w[i+6]?)) ((cols[i+6]?).getD #[])) :
    Gives T (frontPhase cols) (fun out=>
      List.Forall₂ (fun r ws=>BitsRep v ws r) out.1.toList ((wordRows digits w).map rowWires) ∧
      BitsRep v (cleanSignals w).toArray out.2.1 ∧ BitsRep v (winSignals w).toArray out.2.2) := by
  let gr (bs : Rows) (i : Nat) := frontRecord_grows (recordPorts cols bs i) ((cols[i+6]?).getD #[]) (decide (i+7≤1501)) true
  unfold frontPhase
  refine bind_gives (m:=cols.mapM (binary · 3)) (k:=fun bs=>frontSeven cols bs 1501 true)
    (P:=fun bs=>ArrayRel (fun r b=>BitsRep v (rawBinary b) r) bs ((Array.range 1501).map (hot w))) (Q:=recordsSpec v w)
    (mapArray_grows binary_grows _) (fun bs=>bind_grows (mapList_grows (gr bs) _) (fun _=>pure_grows _))
    (binary_cols_gives law unit hc) ?_
  intro bs hb
  let stages (i : Nat) := frontRecord (recordPorts cols bs i) ((cols[i+6]?).getD #[]) (decide (i+7≤1501)) true
  have each (i : Nat) (hi : i∈List.range 1496) : Gives T (stages i) (rowRep v (tripleAt w i)) := by
    have hsize : (w[i+6]?).isSome=decide (i+7≤1501) := by
      by_cases yes : i+6<w.length
      · rw [getElem?_pos w (i+6) yes,decide_eq_true (show i+7≤1501 by omega)]
        rfl
      · rw [getElem?_neg w (i+6) yes,decide_eq_false (show ¬i+7≤1501 by omega)]
        rfl
    have tc : tripleAt w i = pureRow (inputPorts (sliceAt w i 6)) (optionalHot (w[i+6]?)) (decide (i+7≤1501)) true :=
      congrArg (fun yes=>pureRow (inputPorts (sliceAt w i 6)) (optionalHot (w[i+6]?)) yes true) hsize
    rw [tc]
    exact frontRecord_gives law unit (ports bs hb i (List.mem_range.mp hi)) (nextPort i) _ _
  unfold frontSeven
  exact bind_gives (m:=(List.range 1496).mapM stages) (P:=List.Forall₂ (fun i x=>rowRep v (tripleAt w i) x) (List.range 1496)) (Q:=recordsSpec v w) (mapList_grows (gr bs) _) (fun _=>pure_grows _)
    (mapList_gives (gr bs) _ each) (fun ts h=>pure_gives (after_triples len (replace_left h)))


end ExactWordFlow.CompactWordCircuit

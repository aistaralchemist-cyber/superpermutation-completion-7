import CoreControls

namespace ExactWordFlow.Boundary1515
open RotationCoreControls

/-- Both controls cover all 720 rotation classes. -/
theorem reference627 :
    summary (coreWord 627)=(1516,720,93) ∧
    summary (coreTruncated 627)=(1515,720,92) := by native_decide

#print axioms reference627
end ExactWordFlow.Boundary1515

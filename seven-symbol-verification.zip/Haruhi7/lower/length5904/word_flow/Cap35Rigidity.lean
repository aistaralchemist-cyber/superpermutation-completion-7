import Cap35Window
import WheelContacts

namespace ExactWordFlow.Cap35Rigidity
open ResidualDensity WheelContacts
open private rigid rigid_hop from ResidualDensity
open private localMark from DensityBudget

def shape (s : Six) : Finset Six := (Finset.range 5).biUnion (fun k=>wheel (hop^[k] s))

private theorem phase {p : Nat→Prop} [DecidablePred p] (atZero : count p 0 7=6)
    (rep : ∀i,p (i+7)↔p i) : ∃b : Nat,∀k : Nat,∀j<6,p (b+7*k+j) := by
  let H:=(Finset.range 7).filter (fun j=>¬p j)
  have no:=Finset.card_filter_add_card_filter_not (s:=Finset.range 7) (p:=p)
  have six:((Finset.range 7).filter p).card=6:=by simpa only [count,Nat.zero_add] using atZero
  have size:H.card=1:=by dsimp [H]; rw [six,Finset.card_range] at no; omega
  obtain ⟨a,ha⟩:=Finset.card_eq_one.mp size
  have aH:a∈H:=by rw [ha]; simp
  have bound:=Finset.mem_range.mp (Finset.mem_filter.mp aH).1
  have positive (j) (hj:j<7) (ne:j≠a) : p j:=by
    by_contra bad
    have yes:j∈H:=Finset.mem_filter.mpr ⟨Finset.mem_range.mpr hj,bad⟩
    rw [ha,Finset.mem_singleton] at yes
    exact ne yes
  have periodic (z n:Nat) : p (z+7*n)↔p z:=by
    induction n with
    | zero => simp
    | succ n ih => rw [Nat.mul_succ,←Nat.add_assoc,rep,ih]
  refine ⟨a+1,fun k j hj=>?_⟩
  let n:=a+1+7*k+j
  have nn:n%7≠a:=by dsimp [n]; omega
  have yes:=positive (n%7) (Nat.mod_lt _ (by decide)) nn
  have result:=(periodic (n%7) (n/7)).mpr yes
  rw [Nat.mod_add_div] at result
  exact result

/-- The five run starts are forced by one full six-context. Each run
rotates that context exactly five times, the seam then cycles its first
five letters while leaving its sixth letter fixed. -/
theorem spelling {u : Nat→Six} {p : Nat→Prop} [DecidablePred p] (walk : Walk u)
    (mark : CyclicMarked u p 35) (counted : count p 0 35=30) :
    ∃b,full (u b) ∧ ∀k<5,∀j<6,
      p (b+7*k+j) ∧ u (b+7*k+j)=(hop^[k] (u b)).rotate j := by
  obtain ⟨each,rep⟩:=SaturatedCyclicWindow.cycle35 walk mark counted
  obtain ⟨b,good⟩:=phase (each 0) rep
  let M:=localMark (i:=b) (b:=35) mark (Nat.le_refl _)
  have marks (k) (hk:k<5) (j) (hj:j≤5) : p (b+7*k+j) ∧ b≤b+7*k+j ∧ b+7*k+j<b+35:=
    ⟨good k j (by omega),by omega,by omega⟩
  have bases (k) (hk:k<5) : u (b+7*k)=hop^[k] (u b):=by
    induction k with
    | zero => simp
    | succ k ih =>
      have nex:=rigid_hop walk M (b+7*k) (marks k (by omega)) (by
        intro j hj
        simpa only [Nat.mul_succ,←Nat.add_assoc] using marks (k+1) hk j hj)
      simpa only [Nat.mul_succ,←Nat.add_assoc,Function.iterate_succ_apply',ih (by omega)] using nex
  refine ⟨b,mark.clean b (by simpa using good 0 0 (by decide)),?_⟩
  intro k hk j hj
  exact ⟨good k j hj,(rigid walk M (b+7*k) j (fun d hd=>marks k hk d (by omega))).trans
    (congrArg (fun z : Six=>z.rotate j) (bases k hk))⟩

#print axioms spelling
end ExactWordFlow.Cap35Rigidity

import RauzyBudget
import Record071
import CoreControls

namespace ExactWordFlow.RauzyControls
open RauzyBudget RotationCore RotationCoreControls

@[noinline] private def countWheels (seen : Finset Block) : Nat :=
  (WheelContacts.bases.toFinset.filter (fun q => CompleteCycleRank.wheelFactors q ⊆ seen)).card

def counts (w : Block) : List Nat := Id.run do
  let seen:=(SevenWordWindows.windows w).toFinset
  let c:=(complete w).card
  let v:=(visited w).card
  let h:=countWheels seen
  let n:=d₆ w
  let m:=seen.card
  return [w.length,v,c,n,m,h,n-(v+6*c),(SevenWordWindows.windows w).length-m,(m+1)-(n+c+h)]

theorem counts_spec (w : Block) : counts w =
    [w.length,(visited w).card,(complete w).card,d₆ w,d₇ w,wheels w,
    extraContexts w,repeats w,otherRank w] := rfl

/-- Exact equality in the cycle-rank bound on both sides of the target. -/
theorem one_letter :
    counts (coreTruncated 612)=[1620,720,107,1442,1614,66,80,0,0] ∧
    counts (coreWord 612)=[1621,720,108,1442,1615,66,74,0,0] := by native_decide

theorem smaller :
    counts (coreTruncated 625)=[1529,720,94,1364,1523,66,80,0,0] ∧
    counts (coreWord 625)=[1530,720,95,1364,1524,66,74,0,0] := by native_decide

/-- Dropping the other-rank term would give a false universal lower bound of 140. -/
theorem necessary_term :
    counts Record071.word=[5905,720,720,5116,5899,62,76,0,2] := by native_decide

private def trimmed071 : Block := Id.run do
  let source:=Record071.word
  let a:=source.toArray
  let laps:=(List.range (source.length-12)).filter fun i =>
    i != 0 && decide (a.extract i (i+7)).toList.Nodup &&
      a.extract i (i+6) == a.extract (i+7) (i+13)
  let erased:=((laps.take 612).flatMap fun i => (List.range 7).map (i+·)).toFinset
  return source.zipIdx.filterMap fun (c,i) => if i=0 ∨ i∈erased then none else some c

/-- On an actual all-visiting 1620-letter core, the cycle-rank inequality
alone permits 109 completions; the last two rank units are genuinely needed. -/
theorem loose_at_1620 :
    counts trimmed071=[1620,720,107,1444,1614,62,82,0,2] := by native_decide

#print axioms loose_at_1620
#print axioms one_letter
#print axioms necessary_term
end ExactWordFlow.RauzyControls

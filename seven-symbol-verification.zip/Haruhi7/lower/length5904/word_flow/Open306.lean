import CoreControls

namespace ExactWordFlow.Open306
open SevenWordWindows RotationCore

def path : Block := "012345013245013425013452013450213450123405123401523401253401235401325401352401354201354021350421350241350214350124350142350143250143520145320145230145203145023145032145031245031425034125043125041325041235041253041523041532041530241530421534021534201534210534120534102534105234105324103524103254103245103241503241".toList.map (fun c=>Fin.ofNat 7 (c.toNat-'0'.toNat))

/-- The 306-edge open component's required count is achievable by an
actual spelling. This does not assume there is a compatible wheel cover. -/
theorem control : path.length=312 ∧ (visited path).card=260 := by native_decide

#print axioms control
end ExactWordFlow.Open306

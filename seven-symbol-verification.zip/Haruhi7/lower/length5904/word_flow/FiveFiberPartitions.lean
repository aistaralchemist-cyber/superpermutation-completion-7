import FiveFiberMerge
import ExtremeWheelCut

namespace ExactWordFlow.FiveFiberMerge
open SevenWordWindows ResidualDensity WheelContacts ExtremeWheelCut

def fitRows (d : Block) := allRows.filter (fun R=>R⊆group d)
-- Restrict the power set to ten local rows before checking five-row covers.
private theorem local_partitions : ∀d∈fiveOrders,
    fitRows d=((familyRows d true).toFinset ∪ (familyRows d false).toFinset) ∧
    ∀S∈((familyRows d true).toFinset ∪ (familyRows d false).toFinset).powersetCard 5,
      group d⊆S.biUnion id →
      S=(familyRows d true).toFinset ∨ S=(familyRows d false).toFinset := by native_decide

private theorem sizes : ∀r∈allRows, r.card=6 := by native_decide

/-- No assumption on the omissions, the order of the rows, or disjointness.
There are only two five-wheel covers of each thirty-class fiber. -/
theorem only_partitions {d : Block} (hd : d∈fiveOrders) {S : Finset (Finset Block)}
    (leg : S⊆allRows) (cap : S.card≤5) (covers : group d⊆S.biUnion id) :
    S=(familyRows d true).toFinset ∨ S=(familyRows d false).toFinset := by
  have bd:=Finset.card_biUnion_le_card_mul S id 6 (fun r hr=>(sizes r (leg hr)).le)
  have low:=Finset.card_le_card covers
  rw [(wheel_trade.2 d hd).1] at low
  have sz : S.card=5 := by omega
  have eq:group d=S.biUnion id := Finset.eq_of_subset_of_card_le covers (by rw [(wheel_trade.2 d hd).1];omega)
  obtain ⟨shape,parts⟩:=local_partitions d hd
  apply parts S _ covers
  apply Finset.mem_powersetCard.mpr
  refine ⟨?_,sz⟩
  rw [←shape]
  intro R hR
  apply Finset.mem_filter.mpr
  refine ⟨leg hR,?_⟩
  rw [eq]
  exact Finset.subset_biUnion_of_mem id hR

private def shadow (v : Bool) (R : Finset Block) :=
  R.image (fun c=>classKey (c.filter (fun a=>decide (a≠omitted v))))
private theorem signature : ∀u∈states, ∀v : Bool,
    ((shadow v (wheel u)).card=1 ↔ omitted v∉u) := by native_decide

def physicallyRealized (w : Block) (R : Finset Block) :=
  ∃u∈states, wheel u=R ∧ (u++u.take 5) <:+: w

/-- Arbitrary five physical wheels covering each fiber, including any ordering
and overlapping occurrences, are subject to the same six-symbol floor. -/
theorem any_five_floor {w : Block} (all : ∀d∈fiveOrders, ∃S : Finset (Finset Block),
    S⊆allRows ∧ S.card≤5 ∧ group d⊆S.biUnion id ∧ ∀R∈S,physicallyRealized w R) :
    870≤w.length := by
  apply physical_floor
  intro d hd
  obtain ⟨S,leg,cap,covers,real⟩:=all d hd
  have choose (v : Bool) (eq : S=(familyRows d v).toFinset) : literalRows w d v := by
    intro R hR
    have mem : R∈S := eq ▸ List.mem_toFinset.mpr hR
    obtain ⟨u,hu,ur,occ⟩:=real R mem
    obtain ⟨s,hs,sr⟩:=List.mem_map.mp hR
    obtain ⟨hc,both⟩:=List.mem_filter.mp hs
    have st:= (List.mem_filter.mp hc).1
    have notIn : omitted v∉s := (of_decide_eq_true both).1
    have sig := (signature s st v).2 notIn
    rw [sr,←ur] at sig
    exact ⟨u,hu,(signature u hu v).1 sig,ur,occ⟩
  rcases only_partitions hd leg cap covers with yes|no
  · exact ⟨true,choose true yes⟩
  · exact ⟨false,choose false no⟩

#print axioms only_partitions
#print axioms any_five_floor
end ExactWordFlow.FiveFiberMerge

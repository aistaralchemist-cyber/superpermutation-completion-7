import Cap95Shape

namespace ExactWordFlow.Cap94Prices
open SevenWordWindows ResidualDensity DirectedEuler ResidualRoutes ResidualIncidence RotationComponentCount GlobalDensity66
open scoped Classical
open private open95 closed137 from Cap95Shape
open private initial from MarkedDensity
open private two_mass closed111 from MarkedLargeCap
open private cyclic_cap closed_price from GlobalDensity66
open private all_contacts from OverlapBudget

private def close94 (k : Nat) := min (min (min (min (56*k/66) (if 111≤k then 94*k/111 else 720))
  (if 137≤k then 116*k/137 else 720)) (if 92≤k then 78*k/92 else 720))
  (if 208≤k then 176*k/208 else 720)

private theorem scalar94 : ∀ r b : Fin 301,79≤b.val → r.val+b.val≤300 →
    6*(open95 r.val-1)+6*(close94 b.val-1)<5*(r.val+b.val)+24 := by native_decide

private theorem period_price {a : Block} {p : List Block} (r : Route src dst a p a)
    (wd : ∀e∈p,e.length=7) (n k : Nat) (size : 1≤n) (lo : n≤p.length) (small : n≤289)
    (bound : Cap95Marked.upper n initial≤k) : n*classCount a p≤k*p.length := by
  obtain ⟨u,I,w,hm,cc⟩:=closed_observations r wd (by omega)
  have q:=window_cyclic_bound hm lo (fun i pp _ hh=>(Cap95Marked.interval_upper w hh i n small).trans bound)
  simpa only [cc] using q

private theorem closed92 {a : Block} {p : List Block} (r : Route src dst a p a)
    (wd : ∀e∈p,e.length=7) (lo : 92≤p.length) : 92*classCount a p≤78*p.length :=
  period_price r wd 92 78 (by decide) lo (by decide) (by native_decide)
private theorem closed208 {a : Block} {p : List Block} (r : Route src dst a p a)
    (wd : ∀e∈p,e.length=7) (lo : 208≤p.length) : 208*classCount a p≤176*p.length :=
  period_price r wd 208 176 (by decide) lo (by decide) (by native_decide)

theorem large_count
    {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (paid : 66*separateRank X s+6*(active X s).card+60*(large X s).card≤56*X.card+66)
    (hasBig : (large X s).Nonempty) : (occupied X s).card≤93 := by
  classical
  rw [occupied_active h]
  by_contra! many
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  let C (q : Component X) := (contacts (support X s) (label X) q).card
  have rk : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  obtain ⟨qBig,hBig⟩:=hasBig
  obtain ⟨bigIn,away,atleast⟩:=Finset.mem_filter.mp hBig
  change qBig∈Q at bigIn
  change qBig≠home at away
  change 79≤K qBig at atleast
  have bigOnly : (large X s).card≤1 := by omega
  have actBig : qBig∈active X s := Finset.mem_filter.mpr ⟨bigIn,away,show 6≤K qBig by omega⟩
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q=X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have raw : 6*(active X s).card+K home+K qBig≤X.card+6 := two_mass actBig
  have leftMass : K home+K qBig≤300 := by omega
  have get (q) (hq : q∈Q) :
      (q=home → C q≤open95 (K q)) ∧
      (q=qBig → C q≤close94 (K q)) ∧
      (q≠home → q≠qBig → 6*(C q-1)≤5*K q) := by
    obtain ⟨v,_,vv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩:=component_route h.balance v
    rw [vv] at eq lv ep
    have len : es.length=K q := congrArg Multiset.card eq
    have wd (e) (he : e∈es) := h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have incl : C q≤classCount a es:=contacts_bound _ lv r eq
    refine ⟨?_,?_,?_⟩
    · intro atHome
      have lim : es.length+1≤289 := by rw [len,atHome]; omega
      simpa only [open95,len] using incl.trans (Cap95Marked.route_upper r wd lim)
    · rintro rfl
      obtain ⟨aa,bb⟩:=ep.2 away
      subst a; subst b
      change 79≤K q at atleast
      have lo:=cyclic_cap r wd (by omega)
      unfold close94
      refine le_min (le_min (le_min (le_min (by omega) ?_) ?_) ?_) ?_
      · split
        next yes => have cl:=closed111 r wd (by omega); omega
        next => exact all_contacts ..
      · split
        next yes => have cl:=closed137 r wd (by omega); omega
        next => exact all_contacts ..
      · split
        next yes => have cl:=closed92 r wd (by omega); omega
        next => exact all_contacts ..
      · split
        next yes => have cl:=closed208 r wd (by omega); omega
        next => exact all_contacts ..
    · intro notRoot notBig
      obtain ⟨aa,bb⟩:=ep.2 notRoot
      subst a; subst b
      have small : es.length<79 := by
        by_contra! bad
        have seen : q∈large X s := Finset.mem_filter.mpr ⟨hq,notRoot,show 79≤K q by omega⟩
        exact notBig (Finset.card_le_one.mp bigOnly _ seen _ hBig)
      have cl:=closed_price r wd small
      omega
  have compare (q) (hq : q∈Q) :
      6*(C q-1)+(if q=home then 5*K home else 0)+(if q=qBig then 5*K qBig else 0)≤
        5*K q+(if q=home then 6*(C home-1) else 0)+(if q=qBig then 6*(C qBig-1) else 0) := by
    by_cases R : q=home
    · subst q; simp [Ne.symm away,Nat.add_comm]
    by_cases B : q=qBig
    · subst q; simp [away,Nat.add_comm]
    simpa [R,B] using (get q hq).2.2 R B
  have bound:=Finset.sum_le_sum compare
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_ite_eq',root,bigIn,ite_true,total] at bound
  change 6*separateRank X s+5*K home+5*K qBig≤_ at bound
  have hroot:=(get home root).1 rfl
  have hbig:=(get qBig bigIn).2.1 rfl
  have check:=scalar94 ⟨K home,by omega⟩ ⟨K qBig,by omega⟩ atleast leftMass
  change 6*(open95 (K home)-1)+6*(close94 (K qBig)-1)<5*(K home+K qBig)+24 at check
  omega

#print axioms large_count
end ExactWordFlow.Cap94Prices

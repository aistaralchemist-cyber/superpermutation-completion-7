import LapShadowOrbit

namespace ExactWordFlow.LapDeletionShadow
open SevenWordWindows RotationCore DeletionShadow
open private capacityOn from DeletionShadow

private def name (a : Fin 7) (u : Block) :=u.rotate (u.idxOf (if a=0 then 1 else 0))

private theorem names : ∀a∈List.finRange 7,∀d∈board6 a,∀q∈turns d,name a q=d := by native_decide

private theorem fold_agree (ps : List Block) (f g : Block→Nat) (z : Nat)
    (agree : ∀p∈ps,f p=g p) :
    ps.foldl (fun n p=>min n (f p)) z=ps.foldl (fun n p=>min n (g p)) z := by
  induction ps generalizing z with
  | nil => rfl
  | cons p ps ih =>
    simp only [List.foldl_cons,agree p List.mem_cons_self]
    exact ih _ (fun x hx=>agree x (List.mem_cons_of_mem _ hx))

private theorem fold_bound (ps : List Block) (f : Block→Nat) (k z : Nat) :
    ps.foldl (fun n p=>min n (f p)) (min k z)=min k (ps.foldl (fun n p=>min n (f p)) z) := by
  induction ps generalizing z with
  | nil => rfl
  | cons p ps ih =>
    simp only [List.foldl_cons,Nat.min_assoc]
    apply ih

private theorem fold_step (ps : List Block) (f : Block→Nat) (z : Nat) :
    ps.foldl (fun n p=>min n (f p+1)) (z+1)=ps.foldl (fun n p=>min n (f p)) z+1 := by
  induction ps generalizing z with
  | nil => rfl
  | cons p ps ih =>
    simp only [List.foldl_cons]
    rw [show min (z+1) (f p+1)=min z (f p)+1 by omega]
    exact ih _

theorem capacity_step (a : Fin 7) (l p r : Block) (hp : p∈representatives) {d : Block}
    (hd : d∈board6 a) :
    capacity a (l++p++p.take 6++r) d =
      if d=proj a (classKey p) then min 6 (capacity a (l++p.take 6++r) d + 1)
      else capacity a (l++p.take 6++r) d := by
  let b:=proj a (classKey p)
  let f (q : Block):=(sixWindows (erase a (l++p.take 6++r))).count q
  let g (q : Block):=(sixWindows (erase a (l++p++p.take 6++r))).count q
  have member : classKey p∈allClasses := List.mem_toFinset.mpr (List.mem_map_of_mem hp)
  have inB : b∈board6 a := Finset.mem_image_of_mem _ member
  have step (q : Block) : g q=f q+(if q∈turns b then 1 else 0):=one_count a l p r q hp
  change (turns d).foldl (fun v q=>min v (g q)) 6 =
    if d=b then min 6 ((turns d).foldl (fun v q=>min v (f q)) 6 + 1) else (turns d).foldl (fun v q=>min v (f q)) 6
  by_cases eq : d=b
  · subst d
    simp only [ite_true,eq_self]
    have h (q) (hq : q∈turns b) : g q=f q+1:=by simp [step,hq]
    rw [fold_agree _ _ _ _ h]
    have m:=fold_bound (turns b) (fun q=>f q+1) 6 7
    rw [show min 6 7=6 by decide] at m
    rw [m,fold_step (turns b) f 6]
  · rw [ite_eq_right eq]
    apply fold_agree (turns d) g f 6
    intro q hq
    have a1:=names a (List.mem_finRange _) d hd q hq
    have absent : q∉turns b:=fun h=>eq (a1.symm.trans (names a (List.mem_finRange _) b inB q h))
    simp [step,absent]

theorem at_most (a : Fin 7) (w d : Block) : capacity a w d≤6 := by
  let f (q : Block):=(sixWindows (erase a w)).count q
  have bound (ps : List Block) (z : Nat) : ps.foldl (fun n p=>min n (f p)) z≤z := by
    induction ps generalizing z with
    | nil => simp
    | cons p ps ih => exact (ih _).trans (Nat.min_le_left ..)
  exact bound _ _

/-- Any sequence of literal lap removals acts on a projected capacity row by
adding the number of removed classes that map to the row, capped at six. -/
theorem capacity_many (a : Fin 7) {w z : Block} {ps : List Block} (cuts : Cuts w ps z)
    {d : Block} (hd : d∈board6 a) :
    capacity a w d=min 6 (capacity a z d+(ps.filter (fun p=>decide (d=proj a (classKey p)))).length) := by
  induction cuts with
  | stop w => simpa [Nat.min_eq_right (at_most a w d)]
  | @remove l p r ps z hp rest ih =>
    rw [capacity_step a l p r hp hd,ih]
    by_cases eq : d=proj a (classKey p) <;> simp [List.filter_cons,eq] <;> omega

#print axioms capacity_many
#print axioms capacity_step
end ExactWordFlow.LapDeletionShadow

import CanonicalBaseSpare
import BaseRootTags
import SplitWheelPrice
import ContactSurplus

namespace ExactWordFlow.CompletedSpareRanks
open SevenWordWindows ResidualDensity ResidualRoutes ResidualIncidence RotationCore RotationReinsert RotationSpan
open CoreAssembly WheelBaseResidual ConnectorSavings RotationComponentCount LiteralWheelCover EmbeddedWheels
open scoped Classical
open private both from RotationSpan
open private required_data from ResidualIncidence
open private sizes from EmbeddedWheels
open private base_groups from ConnectorSavings

theorem base_spans {b:Block} {Y:Multiset Block} (long:6≤b.length)
    (split:mandatory (complete b)+Y=bag b) :
    ∀v∈terminals Y (b.take 6),
      label (selected Y (complete b)) v=label (selected Y (complete b)) (b.take 6) := by
  let Z:=selected Y (complete b)
  have eq : bag b=Z:=by rw [←split];exact add_comm ..
  have r:=read_route b long
  let S : Set Block:={v | label Z v=label Z (b.take 6)}
  have step (e) (he:e∈windows b) (hs:src e∈S) : dst e∈S :=
    (on_edge (X:=Z) (eq ▸ (show e∈bag b from he))).symm.trans hs
  have all:=r.closed S rfl step
  intro v hv
  change v∈S
  rcases Finset.mem_insert.mp hv with rfl|rest
  · rfl
  · rcases Finset.mem_union.mp rest with srcV|dstV
    · obtain ⟨e,he,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp srcV)
      exact all.2 e (show e∈bag b from split ▸ Multiset.mem_add.mpr (Or.inr he))
    · obtain ⟨e,he,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp dstV)
      have inside:e∈bag b:=split ▸ Multiset.mem_add.mpr (Or.inr he)
      exact step e inside (all.2 e inside)

theorem completed_capacity {b:Block} {Y:Multiset Block} (long:6≤b.length)
    (split:mandatory (complete b)+Y=bag b) :
    (occupied Y (b.take 6)).card≤∑c∈complete b,((attachments Y (b.take 6) c).card-1) :=
  necessary (base_spans long split)

theorem shared_is_complete {b:Block} {Y:Multiset Block} {t c:Block} (long:6≤b.length)
    (split:mandatory (complete b)+Y=bag b) (h:Feasible Y (b.take 6) t)
    (tight:separateRank Y (b.take 6)=719) (hc:c∈allClasses)
    (twice:2≤(attachments Y (b.take 6) c).card) : c∈complete b :=
  forced_at_equality h tight (fun d hd=>((mem_complete b d).mp hd).1)
    (base_spans long split) hc twice

private theorem terminal_support_bal {X : Multiset Block} {s t : Block} (bal:X.map src+{t}=X.map dst+{s}) :
    terminals X s ⊆ support X s := by
  intro v hv
  rcases Finset.mem_insert.mp hv with rfl|others
  · exact Finset.mem_insert_self ..
  have enter (v) (hit : v∈X.map dst) : v∈support X s :=
    Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr (by
      rw [Multiset.map_add]; exact Multiset.mem_add.mpr (Or.inr hit)))
  rcases Finset.mem_union.mp others with outgoing|incoming
  · have pos : v∈X.map src+{t} := Multiset.mem_add.mpr (Or.inl (Multiset.mem_toFinset.mp outgoing))
    rw [bal] at pos
    rcases Multiset.mem_add.mp pos with other|home
    · exact enter v other
    · have eq : v=s := by simpa using home
      exact eq ▸ Finset.mem_insert_self ..
  · exact enter v (Multiset.mem_toFinset.mp incoming)


private theorem partial_dual {X : Multiset Block} {s t : Block} (bal:X.map src+{t}=X.map dst+{s})
    (P:Finset Block) (seen:∀c∈P,∃v∈terminals X s,full v ∧ tag v=c) :
    (∑c∈P,((attachments X s c).card-1))+P.card ≤ (occupied X s).card+separateRank X s+1 := by
  classical
  let Q := (terminals X s).image (label X)
  let I := attachments X s
  let C := fun q=> (contacts (support X s) (label X) q).card
  have sub (c) : I c⊆Q := Finset.image_subset_image (Finset.filter_subset ..)
  have row (c) : (I c).card=∑q∈Q,if q∈I c then 1 else 0 := by
    rw [Finset.sum_boole]
    congr 1
    ext x; simp +contextual [sub c]
  have col (q) : (∑c∈P,if q∈I c then 1 else 0)≤C q := by
    rw [Finset.sum_boole]
    apply Finset.card_le_card
    intro c hc
    obtain ⟨v,hv,eq⟩:=Finset.mem_image.mp (Finset.mem_filter.mp hc).2
    obtain ⟨there,clean,key⟩:=Finset.mem_filter.mp hv
    exact Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨terminal_support_bal bal there,eq,clean⟩,key⟩
  have inc : (∑c∈P,(I c).card) ≤∑q∈Q,C q := by
    simp_rw [row]
    rw [Finset.sum_comm]
    exact Finset.sum_le_sum (fun q _=>col q)
  have positive (c) (hc : c∈P) : 0<(I c).card := by
    obtain ⟨v,hv,clean,tagEq⟩:=seen c hc
    exact Finset.card_pos.mpr ⟨_,Finset.mem_image_of_mem _ (Finset.mem_filter.mpr ⟨hv,clean,tagEq⟩)⟩
  have adjust := Finset.sum_congr (s₁:=P) (s₂:=P) rfl
    (fun c hc => show (I c).card=(I c).card-1+1 by have := positive c hc; omega)
  simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] at adjust
  have pieces := Finset.sum_le_sum (s:=Q) (fun q _=>show C q≤(C q-1)+1 by omega)
  simp only [Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] at pieces
  have lim : (∑q∈Q,(C q-1))≤ separateRank X s :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.image_subset_image (terminal_support_bal bal)) (by intros; omega)
  have qn : Q.card=(occupied X s).card+1:=base_groups X s
  change (∑c∈P, ((I c).card-1))+P.card≤_
  omega


private theorem every_visited {b:Block} {Y:Multiset Block} (long:6≤b.length)
    (split:mandatory (complete b)+Y=bag b) {c:Block} (hc:c∈visited b) :
    ∃u∈terminals Y (b.take 6),full u ∧ tag u=c := by
  classical
  by_contra! missing
  let S : Set Block:={v | full v → tag v≠c}
  have first:b.take 6∈S:=missing _ (Finset.mem_insert_self ..)
  have step (e) (he:e∈windows b) (hs:src e∈S) : dst e∈S:=by
    have mem:e∈mandatory (complete b)+Y:=split ▸ (show e∈bag b from he)
    rcases Multiset.mem_add.mp mem with mand|ext
    · obtain ⟨clean,_,eq⟩:=required_data e (Multiset.mem_filter.mp mand).1
      exact fun _ bad=>hs clean (eq.trans bad)
    · exact missing _ (both (b.take 6) ext).2
  have all:=(read_route b long).closed S first step
  obtain ⟨u,hu,fu,key⟩:=(mem_visited b c).mp hc
  rcases List.mem_cons.mp hu with yes|later
  · exact first (yes ▸ fu) (yes ▸ key)
  · obtain ⟨e,he,rfl⟩:=List.mem_map.mp later
    exact step e he (all.2 e he) fu key

noncomputable def extraAttachments (Y : Multiset Block) (b : Block) : Nat := by
  classical
  exact ∑c∈visited b \ complete b,((attachments Y (b.take 6) c).card-1)

theorem partial_price {b:Block} {Y:Multiset Block} (long:6≤b.length)
    (split:mandatory (complete b)+Y=bag b) :
    (visited b).card+extraAttachments Y b ≤ separateRank Y (b.take 6)+1 := by
  have bm:=mandatory_data (complete b) (fun c hc=>((mem_complete _ _).mp hc).1)
  have balance:=(read_route b long).balance
  change (bag b).map src+_=(bag b).map dst+_ at balance
  rw [←split,Multiset.map_add,Multiset.map_add,bm.2,add_assoc,add_assoc] at balance
  have ub:=partial_dual (add_left_cancel balance) (visited b) (fun _ hc=>every_visited long split hc)
  have lb:=completed_capacity long split
  have parts:=Finset.sum_sdiff (f:=fun c=>(attachments Y (b.take 6) c).card-1) (complete_subset b)
  unfold extraAttachments
  omega

/-- Price outside shared labels and any excess visits beyond a perfect
five-new-label wheel cover together, on the actual same word for every k. -/
theorem unified {b v:Block} {rs:List Row} (ins:Inserts b rs v)
    (done:(complete b).card=92) (all:(visited v).card=720) (edge:v.length=1508) :
    let Y:=bag b-mandatory (complete b)
    let s:=b.take 6
    let nonhome:=((support Y s).image (label Y)).erase (label Y s)
    let B:=nonhome.filter (fun q=>7≤(part Y q).card)
    3*rs.length+45*(extraAttachments Y b+((visited b).card+5*rs.length-720))+25*B.card≤308 := by
  classical
  let Y:=bag b-mandatory (complete b)
  let s:=b.take 6
  have lb:=LapSkeleton.completed_floor b
  have space:(good b).length≤b.length-6:=by rw [←windows_length];exact List.length_filter_le ..
  have long:6≤b.length:=by omega
  have split:mandatory (complete b)+Y=bag b:=add_tsub_cancel_of_le (mandatory_in_bag b)
  have cap:=partial_price long split
  have points:=insertion_bound ins
  obtain ⟨ws,_,n,clean,h,total⟩:=actual_spare ins all long
  change Feasible (Y+turns ws) s _ at h
  have sz:=(sizes clean).1
  rw [Multiset.card_add,sz] at total
  have pr:=(rest_price (Essential.restBalance h (sizes clean).2)
    (fun e he=>h.edges_seven e (Multiset.mem_add.mpr (Or.inl he)))).1
  change 45*separateRank Y s+25*((((support Y s).image (label Y)).erase (label Y s)).filter
    (fun q=>7≤(part Y q).card)).card≤38*Y.card+59 at pr
  change (visited b).card+extraAttachments Y b ≤ separateRank Y s+1 at cap
  change Y.card+6*ws.length+7*(complete b).card+6=v.length at total
  dsimp only
  change 3*rs.length+45*(extraAttachments Y b+((visited b).card+5*rs.length-720))+
    25*((((support Y s).image (label Y)).erase (label Y s)).filter
      (fun q=>7≤(part Y q).card)).card≤308
  omega

theorem high_exact {b v:Block} {rs:List Row} (ins:Inserts b rs v)
    (done:(complete b).card=92) (all:(visited v).card=720) (edge:v.length=1508)
    (many:88≤rs.length) :
    extraAttachments (bag b-mandatory (complete b)) b=0 ∧ (visited b).card+5*rs.length=720 := by
  have bound:=unified ins done all edge
  dsimp only at bound
  have points:=insertion_bound ins
  omega

theorem zero_six {b:Block} (length:b.length=1508) (done:(complete b).card=92)
    (all:(visited b).card=720) : extraAttachments (bag b-mandatory (complete b)) b≤6 := by
  have bound:=unified (Inserts.stop b) done all length
  dsimp only at bound
  simp only [List.length_nil,Nat.mul_zero,Nat.add_zero,Nat.zero_add] at bound
  omega

#print axioms completed_capacity
#print axioms shared_is_complete
#print axioms unified
end ExactWordFlow.CompletedSpareRanks

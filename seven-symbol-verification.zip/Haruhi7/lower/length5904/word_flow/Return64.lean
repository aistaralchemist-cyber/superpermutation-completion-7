import Packet64
import ElevenExtensionCaps
import ExtendedSpineRank

namespace ExactWordFlow.OnePath66.Packet64
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels ResidualControls

/-- Joining a return route onto an open spine makes all its edges part of a single
root row. Only its new clean classes can contribute to connecting the 720 classes. -/
theorem no_return_of_cap {a b : Block} {es ws p : List Block} {F : Multiset Block}
    (r : Route src dst a es b) (rp : Route src dst b p a) (fl : full a)
    (legit : ∀u∈ws,full u) (n : ws.length≤64) (budget : p.length+F.card≤11)
    (cap : classCount a (es++p)+2 ≤ 390+p.length)
    (together : RequiredComponent.ClassesTogether (((↑es : Multiset Block)+turns ws)+(↑p+F))) :
    False := by
  have joined := join_routes r rp
  have seed : (pathClasses a (es++p)).Nonempty :=
    ⟨tag a, List.mem_toFinset.mpr (List.mem_map.mpr
      ⟨a,List.mem_filter.mpr ⟨List.mem_cons_self,decide_eq_true fl⟩,rfl⟩)⟩
  have eq : ((↑(es++p) : Multiset Block)+turns ws)+F = ((↑es : Multiset Block)+turns ws)+(↑p+F) := by
    simp only [←Multiset.coe_add]
    ac_rfl
  have rank := exchange_rank joined legit seed F F (fun _ h => h) (eq.symm ▸ together)
  omega

theorem no_reference_return {ws p : List Block} {F : Multiset Block}
    (rp : Route src dst (mainWord.drop (mainWord.length-6)) p (mainWord.take 6))
    (widths : ∀e∈p,e.length=7) (legit : ∀u∈ws,full u) (n : ws.length≤64)
    (budget : p.length+F.card≤11)
    (together : RequiredComponent.ClassesTogether ((bag mainWord+turns ws)+(↑p+F))) : False :=
  no_return_of_cap (read_route mainWord (by native_decide)) rp (by native_decide)
    legit n budget (ElevenExtensionCaps.route_return_cap rp widths (by omega)) together

#print axioms no_reference_return

#print axioms no_return_of_cap
end ExactWordFlow.OnePath66.Packet64

import ForcedRuns
import WheelContacts
namespace ResidualDensity.ForcedRuns
open WheelContacts
open private rigid rigid_hop from ResidualDensity

/-- Any two different six-mark runs in one witness select disjoint legal wheels. -/
theorem disjoint_rows {u : Nat→Six} {p : Nat→Prop} (w : Walk u) (h : Marked u p)
    {i j : Nat} (lt:i<j) (A:∀d<6,p (i+d)) (B:∀d<6,p (j+d)) :
    i+6≤j ∧ Disjoint (wheel (u i)) (wheel (u j)) := by
  have sep : i+6≤j:=by
    by_contra! overlap
    apply no_seven w h i
    intro d hd
    by_cases small:d<6
    · exact A _ small
    · have eq:i+d=j+(i+d-j):=by omega
      rw [eq];exact B _ (by omega)
  refine ⟨sep,Finset.disjoint_left.mpr ?_⟩
  intro c x y
  obtain ⟨a,ha,e⟩:=List.mem_map.mp (List.mem_toFinset.mp x)
  obtain ⟨b,hb,f⟩:=List.mem_map.mp (List.mem_toFinset.mp y)
  have sa:=List.mem_range.mp ha
  have sb:=List.mem_range.mp hb
  change tag ((u i).rotate a)=c at e
  change tag ((u j).rotate b)=c at f
  have li:=rigid w h i a (fun d hd=>A d (by omega))
  have lj:=rigid w h j b (fun d hd=>B d (by omega))
  have eq:tag (u (i+a))=tag (u (j+b)):=by rw [li,lj,e,f]
  have idx:=h.2 _ _ (A _ sa) (B _ sb) eq
  omega

theorem paired_seam {u : Nat→Six} {p : Nat→Prop} (w : Walk u) (h : Marked u p)
    {i : Nat} (A:∀d<6,p (i+d)) (B:∀d<6,p ((i+7)+d)) :
    u (i+7)=hop (u i) := rigid_hop w h i (fun j hj=>A j (by omega)) (fun j hj=>B j (by omega))

/-- Changing the omitted letter within one marked witness requires different
induced circular orders on the five common symbols. -/
theorem cross_order {u : Nat→Six} {p : Nat→Prop} (w : Walk u) (h : Marked u p)
    {i j : Nat} (lt:i<j) (A:∀d<6,p (i+d)) (B:∀d<6,p (j+d))
    {a b : Six} (ha:a∈bases) (hb:b∈bases) (ai:wheel a=wheel (u i))
    (bj:wheel b=wheel (u j)) (diff:missing a≠missing b) :
    ∀d<5,(afterGap a (missing b)).rotate d≠afterGap b (missing a) := by
  have dis:=(disjoint_rows w h lt A B).2
  rw [←ai,←bj] at dis
  have size:((wheel a)∩(wheel b)).card=0:=by simp [Finset.disjoint_iff_inter_eq_empty.mp dis]
  rw [wheel_contacts ha hb] at size
  have ne:a≠b:=fun e=>diff (congrArg missing e)
  unfold gapCount at size
  simp only [ite_eq_right ne,ite_eq_right diff] at size
  intro d hd eq
  have yes:(List.range 5).any (fun x=>(afterGap a (missing b)).rotate x==afterGap b (missing a))=true:=
    List.any_eq_true.mpr ⟨d,List.mem_range.mpr hd,by simp [eq]⟩
  rw [yes] at size
  split at size <;> contradiction
end ResidualDensity.ForcedRuns

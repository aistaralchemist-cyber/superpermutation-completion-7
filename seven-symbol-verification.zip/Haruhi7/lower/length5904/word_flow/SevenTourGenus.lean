import SevenMoves

namespace ExactWordFlow.SevenTourGenus
open Equiv SevenMoves

private theorem r_order : orderOf r=7 := by
  rw [←Perm.lcm_cycleType]
  change (finRotate (5+2)).cycleType.lcm=7
  rw [cycleType_finRotate,Multiset.lcm_singleton,normalize_eq]

private theorem r_ne : r ≠ 1 := by
  intro h
  have num := (orderOf_eq_one_iff).2 h
  rw [r_order] at num
  contradiction

private theorem seven : r^7=1 := by
  simpa only [r_order] using pow_orderOf_eq_one r

private theorem shifted (x:X) : R x ≠ x := by
  change x*r ≠ x
  intro eq
  exact r_ne (mul_left_cancel (b:=r) (c:=1) (eq.trans (mul_one x).symm))

private theorem seven_cycles {A : Type} [Fintype A] [DecidableEq A] (q : Perm A)
    (size : Fintype.card A=5040) (periodic : q^7=1) (moves : ∀x,q x≠x) :
    q.cycleType=Multiset.replicate 720 7 := by
  classical
  let : Fact (Nat.Prime 7) := ⟨by decide⟩
  have form:=Perm.cycleType_of_pow_prime_eq_one periodic
  have whole : q.support=Finset.univ :=
    Finset.eq_univ_of_forall (fun x=>Perm.mem_support.mpr (moves x))
  have mass:=q.sum_cycleType
  rw [whole,Finset.card_univ,size] at mass
  have val := congrArg Multiset.sum form
  rw [Multiset.sum_replicate,mass] at val
  simp only [smul_eq_mul] at val
  have num : q.cycleType.card=720 := by omega
  exact form.trans (congrArg (fun n : Nat => Multiset.replicate n 7) num)

private theorem rotations : R.cycleType=Multiset.replicate 720 7 := by
  classical
  have pow_apply (n : Nat) (x:X) : (R^n) x=x*r^n := by
    induction n with
    | zero => simp
    | succ n ih =>
      rw [pow_succ',Perm.mul_apply,ih]
      change (x*r^n)*r=x*r^(n+1)
      rw [mul_assoc,pow_succ]
  have periodic : R^7=1 := by
    ext x i
    simp [pow_apply,seven]
  exact seven_cycles R sizeX periodic shifted

private theorem one_type (h : Perm X) (start:X)
    (orbit : ∀y,(R*h).SameCycle start y) : (R*h).cycleType={5040} := by
  classical
  have moved (x:X) : (R*h) x ≠ x := by
    intro fix
    exact shifted x (((orbit (R x)).symm.trans (orbit x)).eq_of_right fix)
  have whole : (R*h).support=Finset.univ :=
    Finset.eq_univ_of_forall (fun x=>Perm.mem_support.mpr (moved x))
  have cycle : (R*h).IsCycle :=
    (Perm.isCycle_iff_sameCycle (moved start)).mpr (fun {y}=>⟨fun _=>moved y,fun _=>orbit y⟩)
  rw [cycle.cycleType,whole,Finset.card_univ,sizeX]

/-- Every actual transitive seven-symbol successor has a genus. The base
action is right rotation on the 5040 permutations; both orbit types are
derived from this action and transitivity. -/
theorem exists_genus (h : Perm X) (start:X) (orbit : ∀y,(R*h).SameCycle start y) :
    ∃g : Nat,h.support.card=h.cycleType.card+719+2*g :=
  PermutationGenus.genus_seven R h start sizeX rotations (one_type h start orbit) orbit

#print axioms exists_genus
end ExactWordFlow.SevenTourGenus

import ShortScalars
import NearHundredShape
import Cap95Shape

set_option Elab.async false
set_option maxHeartbeats 150000

namespace ExactWordFlow.ShortComponentCaps
open SevenWordWindows ResidualDensity ResidualDensity.Density66 DirectedEuler ResidualRoutes ResidualIncidence
open GlobalDensity66 RotationComponentCount MarkedLargeCap
open scoped Classical
open private closed137 from Cap95Shape
open private initial from MarkedDensity
open private two_mass closed111 from MarkedLargeCap
open private cyclic_cap closed_price from GlobalDensity66
open private all_contacts from OverlapBudget
open private Cost totals from NearHundredShape

open ShortScalars

private def beyond (budget n : Nat) :=
  (budget≤855 ∧ 64≤n) ∨ (budget≤856 ∧ 77≤n) ∨ (budget≤857 ∧ 89≤n)

private theorem impossible {price n a b : Nat}
    (bad : beyond price n) (typeB : b=0 ∨ 79≤b)
    (mass : 6*n+a+b≤price+(if b=0 then 0 else 6))
    (rank : 6*719+5*a+5*b≤5*price+6*(openCap a-1)+6*closedRank b) : False := by
  unfold beyond at bad
  have sm : a+b≤477 := by split at mass <;> omega
  have data := scalar ⟨a,by omega⟩ ⟨b,by omega⟩ typeB
  let score:=6*(openCap a-1)+6*closedRank b
  change (a+b≤471+(if b=0 then 0 else 6) → score<5*(a+b)+39) ∧
    (a+b≤394+(if b=0 then 0 else 6) → score<5*(a+b)+34) ∧
    (a+b≤323+(if b=0 then 0 else 6) → score<5*(a+b)+29) at data
  dsimp only [score] at data
  obtain ⟨d1,d2,d3⟩:=data
  rcases bad with h|h|h
  · have := d1 (by omega); omega
  · have := d2 (by omega); omega
  · have := d3 (by omega); omega

private theorem special_zero {n a P s c u z : Nat}
    (rank : 719 ≤ s) (hit : c≤u) (total : 6*s+5*a≤5*P+6*(c-1))
    (mass : 6*n+a≤P) (zero : z=0) :
    (6*n+a+0≤P+(if (0:Nat)=0 then 0 else 6)) ∧
    6*719+5*a+5*0≤5*P+6*(u-1)+6*z := by
  omega

private theorem special_one {a b P s c u k j : Nat} (rank : 719 ≤ s) (hit : c≤u)
    (limit : k≤j) (total : 6*s+5*a+5*b≤5*P+6*(c-1)+6*k) :
    6*719+5*a+5*b≤5*P+6*(u-1)+6*j := by omega

private theorem root_price {a b : Block} {es : List Block} (r : Route src dst a es b)
    (width : ∀e∈es,e.length=7) (small : es.length+1≤478) :
    classCount a es≤openCap es.length := by
  unfold openCap
  exact ShortMarked.route_upper r width small

private theorem all_budgets {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (bad : beyond X.card (occupied X s).card) : False := by
  classical
  rw [occupied_active h] at bad
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  let C (q : Component X) := (contacts (support X s) (label X) q).card
  have rk : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  have bCases:=bad
  unfold beyond at bCases
  have bound : X.card≤858 := by omega
  have price:=(MarkedComponentCap.component_prices h bound).1
  have only : (large X s).card≤1 := by omega
  have homeIn : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have allMass : ∑q∈Q,K q=X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have homeMass : 6*(active X s).card+K home≤X.card := by
    have m := (totals h).1
    rw [occupied_active h] at m
    change K home+6*(active X s).card+_ = X.card at m
    omega
  have hcap : K home+1≤478 := by omega
  have get (q) (hq : q∈Q) :
      (q=home → C q≤openCap (K q)) ∧
      (q∈large X s → C q-1≤closedRank (K q)) ∧
      (q≠home → q∉large X s → 6*(C q-1)≤5*K q) := by
    obtain ⟨v,_,vv⟩:=Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩:=component_route h.balance v
    rw [vv] at eq lv ep
    have len : es.length=K q := congrArg Multiset.card eq
    have wd (e) (he : e∈es) := h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have incl : C q≤classCount a es := contacts_bound _ lv r eq
    refine ⟨?_,?_,?_⟩
    · intro atHome
      have small : es.length+1≤478 := by rw [len,atHome]; exact hcap
      rw [←len]
      exact incl.trans (root_price r wd small)
    · intro big
      obtain ⟨_,away,largeSize⟩:=Finset.mem_filter.mp big
      change q≠home at away
      change 79≤K q at largeSize
      obtain ⟨aa,bb⟩:=ep.2 away
      subst a; subst b
      have lo:=cyclic_cap r wd (by omega)
      have contact : C q≤720 := by
        exact all_contacts ..
      simp only [closedRank,ite_eq_right (show K q≠0 by omega)]
      apply Nat.sub_le_sub_right
      refine le_min (le_min (by omega) ?_) ?_
      · split
        next bigSize => have cl:=closed111 r wd (by omega); omega
        next => exact contact
      · split
        next bigSize => have cl:=closed137 r wd (by omega); omega
        next => exact contact
    · intro away noBig
      obtain ⟨aa,bb⟩:=ep.2 away
      subst a; subst b
      have sm : es.length<79 := by
        by_contra! t
        exact noBig (Finset.mem_filter.mpr ⟨hq,away,show 79≤K q by omega⟩)
      have cl:=closed_price r wd sm
      omega
  have compare (q) (hq : q∈Q) :
      6*(C q-1)+(if q=home then 5*K home else 0)+(if q∈large X s then 5*K q else 0) ≤
        5*K q+(if q=home then 6*(C home-1) else 0)+(if q∈large X s then 6*(C q-1) else 0) := by
    by_cases root : q=home
    · subst q
      have off : home∉large X s := fun m=>(Finset.mem_filter.mp m).2.1 rfl
      simp [off,Nat.add_comm]
    by_cases big : q∈large X s
    · simp [big,root,Nat.add_comm]
    · simpa [big,root] using (get q hq).2.2 root big
  have sum:=Finset.sum_le_sum compare
  have homeHits:=(get home homeIn).1 rfl
  by_cases has : (large X s).Nonempty
  · obtain ⟨q,m⟩:=has
    obtain ⟨inQ,away,long⟩:=Finset.mem_filter.mp m
    change q∈Q at inQ
    change 79≤K q at long
    have act : q∈active X s := Finset.mem_filter.mpr ⟨inQ,away,show 6≤K q by omega⟩
    have bigHits:=(get q inQ).2.1 m
    have mass : 6*(active X s).card+K home+K q≤X.card+6 := two_mass act
    have eq : large X s={q} := by
      ext z
      simp only [Finset.mem_singleton]
      exact ⟨fun hz=>Finset.card_le_one.mp only _ hz _ m,fun e=>e ▸ m⟩
    simp only [eq,Finset.mem_singleton,Finset.sum_add_distrib,←Finset.mul_sum,
      Finset.sum_ite_eq',homeIn,inQ,ite_true,allMass] at sum
    change 6*separateRank X s+5*K home+5*K q≤_ at sum
    apply impossible (a:=K home) (b:=K q) bad (Or.inr long)
    · simpa only [ite_eq_right (show K q≠0 by omega)] using mass
    · exact special_one rk homeHits bigHits sum
  · have eq := Finset.not_nonempty_iff_eq_empty.mp has
    simp only [eq,Finset.notMem_empty,ite_false,Nat.add_zero,Finset.sum_add_distrib,
      ←Finset.mul_sum,Finset.sum_ite_eq',homeIn,ite_true,allMass] at sum
    change 6*separateRank X s+5*K home≤_ at sum
    have both := special_zero (n:=(active X s).card) (z:=closedRank 0)
      rk homeHits sum homeMass rfl
    exact impossible (price:=X.card) (n:=(active X s).card) (a:=K home) (b:=0)
      bad (Or.inl rfl) both.1 both.2

/-- Simultaneous limits for non-start components in every feasible flow;
the closed-cycle cases use windows of 66, 111 and 137 positions. -/
theorem component_limits {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    (X.card≤855 → (occupied X s).card≤63) ∧
    (X.card≤856 → (occupied X s).card≤76) ∧
    (X.card≤857 → (occupied X s).card≤88) := by
  refine ⟨fun b=>?_,fun b=>?_,fun b=>?_⟩ <;> by_contra! n
  · exact all_budgets h (Or.inl ⟨b,n⟩)
  · exact all_budgets h (Or.inr (Or.inl ⟨b,n⟩))
  · exact all_budgets h (Or.inr (Or.inr ⟨b,n⟩))

/-- The actual multiset obtained from the input word satisfies every cap. -/
theorem covering_word (w : Word) (cov : SuperpermutationBounds.Covers w) :
    let X:=bag w-required
    let N:=(occupied X (w.take 6)).card
    (w.length≤5901 → N≤63) ∧ (w.length≤5902 → N≤76) ∧ (w.length≤5903 → N≤88) := by
  obtain ⟨u,v,eqw⟩:=cov (List.finRange 7) List.length_finRange (List.nodup_finRange _)
  have size : 6≤w.length := by rw [eqw]; simp; omega
  obtain ⟨X,eq,len,ok⟩:=extract_windows_at_ends w cov size
  have ident : bag w-required=X := by rw [←eq,add_tsub_cancel_left]
  dsimp only
  rw [ident]
  obtain ⟨lim1,lim2,lim3⟩:=component_limits ok
  exact ⟨fun l=>lim1 (by omega),fun l=>lim2 (by omega),fun l=>lim3 (by omega)⟩

#print axioms covering_word
#print axioms component_limits
end ExactWordFlow.ShortComponentCaps

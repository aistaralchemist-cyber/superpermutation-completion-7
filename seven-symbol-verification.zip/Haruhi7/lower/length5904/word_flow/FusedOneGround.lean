import FusedOne294
import Cap94LookCore

namespace ExactWordFlow.FusedOneGround
def result : Bool := FusedOne294.check Cap94Lookup.accept

set_option maxHeartbeats 0 in
theorem checked : result=true := by native_decide

#print axioms checked
end ExactWordFlow.FusedOneGround

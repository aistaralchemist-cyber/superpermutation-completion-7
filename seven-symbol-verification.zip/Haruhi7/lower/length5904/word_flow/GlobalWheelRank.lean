import WordFlow

namespace GlobalWheelRank
open ExactWordFlow SevenWordWindows

/-- Growing a component through an incident set of vertices adds at most
the size of that set less one.  Sets can overlap, repeat geometrically or
have size zero. -/
theorem grow {α : Type*} [DecidableEq α]
    (R : Finset α) (B : Finset (Finset α)) :
    ∃ C : Finset α, R ⊆ C ∧ C.card ≤ R.card + ∑ b ∈ B, (b.card-1) ∧
        ∀ b∈B, (C∩b).Nonempty → b⊆C := by
  classical
  by_cases h : ∃ b∈B, (R∩b).Nonempty ∧ ¬ b⊆R
  · obtain ⟨b,hb,hmeet,_⟩ := h
    obtain ⟨C,sub,bound,closed⟩ := grow (R∪b) (B.erase b)
    have meet := Finset.card_pos.mpr hmeet
    have card := Finset.card_union_add_card_inter R b
    have pay := Finset.sum_erase_add (f:=fun q : Finset α => q.card-1) B hb
    refine ⟨C,Finset.subset_union_left.trans sub,by omega,?_⟩
    intro q hq meetq
    by_cases eq : q=b
    · exact eq ▸ Finset.subset_union_right.trans sub
    · exact closed q (Finset.mem_erase.mpr ⟨eq,hq⟩) meetq
  · exact ⟨R,Finset.Subset.refl _,by omega,fun b hb hmeet => by
      by_contra bad
      exact h ⟨b,hb,hmeet,bad⟩⟩
termination_by B.card
decreasing_by exact Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (Finset.card_erase_add_one hb).le

/-- Any projection constant along mandatory arcs gives a common, endpoint-
independent obstruction. Each extra must either preserve its projected
vertex or be accounted for by one member of B touching both endpoints. -/
theorem projected_rank {α : Type*} [DecidableEq α] (φ : Block → α)
    (req : ∀ e∈required, φ (src e)=φ (dst e)) {X s t} (h : Feasible X s t)
    (B : Finset (Finset α))
    (account : ∀ e∈X, φ (src e)=φ (dst e) ∨
       ∃ b∈B, φ (src e)∈b ∧ φ (dst e)∈b) :
    (representatives.map (fun e => φ (src e))).toFinset.card ≤
      1 + ∑ b ∈ B, (b.card-1) := by
  classical
  obtain ⟨C,sub,cap,closed⟩ := grow {φ s} B
  let U : Set Block := {v | φ v∈C}
  have root : s∈U := sub (Finset.mem_singleton_self _)
  have step (e) (mem : e∈required+X) (hsrc : src e∈U) : dst e∈U := by
    change φ (dst e)∈C
    rcases Multiset.mem_add.mp mem with hm | hm
    · rw [← req _ hm]
      exact hsrc
    · rcases account _ hm with same | ⟨b,hb,hs,ht⟩
      · rw [←same]; exact hsrc
      · exact closed b hb ⟨_,Finset.mem_inter.mpr ⟨hsrc,hs⟩⟩ ht
  have covered : (representatives.map (fun e => φ (src e))).toFinset ⊆ C := by
    intro v hv
    obtain ⟨e,he,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hv)
    exact h.reachable U root step e (Multiset.mem_add.mpr (Or.inl he))
  simpa using (Finset.card_le_card covered).trans cap

/-- The value on repeated-letter states is arbitrary for this projection.
For a clean state, insert its missing symbol and orient the circle at 0. -/
def cls (v : Block) : Block :=
  let p := v ++ [((List.finRange 7).find? (fun a => !v.contains a)).getD 0]
  p.rotate (p.idxOf 0)

def wheel (q : Block) := (List.range 6).map fun j =>
  let v := q.rotate j
  v ++ v.take 1

def roots := (representatives.map src).toFinset
def touches (q : Block) := ((wheel q).map (fun e => cls (src e))).toFinset

private theorem base :
    (representatives.all fun e => cls (src e) == cls (dst e))=true ∧
    (representatives.map (fun e => cls (src e))).toFinset.card=720 ∧
    ((representatives.map src).all fun q =>
      decide ((touches q).card=6) &&
      ((wheel q).all fun e => decide (cls (dst e)∈touches q)))=true := by native_decide

/-- A uniform inequality with arbitrary choices of six-wheels and arbitrary
exceptional transitions.  An exceptional pair can account for repeated
copies of the same directed transition. -/
theorem wheel_bound {X s t} (h : Feasible X s t) (W : Finset Block)
    (legit : W ⊆ roots) (E : Finset (Block × Block))
    (account : ∀ e∈X, e∈required ∨ (∃ q∈W, e∈wheel q) ∨
      (cls (src e),cls (dst e))∈E) : 719 ≤ 5*W.card+E.card := by
  classical
  let pairs (p : Block × Block) : Finset Block := {p.1,p.2}
  let T := W.image touches
  let F := E.image pairs
  have req (e) (he : e∈required) := eq_of_beq (List.all_eq_true.mp base.1 e he)
  have geom (q) (hq : q∈W) := Bool.and_eq_true_iff.mp
    (List.all_eq_true.mp base.2.2 q (List.mem_toFinset.mp (legit hq)))
  have price := projected_rank cls req h (T∪F) (by
    intro e he
    rcases account e he with hm | ⟨q,hq,hw⟩ | hex
    · exact Or.inl (req e hm)
    · right
      exact ⟨touches q,Finset.mem_union_left _ (Finset.mem_image_of_mem _ hq),
        List.mem_toFinset.mpr (List.mem_map.mpr ⟨_,hw,rfl⟩),
        of_decide_eq_true (List.all_eq_true.mp (geom q hq).2 e hw)⟩
    · right
      exact ⟨_,Finset.mem_union_right _ (Finset.mem_image_of_mem pairs hex),
        by simp [pairs], by simp [pairs]⟩)
  rw [base.2.1] at price
  have tbound : ∑ q ∈ T, (q.card-1) ≤ T.card*5 := by
    apply Finset.sum_le_card_nsmul
    intro q hq
    rcases Finset.mem_image.mp hq with ⟨w,hw,rfl⟩
    exact (show (touches w).card=6 from of_decide_eq_true (geom w hw).1) ▸ (by decide)
  have fbound : ∑ q ∈ F, (q.card-1) ≤ F.card*1 := by
    apply Finset.sum_le_card_nsmul
    intro q hq
    rcases Finset.mem_image.mp hq with ⟨⟨u,v⟩,_,rfl⟩
    have := Finset.card_insert_le u ({v}:Finset Block)
    simp [pairs] at *
    omega
  have union := Finset.sum_union_inter (s₁:=T) (s₂:=F) (f:=fun q : Finset Block => q.card-1)
  have tw : T.card ≤ W.card := Finset.card_image_le
  have fe : F.card ≤ E.card := Finset.card_image_le
  omega

/-- Arbitrary endpoints, degree-balanced or otherwise. Repetition of any
mandatory edge and partial or repeated turns on the 143 wheels are allowed. -/
theorem no_143_wheels {X : Multiset Block} (s t : Block) (W : Finset Block)
    (legit : W ⊆ roots) (few : W.card ≤ 143)
    (account : ∀ e∈X, e∈required ∨ ∃ q∈W, e∈wheel q) :
    ¬ Feasible X s t := by
  intro h
  have n := wheel_bound h W legit ∅ (fun e he =>
    (account e he).imp id Or.inl)
  simp only [Finset.card_empty,Nat.add_zero] at n
  omega

end GlobalWheelRank
#print axioms GlobalWheelRank.projected_rank
#print axioms GlobalWheelRank.wheel_bound

#print axioms GlobalWheelRank.no_143_wheels

import LiteralStar307
import DirectStarMask

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows RotationCore LiteralWheelCover

/-- No actual insertion of 92 wheels into a 92-completion base can produce
a length-1508 word visiting all 720 classes. -/
theorem no_92_insertions {b v : Block} {rs : List Row} (ins : Inserts b rs v) (count : rs.length=92)
    (done : (complete b).card=92) (hit : (visited v).card=720) (len : v.length=1508) : False := by
  obtain ⟨P,onBoard,small,accepted,star⟩:=LiteralStar307.accepted ins count done hit len
    DirectStarMask.accept DirectStarMask.passed
  obtain ⟨c,valid,miss,blocked⟩:=DirectStarMask.reject onBoard accepted
  obtain ⟨R,legal,member,one⟩:=LiteralStar307.single star small c valid miss
  exact blocked R legal member one

theorem equality_91 {b : Block} {k : Nat} (done : (complete b).card=92)
    (budget : b.length+6*k=1508) (fits : condition b k) :
    k≤91 ∧ 962≤b.length := by
  have prior:=equality_92 done budget fits
  suffices k≠92 by omega
  intro counter
  obtain ⟨rs,v,ins,small,vis⟩:=(budget_iff b k).mpr fits
  have len:=ins.length_eq
  have c : (complete v).card=92:=ins.complete_eq ▸ done
  have sharp:=(Boundary1508Floor.only_boundary (w:=v) (by omega) vis c.ge).2
  exact no_92_insertions ins (by omega) done vis (by omega)

#print axioms equality_91
end ExactWordFlow.WheelBaseResidual

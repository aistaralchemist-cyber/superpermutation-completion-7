import OpenWheelPacking
import OrientedCNF
namespace ExactWordFlow.IntegralPackets
open SevenWordWindows SeedWheelCut ExtremeWheelCut OrientedCNF SaturatedOrientation OpenWheelPacking

/-- Even a disconnected packing with exactly enough five-sets to cover
the entire complement would satisfy the exact-cover formula. -/
theorem no_full_packing {P : Finset Block} {r : Nat}
    (bad : (cnf P).Unsat) (size : (allClasses \ P).card=5*(r+1))
    {T : Finset (Finset Block)}
    (valid : ∀u∈T,Packet allRows u ∧ u⊆allClasses \ P)
    (apart : ∀u∈T,∀v∈T,u≠v → Disjoint u v) : T.card≤r := by
  classical
  by_contra! more
  let union:=T.biUnion (fun u=>u)
  have inside : union⊆allClasses \ P := by
    intro x hx
    obtain ⟨u,hu,hit⟩:=Finset.mem_biUnion.mp hx
    exact (valid u hu).2 hit
  have card : union.card=5*T.card := by
    change (T.biUnion (fun u=>u)).card=_
    rw [Finset.card_biUnion (fun u hu v hv ne=>apart u hu v hv ne)]
    calc ∑u∈T,u.card=∑u∈T,5 := Finset.sum_congr rfl (by
           intro u hu
           obtain ⟨_,_,_,_,_,h⟩:=(valid u hu).1
           exact h)
         _ = _ := by simp [Nat.mul_comm]
  have complete : union=allClasses \ P := Finset.eq_of_subset_of_card_le inside (by omega)
  have witness (u : Finset Block) (hu : u∈T) :
      ∃ p : Choice,p.1∈allRows ∧ p.2∈p.1 ∧ children p=u := by
    obtain ⟨w,hw,k,hk,e,_⟩:=(valid u hu).1
    exact ⟨(w,k),hw,hk,e.symm⟩
  let pick (u : Finset Block) : Choice := if h:u∈T then (witness u h).choose else (∅,[])
  have spec (u) (hu : u∈T) : (pick u).1∈allRows ∧ (pick u).2∈(pick u).1 ∧ children (pick u)=u := by
    simpa [pick,hu] using (witness u hu).choose_spec
  let O:=T.image pick
  have rows : ∀p∈O,p.1∈allRows ∧ p.2∈p.1 ∧ Disjoint (children p) P := by
    intro p hp
    obtain ⟨u,hu,rfl⟩:=Finset.mem_image.mp hp
    obtain ⟨w,k,eq⟩:=spec u hu
    refine ⟨w,k,?_⟩
    rw [eq]
    exact Finset.disjoint_left.mpr (fun _ hit hP=>(Finset.mem_sdiff.mp ((valid u hu).2 hit)).2 hP)
  have hit : ∀x∈allClasses \ P,∃p∈O,x∈children p := by
    rw [←complete]
    intro x hx
    obtain ⟨u,hu,seen⟩:=Finset.mem_biUnion.mp hx
    exact ⟨pick u,Finset.mem_image_of_mem _ hu,by rw [(spec u hu).2.2]; exact seen⟩
  have separate : ∀p∈O,∀q∈O,p≠q → Disjoint (children p) (children q) := by
    intro p hp q hq different
    obtain ⟨u,hu,rfl⟩:=Finset.mem_image.mp hp
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hq
    rw [(spec u hu).2.2,(spec v hv).2.2]
    exact apart u hu v hv (fun eq=>different (congrArg pick eq))
  obtain ⟨v,yes⟩:=disjoint_sat rows hit separate
  simpa [yes] using bad v

/-- An integer obstruction on a seed controls every root that contains
it, including roots with wasteful or excess wheel contacts. -/
theorem extend {P A : Finset Block} {r : Nat}
    (bad : (cnf P).Unsat) (outside : (allClasses \ P).card=5*(r+1))
    {W : Finset (Finset Block)} (seed : P⊆A) (board : A⊆allClasses)
    (legal : W⊆allRows) (rows : ∀w∈W,w⊆allClasses ∧ w.card≤6)
    (link : ClosedCover A allClasses W) :
    allClasses.card ≤ A.card+4*W.card+r := by
  obtain ⟨T,valid,apart,lim⟩:=extract W board legal rows link
  have usable : ∀u∈T,Packet allRows u ∧ u⊆allClasses \ P := by
    intro u hu
    refine ⟨(valid u hu).1,?_⟩
    intro x hx
    obtain ⟨on,off⟩:=Finset.mem_sdiff.mp ((valid u hu).2 hx)
    exact Finset.mem_sdiff.mpr ⟨on,fun old=>off (seed old)⟩
  have cap:=no_full_packing bad outside usable apart
  omega

#print axioms no_full_packing
#print axioms extend
end ExactWordFlow.IntegralPackets

import StrippedControl

namespace ExactWordFlow.StrippedControl
open SevenWordWindows RotationCore ResidualDensity LiteralWheelCover

theorem infeasible_descendant {i : Nat} (pos : i < base.length) {z : Block} {rs : List Row}
    (h : Inserts (change i) rs z) (short : z.length≤1508) (hit : (visited z).card=720) :
    (complete z).card≤91 := by
  by_contra! n
  have done : 92≤(complete (change i)).card := h.complete_eq ▸ n
  have len : (change i).length=1286 := by
    change ((base.take i)++base.drop (i+1)).length=1286
    simp only [List.length_append,List.length_take,List.length_drop,Nat.min_eq_left pos.le,
      verified_control.1]
    rw [verified_control.1] at pos
    omega
  have size := h.length_eq
  have few : rs.length≤37 := by omega
  exact no_budget i pos done ((budget_iff (change i) 37).mp ⟨rs,z,h,few,hit⟩)

theorem touched_descendant {a j : Nat} (ha : a∈offsets) (hj : j<12)
    {z : Block} {rs : List Row} (h : Inserts (touched a j) rs z) :
    (complete z).card≤91 := by rw [h.complete_eq]; exact touched_fails ha hj

/-- Replaying insertions within a fixed left and right context. -/
theorem context {w z : Block} {rs : List Row} (h : Inserts w rs z) (l r : Block) :
    Inserts (l++w++r) rs (l++z++r) := by
  induction h with
  | stop => exact .stop _
  | @add x u y tail t clean _ ih =>
    simpa only [List.append_assoc] using
      (Inserts.add (l:=l++x) (u:=u) (r:=y++r) (rs:=tail) clean
        (by simpa only [List.append_assoc] using ih))

/-- All disjointly located inserted wheels on the two flanks of an edit
can be stripped simultaneously in the proof, regardless of their number. -/
theorem flanks {l l' m r r' : Block} {a b : List Row}
    (left : Inserts l a l') (right : Inserts r b r') :
    Inserts (l++m++r) (a++b) (l'++m++r') := by
  have one : Inserts (l++m++r) a (l'++m++r) := by
    simpa only [List.nil_append,List.append_assoc] using context left [] (m++r)
  have two : Inserts (l'++m++r) b (l'++m++r') := by
    simpa only [List.append_nil] using context right (l'++m) []
  exact one.trans two

/-- The distinguished deletion may occur anywhere in the base or anywhere
in one of its 37 doubled slots. All other wheel insertions before and after
the change are unconstrained on the two flanks, and subsequent repair is arbitrary. -/
theorem edited_flanks {l l' m r r' z : Block} {a b s : List Row}
    (origin : (∃i<base.length, l++m++r=change i) ∨
      (∃o∈offsets,∃j<12,l++m++r=touched o j))
    (left : Inserts l a l') (right : Inserts r b r') (repair : Inserts (l'++m++r') s z)
    (short : z.length≤1508) (hit : (visited z).card=720) : (complete z).card≤91 := by
  have hist := (flanks (m:=m) left right).trans repair
  rcases origin with ⟨i,hi,eq⟩|⟨o,ho,j,hj,eq⟩
  · rw [eq] at hist; exact infeasible_descendant hi hist short hit
  · rw [eq] at hist; exact touched_descendant ho hj hist

#print axioms edited_flanks
end ExactWordFlow.StrippedControl

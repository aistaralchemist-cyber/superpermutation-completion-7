import Cap94LookCore
import Cap93Rows

namespace ExactWordFlow.Cap93Lookup
open SevenWordWindows RotationCore NearRootMoves Cap93Catalog Cap94Lookup
def seeds := rows.map (fun p=>visited p.1)
def keys := seeds.map (fun R=>((List.range 7).map (fun j=>bits j R)).toArray)
def lookup : Std.HashMap Nat (Nat × Nat) := Id.run do
  let mut lut : Std.HashMap Nat (Nat × Nat) := {}
  for i in [:keys.size] do
    let key:=keys[i]!
    for j in [:key.size] do lut:=lut.insert key[j]! (i,j)
  return lut

def accept (R : Finset Block) : Bool :=
  let b:=bits 0 R
  let (i,j):=lookup.getD b (rows.size,7)
  decide (i<rows.size ∧ j<7 ∧ (keys[i]!)[j]! = b ∧ ∀c∈R,known c=true)

end ExactWordFlow.Cap93Lookup

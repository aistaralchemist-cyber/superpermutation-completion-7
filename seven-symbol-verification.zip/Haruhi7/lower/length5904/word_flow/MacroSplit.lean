import DirectedEuler

namespace DirectedEuler
namespace MacroSplit

variable {α β : Type*}

private theorem no_macro (xs : List (Option α)) (clean : none∉xs) :
    ∃ ys : List α, xs=ys.map some := by
  induction xs with
  | nil => exact ⟨[],rfl⟩
  | cons o xs ih =>
    obtain ⟨ys,eq⟩ := ih (fun h => clean (List.mem_cons_of_mem _ h))
    cases o with
    | none => exact (clean List.mem_cons_self).elim
    | some x => exact ⟨x::ys,by simp [eq]⟩

private theorem plain (src dst : α → β) (a b : β) (p : List α) {s t : β}
    (r : Route (fun x : Option α => x.elim a src) (fun x => x.elim b dst) s (p.map some) t) :
    Route src dst s p t := by
  induction p generalizing s with
  | nil =>
    cases r
    exact .nil _
  | cons e p ih =>
    cases r with
    | cons _ hs tail => exact .cons e hs (ih tail)

private theorem routes (src dst : α → β) (a b : β) (p q : List α) {s t : β}
    (r : Route (fun x : Option α => x.elim a src) (fun x => x.elim b dst)
      s (p.map some++none::q.map some) t) : Route src dst s p a ∧ Route src dst b q t := by
  induction p generalizing s with
  | nil =>
    cases r with
    | cons _ hs tail =>
      change a=s at hs
      subst s
      exact ⟨.nil _,plain src dst a b q tail⟩
  | cons x p ih =>
    cases r with
    | cons _ hs tail =>
      obtain ⟨hp,hq⟩ := ih tail
      exact ⟨.cons x hs hp,hq⟩

/-- In an Euler trail with one tagged macro-step a→b, every other
edge occurs in a literal prefix ending at a or a literal suffix starting
at b, with multiplicities preserved. -/
theorem split (src dst : α → β) {s a b t : β} (fresh : Multiset α)
    {xs : List (Option α)} (bag : (↑xs : Multiset (Option α)) = fresh.map some + {none})
    (r : Route (fun x : Option α => x.elim a src) (fun x => x.elim b dst) s xs t) :
    ∃ p q : List α, (↑(p++q) : Multiset α)=fresh ∧ Route src dst s p a ∧ Route src dst b q t := by
  classical
  have hit : none∈xs := by
    change none∈(↑xs : Multiset (Option α))
    rw [bag]
    exact Multiset.mem_add.mpr (Or.inr (by simp))
  obtain ⟨u,v,rfl⟩ := List.append_of_mem hit
  have kept : (↑(u++v) : Multiset (Option α))=fresh.map some := by
    apply add_right_cancel (b:=({none} : Multiset (Option α)))
    simpa only [←Multiset.coe_add,←Multiset.cons_coe,←Multiset.singleton_add,
      add_assoc,add_comm,add_left_comm] using bag
  have clean : none∉u++v := by
    change none∉(↑(u++v) : Multiset (Option α))
    rw [kept]
    simp
  obtain ⟨p,rfl⟩ := no_macro u (fun h => clean (List.mem_append_left _ h))
  obtain ⟨q,rfl⟩ := no_macro v (fun h => clean (List.mem_append_right _ h))
  obtain ⟨left,right⟩ := routes src dst a b p q r
  refine ⟨p,q,?_,left,right⟩
  apply Multiset.map_injective (f:=some) (fun _ _ eq => Option.some.inj eq)
  simpa only [Multiset.map_coe,List.map_append] using kept

#print axioms split
end MacroSplit
end DirectedEuler

import FullRowPacking
import RowCredits
import ActualPackingCost

namespace ExactWordFlow.AnonymousRows
open Equiv RowCredits
variable {X Y ι : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y] [DecidableEq ι]

def states (owner : X→ι) (i : ι) := Finset.univ.filter (fun x=>owner x=i)

/-- The result describes whole physical neutral rows in the exceptional
support. Each row supplies six distinct component names, and the names
used by separate rows are disjoint. -/
def Separated (S : Finset X) (owner : X→ι) (color : X→Y) (price : X→Nat)
    (K : Finset ι) : Prop :=
  (∀i∈K,states owner i ⊆ S ∧ ((states owner i).image color).card=6 ∧
    (∑x∈states owner i,price x)=1) ∧
  ∀i∈K,∀j∈K,i≠j → Disjoint ((states owner i).image color) ((states owner j).image color)

theorem packed {R h : Perm X} (start last : X) (orbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (card : Fintype.card X=5040) (classes : Fintype.card Y=720)
    (turn : X→X) (owner : X→ι) (ownerTurn : ∀x,owner (turn x)=owner x)
    (width : ∀i,(states owner i).card≤6)
    (d : X→Nat) (positive : ∀x,x≠last → 1≤d x)
    (one : ∀x,x≠last → (d x=1 ↔ h x=x))
    (two : ∀x,x≠last → d x=2 → h x=turn x ∨ h x=R x)
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (present : E.Nonempty)
    (six : ∀c∈h.cycleFactorsFinset \ E,c.support.card=6)
    (exceptions : ∀c∈E,last∈c.support ∨ ∃y∈c.support,h y≠turn y)
    {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    :
    ∃ (f : Y→Y) (K : Finset ι),
      (∀c∈h.cycleFactorsFinset \ E,∀x∈c.support,∀y∈c.support,f (tag x)=f (tag y)) ∧
      Separated (E.biUnion Perm.support) owner (f ∘ tag) (fee h R last d) K ∧
      29535+5*E.card ≤ 5*(7+∑x∈Finset.univ.erase last,d x)+K.card := by
  classical
  let H:=h.cycleFactorsFinset
  let S:=E.biUnion Perm.support
  let A:=S.image tag
  let W:=(H\E).image (fun c=>c.support.image tag)
  have closed : SeedWheelCut.ClosedCover A Finset.univ W := by
    simpa only [A,S,Finset.biUnion_image] using TourWheelPrice.from_order start orbit tag onto rot E known present
  have rowWidth : ∀w∈W,w.card≤6 := by
    intro w hw
    obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp hw
    exact Finset.card_image_le.trans (six c hc).le
  obtain ⟨f,num,mono⟩:=WheelContraction.colors Finset.univ W rowWidth
  have all:=WheelContraction.all_met (Finset.subset_univ A) closed f mono
  let pool (i : ι):=S.filter (fun x=>owner x=i)
  let T:=S.image owner
  let names (i : ι):=(pool i).image (f ∘ tag)
  let pay:=fee h R last d
  let coins (i : ι):=∑x∈pool i,pay x
  have subPool (i : ι) : pool i⊆states owner i:=Finset.filter_subset_filter _ (Finset.subset_univ _)
  have wide (i : ι) : (names i).card≤6:=
    Finset.card_image_le.trans ((Finset.card_le_card (subPool i)).trans (width i))
  have paid:=row_positive h R turn owner ownerTurn last d positive one two E known exceptions
  obtain ⟨K,_,chosen,disjoint,coverage⟩:=FullRowPacking.extract T names coins (fun i _=>wide i) paid
  have visible : A.image f⊆T.biUnion names := by
    intro z hz
    obtain ⟨y,hy,rfl⟩:=Finset.mem_image.mp hz
    obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hy
    exact Finset.mem_biUnion.mpr ⟨owner x,Finset.mem_image_of_mem _ hx,
      Finset.mem_image_of_mem (f ∘ tag) (Finset.mem_filter.mpr ⟨hx,rfl⟩)⟩
  have whole (i) (hi : i∈K) : pool i=states owner i := by
    apply Finset.eq_of_subset_of_card_le (subPool i)
    have sz : (names i).card≤(pool i).card:=Finset.card_image_le
    have top:=width i
    have full:=(chosen _ hi).1
    omega
  refine ⟨f,K,?_,?_,?_⟩
  · intro c hc x hx y hy
    exact mono _ (Finset.mem_image_of_mem _ hc) _ (Finset.mem_image_of_mem _ hx) _
      (Finset.mem_image_of_mem _ hy)
  · constructor
    · intro i hi
      rw [←whole i hi]
      exact ⟨Finset.filter_subset ..,chosen i hi⟩
    · intro i hi j hj neq
      rw [←whole i hi,←whole j hj]
      exact disjoint i hi j hj neq
  · have total : ∑i∈T,coins i=∑x∈S,pay x :=
      Finset.sum_fiberwise_of_maps_to (fun i hi=>Finset.mem_image_of_mem owner hi) _
    have bill:=budget h R last d S
    have switches:=PermutationGenus.rotation_switch_bound start orbit tag onto rot classes genus
    have cost:=ActualPackingCost.open_packing_cost h last d card positive one E known six
    have sum : (∑c∈H\E,c.support.card)+(∑c∈E,c.support.card)=h.support.card :=
      (Finset.sum_sdiff known).trans h.sum_cycleType
    rw [Finset.sum_congr rfl six] at sum
    simp only [Finset.sum_const,smul_eq_mul] at sum
    change (H\E).card*6+(∑c∈E,c.support.card)=h.support.card at sum
    have n := Finset.card_sdiff_add_card_eq_card known
    have k : H.card=h.cycleType.card:=by simp [H,Perm.cycleType_def]
    have wc : W.card≤(H\E).card:=Finset.card_image_le
    have listed:=Finset.card_le_card visible
    change (∑x∈S,pay x)≤_ at bill
    change (H\E).card+E.card=H.card at n
    change 7+(∑x∈Finset.univ.erase last,d x)+(if h last=last then 0 else 1)=
      5046+(∑c∈E,c.support.card)+(∑x∈Finset.univ.erase last,(d x-2))+6*(H\E).card at cost
    rw [Finset.card_univ,classes,all] at num
    rw [total] at coverage
    split at cost <;> omega

#print axioms packed
end ExactWordFlow.AnonymousRows

import NearHardRoots

namespace ExactWordFlow.Cap92Data
open SevenWordWindows NearHardRoots RotationCore

def words := (include_str "hard306-words.txt").trimAscii.toString.splitOn "\n"
def hard := words.map (fun w=>visited (digits w))

end ExactWordFlow.Cap92Data

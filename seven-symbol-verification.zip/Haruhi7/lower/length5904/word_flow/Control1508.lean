import CoreControls

namespace ExactWordFlow.Boundary1508
open RotationCoreControls

theorem reference628 :
    summary (coreWord 628)=(1509,720,92) ∧
    summary (coreTruncated 628)=(1508,720,91) := by native_decide

#print axioms reference628
end ExactWordFlow.Boundary1508

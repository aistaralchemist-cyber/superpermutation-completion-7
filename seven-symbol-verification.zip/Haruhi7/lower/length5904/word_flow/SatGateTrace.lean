import Std.Sat.CNF
import Mathlib.Tactic

namespace ExactWordFlow.SatGateTrace
open Std.Sat

/-- The first DIMACS variable is reserved for true. A Lean variable index is one lower. -/
abbrev Lit := Literal Nat
def yes : Lit := (0,true)
def no : Lit := (0,false)
def neg (a : Lit) : Lit := (a.1,!a.2)
def val (v : Nat → Bool) (a : Lit) := (v a.1 == a.2)

@[simp] theorem val_neg (v : Nat → Bool) (a : Lit) : val v (neg a) = !(val v a) := by
  rcases a with ⟨i,b⟩; cases h : v i <;> cases b <;> simp [val,neg,h]

@[simp] theorem val_yes {v : Nat → Bool} (h : v 0 = true) : val v yes = true := by simp [val,yes,h]
@[simp] theorem val_no {v : Nat → Bool} (h : v 0 = true) : val v no = false := by simp [val,no,h]
@[simp] theorem val_pos (v : Nat → Bool) (i : Nat) : val v (i,true) = v i := by simp [val]
@[simp] theorem val_negVar (v : Nat → Bool) (i : Nat) : val v (i,false) = !(v i) := by simp [val]

inductive Gate
  | either (out : Nat) (xs : List Lit)
  | mux (out : Nat) (sel left right : Lit)
  | clause (xs : List Lit)
deriving Repr

def Gate.rows : Gate → List (List Lit)
  | .either r xs => ((r,false)::xs) :: xs.map (fun x => [neg x,(r,true)])
  | .mux r c a b =>
    [[neg c,neg a,(r,true)], [neg c,a,(r,false)],
     [c,neg b,(r,true)], [c,b,(r,false)]]
  | .clause xs => [xs]

def Gate.holds (v : Nat → Bool) : Gate → Prop
  | .either r xs => v r = xs.any (val v)
  | .mux r c a b => v r = if val v c then val v a else val v b
  | .clause xs => xs.any (val v) = true

theorem local_iff (v : Nat → Bool) (g : Gate) :
    g.rows.all (fun c => c.any (val v)) = true ↔ g.holds v := by
  cases g with
  | clause xs => simp [Gate.rows,Gate.holds]
  | mux r c a b =>
    simp only [Gate.rows, Gate.holds, List.all_cons, List.all_nil, List.any_cons,
      List.any_nil, val_neg, val_pos, val_negVar]
    cases v r <;> cases val v c <;> cases val v a <;> cases val v b <;> decide
  | either r xs =>
    simp only [Gate.rows, Gate.holds, List.all_cons, List.all_map, List.any_cons,
      List.any_nil, Function.comp_def, val_neg, val_pos, val_negVar]
    cases h : v r
    · simp only [Bool.not_false, Bool.true_or, Bool.or_false, Bool.true_and]
      simp [List.all_eq_true, List.any_eq_false]
    · simp

def formula (gs : List Gate) : CNF Nat :=
  ⟨((gs.flatMap Gate.rows).map CNF.Clause.ofLiterals).toArray⟩

private theorem list_iff (v : Nat → Bool) (rows : List (List Lit)) :
    (CNF.mk ((rows.map CNF.Clause.ofLiterals).toArray)).eval v = true ↔
      ∀ row ∈ rows, row.any (val v) = true := by
  rw [CNF.eval,Array.all_eq_true_iff_forall_mem]
  constructor
  · intro h row hr
    have c := h (CNF.Clause.ofLiterals row) (List.mem_toArray.mpr (List.mem_map.mpr ⟨row,hr,rfl⟩))
    simpa [CNF.Clause.eval,CNF.Clause.literals_ofLiterals,val] using c
  · intro h c hc
    obtain ⟨row,hr,rfl⟩ := List.mem_map.mp (List.mem_toArray.mp hc)
    simpa [CNF.Clause.eval,CNF.Clause.literals_ofLiterals,val] using h row hr

theorem trace_iff (v : Nat → Bool) (gs : List Gate) :
    (formula gs).eval v = true ↔ ∀ g ∈ gs, g.holds v := by
  unfold formula
  rw [list_iff]
  constructor
  · intro h g hg
    exact (local_iff v g).mp (List.all_eq_true.mpr fun row hr => h row (List.mem_flatMap.mpr ⟨g,hg,hr⟩))
  · intro h row member
    obtain ⟨g,hg,hr⟩ := List.mem_flatMap.mp member
    exact List.all_eq_true.mp ((local_iff v g).mpr (h g hg)) row hr


/-- Inputs use the same variable counter as computed gates. An assertion allocates no wire. -/
inductive Op
  | input
  | either (xs : List Lit)
  | mux (sel left right : Lit)
  | clause (xs : List Lit)
deriving Repr, Inhabited

def Op.args : Op → List Lit
  | .input => []
  | .either xs | .clause xs => xs
  | .mux c a b => [c,a,b]

def Op.next (n : Nat) : Op → Nat
  | .clause _ => n
  | _ => n+1

def Op.emit (n : Nat) : Op → List Gate
  | .input => []
  | .either xs => [.either n xs]
  | .mux c a b => [.mux n c a b]
  | .clause xs => [.clause xs]

def compile (n : Nat) : List Op → List Gate
  | [] => []
  | op::rest => op.emit n ++ compile (op.next n) rest

def wellScoped (n : Nat) : List Op → Prop
  | [] => True
  | op::rest => (∀ l ∈ op.args, l.1 < n) ∧ wellScoped (op.next n) rest

def Op.step (inputs : Nat → Bool) (n : Nat) (v : Nat → Bool) : Op → Nat → Bool
  | .input => Function.update v n (inputs n)
  | .either xs => Function.update v n (xs.any (val v))
  | .mux c a b => Function.update v n (if val v c then val v a else val v b)
  | .clause _ => v

def Op.assertion (v : Nat → Bool) : Op → Bool
  | .clause xs => xs.any (val v)
  | _ => true

def run (inputs : Nat → Bool) (n : Nat) (v : Nat → Bool) : List Op → Nat → Bool
  | [] => v
  | op::xs => run inputs (op.next n) (op.step inputs n v) xs

def passes (inputs : Nat → Bool) (n : Nat) (v : Nat → Bool) : List Op → Bool
  | [] => true
  | op::xs => op.assertion v && passes inputs (op.next n) (op.step inputs n v) xs

private theorem step_agrees (op : Op) (inputs v : Nat → Bool) {i n : Nat} (h : i < n) :
    op.step inputs n v i = v i := by
  cases op <;> simp [Op.step,Function.update_of_ne (Nat.ne_of_lt h)]

private theorem stable (inputs : Nat → Bool) (n : Nat) (v : Nat → Bool) (xs : List Op)
    (i : Nat) (old : i<n) : run inputs n v xs i = v i := by
  induction xs generalizing n v with
  | nil => rfl
  | cons op xs ih =>
    change run inputs (op.next n) (op.step inputs n v) xs i = _
    have next : i < op.next n := by cases op <;> simp [Op.next] <;> omega
    rw [ih _ _ next, step_agrees op inputs v old]

private theorem any_agrees {v z : Nat → Bool} {xs : List Lit}
    (eq : ∀ l∈xs, v l.1=z l.1) : xs.any (val v)=xs.any (val z) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    have a := eq x List.mem_cons_self
    have b := ih (fun l hl=>eq l (List.mem_cons_of_mem _ hl))
    simp only [List.any_cons,b,val,a]

private theorem first_holds {op : Op} {n : Nat} {v inputs : Nat → Bool} {rest : List Op}
    (sc : ∀ l∈op.args, l.1<n) (ok : op.assertion v=true) :
    ∀g∈op.emit n, g.holds (run inputs (op.next n) (op.step inputs n v) rest) := by
  let z := run inputs (op.next n) (op.step inputs n v) rest
  have old {l : Lit} (m : l∈op.args) : z l.1=v l.1 := by
    have sm:=sc l m
    have step : n ≤ op.next n := by cases op <;> simp [Op.next]
    exact (stable _ _ _ _ _ (lt_of_lt_of_le sm step)).trans (step_agrees op inputs v sm)
  cases op with
  | input => simp [Op.emit]
  | either xs =>
    simp only [Op.emit,List.mem_singleton,forall_eq]
    change z n = xs.any (val z)
    have out := stable inputs (n+1) (Function.update v n (xs.any (val v))) rest n (by omega)
    rw [show z n=xs.any (val v) by simpa [z,Op.next,Op.step] using out, any_agrees (xs:=xs) (v:=z) (z:=v) (fun _ h => old h)]
  | mux c a b =>
    simp only [Op.emit,List.mem_singleton,forall_eq]
    change z n = if val z c then val z a else val z b
    have out := stable inputs (n+1) (Function.update v n (if val v c then val v a else val v b)) rest n (by omega)
    have ec := old (l:=c) (by simp [Op.args])
    have ea := old (l:=a) (by simp [Op.args])
    have eb := old (l:=b) (by simp [Op.args])
    change z n = if (z c.1 == c.2) then (z a.1 == a.2) else (z b.1 == b.2)
    rw [ec,ea,eb]
    simpa [z,Op.next,Op.step,val] using out
  | clause xs =>
    simp only [Op.emit,List.mem_singleton,forall_eq]
    change xs.any (val z) = true
    rw [any_agrees (xs:=xs) (v:=z) (z:=v) (fun _ h => old h)]
    exact ok

/-- All assertions passing on a topologically scoped operation stream explicitly
constructs one valuation satisfying its exact Tseitin rows. -/
theorem compile_satisfies {ops : List Op} {n : Nat} {v inputs : Nat → Bool}
    (sc : wellScoped n ops) (ok : passes inputs n v ops=true) :
    (formula (compile n ops)).eval (run inputs n v ops)=true := by
  rw [trace_iff]
  induction ops generalizing n v with
  | nil => simp [compile]
  | cons op xs ih =>
    obtain ⟨first,tail⟩:=sc
    obtain ⟨asserted,pass⟩:=Bool.and_eq_true_iff.mp ok
    intro g hg
    rcases List.mem_append.mp (show g∈op.emit n ++ compile (op.next n) xs from hg) with here|later
    · exact first_holds first asserted g here
    · exact ih tail pass g later

#print axioms compile_satisfies
end ExactWordFlow.SatGateTrace

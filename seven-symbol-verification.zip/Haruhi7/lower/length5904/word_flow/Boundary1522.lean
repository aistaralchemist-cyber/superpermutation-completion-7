import NinetyFour
import ExactBoundary
import Control1522

namespace ExactWordFlow.Boundary1522
open SevenWordWindows SuperpermutationBounds RotationCore RotationCoreControls

/-- The global decision can be posed at one exact length. -/
theorem exact_length :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
    ∃v : Block,v.length=1522 ∧ (visited v).card=720 ∧ 94≤(complete v).card := by
  rw [NinetyFour.exact_1522]
  constructor
  · rintro ⟨v,long,short,hv,hc⟩
    obtain ⟨z,len,all,done⟩:=ExactBoundary.pad long short
    exact ⟨z,len,all ▸ hv,done ▸ hc⟩
  · rintro ⟨v,sz,all,many⟩
    exact ⟨v,by omega,sz.le,all,many⟩

theorem exact_count (floor : Transfer5901.WordFloor 5898) :
    (∃w : Block,Covers w ∧ w.length≤5904) ↔
    ∃v : Block,v.length=1522 ∧ (visited v).card=720 ∧ (complete v).card=94 := by
  rw [exact_length]
  constructor
  · rintro ⟨v,len,hit,many⟩
    obtain ⟨w,yes,sz⟩:=expand_remaining (v:=v) (by omega) hit
    have low:=floor w yes
    exact ⟨v,len,hit,by omega⟩
  · rintro ⟨v,len,hit,count⟩
    exact ⟨v,len,hit,count.ge⟩

#print axioms exact_length
end ExactWordFlow.Boundary1522

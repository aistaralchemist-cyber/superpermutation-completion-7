import OverlapBudget

namespace ExactWordFlow
open ResidualIncidence ResidualRoutes SevenWordWindows

/-- Possible lengths of the root component under the scalar, endpoint-free
window bound, when the other components each have at most 72 steps. -/
def allowableLengths (loss : Nat) : Finset Nat := (Finset.range 859).filter fun k =>
  6*(719+loss)+5*k ≤ 5*858+6*(rootClassCap k-1)

theorem root_must_belong {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (small : largeOther X s=∅) (loss : Nat)
    (lower : 719+loss ≤ separateRank X s) : (part X (label X s)).card∈allowableLengths loss := by
  classical
  let k := (part X (label X s)).card
  have count := root_class_cap h.balance h.edges_seven
  have lim := (component_prices h.balance h.edges_seven).2.2 small
  have le : k≤X.card := Multiset.card_le_card (Multiset.filter_le ..)
  apply Finset.mem_filter.mpr
  refine ⟨Finset.mem_range.mpr (by omega),?_⟩
  omega

/-- Exact census of the remaining integer lengths allowed by this inequality
at each loss, together with their least and greatest members. -/
theorem length_table :
    ((List.range 11).map fun d => let K := allowableLengths d
      let xs := K.sort (· ≤ ·)
      (K.card,xs.head?.getD 0,xs.getLast?.getD 0)) =
    [(648,186,858),(585,252,856),(525,306,855),(463,372,854),
     (403,426,853),(341,492,852),(280,546,850),(218,612,849),
     (158,666,848),(96,732,847),(36,786,846)] := by native_decide

#print axioms root_must_belong
#print axioms length_table
end ExactWordFlow

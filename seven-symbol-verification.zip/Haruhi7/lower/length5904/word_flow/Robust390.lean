import SlackClosure

namespace ExactWordFlow.Robust390
open SevenWordWindows SeedWheelCut ExtremeWheelCut SlackClosure
open private digits widths from ExtremeWheelCut
private abbrev P := PlanarScore390.rootClasses

private def entries : List (String × Nat) :=
  [("0143562",45),("0143652",40),("0153426",45),("0163425",45),("0256314",45),
   ("0261435",45),("0265314",40),("0314526",45),("0354261",35),("0456132",45),
   ("0516342",16),("0526143",45),("0561324",45),("0564321",31),("0615342",45),
   ("0631452",45),("0654231",45)]
private def table := entries.map fun (s,n)=>(digits s,12*n)
private def targets := (table.map Prod.fst).toFinset
private def fee (c : Block) := (table.lookup c).getD 0
private def toll (w : Finset Block) := (∑x∈w∩targets, fee x)/((w∩P).card-1)
private def exposure (x : Block) := ∑w∈allRows, if x∈w then toll w else 0

private theorem data :
    targets⊆allClasses ∧ Disjoint P targets ∧ (∑x∈targets,fee x)=8424 ∧
    (∀x∈targets,fee x≤540) ∧
    (∀w∈allRows,toll w≤1020 ∧ (∑x∈w∩targets,fee x)≤toll w*((P∩w).card-1)) ∧
    (∀x∈P,exposure x≤1140) := by native_decide

/-- The obstruction survives arbitrary changes to the prototype as measured
by their actual exposure. A missing prototype tag of zero exposure costs
nothing, and adding a non-target tag does not weaken the certificate. -/
theorem weighted_neighbourhood {A : Finset Block} {W : Finset (Finset Block)}
    (legal : W⊆allRows) (linked : ClosedCover A allClasses W) :
    8424 ≤ 1020*(A.card+5*W.card-720) +
      (∑x∈P\A,exposure x) + (∑x∈targets∩A,fee x) := by
  obtain ⟨need,disjoint,total,individual,rows,exposed⟩:=data
  have bound:=SlackClosure.robust (P:=P) (H:=targets) legal need
    (fun w hw=> widths w (legal hw)) linked 1020 fee toll
    (fun w hw=>(rows w (legal hw)).1) (fun w hw=>(rows w (legal hw)).2)
  have split : (∑x∈targets\A,fee x)+(∑x∈targets∩A,fee x)=∑x∈targets,fee x := by
    have apart : Disjoint (targets\A) (targets∩A) := by
      apply Finset.disjoint_left.mpr
      intro x hx hy
      exact (Finset.mem_sdiff.mp hx).2 (Finset.mem_inter.mp hy).2
    have both : (targets\A)∪(targets∩A)=targets := by
      ext x
      simp only [Finset.mem_union,Finset.mem_sdiff,Finset.mem_inter]
      constructor
      · rintro (h|h) <;> exact h.1
      · intro h
        by_cases hA : x∈A
        · exact Or.inr ⟨h,hA⟩
        · exact Or.inl ⟨h,hA⟩
    rw [←Finset.sum_union apart,both]
  have boardSize : allClasses.card=720 := by native_decide
  change (∑x∈targets\A,fee x) ≤ 1020*(A.card+5*W.card-allClasses.card)+∑x∈P\A,exposure x at bound
  rw [boardSize] at bound
  omega

theorem uniform_distance {A : Finset Block} {W : Finset (Finset Block)}
    (legal : W⊆allRows) (linked : ClosedCover A allClasses W) :
    8424 ≤ 1020*(A.card+5*W.card-720) + 1140*(P\A).card + 540*(A\P).card := by
  obtain ⟨_,disj,_,indiv,_,expo⟩:=data
  have left : (∑x∈P\A,exposure x)≤(P\A).card*1140 := by
    apply Finset.sum_le_card_nsmul
    exact fun x hx => expo x (Finset.mem_sdiff.mp hx).1
  have right : (∑x∈targets∩A,fee x)≤(targets∩A).card*540 := by
    apply Finset.sum_le_card_nsmul
    exact fun x hx => indiv x (Finset.mem_inter.mp hx).1
  have incl : targets∩A⊆A\P := by
    intro x hx
    obtain ⟨target,inside⟩:=Finset.mem_inter.mp hx
    exact Finset.mem_sdiff.mpr ⟨inside,fun mem => Finset.disjoint_left.mp disj mem target⟩
  have card:=Finset.card_le_card incl
  have bill:=weighted_neighbourhood legal linked
  omega

/-- All sets of 390 rotation tags within five arbitrary substitutions of
the prototype fail the planar 66-wheel test, independent of visit order. -/
theorem exclude_five {A : Finset Block} {W : Finset (Finset Block)}
    (legal : W⊆allRows) (size : A.card≤390) (wheels : W.card≤66)
    (lost : (P\A).card≤5) : ¬ClosedCover A allClasses W := by
  intro linked
  have psize:=PlanarScore390.profile.2.2.1
  change P.card=390 at psize
  have a:=Finset.card_sdiff_add_card_inter A P
  have b:=Finset.card_sdiff_add_card_inter P A
  rw [Finset.inter_comm A P] at a
  have bound:=uniform_distance legal linked
  omega

/-- An independently tailored unit-price packing binds the exact root
more strongly than the swap-robust prices. -/
private def marked : Finset Block :=
  ((ForcedRootClosure.force P \ P) \ (["0135426","0143562","0256314"].map digits).toFinset)
private theorem packed :
    marked⊆allClasses ∧ (marked\P).card=15 ∧
      ∀w∈allRows,((w∩marked)\P).card≤(P∩w).card-1 := by native_decide

theorem exact_packets {W : Finset (Finset Block)} (legal : W⊆allRows)
    (linked : ClosedCover P allClasses W) : 69≤W.card := by
  have bill:=weighted (P:=P) (A:=P) (H:=marked) (Finset.Subset.refl _) packed.1
    (fun w hw=>widths w (legal hw)) linked 1 (fun _ => 1)
    (by intro w hw; simpa using packed.2.2 w (legal hw))
  have psize:=PlanarScore390.profile.2.2.1
  have boardSize : allClasses.card=720 := by native_decide
  simp only [Finset.sum_const, smul_eq_mul, mul_one,one_mul, packed.2.1,boardSize] at bill
  change P.card=390 at psize
  omega

theorem exact_length {W : Finset (Finset Block)} {q g L : Nat}
    (legal : W⊆allRows) (linked : ClosedCover P allClasses W) (count : W.card≤q)
    (genus : 390+6*q=q+1+719+2*g) (length : L=5764+(q+1)+73+2*g) :
    70≤q ∧ 5928≤L := by
  have enough:=exact_packets legal linked
  omega

#print axioms weighted_neighbourhood
#print axioms exclude_five
#print axioms exact_length
end ExactWordFlow.Robust390

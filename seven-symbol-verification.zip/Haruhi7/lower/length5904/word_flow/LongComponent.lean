import ResidualIncidence
import ResidualRoutes
import RouteDensity

/-! A short surplus cannot be assembled entirely from short Euler pieces.
This is a necessary condition on the weak support of the original integer
surplus, without normalizing or enumerating either endpoint. -/
namespace ExactWordFlow
open ResidualIncidence ResidualRoutes ResidualDensity DirectedEuler
open scoped Classical


theorem contacts_bound {X : Multiset Block} {q : Component X} {a b : Block}
    {es : List Block} (D : Finset Block) (lab : label X a=q)
    (r : Route src dst a es b) (eq : (↑es : Multiset Block)=part X q) :
    (contacts D (label X) q).card ≤ classCount a es := by
  classical
  apply Finset.card_le_card
  intro z mem
  obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp mem
  have ⟨_,lv,full⟩ := Finset.mem_filter.mp hv
  have reachable := visits lab r eq lv
  apply List.mem_toFinset.mpr
  apply List.mem_map.mpr
  exact ⟨v,List.mem_filter.mpr ⟨reachable,decide_eq_true full⟩,rfl⟩

/-- If 858 supplementary edges suffice, their start component must contain at
least 156 supplementary edges or another component must contain at least 61.
The bound is on the *same multiset* X, with multiplicity. -/
theorem long_component_858 {X : Multiset Block} {s t : Block}
    (h : Feasible X s t) (size : X.card ≤ 858) :
    156 ≤ (part X (label X s)).card ∨
      ∃ q : Component X, q ≠ label X s ∧ 61 ≤ (part X q).card := by
  classical
  let home := label X s
  let D := support X s
  let Q := D.image (label X)
  let C (q : Component X) := (contacts D (label X) q).card
  let K (q : Component X) := (part X q).card
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have hs : ∀ e∈X, label X (src e)∈Q := by
    intro e he
    rw [on_edge he]
    apply Finset.mem_image_of_mem
    exact Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))
  have sumK : ∑ q∈Q, K q = X.card := sum_part_card X Q hs
  have rank : 719 ≤ ∑ q∈Q, (C q-1) := rank719 (label X) h (fun _ he => on_edge he)
  by_contra! no
  obtain ⟨small,others⟩ := no
  have cap (q) (hq : q∈Q) : 6*(C q-1) ≤ 5*K q + (if q=home then 23 else 0) := by
    obtain ⟨v,_,lv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lab,endpoints⟩ := component_route h.balance v
    rw [lv] at eq lab endpoints
    have lengths : es.length=K q := congrArg Multiset.card eq
    have widths (e) (he : e∈es) : e.length=7 := by
      have inside : e∈part X q := eq ▸ (show e∈(↑es : Multiset Block) from he)
      exact h.edges_seven e (in_part.mp inside).1
    have count : C q ≤ classCount a es := contacts_bound D lab r eq
    by_cases hh : q=home
    · rw [ite_eq_left hh]
      have lim : es.length < 156 := by simpa [lengths,K,home,hh] using small
      have bound : 6*classCount a es < 5*es.length+30 := by
        by_contra! gain
        exact (Nat.not_le.mpr lim) (open_route_gain_24 r widths gain)
      omega
    · rw [ite_eq_right hh,Nat.add_zero]
      have lim : es.length≤60 := by have p:=others q hh; change K q<61 at p; omega
      obtain ⟨aa,bb⟩ := endpoints.2 hh
      subst a; subst b
      have bound := closed_route_gain r widths lim
      omega
  have vsum := Finset.sum_le_sum cap
  simp only [←Finset.mul_sum,Finset.sum_add_distrib,Finset.sum_ite_eq',root,ite_true,sumK] at vsum
  omega

/-- Actual length-5904 words inherit the dichotomy via their window multiset. -/
theorem long_component_of_word {w : SevenWordWindows.Word} (hw : SuperpermutationBounds.Covers w)
    (size : w.length=5904) : ∃ (X : Multiset Block) (s t : Block), X.card=858 ∧ Feasible X s t ∧
    (156 ≤ (part X (label X s)).card ∨ ∃ q : Component X, q ≠ label X s ∧ 61 ≤ (part X q).card) := by
  obtain ⟨X,n,flow⟩ := extract_at_ends w hw (by omega)
  refine ⟨X,_,_,by omega,flow,long_component_858 flow (by omega)⟩

end ExactWordFlow
#print axioms ExactWordFlow.long_component_858
#print axioms ExactWordFlow.long_component_of_word

import NearBindingCheck
import Cap94Data

namespace ExactWordFlow.Cap94Catalog
open SevenWordWindows RotationCore ExtremeWheelCut NearWheelBinding NearRootMoves
open private parse from NearBindingCheck

def rows : Array (Block × Answer) :=
  (((include_str "wheel-roots-94.txt").trimAscii.toString.splitOn "\n").map parse).toArray

end ExactWordFlow.Cap94Catalog

import CriticalLetters
import AlmostCover
import Superperm.BridgeCore

namespace SevenNormalizedWord
open SuperpermutationBounds
abbrev Word := List (Fin 7)

/-- Appending the first letter of the final permutation rotates that final
permutation. Repeat to attain any desired length while keeping the original
word as a prefix. -/
private theorem pad_tail (w : Word) (endp : ∃ u p : Word, w=u++p ∧ p.length=7 ∧ p.Nodup) (n : Nat) :
    ∃ t u p : Word, t.length=n ∧ w++t=u++p ∧ p.length=7 ∧ p.Nodup := by
  induction n with
  | zero =>
    obtain ⟨u,p,h,l,nd⟩ := endp
    exact ⟨[],u,p,rfl,by simpa using h,l,nd⟩
  | succ n ih =>
    obtain ⟨t,u,p,lt,h,l,nd⟩ := ih
    cases p with
    | nil => simp at l
    | cons a xs =>
      refine ⟨t++[a],u++[a],xs++[a],by simp [lt],?_,by simpa using l,?_⟩
      · calc
          w++(t++[a]) = (w++t)++[a] := (List.append_assoc ..).symm
          _ = (u++(a::xs))++[a] := by rw [h]
          _ = (u++[a])++(xs++[a]) := by simp
      · exact (List.perm_append_comm (l₁:=[a]) (l₂:=xs)).nodup_iff.mp nd

private theorem relabel_covers (f : Equiv.Perm (Fin 7)) {w : Word} (cover : Covers w) :
    Covers (w.map f) := by
  intro p len nd
  obtain ⟨u,v,h⟩ := cover (p.map f.symm) (by simpa using len) (nd.map f.symm.injective)
  exact ⟨u.map f,v.map f,by simp [h]⟩

/-- Every candidate at or below the target yields an exact-length candidate
beginning with 0123456 and ending in a permutation. The two endpoint
permutations may differ. -/
theorem normalize_5904 {w : Word} (cover : Covers w) (le : w.length ≤ 5904) :
    ∃ s : Word, s.length=5904 ∧ Covers s ∧
      (List.finRange 7 <+: s) ∧ ∃ p : Word, p.length=7 ∧ p.Nodup ∧ p <:+ s := by
  obtain ⟨z,hz,lz⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0<7)
  have zmin (v : Word) (c : Covers v) : z.length≤v.length :=
    lz.trans_le (SuperpermBridge.ssuper_le_length c)
  have ceiling := (zmin w cover).trans le
  obtain ⟨u,v,hfront⟩ := hz (List.finRange 7) List.length_finRange (List.nodup_finRange 7)
  have l0 := congrArg List.length hfront
  simp only [List.length_append,List.length_finRange] at l0
  have positive : 0 < z.length := by omega
  obtain ⟨first,a,b,lf,nf,atFirst,la,_,_⟩ :=
    SevenCriticalLetters.shortest_unique hz zmin 0 positive
  have nilA : a=[] := List.length_eq_zero_iff.mp (by omega)
  subst a
  simp only [List.nil_append] at atFirst
  obtain ⟨last,c,d,ll,nl,atLast,_,bound,_⟩ :=
    SevenCriticalLetters.shortest_unique hz zmin (z.length-1) (by omega)
  have pos := congrArg List.length atLast
  simp only [List.length_append] at pos
  have nilD : d=[] := List.length_eq_zero_iff.mp (by omega)
  subst d
  simp only [List.append_nil] at atLast
  obtain ⟨t,e,p,lt,ending,lp,np⟩ := pad_tail z ⟨c,last,atLast,ll,nl⟩ (5904-z.length)
  let f := (SevenAlmostCover.relabel first lf nf).symm
  have start : first.map f=List.finRange 7 := by
    have fwd := SevenAlmostCover.relabel_map first lf nf
    simpa [f] using congrArg (List.map f) fwd.symm
  refine ⟨(z++t).map f,by simp; omega,?_,?_,?_⟩
  · apply relabel_covers
    intro q lq nq
    obtain ⟨l,r,eq⟩ := hz q lq nq
    exact ⟨l,r++t,by simp [eq]⟩
  · refine ⟨(b++t).map f,?_⟩
    simp [atFirst,start]
  · exact ⟨p.map f,by simp [lp],np.map f.injective,⟨e.map f,by simp [ending]⟩⟩

end SevenNormalizedWord
#print axioms SevenNormalizedWord.normalize_5904

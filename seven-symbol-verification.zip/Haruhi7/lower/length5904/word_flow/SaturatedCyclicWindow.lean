import Cap94Prices

namespace ResidualDensity.SaturatedCyclicWindow
open private localMark localCount count_add chunks interval7 from DensityBudget

private theorem one {p : Nat→Prop} [DecidablePred p] (i : Nat) :
    count p i 1=(if p i then 1 else 0) := by
  simp only [count,Finset.card_filter,Finset.sum_range_one,Nat.add_zero]

private theorem shift {p : Nat→Prop} [DecidablePred p] (k : Nat)
    (periodic : ∀i,p (i+k) ↔ p i) (i : Nat) : count p i k=count p 0 k := by
  induction i with
  | zero => rfl
  | succ i ih =>
    have front:=count_add p i 1 k
    have back:=count_add p i k 1
    have same : count p (i+k) 1=count p i 1 := by simp only [one,periodic i]
    rw [Nat.add_comm 1 k] at front
    omega

/-- A cyclic window bound attained on an integer number of windows forces
the entire mark pattern to be periodic with the window length. -/
theorem saturation {p : Nat→Prop} [DecidablePred p] {a b m : Nat}
    (periodic : ∀i,p (i+b*(m+1)) ↔ p i)
    (cap : ∀i,count p i b≤a) (total : count p 0 (b*(m+1))=a*(m+1)) :
    (∀i,count p i b=a) ∧ (∀i,p (i+b) ↔ p i) := by
  have all (i : Nat) : count p i b=a := by
    have full:=(shift _ periodic i).trans total
    have remain:=chunks cap (i+b) m
    have plain:=count_add p i b (b*m)
    rw [Nat.mul_succ,Nat.add_comm (b*m) b,Nat.mul_succ] at full
    have :=cap i
    omega
  refine ⟨all,?_⟩
  intro i
  have front:=count_add p i 1 b
  have back:=count_add p i b 1
  rw [Nat.add_comm 1 b] at front
  rw [all,one] at front back
  by_cases x : p i <;> by_cases y : p (i+b) <;> simp_all

/-- The 35-edge component forced on 94-component inputs has six marks and
one unmarked position in every seven-window, with the same phase in all five laps. -/
theorem cycle35 {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    (walk : Walk u) (h : CyclicMarked u p 35) (covers : count p 0 35=30) :
    (∀i,count p i 7=6) ∧ (∀i,p (i+7) ↔ p i) := by
  apply saturation (m:=4) (a:=6) (b:=7) h.periodic _ covers
  intro i
  rw [←localCount i 7]
  exact interval7 walk (localMark h (by decide : 7≤35)) i

#print axioms cycle35
end ResidualDensity.SaturatedCyclicWindow

import NinetyTwo
import CrossingRotations

namespace ExactWordFlow.ExcursionCore
open SevenWordWindows RotationCore RotationReinsert LapSkeleton DirectedEuler ResidualDensity

/-- A shortest word at the score threshold, before restoration of missing laps. -/
def Minimal (limit : Nat) (w : Block) : Prop :=
  6≤w.length ∧ (visited w).card=720 ∧ score w≤limit ∧
    ∀z : Block,6≤z.length → (visited z).card=720 → score z≤limit → w.length≤z.length

theorem choose {w : Block} {limit : Nat} (long : 6≤w.length)
    (seen : (visited w).card=720) (budget : score w≤limit) :
    ∃ v : Block, Minimal limit v ∧ v.length≤w.length := by
  classical
  let P (n : Nat) := ∃v : Block,6≤v.length ∧ (visited v).card=720 ∧ score v≤limit ∧ v.length=n
  have nonempty : ∃n,P n := ⟨_,w,long,seen,budget,rfl⟩
  obtain ⟨v,vl,vs,vc,vn⟩:=Nat.find_spec nonempty
  refine ⟨v,⟨vl,vs,vc,?_⟩,vn.trans_le (Nat.find_min' nonempty ⟨w,long,seen,budget,rfl⟩)⟩
  intro z zl zs zc
  exact vn.trans_le (Nat.find_min' nonempty ⟨z,zl,zs,zc,rfl⟩)

/-- A class is lost precisely when at least one of its seven permutation edges
is absent from the retained route. Windows can be far apart in the original word. -/
def lost (w : Block) (keep : List Block) :=
  (complete w).filter (fun c=>∃p∈representatives,classKey p=c ∧ p∉keep)

def HoldsAll (s : Block) (keep : List Block) : Prop :=
  ∀c∈allClasses,∃u∈s::keep.map dst, full u ∧ tag u=c

/-- A route may erase many returns at once, preserve only selected duplicates,
or reorder the surviving edges. All that is needed is a six-letter initial
context, seven-letter edges, and an actual route still visiting each class. -/
theorem retained_route {w : Block} {limit : Nat} (min : Minimal limit w)
    {s t : Block} {keep : List Block} (route : Route src dst s keep t)
    (start : s.length=6) (width : ∀e∈keep,e.length=7) (tags : HoldsAll s keep)
    (short : keep.length<(windows w).length) :
    limit-score w+((windows w).length-keep.length)<7*(lost w keep).card := by
  classical
  obtain ⟨wl,ws,wc,least⟩:=min
  obtain ⟨v,sz,head,windowsV⟩:=spell_route route start width
  have vh : 6≤v.length := by omega
  have sees : allClasses⊆visited v := by
    intro c hc
    obtain ⟨u,hu,clean,eq⟩:=tags c hc
    exact (mem_visited _ _).mpr ⟨u,by simpa [anchors,head,windowsV] using hu,clean,eq⟩
  have vs : (visited v).card=720 := by rw [Finset.Subset.antisymm (visited_subset v) sees,board]
  have saved : complete w \ lost w keep ⊆complete v := by
    intro c hc
    obtain ⟨old,alive⟩:=Finset.mem_sdiff.mp hc
    apply (mem_complete _ _).mpr
    refine ⟨((mem_complete _ _).mp old).1,?_⟩
    intro e rep tagE
    rw [windowsV]
    by_contra absent
    exact alive (Finset.mem_filter.mpr ⟨old,e,rep,tagE,absent⟩)
  have ls : lost w keep⊆complete w:=Finset.filter_subset .. 
  have cost:=Finset.card_le_card saved
  rw [Finset.card_sdiff_of_subset ls] at cost
  have cw:=Finset.card_le_card (complete_subset w)
  have cv:=Finset.card_le_card (complete_subset v)
  have old := windows_length w
  by_contra! cheap
  have budget : score v≤limit := by
    unfold score at wc cheap ⊢
    omega
  have best:=least v vh vs budget
  omega

/-- When a family of deleted detours can endanger at most one more completed
class than the number of detours, its total excess above seven per detour is
at most six. The bound also accounts for unused score at the threshold. -/
theorem forest_price {w : Block} {limit : Nat} (min : Minimal limit w)
    {s t : Block} {keep : List Block} (route : Route src dst s keep t)
    (start : s.length=6) (width : ∀e∈keep,e.length=7) (tags : HoldsAll s keep)
    {m d : Nat} (cut : keep.length+7*m+d=(windows w).length)
    (positive : 0 < 7 * m + d) (few : (lost w keep).card ≤ m + 1) :
    limit - score w + d ≤ 6 := by
  have bound:=retained_route min route start width tags (by omega)
  omega

theorem necessity {w : Block} (long : 6≤w.length) (seen : (visited w).card=720)
    (len : w.length≤1508) (done : 92≤(complete w).card) :
    ∃ v : Block, Minimal 5904 v ∧ v.length≤1508 := by
  have budget : score w≤5904 := by unfold score; omega
  obtain ⟨v,min,short⟩:=choose long seen budget
  exact ⟨v,min,short.trans len⟩

#print axioms retained_route
#print axioms forest_price
end ExactWordFlow.ExcursionCore

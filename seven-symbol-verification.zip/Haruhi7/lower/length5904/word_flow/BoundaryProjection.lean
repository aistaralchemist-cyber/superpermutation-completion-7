import Boundary1508Floor
import JointDeletionShadow

namespace ExactWordFlow.BoundaryProjection
open SevenWordWindows SuperpermutationBounds RotationCore DeletionShadow

/-- A putative shorter word yields one common set of 92 rotations that fits
every deletion table, including their exact, position-based multiplicities. -/
theorem necessary (h : ∃w : Block,Covers w ∧ w.length≤5904) :
    ∃ v T, v.length=1508 ∧ (visited v).card=720 ∧ (complete v).card=92 ∧
      RauzyBudget.defect v=139 ∧ T⊆pool v ∧ T.card=92 ∧
      (∀(a : Fin 7) (d : Block),d∈board6 a → (T.filter (fun c=>proj a c=d)).card≤capacity a v d) ∧
      ∀a : Fin 7,92≤jointUpper a v := by
  obtain ⟨v,len,hit,count,debt⟩:=Boundary1508Floor.exact_obstruction.mp h
  obtain ⟨T,sub,sz,fit⟩:=simultaneous count.ge
  rw [←pool_eq] at sub
  exact ⟨v,T,len,hit,count,debt,sub,sz,fit,fun a=>count ▸ joint_bound a v⟩

theorem projection_suffices
    (bound : ∀v : Block,v.length=1508 → (visited v).card=720 → ∃a : Fin 7,jointUpper a v≤91) :
    SuperpermBridge.HR.Ssuper 7=5905 := by
  apply NinetyTwo.minimum_iff.mpr
  intro w small hit
  by_contra! many
  have long := (Boundary1508Floor.only_boundary small hit many).2
  obtain ⟨z,all,sz⟩:=expand_remaining (v:=w) (by omega) hit
  have candidate : ∃z : Block,Covers z ∧ z.length≤5904 := ⟨z,all,by omega⟩
  obtain ⟨v,_,len,vis,_,_,_,_,_,required⟩:=necessary candidate
  obtain ⟨a,upper⟩:=bound v len vis
  have lower:=required a
  omega

#print axioms necessary
end ExactWordFlow.BoundaryProjection

import WheelJoinOrder
import PathWheelCover

namespace ExactWordFlow.OnePath66
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels
open scoped Classical

private theorem tables : allClasses.card=720 ∧
    (∀v∈states, tag v∈allClasses) ∧
    (∀v∈states, (orbit v).toFinset ⊆ allClasses ∧ (orbit v).toFinset.card=6) := by
  native_decide

/-- For any literal path of 462 steps completed by 66 whole turns, at
least 62 wheels must contribute five previously unvisited rotation classes.
The sum bound is stronger for backbones touching fewer than 394 classes. -/
theorem sixty_two_fresh {a b s t : Block} {es ws : List Block}
    (r : Route src dst a es b) (n : es.length=462) (k : ws.length=66)
    (legit : ∀w∈ws, full w) (h : Feasible ((↑es : Multiset Block)+turns ws) s t) :
    ∃ ordering : List (Finset Block), ordering.Nodup ∧ ordering.toFinset=wheelSets ws ∧
      ordering.length=66 ∧ (∀j∈WheelJoinOrder.gains (pathClasses a es) ordering, j≤5) ∧
      456≤(pathClasses a es).card+(WheelJoinOrder.gains (pathClasses a es) ordering).count 5 ∧
      62≤(WheelJoinOrder.gains (pathClasses a es) ordering).count 5 := by
  apply WheelJoinOrder.sixty_two (V:=allClasses)
  · intro c hc
    obtain ⟨v,hv,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hc)
    exact tables.2.1 v (mem_states (of_decide_eq_true (List.mem_filter.mp hv).2))
  · intro w hw
    obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hw
    exact tables.2.2 v (mem_states (legit v (List.mem_toFinset.mp hv)))
  · exact cover_462_66 r n k legit h
  · exact tables.1
  · exact (contact_range r n k legit h).2.1
  · change (ws.toFinset.image _).card≤66
    exact Finset.card_image_le.trans ((List.toFinset_card_le ws).trans k.le)

#print axioms sixty_two_fresh
end ExactWordFlow.OnePath66

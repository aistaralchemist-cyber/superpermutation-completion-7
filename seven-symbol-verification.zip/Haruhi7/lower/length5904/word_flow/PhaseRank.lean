import PermutationGenus

namespace ExactWordFlow.PhaseRank
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [DecidableEq Y]

/-- Any coloring held fixed by a base successor F requires enough full
ordinary wheels to join its colors into a single actual successor orbit. -/
theorem color_budget {F W : Perm X} (start : X) (orbit : ∀y,(F*W).SameCycle start y)
    (color : X→Y) (base : ∀x,color (F x)=color x)
    (width : ∀c∈W.cycleFactorsFinset,c.support.card≤6) :
    (Finset.univ.image color).card ≤ 1+5*W.cycleFactorsFinset.card := by
  classical
  let wheels := W.cycleFactorsFinset.image (fun c=>c.support.image color)
  obtain ⟨Z,root,bound,closed⟩:=GlobalWheelRank.grow {color start} wheels
  have step (x : X) (present : color x∈Z) : color ((F*W) x)∈Z := by
    rw [Perm.mul_apply,base]
    by_cases fixed : W x=x
    · simpa [fixed] using present
    · have moved:=Perm.mem_support.mpr fixed
      have factor:=Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr moved
      have w : (W.cycleOf x).support.image color∈wheels := Finset.mem_image_of_mem _ factor
      have along (y : X) (hy : W.SameCycle x y) : color y∈(W.cycleOf x).support.image color :=
        Finset.mem_image_of_mem _ (Perm.mem_support_cycleOf_iff.mpr ⟨hy,moved⟩)
      exact closed _ w ⟨_,Finset.mem_inter.mpr ⟨present,along x (.refl _ _)⟩⟩
        (along (W x) (Perm.sameCycle_apply_right.mpr (.refl _ _)))
  have walk (n : Nat) : color (((F*W)^n) start)∈Z := by
    induction n with
    | zero => exact root (Finset.mem_singleton_self _)
    | succ n ih => simpa only [pow_succ',Perm.mul_apply] using step _ ih
  have seen : Finset.univ.image color⊆Z := by
    intro z hz
    obtain ⟨x,_,rfl⟩:=Finset.mem_image.mp hz
    obtain ⟨n,_,eq⟩:=(orbit x).exists_pow_eq'
    exact eq ▸ walk n
  have fees : (∑s∈wheels,(s.card-1)) ≤ 5*wheels.card := by
    have b:=Finset.sum_le_sum (s:=wheels) (g:=fun _=>5) (fun w hw=>show w.card-1≤5 by
      obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp hw
      have a:=Finset.card_image_le (f:=color) (s:=c.support)
      have upper:=width c hc
      omega)
    simpa [Nat.mul_comm] using b
  have n:=Finset.card_le_card seen
  have sz : wheels.card≤W.cycleFactorsFinset.card:=Finset.card_image_le
  simp only [Finset.card_singleton] at bound
  omega

/-- B consists of representatives from different actual base orbits in
the occupied tags. All original tags outside A still count separately.
Representatives may be chosen from any exception ordering and any genus. -/
theorem phase_budget {F W : Perm X} (start : X) (orbit : ∀y,(F*W).SameCycle start y)
    (width : ∀c∈W.cycleFactorsFinset,c.support.card≤6)
    (tag : X→Y) (V A : Finset Y) (realized : ∀t∈V,∃x,tag x=t) (inside : A⊆V)
    (region : ∀x,tag (F x)∈A ↔ tag x∈A) (stationary : ∀x,tag x∉A → tag (F x)=tag x)
    (B : Finset X) (occupied : ∀b∈B,tag b∈A)
    (apart : ∀b∈B,∀c∈B,F.SameCycle b c → b=c) :
    V.card+B.card ≤ A.card+1+5*W.cycleFactorsFinset.card := by
  classical
  let members (x : X) := B.filter (fun b=>F.SameCycle b x)
  let color (x : X) : Y ⊕ Finset X := if tag x∈A then Sum.inr (members x) else Sum.inl (tag x)
  have invariant (x : X) : color (F x)=color x := by
    have eq : members (F x)=members x := by ext; simp [members]
    by_cases old : tag x∈A
    · simp [color,old,(region x).mpr old,eq]
    · simp [color,old,stationary x old]
  have price:=color_budget start orbit color invariant width
  let singles : Finset (Finset X) := B.image fun b=>({b} : Finset X)
  have inc : (V\A).disjSum singles ⊆ Finset.univ.image color := by
    intro z hz
    cases z with
    | inl t =>
      have mem:=Finset.inl_mem_disjSum.mp hz
      obtain ⟨tV,tA⟩:=Finset.mem_sdiff.mp mem
      obtain ⟨x,hx⟩:=realized t tV
      exact Finset.mem_image.mpr ⟨x,Finset.mem_univ _,by simp [color,hx,tA]⟩
    | inr t =>
      have mem:=Finset.inr_mem_disjSum.mp hz
      obtain ⟨b,hb,rfl⟩:=Finset.mem_image.mp mem
      have single : members b={b} := by
        ext v
        constructor
        · intro h
          obtain ⟨hv,hc⟩:=Finset.mem_filter.mp h
          exact Finset.mem_singleton.mpr (apart _ hv _ hb hc)
        · intro h
          obtain rfl:=Finset.mem_singleton.mp h
          exact Finset.mem_filter.mpr ⟨hb,.refl _ _⟩
      exact Finset.mem_image.mpr ⟨b,Finset.mem_univ _,by simp [color,occupied b hb,single]⟩
  have size:=Finset.card_le_card inc
  have count : singles.card=B.card := Finset.card_image_of_injective _ (fun _ _=>Finset.singleton_inj.mp)
  rw [Finset.card_disjSum,Finset.card_sdiff_of_subset inside,count] at size
  have le:=Finset.card_le_card inside
  omega

/-- Apply the split-orbit condition directly to R times the exceptional
permutation J. Its support alone determines the occupied tags. -/
theorem exceptional_faces {R J W : Perm X} (start : X) (orbit : ∀y,((R*J)*W).SameCycle start y)
    (width : ∀c∈W.cycleFactorsFinset,c.support.card≤6) (tag : X→Y) (V : Finset Y)
    (realized : ∀t∈V,∃x,tag x=t) (valid : ∀x,tag x∈V) (rot : ∀x,tag (R x)=tag x)
    (B : Finset X) (occupied : ∀b∈B,tag b∈J.support.image tag)
    (apart : ∀b∈B,∀c∈B,(R*J).SameCycle b c → b=c) :
    V.card+B.card ≤ (J.support.image tag).card+1+5*W.cycleFactorsFinset.card := by
  let A:=J.support.image tag
  have stationary (x) (off : tag x∉A) : J x=x := by
    by_contra moved
    exact off (Finset.mem_image_of_mem _ (Perm.mem_support.mpr moved))
  have zone (x) : tag (J x)∈A ↔ tag x∈A := by
    by_cases fix : J x=x
    · rw [fix]
    · have ind : J (J x)≠J x := fun eq=>fix (J.injective eq)
      exact iff_of_true (Finset.mem_image_of_mem _ (Perm.mem_support.mpr ind))
        (Finset.mem_image_of_mem _ (Perm.mem_support.mpr fix))
  apply phase_budget start orbit width tag V A realized (by
    intro t ht
    obtain ⟨x,_,rfl⟩:=Finset.mem_image.mp ht
    exact valid x) (by simpa only [Perm.mul_apply,rot] using zone)
    (by intro x hx; rw [Perm.mul_apply,rot,stationary x hx]) B occupied apart

/-- Charging the b distinguished occupied faces against the actual genus
g and the length budget, with M exceptional states on a occupied tags. -/
theorem budget_at_5904 {M a b q e g s L : Nat} (tags : a≤M)
    (face_bound : 720+b≤a+1+5*q) (mass : M+5*q=719+e+2*g)
    (length : L=5045+M+s+6*q) (short : L≤5904) :
    (M-a)+b≤e+2*g ∧ 19+5*s+6*((M-a)+b)+5*(5904-L)≤M := by omega

#print axioms color_budget
#print axioms phase_budget
#print axioms exceptional_faces
#print axioms budget_at_5904
end ExactWordFlow.PhaseRank

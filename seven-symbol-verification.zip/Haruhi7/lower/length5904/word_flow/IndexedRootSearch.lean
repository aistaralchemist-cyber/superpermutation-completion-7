import BatchedRealizations
import Std.Data.HashSet.Lemmas

namespace ResidualDensity.IndexedRootSearch
open SevenWordWindows ExtremalRealizations
open private canonical from Interval66
open private rowSets from ExtremalRealizations
open private firsts tailsFor tails_spec from BatchedRealizations

/-- The tree is constructed independently of the actual letter choices. -/
inductive Trie where
  | node (done : Bool) (edges : List (Nat × Trie))

private def trie : Nat → List (List Nat) → Trie
  | 0,ps => .node (ps.contains []) []
  | n+1,ps => .node (ps.contains [])
      ((firsts ps).map (fun k => (k,trie n (tailsFor k ps))))

private def done : Trie → Bool
  | .node a _=>a

private def edges : Trie → List (Nat × Trie)
  | .node _ es=>es

private inductive InTrie : List Nat → Trie → Prop
  | nil {t} : done t=true → InTrie [] t
  | cons {k t child ks} : (k,child)∈edges t → InTrie ks child → InTrie (k::ks) t

private theorem accepted (k : Nat) (ps : List (List Nat)) {q : List Nat} (hq : q∈ps)
    (len : q.length≤k) : InTrie q (trie k ps) := by
  induction k generalizing q ps with
  | zero =>
    have eq:=List.eq_nil_of_length_eq_zero (by omega : q.length=0)
    subst q
    exact .nil (by simpa [done,trie])
  | succ n ih =>
    cases q with
    | nil => exact .nil (by simpa [done,trie])
    | cons k q =>
      have h:= (tails_spec k ps q).mpr hq
      have first : k∈firsts ps := List.mem_eraseDups.mpr (List.mem_filterMap.mpr ⟨_,hq,rfl⟩)
      apply InTrie.cons (child:=trie n (tailsFor k ps))
      · exact List.mem_map.mpr ⟨k,first,rfl⟩
      · exact ih _ h (by simpa using len)

private def asEnd (t : Trie) (seen : List Six) : List (Finset Six) :=
  if done t then [seen.toFinset] else []

private def explore : Nat → Trie → Six → List Six → Std.HashSet Six → List (Finset Six)
  | 0,t,_,seen,_=>asEnd t seen
  | depth+1,t,s,seen,idx=> asEnd t seen ++ (edges t).flatMap fun (k,child) =>
    let later:= !((edges child).isEmpty)
    if k=0 then asEnd child seen ++ (if later then (List.finRange 7).flatMap fun a=>
      explore depth child (step s a) seen idx else [])
    else if full s then
      let hits:=rowTags s k
      if hits.all (fun x=> !idx.contains x) then
        let more:=hits++seen
        asEnd child more ++ (if later then
          let nextIdx:=idx.insertMany hits
          let last:=s.rotate (k-1)
          (List.finRange 7).flatMap fun a=>(List.finRange 7).flatMap fun b=>
            explore depth child (step (step last a) b) more nextIdx else [])
      else []
    else []

private theorem must_later {k : Nat} {ks : List Nat} {t : Trie} (h : InTrie (k::ks) t) :
    !(edges t).isEmpty := by
  cases h with
  | cons yes _ => rw [Bool.not_eq_true']; exact List.isEmpty_eq_false_iff.mpr (List.ne_nil_of_mem yes)

private theorem sound (fuel : Nat) (t : Trie) (q : List Nat) (s : Six) (seen : List Six)
    (idx : Std.HashSet Six) (cache : ∀x∈idx,x∈seen) (path : InTrie q t) (len : q.length≤fuel) :
    rowSets q s seen ⊆ explore fuel t s seen idx := by
  induction fuel generalizing q t s seen idx with
  | zero =>
    have eq:=List.eq_nil_of_length_eq_zero (by omega : q.length=0)
    subst q
    cases path with
    | nil ending => simp [explore,asEnd,ending,rowSets]
  | succ d ih =>
    cases q with
    | nil =>
      cases path with
      | nil ending => intro x hx; exact List.mem_append_left _ (by simpa [rowSets,asEnd,ending] using hx)
    | cons k ks =>
      cases path with
      | cons edge tail =>
        intro x hx
        rw [explore]
        apply List.mem_append_right
        apply List.mem_flatMap.mpr
        refine ⟨_,edge,?_⟩
        dsimp only
        by_cases zero : k=0
        · subst k
          rw [rowSets,ite_eq_left rfl] at hx
          rw [ite_eq_left rfl]
          cases ks with
          | nil =>
            cases tail with
            | nil ending => exact List.mem_append_left _ (by simpa [asEnd,ending] using hx)
          | cons m ms =>
            simp only [List.isEmpty_cons,Bool.false_eq_true,ite_false,List.mem_flatMap] at hx
            obtain ⟨a,ha,child⟩:=hx
            apply List.mem_append_right
            rw [ite_eq_left (must_later tail)]
            exact List.mem_flatMap.mpr ⟨a,ha,ih _ _ _ _ _ cache tail (by simpa using len) child⟩
        · rw [rowSets,ite_eq_right zero] at hx
          rw [ite_eq_right zero]
          by_cases ok : (decide (full s) && (rowTags s k).all (fun z=>decide (z∉seen)))=true
          · rw [ite_eq_left ok] at hx
            obtain ⟨ful,clear⟩:=Bool.and_eq_true_iff.mp ok
            rw [ite_eq_left (of_decide_eq_true ful)]
            have may : (rowTags s k).all (fun z=> !idx.contains z)=true := by
              apply List.all_eq_true.mpr
              intro z hz
              have avoid:=of_decide_eq_true (List.all_eq_true.mp clear _ hz)
              rw [Bool.not_eq_true']; exact Bool.eq_false_iff.mpr (fun h=>avoid (cache z (Std.HashSet.contains_iff_mem.mp h)))
            rw [ite_eq_left may]
            cases ks with
            | nil =>
              cases tail with
              | nil ending => exact List.mem_append_left _ (by simpa [asEnd,ending] using hx)
            | cons m ms =>
              simp only [List.isEmpty_cons,Bool.false_eq_true,ite_false,List.mem_flatMap] at hx
              obtain ⟨a,ha,b,hb,child⟩:=hx
              apply List.mem_append_right
              rw [ite_eq_left (must_later tail)]
              apply List.mem_flatMap.mpr
              refine ⟨a,ha,List.mem_flatMap.mpr ⟨b,hb,?_⟩⟩
              apply ih _ _ _ _ _ _ tail (by simpa using len) child
              intro z hz
              rw [Std.HashSet.mem_insertMany_list] at hz
              rcases hz with old|new
              · exact List.mem_append_right _ (cache _ old)
              · exact List.mem_append_left _ (List.contains_iff_mem.mp new)
          · rw [ite_eq_right ok] at hx; exact (List.not_mem_nil hx).elim

def results (ps : List (List Nat)) : List (Finset Six) :=
  let d:= (ps.map List.length).sum
  let t:=trie d ps
  canonical.flatMap (fun s=>explore d t s [] {})

theorem complete (ps : List (List Nat)) : realizations ps ⊆ results ps := by
  intro R h
  obtain ⟨q,hq,more⟩:=List.mem_flatMap.mp h
  obtain ⟨s,hs,yes⟩:=List.mem_flatMap.mp more
  let len := (ps.map List.length).sum
  have low : q.length≤len := List.single_le_sum (fun _ _=>Nat.zero_le _) _
    (List.mem_map_of_mem hq)
  exact List.mem_flatMap.mpr ⟨s,hs,sound len _ q s [] {} (by simp) (accepted _ _ hq low) low yes⟩
end ResidualDensity.IndexedRootSearch

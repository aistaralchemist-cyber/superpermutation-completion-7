import NearHundredShape
import Cap95Marked

set_option maxHeartbeats 450000
namespace ExactWordFlow.Cap95Shape
open SevenWordWindows ResidualDensity ResidualDensity.Density66 DirectedEuler ResidualRoutes ResidualIncidence
open GlobalDensity66 RotationComponentCount MarkedLargeCap
open scoped Classical
open private initial from MarkedDensity
open private two_mass closed111 from MarkedLargeCap
open private cyclic_cap closed_price from GlobalDensity66
open private all_contacts from OverlapBudget

private def open95 (k : Nat) := Cap95Marked.upper (k+1) initial
private def close95 (k : Nat) := min (min (56*k/66) (if 111≤k then 94*k/111 else 720))
  (if 137≤k then 116*k/137 else 720)
private theorem scalar : ∀ r b : Fin 295,79≤b.val → r.val+b.val≤294 →
    6*(open95 r.val-1)+6*(close95 b.val-1)<5*(r.val+b.val)+24 := by native_decide

private theorem closed137 {a : Block} {p : List Block} (r : Route src dst a p a)
    (wd : ∀e∈p,e.length=7) (lo : 137≤p.length) : 137*classCount a p≤116*p.length := by
  obtain ⟨u,I,w,hm,cc⟩ := closed_observations r wd (by omega)
  have n:=window_cyclic_bound hm lo (fun i pp _ hh=>Cap95Marked.interval137 w hh i)
  simpa only [cc] using n

theorem large_count
    {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (paid : 66*separateRank X s+6*(active X s).card+60*(large X s).card≤56*X.card+66)
    (hasBig : (large X s).Nonempty) : (occupied X s).card≤94 := by
  classical
  rw [occupied_active h]
  by_contra! many
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  let C (q : Component X) := (contacts (support X s) (label X) q).card
  have rk : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  obtain ⟨qBig,hBig⟩:=hasBig
  obtain ⟨bigIn,away,atleast⟩:=Finset.mem_filter.mp hBig
  change qBig∈Q at bigIn
  change qBig≠home at away
  change 79≤K qBig at atleast
  have bigOnly : (large X s).card≤1 := by omega
  have actBig : qBig∈active X s := Finset.mem_filter.mpr ⟨bigIn,away,show 6≤K qBig by omega⟩
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q=X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have raw : 6*(active X s).card+K home+K qBig≤X.card+6 := two_mass actBig
  have leftMass : K home+K qBig≤294 := by omega
  have get (q) (hq : q∈Q) :
      (q=home → C q≤open95 (K q)) ∧
      (q=qBig → C q≤close95 (K q)) ∧
      (q≠home → q≠qBig → 6*(C q-1)≤5*K q) := by
    obtain ⟨v,_,vv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩:=component_route h.balance v
    rw [vv] at eq lv ep
    have len : es.length=K q := congrArg Multiset.card eq
    have wd (e) (he : e∈es) := h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have incl : C q≤classCount a es:=contacts_bound _ lv r eq
    refine ⟨?_,?_,?_⟩
    · intro atHome
      have lim : es.length+1≤289 := by rw [len,atHome]; omega
      simpa only [open95,len] using incl.trans (Cap95Marked.route_upper r wd lim)
    · rintro rfl
      obtain ⟨aa,bb⟩:=ep.2 away
      subst a; subst b
      change 79≤K q at atleast
      have lo:=cyclic_cap r wd (by omega)
      unfold close95
      refine le_min (le_min (by omega) ?_) ?_
      · split
        next largeSize => have cl:=closed111 r wd (by omega); omega
        next => exact all_contacts ..
      · split
        next largeSize => have cl:=closed137 r wd (by omega); omega
        next => exact all_contacts ..
    · intro notRoot notBig
      obtain ⟨aa,bb⟩:=ep.2 notRoot
      subst a; subst b
      have small : es.length<79 := by
        by_contra! bad
        have seen : q∈large X s := Finset.mem_filter.mpr ⟨hq,notRoot,show 79≤K q by omega⟩
        exact notBig (Finset.card_le_one.mp bigOnly _ seen _ hBig)
      have cl:=closed_price r wd small
      omega
  have compare (q) (hq : q∈Q) :
      6*(C q-1)+(if q=home then 5*K home else 0)+(if q=qBig then 5*K qBig else 0)≤
        5*K q+(if q=home then 6*(C home-1) else 0)+(if q=qBig then 6*(C qBig-1) else 0) := by
    by_cases R : q=home
    · subst q; simp [Ne.symm away,Nat.add_comm]
    by_cases B : q=qBig
    · subst q; simp [away,Nat.add_comm]
    simpa [R,B] using (get q hq).2.2 R B
  have bound:=Finset.sum_le_sum compare
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_ite_eq',root,bigIn,ite_true,total] at bound
  change 6*separateRank X s+5*K home+5*K qBig≤_ at bound
  have hroot:=(get home root).1 rfl
  have hbig:=(get qBig bigIn).2.1 rfl
  have check:=scalar ⟨K home,by omega⟩ ⟨K qBig,by omega⟩ atleast leftMass
  change 6*(open95 (K home)-1)+6*(close95 (K qBig)-1)<5*(K home+K qBig)+24 at check
  omega

open private hits Cost totals rank_partition from NearHundredShape

private def simple (k : Nat) := if k=259 then 220 else (38*(k+1)+66)/45

private theorem zeroExcess : ∀x : Fin 289,∀y : Fin 31,258≤x.val → x.val+y.val≤288 →
    719≤(simple x.val-1)+((3325+6*y.val-(if 0<y.val then 6 else 0))/7) →
    y.val=0 ∧ x.val=288 := by native_decide

private theorem frontier {k f w a : Nat} (low : 258≤k) (pay : k+f≤288)
    (price : 45*a≤38*(k+1)+66) (edge : k=259 → a≤220) (cover : 719≤(a-1)+w)
    (close : 7*w+(if 0<f then 6 else 0)≤3325+6*f) :
    f=0 ∧ k=288 ∧ a=245 ∧ w=475 := by
  have ub : a ≤ simple k := by unfold simple; split <;> omega
  have ubW : w≤(3325+6*f-(if 0<f then 6 else 0))/7 := by
    by_cases hp : 0<f <;> simp only [hp,ite_true,ite_false] at close ⊢ <;> omega
  have yes : 719≤(simple k-1)+((3325+6*f-(if 0<f then 6 else 0))/7) := by omega
  have cert:=zeroExcess ⟨k,by omega⟩ ⟨f,by omega⟩ low pay yes
  change f=0 ∧ k=288 at cert
  obtain ⟨rfl,rfl⟩:=cert
  simp at close price ⊢
  omega

private theorem at260 : open95 259=220 := by native_decide

theorem shape
    {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (nr : (occupied X s).card=95) :
    let N:=(occupied X s).card
    X.card=858 ∧ (part X (label X s)).card+6*N=858 ∧
      separateRank X s=719 ∧ hits X s (label X s)+5*N=720 ∧
      ∀q∈occupied X s,(part X q).card=6 ∧ ∃v,full v ∧ label X v=q ∧ part X q=↑(GlobalWheelRank.wheel v) := by
  classical
  let Q:=occupied X s
  let N:=Q.card
  let E:=∑q∈Q,(Cost X q-6)
  let R:=∑q∈Q,(hits X s q-1)
  change N=95 at nr
  have high : N≤100 := MarkedComponentCap.component_limit h budget
  have noBig : large X s=∅ := by
    by_contra! someBig
    have bound : N≤94 :=large_count h budget (MarkedComponentCap.component_prices h budget).1 someBig
    omega
  have home:= (MarkedComponentCap.component_prices h budget).2 noBig
  obtain ⟨a,b,es,eq,route,lab,ep⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ep.1 rfl
  subst a; subst b
  have len : es.length=Cost X (label X s) := congrArg Multiset.card eq
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
  have hit : hits X s (label X s)≤classCount s es := contacts_bound _ lab route eq
  obtain ⟨mass,weight⟩:=totals h
  change Cost X (label X s)+6*N+E=X.card at mass
  change 7*R+(if 0<E then 6 else 0)≤35*N+6*E at weight
  have rank:=rank_partition h
  change separateRank X s=(hits X s (label X s)-1)+R at rank
  have floor : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  change 258≤Cost X (label X s) at home
  have obs:=Cap95Marked.route_upper route wd (by omega)
  have pay:=WeightedMarks.path_cap route wd
  have edge (v : es.length=259) : classCount s es≤220 := by
    change classCount s es≤open95 es.length at obs
    rwa [v,at260] at obs
  have cost : es.length+E≤288 := by omega
  have rprice : 7*R+(if 0<E then 6 else 0)≤3325+6*E := by simpa only [nr] using weight
  have forces:=frontier (k:=es.length) (f:=E) (w:=R) (a:=classCount s es)
    (by omega) cost pay edge (by omega) rprice
  obtain ⟨zero,tight,full,contrib⟩:=forces
  have each (q) (hq : q∈Q) : Cost X q=6 := by
    have sub := Finset.single_le_sum (s:=Q) (f:=fun q=>Cost X q-6) (fun _ _=>Nat.zero_le _) hq
    change Cost X q-6≤E at sub
    have minSz : 6≤Cost X q := (Finset.mem_filter.mp (show q∈active X s from occupied_active h ▸ hq)).2.2
    omega
  change X.card=858 ∧ Cost X (label X s)+6*N=858 ∧ separateRank X s=719 ∧
    hits X s (label X s)+5*N=720 ∧ _
  refine ⟨by omega,by omega,by omega,by omega,fun q hq=>⟨each q hq,?_⟩⟩
  exact six_component h (Finset.mem_erase.mp hq).1 (each q hq)

#print axioms large_count
#print axioms shape
end ExactWordFlow.Cap95Shape

import FusedPacked93
import NinetyThree
import Cap93Lookup
import WheelOnly93
import Control1508

namespace ExactWordFlow.NinetyTwo
open SevenWordWindows SuperpermutationBounds ResidualDensity RotationComponentCount RotationCore

/-- Every residual multiset with budget 858 has at most 92 nonstart
components carrying edges. Both boundary geometries and their wheel
certificates have been checked for arbitrary feasible multisets. -/
theorem component_limit {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (bd : X.card≤858) : (occupied X s).card≤92 := by
  have older:=NinetyThree.component_limit h bd
  by_contra! many
  have n : (occupied X s).card=93:=by omega
  obtain ⟨_,edges,tags,six⟩:=WheelOnly93.shape h bd n
  obtain ⟨R,hit,W,legal,sz,closed⟩:=FusedAny.cover_certificate (by decide) FusedAny.profile300
    Cap93Lookup.accept FusedPacked93.checked h edges tags.ge six
  exact Cap93Lookup.no_cover hit legal (sz.trans n.le) closed

theorem exact_length : (∃w : Block,Covers w ∧ w.length≤5904) ↔ BudgetCoreCurve.atLength 1508 92 :=
  BudgetCoreCurve.threshold 858 92 (by decide) (@component_limit)

open private neg_witness from Target107

theorem ceiling_iff : Target107.ceiling 1620 107 ↔ Target107.ceiling 1508 91 := by
  rw [neg_witness 1620 107,neg_witness 1508 91]
  exact not_congr (RotationCore.exact_1620.symm.trans
    (ComponentCurve.exact_threshold (k:=92) (@component_limit) (by decide) (by decide)))

/-- The original minimum is determined exactly by the smaller ceiling. -/
theorem minimum_iff : SuperpermBridge.HR.Ssuper 7=5905 ↔ Target107.ceiling 1508 91 := by
  exact Target107.goal_iff_minimum.symm.trans ceiling_iff

#print axioms component_limit
#print axioms exact_length
#print axioms minimum_iff
end ExactWordFlow.NinetyTwo

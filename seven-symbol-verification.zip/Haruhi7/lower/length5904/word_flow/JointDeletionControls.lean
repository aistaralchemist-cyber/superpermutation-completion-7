import JointDeletionShadow
import DeletionControls

namespace ExactWordFlow.JointDeletionControls
open RotationCoreControls DeletionShadow DeletionControls

/-- Remove the fifth letter of the 1,509-letter W-0021 core. -/
def interior := (coreWord 628).eraseIdx 4

private def check : Bool :=
  summary interior == (1508,720,91) &&
  bounds interior == [107,98,102,102,92,93,160] &&
  (pool interior).card == 92 &&
  jointVector interior == [92,91,91,91,91,91,91]

theorem interior_control :
    summary interior = (1508,720,91) ∧
    bounds interior = [107,98,102,102,92,93,160] ∧
    (pool interior).card = 92 ∧
    jointVector interior = [92,91,91,91,91,91,91] := by
  have record : check=true := by native_decide
  simp only [check,Bool.and_eq_true,beq_iff_eq] at record
  exact ⟨record.1.1.1,record.1.1.2,record.1.2,record.2⟩

#print axioms interior_control
end ExactWordFlow.JointDeletionControls

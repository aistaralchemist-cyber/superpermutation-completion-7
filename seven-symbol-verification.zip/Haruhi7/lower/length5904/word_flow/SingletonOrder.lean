import ResidualControls
import WheelContacts

/-! An order certificate for the 380 rotation classes untouched by any of
the 66 wheels of the 5,905-letter construction. Each observation may freely
choose any one of seven six-letter contexts. Intermediate letters are unrestricted. -/
namespace ExactWordFlow.SingletonOrder
open SevenWordWindows ResidualDensity

def context (w : Block) (i : Nat) := (w.drop i).take 6

/-- The listed rotation classes have observations at nondecreasing positions. -/
inductive VisitsFrom (w : Block) : List Block → Nat → Prop
  | nil (i) : VisitsFrom w [] i
  | cons {i j : Nat} {c : Block} {cs : List Block} (ordered : i≤j) (valid : j+6≤w.length)
      (clean : full (context w j)) (key : tag (context w j)=c)
      (rest : VisitsFrom w cs j) : VisitsFrom w (c::cs) i

def phases (c : Block) := (List.range 7).map fun k => (c.rotate k).take 6

private theorem phase_table : ∀v∈states, v∈phases (tag v) := by native_decide

private def least (xs : List Nat) (cap : Nat) := xs.foldr min cap

private theorem least_cap (xs : List Nat) (cap : Nat) : least xs cap≤cap := by
  induction xs with
  | nil => exact le_rfl
  | cons x xs ih => exact (min_le_right ..).trans ih

private theorem least_entry (xs : List Nat) (cap : Nat) {k : Nat} (hit : k∈xs) : least xs cap≤k := by
  induction xs with
  | nil => simp at hit
  | cons x xs ih =>
    rcases List.mem_cons.mp hit with rfl|mem
    · exact min_le_left ..
    · exact (min_le_right ..).trans (ih mem)

private def shifts (a b : Block) := (List.range 6).filter fun n => a.drop n == b.take (6-n)
def gap (a b : Block) := least (shifts a b) 6

private theorem gap_between (w : Block) {i j : Nat} (ord : i≤j) :
    gap (context w i) (context w j) ≤ j-i := by
  by_cases far : 6≤j-i
  · exact (least_cap _ _).trans far
  · apply least_entry
    have overlap : (context w i).drop (j-i) = (context w j).take (6-(j-i)) := by
      simp only [context,List.drop_take,List.drop_drop,List.take_take]
      rw [show i+(j-i)=j by omega, Nat.min_eq_left (by omega)]
    exact List.mem_filter.mpr ⟨List.mem_range.mpr (by omega),beq_iff_eq.mpr overlap⟩

private abbrev Row := List (Block×Nat)
private def start (c : Block) : Row := (phases c).map fun v => (v,0)
private def advance (r : Row) (c : Block) : Row := (phases c).map fun v =>
  (v,least (r.map fun p => p.2+gap p.1 v) 10000)
private def finish (r : Row) (cs : List Block) : Row := cs.foldl advance r

def steps : List Block → Nat
  | [] => 0
  | c::cs => least ((finish (start c) cs).map Prod.snd) 10000

private theorem extend {w : Block} {cs : List Block} {i : Nat} (h : VisitsFrom w cs i)
    (r : Row) {k : Nat} (member : (context w i,k)∈r) (cost : k ≤ i) (valid : i+6≤w.length) :
    ∃ p∈finish r cs, p.2+6≤w.length := by
  induction h generalizing r k with
  | nil =>
    exact ⟨_,member,by omega⟩
  | @cons i j c cs order size clean key rest ih =>
    let a := context w i
    let b := context w j
    let low := least (r.map fun p => p.2+gap p.1 b) 10000
    have pb : b∈phases c := key ▸ phase_table b (mem_states clean)
    have inRow : (b,low)∈advance r c := List.mem_map.mpr ⟨b,pb,rfl⟩
    have hit : k+gap a b∈r.map (fun p => p.2+gap p.1 b) := List.mem_map.mpr ⟨_,member,rfl⟩
    have le : low≤k+gap a b := least_entry _ _ hit
    have d : gap a b≤j-i := gap_between w order
    exact ih (advance r c) inRow (by omega) size

theorem steps_bound {w : Block} {cs : List Block} (nonempty : cs≠[]) (h : VisitsFrom w cs 0) :
    steps cs+6≤w.length := by
  cases h with
  | nil => contradiction
  | @cons _ j c cs _ size clean key rest =>
    have phit : context w j∈phases c := key ▸ phase_table _ (mem_states clean)
    have mem : (context w j,0)∈start c := List.mem_map.mpr ⟨_,phit,rfl⟩
    obtain ⟨p,hp,atEnd⟩ := extend rest (start c) mem (Nat.zero_le j) size
    have d : steps (c::cs)≤p.2 := least_entry _ _ (List.mem_map.mpr ⟨p,hp,rfl⟩)
    omega

def wheelLabels := (ResidualControls.wheelWords.flatMap fun w =>
  (ResidualControls.vertices w).filterMap fun v => if full v then some (tag v) else none).toFinset

def order := ((ResidualControls.vertices ResidualControls.mainWord).filterMap fun v =>
  if full v then some (tag v) else none).filter (fun c => c∉wheelLabels)

theorem counts : order.length=380 ∧ order.Nodup ∧ (allClasses\wheelLabels)=order.toFinset ∧
    steps order=463 := by native_decide

/-- Allowing all intermediate states, all endpoint choices, and all phases,
any path preserving the relative order of these 380 singleton classes has
at least 463 edges. This restriction ignores the other ten wheel components. -/
theorem singleton_order_floor {w : Block} (visits : VisitsFrom w order 0) : 469≤w.length := by
  obtain ⟨len,_,_,val⟩ := counts
  have ne : order≠[] := by intro empty; simp [empty] at len
  have bound := steps_bound ne visits
  omega

/-- Each suborder uses both end classes and one of two disjoint sets of
189 interior classes. No assumption is made on the other 189 inner classes. -/
def alternate (parity : Nat) := (order.zipIdx.filter fun p =>
  p.2=0 || p.2+1=order.length || p.2%2=parity).map Prod.fst

theorem two_certificates : (alternate 0).length=191 ∧ (alternate 1).length=191 ∧
    steps (alternate 0)=463 ∧ steps (alternate 1)=463 ∧
    ((alternate 0).toFinset∩(alternate 1).toFinset).card=2 := by native_decide

theorem either_suborder_floor {w : Block}
    (h : VisitsFrom w (alternate 0) 0 ∨ VisitsFrom w (alternate 1) 0) : 469≤w.length := by
  obtain ⟨n,m,x,y,_⟩ := two_certificates
  rcases h with left|right
  · have pos : alternate 0≠[] := by intro eq; simp [eq] at n
    have bound := steps_bound pos left
    omega
  · have pos : alternate 1≠[] := by intro eq; simp [eq] at m
    have bound := steps_bound pos right
    omega

private def checkPositions (w : Block) : Nat → List Nat → List Block → Bool
  | _, [], [] => true
  | i, j::js, c::cs =>
    decide (i≤j ∧ j+6≤w.length ∧ full (context w j) ∧ tag (context w j)=c) &&
      checkPositions w j js cs
  | _, _, _ => false

private theorem checked_positions {w : Block} {cs : List Block} {i : Nat} {ps : List Nat}
    (h : checkPositions w i ps cs=true) : VisitsFrom w cs i := by
  induction ps generalizing cs i with
  | nil => cases cs with
           | nil => exact .nil i
           | cons => simp [checkPositions] at h
  | cons j js ih =>
    cases cs with
    | nil => simp [checkPositions] at h
    | cons c tail =>
      simp only [checkPositions,Bool.and_eq_true,decide_eq_true_eq] at h
      obtain ⟨⟨ord,size,clean,key⟩,more⟩ := h
      exact .cons ord size clean key (ih more)

private def referencePositions := (List.range (ResidualControls.mainWord.length-5)).filter fun j =>
  let v := context ResidualControls.mainWord j
  decide (full v ∧ tag v∉wheelLabels)

theorem reference_attains : ResidualControls.mainWord.length=469 ∧
    VisitsFrom ResidualControls.mainWord order 0 ∧
    VisitsFrom ResidualControls.mainWord (alternate 0) 0 ∧
    VisitsFrom ResidualControls.mainWord (alternate 1) 0 := by
  let visit (p : Nat) : List Nat := ((referencePositions.zipIdx.filter fun x =>
    x.2=0 || x.2+1=order.length || x.2%2=p).map Prod.fst)
  have data : ResidualControls.mainWord.length=469 ∧
      checkPositions ResidualControls.mainWord 0 referencePositions order=true ∧
      checkPositions ResidualControls.mainWord 0 (visit 0) (alternate 0)=true ∧
      checkPositions ResidualControls.mainWord 0 (visit 1) (alternate 1)=true := by
    dsimp only [visit]; native_decide
  exact ⟨data.1,checked_positions data.2.1,checked_positions data.2.2.1,checked_positions data.2.2.2⟩

#print axioms either_suborder_floor
#print axioms reference_attains
#print axioms steps_bound
#print axioms singleton_order_floor
end ExactWordFlow.SingletonOrder

import CoreMinimum
import RotationClassesRequired

namespace ExactWordFlow.CoreAssembly
open SevenWordWindows SuperpermutationBounds ResidualRoutes ResidualDensity RotationCore RotationReinsert

def mandatory (S : Finset Block) := required.filter (fun e => classKey e∈S)

private theorem one_class : ∀c∈allClasses,
    let m := required.filter (fun e => classKey e=c)
    m.card=7 ∧ m.map src=m.map dst := by native_decide

private theorem split_class (R : Multiset Block) (S : Finset Block) (c : Block) (new : c∉S) :
    R.filter (fun e => classKey e∈insert c S) =
      R.filter (fun e => classKey e=c) + R.filter (fun e => classKey e∈S) := by
  induction R using Multiset.induction_on with
  | empty => simp
  | cons e rest ih =>
    simp only [Finset.mem_insert] at ih
    by_cases same : classKey e=c
    · simp [same,new,ih]
    · by_cases there : classKey e∈S <;> simp [same,there,ih]

theorem mandatory_data (S : Finset Block) (good : S⊆allClasses) :
    (mandatory S).card=7*S.card ∧ (mandatory S).map src=(mandatory S).map dst := by
  induction S using Finset.induction_on with
  | empty => simp [mandatory]
  | @insert c S new ih =>
    obtain ⟨count,bal⟩ := ih (fun k hk => good (Finset.mem_insert_of_mem hk))
    obtain ⟨seven,balanced⟩ := one_class c (good (Finset.mem_insert_self ..))
    have step : mandatory (insert c S) = (required.filter fun e => classKey e=c)+mandatory S :=
      split_class required S c new
    rw [step,Multiset.card_add,seven,count,Finset.card_insert_of_notMem new,
      Multiset.map_add,Multiset.map_add,balanced,bal]
    exact ⟨by omega,rfl⟩

/-- Read the root component of the balanced residual and selected seven-cycles.
All classes have an accessible anchor and the selected classes have all seven edges. -/
theorem spell {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {S : Finset Block} (legal : S⊆allClasses)
    (hit : ∀c∈allClasses, ∃ u, full u ∧ tag u=c ∧
      label (X+mandatory S) u=label (X+mandatory S) s)
    (here : ∀p∈representatives, classKey p∈S →
      label (X+mandatory S) (src p)=label (X+mandatory S) s) :
    ∃v : Block, 6≤v.length ∧ v.length≤6+X.card+7*S.card ∧
      (visited v).card=720 ∧ S⊆complete v := by
  classical
  let Y := X+mandatory S
  obtain ⟨n,equal⟩ := mandatory_data S legal
  have bal : Y.map src+{t}=Y.map dst+{s} := by
    simp only [Y,Multiset.map_add,equal]
    simpa only [add_right_comm] using congrArg (·+(mandatory S).map dst) h.balance
  obtain ⟨a,b,es,bag,route,lab,home,_⟩ := component_route bal s
  obtain ⟨ha,hb⟩ := home rfl
  subst a
  subst b
  have whole (e) (he : e∈es) : e∈Y := (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have width (e) (he : e∈es) : e.length=7 := by
    rcases Multiset.mem_add.mp (whole e he) with ext|p
    · exact h.edges_seven _ ext
    · exact ((mem_reps _).mp (Multiset.mem_filter.mp p).1).1
  obtain ⟨v,sz,first,win⟩ := spell_route route h.start_six width
  have supportLen := Multiset.card_le_card (Multiset.filter_le (fun e => label Y (src e)=label Y s) Y)
  change (part Y (label Y s)).card≤Y.card at supportLen
  rw [←bag,Multiset.coe_card,show Y.card=X.card+(mandatory S).card from Multiset.card_add ..,n] at supportLen
  have seen : allClasses⊆visited v := by
    intro c hc
    obtain ⟨u,fu,eq,hit⟩ := hit c hc
    have mem := ResidualRoutes.visits rfl route bag hit
    exact (mem_visited _ _).mpr ⟨u,by simpa [anchors,first,win] using mem,fu,eq⟩
  refine ⟨v,by omega,by omega,by rw [Finset.Subset.antisymm (visited_subset v) seen,board],?_⟩
  intro c hc
  apply (mem_complete _ _).mpr
  refine ⟨legal hc,?_⟩
  intro p hp key
  have sel : classKey p∈S := key ▸ hc
  have member : p∈Y := Multiset.mem_add.mpr (Or.inr (Multiset.mem_filter.mpr ⟨hp,sel⟩))
  rw [win]
  change p∈(↑es : Multiset Block)
  rw [bag]
  exact in_part.mpr ⟨member,here p hp sel⟩

/-- Add one lap for each further requested class, preserving all old windows
and visited classes. The number of letters used is exactly seven per addition. -/
theorem add_classes (T : Finset Block) {w : Block} (long : 6≤w.length)
    (all : (visited w).card=720) (legal : T⊆allClasses) :
    ∃ z : Block, z.length=w.length+7*T.card ∧ (visited z).card=720 ∧
      complete w ∪ T ⊆ complete z := by
  classical
  induction T using Finset.induction_on generalizing w with
  | empty => exact ⟨w,by simp,all,by simp⟩
  | @insert c T hnew ih =>
    have eq : visited w=allClasses := Finset.eq_of_subset_of_card_le (visited_subset _) (by rw [all,board])
    have hc := legal (Finset.mem_insert_self c T)
    have atc := (mem_visited w c).mp (eq ▸ hc)
    obtain ⟨u,sz,anchors,edges,lap⟩ := insert_class long atc
    have inc : visited w⊆visited u := by
      intro k hk
      obtain ⟨x,hx,fl,which⟩ := (mem_visited _ _).mp hk
      exact (mem_visited _ _).mpr ⟨x,anchors x hx,fl,which⟩
    have fullU : (visited u).card=720 := by
      have lo := Finset.card_le_card inc
      have hi := Finset.card_le_card (visited_subset u)
      rw [board] at hi
      omega
    have prev : complete w⊆complete u := by
      intro k hk
      obtain ⟨kLegal,haveAll⟩ := (mem_complete _ _).mp hk
      exact (mem_complete _ _).mpr ⟨kLegal,fun p hp key => edges _ (haveAll p hp key)⟩
    have now := (mem_complete u c).mpr ⟨hc,lap⟩
    obtain ⟨z,n,ok,done⟩ := ih (w:=u) (by omega) fullU (fun k hk => legal (Finset.mem_insert_of_mem hk))
    refine ⟨z,by rw [Finset.card_insert_of_notMem hnew]; omega,ok,?_⟩
    intro k hk
    rcases Finset.mem_union.mp hk with old|chosen
    · exact done (Finset.mem_union_left _ (prev old))
    · rcases Finset.mem_insert.mp chosen with rfl|tail
      · exact done (Finset.mem_union_left _ now)
      · exact done (Finset.mem_union_right _ tail)

theorem target {X : Multiset Block} {s t : Block} (h : Feasible X s t) {S : Finset Block}
    (legal : S⊆allClasses) {k : Nat} (lo : S.card≤k) (hi : k≤720)
    (hit : ∀c∈allClasses, ∃ u, full u ∧ tag u=c ∧ label (X+mandatory S) u=label (X+mandatory S) s)
    (here : ∀p∈representatives, classKey p∈S → label (X+mandatory S) (src p)=label (X+mandatory S) s) :
    ∃v : Block, 6≤v.length ∧ v.length≤6+X.card+7*k ∧ (visited v).card=720 ∧ k≤(complete v).card := by
  obtain ⟨w,long,budget,all,covered⟩ := spell h legal hit here
  have rem := Finset.card_sdiff_of_subset legal
  rw [board] at rem
  obtain ⟨T,sub,count⟩ := Finset.exists_subset_card_eq (s:=allClasses \ S)
    (show k-S.card≤_ by omega)
  have dis : Disjoint S T := Finset.disjoint_left.mpr (by intro x hs ht; exact (Finset.mem_sdiff.mp (sub ht)).2 hs)
  obtain ⟨v,len,va,many⟩ := add_classes T long all (fun x hx => (Finset.mem_sdiff.mp (sub hx)).1)
  have joined : S∪T⊆complete v := (Finset.union_subset_union_left covered).trans many
  have amount := Finset.card_le_card joined
  rw [Finset.card_union_of_disjoint dis] at amount
  exact ⟨v,by omega,by omega,va,by omega⟩

end ExactWordFlow.CoreAssembly

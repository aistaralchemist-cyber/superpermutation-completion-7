import BaseWheelIncidence
import ExtremeWheelCut

namespace ExactWordFlow.WheelBaseExits
open SevenWordWindows RotationCore ResidualDensity WheelFreeBoundary ExtremeWheelCut
open WheelContacts (wheel)
abbrev Row := Finset Block

/-- All the tests refer to literal factors or to the actual leftover edge
multiset of the same base. The endpoint is counted explicitly. -/
def isolated (b : Block) (R : Row) : Prop := ∃s : Block,full s ∧ wheel s=R ∧
  (∀u∈phases s,occurs (prefixAt u 1) b) ∧ (∀u∈phases s,∀l : Block,b≠l++u) ∧
  (∀u∈phases s,∀a : Fin 7,u++[a]∈spare b → a=u.headD 0)

theorem two_per_wheel {b : Block} (free : WheelFree b) {R : Row} (iso : isolated b R) :
    2≤(R∩complete b).card := by
  obtain ⟨s,cl,rfl,edges,endOff,unique⟩:=iso
  exact isolated_needs_two free cl edges endOff unique

/-- A packing bound on isolated wheels present inside the base, including
the entire case m=0. Each row must spend two of the 92 completed classes. -/
theorem at_most_46 {b : Block} (free : WheelFree b) (done : (complete b).card=92)
    (S : Finset Row) (each : ∀R∈S, isolated b R)
    (disjoint : ∀R∈S,∀Q∈S,R≠Q → Disjoint R Q) : S.card≤46 := by
  classical
  let use (R : Row) := R∩complete b
  have sep : ∀R∈S,∀Q∈S,R≠Q → Disjoint (use R) (use Q) :=
    fun R hr Q hq ne=>(disjoint R hr Q hq ne).mono Finset.inter_subset_left Finset.inter_subset_left
  have cap : S.biUnion use ⊆ complete b :=
    Finset.biUnion_subset.mpr fun _ _=>Finset.inter_subset_right
  have total:=Finset.card_le_card cap
  rw [Finset.card_biUnion sep,done] at total
  have lower : (∑_R∈S,2)≤∑R∈S,(use R).card :=
    Finset.sum_le_sum (fun R hr=>two_per_wheel free (each R hr))
  simp only [Finset.sum_const,smul_eq_mul] at lower
  omega

#print axioms at_most_46
end ExactWordFlow.WheelBaseExits

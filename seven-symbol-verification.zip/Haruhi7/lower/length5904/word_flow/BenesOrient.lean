import BenesArray

namespace ExactWordFlow.BenesRouting

private def zeroWire (d : Nat) : Wire d := (index d).symm ⟨0,Nat.two_pow_pos d⟩

/-- Set the first front-bank switch of each subnetwork with at least four ports. -/
def oriented (want : Nat → Bool) : (d node : Nat) → Settings d → Prop
  | 0, _, _ => True
  | 1, _, _ => True
  | d+2, n, (a,_,hi,lo) => a (zeroWire (d+1))=want n ∧
      oriented want (d+1) (2*n) hi ∧ oriented want (d+1) (2*n+1) lo

/-- Every routing operation admits every simultaneous choice of these orientations. -/
theorem realize_orientations {V : Type} (want : Nat → Bool) :
    ∀ d n (s : Settings d), ∃ t : Settings d, oriented want d n t ∧
      ∀ xs : Wire d → V, ∀ j, run d t xs j = run d s xs j
  | 0, _, s => ⟨s,trivial,fun _ _=>rfl⟩
  | 1, _, s => ⟨s,trivial,fun _ _=>rfl⟩
  | d+2, n, (a,z,hi,lo) => by
    by_cases same : a (zeroWire (d+1))=want n
    · obtain ⟨t,ot,ht⟩ := @realize_orientations V want (d+1) (2*n) hi
      obtain ⟨b,ob,hb⟩ := @realize_orientations V want (d+1) (2*n+1) lo
      refine ⟨(a,z,t,b),⟨same,ot,ob⟩,?_⟩
      rintro xs ⟨j,k⟩
      simp only [run,ht,hb]
    · have opposite : (!a (zeroWire (d+1)))=want n := by
        cases h : a (zeroWire (d+1)) <;> cases q : want n <;> simp_all
      obtain ⟨t,ot,ht⟩ := @realize_orientations V want (d+1) (2*n) lo
      obtain ⟨b,ob,hb⟩ := @realize_orientations V want (d+1) (2*n+1) hi
      refine ⟨(fun i=> !a i,fun j=> !z j,t,b),⟨opposite,ot,ob⟩,?_⟩
      rintro xs ⟨j,k⟩
      simp only [run,ht,hb,Bool.not_not]
      cases k <;> cases z j <;> simp

#print axioms realize_orientations
end ExactWordFlow.BenesRouting

import NearBindingFast

namespace ExactWordFlow.NearWheelBinding
theorem checked97 : verified 97=true := verified_of_batched 97 (by native_decide)
#print axioms checked97
end ExactWordFlow.NearWheelBinding

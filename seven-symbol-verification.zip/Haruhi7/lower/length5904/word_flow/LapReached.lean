import LapMultiplicity

namespace ExactWordFlow.LapMultiplicity
open SevenWordWindows ResidualDensity RotationCore
open private cleanTags from LapMultiplicity

theorem reached (w : Block) (hit:(visited w).card=720) {p : Block} (hp:p∈representatives) :
    0 < (tags w).count (classKey p) := by
  have entire : visited w=allClasses:=Finset.eq_of_subset_of_card_le (visited_subset w)
    (by rw [board,hit])
  have present : classKey p∈visited w:=by
    rw [entire];exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨p,hp,rfl⟩)
  apply Multiset.count_pos.mpr
  exact List.mem_toFinset.mp present

#print axioms reached
end ExactWordFlow.LapMultiplicity

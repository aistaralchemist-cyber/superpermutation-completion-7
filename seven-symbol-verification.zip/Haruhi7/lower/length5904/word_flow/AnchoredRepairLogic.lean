import AnchoredRepairCore
import LiteralWheelRows

namespace ExactWordFlow.AnchoredRepair
open SevenWordWindows RotationCore RotationReinsert
open LiteralWheelCover (ready condition)

theorem options_eq (w : Block) : options w=(ready w).image (missing w ∩ ·) := by
  ext U
  simp only [options,ready,List.mem_toFinset,List.mem_map,Finset.mem_image]
  grind

private theorem level_mono (A : Finset Row) {n m : Nat} (hnm : n ≤ m) : level A n⊆level A m := by
  intro x hx
  induction hnm with
  | refl=>exact hx
  | step _ ih=>exact Finset.mem_union_left _ ih

private theorem sound (A : Finset Row) (D : Row) (n : Nat) {Y : Row}
    (hit : Y∈level (A.image (D∩·)) n) :
    ∃S⊆A,S.card≤n ∧ Y=D∩S.biUnion id := by
  induction n generalizing Y with
  | zero=>
    have eq:Y=∅:=Finset.mem_singleton.mp hit
    exact ⟨∅,by simp,by simp,by simp [eq]⟩
  | succ n ih=>
    rcases Finset.mem_union.mp hit with old|new
    · obtain ⟨S,sub,size,eq⟩:=ih old
      exact ⟨S,sub,by omega,eq⟩
    · obtain ⟨U,used,joined⟩:=Finset.mem_biUnion.mp new
      obtain ⟨Z,zok,rfl⟩:=Finset.mem_image.mp joined
      obtain ⟨H,hA,rfl⟩:=Finset.mem_image.mp zok
      obtain ⟨S,sub,size,rfl⟩:=ih used
      refine ⟨insert H S,Finset.insert_subset hA sub,(Finset.card_insert_le ..).trans (by omega),?_⟩
      ext x
      simp
      simp only [← and_or_left, or_comm]

private theorem complete (A : Finset Row) (D : Row) {S : Finset Row} (sub : S⊆A) :
    D∩S.biUnion id∈level (A.image (D∩·)) S.card := by
  induction S using Finset.induction_on with
  | empty=>simp [level]
  | @insert h S fresh ih=>
    have hA:=sub (Finset.mem_insert_self h S)
    have less:=ih (fun _ hy=>sub (Finset.mem_insert_of_mem hy))
    rw [Finset.card_insert_of_notMem fresh]
    apply Finset.mem_union_right
    apply Finset.mem_biUnion.mpr
    refine ⟨_,less,Finset.mem_image.mpr ⟨D∩h,Finset.mem_image_of_mem _ hA,?_⟩⟩
    ext x
    simp
    simp only [← and_or_left, or_comm]

theorem legal_iff (v : Block) (n : Nat) : condition v n ↔ missing v∈level (options v) n := by
  rw [options_eq]
  constructor
  · rintro ⟨S,sub,size,covered⟩
    have reached:=level_mono _ size (complete _ (missing v) sub)
    change missing v ⊆ S.biUnion id at covered
    rwa [Finset.inter_eq_left.mpr covered] at reached
  · intro hit
    obtain ⟨S,sub,size,eq⟩:=sound _ _ _ hit
    refine ⟨S,sub,size,?_⟩
    exact Finset.inter_eq_left.mp eq.symm

theorem impossible_of_absent {v : Block} {c : Block} (never : c∈absent v) (n : Nat) :
    ¬condition v n := by
  rintro ⟨S,sub,_,covered⟩
  obtain ⟨miss,no⟩:=Finset.mem_sdiff.mp never
  obtain ⟨W,wS,mem⟩:=Finset.mem_biUnion.mp (covered miss)
  apply no
  apply Finset.mem_biUnion.mpr
  refine ⟨missing v∩W,?_,Finset.mem_inter.mpr ⟨miss,mem⟩⟩
  rw [options_eq]
  exact Finset.mem_image_of_mem _ (sub wS)

theorem impossible (v : Block) (count : 0<(report v).unavailable) (n : Nat) : ¬condition v n := by
  obtain ⟨c,hc⟩:=Finset.card_pos.mp (show 0<(absent v).card from count)
  exact impossible_of_absent hc n

theorem exact_min (v : Block) (m : Nat) (small : m<6) (profile : (report v).flags=flags m) (n : Nat) :
    condition v n ↔ m≤n := by
  have point (j : Nat) (hj:j<6) : condition v j ↔ m≤j := by
    rw [legal_iff]
    have same:=congrArg (fun xs : List Bool=>xs[j]?.getD false) profile
    simp only [report,flags,List.getElem?_map,List.getElem?_range hj,Option.map_some,Option.getD_some] at same
    simpa using Bool.eq_iff_iff.mp same
  by_cases short : n<6
  · exact point n short
  · have has:=(point m small).mpr (le_refl m)
    have cap : m≤n:=by omega
    obtain ⟨S,sub,size,cover⟩:=has
    exact ⟨fun _=>cap,fun _=>⟨S,sub,size.trans cap,cover⟩⟩

#print axioms legal_iff
#print axioms exact_min
end ExactWordFlow.AnchoredRepair

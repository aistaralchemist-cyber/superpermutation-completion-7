import DeletionShadow
import Control1508

namespace ExactWordFlow.DeletionControls
open RotationCoreControls DeletionShadow

def bounds (w : Block) := (List.finRange 7).map (upper · w)

private def check : Bool :=
  bounds (coreWord 628) == [108,99,103,103,92,94,161] &&
  bounds (coreTruncated 628) == [108,98,102,102,91,93,161]

private theorem result : check=true := by native_decide

theorem reference :
    bounds (coreWord 628)=[108,99,103,103,92,94,161] ∧
    bounds (coreTruncated 628)=[108,98,102,102,91,93,161] := by
  obtain ⟨a,b⟩:=Bool.and_eq_true_iff.mp result
  exact ⟨eq_of_beq a,eq_of_beq b⟩

#print axioms reference
end ExactWordFlow.DeletionControls

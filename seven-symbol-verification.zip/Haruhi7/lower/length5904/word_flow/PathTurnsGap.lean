import NinetyFour
import OnePath66

namespace ExactWordFlow.PathTurnsGap
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence RotationCore
open WeightedMarks ExtremalRealizations ExtremeWheelCut SuperpermutationBounds
open private integer_frontier from NearHundredShape
open private certificate_list from NoHundred
open private sizes from EmbeddedWheels

private theorem normalized_rows {s t : Block} {es ws : List Block}
    (h : Feasible ((↑es : Multiset Block)+EmbeddedWheels.turns ws) s t)
    (r : Route src dst s es t) (fullW : ∀w∈ws,full w)
    {f : Fin 7 → Fin 7} (bij : Function.Bijective f) (zero : f 0=0) :
    ∃W⊆allRows,W.card≤ws.length ∧
      SeedWheelCut.ClosedCover ((touched (s::es.map dst)).image (List.map f)) allClasses W := by
  classical
  have closed:=WheelRelabel.transport_closed fullW (HundredDecomposition.closed_cover h r fullW rfl) f bij.1 zero
  let vs:=ws.map (List.map f)
  have legal : vs.toFinset.image WheelContacts.wheel⊆allRows := by
    intro row hr
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hr
    obtain ⟨x,old,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hv)
    have fullX:=fullW x old
    have fullV : full (x.map f) := ⟨by simpa using fullX.1,fullX.2.map bij.1⟩
    obtain ⟨base,admissible,rows⟩:=WheelContacts.complete fullV
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨base,admissible,rows⟩)
  exact ⟨_,legal,Finset.card_image_le.trans ((List.toFinset_card_le vs).trans
    (by simp [vs])),closed⟩

/-- No assumption of disjoint weak components is imposed on the turns or the path. -/
theorem no_single_path {s t : Block} {es ws : List Block}
    (h : Feasible ((↑es : Multiset Block)+EmbeddedWheels.turns ws) s t)
    (r : Route src dst s es t) (fullW : ∀w∈ws,full w)
    (budget : es.length+6*ws.length≤858) (lo : 96≤ws.length) (hi : ws.length≤100) : False := by
  classical
  have wd (e) (he : e∈es) : e.length=7:=h.edges_seven e (Multiset.mem_add.mpr (Or.inl he))
  have rk:=EmbeddedWheels.residual_rank ws fullW h
  change 719≤5*ws.length+separateRank (↑es) s at rk
  rw [OnePath66.path_rank_eq r s] at rk
  have long : 258≤es.length := by
    by_contra! small
    have := WeightedMarks.short_gain r wd small
    omega
  obtain ⟨_,len,cols,_⟩:=integer_frontier (N:=ws.length) (E:=0) (R:=5*ws.length) r wd lo hi long
    (by omega) (by omega) (by simp; omega)
  by_cases hundred : ws.length=100
  · obtain ⟨f,bij,zero,norm⟩:=ExtremeRootSets.route_coverage r wd (by omega) (by omega)
    have ver:=List.contains_iff_mem.mp (List.all_eq_true.mp certificate_list _ norm)
    obtain ⟨W,legal,size,closed⟩:=normalized_rows h r fullW bij zero
    exact no_cover ver legal (by omega) closed
  obtain ⟨f,bij,zero,norm⟩:=route_coverage_at r wd
    (show es.length+1=859-6*ws.length by omega)
    (show 720-5*ws.length≤classCount s es by omega) (NearExtrema.profiles ws.length)
    (fun v I walk mark observed=>NearExtrema.extreme_mask ws.length lo hi walk mark 0 observed)
  obtain ⟨W,legal,size,closed⟩:=normalized_rows h r fullW bij zero
  by_cases n99 : ws.length=99
  · rw [n99] at norm size
    exact ExtremeWheelFamilies.no_99 norm legal size closed
  have hi98 : ws.length≤98:=by omega
  obtain ⟨rr,hard,w,rows,small,actual,cover⟩:=NearWheelBinding.exhaust lo hi98 norm legal size closed
  have tight : rr.card+5*w.card≤allClasses.card := by rw [board,actual]; omega
  exact OrientedCNF.no_cover rows tight (HardWheelProofs.hard_unsat lo hi98 hard) cover

set_option maxHeartbeats 800000

theorem no_single_path_95 {s t : Block} {es ws : List Block}
    (h : Feasible ((↑es : Multiset Block)+EmbeddedWheels.turns ws) s t)
    (r : Route src dst s es t) (fullW : ∀w∈ws,full w)
    (budget : es.length+6*ws.length≤858) (num : ws.length=95) : False := by
  classical
  have wd (e) (he : e∈es) : e.length=7:=h.edges_seven e (Multiset.mem_add.mpr (Or.inl he))
  have rk:=EmbeddedWheels.residual_rank ws fullW h
  change 719≤5*ws.length+separateRank (↑es) s at rk
  rw [OnePath66.path_rank_eq r s] at rk
  have col : 245≤classCount s es:=by omega
  have val:=WeightedMarks.path_cap r wd
  have len : es.length+1=289:=by omega
  obtain ⟨f,bij,zero,norm⟩:=route_coverage_at r wd len col (Cap95Profiles.profiles 95)
    (fun v I walk mark observed=>Cap95Profiles.extreme_mask walk mark 0 observed)
  obtain ⟨W,legal,size,closed⟩:=normalized_rows h r fullW bij zero
  exact NinetyFour.no_root_cover norm legal (by omega) closed

#print axioms no_single_path_95
#print axioms no_single_path
end ExactWordFlow.PathTurnsGap

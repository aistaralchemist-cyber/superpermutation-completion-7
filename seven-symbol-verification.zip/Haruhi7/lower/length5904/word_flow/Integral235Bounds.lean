import IntegralPackets
import FixedSeed235Exact

namespace ExactWordFlow.Integral235Bounds
open SevenWordWindows SeedWheelCut ExtremeWheelCut OpenWheelPacking FixedSeed235Exact

private theorem board_data : (allClasses \ rootClasses).card=5*(96+1) ∧
    allClasses.card=720 ∧ ∀w∈allRows,w⊆allClasses ∧ w.card≤6 := by native_decide

/-- Integral exact-cover failure on the fixed 235-tag trace extends to
every superset, at every budget, including orders with overlapping wheels. -/
theorem cut {A : Finset Block} {W : Finset (Finset Block)} (seed : rootClasses⊆A)
    (board : A⊆allClasses) (legal : W⊆allRows) (link : ClosedCover A allClasses W) :
    624 ≤ A.card + 4*W.card := by
  have cap:=IntegralPackets.extend impossible board_data.1 seed board legal
    (fun w hw=>board_data.2.2 w (legal hw)) link
  rw [board_data.2.1] at cap
  omega

theorem mass_floor {A : Finset Block} {W : Finset (Finset Block)} (seed : rootClasses⊆A)
    (board : A⊆allClasses) (legal : W⊆allRows) (link : ClosedCover A allClasses W)
    {M s q L : Nat} (mass : A.card≤M) (count : W.card≤q) (length : L=5045+M+s+6*q)
    (short : L≤5904) : 154+2*s+3*(M-A.card)+2*(5904-L) ≤ M := by
  have cap:=cut seed board legal link
  have bound:=word_cut (r:=96) mass count (by omega) length short
  omega

#print axioms cut
#print axioms mass_floor
end ExactWordFlow.Integral235Bounds

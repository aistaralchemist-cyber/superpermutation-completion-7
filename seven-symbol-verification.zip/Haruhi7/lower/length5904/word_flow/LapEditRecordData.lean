import LapEditContexts
import LapMultiplicity

namespace ExactWordFlow.LapEditRecordData
open SevenWordWindows RotationCoreControls LapEditContexts
open private lapStarts from CoreControls

/-- The 653 optional laps are seven-letter tiles; all other source positions
are individual fixed letters. Source order is retained throughout. -/
def tiles : List Tile := Id.run do
  let word:=source.toArray
  let offsets:=lapStarts.toFinset
  let mut out : Array Tile := #[]
  let mut nextIndex:=0
  for i in [:word.size] do
    if nextIndex ≤ i then
      if i ∈ offsets then
        let p:=(word.extract i (i+7)).toList
        out:=out.push ⟨p,some p⟩
        nextIndex:=i+7
      else
        out:=out.push ⟨[word[i]!],none⟩
  return out.toList

private def validCheck : List Tile → Bool
  | [] => true
  | t::ts =>
    (match t.skip with
     | none => true
     | some p => decide (t.raw=p ∧ p.length=7 ∧ p.Nodup ∧ (uncut ts).take 6=p.take 6)) && validCheck ts

private theorem checked_valid (ts : List Tile) (h : validCheck ts=true) : Valid ts := by
  induction ts with
  | nil => trivial
  | cons t ts ih =>
    obtain ⟨this,tail⟩:=Bool.and_eq_true_iff.mp h
    refine ⟨?_,ih tail⟩
    intro p may
    rw [may] at this
    obtain ⟨raw,len,unique,next⟩:=of_decide_eq_true this
    exact ⟨raw,(mem_reps _).mpr ⟨len,unique⟩,next⟩

private theorem tileData :
    uncut tiles=source ∧ validCheck tiles=true ∧
    (tiles.filterMap Tile.skip).map classKey=LapMultiplicity.recordTags ∧
    tiles.length=1987 ∧ (tiles.filterMap Tile.skip).length=653 ∧ (good source).length=5040 := by
  native_decide

theorem uncut_source : uncut tiles=source := tileData.1
theorem valid : Valid tiles := checked_valid _ tileData.2.1
theorem tags : (tiles.filterMap Tile.skip).map classKey=LapMultiplicity.recordTags := tileData.2.2.1
theorem counts : tiles.length=1987 ∧ (tiles.filterMap Tile.skip).length=653 ∧ (good source).length=5040 :=
  tileData.2.2.2
theorem original_good : (good source).length=5040 := counts.2.2

#print axioms valid
#print axioms tags
end ExactWordFlow.LapEditRecordData

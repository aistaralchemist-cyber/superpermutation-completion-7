import MixedRootsExcluded
import ArbitraryTurns91
import Core1501

namespace ExactWordFlow.EqualityComponent91
open SevenWordWindows SuperpermutationBounds ResidualDensity ResidualRoutes RotationComponentCount
open RotationCore CoreAssembly WheelBaseResidual VirtualFrontierTransfer

theorem universal : countBound :=
  transfer MixedRootsExcluded.blocked (fun _ _ _ _ clean flow budget=>arbitrary_turns_le_91 clean flow budget)

theorem candidate_bound {b : Block} {m : Nat} (h : BaseEqualityDecision.candidate b m) :
    m+(occupied (bag b-mandatory (complete b)) (b.take 6)).card≤91 := for_base universal h

theorem component_limit {X : Multiset Block} {s t : Block} (valid : Feasible X s t)
    (size : X.card≤858) : (occupied X s).card≤91 := physical universal valid size

theorem short_word : (∃w : Block,Covers w ∧ w.length≤5904) ↔
    ∃v : Block,v.length=1501 ∧ (visited v).card=720 ∧ (complete v).card=91 :=
  Core1501.exact (@component_limit)

/-- Exactly the equality in the original question, including its zero case. -/
theorem original_equality : (∃b m,BaseEqualityDecision.candidate b m) ↔
    ∃v : Block,v.length=1501 ∧ (visited v).card=720 ∧ (complete v).card=91 := by
  rw [←short_word,BaseEqualityDecision.exact]
  constructor
  · rintro ⟨b,m,h⟩
    have e:=h.2.2.1
    have bound:=candidate_bound h
    exact ⟨b,m,h,by omega,by omega⟩
  · rintro ⟨b,m,h,_,_⟩
    exact ⟨b,m,h⟩

theorem ceiling_equivalence : Target107.ceiling 1620 107 ↔ Target107.ceiling 1501 90 := by
  rw [←Core1501.completion_goal (@component_limit),BaseEqualityDecision.completion_goal,
    BaseEqualityDecision.exact]

#print axioms universal
#print axioms original_equality
#print axioms ceiling_equivalence
end ExactWordFlow.EqualityComponent91

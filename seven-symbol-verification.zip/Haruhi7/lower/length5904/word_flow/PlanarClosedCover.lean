import SevenPlanarTour
import SevenRename

namespace ExactWordFlow.SevenPlanarTour
open Equiv PlanarIncidence SevenMoves SeedWheelCut

private theorem tag_class {p q:X} (eq:tag p=tag q) : R.SameCycle p q := by
  have powrot (x:X) (n:Nat) : (R^n) x=x*r^n:=by
    induction n with
    | zero => simp
    | succ n ih =>
      rw [pow_succ',Perm.mul_apply,ih]
      change x*r^n*r=x*r^(n+1)
      rw [mul_assoc,pow_succ]
  have same (x:X) : R.SameCycle x (normal x):=by
    rw [normal,←powrot]
    exact Perm.sameCycle_pow_right.mpr (.refl _ _)
  have match' : normal p=normal q:=by rw [←repr_tag,←repr_tag,eq]
  have link:=(same q).symm
  rw [←match'] at link
  exact (same p).trans link

/-- Rotation-tag closure of one connected root under the other cycle
supports is enough to obtain joint, physical transitivity. -/
theorem connected_from_cover (h : Perm X) (e : Perm X) (he : e∈h.cycleFactorsFinset)
    (closed : ClosedCover (e.support.image tag) Finset.univ
      ((h.cycleFactorsFinset.erase e).image (fun c=>c.support.image tag))) : Connected R h := by
  classical
  intro P rot step x y yes
  obtain ⟨s,hs⟩:=(Perm.mem_cycleFactorsFinset_iff.mp he).1.nonempty_support
  have walk (F : Perm X) (rule : ∀v,P (F v)↔P v) {u v:X} (same:F.SameCycle u v) : P u↔P v:=by
    obtain ⟨n,_,eq⟩:=same.exists_pow_eq'
    have spin (k:Nat):P ((F^k) u)↔P u := by
      induction k with
      | zero => simp
      | succ k ih => rw [pow_succ',Perm.mul_apply,rule,ih]
    rw [←eq,spin]
  have within (c:Perm X) (hc:c∈h.cycleFactorsFinset) {u v:X} (hu:u∈c.support) (hv:v∈c.support) : P u↔P v:=
    walk h step ((Perm.isCycleOn_support_of_mem_cycleFactorsFinset hc).2 hu hv)
  let C:=Finset.univ.filter (fun t=>∀z,tag z=t → (P z↔P s))
  have seen : Finset.univ⊆C:=by
    apply closed
    · intro t ht
      obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp ht
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,fun z eq=>
        (walk R rot (tag_class eq)).trans (within e he hv hs)⟩
    · intro w hw touch t ht
      obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp hw
      obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp ht
      obtain ⟨j,hj⟩:=touch
      obtain ⟨inside,inc⟩:=Finset.mem_inter.mp hj
      obtain ⟨u,hu,rfl⟩:=Finset.mem_image.mp inc
      have atU : P u↔P s:=(Finset.mem_filter.mp inside).2 u rfl
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,fun z eq=>
        (walk R rot (tag_class eq)).trans ((within c (Finset.mem_erase.mp hc).2 hv hu).trans atU)⟩
  have val (z:X) : P z↔P s:=(Finset.mem_filter.mp (seen (Finset.mem_univ (tag z)))).2 z rfl
  exact (val y).mpr ((val x).mp yes)

/-- For a putative genus-zero single-exception configuration, once its actual
cycle supports attain connected tag closure, its physical successor really has one tour. -/
theorem planar_cover_order (h : Perm X) (e : Perm X) (he : e∈h.cycleFactorsFinset)
    (zero : h.support.card=h.cycleType.card+719)
    (closed : ClosedCover (e.support.image tag) Finset.univ
      ((h.cycleFactorsFinset.erase e).image (fun c=>c.support.image tag))) (start : X) :
    ∀y,(R*h).SameCycle start y :=
  (planar_iff h start zero).mp (connected_from_cover h e he closed)

/-- Exact seed-closure criterion in the same language as TourWheelPrice. -/
theorem planar_cover_iff (h : Perm X) (e : Perm X) (he : e∈h.cycleFactorsFinset)
    (zero : h.support.card=h.cycleType.card+719) (start : X) :
    (ClosedCover (e.support.image tag) Finset.univ
      ((h.cycleFactorsFinset.erase e).image (fun c=>c.support.image tag))) ↔ ∀y,(R*h).SameCycle start y := by
  constructor
  · intro closed
    exact planar_cover_order h e he zero closed start
  · intro orbit
    have c:=TourWheelPrice.from_order start orbit tag tag_surj tag_rot {e} (Finset.singleton_subset_iff.mpr he)
      (Finset.singleton_nonempty e)
    simpa only [Finset.singleton_biUnion,Finset.sdiff_singleton_eq_erase] using c

/-- The seven-symbol planar budget for one exceptional cycle and q full
six-wheels is M+5q=720, where M is the physical exceptional support size. -/
theorem single_mass_iff (h : Perm X) (e : Perm X) (he : e∈h.cycleFactorsFinset)
    (six : ∀c∈h.cycleFactorsFinset.erase e,c.support.card=6)
    (mass : e.support.card+5*(h.cycleFactorsFinset.erase e).card=720) (start : X) :
    (ClosedCover (e.support.image tag) Finset.univ
      ((h.cycleFactorsFinset.erase e).image (fun c=>c.support.image tag))) ↔ ∀y,(R*h).SameCycle start y := by
  have total : (∑c∈h.cycleFactorsFinset,c.support.card)=h.support.card:=h.sum_cycleType
  have split:=Finset.sum_erase_add h.cycleFactorsFinset (fun c=>c.support.card) he
  rw [total,Finset.sum_congr rfl six] at split
  simp only [Finset.sum_const,smul_eq_mul] at split
  have count:=Finset.card_erase_add_one he
  have ct:h.cycleType.card=h.cycleFactorsFinset.card:=by simp [Perm.cycleType_def]
  exact planar_cover_iff h e he (by omega) start

#print axioms planar_cover_iff
#print axioms single_mass_iff
end ExactWordFlow.SevenPlanarTour

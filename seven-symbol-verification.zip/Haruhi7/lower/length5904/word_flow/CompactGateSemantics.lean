import CompactWordCircuit
import Mathlib.Tactic

namespace ExactWordFlow.CompactWordCircuit

/-- The signs here are DIMACS signs. The index passed to an assignment is zero-based. -/
def wire (v : Nat → Bool) (x : W) : Bool :=
  if x < 0 then !(v (x.natAbs-1)) else v (x.natAbs-1)

@[simp] theorem wire_neg {v : Nat → Bool} {x : W} (h : x ≠ 0) :
    wire v (-x) = !(wire v x) := by
  change Int at x
  by_cases hx : x<0
  · simp [wire,hx,hx.le]
  · have pos : 0<x := lt_of_le_of_ne (le_of_not_gt hx) (Ne.symm h)
    simp [wire,hx,pos]

@[simp] theorem wire_one (v : Nat → Bool) : wire v 1 = v 0 := rfl

def gateMeaning (v : Nat → Bool) (out : W) : Event → Prop
  | .fresh _ => True
  | .assertion xs => xs.any (wire v) = true
  | .gateOr xs => wire v out = xs.any (wire v)
  | .gateMux c a b => wire v out = if wire v c then wire v a else wire v b

def tailMeaning (v : Nat → Bool) (n : Nat) : List Event → Prop
  | [] => True
  | e::es => gateMeaning v (Int.ofNat (n+1)) e ∧ tailMeaning v (advance n e) es

/-- Only the appended events enter a primitive's contract. In particular a
folded operation that reuses a wire contributes the empty suffix of the tape. -/
def realizes (m : M W) (st : Tape) (v : Nat → Bool) (b : Bool) : Prop :=
  let (x,last) := m st
  x ≠ 0 ∧ (tailMeaning v st.vars (last.body.toList.drop st.body.size) → wire v x = b)

private theorem pure_ok {st : Tape} {v : Nat → Bool} {x : W} (hx : x≠0) :
    realizes (pure x) st v (wire v x) := by
  exact ⟨hx,fun _=>rfl⟩

private theorem or_raw (xs : List W) (st : Tape) (v : Nat → Bool) :
    realizes (alloc (.gateOr xs)) st v (xs.any (wire v)) := by
  unfold realizes alloc
  constructor
  · change ((st.vars+1 : Nat) : Int) ≠ 0
    exact_mod_cast Nat.succ_ne_zero st.vars
  · intro h
    simpa [Array.toList_push,tailMeaning,gateMeaning] using h

private theorem mux_raw (c a b : W) (st : Tape) (v : Nat → Bool) :
    realizes (alloc (.gateMux c a b)) st v (if wire v c then wire v a else wire v b) := by
  unfold realizes alloc
  constructor
  · change ((st.vars+1 : Nat) : Int) ≠ 0
    exact_mod_cast Nat.succ_ne_zero st.vars
  · intro h
    simpa [Array.toList_push,tailMeaning,gateMeaning] using h

private theorem equiv_any {ts xs : List W} {v : Nat → Bool}
    (same : ∀ x, x∈ts ↔ x∈xs ∧ x≠-1) (unit : v 0=true) :
    ts.any (wire v) = xs.any (wire v) := by
  apply Bool.eq_iff_iff.mpr
  simp only [List.any_eq_true]
  constructor
  · rintro ⟨x,hx,on⟩
    exact ⟨x,((same x).mp hx).1,on⟩
  · rintro ⟨x,hx,on⟩
    have notFalse : x≠-1 := by
      rintro rfl
      have bad : wire v (-1)=false := by simp [wire,unit]
      simp [bad] at on
    exact ⟨x,(same x).mpr ⟨hx,notFalse⟩,on⟩

private def orChoice (ts : List W) : M W :=
  if ts.contains 1 || ts.any (fun x => ts.contains (-x)) then pure 1 else
  match ts with | [] => pure (-1) | [a] => pure a | _ => alloc (.gateOr (ts.mergeSort (· ≤ ·)))

theorem anyGate_realizes (xs : List W) (st : Tape) (v : Nat → Bool)
    (unit : v 0=true) (nz : ∀ x∈xs,x≠0) :
    realizes (anyGate xs) st v (xs.any (wire v)) := by
  let ts := (xs.filter (· != -1)).eraseDups
  have atTS (x : W) : x∈ts ↔ x∈xs ∧ x≠-1 := by
    simp [ts,List.mem_eraseDups]
  have eq := equiv_any atTS unit
  change realizes (orChoice ts) st v _
  unfold orChoice
  split
  next yes =>
    have on : ts.any (wire v)=true := by
      rcases Bool.or_eq_true_iff.mp yes with one|pair
      · exact List.any_eq_true.mpr ⟨1,List.contains_iff_mem.mp one,by simp [unit]⟩
      · obtain ⟨x,hx,hminus⟩ := List.any_eq_true.mp pair
        have hn:=nz x ((atTS x).mp hx).1
        cases h:wire v x with
        | true => exact List.any_eq_true.mpr ⟨x,hx,h⟩
        | false => exact List.any_eq_true.mpr ⟨-x,List.contains_iff_mem.mp hminus,by simp [h,hn]⟩
    rw [←eq,on,←unit,←wire_one v]
    exact pure_ok (by decide)
  next no =>
    rw [←eq]
    cases h:ts with
    | nil =>
      simpa [wire,unit] using (pure_ok (st:=st) (v:=v) (x:=(-1)) (by decide))
    | cons x tl =>
      cases tl with
      | nil =>
        have hx : x∈ts := h ▸ List.mem_cons_self
        simpa using (pure_ok (st:=st) (v:=v) (nz x ((atTS x).mp hx).1))
      | cons y ys =>
        have sort_eq : ((x::y::ys).mergeSort (· ≤ ·)).any (wire v) = (x::y::ys).any (wire v) := by
          apply Bool.eq_iff_iff.mpr
          simp only [List.any_eq_true,List.mem_mergeSort]
        exact sort_eq ▸ or_raw _ st v

private theorem negated (m : M W) (st : Tape) (v : Nat → Bool) (b : Bool)
    (h : realizes m st v b) : realizes (do return -(←m)) st v (!b) := by
  change (-(m st).1 ≠ 0) ∧ _ at ⊢
  obtain ⟨nz,eq⟩:=h
  exact ⟨neg_ne_zero.mpr nz,fun good=>(wire_neg nz).trans (congrArg Bool.not (eq good))⟩

theorem allGate_realizes (xs : List W) (st : Tape) (v : Nat → Bool)
    (unit : v 0=true) (nz : ∀ x∈xs,x≠0) :
    realizes (allGate xs) st v (xs.all (wire v)) := by
  have ns : ∀ y∈xs.map (-·), y≠0 := by
    intro y hy
    obtain ⟨x,hx,rfl⟩:=List.mem_map.mp hy
    exact neg_ne_zero.mpr (nz _ hx)
  have h:=negated _ _ _ _ (anyGate_realizes _ st v unit ns)
  have eq : (!(xs.map (-·)).any (wire v)) = xs.all (wire v) := by
    clear h ns
    induction xs with
    | nil => rfl
    | cons x xs ih =>
      have hn:=nz x List.mem_cons_self
      have slot := ih (fun y hy=>nz y (List.mem_cons_of_mem _ hy))
      simp only [List.map_cons,List.any_cons,List.all_cons,wire_neg hn,Bool.not_or,Bool.not_not,slot]
  exact eq ▸ h


theorem mux_realizes (c a b : W) (st : Tape) (v : Nat → Bool)
    (unit : v 0=true) (nc : c≠0) (na : a≠0) (nb : b≠0) :
    realizes (mux c a b) st v (if wire v c then wire v a else wire v b) := by
  have t : wire v 1=true := unit
  have f : wire v (-1)=false := by simp [wire,unit]
  unfold mux
  split
  next h =>
    rcases Bool.or_eq_true_iff.mp h with cs|ab
    · have id:c=1:=eq_of_beq cs
      subst c
      simpa [unit] using (pure_ok (st:=st) (v:=v) na)
    · have id:a=b:=eq_of_beq ab
      subst b
      simpa using (pure_ok (st:=st) (v:=v) na)
  next =>
    split
    next h =>
      have id:c=(-1):=eq_of_beq h
      subst c
      simpa [f] using (pure_ok (st:=st) (v:=v) nb)
    next =>
      split
      next h =>
        have id:a=1:=eq_of_beq h
        subst a
        have eq:=anyGate_realizes [c,b] st v unit (by simpa using And.intro nc nb)
        change realizes (anyGate [c,b]) st v _
        cases wc:wire v c <;> simpa [wc,unit] using eq
      next =>
        split
        next h =>
          have id:b=1:=eq_of_beq h
          subst b
          have eq:=anyGate_realizes [-c,a] st v unit (by simpa using And.intro nc na)
          change realizes (anyGate [-c,a]) st v _
          cases wc:wire v c <;> simpa [wc,unit,wire_neg nc] using eq
        next =>
          split
          next h =>
            have id:a=(-1):=eq_of_beq h
            subst a
            have eq:=allGate_realizes [-c,b] st v unit (by simpa using And.intro nc nb)
            change realizes (allGate [-c,b]) st v _
            cases wc:wire v c <;> simpa [wc,f,wire_neg nc] using eq
          next =>
            split
            next h =>
              have id:b=(-1):=eq_of_beq h
              subst b
              have eq:=allGate_realizes [c,a] st v unit (by simpa using And.intro nc na)
              change realizes (allGate [c,a]) st v _
              cases wc:wire v c <;> simpa [wc,f] using eq
            next => exact mux_raw c a b st v

theorem bitXor_realizes (a b : W) (st : Tape) (v : Nat → Bool)
    (unit : v 0=true) (na : a≠0) (nb : b≠0) :
    realizes (bitXor a b) st v (wire v a ^^ wire v b) := by
  unfold bitXor
  split
  next h =>
    have id:a=b:=eq_of_beq h
    subst b
    simpa [wire,unit] using (pure_ok (st:=st) (v:=v) (x:=(-1)) (by decide))
  next =>
    split
    next h =>
      have id:a= -b:=eq_of_beq h
      subst a
      cases wb:wire v b <;> simpa [unit,wire_neg nb,wb] using
        (pure_ok (st:=st) (v:=v) (x:=1) (by decide))
    next =>
      have eq := mux_realizes a (-b) b st v unit na (neg_ne_zero.mpr nb) nb
      cases wa:wire v a <;> cases wb:wire v b <;> simpa [wire_neg nb,wa,wb] using eq

#print axioms bitXor_realizes
end ExactWordFlow.CompactWordCircuit

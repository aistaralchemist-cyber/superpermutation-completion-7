import SevenMoves
import Hunter.Words

namespace ExactWordFlow.SevenMoves
open Equiv

/-- Position-word, in the alphabet Fin 7. -/
def word (p : X) : List (Fin 7) := (List.finRange 7).map p

def allowed {α : Type*} [DecidableEq α] (xs ys : List α) : Finset Nat :=
  (Finset.Icc 1 7).filter (fun j=>xs.drop j=ys.take (7-j))

private def minimum (A : Finset Nat) : Nat := if h : A.Nonempty then A.min' h else 7

/-- Paid positive overlap to the actual successor R y, for the successor factor sending p to y. -/
def d (p y:X) : Nat := minimum (allowed (word p) (word (R y)))

private theorem allowed_map {α β : Type*} [DecidableEq α] [DecidableEq β]
    (f : α→β) (inj : Function.Injective f) (xs ys : List α) :
    allowed (xs.map f) (ys.map f)=allowed xs ys := by
  ext j
  simp only [allowed,Finset.mem_filter,←List.map_take,←List.map_drop,
    (List.map_injective_iff.mpr inj).eq_iff]

theorem word_mul (p y:X) : word (p*y)=(word y).map p := by
  simp only [word,List.map_map,Function.comp_def]
  rfl

theorem d_relative (p u:X) : d p (p*u)=d 1 u := by
  change minimum (allowed (word p) (word (p*u*r)))=minimum (allowed (word 1) (word (u*r)))
  rw [mul_assoc,word_mul]
  conv_lhs => arg 1; arg 1; rw [←mul_one p,word_mul]
  rw [allowed_map p p.injective]

/-- The computable cost agrees with the project-wide Hunter positive overlap. -/
theorem d_weight (p y:X) :
    d p y=Hunter.wt 7 ((word p).map Fin.val) ((word (R y)).map Fin.val) := by
  let a:=(word p).map Fin.val
  let b:=(word (R y)).map Fin.val
  have ha:a.length≤7:=by simp [a,word]
  obtain ⟨hd,h7,hv⟩:=Hunter.wt_spec (k:=7) (u:=a) (v:=b) (by decide) ha
  have hm:Hunter.wt 7 a b∈allowed a b:=by simp [allowed,hd,h7,hv]
  have hn:(allowed a b).Nonempty:=⟨_,hm⟩
  have eqn : allowed a b=allowed (word p) (word (R y)):=allowed_map Fin.val Fin.val_injective _ _
  change minimum (allowed (word p) (word (R y)))=Hunter.wt 7 a b
  rw [←eqn,minimum,dite_eq_left hn]
  apply Nat.le_antisymm (Finset.min'_le _ _ hm)
  have hh:=(allowed a b).min'_mem hn
  simp only [allowed,Finset.mem_filter,Finset.mem_Icc] at hh
  exact Hunter.wt_le hh.1.1 hh.1.2 hh.2

-- The action is equivariant under alphabet relabelling, so the 5,040 relative
-- positions suffice to classify the first two costs for all ordered pairs.
private theorem table : (permsOfList (List.finRange 7)).all (fun u=>
    decide (1≤d 1 u ∧ (d 1 u=1 ↔ u=1) ∧ (d 1 u=2 → u=t ∨ u=r)))=true := by decide +native

private theorem specification (p y:X) :
    1≤d p y ∧ (d p y=1 ↔ y=p) ∧ (d p y=2 → y=turn p ∨ y=R p) := by
  let u:=p⁻¹*y
  have hu : u∈permsOfList (List.finRange 7) := mem_permsOfList_of_mem (fun i _=>List.mem_finRange i)
  have factor:p*u=y:=by simp [u]
  obtain ⟨pos,one,two⟩:=of_decide_eq_true (List.all_eq_true.mp table u hu)
  rw [←factor,d_relative]
  refine ⟨pos,?_,?_⟩
  · simp only [one,mul_eq_left]
  · intro h
    rcases two h with a|a
    · exact Or.inl (by rw [a]; rfl)
    · exact Or.inr (by rw [a]; rfl)

theorem d_positive (p y:X) : 1≤d p y := (specification p y).1
theorem d_one (p y:X) : d p y=1 ↔ y=p := (specification p y).2.1
theorem d_two (p y:X) : d p y=2 → y=turn p ∨ y=R p := (specification p y).2.2

#print axioms d_weight
#print axioms d_two

end ExactWordFlow.SevenMoves

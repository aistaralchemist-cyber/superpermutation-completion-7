import GlobalClosedPrice
import Cap35Fibers
import OverlapLoss

namespace ExactWordFlow.FiberBudget
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence ResidualRoutes RotationComponentCount Cap35Rigidity
open scoped Classical

/-- Six common contacts of any two long occupied components charge five units
of excess rank and force at most thirteen occupied nonstart components. -/
theorem few {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤858)
    {q r : Component X} (hq : q∈occupied X s) (hr : r∈occupied X s) (ne : q≠r)
    (longq : 6<(part X q).card) (longr : 6<(part X r).card)
    (common : 6≤(contacts (support X s) (label X) q ∩ contacts (support X s) (label X) r).card) :
    (occupied X s).card≤13 := by
  classical
  have images (k) (hk : k∈occupied X s) : k∈(support X s).image (label X) :=
    (Finset.mem_filter.mp (occupied_active h ▸ hk)).1
  have nonempty:=Finset.card_pos.mp (by omega : 0<(contacts (support X s) (label X) q ∩
      contacts (support X s) (label X) r).card)
  have loss:=overlap_loss (label X) h (fun _ he=>on_edge he) ne (images _ hq) (images _ hr) nonempty
  change 719+(_-1)≤ separateRank X s at loss
  let L:=(occupied X s).filter fun a=>6<(part X a).card
  have sub : {q,r}⊆L := Finset.insert_subset (Finset.mem_filter.mpr ⟨hq,longq⟩)
    (Finset.singleton_subset_iff.mpr (Finset.mem_filter.mpr ⟨hr,longr⟩))
  have twice : 2≤L.card := by simpa [Finset.card_pair ne] using Finset.card_le_card sub
  dsimp only [L] at twice
  have budget:=GlobalClosedPrice.rank_surplus h bd
  dsimp only at budget
  omega

/-- At fourteen or more nonstart components, two sharp 35-edge components
that omit the same symbol in their five-letter restrictions must be disjoint. -/
theorem disjoint_fibers {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤858)
    (many : 14≤(occupied X s).card) {q r : Component X}
    (hq : q∈occupied X s) (hr : r∈occupied X s) (ne : q≠r)
    (qsize : (part X q).card=35) (rsize : (part X r).card=35)
    (qcount : (contacts (support X s) (label X) q).card=30)
    (rcount : (contacts (support X s) (label X) r).card=30) :
    ∃u v,full u ∧ full v ∧ contacts (support X s) (label X) q=Cap35Fibers.fiber u ∧
      contacts (support X s) (label X) r=Cap35Fibers.fiber v ∧
      ∀a : Fin 7,a∉u.take 5 → a∉v.take 5 →
        Disjoint (contacts (support X s) (label X) q) (contacts (support X s) (label X) r) := by
  obtain ⟨u,hu,eq,_⟩:=actual_ten h (Finset.mem_erase.mp hq).1 qsize qcount
  obtain ⟨v,hv,er,_⟩:=actual_ten h (Finset.mem_erase.mp hr).1 rsize rcount
  refine ⟨u,v,hu,hv,eq.trans (Cap35Fibers.shape_eq_fiber _ hu),er.trans (Cap35Fibers.shape_eq_fiber _ hv),?_⟩
  intro a la ra
  apply Finset.disjoint_left.mpr
  intro c qc rc
  have common:=Cap35Fibers.six_common hu hv a la ra ⟨c,Finset.mem_inter.mpr ⟨eq ▸ qc,er ▸ rc⟩⟩
  rw [←eq,←er] at common
  have small:=few h bd hq hr ne (by omega) (by omega) common
  omega

#print axioms few
#print axioms disjoint_fibers
end ExactWordFlow.FiberBudget

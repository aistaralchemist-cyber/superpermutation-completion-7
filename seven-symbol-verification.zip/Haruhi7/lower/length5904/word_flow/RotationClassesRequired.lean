import RequiredComponent

/-! A cyclic class can be represented by its unique rotation beginning with
zero. Every source along the entire rotation is in the same weak component. -/
namespace ExactWordFlow.RequiredComponent
open SevenWordWindows SuperpermutationBounds ResidualRoutes

private theorem key_rotate (p : Block) :
    p.rotate (p.takeWhile (· != 0)).length = classKey p := by
  have h := List.rotate_append_length_eq (p.takeWhile (· != 0)) (p.dropWhile (· != 0))
  rwa [List.takeWhile_append_dropWhile] at h

private theorem rotate_mem {p : Block} (hp : p∈required) (n : Nat) : p.rotate n∈required := by
  have ⟨hl,hd⟩ := (mem_reps p).mp hp
  exact (mem_reps _).mpr ⟨by simpa using hl,(p.rotate_perm n).nodup_iff.mpr hd⟩

private theorem next_src {p : Block} (hp : p∈required) : src (p.rotate 1)=dst p := by
  have hl := ((mem_reps p).mp hp).1
  change (p.rotate 1).take 6=p.drop 1
  rw [List.rotate_eq_drop_append_take (by omega : 1≤p.length)]
  have eq : (p.drop 1).length=6 := by simp [hl]
  rw [←eq,List.take_left]

private theorem rotate_label (X : Multiset Block) {p : Block} (hp : p∈required) (n : Nat) :
    label (required+X) (src p) = label (required+X) (src (p.rotate n)) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [←List.rotate_rotate,next_src (rotate_mem hp n)]
    exact ih.trans (on_edge (Multiset.mem_add.mpr (Or.inl (rotate_mem hp n))))

theorem key_label (X : Multiset Block) {p : Block} (hp : p∈required) :
    label (required+X) (src p) = label (required+X) (src (classKey p)) := by
  rw [←key_rotate]
  exact rotate_label X hp _

def ClassesTogether (X : Multiset Block) : Prop :=
  ∀ c∈allClasses, ∀ d∈allClasses, label (required+X) (src c) = label (required+X) (src d)

private theorem key_mem {p : Block} (hp : p∈required) : classKey p∈allClasses :=
  List.mem_toFinset.mpr (List.mem_map.mpr ⟨p,hp,rfl⟩)

private theorem class_required {c : Block} (hc : c∈allClasses) : c∈required := by
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hc)
  exact key_rotate p ▸ rotate_mem hp _

theorem together_iff_classes (X : Multiset Block) : RequiredTogether X ↔ ClassesTogether X := by
  constructor
  · intro h c hc d hd
    exact h c (class_required hc) d (class_required hd)
  · intro h e he f hf
    exact (key_label X he).trans ((h _ (key_mem he) _ (key_mem hf)).trans (key_label X hf).symm)

theorem exact_5904_iff_720 : (∃ w : Word, Covers w ∧ w.length=5904) ↔
    ∃ (X : Multiset Block) (s t : Block), X.card=858 ∧ (∀ e∈X, e.length=7) ∧
      X.map src+{t}=X.map dst+{s} ∧ ClassesTogether X := by
  simp_rw [←together_iff_classes]
  exact exact_5904_iff_weak

theorem no_5904_iff_two_classes_split : (¬∃ w : Word, Covers w ∧ w.length=5904) ↔
    ∀ (X : Multiset Block) (s t : Block), X.card=858 → (∀ e∈X, e.length=7) →
      X.map src+{t}=X.map dst+{s} →
      ∃ c∈allClasses, ∃ d∈allClasses, label (required+X) (src c) ≠ label (required+X) (src d) := by
  classical
  rw [exact_5904_iff_720]
  simp only [ClassesTogether,not_exists,not_and,not_forall,exists_prop]

end ExactWordFlow.RequiredComponent
#print axioms ExactWordFlow.RequiredComponent.no_5904_iff_two_classes_split

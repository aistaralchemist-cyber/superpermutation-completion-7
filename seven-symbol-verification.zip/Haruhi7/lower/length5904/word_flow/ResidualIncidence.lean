import WordFlow
import ResidualDensity

/-! The bipartite incidence graph of rotation classes and components of the
surplus has at least as many incidences as its vertices minus one. This is
proved from the actual Euler route, including all nonfull contexts. -/
namespace ExactWordFlow.ResidualIncidence
open SevenWordWindows SuperpermutationBounds DirectedEuler ResidualDensity

private def Linked {α β : Type*} : List (α × β) → Prop
  | a::b::xs => (a.1=b.1 ∨ a.2=b.2) ∧ Linked (b::xs)
  | _ => True

private theorem incidence_count {α β : Type*} [DecidableEq α] [DecidableEq β]
    (xs : List (α × β)) (adj : Linked xs) :
    (xs.map Prod.fst).toFinset.card + (xs.map Prod.snd).toFinset.card ≤ xs.toFinset.card + 1 := by
  induction xs with
  | nil => simp
  | cons a tail ih =>
    cases tail with
    | nil => simp
    | cons b zs =>
      obtain ⟨share,rest⟩ := adj
      specialize ih rest
      let l := b::zs
      change ((a::l).map Prod.fst).toFinset.card + ((a::l).map Prod.snd).toFinset.card ≤ (a::l).toFinset.card + 1
      simp only [List.map_cons,List.toFinset_cons]
      by_cases known : a∈l.toFinset
      · have hm : a∈l := List.mem_toFinset.mp known
        have one := List.mem_toFinset.mpr (List.mem_map_of_mem (f:=Prod.fst) hm)
        have two := List.mem_toFinset.mpr (List.mem_map_of_mem (f:=Prod.snd) hm)
        simpa only [Finset.insert_eq_of_mem known,Finset.insert_eq_of_mem one,Finset.insert_eq_of_mem two] using ih
      · rw [Finset.card_insert_of_notMem known]
        have one := Finset.card_insert_le a.1 (l.map Prod.fst).toFinset
        have two := Finset.card_insert_le a.2 (l.map Prod.snd).toFinset
        rcases share with share | share
        · have old : a.1 ∈ (l.map Prod.fst).toFinset := by simp [l,share]
          rw [Finset.insert_eq_of_mem old]
          change (l.map Prod.fst).toFinset.card + (l.map Prod.snd).toFinset.card ≤ l.toFinset.card+1 at ih
          omega
        · have old : a.2 ∈ (l.map Prod.snd).toFinset := by simp [l,share]
          rw [Finset.insert_eq_of_mem old]
          change (l.map Prod.fst).toFinset.card + (l.map Prod.snd).toFinset.card ≤ l.toFinset.card+1 at ih
          omega

private theorem listImage {α β : Type*} [DecidableEq α] [DecidableEq β] (f : α → β) (xs : List α) :
    (xs.map f).toFinset=xs.toFinset.image f := by ext; simp

private theorem linked_route {α β : Type*} {es : List Block} {s t : Block} (g : Block→α) (f : Block→β)
    (r : Route src dst s es t)
    (moves : ∀ e∈es, g (src e)=g (dst e) ∨ f (src e)=f (dst e)) :
    Linked ((s::es.map dst).map (fun v => (g v,f v))) := by
  induction r with
  | nil => trivial
  | @cons u v es e same tail ih =>
    exact ⟨same ▸ moves e List.mem_cons_self,ih (fun b hb => moves b (List.mem_cons_of_mem _ hb))⟩

/-- The six-letter vertices of the complete Euler route, including its root. -/
def support (X : Multiset Block) (s : Block) := insert s ((required+X).map dst).toFinset

/-- Clean rotation classes in one group of vertices. -/
def contacts {ι : Type*} [DecidableEq ι] (D : Finset Block) (g : Block → ι) (q : ι) :=
  (D.filter (fun v => g v=q ∧ full v)).image tag

private theorem required_data : ∀ e∈required, full (src e) ∧ full (dst e) ∧ tag (src e)=tag (dst e) := by
  have finite : representatives.all (fun e => decide (full (src e) ∧ full (dst e) ∧ tag (src e)=tag (dst e))) := by native_decide
  intro e he
  exact of_decide_eq_true (List.all_eq_true.mp finite e he)

private theorem class_count : ((required.map dst).toFinset.image tag).card=720 := by native_decide

/-- Attach a default to a group only if it meets no clean vertex. -/
private def enlarged (F : Finset Block) := if F.Nonempty then F else {[]}
private theorem enlarged_ne (F : Finset Block) : (enlarged F).Nonempty := by
  rw [enlarged]; split <;> simp_all
private theorem enlarged_size (F : Finset Block) : (enlarged F).card = (F.card - 1) + 1 := by
  rw [enlarged]; split
  · rename_i ne
    have pos := Finset.card_pos.mpr ne
    omega
  · rename_i empty
    simp [Finset.not_nonempty_iff_eq_empty.mp empty]

/-- `g` may identify entire residual weak components. Taking one label per
component gives its number of distinct clean rotation classes `C`. Dirty-only
groups and isolated clean contexts each contribute zero to `C - 1`. -/
theorem rank719 {ι : Type*} [DecidableEq ι] {X : Multiset Block} {s t : Block}
    (g : Block → ι) (h : Feasible X s t) (hg : ∀ e∈X, g (src e)=g (dst e)) :
    719 ≤ ∑ q ∈ (support X s).image g, ((contacts (support X s) g q).card - 1) := by
  classical
  let D := support X s
  let Q := D.image g
  let F (q) := contacts D g q
  let f (v : Block) := if full v then tag v else (enlarged_ne (F (g v))).choose
  have ffull (v) (hv : full v) : f v=tag v := by simp [f,hv]
  have lives (v) (hv : v∈D) : f v∈enlarged (F (g v)) := by
    by_cases ok : full v
    · have hit : tag v ∈ F (g v) := Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨hv,rfl,ok⟩,rfl⟩
      simpa [enlarged,ffull v ok,show (F (g v)).Nonempty from ⟨_,hit⟩] using hit
    · simpa [f,ok] using (enlarged_ne (F (g v))).choose_spec
  have rb : required.map src=required.map dst := balanced_representatives
  have balance : (required+X).map src + {t} = (required+X).map dst + {s} := by
    rw [Multiset.map_add,Multiset.map_add,rb,add_assoc,add_assoc,h.balance]
  obtain ⟨es,bag,r⟩ := DirectedEuler.exists_route src dst (required+X) s t balance h.reachable
  let vs := s::es.map dst
  have nodes : vs.toFinset=D := by
    simp only [vs,List.toFinset_cons,D,support,←bag,Multiset.map_coe,List.toFinset_coe]
  have step (e) (he : e∈es) : g (src e)=g (dst e) ∨ f (src e)=f (dst e) := by
    have he' : e∈required+X := bag ▸ (show e∈(↑es : Multiset Block) from he)
    rcases Multiset.mem_add.mp he' with r | x
    · obtain ⟨a,b,eq⟩ := required_data e r
      exact Or.inr (by rw [ffull _ a,ffull _ b,eq])
    · exact Or.inl (hg e x)
  have bound := incidence_count _ (linked_route g f r step)
  change (((vs.map (fun v => (g v, f v))).map Prod.fst).toFinset.card +
    ((vs.map (fun v => (g v, f v))).map Prod.snd).toFinset.card ≤
    (vs.map (fun v => (g v, f v))).toFinset.card + 1) at bound
  simp only [List.map_map,listImage,nodes,Function.comp_def] at bound
  have total : 720 ≤ (D.image f).card := by
    rw [←class_count]
    apply Finset.card_le_card
    intro y mem
    obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp mem
    obtain ⟨e,he,rfl⟩ := Multiset.mem_map.mp (Multiset.mem_toFinset.mp hv)
    have vv : dst e ∈ D := by
      apply Finset.mem_insert_of_mem
      exact Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inl he),rfl⟩)
    exact Finset.mem_image.mpr ⟨_,vv,ffull _ (required_data e he).2.1⟩
  let pairs q := (enlarged (F q)).image (Prod.mk q)
  have cp : D.image (fun v => (g v, f v)) ⊆ Q.biUnion pairs := by
    intro x hx
    obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hx
    exact Finset.mem_biUnion.mpr ⟨g v,Finset.mem_image_of_mem g hv,Finset.mem_image_of_mem _ (lives v hv)⟩
  have up := (Finset.card_le_card cp).trans Finset.card_biUnion_le
  have paircard (q) : (pairs q).card = (F q).card-1+1 := by
    change ((enlarged (F q)).image (Prod.mk q)).card = _
    rw [Finset.card_image_of_injective _ (Prod.mk_right_injective _),enlarged_size]
  simp only [paircard,Finset.sum_add_distrib,Finset.sum_const,smul_eq_mul,mul_one] at up
  change 719 ≤ ∑ q∈Q, ((F q).card-1)
  change Q.card + (D.image f).card ≤ (D.image (fun v => (g v,f v))).card+1 at bound
  omega

end ExactWordFlow.ResidualIncidence
#print axioms ExactWordFlow.ResidualIncidence.rank719

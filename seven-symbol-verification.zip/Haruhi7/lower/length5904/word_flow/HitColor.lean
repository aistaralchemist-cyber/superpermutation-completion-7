import AnonymousRows

namespace ExactWordFlow.HitColor
open AnonymousRows
variable {X Y ι : Type*} [Fintype X] [DecidableEq Y] [DecidableEq ι]

/-- A hitting set in the rotation classes bounds the number of exceptional rows
by the number of different *contracted* labels seen by the hitting set. -/
theorem bound {S : Finset X} {owner : X→ι} {tag : X→Y} {f : Y→Y} {price : X→Nat}
    {K : Finset ι} (sep : Separated S owner (f ∘ tag) price K)
    (H : Finset Y) (hit : ∀i∈K,∃x∈states owner i,tag x∈H) :
    K.card≤(H.image f).card := by
  classical
  let rows (i : ι):=((states owner i).image (f ∘ tag)) ∩ (H.image f)
  have nz (i) (hi:i∈K) : 1≤(rows i).card := by
    obtain ⟨x,hx,hH⟩:=hit i hi
    exact Finset.card_pos.mpr ⟨f (tag x),Finset.mem_inter.mpr
      ⟨Finset.mem_image_of_mem (f ∘ tag) hx,Finset.mem_image_of_mem f hH⟩⟩
  have apart : (K : Set ι).PairwiseDisjoint rows := by
    intro i hi j hj ne
    exact (sep.2 i hi j hj ne).mono Finset.inter_subset_left Finset.inter_subset_left
  have sub : K.biUnion rows⊆H.image f := by
    intro z hz
    obtain ⟨i,_,mem⟩:=Finset.mem_biUnion.mp hz
    exact (Finset.mem_inter.mp mem).2
  have sum:=Finset.sum_le_sum nz
  rw [←Finset.card_biUnion apart] at sum
  simpa using sum.trans (Finset.card_le_card sub)

/-- Every choice of fewer than |K| colours misses an entire selected row. -/
theorem avoided {S : Finset X} {owner : X→ι} {tag : X→Y} {f : Y→Y} {price : X→Nat}
    {K : Finset ι} (sep : Separated S owner (f ∘ tag) price K)
    (H : Finset Y) (small : (H.image f).card<K.card) :
    ∃i∈K,∀x∈states owner i,tag x∉H := by
  classical
  by_contra! no
  exact (Nat.not_le_of_lt small) (bound sep H no)

/-- If the chosen wheels have connected union C, a common label on C costs
one colour in a hitting set, however large C is. -/
theorem one_component (C B : Finset Y) (f : Y→Y) (a : Y)
    (same : ∀z∈C,f z=a) : ((C∪B).image f).card≤1+B.card := by
  have sub : C.image f⊆{a} := by
    intro z hz
    obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hz
    simpa only [Finset.mem_singleton] using same x hx
  rw [Finset.image_union]
  have size := Finset.card_le_card sub
  simp only [Finset.card_singleton] at size
  exact (Finset.card_union_le ..).trans (Nat.add_le_add size Finset.card_image_le)

def chain (A : Finset Y) : List (Finset Y) → Bool
  | [] => true
  | w::rest => decide ((A∩w).Nonempty) && chain (A∪w) rest

theorem connected (f : Y→Y) (a : Y) (A : Finset Y) (ws : List (Finset Y))
    (base : ∀x∈A,f x=a) (joins : chain A ws=true)
    (same : ∀w∈ws,∀x∈w,∀y∈w,f x=f y) :
    ∀x∈ws.foldl (·∪·) A,f x=a := by
  induction ws generalizing A with
  | nil => exact base
  | cons w rest ih =>
    simp only [chain,Bool.and_eq_true,decide_eq_true_eq] at joins
    obtain ⟨y,hy⟩:=joins.1
    have meet:=Finset.mem_inter.mp hy
    apply ih (A∪w) _ joins.2 (fun u hu=>same u (List.mem_cons_of_mem _ hu))
    intro x hx
    rcases Finset.mem_union.mp hx with old|new
    · exact base _ old
    · exact (same w (by simp) x new y meet.2).trans (base y meet.1)

#print axioms bound
#print axioms connected
end ExactWordFlow.HitColor

import WheelBaseResidual
import CoreAssembly

namespace ExactWordFlow.WheelBaseResidual
open SevenWordWindows SuperpermutationBounds ResidualDensity
open RotationCore RotationReinsert LiteralWheelCover EmbeddedWheels CoreAssembly
open private sizes from EmbeddedWheels
open private ordered from WheelAccess

theorem mandatory_in_bag (b : Block) : mandatory (complete b)≤bag b := by
  have uniq:required.Nodup:=Multiset.coe_nodup.mpr (List.nodup_permutations _ (List.nodup_finRange _))
  apply (Multiset.le_iff_subset (Multiset.Nodup.filter _ uniq)).mpr
  intro e he
  obtain ⟨req,comp⟩:=Multiset.mem_filter.mp he
  exact ((mem_complete ..).mp comp).2 e req rfl

private theorem head_unchanged {b v : Block} {rs : List Row} (ins : Inserts b rs v) : v.take 6=b.take 6 := by
  induction ins with
  | stop => rfl
  | add clean _ ih => exact ih.trans (ordered _ _ _ clean).1

private theorem laps_clean : ∀u∈states,∀e∈lap u,e.Nodup := by native_decide
private theorem laps_required (u : Block) (hu:u∈states) (e : Block) (he:e∈lap u) :
    e∈representatives := (mem_reps e).mpr ⟨window_width (lapWord u) he,laps_clean u hu e he⟩

/-- The balance equations and reachability hold at the endpoints of the
base word for its own literal remainder after subtraction, with all restored
wheel rows and their actual multiplicities. This needs no ordering choice
for the 628 restored seven-laps. -/
theorem actual_spare {b v : Block} {rs : List Row} (ins : Inserts b rs v)
    (vis : (visited v).card=720) (long : 6≤b.length) :
    ∃ws : List Block,ws.map WheelContacts.wheel=rs ∧ ws.length=rs.length ∧
      (∀u∈ws,full u) ∧ Feasible ((bag b - mandatory (complete b))+turns ws)
        (b.take 6) (b.drop (b.length-6)) ∧
      ((bag b - mandatory (complete b))+turns ws).card+7*(complete b).card+6=v.length := by
  classical
  let M:=mandatory (complete b)
  let Y:=bag b-M
  obtain ⟨ws,rows,num,cl,wins⟩:=inserted_turns_rows ins
  let X:=Y+turns ws
  have msub:M≤required:=Multiset.filter_le ..
  have before : M+Y=bag b:=add_tsub_cancel_of_le (mandatory_in_bag b)
  have mdata:=mandatory_data (complete b) (fun c hc=>((mem_complete b c).mp hc).1)
  change M.card=7*(complete b).card ∧ M.map src=M.map dst at mdata
  have exactV : M+X=bag v:=by rw [wins,←before,add_assoc]
  have included : bag v≤required+X:=exactV ▸ add_le_add_left msub X
  have canon : visited v=allClasses:=Finset.eq_of_subset_of_card_le (visited_subset v) (by rw [vis,board])
  have growth:=ins.length_eq
  have longV : 6≤v.length:=by omega
  have head:=head_unchanged ins
  have widths (e) (he:e∈X) : e.length=7:=by
    apply window_width v
    change e∈bag v
    exact exactV ▸ Multiset.mem_add.mpr (Or.inr he)
  have rt:=read_route b long
  have bal:=rt.balance
  change (bag b).map src+_=(bag b).map dst+_ at bal
  rw [←before,Multiset.map_add,Multiset.map_add,mdata.2,add_assoc,add_assoc] at bal
  have ybal:=add_left_cancel bal
  have xb:X.map src+{b.drop (b.length-6)}=X.map dst+{b.take 6}:=by
    simp only [X,Multiset.map_add,(sizes cl).2,add_right_comm _ ((turns ws).map dst) _,ybal]
  have card:=congrArg Multiset.card exactV
  simp only [Multiset.card_add,bag,Multiset.coe_card,windows_length] at card
  refine ⟨ws,rows,num,cl,⟨by simp;omega,widths,xb,?_⟩,by change X.card+7*(complete b).card+6=v.length;omega⟩
  intro S hs closed e inAll
  have own (e) (he:e∈bag v): e∈required+X:=Multiset.mem_of_le included he
  have step (e) (he:e∈windows v) (atS:src e∈S):=closed e (own _ he) atS
  have srcV:=(read_route v longV).closed S (head ▸ hs) step
  rcases Multiset.mem_add.mp inAll with req | surplus
  · have c:classKey e∈allClasses:=List.mem_toFinset.mpr (List.mem_map.mpr ⟨e,req,rfl⟩)
    obtain ⟨u,hpos,fu,key⟩:=(mem_visited v (classKey e)).mp (canon ▸ c)
    have here:u∈S:=by
      rcases List.mem_cons.mp hpos with first|later
      · rw [first,head];exact hs
      · obtain ⟨x,hx,rfl⟩:=List.mem_map.mp later
        exact step _ hx (srcV.2 _ hx)
    obtain ⟨loop,_,contains⟩:=lap_geometry u fu
    exact (loop.closed S here (fun x hx=>closed x (Multiset.mem_add.mpr
      (Or.inl (show x∈required from laps_required u (mem_states fu) x hx))))).2 e (contains _ req key.symm)
  · have mem:e∈bag v:=exactV ▸ Multiset.mem_add.mpr (Or.inr surplus)
    exact srcV.2 e mem

/-- In particular, when no wheel is restored, the literal spare itself is
the feasible 858-edge residual of the tested 1508-letter base. -/
theorem zero_spare {b : Block} (done:(complete b).card=92)
    (length:b.length=1508) (fit:condition b 0) :
    Feasible (bag b - mandatory (complete b)) (b.take 6) (b.drop (b.length-6)) ∧
      (bag b - mandatory (complete b)).card=858 := by
  obtain ⟨rs,v,ins,sz,all⟩:=(budget_iff b 0).mpr fit
  have growth:=ins.length_eq
  obtain ⟨ws,_,n,_,flow,card⟩:=actual_spare ins all (by omega)
  have empty:ws=[]:=List.length_eq_zero_iff.mp (by omega)
  simp only [empty,turns,List.flatMap_nil,Multiset.coe_nil,add_zero] at flow card
  exact ⟨flow,by omega⟩

#print axioms actual_spare
#print axioms zero_spare
end ExactWordFlow.WheelBaseResidual

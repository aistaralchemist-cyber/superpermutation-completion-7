import LapEditAssemble
import LapEditFocus
import LapEditCost

namespace ExactWordFlow.LapEditAssemble
open SevenWordWindows RotationCore RotationCoreControls LapEditContexts LapDeletionShadow LocalDeletion

/-- Uniform over source records, end letters, and arbitrary optional-lap choices. -/
theorem after_cut_and_edit {ts : List Tile} (valid : Valid ts)
    (goodSource : (good (uncut ts)).length=5040)
    (eight : ∀p∈ts.filterMap Tile.skip,(LapMultiplicity.tags (uncut ts)).count (classKey p)=8)
    (checked : scan LapEditCost.rejects [] ts=true) {w ps} (r : Render ts w ps)
    (i : Nat) (inside : i<w.length) (all : (visited (w.eraseIdx i)).card=720) :
    (complete (w.eraseIdx i)).card+ps.length<720 := by
  obtain ⟨l,x,z,seen,form,pos,ok,sub⟩:=at_letter checked r i inside
  have cut : Cuts (uncut ts) ps w := by simpa only [List.nil_append] using cuts r valid []
  have localLoss:=LapEditCost.dichotomy l x z seen ok
  have erased : w.eraseIdx i=l++z := by rw [form,pos,erase_center]
  apply from_loss cut goodSource (fun p h=>eight p (member r p h)) _ all
  rw [erased,form]
  rcases localLoss with yes|⟨p,hm,loss⟩
  · exact Or.inl yes
  · exact Or.inr ⟨p,sub _ hm,loss⟩

#print axioms after_cut_and_edit
end ExactWordFlow.LapEditAssemble

import BaseEqualityDecision
import EssentialPackets

namespace ExactWordFlow.PrivateCompletionEdges
open SevenWordWindows SuperpermutationBounds ResidualDensity RotationCore CoreAssembly
open WheelBaseResidual LiteralWheelCover EmbeddedWheels Essential

/-- At cost 858, deleting a balanced packet of six or more edges must
separate required support, even when the original flow was not minimized. -/
theorem cut {A B : Multiset Block} {s t : Block} (flow : Feasible (A+B) s t)
    (budget : (A+B).card≤858) (balanced : Balanced B) (size : 6≤B.card) : MandatoryCut A s t := by
  apply separated_at_floor flow balanced (floor:=5899)
  · exact SuperpermLowerBounds.covers_lower_bound_7_k16_native
  · rw [Multiset.card_add] at budget
    omega

theorem absent {X : Multiset Block} {s t c : Block} (flow : Feasible X s t)
    (budget : X.card≤858) (valid : c∈allClasses) : ¬mandatory {c}≤X := by
  intro sub
  have dec : X=(X-mandatory {c})+mandatory {c}:=(tsub_add_cancel_of_le sub).symm
  have data:=mandatory_data {c} (Finset.singleton_subset_iff.mpr valid)
  have size : (mandatory {c}).card=7:=by simpa using data.1
  exact represented_no_cut (dec ▸ flow) (fun e he=>Multiset.mem_add.mpr (Or.inl (Multiset.mem_filter.mp he).1))
    (cut (dec ▸ flow) (dec ▸ budget) data.2 (by omega))

/-- Each of the 92 completed classes has a permutation which occurs at
exactly one position in the original base word. Applies also at cost zero. -/
theorem private_edge {b c : Block} {m : Nat} (h : BaseEqualityDecision.candidate b m)
    (hc : c∈complete b) : ∃e∈required,classKey e=c ∧ (bag b).count e=1 := by
  classical
  obtain ⟨_,done,total,least⟩:=h
  obtain ⟨rs,v,ins,small,vis⟩:=(budget_iff b m).mpr least.1
  have len:=ins.length_eq
  have floor:=LapSkeleton.completed_floor b
  have room : (good b).length≤b.length-6:=by rw [←windows_length];exact List.length_filter_le ..
  obtain ⟨ws,_,_,_,flow,sz⟩:=actual_spare ins vis (by omega)
  let Y:=bag b-mandatory (complete b)
  have no:=absent flow (by omega) ((mem_complete b c).mp hc).1
  have nodup : required.Nodup:=Multiset.coe_nodup.mpr (List.nodup_permutations _ (List.nodup_finRange _))
  have noY : ¬mandatory {c}≤Y:=fun le=>no (le.trans (Multiset.le_add_right ..))
  have notMem : ¬∀e∈mandatory {c},e∈Y:=fun incl=>noY ((Multiset.le_iff_subset (nodup.filter _)).mpr incl)
  push Not at notMem
  obtain ⟨e,one,away⟩:=notMem
  obtain ⟨legal,tag⟩:=Multiset.mem_filter.mp one
  have key : classKey e=c:=Finset.mem_singleton.mp tag
  have occ : e∈mandatory (complete b):=Multiset.mem_filter.mpr ⟨legal,key ▸ hc⟩
  refine ⟨e,legal,key,?_⟩
  have split : mandatory (complete b)+Y=bag b:=add_tsub_cancel_of_le (mandatory_in_bag b)
  have once : (mandatory (complete b)).count e=1:=Multiset.count_eq_one_of_mem (nodup.filter _) occ
  rw [←split,Multiset.count_add,Multiset.count_eq_zero.mpr away,once,Nat.add_zero]

#print axioms private_edge
end ExactWordFlow.PrivateCompletionEdges

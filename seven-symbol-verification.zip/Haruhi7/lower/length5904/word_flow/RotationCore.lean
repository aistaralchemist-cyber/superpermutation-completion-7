import AdjacentInvalid
import CoreCounts
import RotationContract
import RotationRun

namespace ExactWordFlow.RotationCore
open SevenWordWindows SuperpermutationBounds RotationReinsert

/-- Contract any selected complete runs of the original word, keeping a
literal overlapping word and the anchors for all possible reinsertions. -/
theorem contract {w : Block} (S : Finset Block) (hw : Covers w)
    (pick : S ⊆ completeClasses w) :
    ∃v : Block, 6≤v.length ∧ v.length+7*S.card=w.length ∧
      S⊆visited v ∧ allClasses \ S ⊆ complete v := by
  obtain ⟨a,b,win⟩ := hw (List.finRange 7) List.length_finRange (List.nodup_finRange _)
  have long : 6≤w.length := by simp [win]; omega
  have r := read_route w long
  obtain ⟨ys,path,len,mem,anchors⟩ := RotationContract.many S r (fun _ he => window_width w he)
    (fun c hc => RotationRun.closed_run (pick hc))
  obtain ⟨v,sz,start,edges⟩ := spell_route path (by simp; omega)
    (fun e he => window_width w ((mem e).mp he).1)
  refine ⟨v,by omega,by rw [windows_length] at len; omega,?_,?_⟩
  · intro c hc
    obtain ⟨u,here,fullu,key⟩ := anchors c hc
    apply (mem_visited v c).mpr
    exact ⟨u,by simpa [RotationReinsert.anchors,start,edges] using here,fullu,key⟩
  · intro c hc
    obtain ⟨inBoard,keep⟩ := Finset.mem_sdiff.mp hc
    apply (mem_complete v c).mpr
    refine ⟨inBoard,?_⟩
    intro p hp key
    obtain ⟨pl,nd⟩ := (mem_reps _).mp hp
    obtain ⟨l,r,occ⟩ := hw p pl nd
    rw [edges]
    apply (mem p).mpr
    refine ⟨by rw [occ]; exact window_mem _ _ _ pl,?_⟩
    intro d hd eq
    have same : c=d := by simpa [mark,nd,key] using eq
    exact keep (same ▸ hd)

/-- One free-endpoint word and two counts suffice. No class identities or
reference record are fixed. The right side can be tested directly on v. -/
theorem threshold {k : Nat} (fits : k≤720)
    (enough : ∀w : Block, Covers w → w.length≤5904 →
      ∃z : Block, Covers z ∧ z.length≤5904 ∧ k≤(completeClasses z).card) :
    (∃w : Block, Covers w ∧ w.length≤5904) ↔
      ∃v : Block, 6≤v.length ∧ v.length≤5904-7*k ∧
        (visited v).card=720 ∧ 720-k≤(complete v).card := by
  classical
  constructor
  · rintro ⟨original,covered,limit⟩
    obtain ⟨w,hw,cap,numRuns⟩ := enough original covered limit
    obtain ⟨S,sub,card⟩ := Finset.exists_subset_card_eq numRuns
    have good : S ⊆ allClasses := fun c hc => (Finset.mem_filter.mp (sub hc)).1
    obtain ⟨v,long,size,hit,covered⟩ := contract S hw sub
    have all : allClasses ⊆ visited v := by
      intro c hc
      by_cases sel : c∈S
      · exact hit sel
      · exact complete_subset v (covered (Finset.mem_sdiff.mpr ⟨hc,sel⟩))
    have equal := Finset.Subset.antisymm (visited_subset v) all
    have num := Finset.card_le_card covered
    rw [Finset.card_sdiff_of_subset good,board,card] at num
    exact ⟨v,long,by omega,by rw [equal,board],num⟩
  · rintro ⟨v,long,limit,vis,full⟩
    obtain ⟨K,sub,sz⟩ := Finset.exists_subset_card_eq full
    have good : K ⊆ allClasses := fun c hc => ((mem_complete _ _).mp (sub hc)).1
    have same : visited v=allClasses :=
      Finset.eq_of_subset_of_card_le (visited_subset v) (by rw [vis,board])
    let S := allClasses \ K
    have card : S.card=k := by
      rw [show S.card=(allClasses \ K).card from rfl,Finset.card_sdiff_of_subset good,board,sz]
      omega
    obtain ⟨w,hw,size⟩ := expand (w:=v) S long (by
      intro c hc
      exact (mem_visited _ _).mp (same ▸ (Finset.mem_sdiff.mp hc).1)) (by
      intro p hp keep
      have boardp : classKey p∈allClasses := List.mem_toFinset.mpr (List.mem_map_of_mem hp)
      have ink : classKey p∈K := by by_contra h; exact keep (Finset.mem_sdiff.mpr ⟨boardp,h⟩)
      exact ((mem_complete _ _).mp (sub ink)).2 p hp rfl)
    exact ⟨w,hw,by omega⟩

theorem exact_1837 :
    (∃w : Block, Covers w ∧ w.length≤5904) ↔
      ∃v : Block, 6≤v.length ∧ v.length≤1837 ∧
        (visited v).card=720 ∧ 139≤(complete v).card :=
  threshold (k:=581) (by decide)
    (fun w hw cap => ⟨w,hw,cap,complete_class_floor w hw cap⟩)

/-- Two adjacent invalid-window pairs are forced after endpoint normalization.
The class set, anchor phases, underlying word, and endpoints are all free. -/
theorem exact_1823 :
    (∃w : Block, Covers w ∧ w.length≤5904) ↔
      ∃v : Block, 6≤v.length ∧ v.length≤1823 ∧
        (visited v).card=720 ∧ 137≤(complete v).card := by
  apply threshold (k:=583) (by decide)
  intro w hw cap
  obtain ⟨z,hz,size,count⟩ := AdjacentInvalid.some_583 hw cap
  exact ⟨z,hz,size.le,count⟩

/-- The manuscript's excursion argument implies the premise. Keeping this
word-to-excursion bridge explicit distinguishes its status from exact_1823. -/
theorem exact_1704_of_excursions
    (nineteen : ∀ w : Block, Covers w → w.length≤5904 →
      ∃ z : Block, Covers z ∧ z.length≤5904 ∧ 19≤AdjacentInvalid.adjacent (labels z)) :
    (∃w : Block, Covers w ∧ w.length≤5904) ↔
      ∃v : Block, 6≤v.length ∧ v.length≤1704 ∧
        (visited v).card=720 ∧ 120≤(complete v).card := by
  apply threshold (k:=600) (by decide)
  intro w hw cap
  obtain ⟨z,cover,limit,adj⟩ := nineteen w hw cap
  have bound := AdjacentInvalid.complete_with_gaps z cover limit
  exact ⟨z,cover,limit,by omega⟩

/-- A core that visits every class can restore every unfinished class.
This uses the actual completed classes of this very word. -/
theorem expand_remaining {v : Block} (long : 6≤v.length) (vis : (visited v).card=720) :
    ∃w : Block, Covers w ∧ w.length=v.length+7*(720-(complete v).card) := by
  have all : visited v=allClasses :=
    Finset.eq_of_subset_of_card_le (visited_subset v) (by rw [vis,board])
  have good : complete v ⊆ allClasses := fun c hc => ((mem_complete v c).mp hc).1
  let S := allClasses \ complete v
  obtain ⟨w,hw,sz⟩ := expand (w:=v) S long (by
    intro c hc
    exact (mem_visited _ _).mp (all ▸ (Finset.mem_sdiff.mp hc).1)) (by
    intro p hp keep
    have boardp : classKey p∈allClasses := List.mem_toFinset.mpr (List.mem_map_of_mem hp)
    have done : classKey p∈complete v := by
      by_contra h
      exact keep (Finset.mem_sdiff.mpr ⟨boardp,h⟩)
    exact ((mem_complete _ _).mp done).2 p hp rfl)
  exact ⟨w,hw,by simpa [S,Finset.card_sdiff_of_subset good,board] using sz⟩

/-- Even the weaker published floor of 5,898 suffices for the 139 cap.
A stronger floor of 5,901 also forces a successful core to have length ≥1,834. -/
theorem cap_139 (lower : ∀w : Block, Covers w → 5898≤w.length)
    {v : Block} (long : 6≤v.length) (small : v.length≤1837) (all : (visited v).card=720) :
    (complete v).card≤139 := by
  obtain ⟨w,hw,sz⟩ := expand_remaining long all
  have bound := lower w hw
  omega

theorem length_floor (lower : ∀w : Block, Covers w → 5901≤w.length)
    {v : Block} (long : 6≤v.length) (all : (visited v).card=720) (enough : 139≤(complete v).card) :
    1834≤v.length := by
  obtain ⟨w,hw,sz⟩ := expand_remaining long all
  have bound := lower w hw
  omega

/-- The earlier 5,898 floor already forces a universal upper bound of 137
at the shorter threshold. The public 5,901 floor restricts lengths to 1,820–1,823. -/
theorem cap_137 (lower : ∀w : Block, Covers w → 5898≤w.length)
    {v : Block} (long : 6≤v.length) (small : v.length≤1823) (all : (visited v).card=720) :
    (complete v).card≤137 := by
  obtain ⟨w,hw,sz⟩ := expand_remaining long all
  have bound := lower w hw
  omega

theorem length_floor_1820 (lower : ∀w : Block, Covers w → 5901≤w.length)
    {v : Block} (long : 6≤v.length) (all : (visited v).card=720) (enough : 137≤(complete v).card) :
    1820≤v.length := by
  obtain ⟨w,hw,sz⟩ := expand_remaining long all
  have bound := lower w hw
  omega

/-- A sharp upper bound for a count on a single shorter word would settle
the actual optimum, regardless of the witness path, wheels, or endpoints. -/
theorem optimal_iff_136 : SuperpermBridge.HR.Ssuper 7=5905 ↔
    ∀ v : Block, 6≤v.length → v.length≤1823 → (visited v).card=720 → (complete v).card≤136 := by
  constructor
  · intro eq v long cap all
    by_contra! more
    obtain ⟨w,hw,sz⟩ := exact_1823.mpr ⟨v,long,cap,all,more⟩
    have low := SuperpermBridge.ssuper_le_length hw
    omega
  · intro max
    have up := SuperpermBridge.ssuper_le_length SuperpermLowerBounds.LengthBudget.Word5905.covers
    rw [SuperpermLowerBounds.LengthBudget.Word5905.length_5905] at up
    apply Nat.le_antisymm up
    apply (SuperpermBridge.le_ssuper_iff (by decide : 0<7)).mpr
    intro w hw
    by_contra! small
    obtain ⟨v,long,cap,all,more⟩ := exact_1823.mp ⟨w,hw,by omega⟩
    have limit := max v long cap all
    omega

#print axioms optimal_iff_136
#print axioms exact_1704_of_excursions
#print axioms exact_1823
#print axioms cap_137
#print axioms contract
#print axioms exact_1837
end ExactWordFlow.RotationCore

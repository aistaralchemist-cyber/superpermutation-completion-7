import SquareGeometry
import Mathlib.LinearAlgebra.LinearIndependent.Basic

namespace SquareDual
open SevenWordWindows ExactWordFlow

/-- Any proper family of squares is independent, even when nonzero boundary
coefficients are allowed to vary by square and by incidence. The proof
examines an incidence belonging to exactly one nonzero term of a relation. -/
theorem independent_rows {K : Type*} [Field K] {T : Finset Block} (proper : T ⊂ faces)
    (rows : Block → (Block × Block) → K)
    (supp : ∀ f∈T, ∀ e∈representatives, rows f (incidence e)≠0 ↔ e∈boundary f) :
    LinearIndependent K (fun f : T => rows f.val) := by
  classical
  apply Fintype.linearIndependent_iff.mpr
  intro g hg i
  by_contra n
  let nz := (Finset.univ.filter fun a : T => g a ≠ 0).image Subtype.val
  have included : nz ⊆ T := by
    intro a ha
    obtain ⟨b,_,rfl⟩ := Finset.mem_image.mp ha
    exact b.property
  have occurs (j : T) : j.val∈nz ↔ g j≠0 := by simp [nz]
  obtain ⟨e,he,only⟩ := proper_boundary (Finset.ssubset_of_subset_of_ssubset included proper)
    ⟨i.val,(occurs i).mpr n⟩
  obtain ⟨f,unique⟩ := Finset.card_eq_one.mp only
  have present : f∈nz ∧ e∈boundary f := Finset.mem_filter.mp (unique ▸ Finset.mem_singleton_self _)
  let j : T := ⟨f,included present.1⟩
  have gj : g j≠0 := (occurs j).mp present.1
  have row := (supp f j.property e he).mpr present.2
  have atE := congrFun hg (incidence e)
  simp only [Finset.sum_apply, Pi.smul_apply, Pi.zero_apply, smul_eq_mul] at atE
  have keep : (∑ a : T, g a * rows a.val (incidence e)) = g j * rows j.val (incidence e) := by
    apply Finset.sum_eq_single j
    · intro a _ diff
      by_cases van : g a=0
      · simp [van]
      · have other : e∉boundary a.val := by
          intro hit
          have mem : a.val∈nz.filter (fun q => e∈boundary q) :=
            Finset.mem_filter.mpr ⟨(occurs a).mpr van,hit⟩
          rw [unique,Finset.mem_singleton] at mem
          exact diff (Subtype.ext mem)
        have z : rows a.val (incidence e)=0 := by_contra fun no => other ((supp _ a.property _ he).mp no)
        simp [z]
    · simp
  exact (mul_ne_zero gj row) (keep.symm.trans atE)

/-- Unsigned square rows over GF(2); class coordinate first, wheel
coordinate second. -/
def modTwoRow (f : Block) (z : Block × Block) : ZMod 2 :=
  if z∈(boundary f).image incidence then 1 else 0

theorem independent_mod_two {T : Finset Block} (proper : T ⊂ faces) :
    LinearIndependent (ZMod 2) (fun f : T => modTwoRow f.val) := by
  apply independent_rows proper
  intro f hf e he
  have valid := (face_square (proper.le hf)).2.2.2
  have iffMem : incidence e ∈ (boundary f).image incidence ↔ e∈boundary f := by
    constructor
    · rintro mem
      obtain ⟨d,hd,eq⟩ := Finset.mem_image.mp mem
      exact incidence_injective (List.mem_toFinset.mp (valid hd)) he eq ▸ hd
    · exact Finset.mem_image_of_mem _
  by_cases mem : e∈boundary f <;> simp [modTwoRow,iffMem,mem]

#print axioms independent_rows
#print axioms independent_mod_two
end SquareDual

import ReferenceSpineOptimum
import BypassPackets

namespace ExactWordFlow.SpineWheelTrimming
open SevenWordWindows SuperpermutationBounds DirectedEuler ResidualRoutes RequiredComponent
open ResidualDensity EmbeddedWheels

private theorem startsSix {s t : Block} {es : List Block} (r : Route src dst s es t)
    (hne : es≠[]) (width : ∀e∈es, e.length=7) : s.length=6 := by
  cases r with
  | nil => exact (hne rfl).elim
  | cons e hs _ => simp [←hs,src,width e (List.mem_cons_self ..)]

/-- In an open integer placement connecting the mandatory rotation classes,
discarding the other components keeps every occurrence of a prescribed route
starting at a full six-letter state, and all prescribed complete wheels. -/
theorem trim {a b s t : Block} {p ws : List Block} {F : Multiset Block}
    (path : Route src dst a p b) (startFull : full a) (legit : ∀u∈ws,full u)
    (width : ∀ e∈((↑p : Multiset Block)+turns ws+F), e.length=7)
    (bal : ((↑p : Multiset Block)+turns ws+F).map src+{t}=
      ((↑p : Multiset Block)+turns ws+F).map dst+{s})
    (together : ClassesTogether ((↑p : Multiset Block)+turns ws+F)) :
    ∃ F'≤F, ∃ s' t', Feasible ((↑p : Multiset Block)+turns ws+F') s' t' := by
  classical
  let K := (↑p : Multiset Block)+turns ws
  let X := K+F
  let G := required+X
  let root : Block := List.finRange 7
  have req : root∈required := (mem_reps root).mpr ⟨List.length_finRange,List.nodup_finRange _⟩
  let q := label G (src root)
  have conn : RequiredTogether X := (together_iff_classes X).mpr together
  have same (v : Block) (h : full v) : label G v=q := by
    obtain ⟨e,he,hs⟩ := List.mem_map.mp (show v∈representatives.map (·.take 6) from mem_states h)
    exact hs ▸ conn e he root req
  have pMem (e : Block) (he : e∈p) : e∈G :=
    Multiset.mem_add.mpr (Or.inr (Multiset.mem_add.mpr (Or.inl
      (Multiset.mem_add.mpr (Or.inl he)))))
  have pSame := (path.closed {v | label G v=q} (same _ startFull)
    (fun e he eq => (on_edge (pMem e he)).symm.trans eq)).2
  have wheelClean : ∀ u∈states, ∀ e∈GlobalWheelRank.wheel u, full (src e) := by native_decide
  have kept (e : Block) (he : e∈K) : label G (src e)=q := by
    rcases Multiset.mem_add.mp he with h|h
    · exact pSame e h
    · obtain ⟨u,hu,one⟩ := List.mem_flatMap.mp (show e∈ws.flatMap GlobalWheelRank.wheel from h)
      exact same _ (wheelClean u (mem_states (legit _ hu)) e one)
  let F' := F.filter fun e => label G (src e)=q
  have sub : F'≤F := Multiset.filter_le _ _
  have rb : required.map src=required.map dst := balanced_representatives
  have whole : G.map src+{t}=G.map dst+{s} := by
    change (required+X).map src+{t}=(required+X).map dst+{s}
    rw [Multiset.map_add src required X,Multiset.map_add dst required X,rb,add_assoc,add_assoc,bal]
  obtain ⟨s',t',es,bag,route,_,_⟩ := component_route whole (src root)
  have reqFilter : required.filter (fun e => label G (src e)=q) = required :=
    Multiset.filter_eq_self.mpr (fun e he => conn e he root req)
  have keepFilter : K.filter (fun e => label G (src e)=q) = K := Multiset.filter_eq_self.mpr kept
  have eq : part G q=required+(K+F') := by
    change (required+(K+F)).filter (fun e => label G (src e)=q)=_
    rw [Multiset.filter_add,Multiset.filter_add,reqFilter,keepFilter]
  change (↑es : Multiset Block)=part G q at bag
  rw [eq] at bag
  have mem (e : Block) : e∈es ↔ e∈required+(K+F') := by
    change e∈(↑es : Multiset Block) ↔ _
    rw [bag]
  have wid (e : Block) (he : e∈K+F') : e.length=7 :=
    width e (Multiset.mem_of_le (add_le_add_right sub K) he)
  have nonempty : es≠[] := fun eq => by
    have live := (mem root).mpr (Multiset.mem_add.mpr (Or.inl req))
    simp [eq] at live
  refine ⟨F',sub,s',t',?_,wid,?_,?_⟩
  · apply startsSix route nonempty
    intro e he
    rcases Multiset.mem_add.mp ((mem _).mp he) with m|m
    · exact ((mem_reps e).mp (show e∈representatives from m)).1
    · exact wid _ m
  · have h := route.balance
    rw [bag,Multiset.map_add src required (K+F'),Multiset.map_add dst required (K+F'),rb,
      add_assoc (required.map dst) ((K+F').map src) {t'},
      add_assoc (required.map dst) ((K+F').map dst) {s'}] at h
    exact add_left_cancel h
  · intro S live closed e he
    exact (route.closed S live (fun f hf => closed f ((mem _).mp hf))).2 _ ((mem e).mpr he)

theorem trim_reference {ws : List Block} {F : Multiset Block} {s t : Block}
    (legit : ∀u∈ws,full u)
    (width : ∀ e∈(bag ResidualControls.mainWord+turns ws+F), e.length=7)
    (bal : (bag ResidualControls.mainWord+turns ws+F).map src+{t}=
      (bag ResidualControls.mainWord+turns ws+F).map dst+{s})
    (together : ClassesTogether (bag ResidualControls.mainWord+turns ws+F)) :
    ∃ F'≤F, ∃ s' t', Feasible (bag ResidualControls.mainWord+turns ws+F') s' t' :=
  trim (read_route _ (by native_decide : 6≤ResidualControls.mainWord.length))
    (by native_decide) legit width bal together

theorem exclude_sixty_five_classes {ws : List Block} {F : Multiset Block} {s t : Block}
    (many : 65≤ws.length) (legit : ∀u∈ws,full u)
    (budget : (bag ResidualControls.mainWord+turns ws+F).card≤858)
    (width : ∀ e∈(bag ResidualControls.mainWord+turns ws+F), e.length=7)
    (bal : (bag ResidualControls.mainWord+turns ws+F).map src+{t}=
      (bag ResidualControls.mainWord+turns ws+F).map dst+{s}) :
    ¬ ClassesTogether (bag ResidualControls.mainWord+turns ws+F) := by
  intro together
  obtain ⟨F',small,s',t',yes⟩ := trim_reference legit width bal together
  exact ReferenceSpineOptimum.excludes_5904 many legit
    ((Multiset.card_le_card (add_le_add_right small _)).trans budget) yes

/-- Dropping a literal self-loop preserves degree and reachability even when
it is the only occurrence of its edge label. -/
theorem drop_loop {A : Multiset Block} {e s t : Block} (loop : src e=dst e)
    (yes : Feasible (A+{e}) s t) : Feasible A s t := by
  apply Essential.delete_bypassed yes
  · simp [Essential.Balanced,loop]
  · intro f hf
    obtain rfl := Multiset.mem_singleton.mp hf
    rw [loop]

#print axioms trim_reference
#print axioms exclude_sixty_five_classes
#print axioms drop_loop
end ExactWordFlow.SpineWheelTrimming

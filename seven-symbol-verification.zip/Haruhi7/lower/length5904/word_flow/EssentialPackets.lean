import WordFlow
import LowerBounds.TheoremA

/-! A circulation in a minimum augmentation must connect two sides containing
mandatory support. The minimum is over submultisets at the same two endpoints. -/
namespace ExactWordFlow.Essential
open SevenWordWindows SuperpermutationBounds

abbrev Balanced (B : Multiset Block) := B.map src = B.map dst

def Closed (A : Multiset Block) (S : Set Block) : Prop :=
  ∀ e ∈ required + A, src e ∈ S → dst e ∈ S

def MandatoryCut (A : Multiset Block) (s t : Block) : Prop :=
  ∃ S : Set Block, s ∈ S ∧ t ∈ S ∧
    (∀ e ∈ required + A, src e ∈ S ↔ dst e ∈ S) ∧
    ∃ p ∈ required, src p ∉ S

theorem restBalance {A B : Multiset Block} {s t : Block}
    (h : Feasible (A+B) s t) (hb : Balanced B) : A.map src + {t} = A.map dst + {s} := by
  have eq := h.balance
  simp only [Multiset.map_add, hb] at eq
  exact add_right_cancel (b := B.map dst) (by simpa only [add_assoc, add_comm, add_left_comm] using eq)

/-- On a source-closed side containing the start, an open integer flow has
its end on the same side and has no incoming edge either. -/
theorem restrictBalance {A : Multiset Block} {s t : Block} {S : Set Block}
    (hs : s ∈ S) (bal : A.map src + {t} = A.map dst + {s})
    (closed : ∀ e ∈ A, src e ∈ S → dst e ∈ S) :
    t ∈ S ∧ (∀ e ∈ A, src e ∈ S ↔ dst e ∈ S) ∧
      ∃ Y ≤ A, (∀ e, e ∈ Y ↔ e ∈ A ∧ src e ∈ S) ∧ Y.map src + {t} = Y.map dst + {s} := by
  classical
  let F := A.filter fun e => src e ∈ S
  let G := A.filter fun e => dst e ∈ S
  have sub : F ≤ G := Multiset.le_filter.mpr ⟨Multiset.filter_le _ _,fun e he =>
    closed e (Multiset.mem_filter.mp he).1 (Multiset.mem_filter.mp he).2⟩
  have mono := Multiset.card_le_card sub
  have eq := congrArg (Multiset.filter fun v => v ∈ S) bal
  simp only [Multiset.filter_add,Multiset.filter_map,Multiset.filter_singleton,ite_eq_left hs] at eq
  change F.map src + (if t ∈ S then {t} else ∅) = G.map dst + {s} at eq
  have ht : t ∈ S := by
    by_contra hn
    have sizes := congrArg Multiset.card eq
    simp [hn] at sizes
    omega
  rw [ite_eq_left ht] at eq
  have sz := congrArg Multiset.card eq
  simp at sz
  have fg : F = G := Multiset.eq_of_le_of_card_le sub (by omega)
  have both (e) (he : e ∈ A) : src e ∈ S ↔ dst e ∈ S := by
    have same : e ∈ F ↔ e ∈ G := by rw [fg]
    simpa [F,G,he] using same
  exact ⟨ht,both,F,Multiset.filter_le _ _,fun _ => Multiset.mem_filter,fg ▸ eq⟩

/-- Delete components not needed for any mandatory edge. If every mandatory
source is in the root component, a submultiset already gives a feasible flow. -/
private theorem cut_or_feasible {A : Multiset Block} {s t : Block}
    (hs : s.length=6) (width : ∀ e∈A, e.length=7)
    (bal : A.map src + {t} = A.map dst + {s}) :
    MandatoryCut A s t ∨ ∃ Y ≤ A, Feasible Y s t := by
  classical
  let S : Set Block := {v | ∀ T : Set Block, s∈T → Closed A T → v∈T}
  have root : s∈S := fun _ h _ => h
  have closed : Closed A S := fun e he hu T ht hc => hc e he (hu T ht hc)
  have ac (e) (he : e∈A) := closed e (Multiset.mem_add.mpr (Or.inr he))
  obtain ⟨ht,both,Y,sub,yMem,yBal⟩ := restrictBalance root bal ac
  have rb : required.map src = required.map dst := balanced_representatives
  have closedRequired (e) (he : e∈required) := closed e (Multiset.mem_add.mpr (Or.inl he))
  obtain ⟨_,rboth,_⟩ := restrictBalance (t:=s) root (congrArg (· + {s}) rb) closedRequired
  by_cases covered : ∀ e∈required, src e∈S
  · right
    refine ⟨Y,sub,hs,fun e he => width e ((yMem e).mp he).1,yBal,?_⟩
    intro T start step e he
    have subClosed : Closed A (T ∩ S) := by
      intro a ha u
      have live : a ∈ required + Y := by
        rcases Multiset.mem_add.mp ha with hm | hm
        · exact Multiset.mem_add.mpr (Or.inl hm)
        · exact Multiset.mem_add.mpr (Or.inr ((yMem a).mpr ⟨hm,u.2⟩))
      exact ⟨step a live u.1,closed a ha u.2⟩
    have origin : src e ∈ S := by
      rcases Multiset.mem_add.mp he with h | h
      · exact covered e h
      · exact ((yMem e).mp h).2
    exact (origin (T ∩ S) ⟨start,root⟩ subClosed).1
  · left
    push Not at covered
    refine ⟨S,root,ht,?_,covered⟩
    intro e he
    exact (Multiset.mem_add.mp he).elim (rboth e) (both e)

/-- Same-endpoint minimality among submultisets. -/
def Minimal (X : Multiset Block) (s t : Block) :=
  ∀ Y ≤ X, Feasible Y s t → X.card ≤ Y.card

/-- A nonempty balanced packet deleted from a minimal augmentation leaves a
cut isolating a mandatory seven-permutation from both endpoints. -/
theorem separated_after_deletion {A B : Multiset Block} {s t : Block}
    (h : Feasible (A+B) s t) (smallest : Minimal (A+B) s t)
    (hb : Balanced B) (pos : 0 < B.card) : MandatoryCut A s t := by
  obtain cut | ⟨Y,sub,good⟩ := cut_or_feasible h.start_six
    (fun e he => h.edges_seven e (Multiset.mem_add.mpr (Or.inl he))) (restBalance h hb)
  · exact cut
  · have bound := smallest Y (sub.trans (le_self_add)) good
    have card := Multiset.card_le_card sub
    rw [Multiset.card_add] at bound
    omega

/-- Every feasible placement contains a same-endpoint minimum subplacement. -/
theorem exists_minimal {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    ∃ M ≤ X, Feasible M s t ∧ Minimal M s t := by
  classical
  let P (n : Nat) := ∃ Y ≤ X, Feasible Y s t ∧ Y.card=n
  have ex : ∃ n, P n := ⟨X.card,X,le_rfl,h,rfl⟩
  obtain ⟨M,sub,feas,size⟩ := Nat.find_spec ex
  refine ⟨M,sub,feas,?_⟩
  intro Y sub' good
  rw [size]
  exact Nat.find_min' ex ⟨Y,sub'.trans sub,good,rfl⟩

/-- All endpoint pairs are handled together. Any length-5904 witness gives a
reduced integer placement in which *every* balanced packet has a mandatory cut. -/
theorem necessary_858 {X : Multiset Block} {s t : Block} (size : X.card=858) (h : Feasible X s t) :
    ∃ M ≤ X, M.card ≤ 858 ∧ Feasible M s t ∧
      ∀ A B, M=A+B → Balanced B → 0<B.card → MandatoryCut A s t := by
  obtain ⟨M,sub,good,minimal⟩ := exists_minimal h
  refine ⟨M,sub,size ▸ Multiset.card_le_card sub,good,?_⟩
  intro A B eq hb pos
  subst M
  exact separated_after_deletion good minimal hb pos

/-! Quantitative version for every original placement, before passing to a minimum. -/

theorem separated_at_floor {A B : Multiset Block} {s t : Block} {floor : Nat}
    (h : Feasible (A+B) s t) (hb : Balanced B)
    (low : ∀ w : Word, Covers w → floor ≤ w.length) (short : A.card + 5046 < floor) :
    MandatoryCut A s t := by
  obtain cut | ⟨Y,sub,good⟩ := cut_or_feasible h.start_six
    (fun e he => h.edges_seven e (Multiset.mem_add.mpr (Or.inl he))) (restBalance h hb)
  · exact cut
  · obtain ⟨w,cover,size⟩ := (word_iff_flow (Y.card + 5046) (by omega)).mpr
      ⟨Y,s,t,by omega,good⟩
    have lower := low w cover
    have c := Multiset.card_le_card sub
    omega

/-- Even without the expensive numerical searches in `PFinalK16Native`, the
kernel-checked Kisic bound forces every balanced deletion of length at least
12 to isolate a prescribed permutation in *every* exact-858 placement. -/
theorem twelve_separate {A B : Multiset Block} {s t : Block}
    (h : Feasible (A+B) s t) (size : (A+B).card=858) (hb : Balanced B) (large : 12≤B.card) :
    MandatoryCut A s t := by
  apply separated_at_floor h hb (floor:=5893)
  · intro w hw
    exact SuperpermLowerBounds.superperm_kisic_numerical_bounds.2.2.1.trans
      (SuperpermBridge.ssuper_le_length hw)
  · rw [Multiset.card_add] at size
    omega

/-- If all deleted edges remain represented, both sides of a mandatory cut
are closed for the *original* placement. Original feasibility forbids this. -/
theorem represented_no_cut {A B : Multiset Block} {s t : Block}
    (h : Feasible (A+B) s t) (present : ∀ e∈B, e∈required+A) : ¬MandatoryCut A s t := by
  rintro ⟨S,root,_,internal,p,hp,miss⟩
  apply miss
  apply h.reachable S root _ p (Multiset.mem_add.mpr (Or.inl hp))
  intro e he
  have mem : e∈required+A := by
    rcases Multiset.mem_add.mp he with r | ab
    · exact Multiset.mem_add.mpr (Or.inl r)
    · rcases Multiset.mem_add.mp ab with a | b
      · exact Multiset.mem_add.mpr (Or.inr a)
      · exact present e b
  exact (internal e mem).mp

/-- At most 11 units in total can be removed as a balanced multiset supported
on the other edges. In a minimum even one positive unit is impossible. -/
theorem redundant_at_most_eleven {A B : Multiset Block} {s t : Block}
    (h : Feasible (A+B) s t) (size : (A+B).card=858) (hb : Balanced B)
    (present : ∀ e∈B, e∈required+A) : B.card ≤ 11 := by
  by_contra! large
  exact represented_no_cut h present (twelve_separate h size hb large)

/-- One turn of the ordinary six-wheel through an ordered six-tuple. -/
def turn6 (a b c d e f : Fin 7) : Multiset Block :=
  ↑[[a,b,c,d,e,f,a],[b,c,d,e,f,a,b],[c,d,e,f,a,b,c],
    [d,e,f,a,b,c,d],[e,f,a,b,c,d,e],[f,a,b,c,d,e,f]]

theorem turn6_size (a b c d e f : Fin 7) : (turn6 a b c d e f).card=6 := rfl

theorem turn6_balance (a b c d e f : Fin 7) : Balanced (turn6 a b c d e f) := by
  let xs : List Block := [[b,c,d,e,f,a],[c,d,e,f,a,b],[d,e,f,a,b,c],
    [e,f,a,b,c,d],[f,a,b,c,d,e]]
  change (↑([a,b,c,d,e,f] :: xs) : Multiset Block) = ↑(xs ++ [[a,b,c,d,e,f]])
  exact Quot.sound (List.perm_append_singleton [a,b,c,d,e,f] xs).symm

/-- No two six-turns can both have all their edges represented after deletion.
The turns may belong to distinct wheels or to the same wheel. -/
theorem no_two_redundant_turns {A W V : Multiset Block} {s t : Block}
    (h : Feasible (A+(W+V)) s t) (size : (A+(W+V)).card=858)
    (w : ∃ a b c d e f, W=turn6 a b c d e f)
    (v : ∃ a b c d e f, V=turn6 a b c d e f)
    (present : ∀ e∈W+V, e∈required+A) : False := by
  rcases w with ⟨a,b,c,d,e,f,rfl⟩
  rcases v with ⟨i,j,k,l,m,n,rfl⟩
  have hb : Balanced (turn6 a b c d e f + turn6 i j k l m n) := by
    simp only [Balanced,Multiset.map_add,turn6_balance a b c d e f,turn6_balance i j k l m n]
  have small := redundant_at_most_eleven h size hb present
  simp [turn6_size] at small

/-- All seven extra copies of one required rotation class. -/
def orbit7 (p : Block) : Multiset Block := ↑((List.range 7).map (fun i => p.rotate i))

theorem orbit7_size (p : Block) : (orbit7 p).card=7 := by simp [orbit7]

theorem orbit7_required {p : Block} (mem : p ∈ required) : ∀ e∈orbit7 p, e∈required := by
  intro e he
  obtain ⟨i,_,rfl⟩ := List.mem_map.mp (show e∈(List.range 7).map (fun i => p.rotate i) from he)
  have hp := (mem_reps p).mp (show p∈representatives from mem)
  exact (mem_reps _).mpr ⟨by simpa using hp.1,(p.rotate_perm i).nodup_iff.mpr hp.2⟩

theorem orbit7_balance {p : Block} (hp : p.length=7) : Balanced (orbit7 p) := by
  let v (i : Nat) := src (p.rotate i)
  have ds (i : Nat) : dst (p.rotate i) = v (i+1) := by
    let q := p.rotate i
    have ql : q.length=7 := by simp [q,hp]
    have twice : q.rotate 1=p.rotate (i+1) := List.rotate_rotate ..
    change q.drop 1=(p.rotate (i+1)).take 6
    rw [←twice, List.rotate_eq_drop_append_take (by omega : 1 ≤ q.length)]
    have six : (q.drop 1).length=6 := by simp [ql]
    rw [←six, List.take_left]
  have close : v 7 = v 0 := by
    dsimp [v]
    have ends : p.rotate 7=p := by simpa only [hp] using p.rotate_length
    rw [ends,List.rotate_zero]
  have dsts : (List.range 7).map (fun i => dst (p.rotate i)) = (List.range 7).map (fun i => v (i+1)) := by
    exact List.map_congr_left fun i _ => ds i
  change ((↑((List.range 7).map (fun i => p.rotate i)) : Multiset Block).map src) = _
  unfold orbit7
  rw [Multiset.map_coe,Multiset.map_coe,List.map_map,List.map_map]
  change (↑((List.range 7).map v) : Multiset Block) = ↑((List.range 7).map (fun i => dst (p.rotate i)))
  rw [dsts]
  change (↑[v 0,v 1,v 2,v 3,v 4,v 5,v 6] : Multiset Block) = ↑[v 1,v 2,v 3,v 4,v 5,v 6,v 7]
  rw [close]
  exact Quot.sound (List.perm_append_singleton (v 0) [v 1,v 2,v 3,v 4,v 5,v 6]).symm

/-- In an endpoint-preserving minimum no rotation class can appear twice in
its entirety: deleting the duplicate copies retains all mandatory edges. -/
theorem no_duplicate_orbit_in_minimum {A : Multiset Block} {s t p : Block}
    (mem : p∈required) (h : Feasible (A+orbit7 p) s t) (smallest : Minimal (A+orbit7 p) s t) : False := by
  have hp := (mem_reps p).mp (show p∈representatives from mem)
  have cut := separated_after_deletion h smallest (orbit7_balance hp.1) (by rw [orbit7_size]; decide)
  exact represented_no_cut h (fun e he => Multiset.mem_add.mpr (Or.inl (orbit7_required mem e he))) cut

end ExactWordFlow.Essential
#print axioms ExactWordFlow.Essential.necessary_858

#print axioms ExactWordFlow.Essential.no_two_redundant_turns

#print axioms ExactWordFlow.Essential.no_duplicate_orbit_in_minimum

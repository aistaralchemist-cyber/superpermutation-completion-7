import NinetyFive
import WheelContacts

namespace ExactWordFlow.DeepBridgeComponents
open SevenWordWindows ResidualDensity RotationComponentCount ResidualRoutes

/-- Physical wheel name of a six-context.  Repeated-letter contexts
belong to no ordinary six-wheel. -/
def wheelKey (u : Block) : Block :=
  if full u then ((List.range 6).map (fun i=>u.rotate i)).min?.getD [] else []

private theorem wheel_data : ∀w∈WheelContacts.bases,
    wheelKey w=w ∧ w≠[] ∧ ∃e∈GlobalWheelRank.wheel w,src e=w := by native_decide

private theorem wheel_edges : ∀w∈WheelContacts.bases,∀e∈GlobalWheelRank.wheel w,
    wheelKey (src e)=w ∧ wheelKey (dst e)=w := by native_decide

/-- The first and last interior six-contexts can only have the physical
wheel name of an endpoint or the name of the skipped rotation next to it. -/
theorem boundary_geometry : ∀p∈representatives,∀a : Fin 7,
    let v:=p.tail.tail++[a]
    let u:=a::p.take 5
    (wheelKey v=[] ∨ wheelKey v=wheelKey p.tail ∨
      (a=p[0]?.getD 0 ∧ wheelKey v=wheelKey (p.rotate 1).tail)) ∧
    (wheelKey u=[] ∨ wheelKey u=wheelKey (p.take 6) ∨
      (a=p[6]?.getD 0 ∧ wheelKey u=wheelKey (p.rotate 5).tail)) := by native_decide

/-- Any ordinary wheel which can touch only wheels, within its own physical
six-orbit, is an entire occupied nonroot component of the residual word
graph.  Other occupied components may also use unmarked exceptional edges. -/
theorem isolated_limit {X : Multiset Block} {s t : Block} (flow : Feasible X s t)
    (budget : X.card≤858) (W : Finset Block) (legal : ∀w∈W,w∈WheelContacts.bases)
    (present : ∀w∈W,∀e∈GlobalWheelRank.wheel w,e∈X) (away : wheelKey s∉W)
    (D : Finset Block) (isolated : ∀w∈W,w∉D → ∀e∈X,
        wheelKey (src e)=w ↔ wheelKey (dst e)=w) : W.card ≤ 95+D.card := by
  classical
  let clear:=W \ D
  have incl : clear.image (label X) ⊆ occupied X s := by
    intro z hz
    obtain ⟨w,wm,rfl⟩:=Finset.mem_image.mp hz
    obtain ⟨hw,off⟩:=Finset.mem_sdiff.mp wm
    obtain ⟨key,_,e,elem,origin⟩:=wheel_data w (legal w hw)
    have used:=present w hw e elem
    have sep : label X w≠label X s := by
      intro same
      have m:=(invariant (fun v=>wheelKey v=w) (isolated w hw off) same).mp key
      exact away (m ▸ hw)
    exact Finset.mem_erase.mpr ⟨sep,Finset.mem_image.mpr
      ⟨w,Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,used,origin⟩),rfl⟩⟩
  have unique : Set.InjOn (label X) (clear : Set Block) := by
    intro a ha b hb eq
    obtain ⟨hA,nA⟩:=Finset.mem_sdiff.mp ha
    obtain ⟨hB,_⟩:=Finset.mem_sdiff.mp hb
    have k:=(wheel_data a (legal a hA)).1
    have bkey:=(invariant (fun v=>wheelKey v=a) (isolated a hA nA) eq).mp k
    change wheelKey b=a at bkey
    rw [(wheel_data b (legal b hB)).1] at bkey
    exact bkey.symm
  have ct:=Finset.card_le_card incl
  rw [Finset.card_image_of_injOn unique] at ct
  have bound:=NinetyFive.component_limit flow budget
  have eq:=Finset.card_sdiff_add_card_inter W D
  have inter:=Finset.card_le_card (Finset.inter_subset_right (s₁:=W) (s₂:=D))
  change (W\D).card≤_ at ct
  omega

/-- For an actual collection of exceptional bridge contexts, only positions
at least two from each endpoint can touch an ordinary wheel.  A paid
d-letter transition has d six-contexts between its selected windows. -/
def interior (v : List Block) := (v.drop 2).take (v.length-4)

theorem bridge_limit {X : Multiset Block} {s t : Block} (flow : Feasible X s t)
    (budget : X.card≤858) (W : Finset Block) (legal : ∀w∈W,w∈WheelContacts.bases)
    (present : ∀w∈W,∀e∈GlobalWheelRank.wheel w,e∈X) (away : wheelKey s∉W)
    (bridges : List (List Block))
    (decompose : ∀e∈X,(∃w∈W,e∈GlobalWheelRank.wheel w) ∨
      ∃v∈bridges,src e∈v ∧ dst e∈v)
    (boundary : ∀v∈bridges,∀u∈v,wheelKey u∈W → u∈interior v) :
    W.card ≤ 95+(bridges.map (fun v=>v.length-4)).sum := by
  let points:=bridges.flatMap interior
  let D:=(points.map wheelKey).toFinset
  have unreachable (w : Block) (mem : w∈W) (off : w∉D) (v) (h : v∈bridges) (u) (hu : u∈v) :
      wheelKey u≠w := by
    intro eq
    have core:=boundary v h u hu (eq ▸ mem)
    exact off (List.mem_toFinset.mpr (List.mem_map.mpr ⟨u,List.mem_flatMap.mpr ⟨v,h,core⟩,eq⟩))
  have result:=isolated_limit flow budget W legal present away D (by
    intro w mem off e he
    rcases decompose e he with ⟨v,hv,inV⟩|⟨v,h,hs,ht⟩
    · obtain ⟨a,b⟩:=wheel_edges v (legal v hv) e inV
      rw [a,b]
    · simp [unreachable w mem off v h _ hs,unreachable w mem off v h _ ht])
  have size : D.card ≤ points.length := by
    simpa [D] using (List.toFinset_card_le (points.map wheelKey))
  have bill (bs : List (List Block)) : (bs.flatMap interior).length≤(bs.map (fun v=>v.length-4)).sum := by
    induction bs with
    | nil => simp
    | cons v vs ih =>
      simp only [List.flatMap_cons,List.length_append,List.map_cons,List.sum_cons] at *
      have len : (interior v).length≤v.length-4 := by simp [interior]
      exact Nat.add_le_add len ih
  have size2 := bill bridges
  change points.length≤_ at size2
  omega

#print axioms boundary_geometry
#print axioms bridge_limit
end ExactWordFlow.DeepBridgeComponents

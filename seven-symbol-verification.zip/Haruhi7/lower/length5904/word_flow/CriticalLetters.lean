import Mathlib
import Challenge

namespace SevenCriticalLetters
open SuperpermutationBounds
abbrev Word := List (Fin 7)

private theorem at_middle {w p u v : Word} (h : w=u++p++v) {j : Nat}
    (left : u.length≤j) (right : j<u.length+p.length) (bound : j<w.length) :
    w[j] = p[j-u.length]'(by omega) := by
  subst w
  rw [List.getElem_append_left (by simp; omega),List.getElem_append_right left]

/-- Two equal permutation windows containing the same letter position
must have the same start. The repeated first symbol would violate Nodup. -/
theorem same_start {w p u v x y : Word} {i : Nat} (nodup : p.Nodup)
    (first : w=u++p++v) (other : w=x++p++y)
    (cross1 : u.length ≤ i ∧ i<u.length+p.length)
    (cross2 : x.length ≤ i ∧ i<x.length+p.length) : u.length=x.length := by
  have earlier (a b c d : Word) (ab : w=a++p++b) (cd : w=c++p++d)
      (lt : a.length<c.length) (hi : c.length<a.length+p.length) : False := by
    have lp := congrArg List.length cd
    simp only [List.length_append] at lp
    have lim : c.length<w.length := by omega
    have one := at_middle ab (j:=c.length) (by omega) hi lim
    have two := at_middle cd (j:=c.length) (by omega) (by omega) lim
    have e := nodup.eq_of_getElem_eq (show c.length-a.length<p.length by omega)
      (show c.length-c.length<p.length by omega) (one.symm.trans two)
    omega
  rcases lt_trichotomy u.length x.length with a|a|a
  · exact False.elim (earlier u v x y first other a (by omega))
  · exact a
  · exact False.elim (earlier x y u v other first a (by omega))

/-- Every indispensable letter lies in a permutation window having a unique
start in the entire word. This applies to every position of any shortest word. -/
theorem critical_unique {w : Word} (hw : Covers w) (i : Nat)
    (critical : ¬ Covers (w.eraseIdx i)) :
    ∃ p u v : Word, p.length=7 ∧ p.Nodup ∧ w=u++p++v ∧
      u.length ≤ i ∧ i<u.length+7 ∧
      ∀ x y : Word, w=x++p++y → x.length=u.length := by
  unfold Covers at critical
  push Not at critical
  obtain ⟨p,lp,np,absent⟩ := critical
  obtain ⟨u,v,first⟩ := hw p lp np
  have cuts (a b : Word) (h : w=a++p++b) : a.length ≤ i ∧ i<a.length+p.length := by
    constructor
    · by_contra! before
      specialize absent (a.eraseIdx i) b
      apply absent
      rw [h,List.append_assoc,List.eraseIdx_append_of_lt_length before,List.append_assoc]
    · by_contra! after
      specialize absent a (b.eraseIdx (i-(a++p).length))
      apply absent
      rw [h,List.eraseIdx_append_of_length_le (by simpa using after)]
  obtain ⟨hl,hr⟩ := cuts u v first
  refine ⟨p,u,v,lp,np,first,hl,by omega,?_⟩
  intro x y other
  exact same_start np other first (cuts x y other) (cuts u v first)

theorem shortest_unique {w : Word} (hw : Covers w)
    (minimal : ∀ v : Word, Covers v → w.length≤v.length) (i : Nat) (hi : i<w.length) :
    ∃ p u v : Word, p.length=7 ∧ p.Nodup ∧ w=u++p++v ∧
      u.length ≤ i ∧ i<u.length+7 ∧
      ∀ x y : Word, w=x++p++y → x.length=u.length := by
  apply critical_unique hw
  intro still
  have smaller := List.length_eraseIdx_of_lt hi
  have lo := minimal _ still
  omega

end SevenCriticalLetters
#print axioms SevenCriticalLetters.shortest_unique

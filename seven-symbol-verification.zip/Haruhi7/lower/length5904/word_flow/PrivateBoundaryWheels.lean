import WheelMinimumBoundary

namespace ExactWordFlow.WheelFreeBoundary
open SevenWordWindows RotationCore ResidualDensity LiteralWheelCover

/-- In any actual insertion history that ends in a boundary candidate,
the wheel rows are different and each owns a tag outside the starting word. -/
theorem actual_rows {b v : Block} {rs : List Row} (history : Inserts b rs v)
    (limit : v.length≤1508) (hit : (visited v).card=720) (done : (complete v).card=92) :
    rs.Nodup ∧ ∀R∈rs,∃c∈allClasses \ visited b,c∈R ∧ c∉(rs.toFinset.erase R).biUnion id := by
  have baseDone : (complete b).card=92:=history.complete_eq ▸ done
  have size := history.length_eq
  have entire:=Finset.eq_of_subset_of_card_le (visited_subset v) (by rw [board,hit])
  have covered : allClasses \ visited b⊆rs.toFinset.biUnion id := by
    intro c hc
    obtain ⟨legal,old⟩:=Finset.mem_sdiff.mp hc
    have yes : c∈visited v := entire ▸ legal
    rw [history.visited_eq] at yes
    exact (Finset.mem_union.mp yes).resolve_left old
  have option : condition b rs.toFinset.card:=⟨rs.toFinset,history.rows_ready,le_rfl,covered⟩
  have count : rs.toFinset.card=rs.length := by
    have hi:=List.toFinset_card_le rs
    by_contra! diff
    exact no_cheaper baseDone (by omega : b.length+6*rs.length≤1508) (by omega) option
  have simple := Multiset.toFinset_card_eq_card_iff_nodup.mp
    (show (↑rs : Multiset Row).toFinset.card=(↑rs : Multiset Row).card from count)
  exact ⟨simple,fun R hr=>private_target baseDone (by omega : b.length+6*rs.length≤1508)
    history.rows_ready count.le covered (List.mem_toFinset.mpr hr)⟩

/-- This concrete forbidden substring follows for all 1,508-letter candidates. -/
theorem no_triple {v : Block} (limit : v.length≤1508) (hit : (visited v).card=720)
    (done : (complete v).card=92) (l u r : Block) (hu : full u) : v≠l++u++u++u++r := by
  rintro rfl
  have second : Inserts (l++u++u++r) [WheelContacts.wheel u] (l++u++u++u++r) := by
    simpa only [List.append_assoc] using
      (Inserts.add (l:=l++u) (r:=r) hu (Inserts.stop ((l++u)++u++u++r)))
  have both:=Inserts.add (l:=l) (r:=r) hu second
  simpa using (actual_rows both limit hit done).1

#print axioms no_triple
end ExactWordFlow.WheelFreeBoundary

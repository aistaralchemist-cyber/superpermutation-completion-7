import PlanarIncidence
import SevenMoves

namespace ExactWordFlow.SevenPlanarTour
open Equiv PlanarIncidence SevenMoves

private noncomputable def cycleTag (h : Perm X) (x:X) : X ⊕ Perm X :=
  if h x=x then Sum.inl x else Sum.inr (h.cycleOf x)

private theorem cycle_step (h : Perm X) (x:X) : cycleTag h (h x)=cycleTag h x := by
  by_cases fix:h x=x
  · rw [fix]
  · have no:h (h x)≠h x:=fun eq=>fix (h.injective eq)
    simp [cycleTag,fix,no,Perm.cycleOf_self_apply]

private theorem counts (h : Perm X) :
    (Finset.univ.image (cycleTag h)).card+h.support.card=5040+h.cycleType.card := by
  classical
  have labeling : Finset.univ.image (cycleTag h)=(Finset.univ\h.support).disjSum h.cycleFactorsFinset := by
    ext v
    constructor
    · intro hv
      obtain ⟨x,_,rfl⟩:=Finset.mem_image.mp hv
      by_cases yes : h x=x
      · simp [cycleTag,yes]
      · simpa [cycleTag,yes] using Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr (Perm.mem_support.mpr yes)
    · intro hv
      cases v with
      | inl x =>
        have fixed:=Perm.notMem_support.mp (Finset.mem_sdiff.mp (Finset.inl_mem_disjSum.mp hv)).2
        exact Finset.mem_image.mpr ⟨x,Finset.mem_univ _,by simp [cycleTag,fixed]⟩
      | inr c =>
        have mem:=Finset.inr_mem_disjSum.mp hv
        obtain ⟨x,hx⟩:=(Perm.mem_cycleFactorsFinset_iff.mp mem).1.nonempty_support
        have diff:h x≠x:=by rw [←(Perm.mem_cycleFactorsFinset_iff.mp mem).2 _ hx]; exact Perm.mem_support.mp hx
        exact Finset.mem_image.mpr ⟨x,Finset.mem_univ _,by
          simp [cycleTag,diff,(h.eq_cycleOf_of_mem_cycleFactorsFinset_iff c mem x).mpr hx]⟩
  have n:=Finset.card_sdiff_add_card_eq_card (Finset.subset_univ h.support)
  rw [Finset.card_univ,sizeX] at n
  rw [labeling,Finset.card_disjSum]
  have k:h.cycleType.card=h.cycleFactorsFinset.card:=by simp [Perm.cycleType_def]
  omega

/-- At zero incidence surplus, connectedness of the rotation/correction
incidence graph is necessary and sufficient for an actual single tour.
The statement also allows several exceptional correction cycles. -/
theorem planar_iff (h : Perm X) (start : X)
    (zero : h.support.card=h.cycleType.card+719) :
    Connected R h ↔ ∀y,(R*h).SameCycle start y := by
  constructor
  · intro conn
    have im : Finset.univ.image tag=Finset.univ:=Finset.eq_univ_of_forall (fun y=>by
      obtain ⟨x,rfl⟩:=tag_surj y
      exact Finset.mem_image_of_mem _ (Finset.mem_univ _))
    have n:=counts h
    apply tree_orbit R h tag (cycleTag h) tag_rot (cycle_step h) _ conn start
    rw [im,Finset.card_univ,sizeY,sizeX]
    omega
  · intro full C left right x y hx
    obtain ⟨n,_,eq⟩:=((full x).symm.trans (full y)).exists_pow_eq'
    have step (k:Nat) : C (((R*h)^k) x):=by
      induction k with
      | zero => simpa using hx
      | succ k ih => rw [pow_succ',Perm.mul_apply,Perm.mul_apply,left,right]; exact ih
    exact eq ▸ step n

#print axioms planar_iff
end ExactWordFlow.SevenPlanarTour

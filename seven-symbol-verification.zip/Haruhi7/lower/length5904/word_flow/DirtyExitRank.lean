import RauzyBudget

namespace ExactWordFlow.DirtyExitRank
open SevenWordWindows DirectedEuler RotationReinsert RotationCore CompleteCycleRank

/-- The distinct observed factors with a repeated letter in their source. -/
def dirtyEdges (w : Block) := (windows w).toFinset.filter (fun e => ¬(src e).Nodup)

/-- Sum of the extra distinct exits, one free exit per dirty source that has an exit. -/
def forks (w : Block) := (dirtyEdges w).card - ((dirtyEdges w).image src).card

private theorem levels {s t : Block} {xs : List Block} (walk : Route src dst s xs t) :
    ∃h : Block→Nat, ∀x∈s::xs.map dst,x≠t →
        ∃e∈xs,src e=x ∧ h (dst e)<h x := by
  classical
  induction walk with
  | nil s =>
    refine ⟨fun _ => 0,?_⟩
    intro x hx ne
    exact (ne (by simpa using hx)).elim
  | @cons u t xs e source tail ih =>
    obtain ⟨h,lower⟩:=ih
    let old:=dst e::xs.map dst
    by_cases oldU : u∈old
    · refine ⟨h,?_⟩
      intro x hx ne
      have mem : x∈old := by
        rcases List.mem_cons.mp hx with rfl|later
        · exact oldU
        · exact later
      obtain ⟨f,hf,fs,lt⟩:=lower x mem ne
      exact ⟨f,List.mem_cons_of_mem _ hf,fs,lt⟩
    · let g (x : Block) := if x=u then h (dst e)+1 else h x
      refine ⟨g,?_⟩
      intro x hx ne
      by_cases eq : x=u
      · subst x
        have away : dst e≠u := by
          intro same
          exact oldU (same ▸ List.mem_cons_self ..)
        exact ⟨e,List.mem_cons_self ..,source,by simp [g,away]⟩
      · have mem : x∈old := (List.mem_cons.mp hx).resolve_left eq
        obtain ⟨f,hf,fs,lt⟩ := lower x mem ne
        have away : dst f≠u := by
          intro same
          have seen : dst f∈old := List.mem_cons_of_mem _ (List.mem_map_of_mem hf)
          exact oldU (same ▸ seen)
        exact ⟨f,List.mem_cons_of_mem _ hf,fs,by simpa [g,away,eq] using lt⟩

private theorem count {ι : Type*} [DecidableEq ι] {w : Block} (long : 6≤w.length)
    (J : Finset ι) (E : ι→Finset Block)
    (available : ∀i∈J,E i⊆(windows w).toFinset)
    (positive : ∀i∈J,(E i).Nonempty)
    (closed : ∀i∈J,(E i).image dst⊆(E i).image src)
    (clean : ∀i∈J,∀e∈E i,(src e).Nodup)
    (apart : (↑J : Set ι).PairwiseDisjoint E) :
    d6 w + J.card + forks w ≤ d7 w+1 := by
  classical
  obtain ⟨h,lower⟩:=levels (read_route w long)
  let F:=(windows w).toFinset
  let A:=dirtyEdges w
  let G:=F.filter (fun e=>(src e).Nodup ∧ h (dst e)<h (src e))
  let K:=F \ (A∪G)
  let t:=w.drop (w.length-6)
  have cover : (anchors w).toFinset ⊆ insert t (A.image src ∪ G.image src) := by
    intro v hv
    by_cases last : v=t
    · simp [last]
    obtain ⟨e,he,ve,lt⟩:=lower v (List.mem_toFinset.mp hv) last
    have occ : e∈F := List.mem_toFinset.mpr he
    by_cases ok : (src e).Nodup
    · have hit : e∈G := Finset.mem_filter.mpr ⟨occ,ok,ve ▸ lt⟩
      exact Finset.mem_insert_of_mem (Finset.mem_union_right _ (ve ▸ Finset.mem_image_of_mem src hit))
    · have hit : e∈A := Finset.mem_filter.mpr ⟨occ,ok⟩
      exact Finset.mem_insert_of_mem (Finset.mem_union_left _ (ve ▸ Finset.mem_image_of_mem src hit))
  have baseline : d6 w ≤ (A.image src).card+G.card+1 :=
    (Finset.card_le_card cover).trans ((Finset.card_insert_le ..).trans
      (Nat.add_le_add_right ((Finset.card_union_le ..).trans (Nat.add_le_add_left Finset.card_image_le _)) 1))
  have missing (i) (hi : i∈J) : ∃e∈E i, e∈K := by
    obtain ⟨e,he,least⟩:=(E i).exists_min_image (fun f=>h (src f)) (positive i hi)
    have right := closed i hi (Finset.mem_image_of_mem dst he)
    obtain ⟨f,hf,fe⟩:=Finset.mem_image.mp right
    have grows := least f hf
    rw [fe] at grows
    refine ⟨e,he,Finset.mem_sdiff.mpr ⟨available i hi he,?_⟩⟩
    intro used
    rcases Finset.mem_union.mp used with dirty|fall
    · exact (Finset.mem_filter.mp dirty).2 (clean i hi e he)
    · exact (Nat.not_lt_of_ge grows) (Finset.mem_filter.mp fall).2.2
  let witness (i : ι) := if hi : i∈J then (missing i hi).choose else []
  have own {i : ι} (hi : i∈J) : witness i∈E i ∧ witness i∈K := by
    simpa [witness,hi] using (missing i hi).choose_spec
  have many : J.card≤K.card := Finset.card_le_card_of_injOn witness
    (fun _ hi=>(own hi).2) (by
      intro i hi j hj eq
      by_contra distinct
      exact (Finset.disjoint_left.mp (apart hi hj distinct)) (own hi).1 (eq ▸ (own hj).1))
  have sep : Disjoint A G := Finset.disjoint_left.mpr (fun {_} ha hg =>
    (Finset.mem_filter.mp ha).2 (Finset.mem_filter.mp hg).2.1)
  have sub : A∪G⊆F := Finset.union_subset (Finset.filter_subset ..) (Finset.filter_subset ..)
  have parts:=Finset.card_sdiff_add_card_eq_card sub
  change K.card+(A∪G).card=F.card at parts
  rw [Finset.card_union_of_disjoint sep] at parts
  have subA : (A.image src).card ≤ A.card := Finset.card_image_le
  change d6 w + J.card + (A.card-(A.image src).card) ≤ F.card+1
  omega

open private owner permutation_geometry wheel_geometry from CompleteCycleRank

private theorem cleanPerm : ∀c∈allClasses,∀e∈fibre c,(src e).Nodup := by native_decide
private theorem cleanWheel : ∀q∈WheelContacts.bases,∀e∈wheelFactors q,(src e).Nodup := by native_decide

/-- Dirty outgoing choices and fully visited clean cycles demand disjoint
edges outside a last-exit tree. The result applies at arbitrary endpoints. -/
theorem word_forks_le (w : Block) (long : 6≤w.length) : forks w≤RauzyBudget.otherRank w := by
  classical
  let J := (complete w).disjSum (completeWheels w)
  let E : Block ⊕ Block → Finset Block := Sum.elim fibre wheelFactors
  have geom (i) (hi : i∈J) : E i⊆(windows w).toFinset ∧ (E i).Nonempty ∧
      (E i).image dst⊆(E i).image src ∧ ∀e∈E i,owner e=i ∧ (src e).Nodup := by
    cases i with
    | inl c =>
      have mem : c∈complete w := by simpa [J] using hi
      obtain ⟨a,all⟩:=(mem_complete w c).mp mem
      obtain ⟨pos,cl,tag⟩:=permutation_geometry c a
      refine ⟨?_,pos,cl,fun e he=>⟨tag _ he,cleanPerm _ a _ he⟩⟩
      intro e he
      obtain ⟨legal,key⟩:=Finset.mem_filter.mp (show e∈fibre c from he)
      exact List.mem_toFinset.mpr (all e (List.mem_toFinset.mp legal) key)
    | inr q =>
      have mem : q∈completeWheels w := by simpa [J] using hi
      obtain ⟨base,all⟩:=Finset.mem_filter.mp mem
      have yes:=List.mem_toFinset.mp base
      obtain ⟨pos,cl,tag⟩:=wheel_geometry q yes
      exact ⟨all,pos,cl,fun e he=>⟨tag _ he,cleanWheel _ yes _ he⟩⟩
  have bound:=count long J E (fun i hi=>(geom i hi).1) (fun i hi=>(geom i hi).2.1)
    (fun i hi=>(geom i hi).2.2.1) (fun i hi e he=>((geom i hi).2.2.2 e he).2)
    (by
      intro i hi j hj diff
      exact Finset.disjoint_left.mpr (fun {e} ei ej =>
        diff (((geom i hi).2.2.2 e ei).1.symm.trans ((geom j hj).2.2.2 e ej).1)))
  simp only [J,Finset.card_disjSum] at bound
  change forks w ≤ (d7 w+1)-(d6 w+(complete w).card+(completeWheels w).card)
  omega

/-- Observable charge that dispenses with the computation of a cycle basis. -/
def localCost (w : Block) := RauzyBudget.extraContexts w + RauzyBudget.wheels w +
  RauzyBudget.repeats w + forks w

theorem local_le (w : Block) (long : 6≤w.length) : localCost w≤RauzyBudget.defect w := by
  exact Nat.add_le_add_left (word_forks_le w long) _

/-- A sufficient global proof route. The price-140 premise is left open. -/
theorem sufficient (charge : ∀w : Block,6≤w.length → (visited w).card=720 → 140≤localCost w) :
    ¬∃w : Block,SuperpermutationBounds.Covers w ∧ w.length≤5904 := by
  exact RauzyBudget.criterion.mp (fun w long hit => (charge w long hit).trans (local_le w long))

#print axioms word_forks_le
#print axioms sufficient
end ExactWordFlow.DirtyExitRank

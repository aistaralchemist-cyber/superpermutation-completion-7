import SingletonOrder
import PathWheelCover

namespace ExactWordFlow.SingletonOrder
open DirectedEuler EmbeddedWheels OnePath66 ResidualDensity SevenWordWindows SeedWheelCut

def fixedWheels := ResidualControls.wheelWords.map (·.take 6)

private theorem wheel_table : fixedWheels.length=66 ∧
    (∀u∈fixedWheels, full u) ∧ (wheelSets fixedWheels).biUnion id=wheelLabels ∧
    turns fixedWheels=↑(ResidualControls.wheelWords.flatMap windows) := by native_decide

private theorem uncovered_in_seed {A V : Finset Block} {W : Finset (Finset Block)}
    (cover : ClosedCover A V W) : V\W.biUnion id ⊆ A := by
  have result := cover (A∪W.biUnion id) Finset.subset_union_left
    (fun z hz _ c hc => Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨z,hz,hc⟩))
  intro c hc
  obtain ⟨target,missing⟩ := Finset.mem_sdiff.mp hc
  exact (Finset.mem_union.mp (result target)).resolve_right missing

/-- Every length-462 backbone completing the reference 66 wheels must visit
all 380 singleton classes, but no selection of visits can follow either
191-class subsequence of the reference word. -/
theorem reference_reordering_needed {w s t : Block} (len : (windows w).length=462)
    (h : Feasible ((↑(windows w) : Multiset Block)+↑(ResidualControls.wheelWords.flatMap windows)) s t) :
    order.toFinset ⊆ pathClasses (w.take 6) (windows w) ∧
    ¬VisitsFrom w (alternate 0) 0 ∧ ¬VisitsFrom w (alternate 1) 0 := by
  have n := windows_length w
  obtain ⟨count,legal,labels,edges⟩ := wheel_table
  have linked := cover_462_66 (read_route w (by omega)) len count legal (edges ▸ h)
  have mandatory := uncovered_in_seed linked
  rw [labels, counts.2.2.1] at mandatory
  exact ⟨mandatory,(fun p => by have := either_suborder_floor (Or.inl p); omega),
    (fun p => by have := either_suborder_floor (Or.inr p); omega)⟩

#print axioms reference_reordering_needed
end ExactWordFlow.SingletonOrder

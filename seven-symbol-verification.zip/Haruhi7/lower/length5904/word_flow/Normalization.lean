import CompactCounterexample

namespace ExactWordFlow.CandidateRenaming
open SevenWordWindows RotationCore RotationReinsert ResidualDensity CompactWordCircuit
def rename (a b : Fin 7) (w : Block) : Block := w.map (Equiv.swap a b)
def key (a b : Fin 7) (c : Block) := classKey (rename a b c)

theorem undo (a b : Fin 7) (w : Block) : rename a b (rename a b w)=w := by
  simp [rename,List.map_map,Function.comp_def]
theorem rename_windows (a b : Fin 7) (w : Block) :
    windows (rename a b w)=(windows w).map (rename a b) := by
  induction w with
  | nil => rfl
  | cons x xs ih =>
    by_cases e:6≤xs.length <;> simp [windows,rename,List.map_take,e] at ih ⊢ <;> assumption
theorem rename_anchors (a b : Fin 7) (w : Block) :
    anchors (rename a b w)=(anchors w).map (rename a b) := by
  unfold anchors
  rw [rename_windows]
  simp [List.map_map,Function.comp_def,rename,dst,List.map_take]

private theorem reps (a b : Fin 7) {w : Block} (h:w∈representatives) :
    rename a b w∈representatives := by
  obtain ⟨sz,nd⟩ := (mem_reps _).mp h
  exact (mem_reps _).mpr ⟨by simpa [rename] using sz, nd.map (Equiv.swap a b).injective⟩

set_option maxRecDepth 100000 in
private theorem table : ∀a b : Fin 7,
    (∀s∈states, full (rename a b s) ∧ tag (rename a b s)=key a b (tag s)) ∧
    (∀p∈representatives, classKey (rename a b p)=key a b (classKey p) ∧
       key a b (key a b (classKey p))=classKey p) := by native_decide

private theorem key_undo (a b : Fin 7) {c : Block} (hc:c∈allClasses) :
    key a b (key a b c)=c := by
  obtain ⟨p,hp,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hc)
  exact ((table a b).2 p hp).2
private theorem key_mem (a b : Fin 7) {c : Block} (hc:c∈allClasses) :
    key a b c∈allClasses := by
  obtain ⟨p,hp,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hc)
  exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨_, reps a b hp, ((table a b).2 p hp).1⟩)

private theorem visit_image (a b : Fin 7) (w : Block) {c : Block} (hc:c∈visited w) :
    key a b c ∈ visited (rename a b w) := by
  obtain ⟨u,mem,valid,rfl⟩ := (mem_visited _ _).mp hc
  obtain ⟨full',eq⟩ := (table a b).1 u (mem_states valid)
  exact (mem_visited _ _).mpr ⟨_,rename_anchors a b w ▸ List.mem_map_of_mem mem,full',eq⟩

private theorem done_image (a b : Fin 7) (w : Block) {c : Block} (hc:c∈complete w) :
    key a b c ∈ complete (rename a b w) := by
  obtain ⟨legal,all⟩ := (mem_complete _ _).mp hc
  refine (mem_complete _ _).mpr ⟨key_mem a b legal, ?_⟩
  intro p hp eql
  have h := ((table a b).2 p hp).1
  rw [eql,key_undo a b legal] at h
  have found := all _ (reps a b hp) h
  rw [rename_windows,←undo a b p]
  exact List.mem_map_of_mem found

private theorem card_le (a b : Fin 7) (s t : Finset Block) (sub:s⊆allClasses)
    (map : ∀ c∈s,key a b c∈t) : s.card≤t.card := by
  have inj : Set.InjOn (key a b) (s : Set Block) := by
    intro x hx y hy eq
    simpa only [key_undo a b (sub hx),key_undo a b (sub hy)] using congrArg (key a b) eq
  rw [←Finset.card_image_of_injOn inj]
  apply Finset.card_le_card
  intro x hx
  obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp hx
  exact map c hc

theorem swap_counts (a b : Fin 7) (w : Block) :
    (visited (rename a b w)).card=(visited w).card ∧
    (complete (rename a b w)).card=(complete w).card := by
  have vh (z : Block) := card_le a b _ _ (visited_subset z) (fun c hc=>visit_image a b z hc)
  have dh (z : Block) := card_le a b _ _ (Finset.Subset.trans (complete_subset z) (visited_subset z))
    (fun c hc=>done_image a b z hc)
  exact ⟨le_antisymm (by simpa only [undo] using vh (rename a b w)) (vh w),
    le_antisymm (by simpa only [undo] using dh (rename a b w)) (dh w)⟩

theorem first_zero_all_rows {w : Block} (len : w.length=1501)
    (hit : (visited w).card=720) (many : 91≤(complete w).card) :
    ∃ z : Block, z.length=1501 ∧ z.head?=some 0 ∧
      ∃ v, wire v 2=true ∧ ∀r∈signedRows 0 (goalTape true).body.toList,r.any (wire v)=true := by
  cases w with
  | nil => simp at len
  | cons x xs =>
    let z := rename x 0 (x::xs)
    have zz : z.length=1501 := by simpa [z,rename] using len
    have hd : z.head?=some 0 := by simp [z,rename]
    obtain ⟨vis,done'⟩ := swap_counts x 0 (x::xs)
    obtain ⟨f,v,events,rows⟩ := counterexample_all_rows zz (vis.trans hit) (done' ▸ many)
    have reg := (source_slot (input_admits (layout_parts events)) (0 : Fin 1501) (0 : Fin 7)).2
    exact ⟨z,zz,hd,v,by simpa [wordSource,slot,z,rename] using reg,rows⟩

#print axioms first_zero_all_rows
end ExactWordFlow.CandidateRenaming

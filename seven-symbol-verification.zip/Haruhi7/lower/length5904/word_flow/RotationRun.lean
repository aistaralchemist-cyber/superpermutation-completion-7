import RouteDensity

namespace SevenWordWindows.RotationRun
open ExactWordFlow DirectedEuler ResidualDensity

private def endsOf {α : Type*} [DecidableEq α] (x : α) : List α → Nat
  | [] => 0
  | y::ys => endsOf x ys + if y=x ∧ ys.head? ≠ some x then 1 else 0

private theorem ends_zero {α : Type*} [DecidableEq α] (x : α) (xs : List α) :
    endsOf x xs=0 ↔ x∉xs := by
  induction xs with
  | nil => simp [endsOf]
  | cons y ys ih =>
    by_cases eq : y=x
    · subst y
      cases ys with
      | nil => simp [endsOf]
      | cons z zs =>
        by_cases same : z=x
        · subst z
          simpa [endsOf] using ih
        · simp [endsOf,same]
    · simp [endsOf,eq,ih,Ne.symm eq]

/-- In a list with exactly one run of x, all copies of x occupy a
single literal interval. The two adjacent sublists contain no x. -/
private theorem one_interval {α : Type*} [DecidableEq α] [BEq α] [LawfulBEq α] (x : α) (xs : List α)
    (one : endsOf x xs=1) : ∃ l r : List α, xs=l++List.replicate (xs.count x) x++r ∧ x∉l ∧ x∉r := by
  induction xs with
  | nil => simp [endsOf] at one
  | cons y ys ih =>
    by_cases eq : y=x
    · subst y
      by_cases extendsRun : ys.head?=some x
      · have old : endsOf x ys=1 := by simpa [endsOf,extendsRun] using one
        obtain ⟨l,r,part,left,right⟩ := ih old
        have lnil : l=[] := by
          cases l with
          | nil => rfl
          | cons z ls =>
            have head := congrArg List.head? part
            simp only [List.cons_append,List.head?_cons,extendsRun,Option.some.injEq] at head
            exact (left (head ▸ List.mem_cons_self)).elim
        subst l
        refine ⟨[],r,?_,by simp,right⟩
        rw [List.count_cons_self,List.replicate_succ]
        simpa only [List.nil_append,List.cons_append,List.cons.injEq,true_and] using part
      · have zero : endsOf x ys=0 := by simpa [endsOf,extendsRun] using one
        have absent := (ends_zero x ys).mp zero
        exact ⟨[],ys,by simp [List.count_eq_zero_of_not_mem absent],by simp,absent⟩
    · have old : endsOf x ys=1 := by simpa [endsOf,eq] using one
      obtain ⟨l,r,part,left,right⟩ := ih old
      refine ⟨y::l,r,?_,by simp [Ne.symm eq,left],right⟩
      rw [List.count_cons_of_ne eq]
      exact congrArg (y::·) part

private theorem counted_ends (xs : List (Option Word)) (c : Word) (conn : Connected xs) :
    (runEnds xs).count c=endsOf (some c) xs := by
  induction xs with
  | nil => rfl
  | cons a ys ih =>
    cases ys with
    | nil => cases a <;> simp [runEnds,endsOf,List.count_cons,beq_iff_eq]
    | cons b zs =>
      obtain ⟨link,tail⟩ := conn
      have old := ih tail
      cases a with
      | none =>
        cases b <;> simpa only [runEnds,List.head?_cons,Option.join_some,Option.isSome_none,
          Option.isSome_some,Bool.false_eq_true,ite_false,ite_true,Option.toList_none,
          List.nil_append,endsOf,reduceCtorEq,false_and,Nat.add_zero] using old
      | some u =>
        cases b with
        | none =>
          simpa [runEnds,endsOf,List.count_cons,beq_iff_eq,ne_eq] using
            congrArg (fun n : Nat => n + if u=c then 1 else 0) old
        | some v =>
          have same := link u v rfl rfl
          subst v
          by_cases uc : u=c <;> simpa [runEnds,endsOf,uc,ne_eq] using old

private theorem label_count (xs : List Word) (c : Word) :
    (xs.map mark).count (some c) = ((xs.filter fun p => decide p.Nodup).map classKey).count c := by
  induction xs with
  | nil => rfl
  | cons p ps ih =>
    by_cases fl : p.Nodup
    · simp [mark,fl,List.count_cons,ih]
    · simp [mark,fl,ih]

def turn (p : Word) := (List.range 7).map fun i => p.rotate i

private def spellNext (s : Word) := s++((List.finRange 7).filter fun a => a∉s)

private theorem local_table : ∀p∈representatives,
    spellNext (src p)=p ∧ windows (p++p.take 6)=turn p ∧
    (p++p.take 6).take 6=src p ∧ (p++p.take 6).drop ((p++p.take 6).length-6)=src p ∧
    ResidualDensity.full (src p) ∧ ResidualDensity.tag (src p)=classKey p ∧
    (∀f∈turn p, f∈representatives ∧ mark f=some (classKey p)) := by native_decide

theorem turn_route {p : Word} (hp : p∈representatives) : Route src dst (src p) (turn p) (src p) := by
  have len := ((mem_reps _).mp hp).1
  have ⟨_,edge,first,last,_⟩ := local_table p hp
  have r := read_route (p++p.take 6) (by simp; omega)
  rwa [first,edge,last] at r

private theorem canonical_table : ∀p∈representatives, (turn p).Nodup ∧
    (turn p).toFinset=(turn (classKey p)).toFinset ∧ p∈turn (classKey p) := by native_decide

/-- The seven consecutive rotations use exactly the seven mandatory
copies of the class, one of every permutation in its fibre. -/
theorem turn_fibre {p : Word} (hp : p∈representatives) :
    (↑(turn p) : Multiset Word)=(fibre (classKey p)).val := by
  have h := canonical_table p hp
  apply (Multiset.Nodup.ext (Multiset.coe_nodup.mpr h.1) (fibre (classKey p)).nodup).mpr
  intro q
  change q∈turn p ↔ q∈fibre (classKey p)
  constructor
  · intro hq
    obtain ⟨valid,marked⟩ := (local_table p hp).2.2.2.2.2.2 q hq
    exact Finset.mem_filter.mpr ⟨List.mem_toFinset.mpr valid,
      by simpa [mark,((mem_reps q).mp valid).2] using marked⟩
  · intro hq
    obtain ⟨valid,key⟩ := Finset.mem_filter.mp hq
    apply List.mem_toFinset.mp
    rw [h.2.1,←key]
    exact List.mem_toFinset.mpr (canonical_table q (List.mem_toFinset.mp valid)).2.2

private theorem same_run {s t v : Word} {es fs : List Word}
    (r : Route src dst s es t) (r' : Route src dst s fs v)
    (p : ∀e∈es,e∈representatives) (q : ∀f∈fs,f∈representatives) (n : es.length=fs.length) :
    es=fs := by
  induction r generalizing fs v with
  | nil => exact (List.eq_nil_of_length_eq_zero n.symm).symm
  | cons e hs tail ih =>
    cases r' with
    | nil => simp at n
    | cons f hf tail' =>
      have eq : e=f := (local_table e (p e List.mem_cons_self)).1.symm.trans
        ((congrArg spellNext (hs.trans hf.symm)).trans (local_table f (q f List.mem_cons_self)).1)
      subst f
      exact congrArg (e::·) (ih tail' (fun u hu => p u (List.mem_cons_of_mem _ hu))
        (fun u hu => q u (List.mem_cons_of_mem _ hu)) (by simpa using n))

private theorem route_parts {s t : Word} (l r : List Word)
    (walk : Route src dst s (l++r) t) : ∃ u, Route src dst s l u ∧ Route src dst u r t := by
  induction l generalizing s with
  | nil => exact ⟨s,.nil _,walk⟩
  | cons e l ih =>
    cases walk with
    | cons _ atSrc tail =>
      obtain ⟨u,first,last⟩ := ih tail
      exact ⟨u,.cons e atSrc first,last⟩

private theorem widths (w : Word) (e : Word) (h : e∈windows w) : e.length=7 := by
  induction w with
  | nil => simp [windows] at h
  | cons a w ih =>
    rw [windows] at h
    split at h
    · rcases List.mem_cons.mp h with rfl|other
      · simp; omega
      · exact ih other
    · simp at h

/-- A complete class gives seven contiguous, literally rotated windows.
No other window of the word has the same clean class label. -/
theorem whole_run {w c : Word} (hc : c∈completeClasses w) :
    ∃ (before : List Word) (p : Word) (after : List Word),
      p∈representatives ∧ classKey p=c ∧ windows w=before++turn p++after ∧
      ∀e∈before++after, mark e≠some c := by
  obtain ⟨v,ends⟩ := (Finset.mem_filter.mp hc).2
  have obs := label_count (windows w) c
  change (labels w).count (some c)=(visits w).count c at obs
  have one := (counted_ends (labels w) c (link_windows w)).symm.trans ends
  obtain ⟨L,R,sub,notL,notR⟩ := one_interval (some c) (labels w) one
  rw [obs,v,List.append_assoc] at sub
  obtain ⟨l,tail,split,hL,tmap⟩ := List.map_eq_append_iff.mp sub
  obtain ⟨mid,r,middle,marks,hR⟩ := List.map_eq_append_iff.mp tmap
  have word : windows w=l++mid++r := by rw [split,middle,List.append_assoc]
  have nd := List.eq_replicate_iff.mp marks
  have n : mid.length=7 := by simpa using nd.1
  have m (e) (he : e∈mid) : mark e=some c := nd.2 (mark e) (List.mem_map_of_mem he)
  have inWord (e) (he : e∈mid) : e∈windows w := by rw [word]; exact List.mem_append_left _ (List.mem_append_right _ he)
  have valid (e) (he : e∈mid) : e∈representatives := by
    apply (mem_reps _).mpr
    apply And.intro (widths w e (inWord e he))
    have obs' := m e he
    by_contra bad
    simp [mark,bad] at obs'
  have size := congrArg List.length word
  simp only [windows_length,List.length_append,n] at size
  have walk := read_route w (by omega)
  rw [word,List.append_assoc] at walk
  obtain ⟨u,_,last⟩ := route_parts _ _ walk
  obtain ⟨_,middleRoute,_⟩ := route_parts mid r last
  cases mid with
  | nil => simp at n
  | cons p ps =>
    have hp : p∈representatives := valid p List.mem_cons_self
    have tagp := m p List.mem_cons_self
    have key : classKey p=c := by simpa only [mark,ite_eq_left ((mem_reps p).mp hp).2,Option.some.injEq] using tagp
    have first : src p=u := by cases middleRoute; assumption
    have wheel := turn_route hp
    rw [first] at wheel
    have eq := same_run middleRoute wheel valid (fun f hf => ((local_table p hp).2.2.2.2.2.2 f hf).1)
      (by simpa [turn] using n)
    refine ⟨l,p,r,hp,key,by rwa [←eq],?_⟩
    intro e he same
    rcases List.mem_append.mp he with left|right
    · apply notL
      rw [←hL,←same]
      exact List.mem_map_of_mem left
    · apply notR
      rw [←hR,←same]
      exact List.mem_map_of_mem right

theorem closed_run {w c : Word} (hc : c∈completeClasses w) :
    ∃ (a b d : List Word) (u : Word), windows w=a++b++d ∧ b.length=7 ∧
      (∀e∈b,mark e=some c) ∧ (∀e∈a++d, mark e≠some c) ∧
      Route src dst u b u ∧ ResidualDensity.full u ∧ ResidualDensity.tag u=c := by
  obtain ⟨l,p,r,hp,key,word,outside⟩ := whole_run hc
  have geom := local_table p hp
  exact ⟨l,turn p,r,src p,word,by simp [turn],fun e he => ((geom.2.2.2.2.2.2 e he).2.trans (congrArg some key)),
    outside,turn_route hp,geom.2.2.2.2.1,geom.2.2.2.2.2.1.trans key⟩

#print axioms turn_fibre
#print axioms whole_run
#print axioms closed_run
end SevenWordWindows.RotationRun

import SeedPacking
namespace ExactWordFlow.FractionalPacking
/-- A rational partition of the complement obstructs every classwise
five-child price certificate, including certificates targeting a subset. -/
theorem lower {α ι : Type*} [DecidableEq α] [Fintype ι]
    (V P : Finset α) (child : ι→Finset α) (mass : ι→Nat) (N D : Nat)
    (pos : 0<D) (size : ∑i,mass i=N*D)
    (exact : ∀v∈V, (∑i,if v∈child i then mass i else 0)=D)
    (inside : ∀i,child i⊆V) (outer : V⊆P)
    (weight : α→Nat) (K : Nat) (pay : ∀i,K≤∑v∈child i,weight v) :
    N*K≤∑v∈P,weight v := by
  classical
  have expand (i : ι) : (∑v∈V,if v∈child i then mass i*weight v else 0) =
      mass i*(∑v∈child i,weight v) := by
    rw [← Finset.sum_filter,Finset.filter_mem_eq_inter,Finset.inter_eq_right.mpr (inside i),
      Finset.mul_sum]
  have bound : (∑i,mass i*K) ≤ ∑i,mass i*(∑v∈child i,weight v) :=
    Finset.sum_le_sum (fun i _=>Nat.mul_le_mul_left _ (pay i))
  have cb : (∑i,mass i*(∑v∈child i,weight v))=D*(∑v∈V,weight v) := by
    simp_rw [←expand]
    rw [Finset.sum_comm,Finset.mul_sum]
    refine Finset.sum_congr rfl (fun v hv=>?_ )
    rw [←exact v hv,Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro i _
    by_cases h : v∈child i <;> simp [h]
  rw [←Finset.sum_mul,size,cb] at bound
  have h : D*(N*K)≤D*(∑v∈V,weight v) := by simpa only [Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using bound
  exact (Nat.le_of_mul_le_mul_left h pos).trans (Finset.sum_le_sum_of_subset outer)
end ExactWordFlow.FractionalPacking

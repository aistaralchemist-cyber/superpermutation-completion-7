import PermutationGenus

namespace ExactWordFlow.PhaseReturn
open Equiv
variable {X : Type*} [DecidableEq X]

/-- Every orbit of the partially constructed permutation has a marked
physical state. An integer wheel placement determines these orbits. -/
def Hits (F : Perm X) (S : Finset X) : Prop :=
  ∀x,∃n : Nat,(F^n) x∈S

private noncomputable def delay {F : Perm X} {S : Finset X} (visits : Hits F S) (x : X) :=
  Nat.find (visits x)

/-- First marked state, allowing zero steps. -/
noncomputable def mark {F : Perm X} {S : Finset X} (visits : Hits F S) (x : X) : X :=
  (F^delay visits x) x

private theorem marked {F : Perm X} {S : Finset X} (visits : Hits F S) (x : X) :
    mark visits x∈S := Nat.find_spec (visits x)

private theorem delay_zero {F : Perm X} {S : Finset X} (visits : Hits F S) {x : X} (hx : x∈S) :
    delay visits x=0 := Nat.eq_zero_of_le_zero (Nat.find_min' (visits x) (show (F^0) x∈S by simpa))

private theorem mark_id {F : Perm X} {S : Finset X} (visits : Hits F S) {x : X} (hx : x∈S) :
    mark visits x=x := by simp [mark,delay_zero visits hx]

private theorem shift {F : Perm X} {S : Finset X} (visits : Hits F S) {x : X} (hx : x∉S) :
    delay visits (F x)+1=delay visits x := by
  have step:=marked visits (F x)
  change (F ^ delay visits (F x)) (F x)∈S at step
  have upper:=Nat.find_min' (visits x) (show (F^(delay visits (F x)+1)) x∈S by simpa [pow_succ,Perm.mul_apply] using step)
  change delay visits x≤_ at upper
  have first:=marked visits x
  change (F^delay visits x) x∈S at first
  cases eq : delay visits x with
  | zero => simp [eq,hx] at first
  | succ n =>
    rw [eq,pow_succ,Perm.mul_apply] at first
    have low:=Nat.find_min' (visits (F x)) first
    change delay visits (F x)≤n at low
    omega

private theorem skip {F : Perm X} {S : Finset X} (visits : Hits F S) {x : X} (hx : x∉S) :
    mark visits (F x)=mark visits x := by
  unfold mark
  rw [←shift visits hx,pow_succ,Perm.mul_apply]

private theorem reaches {F J : Perm X} {S : Finset X} (visits : Hits F S)
    (off : ∀x∉S,J x=x) (x : X) : (F*J).SameCycle x (mark visits x) := by
  by_cases yes : x∈S
  · rw [mark_id visits yes]
  · have h:=reaches visits off (F x)
    rw [skip visits yes] at h
    rwa [←Perm.sameCycle_apply_left,Perm.mul_apply,off x yes]
termination_by delay visits x
decreasing_by have eq:=shift visits yes; omega

/-- Advance once on the actual exceptional permutation J, then return to
the marks following the permutation F built from all chosen ordinary wheels. -/
noncomputable def jump {F : Perm X} {S : Finset X} (visits : Hits F S) (J : Perm X) (x : X) : X :=
  mark visits (F (J x))

private theorem compressed {F J : Perm X} {S : Finset X} (visits : Hits F S)
    (off : ∀x∉S,J x=x) {start : X} (hs : start∈S) (n : Nat) :
    ∃k : Nat,(jump visits J)^[k] start= mark visits (((F*J)^n) start) := by
  induction n with
  | zero => exact ⟨0,by simpa using (mark_id visits hs).symm⟩
  | succ n ih =>
    obtain ⟨k,eq⟩:=ih
    let y:=((F*J)^n) start
    change (jump visits J)^[k] start=mark visits y at eq
    rw [pow_succ',Perm.mul_apply]
    change ∃k,(jump visits J)^[k] start=mark visits ((F*J) y)
    by_cases hy : y∈S
    · refine ⟨k+1,?_⟩
      rw [Function.iterate_succ_apply',eq,mark_id visits hy]
      rfl
    · refine ⟨k,?_⟩
      rw [Perm.mul_apply,off y hy,skip visits hy,eq]

variable [Fintype X]

private theorem necessary_hits {F J : Perm X} {S : Finset X} (off : ∀x∉S,J x=x)
    {start : X} (hs : start∈S) (orbit : ∀y,(F*J).SameCycle start y) : Hits F S := by
  have lift (n : Nat) (x : X) (hit : ((F*J)^n) x∈S) : ∃m : Nat,(F^m) x∈S := by
    induction n generalizing x with
    | zero => exact ⟨0,by simpa using hit⟩
    | succ n ih =>
      by_cases hy : x∈S
      · exact ⟨0,by simpa⟩
      · rw [pow_succ,Perm.mul_apply,Perm.mul_apply,off x hy] at hit
        obtain ⟨m,ok⟩:=ih _ hit
        exact ⟨m+1,by simpa [pow_succ,Perm.mul_apply] using ok⟩
  intro x
  obtain ⟨n,_,eq⟩:=(orbit x).symm.exists_pow_eq'
  exact lift n x (eq ▸ hs)

/-- Exact single-tour criterion, including the direction from a connected
return circuit to a full physical successor. No restriction on genus,
cost, the number of ordinary wheels, or the number of exceptional cycles. -/
theorem one_orbit_iff {F J : Perm X} {S : Finset X} (off : ∀x∉S,J x=x)
    {start : X} (hs : start∈S) :
    (∀y,(F*J).SameCycle start y) ↔
      ∃h : Hits F S,∀x∈S,∃k : Nat,(jump h J)^[k] start=x := by
  constructor
  · intro orbit
    let h:=necessary_hits off hs orbit
    refine ⟨h,fun x hx=>?_⟩
    obtain ⟨n,_,eq⟩:=(orbit x).exists_pow_eq'
    obtain ⟨k,ok⟩:=compressed h off hs n
    exact ⟨k,by rwa [eq,mark_id h hx] at ok⟩
  · rintro ⟨h,all⟩ y
    have walk (k : Nat) : (F*J).SameCycle start ((jump h J)^[k] start) := by
      induction k with
      | zero => exact .refl _ _
      | succ k ih =>
        rw [Function.iterate_succ_apply']
        apply ih.trans
        apply Perm.sameCycle_apply_left.mp
        exact reaches h off _
    obtain ⟨k,eq⟩:=all _ (marked h y)
    have w:=walk k
    rw [eq] at w
    exact w.trans (reaches h off y).symm

/-- If the marks are a transversal of the actual unmodified orbits,
any cycle order of J on those marks joins the whole placement. -/
theorem transversal {F J : Perm X} {S : Finset X} (off : ∀x∉S,J x=x)
    (visits : Hits F S) (unique : ∀x∈S,∀y∈S,F.SameCycle x y → x=y)
    {start : X} (hs : start∈S) (cycle : ∀x∈S,J.SameCycle start x) :
    ∀y,(F*J).SameCycle start y := by
  apply (one_orbit_iff off hs).2
  refine ⟨visits,?_⟩
  have keeps {x} (hx : x∈S) : J x∈S := by
    by_contra no
    have e:=J.injective (off (J x) no)
    exact no (e.symm ▸ hx)
  have iter (k : Nat) : (J^k) start∈S ∧ (jump visits J)^[k] start=(J^k) start := by
    induction k with
    | zero => exact ⟨by simpa,by simp⟩
    | succ k ih =>
      rw [pow_succ',Perm.mul_apply,Function.iterate_succ_apply',ih.2]
      refine ⟨keeps ih.1,?_⟩
      apply unique _ (marked visits _) _ (keeps ih.1)
      unfold mark
      simp only [Perm.sameCycle_pow_left, Perm.sameCycle_apply_left]
      exact .refl _ _
  intro x hx
  obtain ⟨k,_,eq⟩:=(cycle _ hx).exists_pow_eq'
  exact ⟨k,(iter k).2.trans eq⟩

#print axioms one_orbit_iff
#print axioms transversal
end ExactWordFlow.PhaseReturn

import DeepBridgeComponents
import SpliceSides

namespace ExactWordFlow.DeepBridgeComponents
open SevenWordWindows RotationSplice

/-- Two safe contexts at either end leave only the interior of a bridge.
This also covers overlaps between the two safe ranges on short bridges. -/
theorem middle_only {v : List Block} {W : Finset Block}
    (front : ∀u∈v.take 2,wheelKey u∉W)
    (back : ∀u∈v.drop (v.length-2),wheelKey u∉W)
    {u : Block} (seen : u∈v) (wheel : wheelKey u∈W) : u∈interior v := by
  obtain ⟨i,hi,eq⟩:=List.mem_iff_getElem.mp seen
  by_cases first : i<2
  · have low : i<(v.take 2).length := by simp; omega
    have inFront:=List.getElem_mem (l:=v.take 2) (n:=i) low
    rw [List.getElem_take,eq] at inFront
    exact (front u inFront wheel).elim
  by_cases last : v.length - 2 ≤ i
  · let j:=i-(v.length-2)
    have h : j<(v.drop (v.length-2)).length := by dsimp [j];simp;omega
    have on:=List.getElem_mem (l:=v.drop (v.length-2)) (n:=j) h
    rw [List.getElem_drop] at on
    have idn : v.length-2+j=i := by dsimp [j];omega
    exact (back _ on (by simpa [idn,eq] using wheel)).elim
  · let j:=i-2
    have idx : j<(interior v).length := by simp [interior,j]; omega
    have on:=List.getElem_mem (l:=interior v) (n:=j) idx
    have off : 2+j=i:=by dsimp [j]; omega
    simpa [interior,List.getElem_drop,List.getElem_take,off,eq] using on

/-- The two end windows fix the candidates for the first and last
interior six-context.  At a skipped good slot only the canonical
ordinary-neighbour condition is needed to exclude an extra wheel. -/
theorem guarded_bridge {W : Finset Block} (empty : []∉W) {x y : Block}
    (px : x∈representatives) (py : y∈representatives) (a b : Fin 7)
    (start : wheelKey x.tail∉W) (finish : wheelKey (y.take 6)∉W)
    (skipLeft : a=x[0]?.getD 0 → wheelKey (x.rotate 1).tail∉W)
    (skipRight : b=y[6]?.getD 0 → wheelKey (y.rotate 5).tail∉W)
    {trace : List Block}
    (first : ∀u∈trace.take 2,u=x.tail ∨ u=x.tail.tail++[a])
    (last : ∀u∈trace.drop (trace.length-2),u=y.take 6 ∨ u=b::y.take 5)
    {u : Block} (seen : u∈trace) (wheel : wheelKey u∈W) : u∈interior trace := by
  apply middle_only (v:=trace) (W:=W) _ _ seen wheel
  · intro v hv
    rcases first v hv with rfl|rfl
    · exact start
    · rcases (boundary_geometry x px a).1 with z|q|⟨a0,q⟩
      · rwa [z]
      · rwa [q]
      · simpa only [q] using skipLeft a0
  · intro v hv
    rcases last v hv with rfl|rfl
    · exact finish
    · rcases (boundary_geometry y py b).2 with z|q|⟨b6,q⟩
      · rwa [z]
      · rwa [q]
      · simpa only [q] using skipRight b6

/-- A physical ordinary wheel moves every one of its six involved
seven-letter states. Maximality of ordinary adjacencies therefore
protects both skipped rotations in a pair of consecutive selected windows. -/
theorem skipped_gates {X : Type*} [Fintype X] [DecidableEq X] {n : Nat}
    (R : Equiv.Perm X) (word : X→Block) (occ : X→Fin n→Prop)
    (pos : X→Fin n) (valid : ∀x,occ x (pos x))
    (best : ∀f,(∀x,occ x (f x)) → (ordinary R f).card≤(ordinary R pos).card)
    (W : Finset Block) (moves : ∀x,wheelKey (word x).tail∈W → x∉ordinary R pos)
    (x z : X) (neX : x≠R x) (neZ : R z≠z)
    (spellsX : word (R x)=(word x).rotate 1)
    (spellsZ : word (R.symm z)=(word (R z)).rotate 5)
    (i j : Fin n) (a b : Fin 7)
    (left : a=(word x)[0]?.getD 0 → occ (R x) i ∧ i.val=(pos x).val+1 ∧ pos (R x)≠i)
    (right : b=(word (R z))[6]?.getD 0 → occ z j ∧ (pos (R z)).val=j.val+1 ∧ pos z≠j) :
    (a=(word x)[0]?.getD 0 → wheelKey ((word x).rotate 1).tail∉W) ∧
    (b=(word (R z))[6]?.getD 0 → wheelKey ((word (R z)).rotate 5).tail∉W) := by
  constructor
  · intro yes wheel
    obtain ⟨available,slot,missed⟩:=left yes
    rw [←spellsX] at wheel
    exact moves _ wheel (forced_outgoing R occ pos valid best x i neX available slot missed)
  · intro yes wheel
    obtain ⟨available,slot,missed⟩:=right yes
    rw [←spellsZ] at wheel
    exact moves _ wheel (forced_incoming R occ pos valid best z j neZ available slot missed)

#print axioms middle_only
#print axioms guarded_bridge
#print axioms skipped_gates
end ExactWordFlow.DeepBridgeComponents

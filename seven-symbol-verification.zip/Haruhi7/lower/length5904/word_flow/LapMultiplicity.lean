import LapDeletionShadow
import RotationRun
import CoreControls

namespace ExactWordFlow.LapMultiplicity
open SevenWordWindows ResidualDensity RotationReinsert LapDeletionShadow
open private lapStarts from CoreControls

private def front : Block→Block→List Block
  | [],_=>[]
  | x::xs,t=>(x::(xs++t).take 6)::front xs t

private theorem six (xs t : Block) : (xs++t.take 6).take 6=(xs++t).take 6 := by
  simp [List.take_append,List.take_take]

private theorem split (l t : Block) (wide : 6≤t.length) :
    windows (l++t)=front l (t.take 6)++windows t := by
  induction l with
  | nil => rfl
  | cons x xs ih =>
    have size:6≤xs.length+t.length:=by omega
    simp [windows,front,size,ih,six]

private def cleanTags (xs : List Block) := (xs.filter (fun u=>decide (full u))).map tag

/-- Every full six-context contributes its class with its actual multiplicity. -/
def tags (w : Block) : Multiset Block := ↑(cleanTags (anchors w))

private theorem center : ∀p∈representatives,
    front p (p.take 6)=RotationRun.turn p ∧
    ((RotationRun.turn p).filter (fun e=>decide e.Nodup)).length=7 ∧
    cleanTags ((RotationRun.turn p).map dst)=List.replicate 7 (classKey p) := by native_decide

theorem ordered {l p r : Block} (hp:p∈representatives) :
    (l++p++p.take 6++r).take 6=(l++p.take 6++r).take 6 ∧
    ∃b e,windows (l++p++p.take 6++r)=b++RotationRun.turn p++e ∧
      windows (l++p.take 6++r)=b++e := by
  have len:=((mem_reps _).mp hp).1
  have hl:(p.take 6).length=6:=by simp [len]
  have hd:(p.take 6++r).take 6=p.take 6:=by simp [hl]
  have hd':(p++(p.take 6++r)).take 6=p.take 6:=by simp [List.take_append,len]
  have wide : 6≤(p.take 6++r).length:=by simp [hl]
  have wid : 6≤(p++(p.take 6++r)).length:=by simp [len];omega
  simp only [List.append_assoc]
  refine ⟨?_,front l (p.take 6),windows (p.take 6++r),?_,?_⟩
  · rw [←six l (p++(p.take 6++r)),←six l (p.take 6++r),hd',hd]
  · rw [split l _ wid,split p _ wide,hd,hd',(center p hp).1]
  · rw [split l _ wide,hd]

private theorem one {l p r : Block} (hp:p∈representatives) :
    ExactWordFlow.bag (l++p++p.take 6++r)=ExactWordFlow.bag (l++p.take 6++r)+↑(RotationRun.turn p) ∧
    (good (l++p++p.take 6++r)).length=(good (l++p.take 6++r)).length+7 ∧
    tags (l++p++p.take 6++r)=tags (l++p.take 6++r)+Multiset.replicate 7 (classKey p) := by
  obtain ⟨head,b,e,old,new⟩:=ordered (l:=l) (r:=r) hp
  obtain ⟨_,size,keys⟩:=center p hp
  constructor
  · unfold ExactWordFlow.bag
    rw [old,new]
    simp only [←Multiset.coe_add]
    ac_rfl
  constructor
  · simp only [good,old,new,List.filter_append,List.length_append,size]
    omega
  · simp only [tags,anchors,head,old,new,List.map_append,List.cons_append.symm]
    have appendTags (u v : List Block):cleanTags (u++v)=cleanTags u++cleanTags v:=by simp [cleanTags]
    simp only [appendTags,keys,←Multiset.coe_add,Multiset.coe_replicate]
    ac_rfl

theorem word_bag {w v : Block} {ps : List Block} (cuts : Cuts w ps v) :
    ExactWordFlow.bag w=ExactWordFlow.bag v+↑(ps.flatMap RotationRun.turn) := by
  induction cuts with
  | stop => simp
  | remove hp rest ih =>
    rw [(one hp).1,ih,List.flatMap_cons]
    simp only [←Multiset.coe_add]
    ac_rfl

theorem good_after {w v : Block} {ps : List Block} (cuts : Cuts w ps v) :
    (good w).length=(good v).length+7*ps.length := by
  induction cuts with
  | stop => simp
  | remove hp rest ih => rw [(one hp).2.1,ih,List.length_cons];omega

theorem tag_bag {w v : Block} {ps : List Block} (cuts : Cuts w ps v) :
    tags w=tags v+7 • (↑(ps.map classKey) : Multiset Block) := by
  induction cuts with
  | stop => simp
  | remove hp rest ih =>
    rw [(one hp).2.2,ih,List.map_cons,←Multiset.cons_coe,←Multiset.singleton_add,smul_add]
    simp only [Multiset.nsmul_singleton]
    ac_rfl

theorem count_after {w v : Block} {ps : List Block} (cuts : Cuts w ps v) (c : Block) :
    (tags w).count c=(tags v).count c+7*(ps.map classKey).count c := by
  have h:=congrArg (Multiset.count c) (tag_bag cuts)
  simpa [List.count_eq_countP,Bool.beq_eq_decide_eq] using h

def recordTags := lapStarts.map fun i=>classKey ((RotationCoreControls.source.toArray.extract i (i+7)).toList)

private def sourceBag := tags RotationCoreControls.source

theorem source_eight : recordTags.length=653 ∧ recordTags.Nodup ∧
    ∀c∈recordTags,(tags RotationCoreControls.source).count c=8 := by
  refine ⟨by simpa only [recordTags,List.length_map] using RotationCoreControls.laps_distinct.1,RotationCoreControls.laps_distinct.2.2,?_⟩
  have check : recordTags.all (fun c=>sourceBag.count c==8)=true := by native_decide
  intro c hc
  exact eq_of_beq (List.all_eq_true.mp check c hc)

theorem source_one {v : Block} {ps : List Block} (cuts : Cuts RotationCoreControls.source ps v)
    {c : Block} (hc:c∈recordTags) (picked:(ps.map classKey).count c=1) :
    (tags v).count c=1 := by
  have before:=source_eight.2.2 c hc
  have after:=count_after cuts c
  omega

/-- A selected record class is cut exactly once, even if the input list of
lap cuts was supplied without a nonrepetition hypothesis. -/
theorem source_mem_one {v : Block} {ps : List Block} (cuts : Cuts RotationCoreControls.source ps v)
    {c : Block} (hc:c∈recordTags) (picked:c∈ps.map classKey) :
    (tags v).count c=1 ∧ (ps.map classKey).count c=1 := by
  have before:=source_eight.2.2 c hc
  have after:=count_after cuts c
  have pos:=List.count_pos_iff.mpr picked
  omega

#print axioms source_eight
#print axioms source_one
end ExactWordFlow.LapMultiplicity

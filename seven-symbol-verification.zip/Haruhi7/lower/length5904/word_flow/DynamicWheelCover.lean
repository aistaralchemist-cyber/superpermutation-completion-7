import WheelMinimumBoundary
import PrivateRepairClass

namespace ExactWordFlow.DynamicWheelCover
open SevenWordWindows SuperpermutationBounds RotationCore RotationReinsert ResidualDensity
open LiteralWheelCover
open WheelContacts (wheel)

-- A row may be used as soon as one of its rotation classes has been reached.
inductive Reaches : Finset Block → List Row → Prop
  | done {V} (all : allClasses ⊆ V) : Reaches V []
  | step {V rs u} (clean : full u) (hit : ∃c∈V, c∈wheel u)
      (rest : Reaches (V ∪ wheel u) rs) : Reaches V (wheel u :: rs)

def price (w : Block) : Nat := w.length+7*(720-(complete w).card)

open RepairedExcursions
open private phases ending from PrivateRepairClass
private theorem phase_access {w c u : Block} (hc : c∈complete w)
    (clean : full u) (onWheel : c∈wheel u) : wheel u ∈ ready w := by
  obtain ⟨i,hi,eq⟩:=List.mem_map.mp (List.mem_toFinset.mp onWheel)
  obtain ⟨fl,wh⟩:=(phases u (mem_states clean)).2 i hi
  obtain ⟨sz,nd,ed,key⟩:=(phases _ (mem_states fl)).1
  have occurs:=((mem_complete w c).mp hc).2 _ ((mem_reps _).mpr ⟨sz,nd⟩) (key.trans eq)
  exact mem_ready.mpr ⟨u.rotate i,ed ▸ List.mem_cons_of_mem _ (List.mem_map_of_mem occurs),fl,wh⟩

private theorem card_cap (w : Block) : (complete w).card≤720 := by
  rw [←board]
  exact Finset.card_le_card ((complete_subset w).trans (visited_subset w))

/-- Advance a mandatory class completion to unlock a six-letter phase.
Its seven letters are paid for by the reduction in unfinished classes. -/
theorem unlock {w u c : Block} (long : 6≤w.length) (clean : full u)
    (seen : c∈visited w) (onWheel : c∈wheel u) :
    ∃v : Block, 6≤v.length ∧ visited w ⊆ visited v ∧
      price v ≤ price w ∧ wheel u ∈ ready v := by
  by_cases done : c∈complete w
  · exact ⟨w,long,Finset.Subset.rfl,le_rfl,phase_access done clean onWheel⟩
  obtain ⟨v,len,anchorsOld,windowsOld,added⟩:=insert_class long ((mem_visited w c).mp seen)
  have boardC:=visited_subset w seen
  have now : c∈complete v := (mem_complete v c).mpr ⟨boardC,added⟩
  have mono : insert c (complete w) ⊆ complete v := by
    intro d hd
    rcases Finset.mem_insert.mp hd with rfl|prev
    · exact now
    obtain ⟨bd,old⟩:=(mem_complete w d).mp prev
    exact (mem_complete v d).mpr ⟨bd,fun p hp h=>windowsOld p (old p hp h)⟩
  have more:=Finset.card_le_card mono
  rw [Finset.card_insert_of_notMem done] at more
  have cap:=card_cap v
  refine ⟨v,by omega,?_,by unfold price; omega,phase_access now clean onWheel⟩
  intro d hd
  obtain ⟨a,whereAt,good,tagEq⟩:=(mem_visited w d).mp hd
  exact (mem_visited v d).mpr ⟨a,anchorsOld a whereAt,good,tagEq⟩

/-- Spell a mixed sequence of mandatory seven-laps and six-wheels on one
actual word, including rows unlocked only by earlier moves. -/
theorem spell {V : Finset Block} {rs : List Row} (path : Reaches V rs)
    {w : Block} (long : 6≤w.length) (seed : V⊆visited w) :
    ∃z : Block, Covers z ∧ z.length≤price w+6*rs.length := by
  induction path generalizing w with
  | done all =>
    have h : visited w=allClasses := Finset.Subset.antisymm (visited_subset w) (all.trans seed)
    obtain ⟨z,cover,len⟩:=expand_remaining long (by rw [h,board])
    exact ⟨z,cover,by simpa [price] using len.le⟩
  | @step V rs u clean hit _ ih =>
    obtain ⟨c,old,onRow⟩:=hit
    obtain ⟨v,wide,more,bound,readyRow⟩:=unlock long clean (seed old) onRow
    obtain ⟨q,ins⟩:=realizes v [wheel u] (by simpa using readyRow)
    have size:=ins.length_eq
    have vis:=ins.visited_eq
    have eq : price q=price v+6 := by
      simp only [price,ins.complete_eq,size,List.length_singleton]
      omega
    have reached : V ∪ wheel u ⊆ visited q := by
      rw [vis]
      simpa using Finset.union_subset_union (seed.trans more) (Finset.Subset.rfl : wheel u ⊆ wheel u)
    obtain ⟨z,cover,len⟩:=ih (w:=q) (by simp at size; omega) reached
    exact ⟨z,cover,by simp only [List.length_cons]; omega⟩

theorem static_path {w : Block} (S : Finset Row) {V : Finset Block}
    (legal : S⊆ready w) (seed : visited w⊆V) (cover : allClasses ⊆ V ∪ S.biUnion id) :
    Reaches V S.toList := by
  classical
  suffices all : ∀rs : List Row, rs.toFinset⊆ready w →
      ∀A : Finset Block, visited w⊆A → allClasses⊆A ∪ rs.toFinset.biUnion id → Reaches A rs by
    exact all S.toList (by simpa using legal) V seed (by simpa using cover)
  intro rs
  induction rs with
  | nil =>
    intro _ A _ h
    exact .done (by simpa using h)
  | cons R rs ih =>
    intro allowed A start h
    rw [List.toFinset_cons,Finset.insert_subset_iff] at allowed
    obtain ⟨u,atU,clean,rfl⟩:=mem_ready.mp allowed.1
    have inRow : tag u∈wheel u := by
      apply List.mem_toFinset.mpr
      apply List.mem_map.mpr
      exact ⟨0,by decide,by simp⟩
    apply Reaches.step clean ⟨tag u,start ((mem_visited _ _).mpr ⟨u,atU,clean,rfl⟩),inRow⟩
    apply ih allowed.2 (A∪wheel u) (start.trans Finset.subset_union_left)
    simpa [Finset.union_assoc] using h

theorem of_condition {b : Block} {k : Nat} (static : condition b k) :
    ∃rs,rs.length≤k ∧ Reaches (visited b) rs := by
  obtain ⟨S,legal,lim,full⟩:=static
  refine ⟨S.toList,by simpa using lim,static_path S legal Finset.Subset.rfl ?_⟩
  intro c hc
  by_cases hit : c∈visited b
  · exact Finset.mem_union_left _ hit
  · exact Finset.mem_union_right _ (full (Finset.mem_sdiff.mpr ⟨hc,hit⟩))

theorem no_shortcut {b : Block} {k : Nat} (done : (complete b).card=92)
    (size : b.length+6*k≤1508) {rs : List Row} (small : rs.length<k) :
    ¬Reaches (visited b) rs := by
  intro path
  have need:=LapSkeleton.completed_floor b
  have room : (good b).length≤b.length-6 := by
    rw [←windows_length]; exact List.length_filter_le ..
  obtain ⟨z,hz,len⟩:=spell path (w:=b) (by omega) Finset.Subset.rfl
  have lb:=SuperpermLowerBounds.covers_lower_bound_7_k16_native z hz
  simp only [price,done] at len
  omega

/-- Any putative equality word minimizes even among class-connected wheel
covers, which may use wheel rows with no initial physical anchor in b. -/
theorem joint_minimum {b : Block} {k : Nat} (done : (complete b).card=92)
    (size : b.length+6*k≤1508) (feasible : condition b k) :
    IsLeast {j : Nat | ∃rs,rs.length≤j ∧ Reaches (visited b) rs} k := by
  refine ⟨of_condition feasible,?_⟩
  rintro j ⟨rs,lim,reaches⟩
  by_contra! lt
  exact no_shortcut done size (by omega) reaches

#print axioms spell
#print axioms joint_minimum
end ExactWordFlow.DynamicWheelCover

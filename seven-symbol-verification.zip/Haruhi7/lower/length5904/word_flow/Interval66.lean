import LongDensity

namespace ResidualDensity.Density66
open SevenWordWindows
open private search_complete from Geometry40
open private admitted admiss unmask mask_cons from StrongerDensity

private def remaining (s : Six) := (List.finRange 7).filter (fun a => a ∉ s)

private theorem missing {s : Six} (h : full s) : ∃a, remaining s=[a] := by
  have ck : states.all (fun v => decide ((remaining v).length=1))=true := by native_decide
  have one := of_decide_eq_true (List.all_eq_true.mp ck s (mem_states h))
  exact List.length_eq_one_iff.mp one

private theorem mem_remaining (a : Fin 7) (s : Six) : a∈remaining s ↔ a∉s := by
  simp [remaining,List.mem_finRange]

private theorem map_tag (f : Fin 7 → Fin 7) (inj : Function.Injective f) (zero : f 0=0)
    (s : Six) (hs : full s) : tag (s.map f)=(tag s).map f := by
  have h' : full (s.map f) := ⟨by simp [hs.1],hs.2.map inj⟩
  obtain ⟨a,ha⟩ := missing hs
  obtain ⟨b,hb⟩ := missing h'
  have no : a∉s := (mem_remaining a s).mp (by simp [ha])
  have gap : f a∉s.map f := by simpa [List.mem_map,inj.eq_iff] using no
  have rel := (mem_remaining (f a) (s.map f)).mpr gap
  rw [hb,List.mem_singleton] at rel
  have pred : (fun x : Fin 7 => x != 0) ∘ f = (fun x => x != 0) := by
    funext x
    by_cases z : x=0
    · simp [z,zero]
    · have nz : f x≠0 := fun e => z (inj (e.trans zero.symm))
      simp only [Function.comp_apply,bne_iff_ne.mpr nz,bne_iff_ne.mpr z]
  change classKey (s.map f ++ remaining (s.map f)) = (classKey (s++remaining s)).map f
  have dec : s.map f++remaining (s.map f)=(s++remaining s).map f := by simp [ha,hb,rel]
  rw [dec]
  unfold classKey
  rw [List.dropWhile_map,List.takeWhile_map,pred,List.map_append]

private def encode (s : Six) (x : Fin 7) : Fin 7 := Fin.ofNat 7 ((tag s).idxOf x)
private def canonical : List Six := (List.range 7).map fun i => ((List.finRange 7).rotate i).take 6

private theorem normalize {u : ℕ→Six} {p : ℕ→Prop} (w : Walk u) (m : Marked u p)
    (i : Nat) (hi : p i) : ∃ v : ℕ→Six, Walk v ∧ Marked v p ∧ v i∈canonical := by
  have ck : states.all (fun s => decide (Function.Injective (encode s) ∧ encode s 0=0 ∧
    s.map (encode s)∈canonical))=true := by native_decide
  obtain ⟨inj,z,can⟩ := of_decide_eq_true (List.all_eq_true.mp ck (u i) (mem_states (m.1 i hi)))
  let f := encode (u i)
  let v (j : Nat) := (u j).map f
  refine ⟨v,?_,⟨?_,?_⟩,can⟩
  · intro j
    obtain ⟨a,eq⟩ := w j
    exact ⟨f a,by simp [v,eq,step,List.map_tail]⟩
  · intro j hj
    exact ⟨by simp [v,(m.1 j hj).1],(m.1 j hj).2.map inj⟩
  · intro j k hj hk eq
    apply m.2 j k hj hk
    change tag ((u j).map f)=tag ((u k).map f) at eq
    rw [map_tag f inj z _ (m.1 j hj),map_tag f inj z _ (m.1 k hk)] at eq
    exact List.map_injective_iff.mpr inj eq

/-- All extremal masks must be ten nonempty rows, with three missing
marks in total relative to ten full rows. -/
private def profiles : Nat → Nat → List (List Nat)
  | 0, d => if d=0 then [[]] else []
  | k+1, d => (List.range (min d 5+1)).flatMap fun e =>
    (profiles k (d-e)).map ((6-e)::·)

private theorem profile_absurd {u : ℕ→Six} {p : ℕ→Prop} (w : Walk u) (m : Marked u p)
    (i : Nat) {ns : List Nat} (hn : ns∈profiles 10 3) (marks : rowsMarked p i ns) : False := by
  have start : p i := by
    cases ns with
    | nil =>
      have empty : []∉profiles 10 3 := by decide +kernel
      exact (empty hn).elim
    | cons n ns =>
      have pos : (profiles 10 3).all (fun l => l.all (fun j => decide (0<j)))=true := by native_decide
      have pn := of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp pos (n::ns) hn) n List.mem_cons_self)
      simpa using marks.1 0 pn
  obtain ⟨v,wv,mv,small⟩ := normalize w m i start
  have nz : ∀j∈ns,0<j := by
    have tb : (profiles 10 3).all (fun l => l.all (fun j => decide (0<j)))=true := by native_decide
    exact fun j hj => of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp tb ns hn) j hj)
  have cert : (profiles 10 3).all (fun l => canonical.all (fun z => !rowSearch l z []))=true := by
    native_decide
  have bad := List.all_eq_true.mp (List.all_eq_true.mp cert ns hn) _ small
  have yes := search_complete wv mv ns nz i marks [] (by simp)
  simp [yes] at bad

theorem interval66 {u : ℕ→Six} {p : ℕ→Prop} [DecidablePred p] (w : Walk u) (m : Marked u p)
    (i : Nat) : count p i 66≤56 := by
  by_contra! many
  have holes (j n : Nat) : (mask p j n).count false + count p j n=n := by
    induction n generalizing j with
    | zero => simp [mask,count]
    | succ n ih =>
      have e : count p j (n+1)=(if p j then 1 else 0)+count p (j+1) n := by
        unfold count
        conv_lhs => rw [show n+1=1+n by omega]
        simp only [Finset.card_filter,Finset.sum_range_add,Finset.range_one,Finset.sum_singleton,Nat.add_assoc,Nat.add_zero]
      rw [mask_cons,e]
      have h := ih (j+1)
      by_cases pp : p j <;> simp [pp] <;> omega
  have h := holes i 66
  have good : goodMask 0 (mask p i 66) := by simpa using admiss w m i 0 66 (by decide) (by simp)
  have member := admitted (mask p i 66) 0 9 (by decide) (by omega) good
  simp only [mask,List.length_map,List.length_range] at member
  have cert : (candidates 66 9 0).all (fun xs => (profiles 10 3).any (fun a => xs==rowsMask a))=true := by native_decide
  obtain ⟨ns,hn,eq⟩ := List.any_eq_true.mp (List.all_eq_true.mp cert _ member)
  exact profile_absurd w m i hn (unmask i 66 ns (eq_of_beq eq))

#print axioms interval66
end ResidualDensity.Density66

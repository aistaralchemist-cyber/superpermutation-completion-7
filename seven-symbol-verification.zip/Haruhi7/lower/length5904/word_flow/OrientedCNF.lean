import OrientedFormula

namespace ExactWordFlow.OrientedCNF
open Std.Sat SevenWordWindows SaturatedOrientation ExtremeWheelCut
open private widths from ExtremeWheelCut
open private atId optionArray incidence admits exactlyOne from OrientedFormula

private theorem mem_options {p : Choice} (wheel : p.1∈allRows) (parent : p.2∈p.1) :
    p∈options := by
  obtain ⟨w,hw,eq⟩:=List.mem_map.mp (List.mem_toFinset.mp wheel)
  have mem : p.2∈ResidualDensity.orbit w := List.mem_toFinset.mp (show p.2∈WheelContacts.wheel w by rw [eq]; exact parent)
  exact List.mem_flatMap.mpr ⟨w,hw,List.mem_map.mpr ⟨p.2,mem,by simp [eq]⟩⟩

private theorem option_idx {p : Choice} (mem : p∈options) :
    atId (options.idxOf p)=p := by
  have pos:=List.idxOf_lt_length_iff.mpr mem
  simp [atId,optionArray,List.getElem?_eq_getElem pos,List.getElem_idxOf]

private theorem admit_iff (A : Finset Block) (i : Nat) (hi : i<optionArray.size) :
    (admits A)[i]?.getD false=true ↔ Disjoint (children (atId i)) A := by
  simp [admits,atId,Array.getElem?_eq_getElem hi,Array.getElem?_map]

private theorem column_spec (A : Finset Block) {d : Block} (ids : List Nat)
    (eq : ids=((List.range optionArray.size).filter (fun i=>decide (d∈children (atId i)))).filter
      (fun i=>(admits A)[i]?.getD false)) (i : Nat) :
    i∈ids ↔ i<optionArray.size ∧ d∈children (atId i) ∧ Disjoint (children (atId i)) A := by
  simp only [eq,List.mem_filter,List.mem_range,decide_eq_true_eq]
  constructor
  · rintro ⟨⟨small,child⟩,accepted⟩
    exact ⟨small,child,(admit_iff A i small).mp accepted⟩
  · rintro ⟨small,child,dis⟩
    exact ⟨⟨small,child⟩,(admit_iff A i small).mpr dis⟩

private theorem one_eval (val : Nat→Bool) {ids : List Nat} (yes : ∃i∈ids,val i=true)
    (unique : ∀i∈ids,∀j∈ids,val i=true → val j=true → i=j) :
    ∀c∈exactlyOne ids,c.eval val=true := by
  intro c hc
  rcases List.mem_cons.mp hc with rfl|neg
  · obtain ⟨i,hit,value⟩:=yes
    rw [CNF.Clause.eval,CNF.Clause.literals_ofLiterals]
    exact List.any_eq_true.mpr ⟨(i,true),List.mem_map.mpr ⟨i,hit,rfl⟩,by simp [value]⟩
  · obtain ⟨i,hi,more⟩:=List.mem_flatMap.mp neg
    obtain ⟨j,hj,rfl⟩:=List.mem_map.mp more
    obtain ⟨jmem,test⟩:=List.mem_filter.mp hj
    have diff : i≠j:=(of_decide_eq_true test).ne
    have deny : val i=false ∨ val j=false := by
      cases ai:val i <;> cases aj:val j <;> simp_all
      exact diff (unique i hi j jmem ai aj)
    rcases deny with no|no <;> simp [CNF.Clause.eval,CNF.Clause.literals_ofLiterals,no]

/-- A disjoint exact covering by legal five-child options gives a Boolean
assignment. Neither an attachment order nor an acyclicity premise is needed. -/
theorem disjoint_sat {A : Finset Block} {T : Finset Choice}
    (valid : ∀p∈T, p.1∈allRows ∧ p.2∈p.1 ∧ Disjoint (children p) A)
    (covers : ∀d∈allClasses \ A,∃p∈T,d∈children p)
    (apart : ∀p∈T,∀q∈T,p≠q → Disjoint (children p) (children q)) :
    ∃val : Nat→Bool,(cnf A).eval val=true := by
  classical
  let val (i : Nat) := decide (∃p∈T,options.idxOf p=i)
  refine ⟨val,?_⟩
  change (((columnIds A).flatMap exactlyOne).toArray.all (fun c=>c.eval val))=true
  rw [List.all_toArray,List.all_eq_true]
  intro c hc
  obtain ⟨ids,member,inList⟩:=List.mem_flatMap.mp hc
  obtain ⟨entry,entryOk,idsEq⟩:=List.mem_map.mp member
  obtain ⟨raw,outside⟩:=List.mem_filter.mp entryOk
  obtain ⟨d,board,rfl⟩:=List.mem_map.mp raw
  have off : d∉A:=of_decide_eq_true outside
  have validD : d∈allClasses:=(allClasses.mem_sort (·≤·)).mp board
  have spec:=column_spec A ids idsEq.symm
  apply one_eval val _ _ c inList
  · obtain ⟨p,hp,child⟩:=covers d (Finset.mem_sdiff.mpr ⟨validD,off⟩)
    have ⟨row,parent,dis⟩:=valid p hp
    have mem:=mem_options row parent
    have bound : options.idxOf p<optionArray.size := by simpa [optionArray] using List.idxOf_lt_length_iff.mpr mem
    refine ⟨options.idxOf p,(spec _).mpr ⟨bound,?_,?_⟩,decide_eq_true ⟨p,hp,rfl⟩⟩
    · rw [option_idx mem]; exact child
    · rw [option_idx mem]; exact dis
  · intro i hi j hj ai aj
    obtain ⟨p,pm,rfl⟩:=of_decide_eq_true ai
    obtain ⟨q,qm,rfl⟩:=of_decide_eq_true aj
    have pv:=valid p pm
    have qv:=valid q qm
    have pp:=mem_options pv.1 pv.2.1
    have qq:=mem_options qv.1 qv.2.1
    have pd:=(spec _).mp hi |>.2.1
    have qd:=(spec _).mp hj |>.2.1
    rw [option_idx pp] at pd
    rw [option_idx qq] at qd
    by_cases eq : p=q
    · rw [eq]
    · exact (Finset.disjoint_left.mp (apart p pm q qm eq) pd qd).elim

/-- Any actual saturated choice of parent-child wheels induces a satisfying
assignment. The exact-cover test also admits some assignments without a
legal connected order, which preserves this implication. -/
theorem choices_sat {A : Finset Block} {W : Finset (Finset Block)} {T : Finset Choice}
    (legal : W⊆allRows) (chosen : Choices A allClasses W T) :
    ∃val : Nat→Bool,(cnf A).eval val=true := by
  exact disjoint_sat (fun p hp=>by
    obtain ⟨w,parent,off,_⟩:=chosen.valid p hp
    exact ⟨legal w,parent,off⟩) chosen.cover chosen.disjoint

theorem no_cover {A : Finset Block} {W : Finset (Finset Block)} (legal : W⊆allRows)
    (tight : A.card+5*W.card≤allClasses.card) (unsat : (cnf A).Unsat) :
    ¬SeedWheelCut.ClosedCover A allClasses W := by
  intro linked
  have width (w) (hw : w∈W) : w.card≤6 := widths _ (legal hw)
  obtain ⟨T,chosen⟩:=exists_choices A allClasses W width tight linked
  obtain ⟨val,yes⟩:=choices_sat legal chosen
  simpa [yes] using unsat val

#print axioms no_cover
end ExactWordFlow.OrientedCNF

import StrippedControl
namespace ExactWordFlow.StrippedControl
open SevenWordWindows RotationCore LiteralWheelCover ResidualDensity

def chosen : Finset Row := (offsets.map (fun i=>WheelContacts.wheel ((base.drop i).take 6))).toFinset
set_option maxRecDepth 30000 in
private theorem cover_certificate :
    chosen ⊆ ready base ∧ chosen.card=37 ∧ allClasses \ visited base ⊆ chosen.biUnion id := by
  native_decide

set_option maxRecDepth 30000 in
private theorem consecutive_check : ∀i∈List.range base.length,
    ¬(full ((base.drop i).take 6) ∧ (base.drop i).take 6=(base.drop (i+6)).take 6) := by
  native_decide

set_option maxRecDepth 30000 in
theorem disjoint_slots : offsets.length=37 ∧ offsets.IsChain (fun i j=>i+6≤j) ∧
    ∀i∈offsets, i+6≤base.length ∧ full ((base.drop i).take 6) := by native_decide

attribute [local irreducible] base offsets RotationCore.visited
theorem base_free : WheelFreeBoundary.WheelFree base := by
  rintro ⟨l,u,r,hu,eq⟩
  have width := hu.1
  have cover : l.length<base.length := by rw [eq]; simp; omega
  have no:=consecutive_check l.length (List.mem_range.mpr cover)
  rw [eq] at no
  have first : (((l++u++u++r).drop l.length).take 6)=u := by
    simp only [List.append_assoc,List.drop_left,List.take_append]
    simp [width]
  have second : (((l++u++u++r).drop (l.length+6)).take 6)=u := by
    rw [←width,←List.length_append]
    simp only [List.append_assoc (l++u),List.drop_left,List.take_append]
    simp [width]
  exact no ⟨first.symm ▸ hu,first.trans second.symm⟩

theorem exact_near_control : IsLeast {j : Nat | condition base j} 37 ∧ base.length+6*37=1509 := by
  obtain ⟨usable,count,covered⟩:=cover_certificate
  refine ⟨⟨⟨chosen,usable,count.le,covered⟩,?_⟩,by rw [verified_control.1]⟩
  intro j fit
  have h := WheelCoverCapacity.cover_bound fit
  have v : (visited base).card=535 := verified_control.2.2.1
  omega

#print axioms base_free
#print axioms exact_near_control
end ExactWordFlow.StrippedControl

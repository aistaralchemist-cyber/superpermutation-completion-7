import RotationReinsert

namespace ExactWordFlow.RotationCore
open SevenWordWindows ResidualDensity RotationReinsert

/-- Rotation classes visited by a six-letter context with six distinct symbols. -/
def visited (w : Block) : Finset Block :=
  (((anchors w).filter (fun u => decide (full u))).map tag).toFinset

/-- Classes in which all seven permutation windows actually occur in the core. -/
def complete (w : Block) : Finset Block :=
  let seen := (windows w).toFinset
  allClasses \ ((representatives.filter (fun p => decide (p∉seen))).map classKey).toFinset

theorem mem_visited (w c : Block) : c∈visited w ↔ HasAnchor w c := by
  simp [visited,HasAnchor,List.mem_map,List.mem_filter,and_assoc]

theorem mem_complete (w c : Block) : c∈complete w ↔
    c∈allClasses ∧ ∀p∈representatives, classKey p=c → p∈windows w := by
  unfold complete
  simp only [Finset.mem_sdiff,List.mem_toFinset,List.mem_map,List.mem_filter,
    decide_eq_true_eq,not_exists,not_and]
  grind

private theorem legal : ∀u∈states, tag u∈allClasses := by native_decide
private theorem end_class : ∀p∈representatives, full (dst p) ∧ tag (dst p)=classKey p := by
  native_decide
theorem board : allClasses.card=720 := by native_decide

theorem visited_subset (w : Block) : visited w ⊆ allClasses := by
  intro c hc
  obtain ⟨u,_,hu,rfl⟩ := (mem_visited w c).mp hc
  exact legal _ (mem_states hu)

theorem complete_subset (w : Block) : complete w ⊆ visited w := by
  intro c hc
  obtain ⟨inBoard,hit⟩ := (mem_complete w c).mp hc
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp inBoard)
  have occ := hit p hp rfl
  have ⟨fl,eq⟩ := end_class p hp
  exact (mem_visited _ _).mpr ⟨dst p,List.mem_cons_of_mem _ (List.mem_map_of_mem occ),fl,eq⟩

end ExactWordFlow.RotationCore

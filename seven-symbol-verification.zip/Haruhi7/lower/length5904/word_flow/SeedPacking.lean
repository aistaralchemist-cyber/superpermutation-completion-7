import SaturatedOrientation
namespace ExactWordFlow.SeedPacking
open SeedWheelCut SaturatedOrientation

/-- Every saturated extension of P partitions all nonroot vertices in
blocks of five. An entirely symbolic packing dual lower-bounds the price
of each allowed block; all those prices must fit inside V minus P. -/
theorem budget {α : Type*} [DecidableEq α] {P A V : Finset α}
    {W legal : Finset (Finset α)} (seed : P⊆A) (allowed : W⊆legal)
    (rows : ∀w∈W,w⊆V ∧ w.card≤6) (tight : A.card+5*W.card≤V.card)
    (linked : ClosedCover A V W) (weight : α→Nat) (K : Nat)
    (price : ∀w∈legal,∀p∈w,Disjoint (w.erase p) P → K≤∑v∈w.erase p,weight v) :
    ∃n : Nat,(V \ A).card=5*n ∧ K*n≤∑v∈V \ P,weight v := by
  classical
  obtain ⟨T,h⟩:=exists_choices A V W (fun w hw=>(rows _ hw).2) tight linked
  have partition : T.biUnion children=V \ A := by
    ext x
    constructor
    · intro hx
      obtain ⟨p,hp,hit⟩:=Finset.mem_biUnion.mp hx
      have ⟨wheel,_,off,_⟩:=h.valid p hp
      exact Finset.mem_sdiff.mpr ⟨(rows _ wheel).1 ((Finset.erase_subset ..) hit),
        fun old=>Finset.disjoint_left.mp off hit old⟩
    · intro hx
      obtain ⟨p,hp,hit⟩:=h.cover _ hx
      exact Finset.mem_biUnion.mpr ⟨p,hp,hit⟩
  have distinct:=fun p hp q hq neq=>h.disjoint p hp q hq neq
  refine ⟨T.card,?_,?_⟩
  · rw [←partition,Finset.card_biUnion distinct]
    have each (p) (hp : p∈T) : (children p).card=5 := by
      have ⟨_,member,_,size⟩:=h.valid p hp
      exact (Finset.card_erase_of_mem member).trans (by omega)
    calc ∑p∈T,(children p).card = ∑p∈T,5 := Finset.sum_congr rfl each
         _ = _ := by simp [Nat.mul_comm]
  · have low : (∑p∈T,K)≤∑p∈T,∑v∈children p,weight v := by
      apply Finset.sum_le_sum
      intro p hp
      have ⟨wheel,member,off,_⟩:=h.valid p hp
      exact price _ (allowed wheel) _ member (off.mono_right seed)
    have sub : V \ A⊆V \ P := fun x hx=>Finset.mem_sdiff.mpr ⟨(Finset.mem_sdiff.mp hx).1,
      fun present=>(Finset.mem_sdiff.mp hx).2 (seed present)⟩
    rw [←Finset.sum_biUnion distinct,partition] at low
    simpa [Nat.mul_comm] using low.trans (Finset.sum_le_sum_of_subset sub)

#print axioms budget
end ExactWordFlow.SeedPacking

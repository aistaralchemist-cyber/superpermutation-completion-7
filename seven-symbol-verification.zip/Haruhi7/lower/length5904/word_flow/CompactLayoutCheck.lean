import CompactLayout

namespace ExactWordFlow.CompactWordCircuit

set_option maxRecDepth 100000 in
theorem checked_layout :
    (layout.pieces.flatMap (fun p=>p.log.toList)) = (goalTape true).body.toList ∧
    alignedAt 0 layout.pieces = true ∧
    claims (goalTape true).body.toList = layout.clauses := by native_decide

theorem layout_parts {T : Test} (h : admits T 0 (goalTape true).body.toList) :
    ∀p∈layout.pieces, admits T p.base p.log.toList :=
  all_parts checked_layout.2.1 (checked_layout.1 ▸ h)

end ExactWordFlow.CompactWordCircuit

import VirtualFrontierTransfer
import Mixed277

namespace ExactWordFlow.MixedRootsExcluded
open SevenWordWindows ResidualDensity ResidualRoutes RotationComponentCount WheelBaseResidual
open RotationCore CoreAssembly EmbeddedWheels VirtualFrontierTransfer

theorem blocked : SeedFailure := by
  have same : SixRoots277.roots=Mixed277.roots:=by native_decide
  intro R root z hz p hp W legal size
  exact Mixed277.no_seed (same ▸ root) hz hp legal size

/-- The mixed 277 and 35 branch is excluded without any assumption about
an embedding of 92 short wheels or a census of the endpoints of the word. -/
theorem excludes_route {s t : Block} {es : List Block} (r : DirectedEuler.Route src dst s es t)
    (width : ∀e∈es,e.length=7) (len : es.length=277) (many : 236≤classCount s es) :
    ¬RootFiberTransport.possible (touched (s::es.map dst)) := no_mixed blocked r width len many

#print axioms blocked
end ExactWordFlow.MixedRootsExcluded

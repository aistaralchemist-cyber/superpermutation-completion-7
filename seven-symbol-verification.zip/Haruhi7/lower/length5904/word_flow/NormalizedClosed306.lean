import BaseWheelFrontier92
import FusedPacked93

namespace ExactWordFlow.NormalizedClosed306
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence RotationCore
open EmbeddedWheels WeightedMarks ExtremeWheelCut
open private normalized_rows from PathTurnsGap

theorem profile : FusedAny.profileOK 306 260=true := by native_decide

theorem certificate {Y : Multiset Block} {ws : List Block} {s t : Block}
    (fw : ∀w∈ws,full w) (h : Feasible (Y+turns ws) s t)
    (budget : (Y+turns ws).card≤858) (n : ws.length=92)
    (check : Finset Block→Bool) (checks : FusedAny.check 306 check=true) :
    ∃P,check P=true ∧ ∃W⊆allRows, W.card≤92 ∧ SeedWheelCut.ClosedCover P allClasses W := by
  obtain ⟨es,r,bag,len,cols,_⟩:=WheelBaseResidual.pure_92 fw h budget n
  have flow : Feasible ((↑es : Multiset Block)+turns ws) s t := bag ▸ h
  have wd (e) (he : e∈es) : e.length=7:=flow.edges_seven e (Multiset.mem_add.mpr (Or.inl he))
  obtain ⟨f,bij,zero,k,norm⟩:=FusedAny.route_coverage (by decide) profile check checks r wd (by omega) cols.ge
  obtain ⟨W,legal,size,covered⟩:=normalized_rows flow r fw bij zero
  obtain ⟨Z,leg,ct,closed⟩:=NearRootMoves.transport legal covered (List.replicate k 7)
  exact ⟨_,norm,_,leg,by omega,closed⟩

end ExactWordFlow.NormalizedClosed306

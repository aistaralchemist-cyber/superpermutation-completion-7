import NearHardRoots

namespace ExactWordFlow.Cap94Data
open SevenWordWindows NearHardRoots RotationCore

def words := (include_str "hard294-words.txt").trimAscii.toString.splitOn "\n"
def hard := words.map (fun w=>visited (digits w))

end ExactWordFlow.Cap94Data

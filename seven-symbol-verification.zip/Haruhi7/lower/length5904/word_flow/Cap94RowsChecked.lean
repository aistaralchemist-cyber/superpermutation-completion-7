import Cap94Catalog

namespace ExactWordFlow.Cap94Catalog
set_option maxHeartbeats 0 in
theorem rows_ok : checkedRows=true := by native_decide
#print axioms rows_ok
end ExactWordFlow.Cap94Catalog

import ExtremeWheelCut

namespace ExactWordFlow.AveragePrice
open SevenWordWindows ExtremeWheelCut

variable (rename : Block→Block→Block) (five : Finset Block)
variable (row : Block→Finset Block) (rootTag : Block→Block)
variable (latin : (∀x∈allClasses,allClasses.image (fun g=>rename g x)=allClasses) ∧
    (∀g∈allClasses,allClasses.image (rename g)=allClasses))
variable (geometry : allClasses.card=720 ∧ five⊆allClasses ∧ five.card=5 ∧
    ∀g∈allClasses,row g∈allRows ∧ rootTag g∈row g ∧
      five.image (rename g)=(row g).erase (rootTag g))


private theorem injective_on {f : Block→Block} (hits : allClasses.image f=allClasses) :
    Set.InjOn f ↑allClasses :=
  Finset.card_image_iff.mp (congrArg Finset.card hits)

include latin in
private theorem sum_renames (price : Block→ℝ) (S : Finset Block) (eligible : S⊆allClasses) :
    (∑g∈allClasses,∑x∈S,price (rename g x))=S.card*(∑x∈allClasses,price x) := by
  rw [Finset.sum_comm]
  have inner (x) (hx : x∈S) :
      (∑g∈allClasses,price (rename g x))=∑v∈allClasses,price v := by
    have hit:=latin.1 x (eligible hx)
    calc _ = ∑v∈allClasses.image (fun g=>rename g x),price v := (Finset.sum_image (injective_on hit)).symm
         _ = _ := by rw [hit]
  rw [Finset.sum_congr rfl inner]
  simp

include latin in
private theorem outside_image {A : Finset Block} (board : A⊆allClasses) {g : Block}
    (hg : g∈allClasses) :
    (allClasses\A).image (rename g)=allClasses\A.image (rename g) := by
  have onto:=latin.2 g hg
  have inj:=injective_on onto
  ext x
  constructor
  · intro hx
    obtain ⟨y,hy,rfl⟩:=Finset.mem_image.mp hx
    obtain ⟨whole,out⟩:=Finset.mem_sdiff.mp hy
    apply Finset.mem_sdiff.mpr
    constructor
    · exact onto ▸ Finset.mem_image_of_mem (rename g) whole
    · intro h
      obtain ⟨z,hz,hEq⟩:=Finset.mem_image.mp h
      exact out (inj (board hz) whole hEq ▸ hz)
  · intro hx
    obtain ⟨whole,out⟩:=Finset.mem_sdiff.mp hx
    rw [←onto] at whole
    obtain ⟨y,hy,rfl⟩:=Finset.mem_image.mp whole
    exact Finset.mem_image_of_mem _ (Finset.mem_sdiff.mpr
      ⟨hy,fun old=>out (Finset.mem_image_of_mem _ old)⟩)

include latin geometry in
/-- For every *fixed* table of prices, even with signed real entries,
a 390-tag support has a relabelling fixing 0 whose 330 outside tags cost
at most 66 unrestricted five-child options. The relabelling can depend
on the table. No path feasibility assumption is required. -/
theorem obstruction (price : Block→ℝ) (K : ℝ) (A : Finset Block) (board : A⊆allClasses)
    (size : A.card=390) (cap : ∀w∈allRows,∀p∈w,∑x∈w.erase p,price x≤K) :
    ∃g∈allClasses, (∑x∈allClasses\A.image (rename g),price x)≤66*K := by
  obtain ⟨total,fiveIn,fiveSize,choices⟩:=geometry
  have each (g) (hg : g∈allClasses) : (∑x∈five,price (rename g x))≤K := by
    obtain ⟨rwleg,pt,img⟩:=choices g hg
    have compatible := cap _ rwleg _ pt
    rw [←img,Finset.sum_image] at compatible
    · exact compatible
    · exact (injective_on (latin.2 g hg)).mono fiveIn
  have bound:=Finset.sum_le_sum each
  rw [sum_renames rename latin price five fiveIn,Finset.sum_const,total,fiveSize] at bound
  have mass : (allClasses\A).card=330 := by rw [Finset.card_sdiff_of_subset board,total,size]
  by_contra! none
  have large (g) (hg : g∈allClasses) : 66*K<∑x∈allClasses\A,price (rename g x) := by
    have h:=none g hg
    rw [←outside_image rename latin board hg,Finset.sum_image] at h
    · exact h
    · exact (injective_on (latin.2 g hg)).mono Finset.sdiff_subset
  have existsTag : allClasses.Nonempty := Finset.card_pos.mp (by omega)
  have conflict:=Finset.sum_lt_sum_of_nonempty existsTag large
  rw [sum_renames rename latin price (allClasses\A) Finset.sdiff_subset,Finset.sum_const,total,mass] at conflict
  norm_num at bound conflict
  linarith

#print axioms obstruction
end ExactWordFlow.AveragePrice

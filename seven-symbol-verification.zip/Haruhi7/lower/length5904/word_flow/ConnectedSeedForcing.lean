import SeedComponents

namespace ExactWordFlow.MultipleRootContacts
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- A wheel has two distinct known anchors connected by a chain of partial
exceptional seeds. The two anchors need not lie on the same exceptional cycle. -/
def blockedRow (E : Finset (Perm X)) (seed : Perm X→Finset Y) (w : Finset Y) : Prop :=
  ∃a∈w ∩ E.biUnion seed,∃b∈w ∩ E.biUnion seed,a≠b ∧ component E seed a=component E seed b

/-- Contract every connected seed component. Even with disconnected
exceptional cycles, all wheels blocked after contraction together account
for at most 8g unanchored rotation tags. -/
theorem connected_seed_forcing {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (E : Finset (Perm X)) (known : E⊆h.cycleFactorsFinset) (seed : Perm X→Finset Y)
    (observed : ∀c∈E,seed c⊆c.support.image tag) (S : Finset Y)
    (width : ∀w∈h.cycleFactorsFinset,w∉E → w.support.card≤6)
    (required : ∀j∈S,∀w∈h.cycleFactorsFinset,w∉E → j∈w.support.image tag →
      blockedRow E seed (w.support.image tag)) :
    (S \ E.biUnion (fun c=>c.support.image tag)).card ≤ 8*g := by
  classical
  let H:=h.cycleFactorsFinset
  let T (c : Perm X):=c.support.image tag
  let A:=E.biUnion T
  let outside:=S \ A
  let W:=(H \ E).filter fun c=>(T c ∩ outside).Nonempty
  let δ (c : Perm X):=c.support.card-(if c∈E then (T c).card else componentCount E seed (T c))
  have cap : (∑c∈H,δ c)≤2*g:=seed_components start oneOrbit tag onto rot classes genus E known seed observed
  have into : W⊆H:= (Finset.filter_subset _ _).trans Finset.sdiff_subset
  have off (w) (hw : w∈W) : w∉E:=(Finset.mem_sdiff.mp (Finset.mem_filter.mp hw).1).2
  have seeds : E.biUnion seed⊆A:=by
    intro j hj
    obtain ⟨c,hc,hit⟩:=Finset.mem_biUnion.mp hj
    exact Finset.mem_biUnion.mpr ⟨c,hc,observed c hc hit⟩
  have row (w) (hw : w∈W) : blockedRow E seed (T w):=by
    obtain ⟨j,hj⟩:=(Finset.mem_filter.mp hw).2
    obtain ⟨a,b⟩:=Finset.mem_inter.mp hj
    exact required j (Finset.mem_sdiff.mp b).1 w (into hw) (off w hw) a
  have each (w) (hw : w∈W) : 1≤δ w := by
    obtain ⟨a,ha,b,hb,ne,same⟩:=row w hw
    have imageL : ((T w).image (component E seed)).card<(T w).card:=by
      have upper:=Finset.card_image_le (s:=T w) (f:=component E seed)
      by_contra! n
      exact ne ((Finset.injOn_of_card_image_eq (le_antisymm upper n)) (Finset.mem_inter.mp ha).1
        (Finset.mem_inter.mp hb).1 same)
    have states : (T w).card≤w.support.card:=Finset.card_image_le
    simp only [δ,ite_eq_right (off w hw),componentCount]
    omega
  have howmany : W.card≤2*g:=by
    calc
      W.card=∑_∈W,1:=by simp
      _≤∑c∈W,δ c:=Finset.sum_le_sum each
      _≤∑c∈H,δ c:=Finset.sum_le_sum_of_subset into
      _≤2*g:=cap
  have cover : outside ⊆ W.biUnion (fun c=>T c∩outside):=by
    intro j hj
    obtain ⟨w,hw,hit⟩:=tag_covered start oneOrbit tag onto rot classes j
    have notE : w∉E:=fun inside=>(Finset.mem_sdiff.mp hj).2 (Finset.mem_biUnion.mpr ⟨w,inside,hit⟩)
    have member:=Finset.mem_inter.mpr ⟨hit,hj⟩
    exact Finset.mem_biUnion.mpr ⟨w,Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨hw,notE⟩,j,member⟩,member⟩
  have four (w) (hw : w∈W) : (T w∩outside).card≤4:=by
    obtain ⟨a,ha,b,hb,ne,_⟩:=row w hw
    obtain ⟨aw,ao⟩:=Finset.mem_inter.mp ha
    obtain ⟨bw,bo⟩:=Finset.mem_inter.mp hb
    have lo : ({a,b} : Finset Y)⊆T w:=by
      intro j hj
      simp only [Finset.mem_insert, Finset.mem_singleton] at hj
      rcases hj with rfl|rfl
      · exact aw
      · exact bw
    have sub : T w∩outside⊆T w \ {a,b}:=by
      intro j hj
      obtain ⟨hwj,ho⟩:=Finset.mem_inter.mp hj
      refine Finset.mem_sdiff.mpr ⟨hwj,?_⟩
      have missing:=(Finset.mem_sdiff.mp ho).2
      simp only [Finset.mem_insert,Finset.mem_singleton]
      rintro (rfl|rfl)
      · exact missing (seeds ao)
      · exact missing (seeds bo)
    have lim:=Finset.card_le_card sub
    rw [Finset.card_sdiff_of_subset lo,Finset.card_pair ne] at lim
    have six : (T w).card≤6:=Finset.card_image_le.trans (width w (into hw) (off w hw))
    omega
  have n:=(Finset.card_le_card cover).trans Finset.card_biUnion_le
  have bound:=Finset.sum_le_card_nsmul W (fun w=>(T w∩outside).card) 4 four
  simp only [smul_eq_mul] at bound
  change outside.card≤8*g
  omega

#print axioms connected_seed_forcing
end ExactWordFlow.MultipleRootContacts

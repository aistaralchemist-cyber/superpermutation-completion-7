import EqualityComponent91

namespace ExactWordFlow.StoppingCriterion
open SevenWordWindows SuperpermutationBounds RotationCore RotationComponentCount

/-- The original seven-symbol optimum expressed as one bound on all words. -/
theorem optimum_iff_ceiling :
    SuperpermBridge.HR.Ssuper 7 = 5905 ↔ Target107.ceiling 1501 90 :=
  Target107.goal_iff_minimum.symm.trans EqualityComponent91.ceiling_equivalence

/-- All completion thresholds covered by the current component bound. -/
theorem minimum_length {k : Nat} (lo : 91 ≤ k) (hi : k ≤ 720) :
    IsLeast (lengthsFor k) (SuperpermBridge.HR.Ssuper 7 - 7 * (720-k)) :=
  ComponentCurve.completion_curve (@EqualityComponent91.component_limit) k (by omega) lo hi

/-- Restoring the 629 remaining classes adds 4403 letters to the minimum. -/
theorem minimum_offset_91 {d : Nat} (h : IsLeast (lengthsFor 91) d) :
    d + 4403 = SuperpermBridge.HR.Ssuper 7 := by
  have exactMin := minimum_length (k:=91) (by decide) (by decide)
  have eq : d = SuperpermBridge.HR.Ssuper 7 - 4403 := h.unique exactMin
  obtain ⟨w, hw, len⟩ := SuperpermBridge.exists_covers_length_eq (by decide : 0 < 7)
  have floor := SuperpermLowerBounds.covers_lower_bound_7_k16_native w hw
  omega

theorem optimum_iff_minimum_91 :
    SuperpermBridge.HR.Ssuper 7 = 5905 ↔ IsLeast (lengthsFor 91) 1502 := by
  constructor
  · intro h
    simpa [h] using minimum_length (k:=91) (by decide) (by decide)
  · intro h
    have eq := minimum_offset_91 h
    omega

/-- The shorter decision requires a component bound for the same budget. -/
theorem threshold_at_cap (k : Nat) (small : k ≤ 720)
    (cap : ∀ {X : Multiset Block} {s t : Block}, Feasible X s t →
      X.card ≤ 858 → (occupied X s).card ≤ k) :
    (∃ w : Block, Covers w ∧ w.length ≤ 5904) ↔ BudgetCoreCurve.atLength (864+7*k) k :=
  BudgetCoreCurve.threshold 858 k small cap

theorem zero_if_certified
    (cap : ∀ {X : Multiset Block} {s t : Block}, Feasible X s t →
      X.card ≤ 858 → (occupied X s).card ≤ 0) :
    (∃ w : Block, Covers w ∧ w.length ≤ 5904) ↔
      ∃ v : Block, v.length = 864 ∧ (visited v).card = 720 := by
  simpa [BudgetCoreCurve.atLength] using threshold_at_cap 0 (by decide) cap

#print axioms optimum_iff_ceiling
#print axioms optimum_iff_minimum_91
#print axioms zero_if_certified
end ExactWordFlow.StoppingCriterion

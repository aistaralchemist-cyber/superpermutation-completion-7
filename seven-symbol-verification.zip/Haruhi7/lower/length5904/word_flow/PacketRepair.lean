import PacketSpelling
import PacketJoin
import Transfer5901

namespace ExactWordFlow.PacketRepair
open SevenWordWindows SuperpermutationBounds ResidualRoutes
open private required_size from WordFlow

/-- Components of the remaining graph that carry at least one mandatory edge. -/
noncomputable def groups (A : Multiset Block) : Finset (Component (required+A)) := by
  classical exact (required.map (fun p => label (required+A) (src p))).toFinset

private theorem member {A : Multiset Block} {q : Component (required+A)} :
    q∈groups A ↔ ∃p∈required,label (required+A) (src p)=q := by
  classical simp [groups]

private theorem nonempty (A : Multiset Block) : (groups A).Nonempty := by
  have pm : List.finRange 7∈required := (mem_reps _).mpr ⟨by simp,List.nodup_finRange _⟩
  exact ⟨_,member.mpr ⟨_,pm,rfl⟩⟩

private theorem occurs {A : Multiset Block} {q : Component (required+A)} {w e : Block}
    (record : (↑(windows w) : Multiset Block)=part (required+A) q)
    (he : e∈required) (hq : label (required+A) (src e)=q) : List.IsInfix e w := by
  have hit : e∈(↑(windows w) : Multiset Block) := record ▸
    in_part.mpr ⟨Multiset.mem_add.mpr (Or.inl he),hq⟩
  obtain ⟨u,v,eq⟩:=RotationReinsert.window_occurs w hit
  exact ⟨u,v,eq.symm⟩

/-- Spell the mandatory pieces, attaching every new circuit with a
one-letter overlap. One piece may contain both open endpoints. -/
theorem repair {A : Multiset Block} {s t : Block} (start : s.length=6)
    (width : ∀e∈A,e.length=7) (balance : A.map src+{t}=A.map dst+{s}) :
    ∃w : Block, Covers w ∧ w.length≤5046+A.card+5*((groups A).card-1) := by
  classical
  let Y:=required+A
  let K (q : Component Y):=(part Y q).card
  let Q:=groups A
  let home:=label Y s
  let q₀:=if home∈Q then home else (nonempty A).choose
  have qmem : q₀∈Q := by
    dsimp only [q₀]
    split
    next h => exact h
    next => exact (nonempty A).choose_spec
  have away {q} (hq : q∈Q.erase q₀) : q≠home := by
    obtain ⟨ne,main⟩:=Finset.mem_erase.mp hq
    rintro rfl
    exact ne (by simp [q₀,main])
  obtain ⟨p,hp,lab⟩:=member.mp qmem
  obtain ⟨w,wl,ww,_⟩:=PacketSpelling.piece start width balance hp 0
  rw [lab] at wl ww
  have wl' : w.length=K q₀+6 := wl
  let P (q : Component Y) (e : Block):=e∈required ∧ label Y (src e)=q
  have ready (q) (hq : q∈Q.erase q₀) (a : Fin 7) :
      ∃v : Block, v.length=K q+5 ∧ ∀e,P q e → List.IsInfix e (a::v) := by
    obtain ⟨f,hf,lq⟩:=member.mp (Finset.mem_erase.mp hq).2
    obtain ⟨v,vl,rec,head⟩:=PacketSpelling.piece start width balance hf a
    rw [lq] at vl rec head
    have hd:=head (away hq)
    cases v with
    | nil => simp at hd
    | cons b v =>
      have eq : b=a := by simpa using hd
      subst b
      refine ⟨v,?_,fun e he => occurs rec he.1 he.2⟩
      change (a::v).length=K q+6 at vl
      simp only [List.length_cons] at vl
      omega
  obtain ⟨z,length,keep,covered⟩:=PacketJoin.glue (Q.erase q₀) K P w (by
    intro empty
    rw [empty] at wl'
    simp at wl') ready
  refine ⟨z,?_,?_⟩
  · intro e len nd
    have he : e∈required := (mem_reps e).mpr ⟨len,nd⟩
    have hq : label Y (src e)∈Q := member.mpr ⟨e,he,rfl⟩
    have contains : List.IsInfix e z := by
      by_cases eq : label Y (src e)=q₀
      · exact (occurs ww he eq).trans keep.isInfix
      · exact covered _ (Finset.mem_erase.mpr ⟨eq,hq⟩) e ⟨he,rfl⟩
    obtain ⟨u,v,h⟩:=contains
    exact ⟨u,v,h.symm⟩
  · let U:=(Y.map (fun e=>label Y (src e))).toFinset
    have seen (e) (h : e∈Y) : label Y (src e)∈U :=
      Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,h,rfl⟩)
    have sub : Q⊆U := by
      intro q hq
      obtain ⟨e,he,le⟩:=member.mp hq
      exact le ▸ seen e (Multiset.mem_add.mpr (Or.inl he))
    have lim : ∑q∈Q,K q ≤ Y.card := by
      calc
        _ ≤ ∑q∈U,K q := Finset.sum_le_sum_of_subset sub
        _ = Y.card := sum_part_card Y U seen
    have sumK:=Finset.sum_erase_add Q K qmem
    have card:=Finset.card_erase_of_mem qmem
    rw [length,wl',Finset.sum_add_distrib, Finset.sum_const, smul_eq_mul] 
    change (∑q∈Q,K q) ≤ (required+A).card at lim
    rw [Multiset.card_add,required_size] at lim
    change _ ≤ 5046+A.card+5*(Q.card-1)
    omega

/-- Every balanced deletion in any feasible budget-858 flow pays this
minimum price in mandatory components, assuming the 5901 word lower bound. -/
theorem cut_budget (floor : Transfer5901.WordFloor 5901) {A B : Multiset Block} {s t : Block}
    (h : Feasible (A+B) s t) (budget : (A+B).card≤858) (bal : Essential.Balanced B) :
    B.card≤3+5*((groups A).card-1) := by
  obtain ⟨w,all,sz⟩:=repair h.start_six (fun e he=>h.edges_seven e (Multiset.mem_add.mpr (Or.inl he)))
    (Essential.restBalance h bal)
  have lower:=floor w all
  rw [Multiset.card_add] at budget
  omega

#print axioms repair
#print axioms cut_budget
end ExactWordFlow.PacketRepair

import ResidualIncidence

/-! An endpoint-independent way to charge repeated incidence in disjoint families
of residual components. The fibres of an arbitrary map are merged at once.
The argument is valid for the original window multiset, including dirty vertices. -/
namespace ExactWordFlow.ResidualIncidence
open ResidualDensity

section Grouping
variable {ι κ α : Type*} [DecidableEq ι] [DecidableEq κ] [DecidableEq α]

def members (Q : Finset ι) (p : ι → κ) (j : κ) : Finset ι :=
  Q.filter (fun i => p i = j)

def separate (Q : Finset ι) (C : ι → Finset α) (p : ι → κ) (j : κ) : ℕ :=
  ∑ i ∈ members Q p j, ((C i).card - 1)

def combined (Q : Finset ι) (C : ι → Finset α) (p : ι → κ) (j : κ) : Finset α :=
  (members Q p j).biUnion C

omit [DecidableEq ι] [DecidableEq α] in
theorem separate_sum (Q : Finset ι) (C : ι → Finset α) (p : ι → κ) :
    ∑ j ∈ Q.image p, separate Q C p j = ∑ i ∈ Q, ((C i).card-1) :=
  Finset.sum_fiberwise_of_maps_to (fun _ hi => Finset.mem_image_of_mem p hi) _

theorem contacts_grouped (D : Finset Block) (g : Block → ι) (p : ι → κ) (j : κ) :
    contacts D (p ∘ g) j = combined (D.image g) (contacts D g) p j := by
  ext c
  simp only [contacts,combined,members,Finset.mem_biUnion,Finset.mem_filter,
    Finset.mem_image,Function.comp_apply]
  constructor
  · rintro ⟨v,⟨hv,hj,fl⟩,rfl⟩
    exact ⟨g v,⟨⟨v,hv,rfl⟩,hj⟩,v,⟨hv,rfl,fl⟩,rfl⟩
  · rintro ⟨i,⟨_,hj⟩,v,⟨hv,hi,fl⟩,rfl⟩
    exact ⟨v,⟨hv,hi ▸ hj,fl⟩,rfl⟩

/-- The actual sum of class capacities after coarsening any residual labeling. -/
theorem partition_rank {X : Multiset Block} {s t : Block}
    (g : Block → ι) (p : ι → κ) (h : Feasible X s t)
    (constant : ∀ e∈X, g (src e)=g (dst e)) :
    let D := support X s
    let Q := D.image g
    719 ≤ ∑ j ∈ Q.image p, ((combined Q (contacts D g) p j).card - 1) := by
  dsimp only
  have bound := rank719 (p ∘ g) h (fun e he => congrArg p (constant e he))
  simpa only [Finset.image_image, ←contacts_grouped] using bound

/-- Inside each fibre, `loss j` units can be charged if they are certified
by counting distinct classes in the union. The same component is not
charged twice. The fibres themselves need not be disjoint as sets of classes. -/
theorem partition_loss {X : Multiset Block} {s t : Block}
    (g : Block → ι) (p : ι → κ) (h : Feasible X s t)
    (constant : ∀ e∈X, g (src e)=g (dst e)) (loss : κ → ℕ)
    (counts : let D := support X s; let Q := D.image g; let C := contacts D g
      ∀ j ∈ Q.image p, (combined Q C p j).card - 1 + loss j ≤ separate Q C p j) :
    let D := support X s
    let Q := D.image g
    719 + ∑ j∈Q.image p, loss j ≤ ∑ i∈Q, ((contacts D g i).card-1) := by
  have co := partition_rank g p h constant
  have total := Finset.sum_le_sum counts
  rw [Finset.sum_add_distrib,separate_sum] at total
  dsimp only at co ⊢
  omega

/-- Merge a chosen finite subfamily; all the other components keep their names.
This permits a local certificate even when the remaining overlap pattern is unknown. -/
theorem subfamily_loss {X : Multiset Block} {s t : Block}
    (g : Block → ι) (h : Feasible X s t)
    (constant : ∀ e∈X, g (src e)=g (dst e)) (T : Finset ι) (loss : ℕ)
    (live : T ⊆ (support X s).image g) (ne : T.Nonempty)
    (cert : let C := contacts (support X s) g
      (T.biUnion C).card - 1 + loss ≤ ∑ i∈T, ((C i).card-1)) :
    719 + loss ≤ ∑ i∈(support X s).image g, ((contacts (support X s) g i).card-1) := by
  classical
  obtain ⟨a,ha⟩ := ne
  let Q := (support X s).image g
  let C := contacts (support X s) g
  let p (i : ι) := if i∈T then a else i
  have home : a∈Q.image p := Finset.mem_image.mpr ⟨a,live ha,by simp [p]⟩
  have atHome : members Q p a=T := by
    ext i
    by_cases hit : i∈T
    · have hi : i∈Q := live hit
      simp [members,p,hit,hi]
    · have notA : i≠a := fun eq => hit (eq ▸ ha)
      simp [members,p,hit,notA]
  have other (j : ι) (hj : j∈Q.image p) (diff : j≠a) : members Q p j={j} := by
    obtain ⟨i,hi,eq⟩ := Finset.mem_image.mp hj
    have out : i∉T := fun inside => diff (eq.symm.trans (by simp [p,inside]))
    have ij : i=j := by simpa [p,out] using eq
    clear eq
    subst j
    ext k
    by_cases hit : k∈T
    · have neq : k≠i := fun eq => out (eq ▸ hit)
      simp [members,p,hit,diff.symm,neq]
    · simp [members,p,hit]
      exact fun eq => eq ▸ hi
  have counted (j) (hj : j∈Q.image p) :
      (combined Q C p j).card-1+(if j=a then loss else 0) ≤ separate Q C p j := by
    by_cases eq : j=a
    · subst j
      simpa only [combined,separate,atHome,ite_true] using cert
    · simp [combined,separate,other j hj eq,eq]
  have price := partition_loss g p h constant (fun j => if j=a then loss else 0) counted
  change 719 + ∑ j∈Q.image p, (if j=a then loss else 0) ≤ _ at price
  simpa only [Finset.sum_ite_eq',home,ite_true] using price

omit [DecidableEq ι] in
/-- Exact loss when every selected set meets a nonempty anchor A. It has
two parts: extra contacts inside the anchor, and repeat visits among new
classes contributed by different sets. Members may coincide as sets. -/
theorem anchor_account (A : Finset α) (B : Finset ι) (C : ι → Finset α)
    (nonempty : A.Nonempty) (meet : ∀i∈B, (C i ∩ A).Nonempty) :
    ((A ∪ B.biUnion C).card-1) + (∑ i∈B, ((C i ∩ A).card-1)) +
        ((∑ i∈B, (C i \ A).card) - ((B.biUnion C) \ A).card) =
      (A.card-1) + ∑ i∈B, ((C i).card-1) := by
  classical
  have row (i) (hi : i∈B) : (C i).card-1 = (C i \ A).card+((C i ∩ A).card-1) := by
    have r := Finset.card_sdiff_add_card (C i) A
    have u := Finset.card_union_add_card_inter (C i) A
    have m := Finset.card_pos.mpr (meet i hi)
    omega
  have outside : B.biUnion (fun i => C i \ A) = (B.biUnion C) \ A := by
    ext x
    simp only [Finset.mem_biUnion,Finset.mem_sdiff]
    constructor
    · rintro ⟨i,hi,hc,ha⟩
      exact ⟨⟨_,hi,hc⟩,ha⟩
    · rintro ⟨⟨i,hi,hc⟩,ha⟩
      exact ⟨_,hi,hc,ha⟩
  have sumOut : ((B.biUnion C) \ A).card ≤ ∑ i∈B, (C i \ A).card :=
    outside ▸ Finset.card_biUnion_le
  have assm := Finset.card_sdiff_add_card (B.biUnion C) A
  rw [Finset.union_comm] at assm
  rw [Finset.sum_congr rfl row,Finset.sum_add_distrib]
  have pos := Finset.card_pos.mpr nonempty
  omega

omit [DecidableEq κ] in
/-- Any one residual component can serve as the anchor, no matter which
component carries the two endpoints. -/
theorem anchor_loss {X : Multiset Block} {s t : Block}
    (g : Block → ι) (h : Feasible X s t)
    (constant : ∀ e∈X, g (src e)=g (dst e)) (a : ι) (B : Finset ι)
    (ha : a∈(support X s).image g) (other : a∉B) (live : B⊆(support X s).image g)
    (nonempty : (contacts (support X s) g a).Nonempty)
    (meet : ∀i∈B, (contacts (support X s) g i ∩ contacts (support X s) g a).Nonempty) :
    let C := contacts (support X s) g
    let A := C a
    719 + ((∑ i∈B, ((C i ∩ A).card-1)) +
        ((∑ i∈B, (C i \ A).card) - ((B.biUnion C) \ A).card))
      ≤ ∑ i∈(support X s).image g, ((C i).card-1) := by
  classical
  let C := contacts (support X s) g
  let A := C a
  have eq := anchor_account A B C nonempty meet
  apply subfamily_loss g h constant (insert a B) _ (Finset.insert_subset ha live)
    (Finset.insert_nonempty ..)
  dsimp only
  rw [Finset.biUnion_insert,Finset.sum_insert other]
  exact (Nat.add_assoc ..) ▸ eq.le

end Grouping

/-- A family built by inserting contact sets which meet the accumulated union.
Each recurrence counts the exact rank lost by the insertion. A set that
meets three previously accumulated classes costs two, even if it meets each
earlier set in only one class. -/
inductive Joined {α : Type*} [DecidableEq α] :
    List (Finset α) → Finset α → ℕ → Prop where
  | first (A : Finset α) (h : A.Nonempty) : Joined [A] A 0
  | attach {xs : List (Finset α)} {A : Finset α} {n : ℕ} (history : Joined xs A n)
      (B : Finset α) (cross : (B∩A).Nonempty) :
      Joined (B::xs) (B∪A) (n + ((B∩A).card - 1))

theorem Joined.account {α : Type*} [DecidableEq α] {xs : List (Finset α)} {U : Finset α}
    {n : ℕ} (j : Joined xs U n) :
    U.Nonempty ∧ U = xs.foldr (· ∪ ·) ∅ ∧
      (xs.map (fun F => F.card-1)).sum = (U.card-1)+n := by
  induction j with
  | first A h => simp [h]
  | @attach xs A n h B z ih =>
    have i := Finset.card_pos.mpr z
    have a := Finset.card_pos.mpr ih.1
    have b := Finset.card_le_card (Finset.inter_subset_left (s₁:=B) (s₂:=A))
    have u := Finset.card_le_card (Finset.subset_union_left (s₁:=B) (s₂:=A))
    have eqn := Finset.card_union_add_card_inter B A
    refine ⟨ih.1.mono Finset.subset_union_right,?_,?_⟩
    · simp only [List.foldr_cons,←ih.2.1]
    · simp only [List.map_cons,List.sum_cons,ih.2.2]
      omega

#print axioms partition_loss
#print axioms Joined.account
end ExactWordFlow.ResidualIncidence

import ComponentCount
import RotationClassesRequired
import CoreCounts

namespace ExactWordFlow.RotationSpan
open SevenWordWindows ResidualDensity DirectedEuler ResidualRoutes ResidualIncidence RotationComponentCount
open private required_data from ResidualIncidence
open private next_src rotate_mem key_rotate class_required from RotationClassesRequired
open scoped Classical

def terminals (X : Multiset Block) (s : Block) : Finset Block :=
  insert s ((X.map src).toFinset ∪ (X.map dst).toFinset)

def selected (X : Multiset Block) (S : Finset Block) :=
  X+required.filter fun e => classKey e∈S

theorem label_lift {X Y : Multiset Block} (le : X≤Y) {v w : Block}
    (eq : label X v=label X w) : label Y v=label Y w := by
  let P : Set Block := {a | label Y a=label Y v}
  have b (e) (he : e∈X) : src e∈P ↔ dst e∈P := by
    change label Y (src e)=_ ↔ label Y (dst e)=_
    rw [on_edge (Multiset.mem_of_le le he)]
  exact ((invariant P b eq).mp (show v∈P from rfl)).symm

private theorem both {X : Multiset Block} (s : Block) {e : Block} (he : e∈X) :
    src e∈terminals X s ∧ dst e∈terminals X s := by
  constructor
  · exact Finset.mem_insert_of_mem (Finset.mem_union_left _
      (Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,he,rfl⟩)))
  · exact Finset.mem_insert_of_mem (Finset.mem_union_right _
      (Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,he,rfl⟩)))

private def rep (u : Block) := u++((List.finRange 7).filter (fun a => a∉u))
private theorem rep_table : ∀u∈states, rep u ∈ representatives ∧ src (rep u)=u := by native_decide
private theorem rotated : ∀p∈representatives, ∀i∈List.range 7,classKey (p.rotate i)=classKey p := by native_decide

private theorem rotate_tag {p : Block} (hp : p∈required) (i : Nat) : classKey (p.rotate i)=classKey p := by
  have len:=((mem_reps p).mp hp).1
  rw [←List.rotate_mod]
  exact rotated p hp _ (List.mem_range.mpr (by rw [len]; exact Nat.mod_lt _ (by decide)))

theorem join_same {X : Multiset Block} {S : Finset Block} {u v : Block} (hu : full u) (hv : full v)
    (eq : tag u=tag v) (mem : tag u∈S) : label (selected X S) u=label (selected X S) v := by
  let Y:=selected X S
  have one (w : Block) (hw : full w) (hs : tag w∈S) : label Y w=label Y (src (tag w)) := by
    have ⟨pp,srcEq⟩:=rep_table w (mem_states hw)
    have chain (i : Nat) : label Y (src (rep w))=label Y (src ((rep w).rotate i)) := by
      induction i with
      | zero => simp
      | succ i ih =>
        have pr := rotate_mem pp i
        have keep : (rep w).rotate i∈Y := Multiset.mem_add.mpr (Or.inr
          (Multiset.mem_filter.mpr ⟨pr,by rw [rotate_tag pp]; exact hs⟩))
        rw [←List.rotate_rotate,next_src pr]
        exact ih.trans (on_edge keep)
    have lhs := chain (((rep w).takeWhile (· != 0)).length)
    rw [key_rotate,srcEq] at lhs
    exact lhs
  exact (one u hu mem).trans (eq ▸ (one v hv (eq ▸ mem)).symm)

theorem every_tag {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {c : Block} (mem : c∈allClasses) : ∃v∈terminals X s, full v ∧ tag v=c := by
  classical
  by_contra! no
  let P : Set Block := {v | full v → tag v≠c}
  have all (v : Block) (hv : v∈terminals X s) : v∈P := no v hv
  have closed (e) (he : e∈required+X) (start : src e∈P) : dst e∈P := by
    rcases Multiset.mem_add.mp he with req|more
    · obtain ⟨u,v,eq⟩:=required_data e req
      exact fun _ z => start u (eq.trans z)
    · exact all _ (both s more).2
  have cc : c∈required := class_required mem
  have one := h.reachable P (all s (Finset.mem_insert_self ..)) closed c (Multiset.mem_add.mpr (Or.inl cc))
  have data : ∀c∈allClasses, tag (src c)=c := by native_decide
  exact one (required_data c cc).1 (data c mem)

private theorem terminal_reachable {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {P : Set Block} (home : s∈P) (step : ∀e∈required+X,src e∈P → dst e∈P) :
    ∀v∈terminals X s,v∈P := by
  intro v hv
  rcases Finset.mem_insert.mp hv with rfl|rest
  · exact home
  rcases Finset.mem_union.mp rest with l|r
  · obtain ⟨e,he,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp l)
    exact h.reachable P home step _ (Multiset.mem_add.mpr (Or.inr he))
  · obtain ⟨e,he,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp r)
    have more : e∈required+X := Multiset.mem_add.mpr (Or.inr he)
    exact step e more (h.reachable P home step e more)

private theorem bridge {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (S : Finset Block) (unreached : ∃v∈terminals X s,label (selected X S) v≠label (selected X S) s) :
    ∃u∈terminals X s, ∃v∈terminals X s, full u ∧ full v ∧ tag u=tag v ∧
      label (selected X S) u=label (selected X S) s ∧ label (selected X S) v≠label (selected X S) s := by
  classical
  let A (x : Block) := label (selected X S) x=label (selected X S) s
  let M (c : Block) := ∃u∈terminals X s,full u ∧ tag u=c ∧ A u
  let P : Set Block := {x | (full x → M (tag x)) ∧ (¬full x → A x)}
  by_contra! no
  have agree (v : Block) (hv : v∈terminals X s) : v∈P ↔ A v := by
    constructor
    · intro hit
      by_cases clean : full v
      · obtain ⟨u,hu,fu,tagEq,ok⟩:=hit.1 clean
        exact no u hu v hv fu clean tagEq ok
      · exact hit.2 clean
    · intro ok
      exact ⟨fun good=>⟨v,hv,good,rfl,ok⟩,fun _ => ok⟩
  have start := (agree s (Finset.mem_insert_self ..)).mpr rfl
  have step (e) (he : e∈required+X) (srcIn : src e∈P) : dst e∈P := by
    rcases Multiset.mem_add.mp he with req | more
    · obtain ⟨fs,fd,eq⟩:=required_data e req
      exact ⟨fun _=>eq ▸ srcIn.1 fs, fun bad => (bad fd).elim⟩
    · obtain ⟨l,r⟩:=both s more
      have eq := on_edge (Multiset.mem_add.mpr (Or.inl more) : e∈selected X S)
      exact (agree _ r).mpr (eq.symm.trans ((agree _ l).mp srcIn))
  obtain ⟨v,hv,bad⟩:=unreached
  exact bad ((agree _ hv).mp (terminal_reachable h start step v hv))

noncomputable def reached (X : Multiset Block) (s : Block) (S : Finset Block) :=
  ((terminals X s).filter fun v=>label (selected X S) v=label (selected X S) s).image (label X)

private theorem reached_iff {X : Multiset Block} {s v : Block} {S : Finset Block} (hv : v∈terminals X s) :
    label X v∈reached X s S ↔ label (selected X S) v=label (selected X S) s := by
  classical
  constructor
  · intro hit
    obtain ⟨u,h,eq⟩:=Finset.mem_image.mp hit
    exact (label_lift (Multiset.le_add_right X _) eq.symm).trans (Finset.mem_filter.mp h).2
  · intro eq
    exact Finset.mem_image.mpr ⟨v,Finset.mem_filter.mpr ⟨hv,eq⟩,rfl⟩

private theorem sel_mono (X : Multiset Block) {A B : Finset Block} (sub : A⊆B) :
    selected X A ≤ selected X B := by
  unfold selected
  apply add_le_add_right
  apply Multiset.le_iff_count.mpr
  intro p
  by_cases yes : classKey p∈A
  · simp [yes,sub yes]
  · simp [Multiset.count_filter,yes]

private theorem rmono (X : Multiset Block) (s : Block) {A B : Finset Block} (sub : A⊆B) :
    reached X s A⊆reached X s B := by
  classical
  intro z hz
  obtain ⟨v,mem,rfl⟩:=Finset.mem_image.mp hz
  have ⟨terminal,eq⟩:=Finset.mem_filter.mp mem
  exact (reached_iff terminal).mpr (label_lift (sel_mono X sub) eq)

private theorem group_bound (X : Multiset Block) (s : Block) (S : Finset Block) :
    (reached X s S).card≤(occupied X s).card+1 := by
  classical
  have sub : reached X s S⊆insert (label X s) (occupied X s) := by
    intro z hz
    obtain ⟨v,mem,rfl⟩:=Finset.mem_image.mp hz
    rcases Finset.mem_insert.mp (Finset.mem_filter.mp mem).1 with rfl|rest
    · exact Finset.mem_insert_self ..
    by_cases home : label X v=label X s
    · exact Finset.mem_insert.mpr (Or.inl home)
    apply Finset.mem_insert_of_mem
    apply Finset.mem_erase.mpr
    refine ⟨home,?_⟩
    rcases Finset.mem_union.mp rest with hs|hd
    · exact Finset.mem_image_of_mem _ hs
    · obtain ⟨e,em,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp hd)
      rw [←on_edge em]
      exact Finset.mem_image_of_mem _ (Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,em,rfl⟩))
  exact (Finset.card_le_card sub).trans (Finset.card_insert_le ..)

private theorem extend {X : Multiset Block} {s t : Block} (h : Feasible X s t) (A : Finset Block)
    (bad : ∃v∈terminals X s, label (selected X A) v≠label (selected X A) s) :
    ∃c∈allClasses, c∉A ∧ (reached X s A).card<(reached X s (insert c A)).card := by
  classical
  obtain ⟨u,hu,v,hv,fu,fv,col,l,r⟩:=bridge h A bad
  let c:=tag u
  have new : c∉A := fun mem => r ((join_same fu fv col mem).symm.trans l)
  have inc : A ⊆ insert c A := Finset.subset_insert ..
  have vSeen := (join_same (X:=X) fu fv col (Finset.mem_insert_self c A)).symm.trans
    (label_lift (sel_mono X inc) l)
  have ck : c∈allClasses := List.mem_toFinset.mpr (List.mem_map.mpr
    ⟨rep u,(rep_table u (mem_states fu)).1,rfl⟩)
  exact ⟨c,ck,new,Finset.card_lt_card ((Finset.ssubset_iff_of_subset (rmono X s inc)).mpr
    ⟨label X v,(reached_iff hv).mpr vSeen,fun mem => r ((reached_iff hv).mp mem)⟩)⟩

/-- Starting with residual components alone, add one rotation class across
each cut. Each addition reaches at least one previously unreachable residual
component. Empty residual components are never charged. -/
theorem spanning {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    ∃ S⊆allClasses, S.card≤(occupied X s).card ∧
      ∀v∈terminals X s,label (selected X S) v=label (selected X S) s := by
  classical
  let N := (occupied X s).card
  have build (n : Nat) (A : Finset Block) (sub : A⊆allClasses) (paid : A.card+1≤(reached X s A).card)
      (fuel : N+1≤(reached X s A).card+n) :
      ∃ S⊆allClasses, S.card≤N ∧ ∀v∈terminals X s,label (selected X S) v=label (selected X S) s := by
    induction n generalizing A with
    | zero =>
      refine ⟨A,sub,by have:=group_bound X s A; omega,?_⟩
      intro v hv
      by_contra! no
      obtain ⟨c,_,_,lt⟩:=extend h A ⟨v,hv,no⟩
      have := group_bound X s (insert c A)
      omega
    | succ n ih =>
      by_cases done : ∀v∈terminals X s,label (selected X A) v=label (selected X A) s
      · exact ⟨A,sub,by have:=group_bound X s A; omega,done⟩
      push Not at done
      obtain ⟨c,yes,new,lt⟩:=extend h A done
      apply ih (insert c A) (Finset.insert_subset yes sub)
      · rw [Finset.card_insert_of_notMem new]; omega
      · omega
  have pos : 0<(reached X s ∅).card := Finset.card_pos.mpr
    ⟨label X s,(reached_iff (Finset.mem_insert_self s _ : s∈terminals X s)).mpr rfl⟩
  exact build (N+1) ∅ (Finset.empty_subset _) (by simpa using pos) (by omega)

/-- Euler spelling only needs these two facts: an anchor for every class
in the root component and membership of every selected mandatory edge. -/
theorem rooted_spanning {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) : ∃S⊆allClasses, S.card≤108 ∧
      (∀c∈allClasses, ∃u, full u ∧ tag u=c ∧ label (selected X S) u=label (selected X S) s) ∧
      (∀p∈representatives, classKey p∈S → label (selected X S) (src p)=label (selected X S) s) := by
  obtain ⟨S,sub,size,span⟩:=spanning h
  have count := (component_limit h budget).1
  refine ⟨S,sub,size.trans count,?_,?_⟩
  · intro c hc
    obtain ⟨u,hu,clean,key⟩:=every_tag h hc
    exact ⟨u,clean,key,span u hu⟩
  · intro p hp inS
    have inBoard:=sub inS
    obtain ⟨u,hu,clean,key⟩:=every_tag h inBoard
    have tab : ∀p∈representatives,tag (src p)=classKey p := by native_decide
    have here:=tab p hp
    exact (join_same (required_data p hp).1 clean (here.trans key.symm) (here ▸ inS)).trans (span u hu)

#print axioms spanning
#print axioms rooted_spanning
end ExactWordFlow.RotationSpan


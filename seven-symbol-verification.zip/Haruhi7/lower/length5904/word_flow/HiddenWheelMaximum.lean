import WheelMinimumBoundary
import CanonicalBaseSpare

namespace ExactWordFlow.HiddenWheelMaximum
open SevenWordWindows SuperpermutationBounds RotationCore RotationReinsert ResidualDensity
open WheelBaseResidual LiteralWheelCover WheelFreeBoundary

/-- A base can account for a boundary 1508-word within this many actual six-wheel insertions. -/
def Fits (b : Block) (k : Nat) : Prop :=
  (complete b).card=92 ∧ b.length+6*k=1508 ∧ condition b k

/-- All spellings of the same directed seven-window multiset from the same
initial six-context avoid a contiguous full six-wheel. -/
def Rigid (b : Block) : Prop := ∀z:Block,z.take 6=b.take 6 → bag z=bag b → WheelFree z

private theorem same_sets {z b : Block} (head:z.take 6=b.take 6) (edges:bag z=bag b) :
    visited z=visited b ∧ complete z=complete b ∧ ready z=ready b := by
  have eqmem (e : Block):e∈windows z ↔ e∈windows b:=by
    change e∈bag z ↔ e∈bag b
    rw [edges]
  have anchors_eq (u : Block):u∈anchors z↔u∈anchors b:=by
    simp only [anchors,head,List.mem_cons,List.mem_map,eqmem]
  refine ⟨?_,?_,?_⟩
  · ext c
    simp only [mem_visited,HasAnchor,anchors_eq]
  · ext c
    simp only [mem_complete,eqmem]
  · ext R
    simp only [mem_ready,anchors_eq]

private theorem alternate {b z : Block} {k : Nat} (fit:Fits b k)
    (head:z.take 6=b.take 6) (edges:bag z=bag b) : Fits z k := by
  obtain ⟨old,length,cond⟩:=fit
  obtain ⟨vis,comp,ready⟩:=same_sets head edges
  have lb:=LapSkeleton.completed_floor b
  have room : (good b).length≤b.length-6:=by rw [←windows_length];exact List.length_filter_le ..
  have n:=congrArg Multiset.card edges
  simp only [bag,Multiset.coe_card,windows_length] at n
  refine ⟨comp ▸ old,by omega,?_⟩
  simpa only [condition,ready,vis] using cond

/-- Removing a revealed six-square produces another boundary witness with
one more wheel available, even when other chosen wheels share its vertices. -/
private theorem grow {z : Block} {k : Nat} (fit:Fits z k) (has:¬WheelFree z) :
    ∃b,Fits b (k+1) := by
  classical
  obtain ⟨l,u,r,clean,rfl⟩:=Classical.not_not.mp has
  obtain ⟨done,size,opt⟩:=fit
  obtain ⟨rs,v,hist,cnt,all⟩:=(budget_iff _ k).mpr opt
  have joined:=Inserts.add clean hist
  refine ⟨l++u++r,?_,?_,(budget_iff _ _).mp ⟨_,v,joined,?_,all⟩⟩
  · rwa [WheelAccess.complete_step l u r clean] at done
  · have n:=clean.1
    simp only [List.length_append] at size ⊢
    omega
  · simp;omega

/-- At a maximum of the number of restored six-wheels, the wheel-free
condition is invariant under every Euler rearrangement of the base. -/
theorem rigid_of_max {b : Block} {k : Nat} (fits:Fits b k)
    (maximum : ∀z j,Fits z j → j≤k) : Rigid b := by
  intro z head edges
  by_contra has
  obtain ⟨next,larger⟩:=grow (alternate fits head edges) has
  have bad:=maximum next (k+1) larger
  omega

open private ordered from WheelAccess
open private wheel_table from WheelBaseResidual

/-- In a rigid base, deleting a full multiset wheel cannot leave a route from
the original start visiting its anchor. Otherwise it could be reinserted as
one contiguous square in another spelling of exactly the same seven-windows. -/
theorem no_removable_turn {b u t : Block} {es : List Block} (rigid : Rigid b)
    (long:6≤b.length) (clean:full u)
    (path:DirectedEuler.Route src dst (b.take 6) es t) (width:∀e∈es,e.length=7)
    (anchor:u∈b.take 6::es.map dst) (removed:bag b=↑es+↑(GlobalWheelRank.wheel u)) : False := by
  obtain ⟨w,_,start,windowsEq⟩:=spell_route path (by simp;omega) width
  have here : u∈anchors w:=by simpa [anchors,start,windowsEq] using anchor
  obtain ⟨l,r,old⟩:=(WheelAccess.anchor_iff _ _ clean).mp here
  subst w
  obtain ⟨head,pre,post,added,base⟩:=ordered l u r clean
  have bags : bag (l++u++u++r)=bag b:=by
    rw [removed,←windowsEq]
    simp only [bag,added,base,wheel_table u (mem_states clean),←Multiset.coe_add]
    ac_rfl
  exact (rigid _ (head.trans start) bags) ⟨l,u,r,clean,rfl⟩

/-- The universal exclusion problem needs only bases that retain the
wheel-free property under every rearrangement of their seven-windows. -/
theorem exact : (∃w:Block,Covers w ∧ w.length≤5904) ↔
    ∃b k,Fits b k ∧ Rigid b ∧ ∀z j,Fits z j → j≤k := by
  classical
  constructor
  · intro yes
    obtain ⟨b,k,_,done,sz,_,_,fit⟩:=WheelFreeBoundary.exact.mp yes
    let K:=(Finset.range 252).filter (fun j=>∃z,Fits z j)
    have choose (z j) (ok:Fits z j) : j∈K:=Finset.mem_filter.mpr
      ⟨Finset.mem_range.mpr (by have := ok.2.1;omega),⟨z,ok⟩⟩
    have live : K.Nonempty:=⟨k,choose b k ⟨done,sz,fit⟩⟩
    let m:=K.max' live
    have best : m∈K:=Finset.max'_mem ..
    obtain ⟨z,fz⟩:=(Finset.mem_filter.mp best).2
    have cap (x j) (ok:Fits x j) : j ≤ m := Finset.le_max' K j (choose x j ok)
    exact ⟨z,m,fz,rigid_of_max fz cap,cap⟩
  · rintro ⟨b,k,⟨done,sz,fit⟩,_,_⟩
    obtain ⟨rs,v,build,lim,vis⟩:=(budget_iff b k).mpr fit
    have c : (complete v).card=92:=build.complete_eq ▸ done
    have len:=build.length_eq
    have lb:=LapSkeleton.completed_floor v
    have room:(good v).length≤v.length-6:=by rw [←windows_length];exact List.length_filter_le ..
    obtain ⟨w,all,n⟩:=expand_remaining (v:=v) (by omega) vis
    exact ⟨w,all,by omega⟩

#print axioms rigid_of_max
#print axioms no_removable_turn
#print axioms exact
end ExactWordFlow.HiddenWheelMaximum

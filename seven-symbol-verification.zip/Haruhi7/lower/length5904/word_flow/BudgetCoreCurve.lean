import CoreAssembly
import RotationSpan
import ExactBoundary

namespace ExactWordFlow.BudgetCoreCurve
open SevenWordWindows SuperpermutationBounds ResidualDensity RotationSpan RotationComponentCount RotationCore
open private required_data from ResidualIncidence

def atLength (l k : Nat) : Prop :=
  ∃v : Block,v.length=l ∧ (visited v).card=720 ∧ k≤(complete v).card

/-- Specialize the spanning construction at any residual budget, using the
cap certified *at that budget*. Padding preserves both finite sets. -/
theorem threshold (b k : Nat) (small : k≤720)
    (cap : ∀{X : Multiset Block} {s t : Block},Feasible X s t → X.card≤b → (occupied X s).card≤k) :
    (∃w : Block,Covers w ∧ w.length≤5046+b) ↔ atLength (6+b+7*k) k := by
  constructor
  · rintro ⟨w,cover,lim⟩
    obtain ⟨l,r,word⟩:=cover (List.finRange 7) List.length_finRange (List.nodup_finRange _)
    obtain ⟨X,size,h⟩:=extract_at_ends w cover (by simp [word];omega)
    obtain ⟨S,sub,count,span⟩:=spanning h
    have amount:=cap h (by omega)
    have hit (c) (hc : c∈allClasses) : ∃u,full u ∧ tag u=c ∧
        ResidualRoutes.label (selected X S) u=ResidualRoutes.label (selected X S) (w.take 6) := by
      obtain ⟨u,hu,clean,key⟩:=every_tag h hc
      exact ⟨u,clean,key,span u hu⟩
    have must (p) (hp : p∈representatives) (want : classKey p∈S) :
        ResidualRoutes.label (selected X S) (src p)=ResidualRoutes.label (selected X S) (w.take 6) := by
      obtain ⟨u,hu,clean,key⟩:=every_tag h (sub want)
      have tab : ∀p∈representatives,tag (src p)=classKey p := by native_decide
      have here:=tab p hp
      exact (join_same (required_data p hp).1 clean (here.trans key.symm) (here ▸ want)).trans (span u hu)
    obtain ⟨v,long,sz,all,done⟩:=CoreAssembly.target h sub (count.trans amount) small hit must
    obtain ⟨z,len,vis,fin⟩:=ExactBoundary.pad (n:=6+b+7*k) long (by omega)
    exact ⟨z,len,vis ▸ all,fin ▸ done⟩
  · rintro ⟨v,len,all,done⟩
    obtain ⟨w,yes,sz⟩:=expand_remaining (v:=v) (by omega) all
    exact ⟨w,yes,by omega⟩

#print axioms threshold
end ExactWordFlow.BudgetCoreCurve

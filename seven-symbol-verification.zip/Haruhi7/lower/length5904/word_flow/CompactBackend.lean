import CompactAdjacentPhysical
import CompactFlags
import CompactInputs
import CompactLimits
import CompactLayoutCheck

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows RotationCore
open CoreCandidateBanks (bankInput pk physicalFlags)
open BenesRouting
open CoreRecordBits (wireLE)

def bankOutput (w : Block) (f : BenesRouting.Bank) :=
  (BenesRouting.arrayRun f 11 1 (bankInput w)).toList

structure BackendWitness (w : Block) (f : BenesRouting.Bank) : Prop where
  width : (bankInput w).size=2048
  sorted : (bankOutput w f).Pairwise (fun a b=>wireLE (pk a) (pk b)=true)
  visited : 720 ≤ (physicalFlags (bankOutput w f)).countP Prod.fst
  completed : 91 ≤ (physicalFlags (bankOutput w f)).countP Prod.snd

theorem backend_witness {w : Block} (len : w.length=1501) (hit : (visited w).card=720)
    (many : 91 ≤ (complete w).card) :
    ∃ f, BackendWitness w f ∧ 720≤(LapSkeleton.starts w).length ∧
      637≤(SevenWordWindows.good w).length ∧ LapSkeleton.dirty w + 1357 ≤ 1496 := by
  obtain ⟨f,rs,actual,perm,size,order,vis,done_,cuts⟩:=CoreCandidateBanks.candidate_banks len hit many
  have hw : (bankInput w).size=2048 := by
    simpa [CoreCandidateBanks.bankInput,←perm.length_eq] using size
  have member (r) (inrs : r∈rs) : r ∈ CoreCandidateBanks.sourceRows w := (perm.mem_iff).mp inrs
  have ord : (rs.map CoreCandidateBanks.rowWires).Pairwise (fun a b=>wireLE (pk a) (pk b)=true) := by
    rw [List.pairwise_map]
    exact order.imp_of_mem fun {a b} ha hb le=>by
      simpa only [pk,CoreCandidateBanks.first19 (member a ha),CoreCandidateBanks.first19 (member b hb)] using le
  have out : bankOutput w f = rs.map CoreCandidateBanks.rowWires := actual
  refine ⟨f,⟨hw,out ▸ ord,?_,?_⟩,cuts⟩
  · rw [out,CoreCandidateBanks.flags_pack member,vis]
  · rw [out,CoreCandidateBanks.flags_pack member]
    exact done_

section
attribute [local irreducible] stage
private theorem bank_stage : layout.bank = stage layout.cleanLimit.top (benes 11 1 (padded layout.front.out.1)) := rfl
private theorem adj_stage : layout.adj = stage layout.bank.top (adjacentRows 19 layout.bank.out.toList) := rfl
private theorem groups_stage : layout.groups = stage layout.adj.top (groupRows 7 19 layout.bank.out.toList
    ((-1)::layout.adj.out.map Prod.snd) (Array.replicate 7 (-1))) := rfl
private theorem visit_stage : layout.visitLimit = stage layout.groups.top
    (capped (layout.groups.out.map Prod.fst).toArray 720) := rfl
private theorem done_stage : layout.doneLimit = stage layout.visitLimit.top
    (capped (layout.groups.out.map Prod.snd).toArray 91) := rfl

end

attribute [local irreducible] layout

private theorem from_stage {T : Test} {s : Stage α} {i : Nat} {m : M α}
    {P : α → Prop} (eq : s=stage i m) (adm : admits T s.base s.log.toList) (meaning : Gives T m P) :
    P s.out := by subst s; exact stage_gives meaning adm

theorem backend_truth {w : Block} {f : BenesRouting.Bank} (wit : BackendWitness w f)
    (v : Nat → Bool) (unit : v 0=true)
    (parts : ∀p∈layout.pieces, admits (sourceTest (wordSource w f) v) p.base p.log.toList)
    (reps : ArrayRel (RowRep v 26) (padded layout.front.out.1) (bankInput w)) :
    (∀p∈layout.adj.out, wire v p.1=true) ∧ wire v layout.visitLimit.out=true ∧
      wire v layout.doneLimit.out=true := by
  let src:=wordSource w f
  have law:=source_models src v
  have bankad := parts layout.bank.toPiece (by
    iterate 6 apply List.mem_cons_of_mem
    exact List.mem_cons_self)
  have adjad := parts layout.adj.toPiece (by
    iterate 7 apply List.mem_cons_of_mem
    exact List.mem_cons_self)
  have groupad := parts layout.groups.toPiece (by
    iterate 8 apply List.mem_cons_of_mem
    exact List.mem_cons_self)
  have visitad := parts layout.visitLimit.toPiece (by
    iterate 9 apply List.mem_cons_of_mem
    exact List.mem_cons_self)
  have donead := parts layout.doneLimit.toPiece (by
    iterate 10 apply List.mem_cons_of_mem
    exact List.mem_cons_self)
  have sim := benes_records src v unit 26 11 1 _ _ reps (reps.size.trans wit.width)
  have bank : List.Forall₂ (RowRep v 26) layout.bank.out.toList (bankOutput w f) :=
    from_stage bank_stage bankad sim
  have checks := adjacent_physical law unit bank wit.sorted
  have adj : (∀p∈layout.adj.out,wire v p.1=true) ∧
      List.Forall₂ (fun x b=>Rep v b x) (layout.adj.out.map Prod.snd) (linkBits (bankOutput w f)) :=
    from_stage adj_stage adjad checks
  have groups : List.Forall₂ (FlagRep v) layout.groups.out (physicalFlags (bankOutput w f)) :=
    from_stage groups_stage groupad (groupRows_gives law unit bank adj.2)
  obtain ⟨vis,done_⟩:=flagProjections groups
  let bs:=physicalFlags (bankOutput w f)
  have count (proj : Bool × Bool → Bool) : (bs.map proj).count true = bs.countP proj := by
    simp [List.count_eq_countP,List.countP_map,Function.comp_def]
  have m := cap_gives (bs:=bs.map Prod.fst) (ws:=(layout.groups.out.map Prod.fst).toArray) law unit
    (by simpa only [List.toList_toArray] using vis) (k:=720) (by rw [count]; exact wit.visited)
  have n := cap_gives (bs:=bs.map Prod.snd) (ws:=(layout.groups.out.map Prod.snd).toArray) law unit
    (by simpa only [List.toList_toArray] using done_) (k:=91) (by rw [count]; exact wit.completed)
  exact ⟨adj.1,(from_stage visit_stage visitad m).2,
    (from_stage done_stage donead n).2⟩

#print axioms backend_witness
#print axioms backend_truth
end ExactWordFlow.CompactWordCircuit

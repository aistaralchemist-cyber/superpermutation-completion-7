import FrontRecordGates
import FrontRawBudget

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows RotationCore RotationReinsert ResidualDensity CoreRecordBits SortedCoreRecords
open CoreCandidateBanks FrontRawBudget FrontLocalMeaning CompactFrontPlan

def sliceAt (w : Block) (i k : Nat) := (w.drop i).take k

theorem windows_at {w : Block} {i : Nat} (h : i<(windows w).length) :
    (windows w)[i] = sliceAt w i 7 := by
  induction w generalizing i with
  | nil => simp [windows] at h
  | cons a w ih =>
    by_cases long : 6≤w.length
    · cases i with
      | zero => simp [windows,long,sliceAt]
      | succ i =>
        have hi : i<(windows w).length := by simpa [windows,long] using h
        simpa [windows,long,sliceAt] using ih hi
    · simp [windows,long] at h

def optionalHot : Option (Fin 7) → Array Bool
  | none => #[]
  | some x => (Array.range 7).map fun a=>decide (x.val=a)

private theorem hot_bit (x : Option (Fin 7)) (a : Fin 7) :
    ((optionalHot x)[a.val]?).getD false = decide (x=some a) := by
  cases x with
  | none => simp [optionalHot]
  | some x => simp [optionalHot,Fin.ext_iff,a.isLt]

private theorem mask_pure (u : Block) (width : u.length=6) (n : Option (Fin 7)) :
    (pureMask (read u) (optionalHot n) n.isSome).toList =
      (List.finRange 7).map (fun a=>decide (a∈mask u n)) := by
  obtain ⟨_,yes,miss⟩ := local_meaning width
  cases n with
  | none => simp [pureMask,mask_last, List.finRange]
  | some a =>
    apply List.ext_getElem
    · simp [pureMask]
    · intro i h1 h2
      have hi : i<7 := by simpa using h2
      let x : Fin 7 := ⟨i,hi⟩
      simp only [pureMask,Option.isSome_some,ite_true,Array.toList_map,Array.toList_range,
        List.getElem_map,List.getElem_range,List.getElem_finRange]
      change (read u template.1.clean && read u (missRef x.val) && ((optionalHot (some a))[x.val]?).getD false) = _
      rw [yes,miss x,hot_bit (some a) x]
      simp [CoreRecordBits.mask,x]

def tripleAt (w : Block) (i : Nat) := pureRow (inputPorts (sliceAt w i 6))
  (optionalHot (w[i+6]?)) (w[i+6]?).isSome true

private theorem pure_triple (u : Block) (width : u.length=6) (n : Option (Fin 7)) :
    pureRow (inputPorts u) (optionalHot n) n.isSome true =
    ( (keyWires u ++ (List.finRange 7).map (fun a=>decide (a∈mask u n))).toArray,
      clean u, n.isSome && (List.finRange 7).any (fun a=>decide (a∈mask u n))) := by
  obtain ⟨key,cl,_⟩ := local_meaning width
  have mk := mask_pure u width n
  apply Prod.ext
  · apply Array.toList_inj.mp
    change (template.1.row.map (read u) ++ pureMask (read u) (optionalHot n) n.isSome).toList=_
    simp only [Array.toList_append,key,mk]
  · apply Prod.ext
    · exact cl
    · change (if n.isSome && true then (pureMask (read u) (optionalHot n) n.isSome).toList.any id else false)=_
      rw [mk]
      cases n <;> simp [List.any_map]

private theorem valid_bit (p : Block) (hp : p.length=7) :
    (List.finRange 7).any (fun a=>decide (a∈(windowRow digits p).mask)) = decide p.Nodup := by
  by_cases nd : p.Nodup
  · cases h : p.getLast? with
    | none => have e := List.getLast?_eq_none_iff.mp h; simp [e] at hp
    | some x => simp [windowRow,nd,h,List.any_eq_true,List.mem_finRange,Option.toFinset]
  · simp [windowRow,nd]

private theorem atWindow {w : Block} {i : Nat} (h : i<(windows w).length) :
    tripleAt w i = (rowWires (windowRow digits ((windows w)[i])), clean (src ((windows w)[i])),
      decide ((windows w)[i]).Nodup) := by
  let p := (windows w)[i]
  have pw : p.length=7 := window_width w (List.getElem_mem ..)
  have atw : p = sliceAt w i 7 := windows_at h
  have fu : src p = sliceAt w i 6 := by simp [atw,src,sliceAt,List.take_take]
  have sw : (src p).length=6 := by simp [src,pw]
  have hi : i+6 < w.length := by rw [windows_length] at h; omega
  have last : p.getLast?=w[i+6]? := by
    rw [List.getLast?_eq_getElem?,pw,atw]
    simp [sliceAt,List.getElem?_drop]
  have ne : (w[i+6]?).isSome=true := by simpa using hi
  rw [tripleAt,←fu,pure_triple _ sw,←last]
  obtain ⟨key,mk⟩ := window_wires p pw
  rw [key,mk,valid_bit p pw,last,ne]
  rfl

private theorem atEnd {w : Block} (large : 6≤w.length) :
    tripleAt w (w.length-6) =
      (rowWires ⟨contextKey digits (w.drop (w.length-6)),∅⟩,clean (w.drop (w.length-6)),false) := by
  have width : (w.drop (w.length-6)).length=6 := by simp; omega
  have last : w[w.length-6+6]?=none := getElem?_neg w _ (by omega)
  have eq : sliceAt w (w.length-6) 6 = w.drop (w.length-6) := by unfold sliceAt; exact List.take_of_length_le (by omega)
  rw [tripleAt,eq,last,pure_triple _ width,key_eq width,mask_last]
  rfl

theorem triple_table {w : Block} (len : w.length=1501) :
    (List.range 1496).map (tripleAt w) =
    ((windows w).map fun p => (rowWires (windowRow digits p),clean (src p),decide p.Nodup)) ++
    [(rowWires ⟨contextKey digits (w.drop (w.length-6)),∅⟩,clean (w.drop (w.length-6)),false)] := by
  rw [show 1496=1495+1 from rfl,List.range_succ,List.map_append]
  apply congrArg₂ List.append
  · apply List.ext_getElem
    · simp [windows_length,len]
    · intro i hi hj
      simp only [List.getElem_map,List.getElem_range]
      apply atWindow
  · simpa [len] using (atEnd (w:=w) (by omega))

#print axioms triple_table
end ExactWordFlow.CompactWordCircuit

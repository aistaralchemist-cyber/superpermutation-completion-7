import RotationSpan
import CoreAssembly
import GlobalWheelRank

namespace ExactWordFlow.ConnectorSavings
open SevenWordWindows ResidualDensity ResidualRoutes RotationSpan RotationComponentCount
open private bridge sel_mono both from RotationSpan
open private required_data from ResidualIncidence
open scoped Classical

/-- The residual components after restoring a set of class cycles, counted
only on the original residual endpoints, including the home state. -/
noncomputable def groups (X : Multiset Block) (s : Block) (S : Finset Block) :=
  (terminals X s).image (label (selected X S))

/-- Original components incident with a given class, anywhere in the flow. -/
noncomputable def attachments (X : Multiset Block) (s c : Block) :=
  ((terminals X s).filter fun v => full v ∧ tag v=c).image (label X)

private def push {X Y : Multiset Block} (h : X≤Y) : Component X → Component Y :=
  Quotient.lift (label Y) (fun _ _ r => label_lift h (Quotient.sound r))

private theorem contract {α β : Type*} [DecidableEq α] [DecidableEq β] (f : α→β)
    {U A : Finset α} (sub : A⊆U) (b : β) (same : ∀x∈A,f x=b) :
    (U.image f).card+A.card≤U.card+1 := by
  classical
  have bound : U.image f ⊆ insert b ((U \ A).image f) := by
    intro y hy
    obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hy
    by_cases ha : x∈A
    · exact Finset.mem_insert.mpr (Or.inl (same x ha))
    · exact Finset.mem_insert_of_mem (Finset.mem_image_of_mem _ (Finset.mem_sdiff.mpr ⟨hx,ha⟩))
  have a:=Finset.card_le_card bound
  have bnd:=Finset.card_insert_le b ((U \ A).image f)
  have c:=Finset.card_image_le (f:=f) (s:=U \ A)
  have incl:=Finset.card_le_card sub
  have d:=Finset.card_sdiff_of_subset sub
  omega

private theorem base_groups (X : Multiset Block) (s : Block) :
    ((terminals X s).image (label X)).card=(occupied X s).card+1 := by
  classical
  have eq : (terminals X s).image (label X)=insert (label X s) (occupied X s) := by
    ext q
    constructor
    · rintro h
      obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp h
      by_cases home : label X v=label X s
      · exact Finset.mem_insert.mpr (.inl home)
      apply Finset.mem_insert_of_mem
      apply Finset.mem_erase.mpr
      refine ⟨home,?_⟩
      rcases Finset.mem_insert.mp hv with rfl|others
      · exact (home rfl).elim
      rcases Finset.mem_union.mp others with hs|hd
      · exact Finset.mem_image_of_mem _ hs
      obtain ⟨e,he,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp hd)
      rw [←on_edge he]
      exact Finset.mem_image_of_mem _ (Multiset.mem_toFinset.mpr (Multiset.mem_map.mpr ⟨e,he,rfl⟩))
    · intro h
      rcases Finset.mem_insert.mp h with rfl|other
      · exact Finset.mem_image_of_mem _ (Finset.mem_insert_self ..)
      obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp (Finset.mem_erase.mp other).2
      exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Finset.mem_union_left _ hv))
  rw [eq,Finset.card_insert_of_notMem (show label X s∉occupied X s by simp [occupied])]

private theorem decrease {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (A : Finset Block)
    (bad : ∃v∈terminals X s,label (selected X A) v≠label (selected X A) s) :
    ∃c∈allClasses, c∉A ∧ (groups X s (insert c A)).card<(groups X s A).card := by
  classical
  obtain ⟨u,hu,v,hv,fu,fv,eq,atHome,away⟩:=bridge h A bad
  let c:=tag u
  have inBoard : c∈allClasses := by
    have table : ∀v∈states,tag v∈allClasses := by native_decide
    exact table u (mem_states fu)
  have inB : tag u∈insert c A := Finset.mem_insert_self ..
  have no : c∉A := fun yes => away ((join_same fu fv eq yes).symm.trans atHome)
  let f := push (sel_mono X (Finset.subset_insert c A))
  let a := label (selected X A) u
  let b := label (selected X A) v
  have ab : a≠b := fun e => away (e.symm.trans atHome)
  have same : f a=f b := join_same fu fv eq inB
  have pair : ({a,b} : Finset _ )⊆groups X s A := by
    change {label (selected X A) u, label (selected X A) v}⊆(terminals X s).image (label (selected X A))
    apply Finset.insert_subset (Finset.mem_image_of_mem _ hu)
    exact Finset.singleton_subset_iff.mpr (Finset.mem_image_of_mem _ hv)
  have one := contract f pair (f b) (by intro x hx; simp only [Finset.mem_insert,Finset.mem_singleton] at hx; rcases hx with rfl|rfl <;> simp [same])
  have image : (groups X s A).image f=groups X s (insert c A) := by
    simp only [groups,Finset.image_image]; rfl
  rw [image,Finset.card_pair ab] at one
  exact ⟨c,inBoard,no,by omega⟩

/-- After freely choosing ANY seed classes, each remaining restoration
merges at least two surviving components. No seed has to touch the root. -/
theorem seeded {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (A : Finset Block) (legal : A⊆allClasses) :
    ∃S⊆allClasses, A⊆S ∧ S.card+1≤A.card+(groups X s A).card ∧
      ∀v∈terminals X s,label (selected X S) v=label (selected X S) s := by
  classical
  by_cases done : ∀v∈terminals X s,label (selected X A) v=label (selected X A) s
  · have pos : 0<(groups X s A).card := Finset.card_pos.mpr
      ⟨_,Finset.mem_image_of_mem _ (Finset.mem_insert_self s _)⟩
    exact ⟨A,legal,Finset.Subset.rfl,by omega,done⟩
  · push Not at done
    obtain ⟨c,yes,new,lt⟩:=decrease h A done
    obtain ⟨S,sub,has,n,all⟩:=seeded h (insert c A) (Finset.insert_subset yes legal)
    rw [Finset.card_insert_of_notMem new] at n
    exact ⟨S,sub,(Finset.subset_insert ..).trans has,by omega,all⟩
termination_by (groups X s A).card

private theorem seed_cost (X : Multiset Block) (s c : Block) :
    (groups X s {c}).card+(attachments X s c).card ≤ (occupied X s).card+2 := by
  classical
  let Y := selected X {c}
  let f := push (Multiset.le_add_right X (required.filter (fun e=>classKey e∈({c}:Finset Block))))
  let I := attachments X s c
  let U := (terminals X s).image (label X)
  have sub : I⊆U := Finset.image_subset_image (Finset.filter_subset ..)
  by_cases live : I.Nonempty
  · obtain ⟨q,hq⟩:=live
    obtain ⟨u,hu,uq⟩:=Finset.mem_image.mp hq
    have ⟨_,fu,uc⟩:=Finset.mem_filter.mp hu
    let z := label Y u
    have same (k) (hk : k∈I) : f k=z := by
      obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hk
      obtain ⟨_,fv,vc⟩:=Finset.mem_filter.mp hv
      exact join_same fv fu (vc.trans uc.symm) (by simp [vc])
    have n:=contract f sub z same
    have image : U.image f=groups X s {c} := by simp only [U,groups,Finset.image_image]; rfl
    rw [image] at n
    have num:=base_groups X s
    change U.card=_ at num
    rw [num] at n
    exact n
  · have empty:=Finset.not_nonempty_iff_eq_empty.mp live
    have bound:=Finset.card_image_le (f:=f) (s:=U)
    have image : U.image f=groups X s {c} := by simp only [U,groups,Finset.image_image]; rfl
    rw [image] at bound
    have num:=base_groups X s
    change U.card=_ at num
    rw [num] at bound
    calc
      _ = (groups X s {c}).card := by change _ + I.card=_; rw [empty]; simp
      _ ≤ _ := bound.trans (by omega)

/-- If a class touches m residual components, a connected core needs at
most N + 2 - m classes, for N occupied nonroot components. -/
theorem one_class {X : Multiset Block} {s t c : Block} (h : Feasible X s t)
    (hc : c∈allClasses) :
    ∃S⊆allClasses, c∈S ∧ S.card+(attachments X s c).card≤(occupied X s).card+2 ∧
      ∀v∈terminals X s,label (selected X S) v=label (selected X S) s := by
  obtain ⟨S,sub,has,n,all⟩:=seeded h {c} (Finset.singleton_subset_iff.mpr hc)
  have credit:=seed_cost X s c
  rw [Finset.card_singleton] at n
  exact ⟨S,sub,has (Finset.mem_singleton_self _),by omega,all⟩

/-- Every selection must also pay the rank of the original residual
components. Each class contributes at most its number of attachments minus
one, even through the intervening clean states which no residual edge uses. -/
theorem necessary {X : Multiset Block} {s : Block} {S : Finset Block}
    (span : ∀v∈terminals X s,label (selected X S) v=label (selected X S) s) :
    (occupied X s).card≤∑c∈S, ((attachments X s c).card-1) := by
  classical
  let I := attachments X s
  let B := S.image I
  obtain ⟨U,sub,bound,close⟩:=GlobalWheelRank.grow {label X s} B
  have root : label X s∈U := sub (Finset.mem_singleton_self _)
  let P : Set Block := {v | if v∈terminals X s then label X v∈U else I (tag v)⊆U}
  have terminal (v) (hv : v∈terminals X s) : v∈P ↔ label X v∈U := by simp [P,hv]
  have common (v) (clean : full v) (incl : tag v∈S) : v∈P ↔ I (tag v)⊆U := by
    by_cases near : v∈terminals X s
    · rw [terminal v near]
      have hit : label X v∈I (tag v) := Finset.mem_image.mpr
        ⟨v,Finset.mem_filter.mpr ⟨near,clean,rfl⟩,rfl⟩
      exact ⟨fun hu => close _ (Finset.mem_image_of_mem _ incl) ⟨_,Finset.mem_inter.mpr ⟨hu,hit⟩⟩,
        fun inside=>inside hit⟩
    · simp [P,near]
  have step (e) (he : e∈selected X S) : src e∈P ↔ dst e∈P := by
    rcases Multiset.mem_add.mp he with more|sel
    · have ends:=both s more
      rw [terminal _ ends.1,terminal _ ends.2,on_edge more]
    · obtain ⟨req,inS⟩:=Multiset.mem_filter.mp sel
      obtain ⟨one,two,same⟩:=required_data e req
      have tab : ∀p∈representatives,tag (src p)=classKey p := by native_decide
      have kept : tag (src e)∈S := tab e req ▸ inS
      rw [common _ one kept,common _ two (same ▸ kept),same]
  have contains : (terminals X s).image (label X)⊆U := by
    intro q hq
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hq
    have start: s∈P:=(terminal s (Finset.mem_insert_self ..)).mpr root
    exact (terminal _ hv).mp ((invariant P step (span v hv)).mpr start)
  have n:=Finset.card_le_card contains
  rw [base_groups] at n
  have total : ∑b∈B,(b.card-1) ≤ ∑c∈S, ((I c).card-1) :=
    Finset.sum_image_le_of_nonneg (fun _ _=>Nat.zero_le _)
  simp only [Finset.card_singleton] at bound
  change _≤∑c∈S, ((I c).card-1)
  omega

/-- The straightforward N-cycle construction is optimal exactly when
all class incidences have degree at most two. This is per flow, with no
length or endpoint restriction. -/
theorem no_saving_iff {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    (∀S : Finset Block, S⊆allClasses →
      (∀v∈terminals X s,label (selected X S) v=label (selected X S) s) →
      (occupied X s).card≤S.card) ↔
    ∀c∈allClasses,(attachments X s c).card≤2 := by
  constructor
  · intro optimal c hc
    obtain ⟨S,legal,_,bound,done⟩:=one_class h hc
    have low:=optimal S legal done
    omega
  · intro two S sub span
    have unit (c) (hc : c∈S) : (attachments X s c).card-1≤1 := by
      have n:=two c (sub hc)
      omega
    have max:=Finset.sum_le_sum unit
    simpa using (necessary span).trans max

/-- Spell any improved span as an actual all-visited core. -/
theorem compressed_word {X : Multiset Block} {s t c : Block} (h : Feasible X s t)
    (hc : c∈allClasses) {k : Nat} (room : (occupied X s).card+2≤k+(attachments X s c).card)
    (board : k≤720) :
    ∃v : Block, 6≤v.length ∧ v.length≤6+X.card+7*k ∧
      (RotationCore.visited v).card=720 ∧ k≤(RotationCore.complete v).card := by
  obtain ⟨S,legal,_,cost,all⟩:=one_class h hc
  apply CoreAssembly.target h legal (by omega) board
  · intro d hd
    obtain ⟨u,hu,clean,eq⟩:=every_tag h hd
    exact ⟨u,clean,eq,all u hu⟩
  · intro p hp inS
    obtain ⟨v,hv,clean,eq⟩:=every_tag h (legal inS)
    have tab : ∀p∈representatives,tag (src p)=classKey p := by native_decide
    have key:=tab p hp
    exact (join_same (required_data p hp).1 clean (key.trans eq.symm) (key ▸ inS)).trans (all v hv)

#print axioms necessary
#print axioms no_saving_iff
#print axioms compressed_word
#print axioms seeded
#print axioms one_class
end ExactWordFlow.ConnectorSavings

import MultipleRootContacts

namespace ExactWordFlow.MultipleRootContacts
open Equiv
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]
variable {R h : Perm X} (start : X) (oneOrbit : ∀y,(R*h).SameCycle start y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat}
    (genus : h.support.card=h.cycleType.card+719+2*g)

include oneOrbit onto rot classes genus in
/-- Multiple wheels can be charged even if each meets a different donor
cycle. The budget is the actual genus, independent of the number of donors. -/
theorem multiple_donors (E W : Finset (Perm X)) (base : E⊆h.cycleFactorsFinset)
    (wheels : W⊆h.cycleFactorsFinset) (apart : Disjoint W E)
    (crossed : ∀w∈W,∃e∈E,2≤(w.support.image tag ∩ e.support.image tag).card) :
    W.card ≤ 2*g := by
  classical
  let V (c : Perm X):=c.support.image tag
  have choose (w) (hw : w∈W) :
      ∃a∈V w, ∃b∈V w, b≠a ∧ ∃e∈E,a∈V e ∧ b∈V e := by
    obtain ⟨e,he,sur⟩:=crossed w hw
    obtain ⟨a,ha,b,hb,ne⟩:=Finset.one_lt_card.mp sur
    obtain ⟨aw,ae⟩:=Finset.mem_inter.mp ha
    obtain ⟨bw,be⟩:=Finset.mem_inter.mp hb
    exact ⟨a,aw,b,bw,ne.symm,e,he,ae,be⟩
  let loss (w : Perm X):= if hw : w∈W then (choose w hw).choose else tag start
  have spec (w) (hw : w∈W) : loss w∈V w ∧
      ∃b∈V w,b≠loss w ∧ ∃e∈E,loss w∈V e ∧ b∈V e := by
    simpa [loss,hw] using (choose w hw).choose_spec
  let K (c : Perm X):=if c∈W then (V c).erase (loss c) else V c
  have inside (c) (_ : c∈h.cycleFactorsFinset) : K c⊆c.support.image tag := by
    by_cases yes : c∈W
    · simpa only [K,ite_eq_left yes] using (Finset.erase_subset (loss c) (V c))
    · simp [K,yes,V]
  have present (c) (hc : c∈h.cycleFactorsFinset) : (K c).Nonempty := by
    by_cases yes : c∈W
    · obtain ⟨b,hb,ne,_⟩:=(spec c yes).2
      exact ⟨b,by simpa [K,yes] using And.intro ne hb⟩
    · obtain ⟨x,ne,_⟩:=(Perm.mem_cycleFactorsFinset_iff.mp hc).1
      exact ⟨tag x,by simpa [K,yes,V] using Finset.mem_image_of_mem tag (Perm.mem_support.mpr ne)⟩
  have detour (c) (_ : c∈h.cycleFactorsFinset) (j) (hj : j∈V c) (gone : j∉K c) :
      ∃e∈h.cycleFactorsFinset,j∈K e ∧ (K c ∩ K e).Nonempty := by
    by_cases yes : c∈W
    · have jl : j=loss c := by
        by_contra other
        exact gone (by simpa only [K,ite_eq_left yes,Finset.mem_erase] using And.intro other hj)
      obtain ⟨b,hb,ne,e,he,old,shared⟩:=(spec c yes).2
      have off : e∉W := fun hx=>Finset.disjoint_left.mp apart hx he
      refine ⟨e,base he,by simpa [K,off,jl] using old, b,Finset.mem_inter.mpr ⟨?_,?_⟩⟩
      · simpa [K,yes] using And.intro ne hb
      · simpa [K,off] using shared
    · exact False.elim (gone (by simpa [K,yes] using hj))
  have top:=rerouted_contacts start oneOrbit tag onto rot classes genus K inside present detour
  have each (c) (hc : c∈W) : 1≤c.support.card-(K c).card := by
    have eq:=Finset.card_erase_add_one ((spec c hc).1)
    have hi : (V c).card≤c.support.card:=Finset.card_image_le
    simp only [K,ite_eq_left hc]
    omega
  calc
    W.card = ∑_∈W,1 := by simp
    _ ≤ ∑c∈W,(c.support.card-(K c).card) := Finset.sum_le_sum each
    _ ≤ ∑c∈h.cycleFactorsFinset,(c.support.card-(K c).card) :=
      Finset.sum_le_sum_of_subset wheels
    _ ≤ 2*g := top

include oneOrbit onto rot classes in
/-- Every rotation tag is incident with some actual moved point; otherwise
the one-orbit successor would preserve a single nonempty tag class. -/
theorem tag_covered (j : Y) : ∃c∈h.cycleFactorsFinset,j∈c.support.image tag := by
  classical
  obtain ⟨x,hx⟩:=onto j
  by_contra! missing
  have stable (y : X) (hy : tag y=j) : h y=y := by
    by_contra moved
    have inCycle := Perm.cycleOf_mem_cycleFactorsFinset_iff.mpr (Perm.mem_support.mpr moved)
    exact missing (h.cycleOf y) inCycle (hy ▸ Finset.mem_image_of_mem tag
      (Perm.mem_support_cycleOf_iff.mpr ⟨.refl _ _,Perm.mem_support.mpr moved⟩))
  have walk (n : Nat) : tag (((R*h)^n) x)=j := by
    induction n with
    | zero => simpa using hx
    | succ n ih => simpa only [pow_succ',Perm.mul_apply,rot,stable _ ih] using ih
  have only (v : Y) : v=j := by
    obtain ⟨y,rfl⟩:=onto v
    obtain ⟨n,_,_,eq⟩:=((oneOrbit x).symm.trans (oneOrbit y)).exists_pow_eq _
    exact eq ▸ walk n
  have card : Fintype.card Y≤1 := by
    rw [←Finset.card_univ,←Finset.card_singleton j]
    exact Finset.card_le_card fun z _=>Finset.mem_singleton.mpr (only z)
  omega

include oneOrbit onto rot classes genus in
/-- S is any set of tags for which every available nonexceptional cycle
has two known contacts with one and the same exceptional cycle. A donor may
vary from wheel to wheel. At most eight times the genus of these tags can
escape the (possibly disconnected) union of the exceptional supports. -/
theorem forced_outside (E : Finset (Perm X)) (base : E⊆h.cycleFactorsFinset)
    (S : Finset Y) (width : ∀w∈h.cycleFactorsFinset, w∉E → w.support.card≤6)
    (blocked : ∀j∈S, ∀w∈h.cycleFactorsFinset, w∉E → j∈w.support.image tag →
        ∃e∈E,2≤(w.support.image tag ∩ e.support.image tag).card) :
    (S \ E.biUnion (fun c=>c.support.image tag)).card ≤ 8*g := by
  classical
  let V (c : Perm X):=c.support.image tag
  let A:=E.biUnion V
  let outside:=S \ A
  let W:=(h.cycleFactorsFinset \ E).filter fun w=> (V w∩outside).Nonempty
  have wheels : W⊆h.cycleFactorsFinset := (Finset.filter_subset _ _).trans Finset.sdiff_subset
  have off (w) (hw : w∈W) : w∉E := (Finset.mem_sdiff.mp (Finset.mem_filter.mp hw).1).2
  have collide (w) (hw : w∈W) : ∃e∈E,2≤(V w∩V e).card := by
    obtain ⟨j,hj⟩:=(Finset.mem_filter.mp hw).2
    have both:=Finset.mem_inter.mp hj
    exact blocked j (Finset.mem_sdiff.mp both.2).1 w (wheels hw) (off w hw) both.1
  have loss:=multiple_donors start oneOrbit tag onto rot classes genus E W base wheels
    (Finset.disjoint_left.mpr (fun {w} hw hE=>off w hw hE)) collide
  have cover : outside⊆W.biUnion (fun w=>V w∩outside) := by
    intro j hj
    obtain ⟨c,hc,hit⟩:=tag_covered start oneOrbit tag onto rot classes j
    have diff : c∉E:=fun inside=>(Finset.mem_sdiff.mp hj).2 (Finset.mem_biUnion.mpr ⟨c,inside,hit⟩)
    have mem:=Finset.mem_inter.mpr ⟨hit,hj⟩
    exact Finset.mem_biUnion.mpr ⟨c,Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨hc,diff⟩,j,mem⟩,mem⟩
  have four (w) (hw : w∈W) : (V w∩outside).card ≤ 4 := by
    obtain ⟨e,he,two⟩:=collide w hw
    have small : V w∩outside⊆V w \ (V w∩V e) := by
      intro j hj
      obtain ⟨yes,out⟩:=Finset.mem_inter.mp hj
      exact Finset.mem_sdiff.mpr ⟨yes,fun hboth=>(Finset.mem_sdiff.mp out).2
        (Finset.mem_biUnion.mpr ⟨e,he,(Finset.mem_inter.mp hboth).2⟩)⟩
    have z:=Finset.card_le_card small
    rw [Finset.card_sdiff_of_subset Finset.inter_subset_left] at z
    have six : (V w).card≤6 := Finset.card_image_le.trans (width w (wheels hw) (off w hw))
    omega
  have n := (Finset.card_le_card cover).trans Finset.card_biUnion_le
  have cap := Finset.sum_le_card_nsmul W (fun w=>(V w∩outside).card) 4 four
  simp only [smul_eq_mul] at cap
  change outside.card≤8*g
  omega

#print axioms multiple_donors
#print axioms tag_covered
#print axioms forced_outside
end ExactWordFlow.MultipleRootContacts

import CoreRecordBits
import RecordFlags

namespace ExactWordFlow.CoreRecordBits
open SevenWordWindows RotationCore ResidualDensity SortedCoreRecords

/-- The Python comparator folds from the least significant end; this is
the equivalent recurrence on the first undecided pair of bits. -/
def wireLE : List Bool → List Bool → Bool
  | [], _ => true
  | _::_, [] => false
  | a::xs, b::ys => if a=b then wireLE xs ys else !a

private theorem cons_order {α : Type*} [LinearOrder α] {a b : α} {l r : List α} :
    a::l ≤ b::r ↔ a<b ∨ a=b ∧ l≤r := by
  rw [le_iff_lt_or_eq,le_iff_lt_or_eq]
  change List.Lex (· < ·) (a::l) (b::r) ∨ _ ↔ _
  rw [List.cons_lex_cons_iff,List.cons.injEq]
  change (a<b ∨ a=b ∧ l<r) ∨ _ ↔ _
  tauto

@[simp] private theorem nil_le_list {α : Type*} [LinearOrder α] (l : List α) : [] ≤ l := by
  cases l with
  | nil => rfl
  | cons a as => exact le_of_lt (show List.Lex (· < ·) [] (a::as) from .nil)

@[simp] private theorem cons_not_le_nil {α : Type*} [LinearOrder α] (a : α) (l : List α) :
    ¬ a::l ≤ [] := not_le_of_gt (show List.Lex (· < ·) [] (a::l) from .nil)

theorem wireLE_iff (xs ys : List Bool) : wireLE xs ys=true ↔ xs ≤ ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [wireLE]
  | cons x xs ih =>
    cases ys with
    | nil => simp [wireLE]
    | cons y ys => cases x <;> cases y <;> simp [wireLE,cons_order,ih]

private def pass3 (x y : Fin 8) (b : Bool) : Bool :=
  (List.range 3).foldl (fun v i =>
    if x.val.testBit i = y.val.testBit i then v else !x.val.testBit i) b

private theorem pass3_table : ∀x y : Fin 8, ∀t : Bool,
    pass3 x y t = (decide (x.val<y.val) || (decide (x.val=y.val) && t)) := by native_decide

private theorem chunk (x y : Fin 8) (xs ys : List Bool) :
    bits3 x.val ++ xs ≤ bits3 y.val ++ ys ↔ x.val<y.val ∨ x.val=y.val ∧ xs≤ys := by
  rw [←wireLE_iff]
  change pass3 x y (wireLE xs ys) = true ↔ _
  rw [pass3_table]
  simp [wireLE_iff]

private theorem packed_order (xs ys : List Nat) (hx : ∀x∈xs,x<8) (hy : ∀y∈ys,y<8) :
    xs.flatMap bits3 ≤ ys.flatMap bits3 ↔ xs ≤ ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [bits3]
  | cons x xs ih =>
    cases ys with
    | nil => simp [bits3]
    | cons y ys =>
      have headx := hx x List.mem_cons_self
      have heady := hy y List.mem_cons_self
      rw [List.flatMap_cons,List.flatMap_cons,chunk ⟨x,headx⟩ ⟨y,heady⟩,
        ih ys (fun a h=>hx a (List.mem_cons_of_mem _ h)) (fun a h=>hy a (List.mem_cons_of_mem _ h)),
        cons_order]

private theorem val_order (xs ys : Block) : xs.map Fin.val ≤ ys.map Fin.val ↔ xs ≤ ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp
  | cons x xs ih =>
    cases ys with
    | nil => simp
    | cons y ys =>
      simp only [List.map_cons,cons_order,Fin.val_inj,ih]
      rfl

/-- In valid keys the leading digit of the rotation is zero. Dirty digits
are bounded to the actual three-bit encoding, including the padding key. -/
def encodable (k : Key) : Prop := match ofLex k with
  | .inl c => c=0::c.tail
  | .inr junk => ∀n∈junk,n<8

private theorem encode_order (x y : Block ⊕ List Nat)
    (hx : encodable (toLex x)) (hy : encodable (toLex y)) :
    encodeKey (toLex x) ≤ encodeKey (toLex y) ↔ toLex x ≤ toLex y := by
  cases x with
  | inl c =>
    cases y with
    | inl d =>
      change c=0::c.tail at hx
      change d=0::d.tail at hy
      have left : ∀a ∈ c.tail.map Fin.val,a<8 := by
        rintro a ha; obtain ⟨i,_,rfl⟩ := List.mem_map.mp ha; omega
      have right : ∀a ∈ d.tail.map Fin.val,a<8 := by
        rintro a ha; obtain ⟨i,_,rfl⟩ := List.mem_map.mp ha; omega
      have reorder := (packed_order _ _ left right).trans (val_order c.tail d.tail)
      change (false :: _) ≤ (false :: _) ↔ _
      rw [cons_order,Sum.Lex.inl_le_inl_iff]
      simp only [lt_self_iff_false,true_and,false_or]
      have tail_iff : c.tail ≤ d.tail ↔ c ≤ d := by
        conv_rhs => rw [hx,hy,cons_order]
        simp
      simpa only [List.flatMap_map] using reorder.trans tail_iff
    | inr d =>
      change (false :: _) ≤ (true :: _) ↔ _
      exact iff_of_true ((cons_order).mpr (Or.inl (by decide : false < true))) (Sum.Lex.inl_lt_inr ..).le
  | inr c =>
    cases y with
    | inl d =>
      change (true :: _) ≤ (false :: _) ↔ _
      exact iff_of_false (by simp [cons_order]) (not_le_of_gt (Sum.Lex.inl_lt_inr ..))
    | inr d =>
      change (true :: _) ≤ (true :: _) ↔ _
      rw [cons_order,Sum.Lex.inr_le_inr_iff]
      simpa using packed_order c d hx hy

theorem wireLE_keys {k l : Key} (hk : encodable k) (hl : encodable l) :
    wireLE (encodeKey k) (encodeKey l)=true ↔ k≤l :=
  (wireLE_iff ..).trans (encode_order (ofLex k) (ofLex l) hk hl)

private theorem head_table : ∀c∈allClasses,c=0::c.tail := by native_decide

theorem context_encodable (u : Block) : encodable (contextKey digits u) := by
  by_cases h : full u
  · rw [contextKey,ite_eq_left h]
    have table : ∀s∈states, tag s∈allClasses := by native_decide
    exact head_table _ (table _ (mem_states h))
  · rw [contextKey,ite_eq_right h]
    change ∀a∈digits u,a<8
    intro a ha
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp ha
    cases tailBit u i 2 <;> cases tailBit u i 1 <;> cases tailBit u i 0 <;> decide

theorem rows_encodable {r : Row} {w : Block} (hr : r∈wordRows digits w) : encodable r.key := by
  rcases List.mem_append.mp hr with h|h
  · obtain ⟨p,_,rfl⟩ := List.mem_map.mp h
    exact context_encodable _
  · obtain rfl := List.mem_singleton.mp h
    exact context_encodable _

#print axioms wireLE_keys
end ExactWordFlow.CoreRecordBits

import ForcedRuns
import SaturatedCyclicWindow
namespace ResidualDensity.ForcedRuns
open SevenWordWindows DirectedEuler ExactWordFlow
open private select per_walk from RouteDensity
open private count_add localCount localMark count_cap from DensityBudget
open private one shift from SaturatedCyclicWindow

/-- Exact marked traversal in the given spelling. A window may cross the end
only when the spelling and its continuation are periodic with the given period. -/
def Realized (s : Six) (es : List Six) (T P : Nat) : Prop :=
  ∃(u : Nat→Six) (I : Finset Nat) (i n : Nat), Walk u ∧
    positions u (es.length+1)=s::es.map dst ∧
    (i+n≤es.length+1 ∨ ∀j,u (j+es.length)=u j) ∧ Marked u (·∈I) ∧
    count (·∈I) i n=classCount s es ∧
    T=endings six [] (mask (·∈I) i n) ∧ P=endings twin [] (mask (·∈I) i n)

theorem open_stats {s t : Six} {es : List Six} (r:Route src dst s es t)
    (wd:∀e∈es,e.length=7) : ∃T P,Realized s es T P ∧
    1995*(classCount s es-1)≤1644*es.length+380*T+1773 ∧
    6*(classCount s es-1)≤5*es.length+P+5 := by
  obtain ⟨u,w,h0,hk,eq⟩:=route_walk r wd
  obtain ⟨I,marked,cnt⟩:=select u (es.length+1)
  rw [eq] at cnt
  have actual : count (·∈I) 0 (es.length+1)=classCount s es:=cnt
  obtain ⟨a,b⟩:=marks w marked 0 (es.length+1)
  rw [actual] at a b
  exact ⟨_,_,⟨u,I,0,es.length+1,w,eq,Or.inl (by omega),marked,actual,rfl,rfl⟩,by omega,by omega⟩

private theorem closed_spelling {s : Six} {es : List Six} (route : Route src dst s es s)
    (widths : ∀ e∈es, e.length=7) (positive : 0<es.length) :
    ∃ (u : ℕ → Six) (I : Finset ℕ), Walk u ∧ positions u (es.length+1)=s::es.map dst ∧ (∀j,u (j+es.length)=u j) ∧
      CyclicMarked u (fun i => i%es.length∈I) es.length ∧
      count (fun i => i%es.length∈I) 0 es.length=classCount s es := by
  classical
  obtain ⟨u,walk,h0,hk,eq⟩ := route_walk route widths
  let k := es.length
  have pos : 0<k := positive
  have endeq : u k=u 0 := hk.trans h0.symm
  have t : touched (positions u (k+1))=touched (positions u k) := by
    have first : u 0 ∈ positions u k :=
      List.mem_map.mpr ⟨0, List.mem_range.mpr pos,rfl⟩
    ext z
    simp only [touched,List.mem_toFinset,List.mem_map,List.mem_filter,decide_eq_true_eq,
      positions,List.range_succ,List.map_append,List.map_cons,List.map_nil,
      List.mem_append,List.mem_singleton] at *
    constructor
    · rintro ⟨x,⟨h|ex,ff⟩,id⟩
      · exact ⟨x,⟨h,ff⟩,id⟩
      · subst x
        exact ⟨u 0,⟨first,by simpa [endeq] using ff⟩,by simpa [endeq] using id⟩
    · rintro ⟨x,⟨h,ff⟩,id⟩; exact ⟨x,⟨Or.inl h,ff⟩,id⟩
  obtain ⟨I,hm,hc⟩ := select u k
  let p (i : Nat) := i%k ∈ I
  have cy : CyclicMarked (fun i => u (i%k)) p k := by
    refine ⟨fun i => by simp [p], fun i hi => hm.1 _ hi,?_⟩
    intro i j ij near pi pj eq
    have same : i%k=j%k := hm.2 _ _ pi pj eq
    exact le_antisymm ij (Nat.ModEq.le_of_lt_add (show j ≡ i [MOD k] from same.symm) near)
  have cc : count p 0 k=count (·∈I) 0 k := by
    unfold count
    congr 1
    ext j
    simp only [Finset.mem_filter,Finset.mem_range,Nat.zero_add,p]
    by_cases jj : j<k <;> simp [jj,Nat.mod_eq_of_lt]
  have prefixEq : positions (fun i=>u (i%k)) (k+1)=positions u (k+1) := by
    apply List.map_congr_left
    intro j hj
    have lt:=List.mem_range.mp hj
    by_cases small:j<k
    · simp [Nat.mod_eq_of_lt small]
    · have e:j=k:=by omega
      simp [e,endeq]
  refine ⟨_,I,per_walk walk pos endeq,prefixEq.trans eq,fun j=>by simp [k],cy,?_⟩
  change count p 0 k=classCount s es
  rw [cc,hc,←t,eq]
  rfl
 
private theorem local_realization {u : Nat→Six} {p : Nat→Prop} [DecidablePred p]
    {k i n : Nat} (c : CyclicMarked u p k) (sz:n≤k) :
    ∃ I : Finset Nat, Marked u (·∈I) ∧ count (·∈I) i n=count p i n ∧
      mask (·∈I) i n=mask p i n := by
  let I:=(Finset.Ico i (i+n)).filter p
  have eq (j : Nat) : j∈I ↔ p j ∧ i≤j ∧ j < i+n := by simp [I,and_comm]
  have hm:=localMark (i:=i) c sz
  have iffEach (j : Nat) (lt : j<n) : i+j∈I ↔ p (i+j):=by
    simp [eq,lt]
  refine ⟨I,⟨fun j hj=>hm.1 j ((eq j).mp hj),fun j z hj hz e=>hm.2 _ _ ((eq j).mp hj) ((eq z).mp hz) e⟩,?_,?_⟩
  · unfold count
    congr 1
    apply Finset.filter_congr
    intro j hj
    exact iffEach _ (Finset.mem_range.mp hj)
  · unfold mask
    apply List.map_congr_left
    intro j hj
    simp [iffEach _ (List.mem_range.mp hj)]

theorem closed_stats {s : Six} {es : List Six} (r:Route src dst s es s)
    (wd:∀e∈es,e.length=7) (size:6≤es.length) : ∃T P,Realized s es T P ∧
    1995*(classCount s es-1)+(if es.length=6 then 269 else 1515)≤1644*es.length+380*T ∧
    6*(classCount s es-1)+(if es.length=6 then 0 else 5)≤5*es.length+P := by
  let k:=es.length
  obtain ⟨u,J,w,spell,per,c,ct⟩:=closed_spelling r wd (by omega)
  let p (j : Nat):=j%k∈J
  have hm : count p 0 k=classCount s es:=ct
  have cyc : CyclicMarked u p k:=c
  by_cases small : k=6
  · obtain ⟨I,hI,countI,maskI⟩:=local_realization (i:=0) (n:=k) cyc (by omega)
    have cap:=count_cap p 0 k
    let T:=endings six [] (mask (·∈I) 0 k)
    let P:=endings twin [] (mask (·∈I) 0 k)
    have whenFull (eq:classCount s es=6) : T=1:= by
      have cnt:=MarkedGeometry.mark_count (·∈I) 0 k
      rw [countI,hm,eq] at cnt
      have length : (mask (·∈I) 0 k).length=6:=by simp [mask,small]
      have all : mask (·∈I) 0 k=List.replicate 6 true:=by
        have z:=List.replicate_count_eq_of_count_eq_length (show (mask (·∈I) 0 k).count true=(mask (·∈I) 0 k).length by omega)
        rw [cnt] at z
        exact z.symm
      change endings six [] (mask (·∈I) 0 k)=1
      rw [all]; decide
    change es.length=6 at small
    refine ⟨T,P,⟨u,I,0,k,w,spell,Or.inr per,hI,countI.trans hm,rfl,rfl⟩,?_,?_⟩
    · simp only [small,ite_true]
      change k=6 at small
      by_cases full:classCount s es=6
      · have z:=whenFull full; omega
      · omega
    · simp only [small,ite_true]; change k=6 at small; omega
  · have big:7≤k:=by change 6≤k at size; omega
    have hole : ∃j,¬p j:=by
      by_contra! all
      have z:=cyclic_7 w cyc big
      have allCount : count p 0 k=k:=by simp [count,all]
      omega
    obtain ⟨j,hj⟩:=hole
    let i:=j+1
    let n:=k-1
    have many : count p i n=classCount s es:=by
      have perCount:=shift k cyc.periodic j
      have partition:=count_add p j 1 n
      rw [one,ite_eq_right hj] at partition
      rw [show 1+n=k by dsimp [n]; omega] at partition
      dsimp only [i]; omega
    obtain ⟨I,hI,countI,_⟩:=local_realization (i:=i) (n:=n) cyc (by dsimp [n]; omega)
    have eq:=countI.trans many
    obtain ⟨a,b⟩:=marks w hI i n
    rw [eq] at a b
    have nn:n+1=k:=by dsimp [n]; omega
    change ¬ es.length=6 at small
    refine ⟨_,_,⟨u,I,i,n,w,spell,Or.inr per,hI,eq,rfl,rfl⟩,?_,?_⟩
    · simp only [ite_eq_right small]; change n+1=es.length at nn; omega
    · simp only [ite_eq_right small]; change n+1=es.length at nn; omega

end ResidualDensity.ForcedRuns

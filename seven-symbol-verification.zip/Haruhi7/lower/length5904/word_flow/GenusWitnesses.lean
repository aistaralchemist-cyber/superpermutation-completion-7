import GenusContacts

set_option maxHeartbeats 100000
namespace ExactWordFlow.PermutationGenus
open Equiv

/-- Removing chosen contacts is possible without losing a rotation tag
if every removed contact has a surviving witness with that same tag. -/
private theorem fiber_charge {X Y : Type*} [DecidableEq X] [DecidableEq Y]
    (S A : Finset X) (tag : X→Y) (inside : A⊆S)
    (keep : ∀x∈A,∃y∈S,y∉A ∧ tag y=tag x) :
    A.card≤S.card-(S.image tag).card := by
  classical
  have preserves : S.image tag ⊆ (S \ A).image tag := by
    intro j hj
    obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hj
    by_cases chosen : x∈A
    · obtain ⟨y,hy,off,eq⟩:=keep x chosen
      exact Finset.mem_image.mpr ⟨y,Finset.mem_sdiff.mpr ⟨hy,off⟩,eq⟩
    · exact Finset.mem_image_of_mem _ (Finset.mem_sdiff.mpr ⟨hx,chosen⟩)
  have imageBound : ((S \ A).image tag).card≤(S \ A).card := Finset.card_image_le
  have bound := (Finset.card_le_card preserves).trans imageBound
  have counts := Finset.card_le_card inside
  rw [Finset.card_sdiff_of_subset inside] at bound
  omega

/-- Disjoint pieces of switch cycles can each supply a local collision.
Choose one endpoint to charge and retain a matching endpoint in its cycle.
All charged incidences together consume at most twice the genus. -/
theorem charge_contacts {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]
    {R h : Perm X} (seed : X) (oneOrbit : ∀y,(R*h).SameCycle seed y)
    (tag : X→Y) (onto : Function.Surjective tag) (rot : ∀x,tag (R x)=tag x)
    (classes : Fintype.card Y=720) {g : Nat} (genus : h.support.card=h.cycleType.card+719+2*g)
    (chosen : Perm X → Finset X) (sub : ∀c∈h.cycleFactorsFinset,chosen c⊆c.support)
    (keep : ∀c∈h.cycleFactorsFinset,∀x∈chosen c,∃y∈c.support,y∉chosen c ∧ tag y=tag x) :
    (∑c∈h.cycleFactorsFinset,(chosen c).card)≤2*g := by
  classical
  calc
    _ ≤ ∑c∈h.cycleFactorsFinset,(c.support.card-(c.support.image tag).card) :=
      Finset.sum_le_sum (fun c hc => fiber_charge c.support (chosen c) tag (sub c hc) (keep c hc))
    _ ≤ 2*g := repeated_contacts seed oneOrbit tag onto rot classes genus

#print axioms charge_contacts
end ExactWordFlow.PermutationGenus

import NearBindingCheck
import Cap93Data

namespace ExactWordFlow.Cap93Catalog
open SevenWordWindows RotationCore ExtremeWheelCut NearWheelBinding NearRootMoves
open private parse from NearBindingCheck

def rows : Array (Block × Answer) :=
  (((include_str "wheel-roots-93.txt").trimAscii.toString.splitOn "\n").map parse).toArray

end ExactWordFlow.Cap93Catalog

import Mathlib.Data.Multiset.FinsetOps
import Mathlib.Tactic

namespace DirectedEuler

variable {α β : Type*}

inductive Route (src dst : α → β) : β → List α → β → Prop where
  | nil (v : β) : Route src dst v [] v
  | cons {u v : β} {es : List α} (e : α) (hs : src e = u)
      (tail : Route src dst (dst e) es v) : Route src dst u (e::es) v

private theorem append {src dst : α → β} {u v t : β} {p q : List α}
    (hp : Route src dst u p v) (hq : Route src dst v q t) :
    Route src dst u (p++q) t := by
  induction hp with
  | nil => exact hq
  | cons e h _ ih => exact .cons e h (ih hq)

private def visited (dst : α → β) (s : β) (p : List α) : Set β :=
  {x | x=s ∨ ∃ e∈p, dst e=x}

private theorem splice {src dst : α → β} {s t u : β} {p q : List α}
    (hp : Route src dst s p t) (hu : u∈visited dst s p) (hq : Route src dst u q u) :
    ∃ p' : List α, (↑p' : Multiset α) = ↑p + ↑q ∧ Route src dst s p' t := by
  induction hp with
  | nil v =>
    have h : u=v := by simpa [visited] using hu
    subst u
    exact ⟨q,by simp,hq⟩
  | @cons a b ps e h tail ih =>
    by_cases ha : u=a
    · subst u
      exact ⟨q++e::ps, by simp [add_comm], append hq (.cons _ h tail)⟩
    · obtain ⟨z,hz,he⟩ := hu.resolve_left ha
      have hv : u∈visited dst (dst e) ps := by
        rcases List.mem_cons.mp hz with rfl|hz
        · exact Or.inl he.symm
        · exact Or.inr ⟨z,hz,he⟩
      obtain ⟨p',hm,hr⟩ := ih hv
      exact ⟨e::p',by rw [← Multiset.cons_coe, ← Multiset.cons_coe, Multiset.cons_add, hm], .cons e h hr⟩

private theorem exists_out {src dst : α → β} {B : Multiset α} {s t : β}
    (bal : B.map src + {t} = B.map dst + {s}) (hne : s≠t) :
    ∃ e∈B, src e=s := by
  classical
  have hin : s∈B.map src + {t} := by rw [bal]; simp
  simpa [hne] using hin

private theorem erase_balance {src dst : α → β} {B : Multiset α} {s t : β} {e : α}
    [DecidableEq α] (he : e∈B) (hs : src e = s)
    (bal : B.map src + {t} = B.map dst + {s}) :
    (B.erase e).map src + {t} = (B.erase e).map dst + {dst e} := by
  have hh : ((e ::ₘ B.erase e).map src)+{t} = ((e ::ₘ B.erase e).map dst)+{s} := by
    rw [Multiset.cons_erase he]
    exact bal
  rw [Multiset.map_cons,Multiset.map_cons,hs] at hh
  simp only [← Multiset.singleton_add] at hh
  exact add_left_cancel (a:=({s}: Multiset β)) (by simpa only [add_assoc,add_comm,add_left_comm] using hh)

private theorem partial_route (src dst : α → β) (B : Multiset α) (s t : β)
    (bal : B.map src + {t} = B.map dst + {s}) :
    ∃ (es : List α) (rem : Multiset α), ↑es + rem = B ∧
      Route src dst s es t ∧ rem.map src = rem.map dst := by
  classical
  by_cases h : s=t
  · subst t
    exact ⟨[],B,by simp, .nil _,add_right_cancel bal⟩
  obtain ⟨e,he,hs⟩ := exists_out bal h
  obtain ⟨p,rem,hm,hr,bal'⟩ := partial_route src dst (B.erase e) (dst e) t
    (erase_balance he hs bal)
  refine ⟨e::p,rem,?_,.cons _ hs hr,bal'⟩
  rw [← Multiset.cons_coe, Multiset.cons_add, hm, Multiset.cons_erase he]
termination_by B.card
decreasing_by classical
              simp [Multiset.card_erase_of_mem he]
              apply Multiset.card_pos.mpr
              intro hz
              simp [hz] at he

private theorem complete (src dst : α → β) (B : Multiset α) (s t : β)
    (reach : ∀ S : Set β, s∈S → (∀ e∈B, src e∈S → dst e∈S) → ∀ e∈B, src e∈S)
    (p : List α) (rem : Multiset α) (hm : ↑p+rem=B) (hr : Route src dst s p t)
    (bal : rem.map src = rem.map dst) :
    ∃ p' : List α, (↑p' : Multiset α)=B ∧ Route src dst s p' t := by
  classical
  by_cases empty : rem=0
  · exact ⟨p,by simpa [empty] using hm,hr⟩
  have hit : ∃ e∈rem, src e∈visited dst s p := by
    by_contra! none
    have closed (e : α) (he : e∈B) (es : src e∈visited dst s p) : dst e∈visited dst s p := by
      rw [← hm, Multiset.mem_add] at he
      rcases he with he|he
      · exact Or.inr ⟨e,he,rfl⟩
      · exact (none e he es).elim
    obtain ⟨e,he⟩ := Multiset.exists_mem_of_ne_zero empty
    exact none e he (reach _ (Or.inl rfl) closed _ (hm ▸ Multiset.mem_add.mpr (Or.inr he)))
  obtain ⟨e,he,seen⟩ := hit
  have b : rem.map src+{src e}=rem.map dst+{src e} := by rw [bal]
  obtain ⟨q,rest,hmq,hq,br⟩ := partial_route src dst (rem.erase e) (dst e) (src e)
    (erase_balance he rfl b)
  have loop : Route src dst (src e) (e::q) (src e) := .cons _ rfl hq
  obtain ⟨p',hp',hr'⟩ := splice hr seen loop
  have acc : (↑(e::q):Multiset α)+rest=rem := by
    rw [← Multiset.cons_coe,Multiset.cons_add,hmq,Multiset.cons_erase he]
  exact complete src dst B s t reach p' rest (by rw [hp',add_assoc,acc,hm]) hr' br
termination_by rem.card
decreasing_by
  have n := congrArg Multiset.card acc
  simp at n
  omega

/-- Euler trail theorem for a finite multiset of labeled directed edges;
the vertex and label types may themselves be infinite. -/
theorem exists_route (src dst : α → β) (B : Multiset α) (s t : β)
    (bal : B.map src + {t} = B.map dst + {s})
    (reach : ∀ S : Set β, s∈S → (∀ e∈B, src e∈S → dst e∈S) → ∀ e∈B, src e∈S) :
    ∃ es : List α, (↑es : Multiset α) = B ∧ Route src dst s es t := by
  obtain ⟨p,rem,hp,hr,br⟩ := partial_route src dst B s t bal
  exact complete src dst B s t reach p rem hp hr br

/-- A trail contributes one more departure than arrival at its source and
one more arrival than departure at its sink, with coincident ends allowed. -/
theorem Route.balance {src dst : α → β} {s t : β} {p : List α}
    (walk : Route src dst s p t) :
    (↑p : Multiset α).map src+{t}=(↑p : Multiset α).map dst+{s} := by
  induction walk with
  | nil => simp
  | @cons u v es e h tail ih =>
    simp only [← Multiset.cons_coe,Multiset.map_cons]
    simp only [← Multiset.singleton_add,h]
    rw [add_assoc,ih]
    ac_rfl

/-- Every set closed under the trail edges and containing the source
contains the sink and the sources of all traversed edges. -/
theorem Route.closed {src dst : α → β} {s t : β} {p : List α}
    (walk : Route src dst s p t) (S : Set β) (hs : s∈S)
    (closed : ∀ e∈p, src e∈S → dst e∈S) :
    t∈S ∧ ∀ e∈p, src e∈S := by
  induction walk with
  | nil => simp [hs]
  | @cons a b ps e h tail ih =>
    have first : src e∈S := h ▸ hs
    obtain ⟨last,rest⟩ := ih (closed e (by simp) first)
      (fun i hi => closed i (List.mem_cons_of_mem e hi))
    exact ⟨last,fun i hi => (List.mem_cons.mp hi).elim (fun he => he ▸ first) (rest i)⟩


end DirectedEuler
#print axioms DirectedEuler.exists_route

import EqualityComponent91
import WheelLRAT

namespace ExactWordFlow.PlacementCertificate
open SevenWordWindows SuperpermutationBounds Std.Sat

/-- Lexicographic order of permutations on 0,...,6. -/
def table : List Block := allPerms.sort (· ≤ ·)
def row (r : Nat) : Block := table[r]?.getD []
def var (r i : Nat) := 5898*r+i

/-- DIMACS IDs are one higher than the zero-based variables in Std.Sat. -/
inductive Schema
  | required (r : Nat)
  | conflict (r i k s j l : Nat)
deriving DecidableEq, Repr

def legal : Schema → Bool
  | .required r => decide (r < table.length)
  | .conflict r i k s j l => decide
      (r<table.length ∧ s<table.length ∧ i<5898 ∧ j<5898 ∧ k<7 ∧ l<7 ∧
       i+k=j+l ∧ (row r)[k]? ≠ (row s)[l]?)

def clause : Schema → CNF.Clause Nat
  | .required r => .ofLiterals ((List.range 5898).map fun i => (var r i,true))
  | .conflict r i _ s j _ => .ofLiterals [(var r i,false),(var s j,false)]

def formula (ss : List Schema) : CNF Nat := ⟨(ss.map clause).toArray⟩
def occurs (w p : Block) (i : Nat) : Prop := (w.drop i).take 7 = p
def truth (w : Block) (v : Nat) := decide ((w.drop (v%5898)).take 7 = row (v/5898))

theorem row_mem {r : Nat} (hr : r<table.length) : row r ∈ representatives := by
  have mem : row r ∈ table := by rw [row,List.getElem?_eq_getElem hr]; exact List.getElem_mem hr
  exact List.mem_toFinset.mp ((Finset.mem_sort (s:=allPerms) (· ≤ ·)).mp mem)

private theorem at_named (w : Block) (r i : Nat) (hi : i<5898) :
    truth w (var r i) = true ↔ occurs w (row r) i := by
  have d : (5898*r+i)/5898=r := by omega
  have m : (5898*r+i)%5898=i := by omega
  simp [truth,var,occurs,d,m]

private theorem letter_at {w p : Block} {i k : Nat} (h : occurs w p i) (hk : k<7) :
    p[k]? = w[i+k]? := by
  rw [←h,List.getElem?_take_of_lt hk,List.getElem?_drop]

private theorem occurs_of_split {w p l t : Block} (eq : w=l++p++t) (width : p.length=7) :
    occurs w p l.length := by
  simp [occurs,eq,List.append_assoc,←width]

/-- Conflict clauses require no covering hypothesis. For a positive clause
it suffices for its own permutation to occur. -/
def requested (w : Block) : Schema → Prop
  | .required r => ∃ l t : Block, w=l++row r++t
  | .conflict .. => True

theorem clause_sound_if_requested {w : Block} (bound : w.length≤5904)
    (s : Schema) (ok : legal s=true) (hit : requested w s) : (clause s).eval (truth w) = true := by
  cases s with
  | required r =>
    have hr : r<table.length := of_decide_eq_true ok
    have width := ((mem_reps _).mp (row_mem hr)).1
    obtain ⟨l,t,eq⟩ := hit
    have size := congrArg List.length eq
    simp only [List.length_append] at size
    have hi : l.length<5898 := by omega
    have here := (at_named w r l.length hi).mpr (occurs_of_split eq width)
    rw [clause,CNF.Clause.eval,CNF.Clause.literals_ofLiterals]
    exact List.any_eq_true.mpr ⟨(var r l.length,true),List.mem_map.mpr ⟨_,List.mem_range.mpr hi,rfl⟩,
      by simp [here]⟩
  | conflict r i k s j l =>
    obtain ⟨_,_,hi,hj,hk,hl,same,different⟩ := of_decide_eq_true ok
    by_cases left : truth w (var r i) = true
    · have right : truth w (var s j) ≠ true := by
        intro v
        have a := letter_at ((at_named w r i hi).mp left) hk
        have b := letter_at ((at_named w s j hj).mp v) hl
        exact different (a.trans (same ▸ b.symm))
      have no := Bool.eq_false_iff.mpr right
      simp [clause,CNF.Clause.eval,CNF.Clause.literals_ofLiterals,no]
    · have no := Bool.eq_false_iff.mpr left
      simp [clause,CNF.Clause.eval,CNF.Clause.literals_ofLiterals,no]

theorem clause_sound {w : Block} (cov : Covers w) (bound : w.length≤5904)
    (s : Schema) (ok : legal s=true) : (clause s).eval (truth w) = true := by
  apply clause_sound_if_requested bound s ok
  cases s with
  | required r =>
    obtain ⟨width,good⟩ := (mem_reps _).mp (row_mem (of_decide_eq_true ok))
    exact cov (row r) width good
  | conflict => trivial

theorem partial_word_satisfies {ss : List Schema} (valid : ss.all legal=true)
    {w : Block} (bound : w.length≤5904) (hit : ∀ s∈ss, requested w s) :
    (formula ss).eval (truth w)=true := by
  rw [formula,CNF.eval,Array.all_eq_true_iff_forall_mem]
  intro c hc
  obtain ⟨s,hs,rfl⟩ := List.mem_map.mp (List.mem_toArray.mp hc)
  exact clause_sound_if_requested bound s (List.all_eq_true.mp valid s hs) (hit s hs)

theorem word_satisfies {ss : List Schema} (valid : ss.all legal=true)
    {w : Block} (cov : Covers w) (bound : w.length≤5904) :
    (formula ss).eval (truth w)=true := by
  rw [formula,CNF.eval,Array.all_eq_true_iff_forall_mem]
  intro c hc
  obtain ⟨s,hs,rfl⟩ := List.mem_map.mp (List.mem_toArray.mp hc)
  exact clause_sound cov bound s (List.all_eq_true.mp valid s hs)

theorem optimum_of_unsat {ss : List Schema} (valid : ss.all legal=true)
    (unsat : (formula ss).Unsat) : SuperpermBridge.HR.Ssuper 7=5905 := by
  apply Target107.goal_iff_minimum.mp
  apply EqualityComponent91.ceiling_equivalence.mpr
  apply (Core1501.completion_goal (@EqualityComponent91.component_limit)).mp
  rintro ⟨w,cov,bound⟩
  have yes := word_satisfies valid cov bound
  simpa [yes] using unsat (truth w)

theorem optimum_of_lrat {ss : List Schema} {proof : String} (valid : ss.all legal=true)
    (passed : WheelLRAT.batch [formula ss] [proof]=true) : SuperpermBridge.HR.Ssuper 7=5905 :=
  optimum_of_unsat valid (WheelLRAT.batch_sound passed (formula ss) (by simp))

#print axioms optimum_of_lrat
end ExactWordFlow.PlacementCertificate

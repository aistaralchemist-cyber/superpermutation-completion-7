import Prefix375

namespace ExactWordFlow.AlphabetSeeds
open SevenWordWindows ExtremeWheelCut SeedWheelCut

/-- Relabelling by swapping alphabet letters i,i+1 and restoring the
canonical starting position of the resulting circular word. -/
private def raw (i : Fin 6) (x : Block) : Block :=
  classKey (x.map (Equiv.swap i.castSucc i.succ))

private def action (i : Fin 6) (x : Block) : Block :=
  if x∈allClasses then raw i x else x

-- The local generators suffice, whatever the length of the relabelling.
private theorem generators :
    (∀i,∀x∈allClasses,raw i x∈allClasses ∧ raw i (raw i x)=x) ∧
    (∀i,∀w∈allRows,w⊆allClasses ∧ w.image (raw i)∈allRows) := by native_decide

private theorem invol (i : Fin 6) : Function.Involutive (action i) := by
  intro x
  by_cases where_ : x∈allClasses
  · obtain ⟨closed,undo⟩:=generators.1 i x where_
    simp [action,where_,closed,undo]
  · simp [action,where_]

private theorem flip (i : Fin 6) {x : Block} {S : Finset Block} :
    x∈S.image (action i) ↔ action i x∈S := by
  constructor
  · intro hx
    obtain ⟨y,hy,eq⟩:=Finset.mem_image.mp hx
    rwa [←eq,invol i y]
  · intro hx
    exact Finset.mem_image.mpr ⟨action i x,hx,invol i x⟩

private theorem row_action (i : Fin 6) {w : Finset Block} (hw : w∈allRows) :
    w.image (action i)∈allRows := by
  obtain ⟨where_,good⟩:=generators.2 i w hw
  have eq : w.image (action i)=w.image (raw i) :=
    Finset.image_congr (fun x hx=>by simp [action,where_ hx])
  rwa [eq]

private theorem mirror (i : Fin 6) (A : Finset Block) (W : Finset (Finset Block))
    (linked : ClosedCover A allClasses W) :
    ClosedCover (A.image (action i)) allClasses (W.image (Finset.image (action i))) := by
  intro C sub stable
  have sub' : A⊆C.image (action i) := fun x hx=>(flip i).mpr (sub (Finset.mem_image_of_mem _ hx))
  have reach:=linked (C.image (action i)) sub' (fun w hw meet=>by
    obtain ⟨x,hx⟩:=meet
    obtain ⟨here,edge⟩:=Finset.mem_inter.mp hx
    have cross : (C∩w.image (action i)).Nonempty :=
      ⟨action i x,Finset.mem_inter.mpr ⟨(flip i).mp here,Finset.mem_image_of_mem _ edge⟩⟩
    have onward:=stable _ (Finset.mem_image_of_mem _ hw) cross
    exact fun y hy=>(flip i).mpr (onward (Finset.mem_image_of_mem _ hy)))
  intro x hx
  have inside : action i x∈allClasses := by simpa [action,hx] using (generators.1 i x hx).1
  have final := (flip i).mp (reach inside)
  rwa [invol i x] at final

def relabel : List (Fin 6) → Finset Block → Finset Block
  | [],P=>P
  | i::tail,P=>(relabel tail P).image (action i)

def rulesOut (P : Finset Block) (maxTags maxRows : Nat) := ∀(A : Finset Block)
    (W : Finset (Finset Block)), P⊆A → W⊆allRows →
    A.card≤ maxTags → W.card≤ maxRows → ¬ClosedCover A allClasses W

/-- Transport *any* forbidden seed through any product of adjacent
alphabet transpositions, with the same root and wheel budgets. -/
theorem transport (ops : List (Fin 6)) (P : Finset Block) {a q : Nat}
    (exclude : rulesOut P a q) : rulesOut (relabel ops P) a q := by
  induction ops with
  | nil => exact exclude
  | cons i tail ih =>
    intro A W inside legal size cap linked
    apply ih (A.image (action i)) (W.image (Finset.image (action i)))
    · exact fun _ hx=>(flip i).mpr (inside (Finset.mem_image_of_mem _ hx))
    · intro b hb
      obtain ⟨w,hw,eq⟩:=Finset.mem_image.mp hb
      exact eq ▸ row_action i (legal hw)
    · exact Finset.card_image_le.trans size
    · exact Finset.card_image_le.trans cap
    · exact mirror i A W linked

theorem all_labelings (ops : List (Fin 6)) : rulesOut (relabel ops Prefix375.prefixTags) 390 66 :=
  transport ops _ (fun _ _ inside legal size cap=>Prefix375.no_completion inside legal size cap)

#print axioms all_labelings
end ExactWordFlow.AlphabetSeeds

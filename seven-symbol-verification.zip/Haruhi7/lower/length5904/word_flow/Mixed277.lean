import Mixed277Checked
import Mixed277Logic
import Mixed277Hard

namespace ExactWordFlow.Mixed277
open SevenWordWindows ResidualDensity Cap35Fibers SeedWheelCut ExtremeWheelCut

theorem no_seed {R : Finset Block} (root : R∈roots) {z : Block} (hz : full z)
    {p : Block} (hp : p∈fiber z) {W : Finset (Finset Block)}
    (legal : W⊆allRows) (size : W.card≤91) : ¬ ClosedCover (R∪(fiber z).erase p) allClasses W :=
  reject root (fiber_in hz) checks geometry (fun _ member=>Mixed277Hard.unsat member) hp legal size

#print axioms no_seed
end ExactWordFlow.Mixed277

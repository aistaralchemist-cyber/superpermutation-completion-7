import Cap93Mass

namespace ExactWordFlow.GlobalClosedPrice
open SevenWordWindows ResidualDensity DirectedEuler ResidualIncidence ResidualRoutes RotationComponentCount
open scoped Classical
open private closeCap cyclic_price from Cap93Mass
open private hits Cost totals rank_partition from NearHundredShape

/-- Numerators measured at denominator 45. Every nonstart component pays
three units; longer components carry further charges. -/
def fee (k : Nat) : Nat :=
  3+(if 6<k then 22 else 0)+(if 6<k ∧ k≠35 then 4 else 0)+(if 214≤k then 16 else 0)

private theorem finite_prices : ∀k : Fin 214, 6≤k.val →
    45*(closeCap k.val-1)+fee k.val ≤38*k.val := by native_decide

private theorem price (k c : Nat) (low : 6≤k) (cap : c≤closeCap k) :
    45*(c-1)+fee k≤38*k := by
  by_cases big : 214≤k
  · have n6 : ¬k≤6:=by omega
    have n40 : ¬ k<40:=by omega
    have n65 : ¬ k<65:=by omega
    have n214 : ¬ k<214:=by omega
    simp [closeCap,n6,n40,n65,n214] at cap
    have pay : fee k=45:=by simp [fee,big,show 6<k by omega,show k≠35 by omega]
    rw [pay]
    omega
  · have p:=finite_prices ⟨k,by omega⟩ low
    change 45*(closeCap k-1)+fee k≤38*k at p
    omega

/-- This price applies at every component count. The right side depends only
on the total number of extra edges. -/
theorem rank_price {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    45*separateRank X s+(∑q∈occupied X s,fee ((part X q).card))≤38*X.card+59 := by
  classical
  let Q:=occupied X s
  let home:=label X s
  have pay (q) (hq:q∈Q) : 45*(hits X s q-1)+fee (Cost X q)≤38*Cost X q := by
    have active:q∈active X s:=occupied_active h ▸ hq
    have size:6≤Cost X q:=(Finset.mem_filter.mp active).2.2
    have away:q≠home:=(Finset.mem_erase.mp hq).1
    obtain ⟨v,_,eq⟩:=residual_clean h away (by change 0<Cost X q; omega)
    obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance v
    rw [eq] at bag lv ends
    obtain ⟨aa,bb⟩:=ends.2 away
    subst a; subst b
    have len:es.length=Cost X q:=congrArg Multiset.card bag
    have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
    have cap:=cyclic_price r wd (by omega)
    rw [len] at cap
    exact price _ _ size ((contacts_bound _ lv r bag).trans cap)
  obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (e) (he:e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have op:=WeightedMarks.path_cap r wd
  have hit:hits X s home≤classCount s es:=contacts_bound _ lv r bag
  have root : 45*(hits X s home-1)≤38*Cost X home+59:=by omega
  have rank:=rank_partition h
  change separateRank X s=hits X s home-1 + ∑q∈Q,(hits X s q-1) at rank
  have sum:=Finset.sum_le_sum pay
  simp only [Finset.sum_add_distrib,←Finset.mul_sum] at sum
  have total:=(totals h).1
  change Cost X home+6*Q.card+(∑q∈Q,(Cost X q-6))=X.card at total
  have split:(∑q∈Q,Cost X q)= 6*Q.card+∑q∈Q,(Cost X q-6) := by
    calc
      _ = ∑q∈Q,(6+(Cost X q-6)) := by
        apply Finset.sum_congr rfl
        intro q hq
        have active:q∈active X s:=occupied_active h ▸ hq
        have size:6≤Cost X q:=(Finset.mem_filter.mp active).2.2
        omega
      _ = _ :=by simp [Finset.sum_add_distrib,Nat.mul_comm]
  change 45*separateRank X s+(∑q∈Q,fee (Cost X q))≤38*X.card+59
  omega

theorem budget {X : Multiset Block} {s t : Block} (h : Feasible X s t) :
    32355+(∑q∈occupied X s,fee ((part X q).card))≤38*X.card+59 := by
  have bound:=rank_price h
  have rank : 719≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  omega

private theorem lump {ι : Type*} (s : Finset ι) (p : ι→Prop) [DecidablePred p] (c : Nat) :
    (∑i∈s,if p i then c else 0)=c*(s.filter p).card := by
  rw [←Finset.sum_filter]
  simp [Nat.mul_comm]

/-- N counts all nonstart components. B counts those longer than six,
D counts the members of B of size other than 35, and H counts those of
size at least 214. -/
theorem count_bound {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd:X.card≤858) :
    let Q:=occupied X s
    3*Q.card + 22*(Q.filter (fun q=>6<(part X q).card)).card +
      4*(Q.filter (fun q=>6<(part X q).card ∧ (part X q).card≠35)).card +
      16*(Q.filter (fun q=>214≤(part X q).card)).card ≤308 := by
  classical
  have b:=budget h
  simp only [fee,Finset.sum_add_distrib,lump,Finset.sum_const,smul_eq_mul] at b
  dsimp only
  omega

/-- Keep the exact rank surplus to charge overlaps even below saturation. -/
theorem rank_surplus {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd:X.card≤858) :
    let Q:=occupied X s
    45*(separateRank X s-719)+3*Q.card + 22*(Q.filter (fun q=>6<(part X q).card)).card +
      4*(Q.filter (fun q=>6<(part X q).card ∧ (part X q).card≠35)).card +
      16*(Q.filter (fun q=>214≤(part X q).card)).card ≤308 := by
  classical
  have bound:=rank_price h
  simp only [fee,Finset.sum_add_distrib,lump,Finset.sum_const,smul_eq_mul] at bound
  have rank : 719≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  dsimp only
  omega

theorem tree_range {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤858)
    (many : 88≤(occupied X s).card) : separateRank X s=719 := by
  have surplus:=rank_surplus h bd
  dsimp only at surplus
  have rank : 719≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  omega

theorem at_most_twelve {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd:X.card≤858) :
    ((occupied X s).filter (fun q=>6<(part X q).card)).card≤12 := by
  have n:=count_bound h bd
  dsimp only at n
  have sub:=Finset.card_filter_le (s:=occupied X s) (p:=fun q=>6<(part X q).card)
  omega

/-- In particular, any still unclassified N=89,90,91,92 case has at
most one non-wheel component, and it is shorter than 214 edges. -/
theorem high_count {X : Multiset Block} {s t : Block} (h : Feasible X s t) (bd : X.card≤858)
    (many : 89≤(occupied X s).card) :
    ((occupied X s).filter (fun q=>6<(part X q).card)).card≤1 ∧
    ∀q∈occupied X s,(part X q).card≤213 := by
  classical
  let Q:=occupied X s
  have price:=count_bound h bd
  dsimp only at price
  refine ⟨by omega,?_⟩
  intro q hq
  by_contra! large
  have p1:=Finset.card_pos.mpr (show (Q.filter (fun q=>6<(part X q).card)).Nonempty from
    ⟨q,Finset.mem_filter.mpr ⟨hq,by omega⟩⟩)
  have p2:=Finset.card_pos.mpr (show (Q.filter (fun q=>6<(part X q).card ∧ (part X q).card≠35)).Nonempty from
    ⟨q,Finset.mem_filter.mpr ⟨hq,by omega⟩⟩)
  have p3:=Finset.card_pos.mpr (show (Q.filter (fun q=>214≤(part X q).card)).Nonempty from
    ⟨q,Finset.mem_filter.mpr ⟨hq,by omega⟩⟩)
  dsimp only [Q] at p1 p2 p3
  omega

#print axioms count_bound
#print axioms at_most_twelve
end ExactWordFlow.GlobalClosedPrice

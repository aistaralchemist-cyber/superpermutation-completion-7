import Core1620
import CrossingRotations

namespace ExactWordFlow.PrivateClassCut
open SevenWordWindows SuperpermutationBounds DirectedEuler ResidualRoutes ResidualDensity
open CoreAssembly RotationCore RotationReinsert RotationSpan

/-- Delete one copy of every permutation in each selected rotation class.
The seven occurrences for a class may lie anywhere in the word. -/
def remaining (w : Block) (S : Finset Block) := bag w - mandatory S

/-- A rotation class still has a six-letter anchor in the component of the
original initial state. This condition mentions no ordering of the edges. -/
def hasRootTag (w : Block) (S : Finset Block) (d : Block) :=
  ∃u, full u ∧ tag u=d ∧ label (remaining w S) u=label (remaining w S) (w.take 6)

private theorem req_tags : ∀p∈representatives,full (src p) ∧ tag (src p)=classKey p := by
  native_decide

private theorem take_le {w : Block} {S : Finset Block} (sub : S⊆complete w) :
    mandatory S ≤ bag w := by
  have uniq : required.Nodup := Multiset.coe_nodup.mpr (List.nodup_permutations _ (List.nodup_finRange _))
  apply (Multiset.le_iff_subset (uniq.filter _)).mpr
  intro p hp
  obtain ⟨rep,sel⟩ := Multiset.mem_filter.mp hp
  exact ((mem_complete _ _).mp (sub sel)).2 p rep rfl

private theorem decomposition {w : Block} {S : Finset Block} (sub : S⊆complete w) :
    remaining w S+mandatory S=bag w := tsub_add_cancel_of_le (take_le sub)

private theorem keep {w : Block} {S : Finset Block} (sub : S⊆complete w) {e : Block}
    (orig : e∈windows w) (out : classKey e∉S) : e∈remaining w S := by
  have he : e∈remaining w S + mandatory S := decomposition sub ▸ (show e∈bag w from orig)
  exact (Multiset.mem_add.mp he).resolve_right (fun hm=>out (Multiset.mem_filter.mp hm).2)

private theorem legal_class {w c : Block} {S : Finset Block} (sub : S⊆complete w)
    (hc : c∈complete w) (out : c∉S) :
    selected 0 {c} ≤ remaining w S := by
  have uniq : required.Nodup := Multiset.coe_nodup.mpr (List.nodup_permutations _ (List.nodup_finRange _))
  simp only [selected,zero_add]
  apply (Multiset.le_iff_subset (uniq.filter _)).mpr
  intro p hp
  obtain ⟨rep,sel⟩:=Multiset.mem_filter.mp hp
  have eq : classKey p=c := by simpa using sel
  exact keep sub (((mem_complete _ _).mp hc).2 p rep eq) (eq ▸ out)

/-- Arbitrarily interleaved full rotation classes can all be removed when
the residual root sees each class. The spelling retains every unselected
completed class, even when the residual contains other components. -/
theorem erase_many {w : Block} {S : Finset Block} (long : 6≤w.length)
    (sub : S⊆complete w) (hit : ∀d∈allClasses,hasRootTag w S d) :
    ∃v : Block, 6≤v.length ∧ v.length+7*S.card≤w.length ∧
      (visited v).card=720 ∧ complete w \ S ⊆ complete v := by
  classical
  let Y:=remaining w S
  let s:=w.take 6
  let t:=w.drop (w.length-6)
  have eq:=decomposition sub
  have area : S⊆allClasses := sub.trans ((complete_subset w).trans (visited_subset w))
  obtain ⟨count,cycle⟩:=mandatory_data S area
  have balance:= (read_route w long).balance
  change (bag w).map src+{t}=(bag w).map dst+{s} at balance
  rw [←eq,Multiset.map_add,Multiset.map_add,cycle,add_right_comm,add_right_comm (remaining w S |>.map dst)] at balance
  have bal : Y.map src+{t}=Y.map dst+{s} := add_right_cancel balance
  obtain ⟨a,b,es,bagEq,trail,_,endInfo⟩:=component_route bal s
  obtain ⟨rfl,rfl⟩:=endInfo.1 rfl
  have old (e) (he : e∈es) : e∈windows w := by
    have inY:= (in_part.mp (bagEq ▸ (show e∈(↑es : Multiset Block) from he))).1
    change e∈bag w
    rw [←eq]
    exact Multiset.mem_add.mpr (Or.inl inY)
  obtain ⟨v,num,first,win⟩:=spell_route trail (by simp [s]; omega)
    (fun e he => window_width w (old e he))
  have sz:=congrArg Multiset.card eq
  simp only [Multiset.card_add,bag,Multiset.coe_card,windows_length,count] at sz
  have partSize := Multiset.card_le_card (Multiset.filter_le (fun e => label Y (src e)=label Y s) Y)
  change (part Y (label Y s)).card≤Y.card at partSize
  rw [←bagEq,Multiset.coe_card] at partSize
  have see : allClasses⊆visited v := by
    intro d hd
    obtain ⟨u,clean,key,root⟩:=hit d hd
    have here:=ResidualRoutes.visits rfl trail bagEq root
    exact (mem_visited _ _).mpr ⟨u,by simpa [anchors,first,win] using here,clean,key⟩
  refine ⟨v,by omega,by dsimp [Y] at partSize; omega,
    by rw [Finset.Subset.antisymm (visited_subset v) see,board],?_⟩
  intro c hc
  obtain ⟨done,out⟩:=Finset.mem_sdiff.mp hc
  obtain ⟨onBoard,all⟩:=(mem_complete _ _).mp done
  obtain ⟨u,clean,key,root⟩:=hit c onBoard
  apply (mem_complete _ _).mpr
  refine ⟨onBoard,fun p hp cls=>?_⟩
  obtain ⟨fp,tagp⟩:=req_tags p hp
  have pp := join_same (X:=0) (S:={c}) fp clean ((tagp.trans cls).trans key.symm)
    (by simp [tagp,cls])
  rw [win]
  change p∈(↑es : Multiset Block)
  rw [bagEq]
  exact in_part.mpr ⟨keep sub (all p hp cls) (cls ▸ out),
    (label_lift (legal_class sub done out) pp).trans root⟩

/-- Before any removed permutation from c is encountered in the original
route, its own source is already reachable. Thus c cannot be the sole
missing class after deleting a single lap. -/
theorem own_anchor {w c : Block} (long : 6≤w.length) (hc : c∈complete w) :
    hasRootTag w {c} c := by
  classical
  have sub : ({c}:Finset Block)⊆complete w := by simpa
  let Y:=remaining w {c}
  let s:=w.take 6
  let P : Set Block := {u | label Y u=label Y s}
  by_contra! no
  have closed (e) (he : e∈windows w) (atSrc : src e∈P) : dst e∈P := by
    have hm : e∈bag w := he
    rw [←decomposition sub] at hm
    rcases Multiset.mem_add.mp hm with remain|removed
    · exact (on_edge remain).symm.trans atSrc
    obtain ⟨rep,sel⟩:=Multiset.mem_filter.mp removed
    obtain ⟨fu,key⟩:=req_tags e rep
    exact (no ⟨_,fu,key.trans (by simpa using sel),atSrc⟩).elim
  obtain ⟨board,all⟩:=(mem_complete _ _).mp hc
  have tab : ∀k∈allClasses, k∈representatives ∧ classKey k=k := by native_decide
  obtain ⟨rep,key⟩:=tab c board
  have orig:=all c rep key
  have reach:=(read_route w long).closed P (show s∈P from rfl) (fun e he hs=>closed e he hs)
  exact no ⟨_,(req_tags _ rep).1,(req_tags _ rep).2.trans key,reach.2 c orig⟩


/-- If c remains anchored after deleting d, then every one of its seven
phases lies in that component, since all c edges are still present. -/
private theorem all_phases {w c d u : Block} (hc : c∈complete w) (hd : d∈complete w)
    (diff : c≠d) (hit : hasRootTag w {d} c) (clean : full u) (key : tag u=c) :
    label (remaining w {d}) u=label (remaining w {d}) (w.take 6) := by
  obtain ⟨v,fv,kv,mem⟩:=hit
  have inside:=join_same (X:=0) (S:={c}) clean fv (key.trans kv.symm) (by simp [key])
  have sub : ({d}:Finset Block)⊆complete w := by simpa
  exact (label_lift (legal_class sub hc (by simpa)) inside).trans mem

/-- A tag blocked by deletion of c cannot serve as a further separator
on the initial side of c. The initial side of c is wholly preserved if
we delete d instead. -/
private theorem nested {w c d : Block} (hc : c∈complete w) (hd : d∈complete w)
    (miss : ¬hasRootTag w {c} d) {u : Block}
    (root : label (remaining w {c}) u=label (remaining w {c}) (w.take 6)) :
    label (remaining w {d}) u=label (remaining w {d}) (w.take 6) := by
  let Y:=remaining w {c}
  let Z:=remaining w {d}
  let s:=w.take 6
  let P : Set Block := {v | label Y v=label Y s → label Z v=label Z s}
  have subc : ({c}:Finset Block)⊆complete w := by simpa
  have subd : ({d}:Finset Block)⊆complete w := by simpa
  have stable (e) (he : e∈Y) : src e∈P ↔ dst e∈P := by
    have step:=on_edge he
    change (label Y (src e)=label Y s → _) ↔ (label Y (dst e)=label Y s → _)
    rw [←step]
    by_cases here : label Y (src e)=label Y s
    · have orig : e∈bag w := decomposition subc ▸ Multiset.mem_add.mpr (Or.inl he)
      rw [←decomposition subd] at orig
      rcases Multiset.mem_add.mp orig with present|rem
      · rw [on_edge present]
      obtain ⟨rep,which⟩:=Multiset.mem_filter.mp rem
      obtain ⟨good,key⟩:=req_tags e rep
      exact (miss ⟨src e,good,key.trans (by simpa using which),here⟩).elim
    · simp [here]
  exact ((invariant P stable root.symm).mp (show s∈P from fun _=>rfl)) root

private theorem dst_tag : ∀p∈representatives, full (dst p) ∧ tag (dst p)=classKey p := by
  native_decide

private theorem two_sides {w c d : Block} (long : 6≤w.length) (hc : c∈complete w)
    (hd : d∈complete w) (diff : c≠d) (dc : hasRootTag w {c} d)
    (cd : hasRootTag w {d} c) {x : Block} (seen : x∈visited w) :
    hasRootTag w {c} x ∨ hasRootTag w {d} x := by
  let Y:=remaining w {c}
  let Z:=remaining w {d}
  let s:=w.take 6
  let P : Set Block := {v | label Y v=label Y s ∨ label Z v=label Z s}
  have subc : ({c}:Finset Block)⊆complete w := by simpa
  have subd : ({d}:Finset Block)⊆complete w := by simpa
  have step (e) (he : e∈windows w) (hs : src e∈P) : dst e∈P := by
    have hy : e∈Y+mandatory {c} := decomposition subc ▸ (show e∈bag w from he)
    have hz : e∈Z+mandatory {d} := decomposition subd ▸ (show e∈bag w from he)
    rcases Multiset.mem_add.mp hy with hy|removed
    · rcases Multiset.mem_add.mp hz with hz|removed
      · rcases hs with hs|hs
        · exact Or.inl ((on_edge hy).symm.trans hs)
        · exact Or.inr ((on_edge hz).symm.trans hs)
      · obtain ⟨rep,which⟩:=Multiset.mem_filter.mp removed
        exact Or.inl (all_phases hd hc diff.symm dc (dst_tag e rep).1
          ((dst_tag e rep).2.trans (by simpa using which)))
    · obtain ⟨rep,which⟩:=Multiset.mem_filter.mp removed
      exact Or.inr (all_phases hc hd diff cd (dst_tag e rep).1
        ((dst_tag e rep).2.trans (by simpa using which)))
  have root : s∈P := Or.inl rfl
  have ok:=(read_route w long).closed P root (fun e he hs=>step e he hs)
  obtain ⟨u,whereAt,fu,key⟩:=(mem_visited _ _).mp seen
  have atU : u∈P := by
    rcases List.mem_cons.mp whereAt with rfl|later
    · exact root
    · obtain ⟨e,he,rfl⟩:=List.mem_map.mp later
      exact step e he (ok.2 e he)
  rcases atU with l|r
  · exact Or.inl ⟨u,fu,key,l⟩
  · exact Or.inr ⟨u,fu,key,r⟩

/-- Tags with no remaining anchor on the initial side after deleting c. -/
noncomputable def blocked (w c : Block) : Finset Block := by
  classical exact (visited w).filter (fun x=>¬hasRootTag w {c} x)

private theorem blocked_iff {w c d : Block} :
    d∈blocked w c ↔ d∈visited w ∧ ¬hasRootTag w {c} d := by classical simp [blocked]

theorem strict_descendant {w c d : Block} (long : 6≤w.length)
    (hc : c∈complete w) (hd : d∈complete w) (below : d∈blocked w c) :
    blocked w d ⊂ blocked w c := by
  have sub : blocked w d⊆blocked w c := by
    intro k hk
    obtain ⟨vis,miss⟩:=blocked_iff.mp hk
    refine blocked_iff.mpr ⟨vis,?_⟩
    rintro ⟨u,fu,key,ok⟩
    exact miss ⟨u,fu,key,nested hc hd (blocked_iff.mp below).2 ok⟩
  exact (Finset.ssubset_iff_of_subset sub).mpr ⟨d,below,fun bad=>(blocked_iff.mp bad).2 (own_anchor long hd)⟩

/-- The invisible-tag sets for deleting completed classes are laminar,
on every word. For two different classes they are strictly nested or disjoint. -/
theorem laminar {w c d : Block} (long : 6≤w.length)
    (hc : c∈complete w) (hd : d∈complete w) (diff : c≠d) :
    blocked w c ⊂ blocked w d ∨ blocked w d ⊂ blocked w c ∨ Disjoint (blocked w c) (blocked w d) := by
  classical
  by_cases cd : c∈blocked w d
  · exact Or.inl (strict_descendant long hd hc cd)
  by_cases dc : d∈blocked w c
  · exact Or.inr (Or.inl (strict_descendant long hc hd dc))
  right; right
  apply Finset.disjoint_left.mpr
  intro k hk hd'
  obtain ⟨seen,noC⟩:=blocked_iff.mp hk
  have noD:=(blocked_iff.mp hd').2
  have get {a b : Block} (h : a∈complete w) (notMem : a∉blocked w b) : hasRootTag w {b} a :=
    Classical.byContradiction (fun bad=>notMem (blocked_iff.mpr ⟨complete_subset w h,bad⟩))
  rcases two_sides long hc hd diff (get hd dc) (get hc cd) seen with l|r
  · exact noC l
  · exact noD r


/-- If every completed tag has a nonempty blocked set, the strict descent
within that set must end at an incomplete tag. -/
theorem private_incomplete {w : Block} (long : 6≤w.length)
    (witness : ∀c∈complete w,(blocked w c).Nonempty) (c : Block) (hc : c∈complete w) :
    ∃d∈blocked w c,d∉complete w := by
  classical
  obtain ⟨d,below⟩:=witness c hc
  by_cases hd : d∈complete w
  · have desc:=strict_descendant long hc hd below
    have small := Finset.card_lt_card desc
    obtain ⟨e,inside,out⟩:=private_incomplete long witness d hd
    exact ⟨e,desc.le inside,out⟩
  · exact ⟨d,below,hd⟩
termination_by (blocked w c).card

/-- In any nonempty score sublevel there is a word at least as short as
the original which is lap-free, has no alternating complementary pair,
and in which deleting each complete class completely hides an incomplete tag. -/
theorem necessary_forest {w : Block} {n : ℕ} (long : 6≤w.length)
    (all : (visited w).card=720) (low : LapSkeleton.score w≤n) :
    ∃v : Block, 6≤v.length ∧ v.length≤w.length ∧ (visited v).card=720 ∧
      LapSkeleton.score v≤n ∧ LapSkeleton.LapFree v ∧ IsEmpty (CrossingRotations.Switch v) ∧
      ∀c∈complete v,∃d∈blocked v c,d∉complete v := by
  classical
  let P (k : ℕ) := ∃v : Block,6≤v.length ∧ (visited v).card=720 ∧
    LapSkeleton.score v≤n ∧ v.length=k
  have ok : ∃k,P k := ⟨_,w,long,all,low,rfl⟩
  obtain ⟨x,lx,ax,sx,mx⟩:=Nat.find_spec ok
  obtain ⟨v,longV,allV,lowV,leV,free,cross⟩:=CrossingRotations.avoid_crossings lx ax sx
  have limit:=Nat.find_min' ok (show P w.length from ⟨w,long,all,low,rfl⟩)
  refine ⟨v,longV,by omega,allV,lowV,free,cross,private_incomplete longV ?_⟩
  intro c hc
  by_contra! empty
  have visAll:=Finset.eq_of_subset_of_card_le (visited_subset v) (by rw [allV,board])
  have hit (d : Block) (hd : d∈allClasses) : hasRootTag v {c} d := by
    by_contra! no
    have there:=blocked_iff.mpr ⟨visAll ▸ hd,no⟩
    exact Finset.notMem_empty d (empty ▸ there)
  have sub : ({c}:Finset Block)⊆complete v := by simpa
  obtain ⟨z,lz,save,views,remain⟩:=erase_many longV sub hit
  simp at save
  have count:=Finset.card_le_card remain
  have diff:=Finset.card_sdiff_of_subset sub
  simp only [Finset.card_singleton] at diff
  have upper:=Finset.card_le_card (complete_subset z)
  have orig:=Finset.card_le_card (complete_subset v)
  have hpos:=Finset.card_pos.mpr (show (complete v).Nonempty from ⟨c,hc⟩)
  have sg : LapSkeleton.score z≤n := by
    unfold CrossingRotations.score LapSkeleton.score at lowV
    unfold LapSkeleton.score
    omega
  have minimal:=Nat.find_min' ok (show P z.length from ⟨z,lz,views,sg,rfl⟩)
  omega

/-- The full 5,904 decision now admits only irreducible candidates whose
entire system of private-tag separators is laminar. -/
theorem exact_1620 :
    (∃w : Block, Covers w ∧ w.length≤5904) ↔
    ∃v : Block, 6≤v.length ∧ v.length≤1620 ∧ (visited v).card=720 ∧
      LapSkeleton.LapFree v ∧ IsEmpty (CrossingRotations.Switch v) ∧
      LapSkeleton.dirty v+((LapSkeleton.starts v).length-720)+LapSkeleton.extraVisits v≤139 ∧
      ∀c∈complete v,∃d∈blocked v c,d∉complete v := by
  constructor
  · intro yes
    obtain ⟨x,long,cap,all,full⟩:=RotationCore.exact_1620.mp yes
    obtain ⟨v,long',leV,all',low,free,cross,protect⟩:=necessary_forest long all
      (n:=5904) (by unfold LapSkeleton.score; omega)
    have budget:=(LapSkeleton.score_budget long' all' free).1
    exact ⟨v,long',leV.trans cap,all',free,cross,by omega,protect⟩
  · rintro ⟨v,long,_,all,free,_,low,_⟩
    have budget:=(LapSkeleton.score_budget long all free).1
    obtain ⟨w,cover,len⟩:=expand_remaining long all
    exact ⟨w,cover,len.trans_le (by unfold LapSkeleton.score at budget; omega)⟩

/-- Deleting more completed classes cannot create a new initial-component
anchor. Thus an arbitrary nonempty joint deletion cannot succeed on a
word whose every singleton deletion already blocks another visited tag. -/
theorem monotone {w x : Block} {S T : Finset Block} (incl : S⊆T)
    (hit : hasRootTag w T x) : hasRootTag w S x := by
  have more : mandatory S ≤ mandatory T := by
    unfold mandatory
    apply Multiset.le_iff_count.mpr
    intro p
    by_cases hp : classKey p∈S
    · simp [hp,incl hp]
    · simp [hp]
  obtain ⟨u,fu,key,atRoot⟩:=hit
  exact ⟨u,fu,key,label_lift (tsub_le_tsub_left more (bag w)) atRoot⟩

theorem no_joint_cut {w : Block} (blockedOne : ∀c∈complete w,(blocked w c).Nonempty)
    {T : Finset Block} (within : T⊆complete w) (nonempty : T.Nonempty) :
    ∃d∈visited w,¬hasRootTag w T d := by
  obtain ⟨c,hc⟩:=nonempty
  obtain ⟨d,missing⟩:=blockedOne c (within hc)
  obtain ⟨orig,no⟩:=blocked_iff.mp missing
  exact ⟨d,orig,fun hit=>no (monotone (Finset.singleton_subset_iff.mpr hc) hit)⟩

#print axioms erase_many
#print axioms laminar
#print axioms no_joint_cut
#print axioms exact_1620
end ExactWordFlow.PrivateClassCut

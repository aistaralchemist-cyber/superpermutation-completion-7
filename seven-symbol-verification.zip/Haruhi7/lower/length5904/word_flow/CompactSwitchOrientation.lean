import BenesOrient
import CompactCounterexample
import Batteries.Tactic.OpenPrivate

namespace ExactWordFlow.BenesRouting
open private zeroWire from BenesOrient

/-- Heap addresses of internal nodes whose subnetworks still have at least four wires. -/
def branchNodes : Nat → Nat → List Nat
  | 0, _ | 1, _ => []
  | d+2, n => n::(branchNodes (d+1) (2*n) ++ branchNodes (d+1) (2*n+1))

theorem orientation_values (want : Nat → Bool) (f : Bank) :
    ∀ d n, oriented want d n (readSettings f d n) →
      ∀ k ∈ branchNodes d n, f k false 0=want k
  | 0,_,_ => by simp [branchNodes]
  | 1,_,_ => by simp [branchNodes]
  | d+2,n,h => by
    obtain ⟨head,hi,lo⟩:=h
    intro k hk
    rcases List.mem_cons.mp hk with rfl|sub
    · simpa only [zeroWire,Equiv.apply_symm_apply] using head
    · rcases List.mem_append.mp sub with a|b
      · exact orientation_values want f (d+1) (2*n) hi k a
      · exact orientation_values want f (d+1) (2*n+1) lo k b

theorem normalized_bank {V : Type} [Inhabited V] (f : Bank) (d : Nat)
    (rows : Array V) (size : rows.size=2^d) (want : Nat → Bool) :
    ∃ g : Bank, (∀ k∈branchNodes d 1,g k false 0=want k) ∧
      arrayRun g d 1 rows=arrayRun f d 1 rows := by
  obtain ⟨t,settings,eq⟩ := realize_orientations (V:=V) want d 1 (readSettings f d 1)
  obtain ⟨g,hg⟩ := assign_banks d t
  refine ⟨g,orientation_values want g d 1 (hg ▸ settings),?_⟩
  let xs := fun i => rows[(index d i).val]!
  have rep : Represents d rows xs := ⟨size,fun _=>rfl⟩
  have H := arrayRun_correct g d 1 rows xs rep
  have K := arrayRun_correct f d 1 rows xs rep
  apply Array.ext (H.1.trans K.1.symm)
  intro i h1 h2
  have hi : i<2^d := H.1 ▸ h1
  let j := (index d).symm ⟨i,hi⟩
  have G := H.2 j
  have F := K.2 j
  rw [hg] at G
  have out := G.trans ((eq xs j).trans F.symm)
  simp only [j,Equiv.apply_symm_apply] at out
  simpa only [getElem!_pos (arrayRun g d 1 rows) i h1,getElem!_pos (arrayRun f d 1 rows) i h2] using out

theorem internal_addresses : (branchNodes 11 1).mergeSort = List.range' 1 1023 := by native_decide

theorem is_branch {k : Nat} (lo : 0<k) (hi : k<1024) : k∈branchNodes 11 1 := by
  apply (List.mem_mergeSort (le:=fun a b : Nat => decide (a≤b))).mp
  rw [internal_addresses]
  exact List.mem_range'.mpr ⟨k-1,by omega,by omega⟩

end ExactWordFlow.BenesRouting

namespace ExactWordFlow.CompactWordCircuit
open SevenWordWindows RotationCore BenesRouting

/-- Each pair is (network node, zero-based variable index). -/
def asPin : Event × Nat → Option (Nat × Nat)
  | (.fresh (.switch k false 0),i) => if 0<k ∧ k<1024 then some (k,i) else none
  | _ => none

def pins := ((registers (goalTape true).body.toList).zipIdx).filterMap asPin

private theorem pins_sound {src : Source → Bool} {v : Nat → Bool}
    (h : admits (sourceTest src v) 0 (goalTape true).body.toList) :
    ∀p∈pins, (0<p.1 ∧ p.1<1024) ∧ v p.2=src (.switch p.1 false 0) := by
  intro p hp
  obtain ⟨⟨e,i⟩,mem,eq⟩:=List.mem_filterMap.mp hp
  have registered := List.mk_mem_zipIdx_iff_getElem?.mp mem
  cases e with
  | assertion | gateOr | gateMux => simp [asPin] at eq
  | fresh s =>
    cases s with
    | one | symbol => simp [asPin] at eq
    | switch k back bit =>
      cases back <;> cases bit <;> simp [asPin] at eq
      obtain ⟨bound,rfl⟩ := eq
      exact ⟨bound,by simpa only [Nat.zero_add] using reads_registers h registered⟩

theorem actual_pin_nodes : (pins.map Prod.fst).mergeSort = List.range' 1 1023 := by native_decide

theorem oriented_counterexample {w : Block} (len : w.length=1501)
    (hit : (visited w).card=720) (many : 91≤(complete w).card) (want : Nat → Bool) :
    ∃ v,(certFormula (goalTape true)).eval v=true ∧ ∀p∈pins,v p.2=want p.1 := by
  obtain ⟨f,wit,_⟩:=backend_witness len hit many
  obtain ⟨g,normalized,same⟩:=normalized_bank f 11 (CoreCandidateBanks.bankInput w) wit.width want
  have out : bankOutput w g=bankOutput w f := congrArg Array.toList same
  have chosen : BackendWitness w g :=
    ⟨wit.width,out ▸ wit.sorted,out ▸ wit.visited,out ▸ wit.completed⟩
  obtain ⟨v,events,sat⟩:=assignment_of_backend len hit many chosen
  refine ⟨v,sat,?_⟩
  intro p hp
  obtain ⟨bounds,value⟩:=pins_sound events p hp
  exact value.trans (normalized _ (is_branch bounds.1 bounds.2))

open Std.Sat SevenWordWindows RotationCore

/-- The original clause array followed by one negative unit for each indexed switch. -/
def orientationUnits : CNF Nat := ⟨(pins.map fun p=>CNF.Clause.ofLiterals [(p.2,false)]).toArray⟩

def orientedFormula : CNF Nat := checkerFormula (goalTape true) ++ orientationUnits

theorem counterexample_oriented_formula {w : Block} (len : w.length=1501)
    (hit : (visited w).card=720) (many : 91≤(complete w).card) :
    ∃v, orientedFormula.eval v=true := by
  obtain ⟨v,original,units⟩:=oriented_counterexample len hit many (fun _=>false)
  refine ⟨v,?_⟩
  rw [orientedFormula,CNF.eval_append,checkerFormula_eq _ (scope_checked (goal_scope true)).1,
    original,Bool.true_and]
  rw [CNF.eval,Array.all_eq_true_iff_forall_mem]
  intro c hc
  obtain ⟨p,hp,rfl⟩:=List.mem_map.mp (List.mem_toArray.mp hc)
  simp [CNF.Clause.eval,units p hp]

theorem optimum_of_oriented_unsat (no : orientedFormula.Unsat) : SuperpermBridge.HR.Ssuper 7=5905 := by
  apply CoreDecision1501.optimum_of_refutation
    (model:=∃v,orientedFormula.eval v=true)
  · intro w len occ
    obtain ⟨hit,count⟩ := (CoreDecision1501.occurrenceCover_iff w 91).mp occ
    exact counterexample_oriented_formula len hit count
  · rintro ⟨v,h⟩
    exact Bool.noConfusion (h.symm.trans (no v))

#print axioms counterexample_oriented_formula
end ExactWordFlow.CompactWordCircuit


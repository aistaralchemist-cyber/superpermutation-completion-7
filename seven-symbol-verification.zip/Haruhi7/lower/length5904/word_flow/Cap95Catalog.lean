import NearBindingFast
import Cap95Profiles
import Cap95Data
import BatchedRealizations

namespace ExactWordFlow.Cap95Catalog
open SevenWordWindows SeedWheelCut RotationCore ExtremeWheelCut NearRootMoves NearHardRoots
open ResidualDensity ResidualDensity.ExtremalRealizations ResidualDensity.Cap95Profiles
open NearWheelBinding
open private parse baseGood index checkLookup fingerprint from NearBindingCheck
open private eliminates from ExtremeWheelCut

private def rows : Array (Block × Answer) :=
  (((include_str "wheel-roots-95.txt").trimAscii.toString.splitOn "\n").map parse).toArray

def verified (n : Nat) :=
  let v := rows
  let table := (Cap95Data.hard).toArray
  v.toList.all (baseGood n table) &&
    let lut := index v
    (realizations (Cap95Profiles.profiles n)).all (checkLookup v lut)

/-- Every connected cover in one of the three complete finite geometries
can be relabelled to a remaining representative. All other rooted cases are
excluded by explicit connected-wheel forcing chains. -/
theorem exhaust_verified {n : Nat} (ver : verified n=true) {R : Finset Block}
    (geo : R∈realizations (Cap95Profiles.profiles n)) {W : Finset (Finset Block)}
    (legal : W⊆allRows) (size : W.card≤n) (covered : ClosedCover R allClasses W) :
    ∃r∈Cap95Data.hard, ∃w : Finset (Finset Block),
      w⊆allRows ∧ w.card≤n ∧ r.card=720-5*n ∧ ClosedCover r allClasses w := by
  obtain ⟨bases,links⟩:=Bool.and_eq_true_iff.mp ver
  let v := rows
  let tab := (Cap95Data.hard).toArray
  let ij := (index v).getD (fingerprint R) (v.size,0)
  have look := of_decide_eq_true (List.all_eq_true.mp links R geo)
  change ij.1<v.size ∧ applyMoves (List.replicate ij.2 7) R=visited v[ij.1]!.1 at look
  have entry : v[ij.1]!∈v.toList := by
    rw [getElem!_pos v ij.1 look.1]
    exact Array.mem_toList_iff.mpr (Array.getElem_mem look.1)
  have ok := List.all_eq_true.mp bases _ entry
  obtain ⟨V,allowed,bound,link⟩:=transport legal covered (List.replicate ij.2 7)
  rw [look.2] at link
  generalize h : v[ij.1]! = p at link ok
  obtain ⟨word,ans⟩:=p
  cases ans with
  | easy c =>
    obtain ⟨budget,cert⟩:=Bool.and_eq_true_iff.mp ok
    have price := of_decide_eq_true budget
    exact False.elim (eliminates _ _ allowed (by rw [board]; omega) cert link)
  | hard i xs =>
    obtain ⟨ix,eq,sz⟩:=of_decide_eq_true ok
    change i<tab.size at ix
    change applyMoves xs (visited word)=tab[i]! at eq
    change (tab[i]!).card=720-5*n at sz
    have mem : tab[i]!∈Cap95Data.hard := by
      change tab[i]!∈tab.toList
      rw [getElem!_pos tab i ix]
      exact Array.mem_toList_iff.mpr (Array.getElem_mem ix)
    obtain ⟨w,l,s,cc⟩:=transport allowed link xs
    rw [eq] at cc
    exact ⟨_,mem,w,l,s.trans (bound.trans size),sz,cc⟩

end ExactWordFlow.Cap95Catalog

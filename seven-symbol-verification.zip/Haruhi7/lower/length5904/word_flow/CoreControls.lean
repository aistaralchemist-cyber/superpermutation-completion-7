import CoreCounts
import Word5905

namespace ExactWordFlow.RotationCoreControls
open SevenWordWindows ResidualDensity RotationCore
abbrev source : Block := SuperpermLowerBounds.LengthBudget.Word5905.word

/-- Non-initial laps have thirteen symbols of the form u a u, with
u a a permutation. Deleting the first seven symbols leaves the same u. -/
private def lapStarts : List Nat :=
  let a := source.toArray
  (List.range (source.length-12)).filter fun i =>
    let p := (a.extract i (i+7)).toList
    i != 0 && decide p.Nodup &&
      a.extract i (i+6) == a.extract (i+7) (i+13)

/-- Distinct disjoint laps can be contracted in parallel, so the first
letter survives and taking the tail gives the same contraction of W-0021.tail. -/
private def eraseLaps (w : Block) (offsets : List Nat) : Block :=
  let removed := (offsets.flatMap fun i => (List.range 7).map (i+·)).toFinset
  w.zipIdx.filterMap fun (x,i) => if i ∈ removed then none else some x

def coreWord (k : Nat) : Block := eraseLaps source (lapStarts.take k)

def coreTruncated (k : Nat) : Block :=
  eraseLaps source.tail ((lapStarts.take k).map (·-1))

theorem tail_compatibility : ∀k∈[581,583,600], coreTruncated k=(coreWord k).tail := by
  native_decide

theorem laps_distinct :
    lapStarts.length=653 ∧ lapStarts.IsChain (fun i j => i+7≤j) ∧
    (lapStarts.map (fun i => classKey ((source.toArray.extract i (i+7)).toList))).Nodup := by
  native_decide

def summary (w : Block) := (w.length,(visited w).card,(complete w).card)

theorem reference581 :
    summary (coreWord 581)=(1838,720,139) ∧
    summary (coreTruncated 581)=(1837,720,138) := by native_decide

theorem reference583 :
    summary (coreWord 583)=(1824,720,137) ∧
    summary (coreTruncated 583)=(1823,720,136) := by native_decide

theorem reference600 :
    summary (coreWord 600)=(1705,720,120) ∧
    summary (coreTruncated 600)=(1704,720,119) := by native_decide

#print axioms reference581
#print axioms reference583
#print axioms reference600
end ExactWordFlow.RotationCoreControls

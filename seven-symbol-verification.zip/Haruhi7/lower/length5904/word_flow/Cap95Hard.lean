import WheelLRAT
import OrientedFormula
import Cap95Data

namespace ExactWordFlow.Cap95Hard
open WheelLRAT Cap95Data OrientedCNF

private def formulas := (hard).map cnf
private def certificates := wheelCertificates% formulas

/-- Each formula is constructed from the actual footprint. Lean checks
every proof against that same formula before deriving unsatisfiability. -/
theorem unsat {R} (member : R∈hard) : (cnf R).Unsat :=
  batch_sound (fs:=formulas) (cs:=certificates) (by native_decide)
    (cnf R) (List.mem_map_of_mem member)

#print axioms unsat
end ExactWordFlow.Cap95Hard

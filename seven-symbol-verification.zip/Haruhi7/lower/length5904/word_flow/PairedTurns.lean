import EmbeddedWheels

namespace ExactWordFlow.PairedTurns
open SevenWordWindows ResidualDensity ResidualIncidence ResidualRoutes GlobalWheelRank EmbeddedWheels
open scoped Classical

def rows (pairs : List (Block × Block)) (singles : List Block) :=
  pairs.flatMap (fun ab => [ab.1,ab.2]) ++ singles

private def wheelRow (w : Block) := (orbit w).toFinset
private def pairRow (ab : Block × Block) := wheelRow ab.1 ∪ wheelRow ab.2

private theorem lens (pairs : List (Block × Block)) (singles : List Block) :
    (rows pairs singles).length=2*pairs.length+singles.length := by
  induction pairs with
  | nil => simp [rows]
  | cons a l ih => simp [rows] at ih ⊢; omega

private theorem pair_cap (pairs : List (Block × Block)) (singles : List Block)
    (legit : ∀ w∈rows pairs singles, full w)
    (overlap : ∀ab∈pairs, 2≤((orbit ab.1).toFinset ∩ (orbit ab.2).toFinset).card) :
    ∃W : Finset (Finset Block),
      (∀w∈rows pairs singles, ∃u∈W, (orbit w).toFinset⊆u) ∧
      (∑u∈W,(u.card-1))≤9*pairs.length+5*singles.length := by
  classical
  let A := pairs.toFinset.image pairRow
  let B := singles.toFinset.image wheelRow
  have hm1 (a b : Block) (h : (a,b)∈pairs) : a∈rows pairs singles ∧ b∈rows pairs singles := by
    constructor <;> apply List.mem_append_left _ <;> exact List.mem_flatMap.mpr ⟨(a,b),h,by simp⟩
  have hm2 {v} (h : v∈singles) : v∈rows pairs singles := List.mem_append_right _ h
  have six (v) (hv : v∈rows pairs singles) : (wheelRow v).card=6 :=
    wheel_contacts_six v (legit v hv)
  refine ⟨A∪B,?_,?_⟩
  · intro w hw
    rcases List.mem_append.mp hw with hp|hs
    · obtain ⟨⟨a,b⟩,hab,either⟩ := List.mem_flatMap.mp hp
      refine ⟨pairRow (a,b),Finset.mem_union_left _ (Finset.mem_image_of_mem _ (List.mem_toFinset.mpr hab)),?_⟩
      simp only [List.mem_cons,List.not_mem_nil,or_false] at either
      rcases either with rfl|rfl
      · exact Finset.subset_union_left
      · exact Finset.subset_union_right
    · exact ⟨wheelRow w,Finset.mem_union_right _ (Finset.mem_image_of_mem _ (List.mem_toFinset.mpr hs)),fun _ hx => hx⟩
  · let r (u : Finset Block) := u.card-1
    have sa : (∑u∈A,r u)≤A.card*9 := by
      apply Finset.sum_le_card_nsmul
      intro q hq
      obtain ⟨⟨a,b⟩,hab,rfl⟩ := Finset.mem_image.mp hq
      have mem := hm1 a b (List.mem_toFinset.mp hab)
      have len1 := six a mem.1
      have len2 := six b mem.2
      have hc := Finset.card_union_add_card_inter (wheelRow a) (wheelRow b)
      have hl : 2 ≤ (wheelRow a ∩ wheelRow b).card := overlap (a,b) (List.mem_toFinset.mp hab)
      change (wheelRow a ∪ wheelRow b).card-1≤9
      omega
    have sb : (∑u∈B,r u)≤B.card*5 := by
      apply Finset.sum_le_card_nsmul
      intro q hq
      obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hq
      have sz := six v (hm2 (List.mem_toFinset.mp hv))
      change (wheelRow v).card-1≤5
      omega
    have ac : A.card≤pairs.length := Finset.card_image_le.trans (List.toFinset_card_le _)
    have bc : B.card ≤ singles.length := Finset.card_image_le.trans (List.toFinset_card_le _)
    have join := Finset.sum_union_inter (s₁:=A) (s₂:=B) (f:=r)
    change (∑u∈A∪B,r u)≤_
    omega

/-- Every disjoint pair of removed turns sharing at least two rotation classes
uses one unit of rank. The pairs may meet one another or the residual path,
and repeated wheel states are allowed. -/
theorem matching_bound {Y : Multiset Block} {s t : Block}
    (pairs : List (Block × Block)) (singles : List Block)
    (legit : ∀ w∈rows pairs singles, full w)
    (overlap : ∀ab∈pairs, 2≤((orbit ab.1).toFinset ∩ (orbit ab.2).toFinset).card)
    (h : Feasible (Y+turns (rows pairs singles)) s t)
    (budget : (Y+turns (rows pairs singles)).card≤858) :
    (rows pairs singles).length+10*(pairs.length+(largeOther Y s).card)≤112 := by
  obtain ⟨W,con,price⟩ := pair_cap pairs singles legit overlap
  have base := grouped_rank _ legit h W con
  have ranked := base.trans (Nat.add_le_add_right price _)
  have len := lens pairs singles
  exact (turns_with_loss _ legit h budget pairs.length (by omega)).2

end ExactWordFlow.PairedTurns
#print axioms ExactWordFlow.PairedTurns.matching_bound

import ShortCyclePotential

namespace ExactWordFlow.Cap93Mass
open ResidualDensity DirectedEuler ResidualIncidence ResidualRoutes RotationComponentCount
open private initial from MarkedDensity
open private count_cap from DensityBudget
open private hits Cost totals rank_partition from NearHundredShape
open scoped Classical

private def rootCap (k:Nat) := if k=265 then 225 else if k+1≤289 then Cap95Marked.upper (k+1) initial
  else (38*(k+1)+66)/45

private def closeCap (k:Nat) := if k≤6 then k else if k<40 then 6*k/7 else if k<65 then 34*k/40
  else if k<214 then 11*k/13 else 38*k/45

private def gain (x:Nat) := closeCap (6+x)-6

/-- Each entry bounds the largest gain in incidence rank that can be won
with exactly that many edges above six per non-start component. -/
private def bank (e:Nat) : Nat := ([
  0,0,0,1,2,3,4,5,6,6,7,8,9,10,11,12,12,13,
  14,15,16,17,18,18,19,20,21,22,23,24,24,25,26,27,28,28,
  29,30,31,32,33,33,34,35,36,37,38,39,39,40,41,42,43,44,
  45,45,46,47,48,49,49,50,51,52,53,54,54,55,56,57,58,59,
  60,60,61,62,63,64,65,65,66,67,68,69,70,71,71,72,73,74,
  75,76,76,77,78,79,80,81,82,82,83,84,85,86,87,87,88,89,
  90,91,92,93,93,94,95,96,97,98,98,99,100,101,102,103,104,104,
  105,106,107,108,109,109,110,111,112,113,114,115,115,116,117,118,119,120,
  120,121,122,123,124,125,126,126,127,128,129,130,131,131,132,133,134,135,
  136,137,137,138,139,140,141,142,142,143,144,145,146,147,148,148,149,150,
  151,152,153,153,154,155,156,157,158,159,159,160,161,162,163,164,164,165,
  166,167,168,169,170,170,171,172,173,174,174,175,176,177,178,178,179,180,
  181,182,183,184,184,185,186,187,188,189,189,190,191,192,193,194,194,195,
  196,197,198,199,200,200,201,202,203,204,205,205,206,207,208,209,210,211,
  211,212,213,214,215,216,216,217,218,219,220,221,222,222,223,224,225,226,
  227,227,228,229,230,231,232,232,233,234,235,236,237,238,238,239,240,241,
  242,243,243,244,245,246,247,248,249,249,250,251,252] : List Nat).toArray[e]?.getD 0

private theorem bank_safe : ∀x y : Fin 301,x.val+y.val≤300 →
    gain x.val+bank y.val≤bank (x.val+y.val) := by native_decide

private theorem profiles : ∀k e:Fin 301,k.val+e.val≤300 →
    719≤rootCap k.val-1+465+bank e.val →
      (k.val=300 ∧ e.val=0 ∧ rootCap k.val=255 ∧ bank e.val=0) ∨
      (k.val=271 ∧ e.val=29 ∧ rootCap k.val=231 ∧ bank e.val=24) := by native_decide

private theorem no_split : ∀x:Fin 30,0<x.val → x.val<29 → gain x.val+bank (29-x.val)<24 := by native_decide

private theorem root_price {s t:Block} {es:List Block} (r:Route src dst s es t)
    (wd:∀e∈es,e.length=7) : classCount s es≤rootCap es.length := by
  unfold rootCap
  split
  next eq => exact NoRoot265.route r wd eq
  next =>
    split
    next small => exact Cap95Marked.route_upper r wd small
    next => have bound:=WeightedMarks.path_cap r wd; omega

private theorem cyclic_price {s:Block} {es:List Block} (r:Route src dst s es s)
    (wd:∀e∈es,e.length=7) (pos:6≤es.length) : classCount s es≤closeCap es.length := by
  obtain ⟨u,I,w,cy,m⟩:=closed_observations r wd (by omega)
  unfold closeCap
  split
  next =>
    have cap:=count_cap (fun i=>i%es.length∈I) 0 es.length
    rwa [m] at cap
  next =>
    split
    next =>
      have cap:=cyclic_7 w cy (by omega : 7≤es.length)
      rw [m] at cap
      omega
    next =>
      split
      next =>
        have cap:=window_cyclic_bound cy (by omega : 40≤es.length)
          (fun i pp _ hh=>interval40 w hh i)
        rw [m] at cap
        omega
      next =>
        split
        next => have cap:=ShortCyclePotential.closed_route r wd (by omega); omega
        next => have cap:=SynchronizedCycles.closed_route r wd (by omega); omega

private theorem aggregate {ι : Type*} [DecidableEq ι] (T : Finset ι) (e rank : ι→Nat)
    (localBound : ∀q∈T,rank q≤5+gain (e q)) (lim : (∑q∈T,e q)≤300) :
    (∑q∈T,rank q)≤5*T.card+bank (∑q∈T,e q) := by
  induction T using Finset.induction_on with
  | empty => simp
  | @insert a T ha ih =>
    rw [Finset.sum_insert ha] at lim
    have old:=ih (fun q hq=>localBound _ (Finset.mem_insert_of_mem hq)) (by omega)
    have now:=localBound a (Finset.mem_insert_self ..)
    have table:=bank_safe ⟨e a,by omega⟩ ⟨∑q∈T,e q,by omega⟩ lim
    rw [Finset.sum_insert ha,Finset.sum_insert ha,Finset.card_insert_of_notMem ha]
    change gain (e a)+bank (∑q∈T,e q)≤bank (e a+∑q∈T,e q) at table
    omega

/-- With exactly 93 non-start components the entire mass is forced into a
300-edge open part, or a 271-edge open part and a single 35-edge closed part.
The start and all other components are unrestricted in the hypotheses. -/
theorem shape {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (number : (occupied X s).card=93) :
    X.card=858 ∧
      (((part X (label X s)).card=300 ∧ hits X s (label X s)=255 ∧
        ∀q∈occupied X s,(part X q).card=6) ∨
      ((part X (label X s)).card=271 ∧ hits X s (label X s)=231 ∧
        ∃q∈occupied X s,(part X q).card=35 ∧ hits X s q=30 ∧
          ∀o∈occupied X s,o≠q → (part X o).card=6)) := by
  classical
  let Q:=occupied X s
  let extra (q:Component X):=Cost X q-6
  let rank (q:Component X):=hits X s q-1
  let home:=label X s
  let E:=∑q∈Q,extra q
  let W:=∑q∈Q,rank q
  change Q.card=93 at number
  have mass:=(totals h).1
  change Cost X home+6*Q.card+E=X.card at mass
  rw [number] at mass
  have floor : 719≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  rw [rank_partition h] at floor
  change 719≤hits X s home-1+W at floor
  have gainBound (q) (hq:q∈Q): 6≤Cost X q ∧ hits X s q≤closeCap (Cost X q) := by
    have active:q∈active X s:=occupied_active h ▸ hq
    have size:6≤Cost X q:=(Finset.mem_filter.mp active).2.2
    have away: q≠home:=(Finset.mem_erase.mp hq).1
    obtain ⟨v,_,eq⟩:=residual_clean h away (by change 0<Cost X q; omega)
    obtain ⟨a,b,es,bag,r,lv,ends⟩:=component_route h.balance v
    rw [eq] at bag lv ends
    obtain ⟨aa,bb⟩:=ends.2 away
    subst a; subst b
    have len:es.length=Cost X q:=congrArg Multiset.card bag
    have wd (f) (hf:f∈es):=h.edges_seven f (in_part.mp (bag ▸ (show f∈(↑es : Multiset Block) from hf))).1
    have bound:=cyclic_price r wd (by omega)
    rw [len] at bound
    exact ⟨size,(contacts_bound _ lv r bag).trans bound⟩
  have price (q) (hq:q∈Q) : rank q≤5+gain (extra q):=by
    obtain ⟨low,cap⟩:=gainBound q hq
    simp only [gain,extra,rank,show 6+(Cost X q-6)=Cost X q by omega]
    omega
  obtain ⟨a,b,es,bag,r,lv,endp⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=endp.1 rfl
  subst a; subst b
  have len:es.length=Cost X home:=congrArg Multiset.card bag
  have wd (f) (hf:f∈es):=h.edges_seven f (in_part.mp (bag ▸ (show f∈(↑es : Multiset Block) from hf))).1
  have root:= (contacts_bound (support X s) lv r bag).trans (root_price r wd)
  change hits X s home≤rootCap es.length at root
  rw [len] at root
  have aggregateBound:=aggregate Q extra rank price (by change E≤300; omega)
  change W≤5*Q.card+bank E at aggregateBound
  rw [number] at aggregateBound
  have pair:=profiles ⟨Cost X home,by omega⟩ ⟨E,by omega⟩ (by change Cost X home+E≤300; omega) (by change 719≤rootCap (Cost X home)-1+465+bank E; omega)
  change (Cost X home=300 ∧ E=0 ∧ rootCap (Cost X home)=255 ∧ bank E=0) ∨
    (Cost X home=271 ∧ E=29 ∧ rootCap (Cost X home)=231 ∧ bank E=24) at pair
  have member (q) (hq:q∈Q) : extra q≤E:=Finset.single_le_sum (s:=Q) (f:=extra) (fun _ _=>Nat.zero_le _) hq
  change X.card=858 ∧ ((Cost X home=300 ∧ hits X s home=255 ∧ ∀q∈Q,Cost X q=6) ∨
    (Cost X home=271 ∧ hits X s home=231 ∧ ∃q∈Q,Cost X q=35 ∧ hits X s q=30 ∧
      ∀o∈Q,o≠q → Cost X o=6))
  rcases pair with ⟨rootK,empty,cap,bank0⟩|⟨rootK,spend,cap,b29⟩
  · refine ⟨by omega,Or.inl ⟨rootK,by omega,fun q hq=>?_⟩⟩
    have minimum:= (gainBound q hq).1
    have small:=member q hq
    dsimp only [extra] at small
    omega
  · have someExtra : ∃q∈Q,0<extra q:=by
      by_contra! none
      have all:E=0:=Finset.sum_eq_zero (fun q hq=>Nat.eq_zero_of_le_zero (none q hq))
      omega
    obtain ⟨q,hq,nonzero⟩:=someExtra
    let D:=Q.erase q
    let x:=extra q
    have ex:=Finset.sum_erase_add Q extra hq
    change (∑o∈D,extra o)+x=E at ex
    have rk:=Finset.sum_erase_add Q rank hq
    change (∑o∈D,rank o)+rank q=W at rk
    have dc:D.card+1=Q.card:=Finset.card_erase_add_one hq
    have old:=aggregate D extra rank (fun o ho=>price _ (Finset.mem_erase.mp ho).2) (by omega)
    have localP:rank q≤5+gain x:=price q hq
    have same : x=29:=by
      by_contra different
      have lower:0<x:=nonzero
      have strict:=no_split ⟨x,by omega⟩ lower (by change x<29; omega)
      have er : (∑o∈D,extra o)=29-x:=by omega
      rw [er] at old
      change gain x+bank (29-x)<24 at strict
      omega
    have size:Cost X q=35:=by change Cost X q-6=29 at same; omega
    have zeroRest : (∑o∈D,extra o)=0:=by omega
    rw [zeroRest,show bank 0=0 by native_decide] at old
    have upper: hits X s q≤30:=by
      have z:=(gainBound q hq).2
      rwa [size,show closeCap 35=30 by decide] at z
    refine ⟨by omega,Or.inr ⟨rootK,by omega,q,hq,size,?_,?_⟩⟩
    · have qrank : rank q=hits X s q-1:=rfl
      omega
    · intro o ho diff
      have le:=Finset.single_le_sum (s:=D) (f:=extra) (fun _ _=>Nat.zero_le _) (Finset.mem_erase.mpr ⟨diff,ho⟩)
      have minLen:=(gainBound o ho).1
      rw [zeroRest] at le
      dsimp [extra] at le
      omega

#print axioms shape
end ExactWordFlow.Cap93Mass

import BypassPackets
import TightIncidence

/-! A check on the original 35-component example. Wheels 65 and 66,
taken together, connect no previously separate mandatory components. -/
namespace ExactWordFlow.Essential
open SevenWordWindows ResidualDensity DirectedEuler ResidualRoutes

/-- Every context visited by a walk lies in the same weak component. -/
theorem walk_label {G : Multiset Block} {a b : Block} {es : List Block}
    (r : Route src dst a es b) (use : ∀ e∈es, e∈G) {v : Block} (mem : v∈a::es.map dst) :
    label G v=label G a := by
  induction r with
  | nil => simpa using congrArg (label G) (List.mem_singleton.mp mem)
  | cons e hs _ ih =>
    rcases List.mem_cons.mp mem with eq | rest
    · exact congrArg _ eq
    · have same := on_edge (use e (List.mem_cons_self ..))
      rw [hs] at same
      exact (ih (fun f hf => use f (List.mem_cons_of_mem _ hf)) (by simpa using rest)).trans same.symm

/-- Any two six-letter contexts having the same clean rotation label lie in
the same mandatory component, regardless of the additional edges. -/
theorem same_tag {A : Multiset Block} {v w : Block} (fv : full v) (fw : full w)
    (share : tag v=tag w) : label (required+A) v=label (required+A) w := by
  let cyc (z : Block) := tag z ++ tag z
  have table : states.all (fun z => decide ((cyc z).length≥6 ∧
      (z∈((cyc z).take 6 :: (windows (cyc z)).map dst)) ∧ ∀e∈windows (cyc z), e∈representatives))=true := by native_decide
  have side (z : Block) (f : full z) :
      label (required+A) z = label (required+A) ((cyc z).take 6) := by
    obtain ⟨len,visit,perm⟩ := of_decide_eq_true (List.all_eq_true.mp table z (mem_states f))
    apply walk_label (read_route _ len) _ visit
    intro e he
    exact Multiset.mem_add.mpr (Or.inl (perm e he))
  exact ((side v fv).trans (by simp [cyc,share])).trans (side w fw).symm

end ExactWordFlow.Essential

namespace Dense462.RankTight.IncidenceMap
open ExactWordFlow SevenWordWindows DirectedEuler ResidualDensity ExactWordFlow.Essential ExactWordFlow.ResidualRoutes
private def keptWalks := walks.take 65
private def droppedWalks := walks.drop 65
private def kept : Multiset Block := ↑(keptWalks.flatMap windows)
private def dropped : Multiset Block := ↑(droppedWalks.flatMap windows)
private def main := Dense462.word
private def via := walks[56]!
private def ports (w : Block) := (contexts w).filter (fun v => decide (full v))

private theorem recordFacts :
    kept+dropped=X ∧ dropped.card=12 ∧ Balanced dropped ∧
    main∈keptWalks ∧ via∈keptWalks ∧ main.length≥6 ∧ via.length≥6 ∧
    (∃u∈ports main, ∃v∈ports via, tag u=tag v) ∧
    ((droppedWalks.flatMap windows).all fun e => [src e,dst e].all fun u =>
      decide (full u ∧ ∃v∈ports main ++ ports via, tag u=tag v))=true := by native_decide

theorem redundant_pair : ∃ A B : Multiset Block, X=A+B ∧ B.card=12 ∧ Balanced B ∧ Bypassable A B := by
  obtain ⟨partition,size,bal,hm,hv,lm,lv,hshare,allv⟩ := recordFacts
  refine ⟨kept,dropped,partition.symm,size,bal,?_⟩
  let G := required+kept
  have within {w : Block} (hw : w∈keptWalks) (len : w.length≥6) {v : Block} (hv : v∈ports w) :
      label G v=label G (w.take 6) := by
    apply walk_label (read_route _ len) _ (List.mem_filter.mp hv).1
    intro e he
    exact Multiset.mem_add.mpr (Or.inr (show e∈keptWalks.flatMap windows from List.mem_flatMap.mpr ⟨w,hw,he⟩))
  have fullPort {w v : Block} (h : v∈ports w) : full v := of_decide_eq_true (List.mem_filter.mp h).2
  obtain ⟨u,hu,v,hz,eq⟩ := hshare
  have same : label G (via.take 6) = label G (main.take 6) :=
    (within hv lv hz).symm.trans ((same_tag (fullPort hz) (fullPort hu) eq.symm).trans (within hm lm hu))
  intro e he
  have good := List.all_eq_true.mp allv e (show e∈droppedWalks.flatMap windows from he)
  have endLabel (z : Block) (hz : z∈[src e,dst e]) : label G z=label G (main.take 6) := by
    obtain ⟨fz,v,hv',eq⟩ := of_decide_eq_true (List.all_eq_true.mp good z hz)
    rcases List.mem_append.mp hv' with first|second
    · exact (same_tag fz (fullPort first) eq).trans (within hm lm first)
    · exact (same_tag fz (fullPort second) eq).trans ((within hv lv second).trans same)
  exact (endLabel _ (by simp)).trans (endLabel _ (by simp)).symm

/-- A second independent exclusion of the 858-edge example. The bypass test
does not require knowing in advance that its full graph has 35 components. -/
theorem separated_by_bypass : ¬Feasible X Dense462.first Dense462.last := by
  obtain ⟨A,B,eq,many,bal,bypass⟩ := redundant_pair
  have size := Dense462.RankTight.passes.1
  rw [eq] at size ⊢
  exact no_twelve_bypassed (by omega) bal bypass (by omega)

#print axioms redundant_pair
#print axioms separated_by_bypass
end Dense462.RankTight.IncidenceMap

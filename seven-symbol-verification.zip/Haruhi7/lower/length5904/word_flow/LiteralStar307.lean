import FusedPacked93
import BaseLiteralStar

namespace ExactWordFlow.LiteralStar307
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence ResidualRoutes RotationCore
open LiteralWheelCover WeightedMarks ExtremeWheelCut NearRootMoves
open private catalog from NearRootMoves
open private widths from ExtremeWheelCut
open scoped Classical

/-- Every chosen row intersects the initial set of classes. -/
def Star (P : Row) : Prop := ∃W⊆allRows, W.card≤92 ∧ allClasses⊆P∪W.biUnion id ∧
  ∀R∈W,(R∩P).Nonempty

private theorem row_of_full {s : Block} (ok : full s) : WheelContacts.wheel s∈allRows := by
  obtain ⟨t,b,eq⟩:=WheelContacts.complete ok
  exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨t,b,eq⟩)

theorem from_inserts {b v : Block} {rs : List Row} (ins : Inserts b rs v) (count : rs.length=92)
    (done : (complete b).card=92) (boardV : (visited v).card=720) (len : v.length=1508) : Star (visited b) := by
  obtain ⟨_,data⟩:=WheelBaseResidual.direct_partition ins count done boardV len
  refine ⟨rs.toFinset,?_,(List.toFinset_card_le _).trans count.le,?_,?_⟩
  · intro R hr
    obtain ⟨u,_,clean,eq⟩:=mem_ready.mp (ins.rows_ready hr)
    exact eq ▸ row_of_full clean
  · have eq:=Finset.eq_of_subset_of_card_le (visited_subset v) (by rw [board,boardV])
    rw [←eq,ins.visited_eq]
  · intro R hr
    exact Finset.card_pos.mp (by rw [(data R hr).1]; decide)

private theorem image_star {P : Row} (hit : Star P) (f : Block→Block)
    (onto : allClasses.image f=allClasses) (images : ∀r∈allRows,r.image f∈allRows) :
    Star (P.image f) := by
  obtain ⟨W,legal,size,cover,anchored⟩:=hit
  refine ⟨W.image (Finset.image f),?_,Finset.card_image_le.trans size,?_,?_⟩
  · intro row hr
    obtain ⟨r,inside,eq⟩:=Finset.mem_image.mp hr
    rw [←eq]
    exact images r (legal inside)
  · intro c hc
    obtain ⟨d,hd,rfl⟩:=Finset.mem_image.mp (show c∈allClasses.image f by rw [onto];exact hc)
    rcases Finset.mem_union.mp (cover hd) with p|q
    · exact Finset.mem_union_left _ (Finset.mem_image_of_mem f p)
    obtain ⟨r,hr,inside⟩:=Finset.mem_biUnion.mp q
    exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr
      ⟨r.image f,Finset.mem_image_of_mem _ hr,Finset.mem_image_of_mem _ inside⟩)
  · intro row hr
    obtain ⟨r,inside,eq⟩:=Finset.mem_image.mp hr
    rw [←eq]
    obtain ⟨c,hc⟩:=anchored r inside
    exact ⟨f c,Finset.mem_inter.mpr ⟨Finset.mem_image_of_mem _ (Finset.mem_inter.mp hc).1,
      Finset.mem_image_of_mem _ (Finset.mem_inter.mp hc).2⟩⟩

private theorem images_wheels (f : Fin 7→Fin 7) (bij : Function.Bijective f) (zero : f 0=0) :
    ∀r∈allRows,r.image (List.map f)∈allRows := by
  intro r hr
  obtain ⟨s,old,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hr)
  have tab : ∀t∈WheelContacts.bases,full t:=by native_decide
  have clean:=tab s old
  rw [show (WheelContacts.wheel s).image (List.map f)=WheelContacts.wheel (s.map f) from
    WheelRelabel.image_wheel f bij.1 zero clean]
  exact row_of_full (WheelRelabel.full_image f bij.1 clean)

private theorem step (P : Row) (ops : List (Fin 8)) (p : Star P) (boardP : P⊆allClasses) :
    Star (applyMoves ops P) ∧ applyMoves ops P⊆allClasses ∧ (applyMoves ops P).card≤P.card := by
  induction ops generalizing P with
  | nil => exact ⟨p,boardP,le_rfl⟩
  | cons i ops ih =>
    have act:=catalog i
    have sub : P.image (move i)⊆allClasses :=act.1 ▸ Finset.image_mono _ boardP
    obtain ⟨ok,board',sz⟩:=ih _ (image_star p _ act.1 act.2) sub
    exact ⟨ok,board',sz.trans Finset.card_image_le⟩

/-- At budget 92 and initial size at most 260, every missing class must be
in a row with precisely one initial contact. This is true before any insertions. -/
theorem single {P : Row} (ok : Star P) (small : P.card≤260) (c : Block)
    (hc : c∈allClasses) (outside : c∉P) : ∃r∈allRows,c∈r ∧ (P∩r).card=1 := by
  classical
  obtain ⟨W,leg,cost,cover,anch⟩:=ok
  obtain ⟨r,hr,cr⟩:=Finset.mem_biUnion.mp ((Finset.mem_union.mp (cover hc)).resolve_left outside)
  let part (r : Row) := r \ P
  have lim (q) (hq : q∈W) : (part q).card≤5 := by
    have w:=widths q (leg hq)
    have hit:=Finset.card_pos.mpr (anch q hq)
    have split:=Finset.card_sdiff_add_card_inter q P
    change (q \ P).card≤5
    omega
  have cov : allClasses⊆P∪W.biUnion part :=by
    intro d hd
    rcases Finset.mem_union.mp (cover hd) with old|new
    · exact Finset.mem_union_left _ old
    by_cases isOld : d∈P
    · exact Finset.mem_union_left _ isOld
    obtain ⟨q,hq,dq⟩:=Finset.mem_biUnion.mp new
    exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨q,hq,Finset.mem_sdiff.mpr ⟨dq,isOld⟩⟩)
  have enough:=(Finset.card_le_card cov).trans (Finset.card_union_le ..)
  have costT:=Finset.card_biUnion_le (s:=W) (t:=part)
  have sum:=Finset.sum_erase_add (s:=W) (fun q=>(part q).card) hr
  have others : (∑q∈W.erase r,(part q).card)≤(W.erase r).card*5 :=
    Finset.sum_le_card_nsmul _ _ _ (fun q hq=>lim q (Finset.mem_of_mem_erase hq))
  have erased:=Finset.card_erase_of_mem hr
  have used:=Finset.card_pos.mpr (show W.Nonempty from ⟨_,hr⟩)
  have split:=Finset.card_sdiff_add_card_inter r P
  have w:=widths r (leg hr)
  have one:=Finset.card_pos.mpr (anch r hr)
  have all:=board
  have paid : (W.biUnion part).card≤(W.erase r).card*5+(r \ P).card :=by
    calc
      _ ≤ ∑q∈W,(part q).card :=costT
      _ = (∑q∈W.erase r,(part q).card)+(part r).card:=sum.symm
      _ ≤ _ :=Nat.add_le_add_right others _
  exact ⟨r,leg hr,cr,by rw [Finset.inter_comm];omega⟩

theorem profile : FusedAny.profileOK 306 260=true := by native_decide

theorem accepted {b v : Block} {rs : List Row} (ins : Inserts b rs v) (count : rs.length=92)
    (done : (complete b).card=92) (boardV : (visited v).card=720) (len : v.length=1508)
    (test : Row→Bool) (passes : FusedAny.check 306 test=true) :
    ∃P : Row, P⊆allClasses ∧ P.card≤260 ∧ test P=true ∧ Star P := by
  obtain ⟨s,t,es,r,edges,rootEq,size,wd⟩:=WheelBaseResidual.actual_footprint_widths ins count done boardV len
  have colors : 260≤classCount s es:=by change 260≤(touched (s::es.map dst)).card;rw [←rootEq,size]
  obtain ⟨f,bij,zero,k,norm⟩:=FusedAny.route_coverage (by decide) profile test passes r wd (by omega) colors
  let P:=visited b
  have ok:=from_inserts ins count done boardV len
  have onto:=WheelRelabel.image_allClasses f bij.1 zero
  have sub : P.image (List.map f) ⊆ allClasses:=onto ▸ Finset.image_mono _ (visited_subset b)
  obtain ⟨star,board',card⟩:=step _ (List.replicate k 7) (image_star ok _ onto (images_wheels f bij zero)) sub
  rw [←rootEq] at norm
  exact ⟨_,board',card.trans (Finset.card_image_le.trans size.le),norm,star⟩

end ExactWordFlow.LiteralStar307

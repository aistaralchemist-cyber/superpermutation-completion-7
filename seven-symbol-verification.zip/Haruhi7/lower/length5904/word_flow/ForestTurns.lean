import PairedTurns

namespace ExactWordFlow.ForestTurns
open SevenWordWindows ResidualDensity ResidualIncidence ResidualRoutes EmbeddedWheels
open scoped Classical

def covered (ws : List Block) := ws.toFinset.biUnion (fun w => (orbit w).toFinset)

inductive Attached : List Block → Prop where
  | one (w : Block) : Attached [w]
  | add {w : Block} {ws : List Block} : Attached ws →
      2≤((orbit w).toFinset ∩ covered ws).card → Attached (w::ws)

private theorem card_bound {ws : List Block} (tree : Attached ws)
    (legit : ∀w∈ws, full w) : (covered ws).card≤4*ws.length+2 ∧ 0 < ws.length := by
  induction tree with
  | one w =>
    have size := wheel_contacts_six w (legit w (by simp))
    simp [covered,size]
  | @add w ws tail overlap ih =>
    obtain ⟨prior,_⟩ := ih (fun v hv => legit v (List.mem_cons_of_mem _ hv))
    have size := wheel_contacts_six w (legit w (by simp))
    have extend : covered (w::ws)=(orbit w).toFinset ∪ covered ws := by simp [covered]
    have inc := Finset.card_union_add_card_inter (orbit w).toFinset (covered ws)
    rw [extend,List.length_cons]
    omega

private theorem prices (trees : List (List Block)) (all : ∀ws∈trees, Attached ws)
    (legit : ∀w∈trees.flatten, full w) :
    (∑u ∈ trees.toFinset.image covered, (u.card-1)) ≤
      4*trees.flatten.length+trees.length := by
  classical
  induction trees with
  | nil => simp
  | cons ws rest ih =>
    have head := card_bound (all ws (by simp)) (fun w hw => legit w (List.mem_flatten.mpr ⟨ws,by simp,hw⟩))
    have next := ih (fun z hz => all z (List.mem_cons_of_mem _ hz)) (fun w hw =>
      legit w (List.mem_append_right _ hw))
    simp only [List.toFinset_cons,Finset.image_insert,List.flatten_cons,List.length_append,List.length_cons]
    by_cases inRest : covered ws∈rest.toFinset.image covered
    · rw [Finset.insert_eq_of_mem inRest]; omega
    · rw [Finset.sum_insert inRest]; omega

/-- Removing all turns in any partition into lists whose successive turns
share two already present classes charges one rank loss per attachment. -/
theorem forest_bound {Y : Multiset Block} {s t : Block}
    (trees : List (List Block)) (all : ∀ws∈trees, Attached ws)
    (legit : ∀w∈trees.flatten, full w)
    (h : Feasible (Y+turns trees.flatten) s t)
    (budget : (Y+turns trees.flatten).card≤858) :
    trees.flatten.length+10*(trees.flatten.length-trees.length+(largeOther Y s).card)≤112 := by
  have p := prices trees all legit
  have con : ∀w∈trees.flatten, ∃u∈trees.toFinset.image covered, (orbit w).toFinset⊆u := by
    intro w hw
    obtain ⟨ws,hws,hit⟩ := List.mem_flatten.mp hw
    refine ⟨covered ws,Finset.mem_image_of_mem covered (List.mem_toFinset.mpr hws),?_⟩
    intro v hv
    exact Finset.mem_biUnion.mpr ⟨w,List.mem_toFinset.mpr hit,hv⟩
  have need := grouped_rank trees.flatten legit h _ con
  have merged := need.trans (Nat.add_le_add_right p _)
  have alone := residual_rank trees.flatten legit h
  change 719≤5*trees.flatten.length+separateRank Y s at alone
  exact (turns_with_loss _ legit h budget (trees.flatten.length-trees.length) (by omega)).2

end ExactWordFlow.ForestTurns
#print axioms ExactWordFlow.ForestTurns.forest_bound

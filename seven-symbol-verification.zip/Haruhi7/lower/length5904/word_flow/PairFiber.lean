import RunCompatibility
import Cap35Fibers
namespace ResidualDensity.ForcedRuns
open WheelContacts ExactWordFlow Cap35Rigidity Cap35Fibers

private theorem row_size (s : Six) (hs : full s) : (wheel s).card=6 := by
  obtain ⟨a,ha,eq⟩:=complete hs
  have one:=wheel_contacts ha ha
  simpa [gapCount,eq] using one

/-- A one-hole pair uses exactly twelve different tags inside a single
30-tag family determined solely by a five-symbol cyclic order. -/
theorem paired_fiber {u : Nat→Six} {p : Nat→Prop} (w : Walk u) (h : Marked u p)
    {i : Nat} (A:∀d<6,p (i+d)) (B:∀d<6,p ((i+7)+d)) :
    let C:=wheel (u i)∪wheel (u (i+7))
    C.card=12 ∧ C⊆fiber (u i) ∧ (fiber (u i)).card=30 := by
  have hi : full (u i):=h.1 _ (by simpa using A 0 (by decide))
  have hj : full (u (i+7)):=h.1 _ (by simpa using B 0 (by decide))
  have no:=(disjoint_rows w h (by omega : i < i+7) A B).2
  have card:=Finset.card_union_of_disjoint no
  rw [row_size _ hi,row_size _ hj] at card
  have hopEq:=paired_seam w h A B
  dsimp only
  refine ⟨card,?_,shape_eq_fiber _ hi ▸ (Cap35Rigidity.ten (u i) hi).1⟩
  rw [←shape_eq_fiber _ hi]
  apply Finset.union_subset
  · intro x hx
    apply Finset.mem_biUnion.mpr
    exact ⟨0,by decide,by simpa using hx⟩
  · intro x hx
    apply Finset.mem_biUnion.mpr
    exact ⟨1,by decide,by simpa [hopEq] using hx⟩
end ResidualDensity.ForcedRuns

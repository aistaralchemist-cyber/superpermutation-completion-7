import FiveExtensionCaps
import ExtendedSpineRank
import SpineExtensions
import PathWheelCover

namespace ExactWordFlow.ElevenExtensionCaps
open SevenWordWindows ResidualDensity ResidualControls FiveExtensionCaps

private def add (right : Bool) (a : Fin 7) (w : Block) : Block :=
  if right then w++[a] else a::w

private def vertex (right : Bool) (a : Fin 7) (w : Block) : Block :=
  if right then w.drop (w.length-5)++[a] else a::w.take 5

private theorem vertices_cons (a : Fin 7) (w : Block) (long : 6 ≤ w.length) :
    vertices (a::w) = (a::w).take 6 :: vertices w := by
  simp [vertices,windows,long,dst]

private theorem vertices_snoc (a : Fin 7) (w : Block) (long : 6 ≤ w.length) :
    vertices (w++[a]) = vertices w ++ [vertex true a w] := by
  induction w with
  | nil => simp at long
  | cons b xs ih =>
    by_cases ok : 6≤xs.length
    · have ok' : 6≤(xs++[a]).length := by simp; omega
      change vertices (b::(xs++[a])) = _
      rw [vertices_cons _ _ ok',vertices_cons _ _ ok,ih ok]
      simp [vertex,List.take_append_of_le_length (show 5≤xs.length by omega)]
      rw [show xs.length-4=(xs.length-5)+1 by omega]
      rfl
    · have m : xs.length=5 := by simp_all; omega
      have n : (xs++[a]).length=6 := by simp [m]
      have f : windows (xs++[a])=[] := List.eq_nil_of_length_eq_zero (by rw [windows_length,n])
      simp [vertices,windows,vertex,m,dst,f,n,
        List.take_append_of_le_length (show 5≤xs.length by omega)]

private def grow (A : Finset Block) (v : Block) : Finset Block :=
  if full v then insert (tag v) A else A

private theorem classes_add (right : Bool) (a : Fin 7) (w : Block) (long : 6≤w.length) :
    extension_classes (add right a w) = grow (extension_classes w) (vertex right a w) := by
  cases right
  · simp only [add,Bool.false_eq_true,ite_false,extension_classes,vertices_cons _ _ long,vertex,List.take_succ_cons]
    by_cases h : full (a::w.take 5) <;> simp [grow,h,touched]
  · simp only [add,ite_true,extension_classes,vertices_snoc _ _ long]
    by_cases h : full (vertex true a w) <;> simp [grow,h,touched,List.filter_append]

private def moves : List (Bool × Fin 7) → Block → Block
  | [],w => w
  | (side,a)::rest,w => moves rest (add side a w)

private theorem moves_append (p q : List (Bool × Fin 7)) (w : Block) :
    moves (p++q) w=moves q (moves p w) := by
  induction p generalizing w with
  | nil => rfl
  | cons h p ih => exact ih _

private theorem left_moves (p w : Block) :
    moves (p.map fun a => (false,a)) w=p.reverse++w := by
  induction p generalizing w with
  | nil => simp [moves]
  | cons x xs ih => simp [moves,ih,add,List.append_assoc]

private theorem right_moves (q w : Block) :
    moves (q.map fun a => (true,a)) w=w++q := by
  induction q generalizing w with
  | nil => simp [moves]
  | cons x xs ih => simp [moves,ih,add,List.append_assoc]

/-- Once even all remaining letters would miss the target, an entire branch is certified. -/
private def rejects (eligible : Block → Bool) : List Bool → Block → Finset Block → Int → Bool
  | [],w,_,need => !eligible w || decide (0<need)
  | side::rest,w,A,need =>
    if (rest.length : Int)+1<need then true
    else (List.finRange 7).all fun a =>
      let v := vertex side a w
      let gain := if full v ∧ tag v ∉ A then 1 else 0
      rejects eligible rest (add side a w) (grow A v) (need-gain)

private theorem grow_card (A : Finset Block) (v : Block) :
    (grow A v).card=A.card+(if full v ∧ tag v ∉ A then 1 else 0) := by
  by_cases hv : full v <;> by_cases ht : tag v∈A <;> simp [grow,hv,ht]

private theorem length_add (side : Bool) (a : Fin 7) (w : Block) :
    (add side a w).length=w.length+1 := by cases side <;> simp [add]

private theorem moves_cap (s : List (Bool × Fin 7)) (w : Block) (long : 6≤w.length) :
    (extension_classes (moves s w)).card≤(extension_classes w).card+s.length := by
  induction s generalizing w with
  | nil => simp [moves]
  | cons h s ih =>
    rcases h with ⟨side,a⟩
    have h' := ih (add side a w) (by rw [length_add]; omega)
    rw [classes_add _ _ _ long,grow_card] at h'
    change (extension_classes (moves s (add side a w))).card≤_
    simp only [List.length_cons]
    split at h' <;> omega

private theorem sound (eligible : Block → Bool) (s : List (Bool × Fin 7)) (w : Block) (long : 6≤w.length) (need : Int)
    (ok : eligible (moves s w)=true)
    (h : rejects eligible (s.map Prod.fst) w (extension_classes w) need=true) :
    ((extension_classes (moves s w)).card : Int) < (extension_classes w).card+need := by
  induction s generalizing w need with
  | nil => simpa [moves,rejects,show eligible w=true from ok] using h
  | cons h0 s ih =>
    rcases h0 with ⟨side,a⟩
    rw [List.map_cons,rejects] at h
    split at h
    · have ub := moves_cap ((side,a)::s) w long
      simp_all
      omega
    · have step := List.all_eq_true.mp h a (List.mem_finRange _)
      simp only at step
      rw [←classes_add _ _ _ long] at step
      have nxt := ih (add side a w) (by rw [length_add]; omega) _ ok step
      rw [classes_add _ _ _ long,grow_card] at nxt
      change ((extension_classes (moves s (add side a w))).card : Int)<_
      by_cases hv : full (vertex side a w) ∧ tag (vertex side a w) ∉ extension_classes w <;> simp [hv] at nxt <;> omega

private theorem of_check (eligible : Block → Bool) {p q w : Block} (long : 6≤w.length) (need : Int)
    (ok : eligible (p++w++q)=true)
    (h : rejects eligible (List.replicate p.length false ++ List.replicate q.length true)
      w (extension_classes w) need=true) :
    ((extension_classes (p++w++q)).card : Int) < (extension_classes w).card+need := by
  let s := (p.reverse.map fun a => (false,a))++(q.map fun a => (true,a))
  have flags : s.map Prod.fst = List.replicate p.length false ++ List.replicate q.length true := by
    simp [s,List.map_map,Function.comp_def]
  have eq : moves s w = p++w++q := by rw [show moves s w = _ from moves_append _ _ _,left_moves,right_moves,List.reverse_reverse]
  have r := sound eligible s w long need (eq ▸ ok) (flags ▸ h)
  rw [eq] at r
  exact r

/-- A certificate on left/right extension lengths. The predicate may select
only terminal words of interest, for example literal returns to the start. -/
def extensionCheck (w : Block) (left right : Nat) (need : Int)
    (eligible : Block → Bool) : Bool :=
  rejects eligible (List.replicate left false ++ List.replicate right true) w (extension_classes w) need

theorem extension_check_bound {w p q : Block} (long : 6≤w.length) (need : Int)
    (eligible : Block → Bool) (ok : eligible (p++w++q)=true)
    (check : extensionCheck w p.length q.length need eligible=true) :
    ((extension_classes (p++w++q)).card : Int)<(extension_classes w).card+need :=
  of_check eligible long need ok check

private def splitCheck (n : Nat) (need : Int := 10) := (List.range (n+1)).all fun l =>
  rejects (fun _ => true) (List.replicate l false ++ List.replicate (n-l) true) mainWord (extension_classes mainWord) need

private theorem boards : splitCheck 10=true ∧ splitCheck 11=true := by native_decide

/-- Every literal allocation of 10 or 11 letters at the two W-0021 ends gains at most nine classes. -/
theorem reference_cap (p q : Block) (n : p.length+q.length=10 ∨ p.length+q.length=11) :
    (extension_classes (p++mainWord++q)).card ≤399 := by
  let k := p.length+q.length
  have h : splitCheck k=true := by
    dsimp [k]
    rcases n with e|e
    · rw [e]; exact boards.1
    · rw [e]; exact boards.2
  have sub := List.all_eq_true.mp h p.length (List.mem_range.mpr (by dsimp [k]; omega))
  have size : k-p.length=q.length := by dsimp [k]; omega
  simp only [size] at sub
  have cap := of_check (fun _ => true) (p:=p) (q:=q) (w:=mainWord) (by native_decide) 10 rfl sub
  have old : (extension_classes mainWord).card=390 := by native_decide
  omega

private theorem ten_board : splitCheck 10 9=true := by native_decide

/-- The exact ceiling for ten letters is 398. -/
theorem reference_ten_cap (p q : Block) (n : p.length+q.length=10) :
    (extension_classes (p++mainWord++q)).card≤398 := by
  have sub := List.all_eq_true.mp ten_board p.length (List.mem_range.mpr (by omega))
  have size : 10-p.length=q.length := by omega
  simp only [size] at sub
  have cap := of_check (fun _ => true) (p:=p) (q:=q) (w:=mainWord) (by native_decide) 9 rfl sub
  have old : (extension_classes mainWord).card=390 := by native_decide
  omega

theorem attained_ten :
    (extension_classes ([6,5,0,1,2,3,6,4]++mainWord++[5,4])).card=398 := by native_decide

#print axioms reference_ten_cap
#print axioms attained_ten

private def closes (w : Block) : Bool := decide (w.drop (w.length-6)=mainWord.take 6)

private def closingCheck (n : Nat) := rejects closes (List.replicate n true)
  mainWord (extension_classes mainWord) ((n : Int)-1)

private theorem closing_board : (List.range 12).all closingCheck=true := by native_decide

/-- A return to the opening six-state loses two units, regardless of the return word. -/
theorem reference_closure (p : Block) (short : p.length≤11)
    (cl : (mainWord++p).drop ((mainWord++p).length-6)=mainWord.take 6) :
    (extension_classes (mainWord++p)).card+2 ≤ 390+p.length := by
  have ch := List.all_eq_true.mp closing_board p.length (List.mem_range.mpr (by omega))
  have cap := of_check closes (p:=[]) (q:=p) (w:=mainWord) (by native_decide)
    ((p.length : Int)-1) (by simpa [closes] using cl) (by simpa [closingCheck] using ch)
  simp only [List.nil_append] at cap
  have old : (extension_classes mainWord).card=390 := by native_decide
  omega

theorem attained :
    (extension_classes ([6,3,4,0,1,2,3,6,4]++mainWord++[5,4])).card=399 := by native_decide

open DirectedEuler OnePath66

private theorem same_end {s t t' : Block} {es : List Block}
    (r : Route src dst s es t) (r' : Route src dst s es t') : t=t' := by
  have h := add_left_cancel (r.balance.trans r'.balance.symm)
  simpa using h

/-- The numerical ceiling applies directly to a directed return subtrail. -/
theorem route_return_cap {p : List Block}
    (rp : Route src dst (mainWord.drop (mainWord.length-6)) p (mainWord.take 6))
    (widths : ∀e∈p,e.length=7) (short : p.length≤11) :
    (pathClasses (mainWord.take 6) (windows mainWord++p)).card+2 ≤390+p.length := by
  have long : 6 ≤ mainWord.length := by native_decide
  obtain ⟨pre,q,hpre,hq,eq,head⟩ := spell_extensions mainWord long (.nil _) rp (by simp) widths
  have no : pre=[] := List.eq_nil_of_length_eq_zero hpre
  subst pre
  simp only [List.nil_append] at eq head
  have r := read_route (mainWord++q) (by simp; omega)
  rw [eq,head] at r
  have endEq := same_end r (join_routes (read_route mainWord long) rp)
  have cap := reference_closure q (by omega) endEq
  change (pathClasses ((mainWord++q).take 6) (windows (mainWord++q))).card+2≤_ at cap
  simpa only [head,eq,hq] using cap

/-- The bound is independent of the source and target of the directed end extensions. -/
theorem route_extension_cap {p q : List Block} {s t : Block}
    (rp : Route src dst s p (mainWord.take 6))
    (rq : Route src dst (mainWord.drop (mainWord.length-6)) q t)
    (wp : ∀e∈p,e.length=7) (wq : ∀e∈q,e.length=7)
    (n : p.length+q.length=10 ∨ p.length+q.length=11) :
    (pathClasses s (p++windows mainWord++q)).card≤399 := by
  obtain ⟨u,v,hu,hv,eq,head⟩ := spell_extensions mainWord (by native_decide) rp rq wp wq
  have cap := reference_cap u v (by rwa [hu,hv])
  change (pathClasses ((u++mainWord++v).take 6) (windows (u++mainWord++v))).card≤399 at cap
  simpa only [head,eq] using cap

#print axioms route_return_cap
#print axioms route_extension_cap

#print axioms reference_cap
#print axioms reference_closure
#print axioms attained
end ExactWordFlow.ElevenExtensionCaps

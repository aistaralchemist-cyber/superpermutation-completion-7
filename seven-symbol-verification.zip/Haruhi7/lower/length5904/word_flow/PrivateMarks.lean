import AnonymousSeven

namespace ExactWordFlow.PrivateMarks
open Equiv SevenMoves AnonymousSeven

variable {α β : Type*} [DecidableEq β]
def shared (S : Finset α) (label : α→β) :=
  S.filter (fun x=>1<(S.filter (fun y=>label y=label x)).card)

theorem shared_bound (S : Finset α) (label : α→β) :
    (shared S label).card+2*(S.image label).card≤2*S.card := by
  classical
  let tags:=S.image label
  let T (b : β):=S.filter (fun x=>label x=b)
  let B:=shared S label
  let U (b : β):=B.filter (fun x=>label x=b)
  have one (b) (hb:b∈tags): 1≤(T b).card:=by
    obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hb
    exact Finset.card_pos.mpr ⟨x,Finset.mem_filter.mpr ⟨hx,rfl⟩⟩
  have each (b) (hb:b∈tags) : (U b).card+2≤2*(T b).card:=by
    have sub : U b⊆T b:=Finset.filter_subset_filter _ (Finset.filter_subset ..)
    have bd:=Finset.card_le_card sub
    have pos:=one _ hb
    by_cases big : 1<(T b).card
    · omega
    · have empty : U b=∅:=Finset.eq_empty_iff_forall_notMem.mpr (by
        intro x hx
        obtain ⟨sh,atB⟩:=Finset.mem_filter.mp hx
        obtain ⟨_,many⟩:=Finset.mem_filter.mp sh
        rw [atB] at many
        exact big many)
      rw [empty,Finset.card_empty]; omega
  have cover (A : Finset α) (sub:A⊆S) :
      (∑i∈tags,(A.filter (fun x=>label x=i)).card)=A.card := by
    exact (Finset.card_eq_sum_card_fiberwise (f:=label) (t:=tags)
      (fun x (hx:x∈A)=>Finset.mem_image_of_mem label (sub hx))).symm
  have tot:=Finset.sum_le_sum each
  rw [Finset.sum_add_distrib,←Finset.mul_sum] at tot
  change (∑b∈tags,(B.filter (fun x=>label x=b)).card)+_≤2*(∑b∈tags,(S.filter (fun x=>label x=b)).card) at tot
  rw [cover B (Finset.filter_subset ..),cover S (Finset.Subset.refl _)] at tot
  simpa [tags,mul_comm] using tot

theorem all_cycles (h : Perm X) (start : X) (tour : ∀y,(R*h).SameCycle start y)
    (present : (exceptions h).Nonempty) {g : Nat}
    (genus : h.support.card=h.cycleType.card+719+2*g) :
    let E:=exceptions h
    let S:=E.biUnion Perm.support
    ∃f : Y→Y,
      (∀c∈h.cycleFactorsFinset \ E,∀x∈c.support,∀y∈c.support,f (tag x)=f (tag y)) ∧
      (shared S (f ∘ tag)).card≤2*(E.card-1+2*g) := by
  classical
  let E:=exceptions h
  let S:=E.biUnion Perm.support
  let H:=h.cycleFactorsFinset
  let A:=S.image tag
  let W:=(H\E).image (fun c=>c.support.image tag)
  have known : E⊆H:=Finset.filter_subset ..
  have closed : SeedWheelCut.ClosedCover A Finset.univ W := by
    simpa only [A,S,Finset.biUnion_image] using TourWheelPrice.from_order start tour tag tag_surj tag_rot E known present
  have width (w) (hw:w∈W) : w.card≤6:=by
    obtain ⟨c,hc,rfl⟩:=Finset.mem_image.mp hw
    exact Finset.card_image_le.trans (ordinary_six hc).le
  obtain ⟨f,ct,mono⟩:=WheelContraction.colors Finset.univ W width
  have met:=WheelContraction.all_met (Finset.subset_univ A) closed f mono
  rw [Finset.card_univ,sizeY,met] at ct
  have size : (A.image f).card=(S.image (f ∘ tag)).card := by rw [←Finset.image_image]
  rw [size] at ct
  have wc : W.card≤(H\E).card:=Finset.card_image_le
  have tally : (∑c∈H\E,c.support.card)+(∑c∈E,c.support.card)=h.support.card :=
    (Finset.sum_sdiff known).trans h.sum_cycleType
  rw [Finset.sum_congr rfl (fun c hc=>ordinary_six (h:=h) hc)] at tally
  simp only [Finset.sum_const,smul_eq_mul] at tally
  change (H\E).card*6+(∑c∈E,c.support.card)=h.support.card at tally
  have count : (H\E).card+E.card=H.card:=Finset.card_sdiff_add_card_eq_card known
  have factors : H.card=h.cycleType.card := by simp [H,Perm.cycleType_def]
  have sBound : S.card≤∑c∈E,c.support.card := Finset.card_biUnion_le
  have paid:=shared_bound S (f ∘ tag)
  have pos : 0<E.card:=Finset.card_pos.mpr present
  refine ⟨f,?_,?_⟩
  · intro c hc x hx y hy
    exact mono _ (Finset.mem_image_of_mem _ hc) _ (Finset.mem_image_of_mem _ hx) _
      (Finset.mem_image_of_mem _ hy)
  · change (shared S (f ∘ tag)).card≤2*(E.card-1+2*g)
    omega

#print axioms all_cycles
end ExactWordFlow.PrivateMarks

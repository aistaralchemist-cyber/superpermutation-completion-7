import FixedSeed235Data
import WheelLRAT
import OrientedCNF
namespace ExactWordFlow.FixedSeed235Exact
open WheelLRAT SevenWordWindows SeedWheelCut ExtremeWheelCut OrientedCNF
private def formulas := [cnf rootClasses]
private def checks := wheelCertificates% formulas

theorem impossible : (cnf rootClasses).Unsat :=
  WheelLRAT.batch_sound (fs:=formulas) (cs:=checks) (by native_decide)
    (cnf rootClasses) (by simp [formulas])

theorem no_cover {W : Finset (Finset Block)} (legal : W⊆allRows) (size : W.card≤97) :
    ¬ ClosedCover rootClasses allClasses W := by
  have n := profile.2.2.1
  have total : allClasses.card=720 := by native_decide
  exact OrientedCNF.no_cover legal (by omega) impossible

#print axioms impossible
#print axioms no_cover
end ExactWordFlow.FixedSeed235Exact

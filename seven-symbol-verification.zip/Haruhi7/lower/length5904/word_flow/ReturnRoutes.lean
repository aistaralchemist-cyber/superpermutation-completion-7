import ReturnFootprints

namespace ExactWordFlow.ReturnFootprints
open SevenWordWindows RotationCore RotationReinsert LapSkeleton DirectedEuler ResidualDensity ExcursionCore
open private split_at end_eq join from LapSkeleton

private theorem first_seven {w p : Block} {ps : List Block} (word : windows w=p::ps) : w.take 7=p := by
  cases w with
  | nil => simp [windows] at word
  | cons x xs =>
    unfold windows at word
    split at word
    · exact (List.cons.inj word).1
    · contradiction

private theorem anchored {s : Block} {p : Block} {es : List Block}
    (rp : Route src dst s (p::es) s) (rep : p∈representatives)
    (wd : ∀e∈p::es,e.length=7) (lo : 7≤(p::es).length) (hi : (p::es).length≤10) :
    (labels (p::es)).card≤2 := by
  have len:=((mem_reps p).mp rep).1
  have first : src p=s := by cases rp with | cons _ eq _ => exact eq
  have six : s.length=6 := by rw [←first]; simp [src,len]
  obtain ⟨w,sz,sh,we⟩:=spell_route rp six wd
  have l : 13≤w.length:=by omega
  have head:=first_seven we
  have back:=read_route w (by omega)
  rw [sh,we] at back
  have endp : w.drop (w.length-6)=s:=end_eq back rp
  let a:=(w.drop 7).take (w.length-13)
  have al : a.length≤3 := by
    have lb : a.length≤w.length-13:=by simp [a]
    omega
  have mid : (w.drop 7).drop (w.length-13)=s := by
    rw [List.drop_drop,show 7+(w.length-13)=w.length-6 by omega]
    exact endp
  have eq : p++a++p.take 6=w := by
    rw [←show s=p.take 6 from first.symm]
    rw [←mid,List.append_assoc]
    change p++((w.drop 7).take (w.length-13)++(w.drop 7).drop (w.length-13))=w
    rw [List.take_append_drop,←head,List.take_append_drop]
  rw [←we,←eq]
  exact word_cap rep al

/-- Every closed subwalk with seven through ten steps has at most two distinct
rotation classes among its actual length-seven permutation windows. There is no
hypothesis on its start letters or on where the first permutation is read. -/
theorem short_return {s : Block} {es : List Block} (path : Route src dst s es s)
    (wd : ∀e∈es,e.length=7) (lo : 7≤es.length) (hi : es.length≤10) :
    (labels es).card≤2 := by
  by_cases good : ∃p∈es,p.Nodup
  · obtain ⟨p,mem,nd⟩:=good
    have rep: p∈representatives := (mem_reps _).mpr ⟨wd p mem,nd⟩
    obtain ⟨a,b,split⟩:=List.mem_iff_append.mp mem
    subst es
    obtain ⟨u,left,right⟩:=split_at a (p::b) path
    have turn: Route src dst u (p::(b++a)) u := by
      cases right with | cons _ eq rem => exact .cons p eq (join rem left)
    have same (q : Block) : q∈p::(b++a) ↔ q∈a++(p::b) := by
      simp only [List.mem_cons,List.mem_append]
      tauto
    have num : (p::(b++a)).length=(a++(p::b)).length := by simp; omega
    have cap:=anchored turn rep (fun e h=>wd e ((same _).mp h)) (num ▸ lo) (num ▸ hi)
    have eq : labels (p::(b++a))=labels (a++(p::b)) := by
      ext c
      simp only [labels,List.mem_toFinset,List.mem_map,List.mem_filter]
      simp only [same]
    rwa [eq] at cap
  · have empty : labels es=∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro c h
      obtain ⟨p,hs,_⟩:=List.mem_map.mp (List.mem_toFinset.mp h)
      obtain ⟨hp,unique⟩:= List.mem_filter.mp hs
      exact good ⟨p,hp,of_decide_eq_true unique⟩
    simp [empty]

#print axioms short_return
end ExactWordFlow.ReturnFootprints

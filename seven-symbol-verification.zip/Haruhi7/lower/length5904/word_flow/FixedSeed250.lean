import FixedSeed390
import WheelLRAT
import OrientedCNF
namespace ExactWordFlow.FixedSeed250
open WheelLRAT SevenWordWindows SeedWheelCut ExtremeWheelCut ForcedRootClosure OrientedCNF
open private digits from ExtremeWheelCut
open private cost from PlanarScoreExample

private def rows : List (Nat × String) := [
  (5, "0123456"),
  (5, "0234516"),
  (5, "0345126"),
  (3, "0451236"),
  (5, "0645132"),
  (5, "0451362"),
  (3, "0513642"),
  (5, "0251346"),
  (5, "0513426"),
  (5, "0134256"),
  (3, "0342516"),
  (5, "0634215"),
  (5, "0342165"),
  (3, "0421635"),
  (5, "0542136"),
  (5, "0421356"),
  (5, "0213546"),
  (3, "0135426"),
  (5, "0613524"),
  (5, "0135264"),
  (3, "0352614"),
  (5, "0435216"),
  (5, "0352146"),
  (5, "0521436"),
  (3, "0214356"),
  (5, "0621453"),
  (5, "0214563"),
  (3, "0145623"),
  (5, "0314526"),
  (5, "0145236"),
  (5, "0452316"),
  (3, "0523146"),
  (3, "0652341"),
  (5, "0165243"),
  (5, "0652413"),
  (5, "0524163"),
  (3, "0241653"),
  (5, "0324156"),
  (5, "0241536"),
  (5, "0415326"),
  (3, "0153246"),
  (5, "0615342"),
  (5, "0153462"),
  (3, "0534612"),
  (5, "0253416"),
  (5, "0534126")]
def walk : List Block := rows.flatMap fun (r,s) =>
  (List.range (r+1)).map fun j => (digits s).take 1 ++ (digits s).tail.rotate j
def rootClasses := (walk.map classKey).toFinset
private def paid := (walk.zip walk.tail).map fun (x,y) => cost x y

theorem profile : (∀ p∈walk,p.length=7 ∧ p.Nodup) ∧ walk.length=250 ∧
    rootClasses.card=250 ∧ paid.length=249 ∧ paid.count 2=204 ∧ paid.count 3=45 ∧
    cost (walk.getLastD []) (walk.headD [])=5 ∧
    (paid.map fun d=>d-2).sum=45 ∧
    walk.length-6-5*(paid.map fun d=>d-2).sum=19 := by native_decide

theorem fixed : force rootClasses=rootClasses := by native_decide
private def formulas := [cnf rootClasses]
private def checks := wheelCertificates% formulas

theorem impossible : (cnf rootClasses).Unsat :=
  WheelLRAT.batch_sound (fs:=formulas) (cs:=checks) (by native_decide)
    (cnf rootClasses) (by simp [formulas])

theorem no_cover {W : Finset (Finset Block)} (legal : W⊆allRows) (size : W.card≤94) :
    ¬ ClosedCover rootClasses allClasses W := by
  have n := profile.2.2.1
  have total : allClasses.card=720 := by native_decide
  exact OrientedCNF.no_cover legal (by omega) impossible

#print axioms profile
#print axioms fixed
#print axioms impossible
#print axioms no_cover
end ExactWordFlow.FixedSeed250

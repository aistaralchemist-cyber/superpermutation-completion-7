import OnePath66
import SeedWheelCut

namespace ExactWordFlow.OnePath66
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels

def pathClasses (a : Block) (es : List Block) := touched (a::es.map dst)
def wheelSets (ws : List Block) := ws.toFinset.image (fun w => (orbit w).toFinset)

private theorem board :
    (∀e∈representatives, full (src e) ∧ full (dst e) ∧ tag (src e)=classKey e ∧
      tag (src e)=tag (dst e)) ∧
    ∀w∈states, ∀e∈GlobalWheelRank.wheel w, full (src e) ∧ full (dst e) ∧
      tag (src e)∈orbit w ∧ tag (dst e)∈orbit w := by native_decide

/-- True for any number of legal wheel turns and for arbitrary global
endpoints. All dirty path states can be given one already visited class. -/
theorem path_wheel_cover {a b s t : Block} {es ws : List Block} (r : Route src dst a es b)
    (legit : ∀w∈ws, full w) (h : Feasible ((↑es : Multiset Block)+turns ws) s t)
    (nonempty : (pathClasses a es).Nonempty) :
    SeedWheelCut.ClosedCover (pathClasses a es) allClasses (wheelSets ws) := by
  classical
  obtain ⟨d,hd⟩ := nonempty
  let φ (v : Block) := if full v then tag v else d
  have clean (v : Block) (fl : full v) : φ v=tag v := by simp [φ,fl]
  have dstVisit (e : Block) (he : e∈es) : dst e∈a::es.map dst :=
    List.mem_cons_of_mem _ (List.mem_map.mpr ⟨e,he,rfl⟩)
  have srcVisit := (r.closed {v | v∈a::es.map dst} List.mem_cons_self
    (fun e he _ => dstVisit e he)).2
  have onPath (v : Block) (seen : v∈a::es.map dst) : φ v∈pathClasses a es := by
    by_cases fl : full v
    · rw [clean v fl]
      exact List.mem_toFinset.mpr (List.mem_map.mpr
        ⟨v,List.mem_filter.mpr ⟨seen,decide_eq_true fl⟩,rfl⟩)
    · simpa [φ,fl] using hd
  apply SeedWheelCut.of_feasible φ _ _ _ h
  · intro c hc
    obtain ⟨e,he,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hc)
    have dat := board.1 e he
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨e,he,(clean _ dat.1).trans dat.2.2.1⟩)
  · obtain ⟨v,hv,eq⟩ := List.mem_map.mp (List.mem_toFinset.mp hd)
    have fl := of_decide_eq_true (List.mem_filter.mp hv).2
    obtain ⟨e,he,srcV⟩ := List.mem_map.mp (mem_states fl)
    refine ⟨e,he,?_⟩
    change src e=v at srcV
    rw [srcV,clean _ fl,eq]
    exact hd
  · intro e he
    have dat := board.1 e he
    exact (clean _ dat.1).trans (dat.2.2.2.trans (clean _ dat.2.1).symm)
  · intro e he
    rcases Multiset.mem_add.mp he with path|wh
    · exact Or.inr (Or.inl ⟨onPath _ (srcVisit e path),onPath _ (dstVisit e path)⟩)
    · obtain ⟨w,hw,we⟩ := List.mem_flatMap.mp (show e∈ws.flatMap GlobalWheelRank.wheel from wh)
      have dat := board.2 w (mem_states (legit w hw)) e we
      exact Or.inr (Or.inr ⟨_,Finset.mem_image_of_mem _ (List.mem_toFinset.mpr hw),
        (clean _ dat.1) ▸ List.mem_toFinset.mpr dat.2.2.1,
        (clean _ dat.2.1) ▸ List.mem_toFinset.mpr dat.2.2.2⟩)

/-- The five-value range supplies the anchor automatically at 462+66. -/
theorem cover_462_66 {a b s t : Block} {es ws : List Block}
    (r : Route src dst a es b) (n : es.length=462) (k : ws.length=66)
    (legit : ∀w∈ws, full w) (h : Feasible ((↑es : Multiset Block)+turns ws) s t) :
    SeedWheelCut.ClosedCover (pathClasses a es) allClasses (wheelSets ws) := by
  apply path_wheel_cover r legit h
  apply Finset.card_pos.mp
  have lo := (contact_range r n k legit h).1
  change 0<classCount a es
  omega

#print axioms cover_462_66
end ExactWordFlow.OnePath66

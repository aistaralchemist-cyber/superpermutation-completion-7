import AnonymousSeven
import OwnerOrbit
import SevenBlockerData

namespace ExactWordFlow.BlockerFloors
open Equiv AnonymousSeven AnonymousRows SevenMoves SevenBlockerData

private theorem hit_states {U : Finset Y} (hit : ∀p:X,∃x∈owner p,tag x∈U)
    (i : Finset X) (ne : (states owner i).Nonempty) :
    ∃x∈states owner i,tag x∈U := by
  obtain ⟨p,hp⟩:=ne
  obtain ⟨x,hx,tagged⟩:=hit p
  exact ⟨x,Finset.mem_filter.mpr ⟨Finset.mem_univ _,(owner_mem p x hx).trans (Finset.mem_filter.mp hp).2⟩,tagged⟩

theorem floor49 (h : Perm X) (start last : X) (tour : ∀y,(R*h).SameCycle start y)
    (required : ∀w∈ws 49,Required h w) : 5905≤length h last := by
  by_contra! bad
  have b:=blocker h start last tour (ws 49) root (guards 49) required join49
    (hit_states hits49) (by omega)
  rw [guard49] at b
  omega

theorem floor59 (h : Perm X) (start last : X) (tour : ∀y,(R*h).SameCycle start y)
    (required : ∀w∈ws 59,Required h w) : 5908≤length h last := by
  by_contra! bad
  have b:=blocker h start last tour (ws 59) root (guards 59) required join59
    (hit_states hits59) (by omega)
  rw [guard59] at b
  omega

#print axioms floor49
#print axioms floor59
end ExactWordFlow.BlockerFloors

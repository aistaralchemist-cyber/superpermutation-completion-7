import CandidateBanks

namespace ExactWordFlow.CoreCandidateBanks
open SevenWordWindows RotationCore SortedCoreRecords CoreRecordBits

abbrev Bits := Array Bool

def pk (r : Bits) := r.toList.take 19
def pm (r : Bits) : Finset (Fin 7) :=
  Finset.univ.filter fun a => (r.toList[19+a.val]?).getD false

def physicalFinish (r : Bits) (m : Finset (Fin 7)) : Bool × Bool :=
  let stop := !(r.toList.head?.getD true)
  (stop,stop && decide (m=Finset.univ))

/-- Physical end-of-run flags from 19 key bits and the seven mask bits.
The first row has no previous mask and the final row closes a group. -/
def physicalRun (r : Bits) (m : Finset (Fin 7)) : List Bits → List (Bool × Bool)
  | [] => [physicalFinish r m]
  | s::rs =>
    let eq := pk r == pk s
    (if eq then (false,false) else physicalFinish r m) ::
      physicalRun s (pm s ∪ if eq then m else ∅) rs

def physicalFlags : List Bits → List (Bool × Bool)
  | [] => []
  | r::rs => physicalRun r (pm r) rs

private theorem mask_pack {w : Block} {r : Row} (mem : r∈sourceRows w) :
    pm (rowWires r) = r.mask := by
  ext a
  have width := source_width mem
  unfold pm
  rw [Finset.mem_filter]
  simp only [Finset.mem_univ,true_and]
  change ((encodeKey r.key ++ (List.finRange 7).map (fun b => decide (b∈r.mask)))[19+a.val]?).getD false = true ↔ a∈r.mask
  rw [List.getElem?_append_right (by omega),show (19+a.val-(encodeKey r.key).length) = a.val by omega]
  simp

private theorem valid_pack (r : Row) :
    (!(rowWires r).toList.head?.getD true)=(classOf r.key).isSome := by
  obtain ⟨k,m⟩:=r
  cases k <;> rfl

private theorem key_beq {w : Block} {r s : Row} (mr : r∈sourceRows w) (ms : s∈sourceRows w) :
    (pk (rowWires r) == pk (rowWires s)) = decide (r.key = s.key) := by
  simp only [pk,first19 mr,first19 ms]
  by_cases h:r.key=s.key
  · simp [h]
  · have diff : encodeKey r.key ≠ encodeKey s.key := by
      intro eq
      have embed (a b : Row) (ha : a∈sourceRows w) (hb : b∈sourceRows w)
          (le : encodeKey a.key ≤ encodeKey b.key) : a.key ≤ b.key :=
        (wireLE_keys (source_encodable ha) (source_encodable hb)).mp ((wireLE_iff ..).mpr le)
      exact h (le_antisymm (embed r s mr ms eq.le) (embed s r ms mr eq.symm.le))
    simp [h,diff]

private theorem physical_run_correct {w : Block} (r : Row) (m) (rs : List Row)
    (mr : r∈sourceRows w) (ms : ∀x∈rs,x∈sourceRows w) :
    physicalRun (rowWires r) m (rs.map rowWires)=runFlags ⟨r.key,m⟩ rs := by
  induction rs generalizing r m with
  | nil => simp only [List.map_nil,physicalRun,runFlags,physicalFinish,finish,valid_pack]
  | cons s rs ih =>
    have hs := ms s List.mem_cons_self
    have rest := fun x hx => ms x (List.mem_cons_of_mem _ hx)
    simp only [List.map_cons,physicalRun,runFlags,key_beq mr hs,mask_pack hs]
    by_cases h:r.key=s.key
    · simp [h,ih s _ hs rest]
    · simp only [h,decide_false,Bool.false_eq_true,ite_false,Finset.union_empty,ih s _ hs rest,physicalFinish,valid_pack,finish]

theorem flags_pack {w : Block} {rs : List Row} (mem : ∀r∈rs,r∈sourceRows w) :
    physicalFlags (rs.map rowWires) = flags rs := by
  cases rs with
  | nil => rfl
  | cons r rs =>
    have hr:=mem r List.mem_cons_self
    simp only [List.map_cons,physicalFlags,flags,mask_pack hr]
    exact physical_run_correct r r.mask rs hr (fun x hx=>mem x (List.mem_cons_of_mem _ hx))

def adjChecks : List Bits → List Bool
  | [] | [_] => []
  | a::b::rs => wireLE (pk a) (pk b)::adjChecks (b::rs)

private theorem adj_eq {rs : List Bits} (ord : rs.Pairwise (fun a b=>wireLE (pk a) (pk b)=true)) :
    adjChecks rs=List.replicate (rs.length-1) true := by
  induction rs with
  | nil => rfl
  | cons a rs ih =>
    cases rs with
    | nil => rfl
    | cons b rs =>
      obtain ⟨head,tail⟩:=List.pairwise_cons.mp ord
      simp only [adjChecks,head b List.mem_cons_self,ih tail,List.length_cons,Nat.add_one_sub_one,
        List.replicate_succ]

end ExactWordFlow.CoreCandidateBanks

import Cap93Catalog

namespace ExactWordFlow.Cap93Catalog
set_option maxHeartbeats 0 in
theorem rows_ok : checkedRows=true := by native_decide
#print axioms rows_ok
end ExactWordFlow.Cap93Catalog

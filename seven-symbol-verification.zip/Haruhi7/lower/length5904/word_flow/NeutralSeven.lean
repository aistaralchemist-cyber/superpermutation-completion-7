import RunCollision
import CanonicalGenusCap

namespace ExactWordFlow.RunCollision
open SevenWordWindows

abbrev legalStates := {p // p∈representatives.toFinset}
def fibre (p : Block) := (Finset.range 6).image (atPhase p)

private theorem orbitCheck : ∀p∈representatives,p∈fibre p ∧ fibre (atPhase p 1)=fibre p := by
  native_decide

/-- This uses the actual seven-letter geometry, so the abstract
neutral-fibre cap is six for every literal correction order. -/
theorem six_capacity (y : Finset Block) :
    (Finset.univ.filter (fun p : legalStates=>fibre p.val=y)).card ≤ 6 := by
  classical
  let S := Finset.univ.filter fun p : legalStates=>fibre p.val=y
  by_cases active : S.Nonempty
  · obtain ⟨p,hp⟩:=active
    have eq : fibre p.val=y := (Finset.mem_filter.mp hp).2
    have bound : S.image Subtype.val ⊆ y := by
      intro z hz
      obtain ⟨q,hq,rfl⟩:=Finset.mem_image.mp hz
      exact (Finset.mem_filter.mp hq).2 ▸ (orbitCheck q.val (List.mem_toFinset.mp q.2)).1
    have inj : (S.image Subtype.val).card=S.card :=
      Finset.card_image_of_injective S Subtype.val_injective
    have size : (fibre p.val).card≤(Finset.range 6).card := Finset.card_image_le
    change S.card≤6
    rw [←inj]
    exact (Finset.card_le_card bound).trans (by simpa [←eq] using size)
  · have empty := Finset.not_nonempty_iff_eq_empty.mp active
    change S.card≤6
    simp [empty]

theorem neutral_key {p : legalStates} : fibre (atPhase p.val 1)=fibre p.val :=
  (orbitCheck p.val (List.mem_toFinset.mp p.property)).2

#print axioms six_capacity
#print axioms neutral_key
end ExactWordFlow.RunCollision

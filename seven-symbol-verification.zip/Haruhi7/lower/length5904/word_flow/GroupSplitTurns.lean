import MarkedLargeCap
import HundredDecomposition

namespace ExactWordFlow.GroupSplitTurns
open SevenWordWindows DirectedEuler ResidualDensity ResidualIncidence ResidualRoutes RotationComponentCount
open scoped Classical
open private required_data from ResidualIncidence
open private sizes wheel_data from EmbeddedWheels
open private six_cycle from MarkedLargeCap
open private partition wheel_list from HundredDecomposition

/-- A closed residual component meets a full context even after a multiset
of whole wheels has been removed from the original feasible flow. -/
theorem clean_of_split {Y : Multiset Block} {ws : List Block} {s t : Block}
    (h : Feasible (Y+EmbeddedWheels.turns ws) s t) (fw : ∀u∈ws,full u)
    {q : Component Y} (away : q≠label Y s) (pos : 0<(part Y q).card) :
    ∃v,full v ∧ label Y v=q := by
  classical
  by_contra! no
  let S : Set Block := {v | label Y v≠q}
  have stable (e) (he : e∈required+(Y+EmbeddedWheels.turns ws)) (hs : src e∈S) : dst e∈S := by
    change label Y (dst e)≠q
    rcases Multiset.mem_add.mp he with req | more
    · exact no _ (required_data e req).2.1
    rcases Multiset.mem_add.mp more with y|t
    · rw [←on_edge y]
      exact hs
    obtain ⟨u,old,edge⟩:=List.mem_flatMap.mp (show e∈ws.flatMap GlobalWheelRank.wheel from t)
    exact no _ ((wheel_data u (mem_states (fw u old))).2.2.2 e edge).2.1
  obtain ⟨e,he⟩:=Multiset.exists_mem_of_ne_zero (show part Y q≠0 by intro eq; simp [eq] at pos)
  have ey : e∈Y+EmbeddedWheels.turns ws:=Multiset.mem_add.mpr (Or.inl (in_part.mp he).1)
  exact (h.reachable S (Ne.symm away) stable e (Multiset.mem_add.mpr (Or.inr ey))) (in_part.mp he).2

/-- If all the noninitial components after removal of chosen wheels have
size at most six, the whole feasible flow consists, with multiplicity,
of one actual path, the chosen wheels, and further genuine six-wheels. -/
theorem group {Y : Multiset Block} {ws : List Block} {s t : Block}
    (h : Feasible (Y+EmbeddedWheels.turns ws) s t) (fw : ∀u∈ws,full u)
    (small : ∀q∈((support Y s).image (label Y)).erase (label Y s), (part Y q).card≤6) :
    ∃es extra : List Block, Route src dst s es t ∧ (∀u∈extra, full u) ∧
      Y+EmbeddedWheels.turns ws=(↑es : Multiset Block)+EmbeddedWheels.turns (extra++ws) := by
  classical
  have bal:=Essential.restBalance h (sizes fw).2
  have wd (e) (he : e∈Y) :=h.edges_seven e (Multiset.mem_add.mpr (Or.inl he))
  have whole (q) (hq : q∈occupied Y s) : ∃v,full v ∧ label Y v=q ∧ part Y q=↑(GlobalWheelRank.wheel v) := by
    obtain ⟨away,seen⟩:=Finset.mem_erase.mp hq
    obtain ⟨x,hx,key⟩:=Finset.mem_image.mp seen
    obtain ⟨e,old,rfl⟩:=Multiset.mem_map.mp (Multiset.mem_toFinset.mp hx)
    have loc : e∈part Y q := in_part.mpr ⟨old,key⟩
    have pos : 0<(part Y q).card:=Multiset.card_pos.mpr (fun eq=>by simp [eq] at loc)
    have dq : q∈(support Y s).image (label Y) := by
      rw [←key,on_edge old]
      exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
        (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr old),rfl⟩)))
    have cap:=small q (Finset.mem_erase.mpr ⟨away,dq⟩)
    obtain ⟨v,clean,atV⟩:=clean_of_split h fw away pos
    obtain ⟨a,b,es,bag,r,_,ends⟩:=component_route bal v
    rw [atV] at bag ends
    obtain ⟨atA,atB⟩:=ends.2 away
    subst a; subst b
    have len : es.length=(part Y q).card:=congrArg Multiset.card bag
    have width (x) (hx : x∈es) := wd x (in_part.mp (bag ▸ (show x∈(↑es : Multiset Block) from hx))).1
    have minLen:=closed_clean clean r width (by omega)
    have turn:=six_cycle clean r width (by omega)
    exact ⟨v,clean,atV,bag.symm.trans (congrArg (fun l : List Block=>(↑l : Multiset Block)) turn)⟩
  obtain ⟨extra,_,legal,_,packet⟩:=wheel_list (occupied Y s) whole
  obtain ⟨a,b,es,bag,r,_,ends⟩:=component_route bal s
  obtain ⟨atS,atT⟩:=ends.1 rfl
  subst a; subst b
  refine ⟨es,extra,r,fun u hu=>(legal _ hu).1,?_⟩
  have split:=partition Y s
  rw [←bag,←packet] at split
  calc
    _=(↑es+EmbeddedWheels.turns extra)+EmbeddedWheels.turns ws:=congrArg (·+EmbeddedWheels.turns ws) split
    _=_:=by simp [EmbeddedWheels.turns]

#print axioms group
end ExactWordFlow.GroupSplitTurns

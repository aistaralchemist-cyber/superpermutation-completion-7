import ForcedRootClosure
namespace ExactWordFlow.FixedSeed390
open SevenWordWindows SeedWheelCut ExtremeWheelCut ForcedRootClosure
open private digits makeCert valid eliminates from ExtremeWheelCut
open private cost from PlanarScoreExample

/-- An actual cycle in the adjusted successor order, stored by runs of
paid ordinary two-letter advances. The first move after the last run is free. -/
private def rows : List (Nat × String) := [
  (5, "0123456"),
  (5, "0234516"),
  (5, "0345126"),
  (5, "0451236"),
  (3, "0512346"),
  (5, "0651243"),
  (5, "0512463"),
  (5, "0124653"),
  (3, "0246513"),
  (5, "0324615"),
  (5, "0246135"),
  (3, "0461325"),
  (5, "0546123"),
  (5, "0461253"),
  (5, "0612543"),
  (3, "0125463"),
  (5, "0312564"),
  (5, "0125634"),
  (3, "0256314"),
  (5, "0425613"),
  (5, "0256143"),
  (5, "0561423"),
  (3, "0614253"),
  (5, "0361452"),
  (5, "0614532"),
  (3, "0145362"),
  (5, "0214563"),
  (5, "0145623"),
  (5, "0456213"),
  (3, "0562143"),
  (5, "1356240"),
  (2, "0562413"),
  (5, "0135642"),
  (5, "0356412"),
  (5, "0564132"),
  (3, "0641352"),
  (5, "0264153"),
  (5, "0641523"),
  (5, "0415263"),
  (3, "0152643"),
  (5, "0315246"),
  (5, "0152436"),
  (3, "0524316"),
  (3, "0652413"),
  (5, "0365214"),
  (5, "0652134"),
  (3, "0521364"),
  (5, "0452163"),
  (5, "0521643"),
  (5, "0216453"),
  (3, "0164523"),
  (5, "5316420"),
  (2, "0164253"),
  (5, "0531624"),
  (5, "0316254"),
  (5, "0162534"),
  (3, "0625314"),
  (5, "0462513"),
  (5, "0625143"),
  (3, "0251463"),
  (5, "0325164"),
  (5, "0251634"),
  (5, "0163542"),
  (5, "0635412"),
  (5, "0354162"),
  (5, "0416532"),
  (5, "0165342"),
  (3, "0653412"),
  (3, "0265314"),
  (5, "0426513"),
  (5, "0265143"),
  (5, "0651423")]
def walk : List Block := rows.flatMap fun (r,s) =>
  (List.range (r+1)).map fun j => (digits s).take 1 ++ (digits s).tail.rotate j
def rootClasses := (walk.map classKey).toFinset
private def paid := (walk.zip walk.tail).map fun (x,y) => cost x y

theorem profile : (∀ p∈walk,p.length=7 ∧ p.Nodup) ∧ walk.length=390 ∧
    rootClasses.card=390 ∧ paid.length=389 ∧ paid.count 2=318 ∧ paid.count 3=69 ∧ paid.count 4=2 ∧
    cost (walk.getLastD []) (walk.headD [])=7 ∧
    (paid.map fun d => d-2).sum=73 ∧
    walk.length-6-5*(paid.map fun d => d-2).sum=19 := by native_decide

theorem fixed : force rootClasses=rootClasses := by native_decide

/-- Force is monotone on arbitrary sets, without requiring them to be visited. -/
theorem mono : Monotone force := by
  intro X Y sub d hd
  rcases Finset.mem_union.mp hd with old | new
  · exact Finset.mem_union_left _ (sub old)
  · obtain ⟨member,blocked⟩:=Finset.mem_filter.mp new
    apply Finset.mem_union_right
    apply Finset.mem_filter.mpr
    refine ⟨member,fun w legal contains=>?_⟩
    exact (blocked w legal contains).trans (Finset.card_le_card (Finset.inter_subset_inter sub (Finset.Subset.refl _)))

/-- In this score-19 instance no choice of 378 seed tags, and no number
of closure iterations, can yield the 391st tag needed by that argument. -/
theorem every_subseed (P : Finset Block) (sub : P⊆rootClasses) (n : Nat) :
    (force^[n]) P⊆rootClasses := by
  induction n with
  | zero => exact sub
  | succ n ih =>
    rw [Function.iterate_succ_apply']
    simpa only [fixed] using mono ih

theorem closure_cap (P : Finset Block) (sub : P⊆rootClasses) (n : Nat) :
    ((force^[n]) P).card≤390 := by
  exact (Finset.card_le_card (every_subseed P sub n)).trans_eq profile.2.2.1

private def oneJoin := makeCert [("0126534","012654")] "0315264"
private theorem conflict : valid rootClasses oneJoin=true := by native_decide

/-- Nonetheless a simultaneous 66-wheel cover is impossible: 0126534
requires the wheel 012654 and then 0315264 has no admissible wheel. -/
theorem no_cover {W : Finset (Finset Block)} (legal : W⊆allRows)
    (limit : W.card≤66) : ¬ ClosedCover rootClasses allClasses W := by
  have size := profile.2.2.1
  have card : allClasses.card=720 := by native_decide
  exact eliminates oneJoin _ legal (by omega) conflict

theorem any_genus_floor {W : Finset (Finset Block)} {wheels genus length : Nat}
    (legal : W⊆allRows) (linked : ClosedCover rootClasses allClasses W)
    (count : W.card≤wheels) (mass : 390+6*wheels=(wheels+1)+719+2*genus)
    (price : length=5764+(wheels+1)+73+2*genus) : 5916 ≤ length := by
  have many : 67 ≤ wheels := by
    by_contra! low
    exact no_cover legal (by omega) linked
  omega

#print axioms profile
#print axioms fixed
#print axioms every_subseed
#print axioms closure_cap
#print axioms no_cover
#print axioms any_genus_floor
end ExactWordFlow.FixedSeed390

import NearBindingCheck
import BatchedRealizations

namespace ExactWordFlow.NearWheelBinding
open SevenWordWindows ResidualDensity ResidualDensity.NearExtrema
open private records baseGood index checkLookup from NearBindingCheck

/-- Verify the shared search prefixes once; the inclusion moves the check
back to the geometric realization set used in the word theorem. -/
def batched (n : Nat) :=
  let v := records n
  let table := (NearHardRoots.hard n).toArray
  v.toList.all (baseGood n table) &&
    let lut := index v
    (BatchedRealizations.results (profiles n)).all (checkLookup v lut)

theorem verified_of_batched (n : Nat) (ok : batched n=true) : verified n=true := by
  obtain ⟨base,geo⟩ := Bool.and_eq_true_iff.mp ok
  apply Bool.and_eq_true_iff.mpr
  refine ⟨base,List.all_eq_true.mpr ?_⟩
  intro R hr
  exact List.all_eq_true.mp geo R (BatchedRealizations.covers (profiles n) hr)

end ExactWordFlow.NearWheelBinding

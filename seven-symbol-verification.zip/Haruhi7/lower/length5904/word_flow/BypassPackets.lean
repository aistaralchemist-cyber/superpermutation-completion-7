import ResidualRoutes

/-! Deleting a circulation preserves feasibility whenever every one of its
edges joins states that are already in the same weak component of the kept
support. No equality of the old and replacement edge labels is required. -/
namespace ExactWordFlow.Essential
open ResidualRoutes SevenWordWindows SuperpermutationBounds

def Bypassable (A B : Multiset Block) : Prop :=
  ∀ e∈B, label (required+A) (src e) = label (required+A) (dst e)

theorem delete_bypassed {A B : Multiset Block} {s t : Block}
    (h : Feasible (A+B) s t) (hb : Balanced B) (bypass : Bypassable A B) : Feasible A s t := by
  have bal := restBalance h hb
  have req : required.map src=required.map dst := balanced_representatives
  have whole : (required+A).map src + {t} = (required+A).map dst + {s} := by
    rw [Multiset.map_add,Multiset.map_add,req,add_assoc,add_assoc,bal]
  refine ⟨h.start_six,fun e he => h.edges_seven e (Multiset.mem_add.mpr (Or.inl he)),bal,?_⟩
  intro S start closed e he
  have both := (restrictBalance start whole closed).2.1
  refine h.reachable S start ?_ e ?_
  · intro f hf hs
    rw [← add_assoc] at hf
    rcases Multiset.mem_add.mp hf with kept | deleted
    · exact closed f kept hs
    · exact (invariant S both (bypass f deleted)).mp hs
  · rw [← add_assoc]
    exact Multiset.mem_add.mpr (Or.inl he)

/-- Twelve bypassable extra steps account for the entire gap to the
kernel-checked 5,893 lower bound. This holds for any choice of endpoints. -/
theorem no_twelve_bypassed {A B : Multiset Block} {s t : Block}
    (budget : (A+B).card≤858) (hb : Balanced B) (bypass : Bypassable A B)
    (many : 12≤B.card) : ¬Feasible (A+B) s t := by
  intro h
  have hf := delete_bypassed h hb bypass
  obtain ⟨w,cv,sz⟩ := (word_iff_flow (A.card+5046) (by omega)).mpr ⟨A,s,t,by omega,hf⟩
  have lo := SuperpermLowerBounds.superperm_kisic_numerical_bounds.2.2.1.trans
    (SuperpermBridge.ssuper_le_length cv)
  rw [Multiset.card_add] at budget
  omega

theorem minimal_no_bypass {A B : Multiset Block} {s t : Block}
    (h : Feasible (A+B) s t) (min : Minimal (A+B) s t) (hb : Balanced B)
    (bypass : Bypassable A B) : B.card=0 := by
  have c := min A le_self_add (delete_bypassed h hb bypass)
  rw [Multiset.card_add] at c
  omega

#print axioms delete_bypassed
#print axioms no_twelve_bypassed
#print axioms minimal_no_bypass
end ExactWordFlow.Essential

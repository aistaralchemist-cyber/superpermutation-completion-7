import CompatibleWheelExample
import SeedWheelCut

namespace CompatibleWheelExample
open ResidualDensity SevenWordWindows SeedWheelCut

/-- The two overlapping forced wheels exclude every connected 66-wheel completion
of this actual 462-edge open route. -/
theorem no66_cover (R : Finset (Finset Six)) (legal : ∀r∈R, r∈rows) (budget : R.card≤66) :
    ¬ClosedCover A allClasses R := by
  intro linked
  obtain ⟨_,_,_,nx,ny,nz,fx,fy,wv,zw,zv,wa,va⟩ := compatible_data
  have ac : A.card=390 := witnessed.2.2
  have vc : allClasses.card=720 := by native_decide
  have size : rows.all (fun r => decide (r.card=6))=true := by native_decide
  have width (r) (hr : r∈R) : r.card≤6 := le_of_eq <| of_decide_eq_true
    (List.all_eq_true.mp size r (legal r hr))
  have force (d : Six) (g : Finset Six) (dv : d∈allClasses) (dd : d∉A)
      (keys : goodRows.filter (fun r => decide (d∈r))=[g]) : g∈R := by
    by_contra no
    apply dd
    apply forced_by_seed A A allClasses R d (Finset.Subset.refl _) dv width (by omega) _ linked
    intro r hr dr
    by_contra! small
    have good : r∈goodRows := List.mem_filter.mpr ⟨legal r hr,decide_eq_true
      (by rw [Finset.inter_comm]; omega)⟩
    have mem : r∈goodRows.filter (fun v => decide (d∈v)) :=
      List.mem_filter.mpr ⟨good,decide_eq_true dr⟩
    rw [keys,List.mem_singleton] at mem
    exact no (mem ▸ hr)
  have wr := force x W (by native_decide) nx fx
  have vr := force y V (by native_decide) ny fy
  have both : (A∪W∪V).card=399 := by native_decide
  let T := (R.erase W).erase V
  have vin : V∈R.erase W := Finset.mem_erase.mpr ⟨Ne.symm wv,vr⟩
  have left : T.card + 2=R.card := by
    have h1 := Finset.card_erase_add_one wr
    have h2 := Finset.card_erase_add_one vin
    change ((R.erase W).erase V).card+2=R.card
    omega
  obtain ⟨C,sub,cap,rest⟩ := GlobalWheelRank.grow (A∪W∪V) T
  have includes : A ⊆ C := Finset.subset_union_left.trans (Finset.subset_union_left.trans sub)
  have closed (r : Finset Six) (hr : r∈R) (meet : (C∩r).Nonempty) : r⊆C := by
    by_cases a : r=W
    · subst r
      exact Finset.subset_union_right.trans (Finset.subset_union_left.trans sub)
    by_cases b : r=V
    · subst r;exact Finset.subset_union_right.trans sub
    exact rest r (Finset.mem_erase.mpr ⟨b,Finset.mem_erase.mpr ⟨a,hr⟩⟩) meet
  have total := Finset.card_le_card (linked C includes closed)
  have sum : ∑ r∈T,(r.card-1) ≤ T.card*5 := by
    apply Finset.sum_le_card_nsmul
    intro r hr
    have orig := (Finset.mem_erase.mp ((Finset.mem_erase.mp hr).2)).2
    have := width r orig
    omega
  omega

end CompatibleWheelExample
#print axioms CompatibleWheelExample.no66_cover

import Bound
namespace ExactWordFlow.WheelCoverCapacity
open SevenWordWindows RotationCore LiteralWheelCover

def gain (b : Block) (R : Row) := (R \ visited b).card

/-- A capacity bound using the entire histogram of initially available rows,
with no enumeration of covers. It applies to an arbitrary threshold t. -/
theorem threshold {b : Block} {k : Nat} (cover : condition b k) (t : Nat) :
    720 ≤ (visited b).card + t*k + ∑ R∈ready b, (gain b R-t) := by
  classical
  obtain ⟨S,valid,count,all⟩ := cover
  have inc : allClasses \ visited b ⊆ S.biUnion (fun R => R \ visited b) := by
    intro c hc
    obtain ⟨R,hR,wit⟩ := Finset.mem_biUnion.mp (all hc)
    exact Finset.mem_biUnion.mpr ⟨R,hR,Finset.mem_sdiff.mpr ⟨wit,(Finset.mem_sdiff.mp hc).2⟩⟩
  have mass := (Finset.card_le_card inc).trans (Finset.card_biUnion_le)
  rw [Finset.card_sdiff_of_subset (visited_subset b),board] at mass
  change 720 - (visited b).card ≤ ∑R∈S,gain b R at mass
  have up (R : Row) (_ : R∈S) : gain b R ≤ t+(gain b R-t) := by omega
  have cap := Finset.sum_le_sum up
  rw [Finset.sum_add_distrib] at cap
  simp only [Finset.sum_const, smul_eq_mul] at cap
  have positive := Finset.sum_le_sum_of_subset (f:=fun R=>gain b R-t) valid
  have limit := Nat.mul_le_mul_left t count
  rw [Nat.mul_comm _ t] at cap
  omega

/-- Each unused slot in a selected row also consumes one unit of the 139
residual defect. Neither the wheel-free hypothesis nor a prechosen source is needed. -/
theorem defect_split {b : Block} {k : Nat} (done : (complete b).card=92)
    (len : b.length+6*k=1508) (cover : condition b k) :
    RauzyBudget.defect b + k + (5*k-(allClasses \ visited b).card) = 139 := by
  have need := LapSkeleton.completed_floor b
  have goodlen : (good b).length≤b.length-6 := by rw [←windows_length]; exact List.length_filter_le ..
  have cost := RauzyBudget.length_eq b (by omega)
  have cap := cover_bound cover
  have boardbound := Finset.card_le_card (visited_subset b)
  rw [board] at boardbound
  rw [Finset.card_sdiff_of_subset (visited_subset b),board]
  omega

#print axioms threshold
#print axioms defect_split
end ExactWordFlow.WheelCoverCapacity

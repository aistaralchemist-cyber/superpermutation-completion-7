import MarkedComponentCap
import LapSkeleton

namespace ExactWordFlow.MarkedLargeCap
open scoped Classical
open SevenWordWindows ResidualDensity ResidualDensity.Density66 DirectedEuler ResidualRoutes ResidualIncidence GlobalDensity66 RotationComponentCount

open private open_cap cyclic_cap closed_price chunksCap prices from GlobalDensity66
open private all_contacts from OverlapBudget

private def openBound (k : Nat) := min (cap k) ((38*(k+1)+66)/45)
private def closeBound (k : Nat) := min (56*k/66) (if 111≤k then 94*k/111 else 720)

private theorem scalar : ∀ r b : Fin 289,79≤b.val → r.val+b.val≤288 →
    6*(openBound r.val-1)+6*(closeBound b.val-1)<5*(r.val+b.val)+24 := by
  native_decide

/-- Single out one positive nonroot component; each of the other active
components still consumes six edges. -/
private theorem two_mass {X : Multiset Block} {s : Block} {qBig : Component X}
    (actBig : qBig∈active X s) : 6*(active X s).card+(part X (label X s)).card+
      (part X qBig).card≤X.card+6 := by
  classical
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  obtain ⟨bigIn,away,_⟩:=Finset.mem_filter.mp actBig
  change qBig∈Q at bigIn
  change qBig≠home at away
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q=X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have rootNot : home∉active X s := fun mem=>(Finset.mem_filter.mp mem).2.1 rfl
  have sizeTerm (q) (_ : q∈Q) :
      (if q∈active X s then 6 else 0)+(if q=home then K home else 0)+
        (if q=qBig then K qBig else 0)≤K q+(if q=qBig then 6 else 0) := by
    by_cases R : q=home
    · subst q; simp [rootNot,Ne.symm away]
    by_cases B : q=qBig
    · subst q; simp [actBig,away,Nat.add_comm]
    by_cases A : q∈active X s
    · simpa [R,B,A,K] using (Finset.mem_filter.mp A).2.2
    · simp [R,B,A]
  have raw:=Finset.sum_le_sum sizeTerm
  have actSub : active X s⊆Q := fun _ mem=>(Finset.mem_filter.mp mem).1
  have allAct : (Q.filter fun q=>q∈active X s)=active X s :=
    by
    ext x
    simp only [Finset.mem_filter]
    exact ⟨And.right,fun hx=>⟨actSub hx,hx⟩⟩
  have actEq : (∑q∈Q,if q∈active X s then 6 else 0)=6*(active X s).card := by
    rw [←Finset.sum_filter,allAct]; simp [Nat.mul_comm]
  simp only [Finset.sum_add_distrib,Finset.sum_ite_eq',root,bigIn,ite_true,actEq,total] at raw
  exact raw

/-- With at least 96 edge-bearing nonroot components, the 66-position price
leaves room for at most one closed component of size 79 or more. In that
case root plus large component have at most 288 edges. -/
private theorem bound_of_intervals
    (pathCap : ∀{a b : Block} {p : List Block},Route src dst a p b → (∀e∈p,e.length=7) →
      45*classCount a p≤38*(p.length+1)+66)
    (closed111 : ∀{a : Block} {p : List Block},Route src dst a p a → (∀e∈p,e.length=7) →
      111≤p.length → 111*classCount a p≤94*p.length)
    {X : Multiset Block} {s t : Block} (h : Feasible X s t) (budget : X.card≤858)
    (paid : 66*separateRank X s+6*(active X s).card+60*(large X s).card≤56*X.card+66)
    (hasBig : (large X s).Nonempty) : (occupied X s).card≤95 := by
  classical
  rw [occupied_active h]
  by_contra! many
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  let C (q : Component X) := (contacts (support X s) (label X) q).card
  have rk : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  obtain ⟨qBig,hBig⟩:=hasBig
  obtain ⟨bigIn,away,atleast⟩:=Finset.mem_filter.mp hBig
  change qBig∈Q at bigIn
  change qBig≠home at away
  change 79≤K qBig at atleast
  have bigOnly : (large X s).card≤1 := by omega
  have actBig : qBig∈active X s := Finset.mem_filter.mpr ⟨bigIn,away,show 6≤K qBig by omega⟩
  have root : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q=X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have raw : 6*(active X s).card+K home+K qBig≤X.card+6 := two_mass actBig
  have leftMass : K home+K qBig≤288 := by omega
  have get (q) (hq : q∈Q) :
      (q=home → C q≤openBound (K q)) ∧
      (q=qBig → C q≤closeBound (K q)) ∧
      (q≠home → q≠qBig → 6*(C q-1)≤5*K q) := by
    obtain ⟨v,_,vv⟩ := Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩:=component_route h.balance v
    rw [vv] at eq lv ep
    have len : es.length=K q := congrArg Multiset.card eq
    have wd (e) (he : e∈es) := h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have incl : C q≤classCount a es:=contacts_bound _ lv r eq
    refine ⟨fun _=>?_,?_,?_⟩
    · obtain ⟨x,y,z⟩:=open_cap r wd
      have p:=pathCap r wd
      rw [len] at x y z p
      exact le_min (le_min (all_contacts ..) (le_min (incl.trans x) (le_min (incl.trans y) (incl.trans z)))) (by omega)
    · rintro rfl
      obtain ⟨aa,bb⟩:=ep.2 away
      subst a; subst b
      change 79≤K q at atleast
      have lo:=cyclic_cap r wd (by omega)
      refine le_min (by omega) ?_
      split
      next largeSize => have cl:=closed111 r wd (by omega); omega
      next => exact all_contacts .. 
    · intro notRoot notBig
      obtain ⟨aa,bb⟩:=ep.2 notRoot
      subst a; subst b
      have small : es.length<79 := by
        by_contra! bad
        have seen : q∈large X s := Finset.mem_filter.mpr ⟨hq,notRoot,show 79≤K q by omega⟩
        exact notBig (Finset.card_le_one.mp bigOnly _ seen _ hBig)
      have cl:=closed_price r wd small
      omega
  have compare (q) (hq : q∈Q) :
      6*(C q-1)+(if q=home then 5*K home else 0)+(if q=qBig then 5*K qBig else 0)≤
        5*K q+(if q=home then 6*(C home-1) else 0)+(if q=qBig then 6*(C qBig-1) else 0) := by
    by_cases R : q=home
    · subst q; simp [Ne.symm away,Nat.add_comm]
    by_cases B : q=qBig
    · subst q; simp [away,Nat.add_comm]
    simpa [R,B] using (get q hq).2.2 R B
  have bound:=Finset.sum_le_sum compare
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_ite_eq',root,bigIn,ite_true,total] at bound
  change 6*separateRank X s+5*K home+5*K qBig≤_ at bound
  have hroot:=(get home root).1 rfl
  have hbig:=(get qBig bigIn).2.1 rfl
  have check:=scalar ⟨K home,by omega⟩ ⟨K qBig,by omega⟩ atleast leftMass
  change 6*(openBound (K home)-1)+6*(closeBound (K qBig)-1)<5*(K home+K qBig)+24 at check
  omega

/-- At this 258-edge extreme the open component hits exactly 220 distinct
rotation classes. Every other component obeys the short closed-walk price. -/
private theorem root_contacts {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (totalSize : X.card=858) (size : (part X (label X s)).card=258) (empty : large X s=∅) :
    (contacts (support X s) (label X) (label X s)).card=220 := by
  classical
  let Q := (support X s).image (label X)
  let home := label X s
  let K (q : Component X) := (part X q).card
  let C (q : Component X) := (contacts (support X s) (label X) q).card
  have homeIn : home∈Q := Finset.mem_image.mpr ⟨s,Finset.mem_insert_self ..,rfl⟩
  have total : ∑q∈Q,K q=X.card := sum_part_card X Q (by
    intro e he
    rw [on_edge he]
    exact Finset.mem_image_of_mem _ (Finset.mem_insert_of_mem (Multiset.mem_toFinset.mpr
      (Multiset.mem_map.mpr ⟨e,Multiset.mem_add.mpr (Or.inr he),rfl⟩))))
  have each (q) (hq : q∈Q) :
      (q=home → C q≤cap (K q)) ∧ (q≠home → 6*(C q-1)≤5*K q) := by
    obtain ⟨v,_,vv⟩:=Finset.mem_image.mp hq
    obtain ⟨a,b,es,eq,r,lv,ep⟩:=component_route h.balance v
    rw [vv] at eq lv ep
    have len : es.length=K q := congrArg Multiset.card eq
    have wd (e) (he : e∈es) := h.edges_seven e (in_part.mp (eq ▸ (show e∈(↑es : Multiset Block) from he))).1
    have incl : C q≤classCount a es := contacts_bound _ lv r eq
    constructor
    · intro _
      obtain ⟨x,y,z⟩:=open_cap r wd
      rw [len] at x y z
      exact le_min (all_contacts ..) (le_min (incl.trans x) (le_min (incl.trans y) (incl.trans z)))
    · intro away
      obtain ⟨aa,bb⟩:=ep.2 away
      subst a; subst b
      have small : es.length<79 := by
        by_contra! bad
        have seen : q∈large X s := Finset.mem_filter.mpr ⟨hq,away,show 79≤K q by omega⟩
        simp [empty] at seen
      have cl:=closed_price r wd small
      omega
  have price (q) (hq : q∈Q) : 6*(C q-1)+(if q=home then 5*K home else 0)≤
      5*K q+(if q=home then 6*(C home-1) else 0) := by
    by_cases atHome : q=home
    · subst q; simp [Nat.add_comm]
    simpa [atHome] using (each q hq).2 atHome
  have full:=Finset.sum_le_sum price
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_ite_eq',homeIn,ite_true,total] at full
  change 6*separateRank X s+5*K home≤5*X.card+6*(C home-1) at full
  have rk : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  change K home=258 at size
  have maxC:=(each home homeIn).1 rfl
  have scalar : cap 258=220 := by native_decide
  rw [size,scalar] at maxC
  change C home=220
  omega

/-- If the global bound 100 is attained, the 858-edge budget is
saturated: the open component has 258 edges and every positive nonroot
component has exactly six. -/
private theorem extreme_of_prices {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (fullCount : (occupied X s).card=100)
    (bigLimit : (large X s).Nonempty → (occupied X s).card≤95)
    (rootLimit : large X s=∅ → 258≤(part X (label X s)).card) :
    X.card=858 ∧ (part X (label X s)).card=258 ∧
      separateRank X s=719 ∧ (contacts (support X s) (label X) (label X s)).card=220 ∧
      ∀ q∈occupied X s,(part X q).card=6 := by
  classical
  have noBig : large X s=∅ := by
    by_contra! nonempty
    have := bigLimit nonempty
    omega
  have home:=rootLimit noBig
  rw [occupied_active h] at fullCount ⊢
  have each (q) (activeQ : q∈active X s) :
      X.card=858 ∧ (part X (label X s)).card=258 ∧ (part X q).card=6 := by
    have mass:=two_mass activeQ
    have minSize:=(Finset.mem_filter.mp activeQ).2.2
    omega
  obtain ⟨q,hq⟩:=Finset.card_pos.mp (show 0<(active X s).card by omega)
  have total:=(each q hq).1
  have rootSize:=(each q hq).2.1
  have cap258 : cap 258=220 := by native_decide
  have old:=(prices h.balance h.edges_seven budget).2 noBig
  change 6*separateRank X s+5*(part X (label X s)).card≤5*X.card+6*(cap (part X (label X s)).card-1) at old
  rw [rootSize,cap258,total] at old
  have minRank : 719 ≤ separateRank X s:=rank719 _ h (fun _ he=>on_edge he)
  exact ⟨total,rootSize,by omega,root_contacts h total rootSize noBig,fun q hq=>(each q hq).2.2⟩

open private end_eq from LapSkeleton

/-- A closed route with exactly six steps and a clean initial vertex u
spells u++u. Its edges therefore form the ordinary wheel of u. -/
private theorem six_cycle {v : Block} {es : List Block} (clean : full v)
    (trip : Route src dst v es v) (width : ∀e∈es,e.length=7) (six : es.length=6) :
    es=GlobalWheelRank.wheel v := by
  obtain ⟨z,len,front,windows⟩:=RotationReinsert.spell_route trip clean.1 width
  have closed:=read_route z (by omega)
  rw [front,windows] at closed
  have last:=end_eq closed trip
  rw [show z.length-6=6 by omega] at last
  have eq:=List.take_append_drop 6 z
  rw [front,last] at eq
  have table : ∀u∈states,SevenWordWindows.windows (u++u)=GlobalWheelRank.wheel u := by native_decide
  exact windows.symm.trans (eq ▸ table v (mem_states clean))

theorem six_component {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    {q : Component X} (away : q≠label X s) (size : (part X q).card=6) :
    ∃v,full v ∧ label X v=q ∧ part X q=↑(GlobalWheelRank.wheel v) := by
  obtain ⟨v,clean,key⟩:=residual_clean h away (by omega : 0<(part X q).card)
  obtain ⟨a,b,es,bag,route,_,ep⟩:=component_route h.balance v
  rw [key] at bag ep
  obtain ⟨aa,bb⟩:=ep.2 away
  subst a; subst b
  have len:=congrArg Multiset.card bag
  have width (e) (he : e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have turn:=six_cycle clean route width (by simpa [size] using len)
  exact ⟨v,clean,key,bag.symm.trans (congrArg (fun l : List Block=>(↑l : Multiset Block)) turn)⟩

private theorem closed111 {a : Block} {p : List Block} (r : Route src dst a p a)
    (wd : ∀e∈p,e.length=7) (lo : 111≤p.length) : 111*classCount a p≤94*p.length := by
  obtain ⟨u,I,w,hm,cc⟩ := closed_observations r wd (by omega)
  have n:=window_cyclic_bound hm lo (fun i pp _ hh=>WeightedMarks.interval111 w hh i)
  simpa only [cc] using n

/-- Uniform numerical limit when at least one nonroot component has 79 edges. -/
theorem large_le {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (hasBig : (large X s).Nonempty) : (occupied X s).card≤95 :=
  bound_of_intervals WeightedMarks.path_cap closed111 h budget
    (MarkedComponentCap.component_prices h budget).1 hasBig

/-- The only possible hundred-component case at cost 858 consists of
a 258-edge initial component and one hundred ordinary six-wheels. The
initial component has exactly 220 class contacts and the rank is tight. -/
theorem hundred_shape {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (hundred : (occupied X s).card=100) :
    X.card=858 ∧ (part X (label X s)).card=258 ∧ separateRank X s=719 ∧
      (contacts (support X s) (label X) (label X s)).card=220 ∧
      ∀q∈occupied X s,(part X q).card=6 ∧
        ∃v,full v ∧ label X v=q ∧ part X q=↑(GlobalWheelRank.wheel v) := by
  obtain ⟨total,home,rank,colors,all⟩:=extreme_of_prices h budget hundred
    (large_le h budget) (MarkedComponentCap.component_prices h budget).2
  refine ⟨total,home,rank,colors,fun q hq=>⟨all q hq,?_⟩⟩
  exact six_component h (Finset.mem_erase.mp hq).1 (all q hq)

#print axioms large_le
#print axioms hundred_shape
end ExactWordFlow.MarkedLargeCap

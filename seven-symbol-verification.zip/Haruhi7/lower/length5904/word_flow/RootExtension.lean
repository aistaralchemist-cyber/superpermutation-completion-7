import FixedSeed235Exact

namespace ExactWordFlow.RootExtension
open SeedWheelCut SevenWordWindows ExtremeWheelCut
variable {α : Type*} [DecidableEq α]

theorem compose {A B V : Finset α} {D W : Finset (Finset α)}
    (first : ClosedCover A B D) (rest : ClosedCover B V W) : ClosedCover A V (D∪W) := by
  intro C inside closed
  apply rest C (first C inside (fun w hw=>closed w (Finset.mem_union_left _ hw)))
    (fun w hw=>closed w (Finset.mem_union_right _ hw))

theorem inherit_cut {A B V : Finset α} {rows D W : Finset (Finset α)} (n : Nat)
    (no : ∀ {U : Finset (Finset α)},U⊆rows → U.card≤n → ¬ClosedCover A V U)
    (first : ClosedCover A B D) (dOK : D⊆rows) (wOK : W⊆rows) (bill : D.card+W.card≤n) :
    ¬ClosedCover B V W := by
  intro rest
  exact no (Finset.union_subset dOK wOK) ((Finset.card_union_le ..).trans bill) (compose first rest)

theorem one_wheel (A w : Finset α) (meet : (A∩w).Nonempty) : ClosedCover A (A∪w) {w} := by
  intro C base closed
  obtain ⟨z,hz⟩:=meet
  obtain ⟨za,zw⟩:=Finset.mem_inter.mp hz
  exact Finset.union_subset base
    (closed w (Finset.mem_singleton_self _) ⟨z,Finset.mem_inter.mpr ⟨base za,zw⟩⟩)

/-- Any root supplied by the old 235-tag trace and at most three ordinary
wheels inherits a complete exclusion at the 94-wheel budget. -/
theorem from235 {B : Finset Block} {D W : Finset (Finset Block)}
    (first : ClosedCover FixedSeed235Exact.rootClasses B D)
    (dOK : D⊆allRows) (small : D.card≤3) (wOK : W⊆allRows) (n : W.card≤94) :
    ¬ ClosedCover B allClasses W :=
  inherit_cut 97 (@FixedSeed235Exact.no_cover) first dOK wOK (by omega)

end ExactWordFlow.RootExtension

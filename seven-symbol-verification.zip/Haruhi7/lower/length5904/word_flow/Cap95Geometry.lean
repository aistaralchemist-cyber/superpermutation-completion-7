import Cap95Shape
import Cap95Profiles
import NoNearHundred

namespace ExactWordFlow.Cap95Geometry
open SevenWordWindows DirectedEuler ResidualDensity RotationComponentCount RotationCore
open WeightedMarks ExtremalRealizations ExtremeWheelCut SuperpermutationBounds
open scoped Classical
open private partition wheel_list from HundredDecomposition
open private hits from NearHundredShape
open private initial from MarkedDensity
open private select from RouteDensity
open ResidualRoutes

theorem cover_certificate {X : Multiset Block} {s t : Block} (h : Feasible X s t)
    (budget : X.card≤858) (card : (occupied X s).card=95) :
    ∃R∈realizations (Cap95Profiles.profiles 95),∃W⊆allRows,
      W.card≤95 ∧ SeedWheelCut.ClosedCover R allClasses W := by
  classical
  obtain ⟨_,root,_,colors,every⟩:=Cap95Shape.shape h budget card
  obtain ⟨a,b,es,bag,r,eq,ends⟩:=component_route h.balance s
  obtain ⟨aa,bb⟩:=ends.1 rfl
  subst a; subst b
  have len : es.length=(part X (label X s)).card:=congrArg Multiset.card bag
  have wd (e) (he : e∈es):=h.edges_seven e (in_part.mp (bag ▸ (show e∈(↑es : Multiset Block) from he))).1
  have cover : hits X s (label X s)≤classCount s es:=contacts_bound _ eq r bag
  obtain ⟨ws,num,legal,_,packet⟩:=wheel_list (occupied X s) (fun q hq=>(every q hq).2)
  have split:=partition X s
  rw [←bag,←packet] at split
  have fullW (v) (hv : v∈ws) := (legal v hv).1
  change (part X (label X s)).card+6*(occupied X s).card=858 at root
  change hits X s (label X s)+5*(occupied X s).card=720 at colors
  have length : es.length+1=289 := by omega
  have count : 245≤classCount s es := by omega
  obtain ⟨f,bij,zero,norm⟩:=route_coverage_at r wd length count (Cap95Profiles.profiles 95)
    (fun v I walk mark observed=>Cap95Profiles.extreme_mask walk mark 0 observed)
  have closed:=WheelRelabel.transport_closed fullW (HundredDecomposition.closed_cover h r fullW split) f bij.1 zero
  let vs:=ws.map (List.map f)
  have legal : vs.toFinset.image WheelContacts.wheel⊆allRows := by
    intro row hr
    obtain ⟨v,hv,rfl⟩:=Finset.mem_image.mp hr
    obtain ⟨x,old,rfl⟩:=List.mem_map.mp (List.mem_toFinset.mp hv)
    have fullX:=fullW x old
    have fullV : full (x.map f) := ⟨by simpa using fullX.1,fullX.2.map bij.1⟩
    obtain ⟨base,admissible,rows⟩:=WheelContacts.complete fullV
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨base,admissible,rows⟩)
  exact ⟨_,norm,_,legal,Finset.card_image_le.trans ((List.toFinset_card_le vs).trans
    (by simpa [vs] using (num.trans card).le)),closed⟩

end ExactWordFlow.Cap95Geometry

import ResidualIncidence

namespace ExactWordFlow.ResidualIncidence
open ResidualDensity

/-- Two surplus groups sharing h positive rotation-class contacts waste at least
h-1 of the separately counted connections. This applies to arbitrary groups
constant along extra edges, including the weak residual components. -/
theorem overlap_loss {ι : Type*} [DecidableEq ι] {X : Multiset Block} {s t : Block}
    (g : Block → ι) (h : Feasible X s t) (hg : ∀ e∈X, g (src e)=g (dst e))
    {a b : ι} (ne : a≠b) (ha : a∈(support X s).image g) (hb : b∈(support X s).image g)
    (shared : ((contacts (support X s) g a) ∩ (contacts (support X s) g b)).Nonempty) :
    719 + (((contacts (support X s) g a) ∩ (contacts (support X s) g b)).card-1) ≤
      ∑ q ∈ (support X s).image g, ((contacts (support X s) g q).card-1) := by
  classical
  let D := support X s
  let Q := D.image g
  let C := contacts D g
  let merge (x : ι) := if x=b then a else x
  let f := merge ∘ g
  let R := (Q.erase b).erase a
  have hq : D.image f=Q.erase b := by
    ext x
    simp only [Finset.mem_image,Finset.mem_erase]
    constructor
    · rintro ⟨v,hv,rfl⟩
      by_cases eq : g v=b
      · have fe : f v=a := by simp [f,merge,eq]
        rw [fe]
        exact ⟨ne,ha⟩
      · have fe : f v=g v := by simp [f,merge,eq]
        rw [fe]
        exact ⟨eq,Finset.mem_image_of_mem g hv⟩
    · rintro ⟨xb,hx⟩
      obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hx
      exact ⟨_,hv,by simp [f,merge,xb]⟩
  have outside (q : ι) (qa : q≠a) (qb : q≠b) : contacts D f q=C q := by
    apply congrArg (Finset.image tag)
    apply Finset.filter_congr
    intro v _
    by_cases eq : g v=b <;> simp [f,merge,eq,Ne.symm qa,Ne.symm qb]
  have both : contacts D f a = C a ∪ C b := by
    ext x
    simp only [contacts,C,Finset.mem_union,Finset.mem_image,Finset.mem_filter]
    constructor
    · rintro ⟨v,⟨hv,eq,full⟩,id⟩
      by_cases ev : g v=b
      · exact Or.inr ⟨v,⟨hv,ev,full⟩,id⟩
      · exact Or.inl ⟨v,⟨hv,by simpa [f,merge,ev] using eq,full⟩,id⟩
    · rintro (⟨v,⟨hv,eq,hv'⟩,rfl⟩|⟨v,⟨hv,eq,hv'⟩,rfl⟩) <;>
        exact ⟨v,⟨hv,by simp [f,merge,eq,ne],hv'⟩,rfl⟩
  have rr := rank719 f h (fun e he => congrArg merge (hg e he))
  change 719 ≤ ∑ q ∈ D.image f, ((contacts D f q).card-1) at rr
  have ain : a∈Q.erase b := Finset.mem_erase.mpr ⟨ne,ha⟩
  have sum_out : ∑ q∈R, ((contacts D f q).card-1) = ∑ q∈R, ((C q).card-1) := by
    apply Finset.sum_congr rfl
    intro q hq
    obtain ⟨qa,mem⟩ := Finset.mem_erase.mp hq
    rw [outside q qa (Finset.mem_erase.mp mem).1]
  have sum₁ := Finset.sum_erase_add (s:=Q.erase b) (fun q => (contacts D f q).card-1) ain
  have sum₂ := Finset.sum_erase_add (s:=Q.erase b) (fun q => (C q).card-1) ain
  have sum₃ := Finset.sum_erase_add (s:=Q) (fun q => (C q).card-1) hb
  rw [hq,←sum₁,both] at rr
  change 719 ≤ (∑ q∈R, ((contacts D f q).card-1)) + ((C a ∪ C b).card-1) at rr
  rw [sum_out] at rr
  change 719+((C a ∩ C b).card-1) ≤ ∑ q∈Q, ((C q).card-1)
  rw [←sum₃,←sum₂]
  have jp := Finset.card_union_add_card_inter (C a) (C b)
  have ip : 0<(C a ∩ C b).card := Finset.card_pos.mpr shared
  have ap := Finset.card_le_card (Finset.inter_subset_left (s₂:=C b) (s₁:=C a))
  have bp := Finset.card_le_card (Finset.inter_subset_right (s₂:=C b) (s₁:=C a))
  dsimp only [R] at rr
  omega

#print axioms overlap_loss
end ExactWordFlow.ResidualIncidence

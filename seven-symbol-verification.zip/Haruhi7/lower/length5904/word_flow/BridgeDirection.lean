import EndExchange

namespace ExactWordFlow.OnePath66
open SevenWordWindows ResidualDensity DirectedEuler EmbeddedWheels ResidualRoutes
open scoped Classical

/-- A directed bridge of an open integer-balanced graph separates the global
start from the global finish in the orientation of the bridge. -/
theorem bridge_direction {G : Multiset Block} {e s t : Block}
    (bal : (e ::ₘ G).map src+{t}=(e ::ₘ G).map dst+{s})
    (bridge : label G (src e)≠label G (dst e)) :
    label G s=label G (src e) ∧ label G t=label G (dst e) := by
  let f := label G
  have constant : G.map (f ∘ src) = G.map (f ∘ dst) :=
    Multiset.map_congr rfl (fun g hg => on_edge hg)
  have eq := congrArg (Multiset.map f) bal
  simp only [Multiset.map_add,Multiset.map_cons,Multiset.map_singleton,Multiset.map_map,
    Multiset.cons_add] at eq
  rw [constant] at eq
  have reduced : {f (src e)}+{f t} = {f (dst e)}+({f s} : Multiset (Component G)) := by
    apply add_left_cancel (a:=G.map (f ∘ dst))
    simpa only [←Multiset.singleton_add,add_assoc,add_comm,add_left_comm] using eq
  have x : f (src e)∈({f (dst e)}+{f s} : Multiset (Component G)) := by rw [←reduced]; simp
  have y : f (dst e)∈({f (src e)}+{f t} : Multiset (Component G)) := by rw [reduced]; simp
  simp only [Multiset.mem_add,Multiset.mem_singleton] at x y
  exact ⟨(x.resolve_left bridge).symm,(y.resolve_left (Ne.symm bridge)).symm⟩

theorem five_oriented_bridges {a b s t : Block} {es ws : List Block}
    (r : Route src dst a es b) (legit : ∀w∈ws, full w) (classes : classCount a es=390)
    (k : ws.length≤65) (F : Multiset Block) (five : F.card=5)
    (h : Feasible (((↑es : Multiset Block)+turns ws)+F) s t) (e : Block) (mem : e∈F) :
    let G := required+(((↑es : Multiset Block)+turns ws)+F.erase e)
    label G s=label G (src e) ∧ label G t=label G (dst e) ∧ label G s≠label G t := by
  let base := (↑es : Multiset Block)+turns ws
  let G := required+(base+F.erase e)
  have all := (RequiredComponent.together_iff_classes _).mp (RequiredComponent.feasible_together h)
  have split := every_fresh_is_bridge r legit classes k five all mem
  have eq : required+(base+F)=e ::ₘ G := by
    change required+(base+F)=e ::ₘ (required+(base+F.erase e))
    rw [←Multiset.add_cons,←Multiset.add_cons,Multiset.cons_erase mem]
  have bal : (e ::ₘ G).map src+{t}=(e ::ₘ G).map dst+{s} := by
    have req : required.map src=required.map dst := balanced_representatives
    have ext := congrArg (required.map dst + ·) h.balance
    change required.map dst + ((base+F).map src+{t})= required.map dst + ((base+F).map dst+{s}) at ext
    rw [←eq]
    simpa only [Multiset.map_add,req,add_assoc] using ext
  obtain ⟨start,finish⟩ := bridge_direction bal split
  exact ⟨start,finish,fun same => split (start.symm.trans (same.trans finish))⟩

#print axioms five_oriented_bridges
end ExactWordFlow.OnePath66

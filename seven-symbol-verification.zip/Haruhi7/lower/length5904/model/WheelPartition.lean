import OmittedWheels
namespace SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain T5899

/-- Subset of one oriented wheel, represented by part of a single row of
at most six entries. Distinctness is inherited from the original configuration. -/
structure WheelPacket where
  cells : List (Vtx 7)
  positive : 0 < cells.length
  small : cells.length ≤ 5
  wheel : ∃ r : NRow 7, r.len≤6 ∧ ∀ x ∈ cells, x ∈ r.entries

noncomputable def packetDef (p : WheelPacket) : ℤ := 5-(p.cells.length : ℤ)

private theorem packets_of_hanging {c : NConfig 7} (hv : c.Valid) {H : NHanging 7}
    (mem : H ∈ c.hanging) :
    ∃ ps : List WheelPacket,
      (rowsEntries (famH H).flatten ++ ps.flatMap WheelPacket.cells).Perm
          (rowsEntries H.rows) ∧ (ps.map packetDef).sum ≤ slackH H := by
  classical
  have ok := hanging_ok hv mem
  have nonneg := slack_nonneg hv mem
  by_cases free : H.att=0
  · by_cases heavy : 2 ≤ (cutRows H.rows).length
    · obtain ⟨first,last,mid,_,_,_,_,hs,_,_,_,_⟩ := ok.decomp2 heavy
      have flat : (first::(mid++[last])).flatten=H.rows := by rw [←hs]; exact ok.inv.flat
      have rot := rot_entries_perm first last mid
      rw [flat] at rot
      refine ⟨[],?_,by simpa using nonneg⟩
      have groups : famH H=mid++[last++first] := by
        unfold famH
        rw [ite_eq_left free,ite_eq_left heavy,hs,rotSegs_eq]
      simpa [groups] using rot
    · have one : (cutRows H.rows).length=1 := by have := ok.pos; omega
      by_cases big : 2 ≤ H.rows.length
      · obtain ⟨a,mid,b,shape⟩ := exists_first_mid_last big
        obtain ⟨lim,junction⟩ := omitted_ends_geometry hv mem free one shape
        have lenA := ok.len a (by rw [shape]; simp)
        let pkt : WheelPacket := {
          cells := a.entries ++ b.entries
          positive := by simp [NRow.entries_length]; omega
          small := by simpa [NRow.entries_length] using lim
          wheel := by
            refine ⟨mergeRow b a, by change b.len+(a.len+1)≤6; omega,?_⟩
            intro x hx
            have h : x ∈ tau2V b.lastEntry :: (b.entries ++ a.entries) := by
              apply List.mem_cons_of_mem
              exact List.mem_append.mpr ((List.mem_append.mp hx).elim Or.inr Or.inl)
            have hx' := junction.entries.mem_iff.mpr h
            simpa only [rowsEntries_cons,rowsEntries_nil,List.append_nil] using hx'
        }
        refine ⟨[pkt],?_,?_⟩
        · have pieces : (famH H).flatten = mid := by
            by_cases empty : mid=[]
            · subst mid
              have sm : ¬3 ≤ H.rows.length := by simp [shape]
              unfold famH
              rw [ite_eq_left free,ite_eq_right heavy,ite_eq_right sm,List.flatten_nil]
            · have big' : 3≤H.rows.length := by
                have ne := List.length_pos_iff_ne_nil.mpr empty
                have rows : H.rows.length=mid.length+2 := by rw [shape]; simp
                omega
              unfold famH
              rw [ite_eq_left free,ite_eq_right heavy,ite_eq_left big',shape]
              simp
          rw [pieces,shape,rowsEntries_cons,rowsEntries_append]
          simp only [List.flatMap_cons,List.flatMap_nil,List.append_nil,rowsEntries_cons,
            rowsEntries_nil]
          change (rowsEntries mid ++ (a.entries ++ b.entries)).Perm
            (a.entries ++ (rowsEntries mid ++ b.entries))
          simpa only [List.append_assoc] using
            (List.perm_append_comm (l₁:=rowsEntries mid) (l₂:=a.entries)).append_right b.entries
        · have slack := closed_ends_slack hv mem free one shape
          simp only [List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,Int.add_zero,
            packetDef,pkt,List.length_append,NRow.entries_length,Nat.cast_add]
          split at slack <;> omega
      · obtain ⟨r,shape⟩ : ∃ r, H.rows=[r] := by
          cases shape : H.rows with
          | nil => have := ok.ne; contradiction
          | cons a rest =>
            have objectLength := congrArg List.length shape
            rw [List.length_cons] at objectLength
            have len : rest.length=0 := by omega
            exact ⟨a,by simp [List.eq_nil_of_length_eq_zero len]⟩
        obtain ⟨slack,lim⟩ := closed_singleton_slack hv mem free shape
        have lenR := ok.len r (by rw [shape]; simp)
        let pkt : WheelPacket := {
          cells := r.entries
          positive := by rw [NRow.entries_length]; omega
          small := by simpa [NRow.entries_length] using lim
          wheel := ⟨r,by omega,fun _ hh => hh⟩
        }
        refine ⟨[pkt],?_,?_⟩
        · have sm : ¬3 ≤ H.rows.length := by simp [shape]
          have gone : famH H=[] := by
            unfold famH
            rw [ite_eq_left free,ite_eq_right heavy,ite_eq_right sm]
          simp [gone,shape,rowsEntries_cons,rowsEntries_nil,pkt]
        · simp [packetDef,pkt,NRow.entries_length,slack]
  · refine ⟨[], ?_,by simpa using nonneg⟩
    simp [famH,free,ok.inv.flat]

private theorem packet_append (a b c d : List α) :
    ((a++b)++(c++d)).Perm ((a++c)++(b++d)) := by
  simpa only [List.append_assoc] using
    ((List.perm_append_comm (l₁:=b) (l₂:=c)).append_right d).append_left a

private theorem packets_of_list {c : NConfig 7} (hv : c.Valid)
    (hs : List (NHanging 7)) (sub : ∀ H ∈ hs, H∈c.hanging) :
    ∃ ps : List WheelPacket,
      (rowsEntries (hs.flatMap famH).flatten ++ ps.flatMap WheelPacket.cells).Perm
        (hs.flatMap fun H => rowsEntries H.rows) ∧
      (ps.map packetDef).sum ≤ (hs.map slackH).sum := by
  induction hs with
  | nil => exact ⟨[],by simp [rowsEntries_nil],by simp⟩
  | cons H hs ih =>
    obtain ⟨p,hp,sp⟩ := packets_of_hanging hv (sub H List.mem_cons_self)
    obtain ⟨q,hq,sq⟩ := ih (fun X hX => sub X (List.mem_cons_of_mem H hX))
    refine ⟨p++q,?_,?_⟩
    · rw [List.flatMap_cons,List.flatten_append,rowsEntries_append,List.flatMap_append,List.flatMap_cons]
      exact (packet_append _ _ _ _).trans (hp.append hq)
    · simp; omega

/-- The actual classes not retained by the normalized family are partitioned
into packets on wheels; the total deficit below five is bounded by the
difference between the actual and required family value. -/
theorem omitted_partition (c : NConfig 7) (hv : c.Valid) {j : ℕ} (cost : c.cost≤137+j) :
    ∃ ps : List WheelPacket,
      (rowsEntries (famC c).flatten ++ ps.flatMap WheelPacket.cells).Perm c.entries ∧
      (ps.map packetDef).sum + 30+5*(epsC c : ℤ) ≤ lE (prs (famC c))+5*j := by
  obtain ⟨p,hp,sp⟩ := packets_of_list hv c.hanging (fun _ h => h)
  refine ⟨p,?_,?_⟩
  · have kernel := (kernel_ok hv).inv.flat
    unfold famC NConfig.entries
    rw [List.flatten_append,rowsEntries_append,kernel,List.append_assoc]
    exact hp.append_left _
  · have := total_slack c hv cost
    omega

private theorem packet_price (ps : List WheelPacket) :
    (ps.map packetDef).sum + ((ps.flatMap WheelPacket.cells).length : ℤ) =
       5*(ps.length : ℤ) := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    simp only [List.map_cons,List.sum_cons,List.flatMap_cons,List.length_append,
      List.length_cons,Nat.cast_add,Nat.cast_one,packetDef]
    omega

/-- Every standard configuration has a geometric cover whose number of rows,
trails and omitted packets is bounded by its actual cost. -/
theorem partition_at_price (c : NConfig 7) (hv : c.Valid) :
    ∃ ps : List WheelPacket,
      (rowsEntries (famC c).flatten ++ ps.flatMap WheelPacket.cells).Perm c.entries ∧
      (famC c).flatten.length + (famC c).length + epsC c + ps.length ≤ c.cost+1 := by
  obtain ⟨ps,hp,sp⟩ := packets_of_list hv c.hanging (fun _ h => h)
  have part : (rowsEntries (famC c).flatten ++ ps.flatMap WheelPacket.cells).Perm c.entries := by
    have kernel := (kernel_ok hv).inv.flat
    unfold famC NConfig.entries
    rw [List.flatten_append,rowsEntries_append,kernel,List.append_assoc]
    exact hp.append_left _
  have num := part.length_eq
  rw [List.length_append] at num
  have area := rowsEntries_length_add_holes (k:=7)
    (fun r hr => len_le_of_rowsEntries_pairwise (by decide : 2 ≤ 7) (famC_trailFam hv).classes hr)
  change (rowsEntries (famC c).flatten).length + rowsHoles 7 (famC c).flatten =
      6*(famC c).flatten.length at area
  have far := exact_slack c hv
  rw [lE_prs] at far
  have mass := packet_price ps
  exact ⟨ps,part,by omega⟩

end SuperpermLowerBounds.LengthBudget
#print axioms SuperpermLowerBounds.LengthBudget.omitted_partition
#print axioms SuperpermLowerBounds.LengthBudget.partition_at_price

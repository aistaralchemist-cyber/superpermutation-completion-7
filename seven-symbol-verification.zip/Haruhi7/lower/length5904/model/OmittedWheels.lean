import LengthBudget
namespace SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain T5899

/-- The real block representatives form a complete transversal of the
720 cyclic classes. Distinctness gives the upper half of the equality. -/
theorem exact_entries (c : NConfig 7) (hv : c.Valid) : c.entries.length = 720 := by
  have card := (lineWalk_nodup (by decide : 1 ≤ 7) hv.distinct).length_le_card
  rw [Hunter.ProofsRecursion.card_Vtx, length_lineWalk] at card
  have f : Nat.factorial 7=5040 := by decide
  have ge := entries_length_ge hv
  omega

/-- The nonnegative value surplus contributed by an individual attachment.
A zero surplus is forced at every attachment when the family's lower bound
is attained. -/
noncomputable def slackH (H : NHanging 7) : ℤ :=
  lE (prs (famH H)) - vH H - 5*(epsH H : ℤ)

theorem slack_nonneg {c : NConfig 7} (hv : c.Valid) {H : NHanging 7}
    (hH : H ∈ c.hanging) : 0 ≤ slackH H := by
  have := (famH_spec hv hH).2.2.1
  unfold slackH
  omega

private theorem attachment_account : ∀ hs : List (NHanging 7),
    lE (prs (hs.flatMap famH)) = (hs.map slackH).sum + (hs.map vH).sum +
      5*(((hs.map epsH).sum : ℕ) : ℤ)
  | [] => by simp [prs,lE]
  | H :: hs => by
      rw [List.flatMap_cons,prs_append,lE_append,attachment_account hs]
      simp only [List.map_cons,List.sum_cons,Nat.cast_add]
      unfold slackH
      ring

/-- The exact aggregate identity, with the actual configuration cost.
It applies at every length. -/
theorem exact_slack (c : NConfig 7) (hv : c.Valid) :
    (c.hanging.map slackH).sum + (c.entries.length : ℤ) -
      5*(c.cost : ℤ) + 5*(epsC c : ℤ) - 5 = lE (prs (famC c)) := by
  obtain ⟨_,v,_⟩ := accounts hv
  have hk := (kernel_ok hv).seg_num 0
  simp only [Nat.add_zero] at hk
  unfold epsC famC
  rw [prs_append,lE_append,attachment_account]
  simp only [Nat.cast_add]
  omega

/-- Accounting for the entire list, including components that were cut but
contributed no trail. -/
theorem total_slack (c : NConfig 7) (hv : c.Valid) {j : ℕ} (cost : c.cost ≤ 137+j) :
    (c.hanging.map slackH).sum + 30 + 5*(epsC c : ℤ) ≤
        lE (prs (famC c)) + 5*j := by
  obtain ⟨cnt,val,_⟩ := accounts hv
  have hk := (kernel_ok hv).seg_num 0
  simp only [Nat.add_zero] at hk
  unfold epsC famC
  rw [prs_append, lE_append, attachment_account]
  simp only [Nat.cast_add]
  omega

/-- Two or more rows in a free, uncut hanging have both end blocks in one wheel.
The extra block threading them belongs to the same wheel and is not used
by the component. -/
theorem omitted_ends_geometry {c : NConfig 7} (hv : c.Valid) {H : NHanging 7}
    (hH : H ∈ c.hanging) (free : H.att=0) (uncut : (cutRows H.rows).length=1)
    {a b : NRow 7} {mid : List (NRow 7)} (shape : H.rows = a :: (mid ++ [b])) :
    (a.len+b.len ≤ 5) ∧ Junction 7 b a (tau2V b.lastEntry) [mergeRow b a] := by
  have ⟨first,last⟩ := head?_getLast?_of_eq shape
  have size := free_single_len hv hH free uncut shape
  exact ⟨by omega,(free_geom hv hH free last first).1⟩

theorem closed_ends_slack {c : NConfig 7} (hv : c.Valid) {H : NHanging 7}
    (hH : H ∈ c.hanging) (free : H.att=0) (uncut : (cutRows H.rows).length=1)
    {a b : NRow 7} {mid : List (NRow 7)} (shape : H.rows = a :: (mid ++ [b])) :
    slackH H = (5 : ℤ) - a.len - b.len + (if mid=[] then 5 else 0) := by
  have hok := hanging_ok hv hH
  obtain ⟨_,_,zero⟩ := hok.single uncut
  have noeps : epsH H=0 := by simp [epsH, epsR, free, zero, uncut]
  have ha := hok.len_le a (by rw [shape]; simp)
  have hb := hok.len_le b (by rw [shape]; simp)
  have mf : ¬ 2 ≤ (cutRows H.rows).length := by omega
  have ev : vH H = valR H.rows 0 := by unfold vH; rw [zero,free]
  have rows : H.rows.length=mid.length+2 := by rw [shape]; simp
  have holes : rowsHoles 7 H.rows=(6-a.len)+rowsHoles 7 mid+(6-b.len) := by
    rw [shape,rowsHoles_cons,rowsHoles_append,rowsHoles_singleton]
    omega
  unfold slackH
  rw [noeps,ev]
  unfold valR
  rw [rows,holes]
  by_cases empty : mid=[]
  · subst mid
    have short : ¬ 3 ≤ H.rows.length := by simp [shape]
    have fam : famH H = [] := by
      unfold famH
      rw [ite_eq_left free,ite_eq_right mf,ite_eq_right short]
    rw [fam,prs_nil,lE_nil,rowsHoles_nil]
    simp only [List.length_nil, Nat.cast_add, Nat.cast_zero, Nat.cast_ofNat, ite_true,
      Int.mul_zero, Int.sub_zero, Int.zero_add, Nat.add_zero]
    omega
  · have pos : 3 ≤ H.rows.length := by
      have nonzero := List.length_pos_iff_ne_nil.mpr empty
      omega
    have fam : famH H = [mid] := by
      unfold famH
      rw [ite_eq_left free,ite_eq_right mf,ite_eq_left pos,shape]
      simp
    rw [fam,prs_cons,prs_nil,lE_cons,lE_nil,ite_eq_right empty]
    simp only [Nat.cast_add,Nat.cast_zero,Nat.cast_ofNat,Int.mul_zero,Int.add_zero,Int.sub_zero]
    omega

theorem closed_singleton_slack {c : NConfig 7} (hv : c.Valid) {H : NHanging 7}
    (hH : H ∈ c.hanging) (free : H.att=0) {r : NRow 7} (shape : H.rows=[r]) :
    slackH H = (5 : ℤ)-r.len ∧ r.len ≤ 5 := by
  have lim := free_one_len hv hH free shape
  have u : (cutRows H.rows).length=1 := by simp [shape,cutRows]
  have zz := ((hanging_ok hv hH).single u).2.2
  have noeps : epsH H=0 := by simp [epsH,epsR,free,zz,u]
  have fam : famH H = [] := by
    have mf : ¬ 2 ≤ (cutRows H.rows).length := by omega
    have small : ¬ 3 ≤ H.rows.length := by simp [shape]
    unfold famH
    rw [ite_eq_left free,ite_eq_right mf,ite_eq_right small]
  constructor
  · unfold slackH vH valR
    rw [fam,prs_nil,lE_nil,noeps,zz,free,shape,rowsHoles_singleton]
    simp only [List.length_singleton,Nat.cast_one,Nat.cast_zero,Nat.zero_add,
      Int.mul_zero,Int.sub_zero]
    omega
  · exact lim

end SuperpermLowerBounds.LengthBudget
#print axioms SuperpermLowerBounds.LengthBudget.total_slack
#print axioms SuperpermLowerBounds.LengthBudget.omitted_ends_geometry
#print axioms SuperpermLowerBounds.LengthBudget.closed_ends_slack
#print axioms SuperpermLowerBounds.LengthBudget.closed_singleton_slack

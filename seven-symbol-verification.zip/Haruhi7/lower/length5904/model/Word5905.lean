import AllWordPrice
import SevenReference

/-! The literal text of W-0021 by Andrei Teodorescu is supplied, with
attribution, in SevenReference.lean. Decode the decimal digits as Fin 7. -/
namespace SuperpermLowerBounds.LengthBudget.Word5905

def word : List (Fin 7) := SevenReference.word.toList.map fun c =>
  Fin.ofNat 7 (c.toNat - '0'.toNat)

private def allHit : Bool :=
  (List.finRange 7).permutations.all (fun p => decide (List.IsInfix p word))

/-- One native finite check of the length and occurrence of every permutation. -/
private theorem occurrence_table : ((word.length == 5905) && allHit) = true := by
  native_decide

private theorem test_results : (word.length == 5905) = true ∧ allHit = true :=
  (Bool.and_eq_true_iff (x:=word.length == 5905) (y:=allHit)).mp occurrence_table

theorem length_5905 : word.length = 5905 := by
  exact eq_of_beq test_results.1

theorem covers : SuperpermutationBounds.Covers word := by
  intro p len nodup
  have all : p.toFinset = Finset.univ := Finset.eq_univ_of_card p.toFinset
    (by rw [List.toFinset_card_of_nodup nodup,len,Fintype.card_fin])
  have perm : p.Perm (List.finRange 7) := by
    apply (List.perm_ext_iff_of_nodup nodup (List.nodup_finRange _)).mpr
    intro a
    constructor
    · exact fun _ => List.mem_finRange _
    · intro _
      exact List.mem_toFinset.mp (by rw [all]; exact Finset.mem_univ a)
  have table : (List.finRange 7).permutations.all (fun q => decide (List.IsInfix q word)) = true :=
    test_results.2
  have h : decide (List.IsInfix p word) = true :=
    (List.all_eq_true (l:=(List.finRange 7).permutations)
      (p:=fun q => decide (List.IsInfix q word))).mp table p (List.mem_permutations.mpr perm)
  obtain ⟨a,b,e⟩ := of_decide_eq_true h
  exact ⟨a,b,e.symm⟩

theorem geometric_price_142 : geometricPrice ≤ 142 := by
  have h := lower_by_geometric_price word covers
  rw [length_5905] at h
  omega

end SuperpermLowerBounds.LengthBudget.Word5905
#print axioms SuperpermLowerBounds.LengthBudget.Word5905.covers
#print axioms SuperpermLowerBounds.LengthBudget.Word5905.geometric_price_142

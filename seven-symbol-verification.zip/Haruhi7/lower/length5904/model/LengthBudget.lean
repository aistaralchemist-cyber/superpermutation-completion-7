import LowerBounds.PTheorem

/-! Seven-letter budget for an arbitrary increase j above 5901.
The normalized configuration and all row/weight identities are from Jakub
Halfar's pinned Almanac library (see the accompanying note). -/
namespace SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain T5899

theorem accounts {c : NConfig 7} (hv : c.Valid) :
    720 ≤ (c.entries.length : ℤ) ∧
    valR c.kernel (rX c.kernel) + (c.hanging.map vH).sum =
        (c.entries.length : ℤ) - 5 * (c.cost : ℤ) ∧
    (wtR c.kernel (rX c.kernel) : ℤ) + ((c.hanging.map wH).sum : ℤ) =
        6 * (c.cost : ℤ) - (c.entries.length : ℤ) := by
  have hlen := hv.len_le (by decide : 2 ≤ 7)
  refine ⟨by exact_mod_cast entries_length_ge hv, ?_, ?_⟩
  · rw [valR_eq hlen.1, sum_vH c.hanging hlen.2]
    unfold NConfig.entries NConfig.cost
    simp only [List.length_append, Nat.cast_add, rowsCost_eq]
    push_cast
    ring
  · rw [wtR_eq hlen.1, sum_wH c.hanging hlen.2]
    unfold NConfig.entries NConfig.cost
    simp only [List.length_append, Nat.cast_add, rowsCost_eq]
    push_cast
    ring

theorem costs (c : NConfig 7) (hv : c.Valid) {j : ℕ} (hc : c.cost ≤ 137+j) :
    30 + 5*(epsC c : ℤ) ≤ lE (prs (famC c)) + 5*j ∧
    lW (prs (famC c)) + 6*epsC c ≤ 108 + 6*j := by
  obtain ⟨hE,hv0,hw0⟩ := accounts hv
  obtain ⟨hvalue,hweight⟩ := famC_num hv
  omega

theorem budget_of_covers (w : List (Fin 7)) (hw : SuperpermutationBounds.Covers w)
    {j : Nat} (length : w.length ≤ 5901+j) :
    ∃ c : NConfig 7, c.Valid ∧ c.cost ≤ 137+j ∧
      30 + 5*(epsC c : ℤ) ≤ lE (prs (famC c)) + 5*j ∧
      lW (prs (famC c)) + 6*epsC c ≤ 108+6*j := by
  obtain ⟨c,hv,h⟩ := exists_stdConfig_of_covers (by decide : 5 ≤ 7) hw
  have hn : hpv 7 = 5884 := by decide
  have hf : (7-2).factorial = 120 := by decide
  have hc : c.cost ≤ 137+j := by omega
  exact ⟨c,hv,hc,costs c hv hc⟩

private theorem short_price (h0 : ChainCap Mf 84) {F : List (List (NRow 7))}
    (hF : TrailFam 7 F) (small : rowsHoles 7 F.flatten ≤ 45) :
    lE (prs F) ≤ (rowsHoles 7 F.flatten : ℤ) := by
  have cell : ∀ i : Fin 46, Mf i.val ≤ 2*i.val+5 := by decide
  induction F with
  | nil => simp [prs, lE, rowsHoles]
  | cons A F ih =>
    have pair := hF.classes
    rw [List.flatten_cons, rowsEntries_append, List.pairwise_append] at pair
    have tail : TrailFam 7 F :=
      ⟨fun B h => hF.trails B (List.mem_cons_of_mem A h), pair.2.1⟩
    rw [List.flatten_cons, rowsHoles_append] at small ⊢
    have hcap := chain_cap_rows h0 (hF.trails A List.mem_cons_self) pair.1 (by omega)
    have hi := cell ⟨rowsHoles 7 A,by omega⟩
    change Mf (rowsHoles 7 A) ≤ 2 * rowsHoles 7 A + 5 at hi
    have htail := ih tail (by omega)
    rw [prs_cons, lE_cons]
    simp only [Nat.cast_add]
    omega

theorem family_constraints (cap : ChainCap Mf 84) (prof : Profiles)
    (c : NConfig 7) (hv : c.Valid) {j : ℕ} (hc : c.cost ≤ 137+j) :
    epsC c ≤ j+3 ∧ 6*(famC c).length + 11*epsC c ≤ 78+11*j ∧
    (epsC c = j+3 → (famC c).length ≤ 6) := by
  let F := famC c
  have valid := famC_trailFam hv
  obtain ⟨value,weight⟩ := costs c hv hc
  have net : epsC c ≤ j+3 := by
    by_contra! h
    have upper := family_le_49 cap prof valid (by omega)
    omega
  have mass := lW_prs (famC c)
  refine ⟨net, ?_, ?_⟩
  · by_contra! h
    have small : rowsHoles 7 (famC c).flatten ≤ 45 := by omega
    have price := short_price cap valid small
    omega
  · intro eq
    by_contra! many
    have upper := family_le_44 cap valid (by omega) (by omega)
    omega

/-- Separate, explicit finite geometry assumptions for the lower side of the
trail-count window. They apply to abstract disjoint trails at the effective
excess, independently of the actual excess of the normalized word. -/
def TrailCap (size budget floor : ℕ) :=
  ∀ F : List (List (NRow 7)), TrailFam 7 F → F.length=size →
    rowsHoles 7 F.flatten ≤ budget →
    (F.flatten.length : ℤ) - (rowsHoles 7 F.flatten : ℤ) < floor

theorem additional_limits (cap : ChainCap Mf 84) (profiles : Profiles)
    (one : TrailCap 1 96 40) (two : TrailCap 2 84 50)
    (three : TrailCap 3 72 60) (five : TrailCap 5 60 70) (six : TrailCap 6 54 75)
    (c : NConfig 7) (hv : c.Valid) {j : ℕ} (hj : j ≤ 3) (hc : c.cost ≤ 137+j) :
    1 ≤ (famC c).length ∧ epsC c+1 ≤ (famC c).length+j ∧
      (epsC c = j+3 → (famC c).length = 4) := by
  have F := famC_trailFam hv
  obtain ⟨lo,hi⟩ := costs c hv hc
  rw [lE_prs] at lo
  rw [lW_prs] at hi
  obtain ⟨net,_,high⟩ := family_constraints cap profiles c hv hc
  have pos : 1 ≤ (famC c).length := by
    by_contra! neg
    have h : famC c = [] := List.eq_nil_of_length_eq_zero (by omega)
    rw [h] at lo
    simp [rowsHoles] at lo
    omega
  have small : epsC c+1 ≤ (famC c).length+j := by
    by_contra! h
    have cases : (famC c).length=1 ∨ (famC c).length=2 ∨ (famC c).length=3 := by omega
    rcases cases with c1|c2|c3
    · have := one _ F c1 (by omega)
      omega
    · have := two _ F c2 (by omega)
      omega
    · have := three _ F c3 (by omega)
      omega
  refine ⟨pos,small,?_⟩
  intro eq
  have top := high eq
  by_contra! h
  have cases : (famC c).length=5 ∨ (famC c).length=6 := by omega
  rcases cases with c5|c6
  · have := five _ F c5 (by omega)
    omega
  · have := six _ F c6 (by omega)
    omega

/-- The cumulative threshold for proving 5905: this single instance
includes all lengths at most 5904. -/
theorem word_5904 (cap : ChainCap Mf 84) (profiles : Profiles)
    (w : List (Fin 7)) (hw : SuperpermutationBounds.Covers w) (hl : w.length ≤ 5904) :
    ∃ c : NConfig 7, c.Valid ∧ c.cost ≤ 140 ∧
      15+5*(epsC c : ℤ) ≤ lE (prs (famC c)) ∧
      lW (prs (famC c)) + 6*epsC c ≤ 126 ∧ epsC c≤6 ∧
      6*(famC c).length + 11*epsC c ≤ 111 := by
  obtain ⟨c,hv,hc,lo,hi⟩ := budget_of_covers w hw (j:=3) hl
  have ⟨e,m,_⟩ := family_constraints cap profiles c hv hc
  exact ⟨c,hv,hc,by omega,by omega,by omega,by omega⟩

end SuperpermLowerBounds.LengthBudget
#print axioms SuperpermLowerBounds.LengthBudget.budget_of_covers
#print axioms SuperpermLowerBounds.LengthBudget.family_constraints
#print axioms SuperpermLowerBounds.LengthBudget.additional_limits

#print axioms SuperpermLowerBounds.LengthBudget.word_5904

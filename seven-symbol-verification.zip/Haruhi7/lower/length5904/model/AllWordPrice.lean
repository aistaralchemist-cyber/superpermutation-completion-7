import WheelPartition

namespace SuperpermLowerBounds.LengthBudget
open Hunter PreimageChain T5899

/-- For every covering word, the genuine row representative of every rotation
class belongs to this trail family or exactly one of its omitted wheel packets.
The right-hand side uses the word's own length. No finite chain cap or
endpoint computation is assumed. -/
theorem all_word_price (w : List (Fin 7)) (covered : SuperpermutationBounds.Covers w) :
    ∃ (F : List (List (NRow 7))) (ps : List WheelPacket),
      TrailFam 7 F ∧
      (let U := rowsEntries F.flatten ++ ps.flatMap WheelPacket.cells
       U.length = 720 ∧ U.Pairwise (NotRot (k:=7)) ∧
         ∀ v : Vtx 7, ∃ x ∈ U, (v : List ℕ) ~r (x : List ℕ)) ∧
      5763 + F.flatten.length + F.length + ps.length ≤ w.length := by
  obtain ⟨c,hv,length⟩ := exists_stdConfig_of_covers (by decide : 5 ≤ 7) covered
  obtain ⟨p,part,price⟩ := partition_at_price c hv
  refine ⟨famC c,p,famC_trailFam hv,?_,?_⟩
  · exact ⟨part.length_eq.trans (exact_entries c hv),pairwise_of_perm hv.distinct part,
      fun v => by
        obtain ⟨x,mem,rot⟩ := hv.cover v
        exact ⟨x,part.mem_iff.mpr mem,rot⟩⟩
  · have hn : hpv 7 = 5884 := by decide
    have hf : (7-2).factorial = 120 := by decide
    omega

/-- Minimum price over every geometric covering partition. A partition is
charged one unit per row, trail, and omitted wheel packet. Minimizing over
trail orders also minimizes the number of trails needed for each row set. -/
noncomputable def geometricPrice : Nat :=
  sInf {n : Nat | ∃ (F : List (List (NRow 7))) (ps : List WheelPacket),
    TrailFam 7 F ∧
    (let U := rowsEntries F.flatten ++ ps.flatMap WheelPacket.cells
     U.length = 720 ∧ U.Pairwise (NotRot (k:=7)) ∧
       ∀ v : Vtx 7, ∃ x ∈ U, (v : List ℕ) ~r (x : List ℕ)) ∧
    n = F.flatten.length + F.length + ps.length}

/-- The lower bound for every seven-letter covering word. -/
theorem lower_by_geometric_price (w : List (Fin 7)) (hw : SuperpermutationBounds.Covers w) :
    5763 + geometricPrice ≤ w.length := by
  obtain ⟨F,ps,family,coverage,price⟩ := all_word_price w hw
  have low : geometricPrice ≤ F.flatten.length + F.length + ps.length :=
    Nat.sInf_le ⟨F,ps,family,coverage,rfl⟩
  omega

theorem sufficient_price (lower : 142 ≤ geometricPrice) (w : List (Fin 7))
    (hw : SuperpermutationBounds.Covers w) : 5905 ≤ w.length := by
  have := lower_by_geometric_price w hw
  omega

end SuperpermLowerBounds.LengthBudget
#print axioms SuperpermLowerBounds.LengthBudget.all_word_price
#print axioms SuperpermLowerBounds.LengthBudget.lower_by_geometric_price
